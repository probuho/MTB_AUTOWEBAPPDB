package org.dom4j;

import java.util.List;
import java.util.Map;
import org.jaxen.FunctionContext;
import org.jaxen.NamespaceContext;
import org.jaxen.VariableContext;

public interface XPath extends NodeFilter {
  String getText();
  
  boolean matches(Node paramNode);
  
  Object evaluate(Object paramObject);
  
  Object selectObject(Object paramObject);
  
  List selectNodes(Object paramObject);
  
  List selectNodes(Object paramObject, XPath paramXPath);
  
  List selectNodes(Object paramObject, XPath paramXPath, boolean paramBoolean);
  
  Node selectSingleNode(Object paramObject);
  
  String valueOf(Object paramObject);
  
  Number numberValueOf(Object paramObject);
  
  boolean booleanValueOf(Object paramObject);
  
  void sort(List paramList);
  
  void sort(List paramList, boolean paramBoolean);
  
  FunctionContext getFunctionContext();
  
  void setFunctionContext(FunctionContext paramFunctionContext);
  
  NamespaceContext getNamespaceContext();
  
  void setNamespaceContext(NamespaceContext paramNamespaceContext);
  
  void setNamespaceURIs(Map paramMap);
  
  VariableContext getVariableContext();
  
  void setVariableContext(VariableContext paramVariableContext);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\XPath.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */