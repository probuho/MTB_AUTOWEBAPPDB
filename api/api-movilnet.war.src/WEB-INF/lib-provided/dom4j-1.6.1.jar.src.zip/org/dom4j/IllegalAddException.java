/*    */ package org.dom4j;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalAddException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public IllegalAddException(String reason) {
/* 20 */     super(reason);
/*    */   }
/*    */   
/*    */   public IllegalAddException(Element parent, Node node, String reason) {
/* 24 */     super("The node \"" + node.toString() + "\" could not be added to the element \"" + parent.getQualifiedName() + "\" because: " + reason);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IllegalAddException(Branch parent, Node node, String reason) {
/* 30 */     super("The node \"" + node.toString() + "\" could not be added to the branch \"" + parent.getName() + "\" because: " + reason);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\IllegalAddException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */