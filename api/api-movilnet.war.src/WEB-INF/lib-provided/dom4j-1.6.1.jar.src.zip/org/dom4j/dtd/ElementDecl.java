/*    */ package org.dom4j.dtd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementDecl
/*    */ {
/*    */   private String name;
/*    */   private String model;
/*    */   
/*    */   public ElementDecl() {}
/*    */   
/*    */   public ElementDecl(String name, String model) {
/* 29 */     this.name = name;
/* 30 */     this.model = model;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 39 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setName(String name) {
/* 49 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getModel() {
/* 58 */     return this.model;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setModel(String model) {
/* 68 */     this.model = model;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 72 */     return "<!ELEMENT " + this.name + " " + this.model + ">";
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\dtd\ElementDecl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */