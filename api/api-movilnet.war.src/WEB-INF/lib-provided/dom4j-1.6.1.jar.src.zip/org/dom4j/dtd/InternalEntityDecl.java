/*     */ package org.dom4j.dtd;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalEntityDecl
/*     */ {
/*     */   private String name;
/*     */   private String value;
/*     */   
/*     */   public InternalEntityDecl() {}
/*     */   
/*     */   public InternalEntityDecl(String name, String value) {
/*  30 */     this.name = name;
/*  31 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  40 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/*  50 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  59 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value) {
/*  69 */     this.value = value;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  73 */     StringBuffer buffer = new StringBuffer("<!ENTITY ");
/*     */     
/*  75 */     if (this.name.startsWith("%")) {
/*  76 */       buffer.append("% ");
/*  77 */       buffer.append(this.name.substring(1));
/*     */     } else {
/*  79 */       buffer.append(this.name);
/*     */     } 
/*     */     
/*  82 */     buffer.append(" \"");
/*  83 */     buffer.append(escapeEntityValue(this.value));
/*  84 */     buffer.append("\">");
/*     */     
/*  86 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String escapeEntityValue(String text) {
/*  90 */     StringBuffer result = new StringBuffer();
/*     */     
/*  92 */     for (int i = 0; i < text.length(); i++) {
/*  93 */       char c = text.charAt(i);
/*     */       
/*  95 */       switch (c) {
/*     */         case '<':
/*  97 */           result.append("&#38;#60;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '>':
/* 102 */           result.append("&#62;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '&':
/* 107 */           result.append("&#38;#38;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '\'':
/* 112 */           result.append("&#39;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '"':
/* 117 */           result.append("&#34;");
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 123 */           if (c < ' ') {
/* 124 */             result.append("&#" + c + ";"); break;
/*     */           } 
/* 126 */           result.append(c);
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 133 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\dtd\InternalEntityDecl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */