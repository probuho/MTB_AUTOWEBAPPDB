package org.dom4j.rule;

import org.dom4j.Node;
import org.dom4j.NodeFilter;

public interface Pattern extends NodeFilter {
  public static final short ANY_NODE = 0;
  
  public static final short NONE = 9999;
  
  public static final short NUMBER_OF_TYPES = 14;
  
  public static final double DEFAULT_PRIORITY = 0.5D;
  
  boolean matches(Node paramNode);
  
  double getPriority();
  
  Pattern[] getUnionPatterns();
  
  short getMatchType();
  
  String getMatchesNodeName();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\rule\Pattern.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */