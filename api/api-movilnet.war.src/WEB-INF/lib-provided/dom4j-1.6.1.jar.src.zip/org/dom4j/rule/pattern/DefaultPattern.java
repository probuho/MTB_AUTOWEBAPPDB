/*    */ package org.dom4j.rule.pattern;
/*    */ 
/*    */ import org.dom4j.Node;
/*    */ import org.dom4j.NodeFilter;
/*    */ import org.dom4j.rule.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultPattern
/*    */   implements Pattern
/*    */ {
/*    */   private NodeFilter filter;
/*    */   
/*    */   public DefaultPattern(NodeFilter filter) {
/* 31 */     this.filter = filter;
/*    */   }
/*    */   
/*    */   public boolean matches(Node node) {
/* 35 */     return this.filter.matches(node);
/*    */   }
/*    */   
/*    */   public double getPriority() {
/* 39 */     return 0.5D;
/*    */   }
/*    */   
/*    */   public Pattern[] getUnionPatterns() {
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public short getMatchType() {
/* 47 */     return 0;
/*    */   }
/*    */   
/*    */   public String getMatchesNodeName() {
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\rule\pattern\DefaultPattern.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */