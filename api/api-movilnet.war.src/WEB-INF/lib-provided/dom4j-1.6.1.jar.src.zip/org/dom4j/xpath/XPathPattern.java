/*     */ package org.dom4j.xpath;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.dom4j.InvalidXPathException;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.XPathException;
/*     */ import org.dom4j.rule.Pattern;
/*     */ import org.jaxen.Context;
/*     */ import org.jaxen.ContextSupport;
/*     */ import org.jaxen.JaxenException;
/*     */ import org.jaxen.NamespaceContext;
/*     */ import org.jaxen.SimpleNamespaceContext;
/*     */ import org.jaxen.SimpleVariableContext;
/*     */ import org.jaxen.VariableContext;
/*     */ import org.jaxen.XPathFunctionContext;
/*     */ import org.jaxen.dom4j.DocumentNavigator;
/*     */ import org.jaxen.pattern.Pattern;
/*     */ import org.jaxen.pattern.PatternParser;
/*     */ import org.jaxen.saxpath.SAXPathException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathPattern
/*     */   implements Pattern
/*     */ {
/*     */   private String text;
/*     */   private Pattern pattern;
/*     */   private Context context;
/*     */   
/*     */   public XPathPattern(Pattern pattern) {
/*  45 */     this.pattern = pattern;
/*  46 */     this.text = pattern.getText();
/*  47 */     this.context = new Context(getContextSupport());
/*     */   }
/*     */   
/*     */   public XPathPattern(String text) {
/*  51 */     this.text = text;
/*  52 */     this.context = new Context(getContextSupport());
/*     */     
/*     */     try {
/*  55 */       this.pattern = PatternParser.parse(text);
/*  56 */     } catch (SAXPathException e) {
/*  57 */       throw new InvalidXPathException(text, e.getMessage());
/*  58 */     } catch (Throwable t) {
/*  59 */       throw new InvalidXPathException(text, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean matches(Node node) {
/*     */     try {
/*  65 */       ArrayList list = new ArrayList(1);
/*  66 */       list.add(node);
/*  67 */       this.context.setNodeSet(list);
/*     */       
/*  69 */       return this.pattern.matches(node, this.context);
/*  70 */     } catch (JaxenException e) {
/*  71 */       handleJaxenException(e);
/*     */       
/*  73 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getText() {
/*  78 */     return this.text;
/*     */   }
/*     */   
/*     */   public double getPriority() {
/*  82 */     return this.pattern.getPriority();
/*     */   }
/*     */   
/*     */   public Pattern[] getUnionPatterns() {
/*  86 */     Pattern[] patterns = this.pattern.getUnionPatterns();
/*     */     
/*  88 */     if (patterns != null) {
/*  89 */       int size = patterns.length;
/*  90 */       XPathPattern[] answer = new XPathPattern[size];
/*     */       
/*  92 */       for (int i = 0; i < size; i++) {
/*  93 */         answer[i] = new XPathPattern(patterns[i]);
/*     */       }
/*     */       
/*  96 */       return (Pattern[])answer;
/*     */     } 
/*     */     
/*  99 */     return null;
/*     */   }
/*     */   
/*     */   public short getMatchType() {
/* 103 */     return this.pattern.getMatchType();
/*     */   }
/*     */   
/*     */   public String getMatchesNodeName() {
/* 107 */     return this.pattern.getMatchesNodeName();
/*     */   }
/*     */   
/*     */   public void setVariableContext(VariableContext variableContext) {
/* 111 */     this.context.getContextSupport().setVariableContext(variableContext);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 115 */     return "[XPathPattern: text: " + this.text + " Pattern: " + this.pattern + "]";
/*     */   }
/*     */   
/*     */   protected ContextSupport getContextSupport() {
/* 119 */     return new ContextSupport((NamespaceContext)new SimpleNamespaceContext(), XPathFunctionContext.getInstance(), (VariableContext)new SimpleVariableContext(), DocumentNavigator.getInstance());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleJaxenException(JaxenException exception) throws XPathException {
/* 126 */     throw new XPathException(this.text, exception);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\xpath\XPathPattern.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */