package org.dom4j;

import java.util.Map;

public interface ProcessingInstruction extends Node {
  String getTarget();
  
  void setTarget(String paramString);
  
  String getText();
  
  String getValue(String paramString);
  
  Map getValues();
  
  void setValue(String paramString1, String paramString2);
  
  void setValues(Map paramMap);
  
  boolean removeValue(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\ProcessingInstruction.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */