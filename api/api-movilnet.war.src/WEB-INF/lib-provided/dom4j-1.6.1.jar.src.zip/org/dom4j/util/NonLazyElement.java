/*    */ package org.dom4j.util;
/*    */ 
/*    */ import org.dom4j.Namespace;
/*    */ import org.dom4j.QName;
/*    */ import org.dom4j.tree.BaseElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonLazyElement
/*    */   extends BaseElement
/*    */ {
/*    */   public NonLazyElement(String name) {
/* 25 */     super(name);
/* 26 */     this.attributes = createAttributeList();
/* 27 */     this.content = createContentList();
/*    */   }
/*    */   
/*    */   public NonLazyElement(QName qname) {
/* 31 */     super(qname);
/* 32 */     this.attributes = createAttributeList();
/* 33 */     this.content = createContentList();
/*    */   }
/*    */   
/*    */   public NonLazyElement(String name, Namespace namespace) {
/* 37 */     super(name, namespace);
/* 38 */     this.attributes = createAttributeList();
/* 39 */     this.content = createContentList();
/*    */   }
/*    */   
/*    */   public NonLazyElement(QName qname, int attributeCount) {
/* 43 */     super(qname);
/* 44 */     this.attributes = createAttributeList(attributeCount);
/* 45 */     this.content = createContentList();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4\\util\NonLazyElement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */