package org.dom4j.util;

public interface SingletonStrategy {
  Object instance();
  
  void reset();
  
  void setSingletonClassName(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4\\util\SingletonStrategy.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */