/*    */ package org.dom4j.util;
/*    */ 
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.DocumentFactory;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDataDocumentFactory
/*    */   extends DocumentFactory
/*    */ {
/* 30 */   protected static transient UserDataDocumentFactory singleton = new UserDataDocumentFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DocumentFactory getInstance() {
/* 41 */     return singleton;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Element createElement(QName qname) {
/* 47 */     return (Element)new UserDataElement(qname);
/*    */   }
/*    */   
/*    */   public Attribute createAttribute(Element owner, QName qname, String value) {
/* 51 */     return (Attribute)new UserDataAttribute(qname, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4\\util\UserDataDocumentFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */