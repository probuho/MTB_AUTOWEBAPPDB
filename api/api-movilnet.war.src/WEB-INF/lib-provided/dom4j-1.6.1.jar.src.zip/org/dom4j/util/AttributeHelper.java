/*    */ package org.dom4j.util;
/*    */ 
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeHelper
/*    */ {
/*    */   public static boolean booleanValue(Element element, String attributeName) {
/* 28 */     return booleanValue(element.attribute(attributeName));
/*    */   }
/*    */   
/*    */   public static boolean booleanValue(Element element, QName attributeQName) {
/* 32 */     return booleanValue(element.attribute(attributeQName));
/*    */   }
/*    */   
/*    */   protected static boolean booleanValue(Attribute attribute) {
/* 36 */     if (attribute == null) {
/* 37 */       return false;
/*    */     }
/*    */     
/* 40 */     Object value = attribute.getData();
/*    */     
/* 42 */     if (value == null)
/* 43 */       return false; 
/* 44 */     if (value instanceof Boolean) {
/* 45 */       Boolean b = (Boolean)value;
/*    */       
/* 47 */       return b.booleanValue();
/*    */     } 
/* 49 */     return "true".equalsIgnoreCase(value.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4\\util\AttributeHelper.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */