/*    */ package org.dom4j.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleSingleton
/*    */   implements SingletonStrategy
/*    */ {
/* 23 */   private String singletonClassName = null;
/*    */   
/* 25 */   private Object singletonInstance = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object instance() {
/* 31 */     return this.singletonInstance;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 35 */     if (this.singletonClassName != null) {
/* 36 */       Class clazz = null;
/*    */       try {
/* 38 */         clazz = Thread.currentThread().getContextClassLoader().loadClass(this.singletonClassName);
/*    */         
/* 40 */         this.singletonInstance = clazz.newInstance();
/* 41 */       } catch (Exception ignore) {
/*    */         try {
/* 43 */           clazz = Class.forName(this.singletonClassName);
/* 44 */           this.singletonInstance = clazz.newInstance();
/* 45 */         } catch (Exception ignore2) {}
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSingletonClassName(String singletonClassName) {
/* 53 */     this.singletonClassName = singletonClassName;
/* 54 */     reset();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4\\util\SimpleSingleton.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */