/*    */ package org.dom4j.util;
/*    */ 
/*    */ import org.dom4j.DocumentFactory;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonLazyDocumentFactory
/*    */   extends DocumentFactory
/*    */ {
/* 27 */   protected static transient NonLazyDocumentFactory singleton = new NonLazyDocumentFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DocumentFactory getInstance() {
/* 38 */     return singleton;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Element createElement(QName qname) {
/* 44 */     return (Element)new NonLazyElement(qname);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4\\util\NonLazyDocumentFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */