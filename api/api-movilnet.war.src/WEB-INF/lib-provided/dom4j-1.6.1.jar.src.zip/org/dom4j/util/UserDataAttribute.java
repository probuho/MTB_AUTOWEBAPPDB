/*    */ package org.dom4j.util;
/*    */ 
/*    */ import org.dom4j.QName;
/*    */ import org.dom4j.tree.DefaultAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDataAttribute
/*    */   extends DefaultAttribute
/*    */ {
/*    */   private Object data;
/*    */   
/*    */   public UserDataAttribute(QName qname) {
/* 30 */     super(qname);
/*    */   }
/*    */   
/*    */   public UserDataAttribute(QName qname, String text) {
/* 34 */     super(qname, text);
/*    */   }
/*    */   
/*    */   public Object getData() {
/* 38 */     return this.data;
/*    */   }
/*    */   
/*    */   public void setData(Object data) {
/* 42 */     this.data = data;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4\\util\UserDataAttribute.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */