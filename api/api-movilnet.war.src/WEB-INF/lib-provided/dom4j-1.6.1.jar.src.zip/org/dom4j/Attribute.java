package org.dom4j;

public interface Attribute extends Node {
  QName getQName();
  
  Namespace getNamespace();
  
  void setNamespace(Namespace paramNamespace);
  
  String getNamespacePrefix();
  
  String getNamespaceURI();
  
  String getQualifiedName();
  
  String getValue();
  
  void setValue(String paramString);
  
  Object getData();
  
  void setData(Object paramObject);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\Attribute.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */