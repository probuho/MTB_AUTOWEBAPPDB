/*    */ package org.dom4j.datatype;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidSchemaException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public InvalidSchemaException(String reason) {
/* 20 */     super(reason);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\datatype\InvalidSchemaException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */