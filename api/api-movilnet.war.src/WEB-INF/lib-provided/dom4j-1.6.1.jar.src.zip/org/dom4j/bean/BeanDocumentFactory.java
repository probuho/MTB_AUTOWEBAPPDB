/*    */ package org.dom4j.bean;
/*    */ 
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.DocumentFactory;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.QName;
/*    */ import org.dom4j.tree.DefaultAttribute;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanDocumentFactory
/*    */   extends DocumentFactory
/*    */ {
/* 33 */   private static BeanDocumentFactory singleton = new BeanDocumentFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DocumentFactory getInstance() {
/* 43 */     return singleton;
/*    */   }
/*    */ 
/*    */   
/*    */   public Element createElement(QName qname) {
/* 48 */     Object bean = createBean(qname);
/*    */     
/* 50 */     if (bean == null) {
/* 51 */       return (Element)new BeanElement(qname);
/*    */     }
/* 53 */     return (Element)new BeanElement(qname, bean);
/*    */   }
/*    */ 
/*    */   
/*    */   public Element createElement(QName qname, Attributes attributes) {
/* 58 */     Object bean = createBean(qname, attributes);
/*    */     
/* 60 */     if (bean == null) {
/* 61 */       return (Element)new BeanElement(qname);
/*    */     }
/* 63 */     return (Element)new BeanElement(qname, bean);
/*    */   }
/*    */ 
/*    */   
/*    */   public Attribute createAttribute(Element owner, QName qname, String value) {
/* 68 */     return (Attribute)new DefaultAttribute(qname, value);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object createBean(QName qname) {
/* 73 */     return null;
/*    */   }
/*    */   
/*    */   protected Object createBean(QName qname, Attributes attributes) {
/* 77 */     String value = attributes.getValue("class");
/*    */     
/* 79 */     if (value != null) {
/*    */       try {
/* 81 */         Class beanClass = Class.forName(value, true, BeanDocumentFactory.class.getClassLoader());
/*    */ 
/*    */         
/* 84 */         return beanClass.newInstance();
/* 85 */       } catch (Exception e) {
/* 86 */         handleException(e);
/*    */       } 
/*    */     }
/*    */     
/* 90 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void handleException(Exception e) {
/* 95 */     System.out.println("#### Warning: couldn't create bean: " + e);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\bean\BeanDocumentFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */