/*     */ package org.dom4j.dom;
/*     */ 
/*     */ import org.dom4j.CharacterData;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.tree.DefaultComment;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMComment
/*     */   extends DefaultComment
/*     */   implements Comment
/*     */ {
/*     */   public DOMComment(String text) {
/*  28 */     super(text);
/*     */   }
/*     */   
/*     */   public DOMComment(Element parent, String text) {
/*  32 */     super(parent, text);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(String feature, String version) {
/*  38 */     return DOMNodeHelper.supports((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/*  42 */     return DOMNodeHelper.getNamespaceURI((Node)this);
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  46 */     return DOMNodeHelper.getPrefix((Node)this);
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) throws DOMException {
/*  50 */     DOMNodeHelper.setPrefix((Node)this, prefix);
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/*  54 */     return DOMNodeHelper.getLocalName((Node)this);
/*     */   }
/*     */   
/*     */   public String getNodeName() {
/*  58 */     return "#comment";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNodeValue() throws DOMException {
/*  65 */     return DOMNodeHelper.getNodeValue((Node)this);
/*     */   }
/*     */   
/*     */   public void setNodeValue(String nodeValue) throws DOMException {
/*  69 */     DOMNodeHelper.setNodeValue((Node)this, nodeValue);
/*     */   }
/*     */   
/*     */   public Node getParentNode() {
/*  73 */     return DOMNodeHelper.getParentNode((Node)this);
/*     */   }
/*     */   
/*     */   public NodeList getChildNodes() {
/*  77 */     return DOMNodeHelper.getChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node getFirstChild() {
/*  81 */     return DOMNodeHelper.getFirstChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getLastChild() {
/*  85 */     return DOMNodeHelper.getLastChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getPreviousSibling() {
/*  89 */     return DOMNodeHelper.getPreviousSibling((Node)this);
/*     */   }
/*     */   
/*     */   public Node getNextSibling() {
/*  93 */     return DOMNodeHelper.getNextSibling((Node)this);
/*     */   }
/*     */   
/*     */   public NamedNodeMap getAttributes() {
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   public Document getOwnerDocument() {
/* 101 */     return DOMNodeHelper.getOwnerDocument((Node)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node insertBefore(Node newChild, Node refChild) throws DOMException {
/* 106 */     checkNewChildNode(newChild);
/*     */     
/* 108 */     return DOMNodeHelper.insertBefore((Node)this, newChild, refChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node replaceChild(Node newChild, Node oldChild) throws DOMException {
/* 113 */     checkNewChildNode(newChild);
/*     */     
/* 115 */     return DOMNodeHelper.replaceChild((Node)this, newChild, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node removeChild(Node oldChild) throws DOMException {
/* 120 */     return DOMNodeHelper.removeChild((Node)this, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node appendChild(Node newChild) throws DOMException {
/* 125 */     checkNewChildNode(newChild);
/*     */     
/* 127 */     return DOMNodeHelper.appendChild((Node)this, newChild);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkNewChildNode(Node newChild) throws DOMException {
/* 132 */     throw new DOMException((short)3, "Comment nodes cannot have children");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasChildNodes() {
/* 137 */     return DOMNodeHelper.hasChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node cloneNode(boolean deep) {
/* 141 */     return DOMNodeHelper.cloneNode((Node)this, deep);
/*     */   }
/*     */   
/*     */   public void normalize() {
/* 145 */     DOMNodeHelper.normalize((Node)this);
/*     */   }
/*     */   
/*     */   public boolean isSupported(String feature, String version) {
/* 149 */     return DOMNodeHelper.isSupported((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public boolean hasAttributes() {
/* 153 */     return DOMNodeHelper.hasAttributes((Node)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getData() throws DOMException {
/* 159 */     return DOMNodeHelper.getData((CharacterData)this);
/*     */   }
/*     */   
/*     */   public void setData(String data) throws DOMException {
/* 163 */     DOMNodeHelper.setData((CharacterData)this, data);
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 167 */     return DOMNodeHelper.getLength((CharacterData)this);
/*     */   }
/*     */   
/*     */   public String substringData(int offset, int count) throws DOMException {
/* 171 */     return DOMNodeHelper.substringData((CharacterData)this, offset, count);
/*     */   }
/*     */   
/*     */   public void appendData(String arg) throws DOMException {
/* 175 */     DOMNodeHelper.appendData((CharacterData)this, arg);
/*     */   }
/*     */   
/*     */   public void insertData(int offset, String arg) throws DOMException {
/* 179 */     DOMNodeHelper.insertData((CharacterData)this, offset, arg);
/*     */   }
/*     */   
/*     */   public void deleteData(int offset, int count) throws DOMException {
/* 183 */     DOMNodeHelper.deleteData((CharacterData)this, offset, count);
/*     */   }
/*     */ 
/*     */   
/*     */   public void replaceData(int offset, int count, String arg) throws DOMException {
/* 188 */     DOMNodeHelper.replaceData((CharacterData)this, offset, count, arg);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\dom\DOMComment.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */