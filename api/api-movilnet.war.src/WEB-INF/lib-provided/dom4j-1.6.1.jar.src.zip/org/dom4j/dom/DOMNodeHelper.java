/*     */ package org.dom4j.dom;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.dom4j.Branch;
/*     */ import org.dom4j.CharacterData;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentType;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Node;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMNodeHelper
/*     */ {
/*  33 */   public static final NodeList EMPTY_NODE_LIST = new EmptyNodeList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean supports(Node node, String feature, String version) {
/*  41 */     return false;
/*     */   }
/*     */   
/*     */   public static String getNamespaceURI(Node node) {
/*  45 */     return null;
/*     */   }
/*     */   
/*     */   public static String getPrefix(Node node) {
/*  49 */     return null;
/*     */   }
/*     */   
/*     */   public static String getLocalName(Node node) {
/*  53 */     return null;
/*     */   }
/*     */   
/*     */   public static void setPrefix(Node node, String prefix) throws DOMException {
/*  57 */     notSupported();
/*     */   }
/*     */   
/*     */   public static String getNodeValue(Node node) throws DOMException {
/*  61 */     return node.getText();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setNodeValue(Node node, String nodeValue) throws DOMException {
/*  66 */     node.setText(nodeValue);
/*     */   }
/*     */   
/*     */   public static Node getParentNode(Node node) {
/*  70 */     return asDOMNode((Node)node.getParent());
/*     */   }
/*     */   
/*     */   public static NodeList getChildNodes(Node node) {
/*  74 */     return EMPTY_NODE_LIST;
/*     */   }
/*     */   
/*     */   public static Node getFirstChild(Node node) {
/*  78 */     return null;
/*     */   }
/*     */   
/*     */   public static Node getLastChild(Node node) {
/*  82 */     return null;
/*     */   }
/*     */   
/*     */   public static Node getPreviousSibling(Node node) {
/*  86 */     Element parent = node.getParent();
/*     */     
/*  88 */     if (parent != null) {
/*  89 */       int index = parent.indexOf(node);
/*     */       
/*  91 */       if (index > 0) {
/*  92 */         Node previous = parent.node(index - 1);
/*     */         
/*  94 */         return asDOMNode(previous);
/*     */       } 
/*     */     } 
/*     */     
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   public static Node getNextSibling(Node node) {
/* 102 */     Element parent = node.getParent();
/*     */     
/* 104 */     if (parent != null) {
/* 105 */       int index = parent.indexOf(node);
/*     */       
/* 107 */       if (index >= 0 && 
/* 108 */         ++index < parent.nodeCount()) {
/* 109 */         Node next = parent.node(index);
/*     */         
/* 111 */         return asDOMNode(next);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 116 */     return null;
/*     */   }
/*     */   
/*     */   public static NamedNodeMap getAttributes(Node node) {
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   public static Document getOwnerDocument(Node node) {
/* 124 */     return asDOMDocument(node.getDocument());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Node insertBefore(Node node, Node newChild, Node refChild) throws DOMException {
/* 130 */     if (node instanceof Branch) {
/* 131 */       Branch branch = (Branch)node;
/* 132 */       List list = branch.content();
/* 133 */       int index = list.indexOf(refChild);
/*     */       
/* 135 */       if (index < 0) {
/* 136 */         branch.add((Node)newChild);
/*     */       } else {
/* 138 */         list.add(index, newChild);
/*     */       } 
/*     */       
/* 141 */       return newChild;
/*     */     } 
/* 143 */     throw new DOMException((short)3, "Children not allowed for this node: " + node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Node replaceChild(Node node, Node newChild, Node oldChild) throws DOMException {
/* 151 */     if (node instanceof Branch) {
/* 152 */       Branch branch = (Branch)node;
/* 153 */       List list = branch.content();
/* 154 */       int index = list.indexOf(oldChild);
/*     */       
/* 156 */       if (index < 0) {
/* 157 */         throw new DOMException((short)8, "Tried to replace a non existing child for node: " + node);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 162 */       list.set(index, newChild);
/*     */       
/* 164 */       return oldChild;
/*     */     } 
/* 166 */     throw new DOMException((short)3, "Children not allowed for this node: " + node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Node removeChild(Node node, Node oldChild) throws DOMException {
/* 173 */     if (node instanceof Branch) {
/* 174 */       Branch branch = (Branch)node;
/* 175 */       branch.remove((Node)oldChild);
/*     */       
/* 177 */       return oldChild;
/*     */     } 
/*     */     
/* 180 */     throw new DOMException((short)3, "Children not allowed for this node: " + node);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Node appendChild(Node node, Node newChild) throws DOMException {
/* 186 */     if (node instanceof Branch) {
/* 187 */       Branch branch = (Branch)node;
/* 188 */       Node previousParent = newChild.getParentNode();
/*     */       
/* 190 */       if (previousParent != null) {
/* 191 */         previousParent.removeChild(newChild);
/*     */       }
/*     */       
/* 194 */       branch.add((Node)newChild);
/*     */       
/* 196 */       return newChild;
/*     */     } 
/*     */     
/* 199 */     throw new DOMException((short)3, "Children not allowed for this node: " + node);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean hasChildNodes(Node node) {
/* 204 */     return false;
/*     */   }
/*     */   
/*     */   public static Node cloneNode(Node node, boolean deep) {
/* 208 */     return asDOMNode((Node)node.clone());
/*     */   }
/*     */   
/*     */   public static void normalize(Node node) {
/* 212 */     notSupported();
/*     */   }
/*     */   
/*     */   public static boolean isSupported(Node n, String feature, String version) {
/* 216 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean hasAttributes(Node node) {
/* 220 */     if (node != null && node instanceof Element) {
/* 221 */       return (((Element)node).attributeCount() > 0);
/*     */     }
/* 223 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getData(CharacterData charData) throws DOMException {
/* 230 */     return charData.getText();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setData(CharacterData charData, String data) throws DOMException {
/* 235 */     charData.setText(data);
/*     */   }
/*     */   
/*     */   public static int getLength(CharacterData charData) {
/* 239 */     String text = charData.getText();
/*     */     
/* 241 */     return (text != null) ? text.length() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String substringData(CharacterData charData, int offset, int count) throws DOMException {
/* 246 */     if (count < 0) {
/* 247 */       throw new DOMException((short)1, "Illegal value for count: " + count);
/*     */     }
/*     */ 
/*     */     
/* 251 */     String text = charData.getText();
/* 252 */     int length = (text != null) ? text.length() : 0;
/*     */     
/* 254 */     if (offset < 0 || offset >= length) {
/* 255 */       throw new DOMException((short)1, "No text at offset: " + offset);
/*     */     }
/*     */ 
/*     */     
/* 259 */     if (offset + count > length) {
/* 260 */       return text.substring(offset);
/*     */     }
/*     */     
/* 263 */     return text.substring(offset, offset + count);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void appendData(CharacterData charData, String arg) throws DOMException {
/* 268 */     if (charData.isReadOnly()) {
/* 269 */       throw new DOMException((short)7, "CharacterData node is read only: " + charData);
/*     */     }
/*     */     
/* 272 */     String text = charData.getText();
/*     */     
/* 274 */     if (text == null) {
/* 275 */       charData.setText(text);
/*     */     } else {
/* 277 */       charData.setText(text + arg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void insertData(CharacterData data, int offset, String arg) throws DOMException {
/* 284 */     if (data.isReadOnly()) {
/* 285 */       throw new DOMException((short)7, "CharacterData node is read only: " + data);
/*     */     }
/*     */     
/* 288 */     String text = data.getText();
/*     */     
/* 290 */     if (text == null) {
/* 291 */       data.setText(arg);
/*     */     } else {
/* 293 */       int length = text.length();
/*     */       
/* 295 */       if (offset < 0 || offset > length) {
/* 296 */         throw new DOMException((short)1, "No text at offset: " + offset);
/*     */       }
/*     */       
/* 299 */       StringBuffer buffer = new StringBuffer(text);
/* 300 */       buffer.insert(offset, arg);
/* 301 */       data.setText(buffer.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deleteData(CharacterData charData, int offset, int count) throws DOMException {
/* 309 */     if (charData.isReadOnly()) {
/* 310 */       throw new DOMException((short)7, "CharacterData node is read only: " + charData);
/*     */     }
/*     */     
/* 313 */     if (count < 0) {
/* 314 */       throw new DOMException((short)1, "Illegal value for count: " + count);
/*     */     }
/*     */ 
/*     */     
/* 318 */     String text = charData.getText();
/*     */     
/* 320 */     if (text != null) {
/* 321 */       int length = text.length();
/*     */       
/* 323 */       if (offset < 0 || offset >= length) {
/* 324 */         throw new DOMException((short)1, "No text at offset: " + offset);
/*     */       }
/*     */       
/* 327 */       StringBuffer buffer = new StringBuffer(text);
/* 328 */       buffer.delete(offset, offset + count);
/* 329 */       charData.setText(buffer.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void replaceData(CharacterData charData, int offset, int count, String arg) throws DOMException {
/* 337 */     if (charData.isReadOnly()) {
/* 338 */       throw new DOMException((short)7, "CharacterData node is read only: " + charData);
/*     */     }
/*     */     
/* 341 */     if (count < 0) {
/* 342 */       throw new DOMException((short)1, "Illegal value for count: " + count);
/*     */     }
/*     */ 
/*     */     
/* 346 */     String text = charData.getText();
/*     */     
/* 348 */     if (text != null) {
/* 349 */       int length = text.length();
/*     */       
/* 351 */       if (offset < 0 || offset >= length) {
/* 352 */         throw new DOMException((short)1, "No text at offset: " + offset);
/*     */       }
/*     */       
/* 355 */       StringBuffer buffer = new StringBuffer(text);
/* 356 */       buffer.replace(offset, offset + count, arg);
/* 357 */       charData.setText(buffer.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendElementsByTagName(List list, Branch parent, String name) {
/* 367 */     boolean isStar = "*".equals(name);
/*     */     
/* 369 */     for (int i = 0, size = parent.nodeCount(); i < size; i++) {
/* 370 */       Node node = parent.node(i);
/*     */       
/* 372 */       if (node instanceof Element) {
/* 373 */         Element element = (Element)node;
/*     */         
/* 375 */         if (isStar || name.equals(element.getName())) {
/* 376 */           list.add(element);
/*     */         }
/*     */         
/* 379 */         appendElementsByTagName(list, (Branch)element, name);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void appendElementsByTagNameNS(List list, Branch parent, String namespace, String localName) {
/* 386 */     boolean isStarNS = "*".equals(namespace);
/* 387 */     boolean isStar = "*".equals(localName);
/*     */     
/* 389 */     for (int i = 0, size = parent.nodeCount(); i < size; i++) {
/* 390 */       Node node = parent.node(i);
/*     */       
/* 392 */       if (node instanceof Element) {
/* 393 */         Element element = (Element)node;
/*     */         
/* 395 */         if ((isStarNS || ((namespace == null || namespace.length() == 0) && (element.getNamespaceURI() == null || element.getNamespaceURI().length() == 0)) || (namespace != null && namespace.equals(element.getNamespaceURI()))) && (isStar || localName.equals(element.getName())))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 403 */           list.add(element);
/*     */         }
/*     */         
/* 406 */         appendElementsByTagNameNS(list, (Branch)element, namespace, localName);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NodeList createNodeList(List list) {
/* 414 */     return new NodeList(list) {
/*     */         public Node item(int index) {
/* 416 */           if (index >= getLength())
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 422 */             return null;
/*     */           }
/* 424 */           return DOMNodeHelper.asDOMNode(this.val$list.get(index));
/*     */         }
/*     */ 
/*     */         
/*     */         public int getLength() {
/* 429 */           return this.val$list.size();
/*     */         }
/*     */         private final List val$list;
/*     */       };
/*     */   }
/*     */   public static Node asDOMNode(Node node) {
/* 435 */     if (node == null) {
/* 436 */       return null;
/*     */     }
/*     */     
/* 439 */     if (node instanceof Node) {
/* 440 */       return (Node)node;
/*     */     }
/*     */     
/* 443 */     System.out.println("Cannot convert: " + node + " into a W3C DOM Node");
/*     */     
/* 445 */     notSupported();
/*     */     
/* 447 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Document asDOMDocument(Document document) {
/* 452 */     if (document == null) {
/* 453 */       return null;
/*     */     }
/*     */     
/* 456 */     if (document instanceof Document) {
/* 457 */       return (Document)document;
/*     */     }
/*     */     
/* 460 */     notSupported();
/*     */     
/* 462 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static DocumentType asDOMDocumentType(DocumentType dt) {
/* 467 */     if (dt == null) {
/* 468 */       return null;
/*     */     }
/*     */     
/* 471 */     if (dt instanceof DocumentType) {
/* 472 */       return (DocumentType)dt;
/*     */     }
/*     */     
/* 475 */     notSupported();
/*     */     
/* 477 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Text asDOMText(CharacterData text) {
/* 482 */     if (text == null) {
/* 483 */       return null;
/*     */     }
/*     */     
/* 486 */     if (text instanceof Text) {
/* 487 */       return (Text)text;
/*     */     }
/*     */     
/* 490 */     notSupported();
/*     */     
/* 492 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Element asDOMElement(Node element) {
/* 497 */     if (element == null) {
/* 498 */       return null;
/*     */     }
/*     */     
/* 501 */     if (element instanceof Element) {
/* 502 */       return (Element)element;
/*     */     }
/*     */     
/* 505 */     notSupported();
/*     */     
/* 507 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Attr asDOMAttr(Node attribute) {
/* 512 */     if (attribute == null) {
/* 513 */       return null;
/*     */     }
/*     */     
/* 516 */     if (attribute instanceof Attr) {
/* 517 */       return (Attr)attribute;
/*     */     }
/*     */     
/* 520 */     notSupported();
/*     */     
/* 522 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notSupported() {
/* 533 */     throw new DOMException((short)9, "Not supported yet");
/*     */   }
/*     */   
/*     */   public static class EmptyNodeList
/*     */     implements NodeList {
/*     */     public Node item(int index) {
/* 539 */       return null;
/*     */     }
/*     */     
/*     */     public int getLength() {
/* 543 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\dom\DOMNodeHelper.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */