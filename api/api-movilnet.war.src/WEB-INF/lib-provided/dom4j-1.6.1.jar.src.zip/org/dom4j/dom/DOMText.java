/*     */ package org.dom4j.dom;
/*     */ 
/*     */ import org.dom4j.CharacterData;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.Text;
/*     */ import org.dom4j.tree.DefaultText;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMText
/*     */   extends DefaultText
/*     */   implements Text
/*     */ {
/*     */   public DOMText(String text) {
/*  29 */     super(text);
/*     */   }
/*     */   
/*     */   public DOMText(Element parent, String text) {
/*  33 */     super(parent, text);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(String feature, String version) {
/*  39 */     return DOMNodeHelper.supports((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/*  43 */     return DOMNodeHelper.getNamespaceURI((Node)this);
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  47 */     return DOMNodeHelper.getPrefix((Node)this);
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) throws DOMException {
/*  51 */     DOMNodeHelper.setPrefix((Node)this, prefix);
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/*  55 */     return DOMNodeHelper.getLocalName((Node)this);
/*     */   }
/*     */   
/*     */   public String getNodeName() {
/*  59 */     return "#text";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNodeValue() throws DOMException {
/*  66 */     return DOMNodeHelper.getNodeValue((Node)this);
/*     */   }
/*     */   
/*     */   public void setNodeValue(String nodeValue) throws DOMException {
/*  70 */     DOMNodeHelper.setNodeValue((Node)this, nodeValue);
/*     */   }
/*     */   
/*     */   public Node getParentNode() {
/*  74 */     return DOMNodeHelper.getParentNode((Node)this);
/*     */   }
/*     */   
/*     */   public NodeList getChildNodes() {
/*  78 */     return DOMNodeHelper.getChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node getFirstChild() {
/*  82 */     return DOMNodeHelper.getFirstChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getLastChild() {
/*  86 */     return DOMNodeHelper.getLastChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getPreviousSibling() {
/*  90 */     return DOMNodeHelper.getPreviousSibling((Node)this);
/*     */   }
/*     */   
/*     */   public Node getNextSibling() {
/*  94 */     return DOMNodeHelper.getNextSibling((Node)this);
/*     */   }
/*     */   
/*     */   public NamedNodeMap getAttributes() {
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   public Document getOwnerDocument() {
/* 102 */     return DOMNodeHelper.getOwnerDocument((Node)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node insertBefore(Node newChild, Node refChild) throws DOMException {
/* 107 */     checkNewChildNode(newChild);
/*     */     
/* 109 */     return DOMNodeHelper.insertBefore((Node)this, newChild, refChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node replaceChild(Node newChild, Node oldChild) throws DOMException {
/* 114 */     checkNewChildNode(newChild);
/*     */     
/* 116 */     return DOMNodeHelper.replaceChild((Node)this, newChild, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node removeChild(Node oldChild) throws DOMException {
/* 121 */     return DOMNodeHelper.removeChild((Node)this, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node appendChild(Node newChild) throws DOMException {
/* 126 */     checkNewChildNode(newChild);
/*     */     
/* 128 */     return DOMNodeHelper.appendChild((Node)this, newChild);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkNewChildNode(Node newChild) throws DOMException {
/* 133 */     throw new DOMException((short)3, "Text nodes cannot have children");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasChildNodes() {
/* 138 */     return DOMNodeHelper.hasChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node cloneNode(boolean deep) {
/* 142 */     return DOMNodeHelper.cloneNode((Node)this, deep);
/*     */   }
/*     */   
/*     */   public void normalize() {
/* 146 */     DOMNodeHelper.normalize((Node)this);
/*     */   }
/*     */   
/*     */   public boolean isSupported(String feature, String version) {
/* 150 */     return DOMNodeHelper.isSupported((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public boolean hasAttributes() {
/* 154 */     return DOMNodeHelper.hasAttributes((Node)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getData() throws DOMException {
/* 160 */     return DOMNodeHelper.getData((CharacterData)this);
/*     */   }
/*     */   
/*     */   public void setData(String data) throws DOMException {
/* 164 */     DOMNodeHelper.setData((CharacterData)this, data);
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 168 */     return DOMNodeHelper.getLength((CharacterData)this);
/*     */   }
/*     */   
/*     */   public String substringData(int offset, int count) throws DOMException {
/* 172 */     return DOMNodeHelper.substringData((CharacterData)this, offset, count);
/*     */   }
/*     */   
/*     */   public void appendData(String arg) throws DOMException {
/* 176 */     DOMNodeHelper.appendData((CharacterData)this, arg);
/*     */   }
/*     */   
/*     */   public void insertData(int offset, String arg) throws DOMException {
/* 180 */     DOMNodeHelper.insertData((CharacterData)this, offset, arg);
/*     */   }
/*     */   
/*     */   public void deleteData(int offset, int count) throws DOMException {
/* 184 */     DOMNodeHelper.deleteData((CharacterData)this, offset, count);
/*     */   }
/*     */ 
/*     */   
/*     */   public void replaceData(int offset, int count, String arg) throws DOMException {
/* 189 */     DOMNodeHelper.replaceData((CharacterData)this, offset, count, arg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Text splitText(int offset) throws DOMException {
/* 195 */     if (isReadOnly()) {
/* 196 */       throw new DOMException((short)7, "CharacterData node is read only: " + this);
/*     */     }
/*     */     
/* 199 */     String text = getText();
/* 200 */     int length = (text != null) ? text.length() : 0;
/*     */     
/* 202 */     if (offset < 0 || offset >= length) {
/* 203 */       throw new DOMException((short)1, "No text at offset: " + offset);
/*     */     }
/*     */     
/* 206 */     String start = text.substring(0, offset);
/* 207 */     String rest = text.substring(offset);
/* 208 */     setText(start);
/*     */     
/* 210 */     Element parent = getParent();
/* 211 */     Text newText = createText(rest);
/*     */     
/* 213 */     if (parent != null) {
/* 214 */       parent.add(newText);
/*     */     }
/*     */     
/* 217 */     return DOMNodeHelper.asDOMText((CharacterData)newText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Text createText(String text) {
/* 225 */     return (Text)new DOMText(text);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\dom\DOMText.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */