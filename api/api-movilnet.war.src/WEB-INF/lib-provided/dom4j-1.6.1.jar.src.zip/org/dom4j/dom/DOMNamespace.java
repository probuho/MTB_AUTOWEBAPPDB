/*     */ package org.dom4j.dom;
/*     */ 
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.tree.DefaultNamespace;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMNamespace
/*     */   extends DefaultNamespace
/*     */   implements Node
/*     */ {
/*     */   public DOMNamespace(String prefix, String uri) {
/*  29 */     super(prefix, uri);
/*     */   }
/*     */   
/*     */   public DOMNamespace(Element parent, String prefix, String uri) {
/*  33 */     super(parent, prefix, uri);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(String feature, String version) {
/*  39 */     return DOMNodeHelper.supports((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/*  43 */     return DOMNodeHelper.getNamespaceURI((Node)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix) throws DOMException {
/*  50 */     DOMNodeHelper.setPrefix((Node)this, prefix);
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/*  54 */     return DOMNodeHelper.getLocalName((Node)this);
/*     */   }
/*     */   
/*     */   public String getNodeName() {
/*  58 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNodeValue() throws DOMException {
/*  65 */     return DOMNodeHelper.getNodeValue((Node)this);
/*     */   }
/*     */   
/*     */   public void setNodeValue(String nodeValue) throws DOMException {
/*  69 */     DOMNodeHelper.setNodeValue((Node)this, nodeValue);
/*     */   }
/*     */   
/*     */   public Node getParentNode() {
/*  73 */     return DOMNodeHelper.getParentNode((Node)this);
/*     */   }
/*     */   
/*     */   public NodeList getChildNodes() {
/*  77 */     return DOMNodeHelper.getChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node getFirstChild() {
/*  81 */     return DOMNodeHelper.getFirstChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getLastChild() {
/*  85 */     return DOMNodeHelper.getLastChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getPreviousSibling() {
/*  89 */     return DOMNodeHelper.getPreviousSibling((Node)this);
/*     */   }
/*     */   
/*     */   public Node getNextSibling() {
/*  93 */     return DOMNodeHelper.getNextSibling((Node)this);
/*     */   }
/*     */   
/*     */   public NamedNodeMap getAttributes() {
/*  97 */     return DOMNodeHelper.getAttributes((Node)this);
/*     */   }
/*     */   
/*     */   public Document getOwnerDocument() {
/* 101 */     return DOMNodeHelper.getOwnerDocument((Node)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node insertBefore(Node newChild, Node refChild) throws DOMException {
/* 106 */     return DOMNodeHelper.insertBefore((Node)this, newChild, refChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node replaceChild(Node newChild, Node oldChild) throws DOMException {
/* 111 */     return DOMNodeHelper.replaceChild((Node)this, newChild, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node removeChild(Node oldChild) throws DOMException {
/* 116 */     return DOMNodeHelper.removeChild((Node)this, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node appendChild(Node newChild) throws DOMException {
/* 121 */     return DOMNodeHelper.appendChild((Node)this, newChild);
/*     */   }
/*     */   
/*     */   public boolean hasChildNodes() {
/* 125 */     return DOMNodeHelper.hasChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node cloneNode(boolean deep) {
/* 129 */     return DOMNodeHelper.cloneNode((Node)this, deep);
/*     */   }
/*     */   
/*     */   public void normalize() {
/* 133 */     DOMNodeHelper.normalize((Node)this);
/*     */   }
/*     */   
/*     */   public boolean isSupported(String feature, String version) {
/* 137 */     return DOMNodeHelper.isSupported((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public boolean hasAttributes() {
/* 141 */     return DOMNodeHelper.hasAttributes((Node)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\dom\DOMNamespace.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */