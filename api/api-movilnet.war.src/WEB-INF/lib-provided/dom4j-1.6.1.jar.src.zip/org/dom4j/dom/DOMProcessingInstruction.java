/*     */ package org.dom4j.dom;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.tree.DefaultProcessingInstruction;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMProcessingInstruction
/*     */   extends DefaultProcessingInstruction
/*     */   implements ProcessingInstruction
/*     */ {
/*     */   public DOMProcessingInstruction(String target, Map values) {
/*  32 */     super(target, values);
/*     */   }
/*     */   
/*     */   public DOMProcessingInstruction(String target, String values) {
/*  36 */     super(target, values);
/*     */   }
/*     */   
/*     */   public DOMProcessingInstruction(Element parent, String target, String val) {
/*  40 */     super(parent, target, val);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(String feature, String version) {
/*  46 */     return DOMNodeHelper.supports((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/*  50 */     return DOMNodeHelper.getNamespaceURI((Node)this);
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  54 */     return DOMNodeHelper.getPrefix((Node)this);
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) throws DOMException {
/*  58 */     DOMNodeHelper.setPrefix((Node)this, prefix);
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/*  62 */     return DOMNodeHelper.getLocalName((Node)this);
/*     */   }
/*     */   
/*     */   public String getNodeName() {
/*  66 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNodeValue() throws DOMException {
/*  73 */     return DOMNodeHelper.getNodeValue((Node)this);
/*     */   }
/*     */   
/*     */   public void setNodeValue(String nodeValue) throws DOMException {
/*  77 */     DOMNodeHelper.setNodeValue((Node)this, nodeValue);
/*     */   }
/*     */   
/*     */   public Node getParentNode() {
/*  81 */     return DOMNodeHelper.getParentNode((Node)this);
/*     */   }
/*     */   
/*     */   public NodeList getChildNodes() {
/*  85 */     return DOMNodeHelper.getChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node getFirstChild() {
/*  89 */     return DOMNodeHelper.getFirstChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getLastChild() {
/*  93 */     return DOMNodeHelper.getLastChild((Node)this);
/*     */   }
/*     */   
/*     */   public Node getPreviousSibling() {
/*  97 */     return DOMNodeHelper.getPreviousSibling((Node)this);
/*     */   }
/*     */   
/*     */   public Node getNextSibling() {
/* 101 */     return DOMNodeHelper.getNextSibling((Node)this);
/*     */   }
/*     */   
/*     */   public NamedNodeMap getAttributes() {
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   public Document getOwnerDocument() {
/* 109 */     return DOMNodeHelper.getOwnerDocument((Node)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node insertBefore(Node newChild, Node refChild) throws DOMException {
/* 114 */     checkNewChildNode(newChild);
/*     */     
/* 116 */     return DOMNodeHelper.insertBefore((Node)this, newChild, refChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node replaceChild(Node newChild, Node oldChild) throws DOMException {
/* 121 */     checkNewChildNode(newChild);
/*     */     
/* 123 */     return DOMNodeHelper.replaceChild((Node)this, newChild, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node removeChild(Node oldChild) throws DOMException {
/* 128 */     return DOMNodeHelper.removeChild((Node)this, oldChild);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node appendChild(Node newChild) throws DOMException {
/* 133 */     checkNewChildNode(newChild);
/*     */     
/* 135 */     return DOMNodeHelper.appendChild((Node)this, newChild);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkNewChildNode(Node newChild) throws DOMException {
/* 140 */     throw new DOMException((short)3, "PI nodes cannot have children");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasChildNodes() {
/* 145 */     return DOMNodeHelper.hasChildNodes((Node)this);
/*     */   }
/*     */   
/*     */   public Node cloneNode(boolean deep) {
/* 149 */     return DOMNodeHelper.cloneNode((Node)this, deep);
/*     */   }
/*     */   
/*     */   public void normalize() {
/* 153 */     DOMNodeHelper.normalize((Node)this);
/*     */   }
/*     */   
/*     */   public boolean isSupported(String feature, String version) {
/* 157 */     return DOMNodeHelper.isSupported((Node)this, feature, version);
/*     */   }
/*     */   
/*     */   public boolean hasAttributes() {
/* 161 */     return DOMNodeHelper.hasAttributes((Node)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getData() {
/* 168 */     return getText();
/*     */   }
/*     */   
/*     */   public void setData(String data) throws DOMException {
/* 172 */     if (isReadOnly()) {
/* 173 */       throw new DOMException((short)7, "This ProcessingInstruction is read only");
/*     */     }
/*     */     
/* 176 */     setText(data);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\dom\DOMProcessingInstruction.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */