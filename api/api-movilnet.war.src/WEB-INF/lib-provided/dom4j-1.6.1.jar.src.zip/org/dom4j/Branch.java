package org.dom4j;

import java.util.Iterator;
import java.util.List;

public interface Branch extends Node {
  Node node(int paramInt) throws IndexOutOfBoundsException;
  
  int indexOf(Node paramNode);
  
  int nodeCount();
  
  Element elementByID(String paramString);
  
  List content();
  
  Iterator nodeIterator();
  
  void setContent(List paramList);
  
  void appendContent(Branch paramBranch);
  
  void clearContent();
  
  List processingInstructions();
  
  List processingInstructions(String paramString);
  
  ProcessingInstruction processingInstruction(String paramString);
  
  void setProcessingInstructions(List paramList);
  
  Element addElement(String paramString);
  
  Element addElement(QName paramQName);
  
  Element addElement(String paramString1, String paramString2);
  
  boolean removeProcessingInstruction(String paramString);
  
  void add(Node paramNode);
  
  void add(Comment paramComment);
  
  void add(Element paramElement);
  
  void add(ProcessingInstruction paramProcessingInstruction);
  
  boolean remove(Node paramNode);
  
  boolean remove(Comment paramComment);
  
  boolean remove(Element paramElement);
  
  boolean remove(ProcessingInstruction paramProcessingInstruction);
  
  void normalize();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\Branch.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */