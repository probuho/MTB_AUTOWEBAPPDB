package org.dom4j;

public interface ElementPath {
  int size();
  
  Element getElement(int paramInt);
  
  String getPath();
  
  Element getCurrent();
  
  void addHandler(String paramString, ElementHandler paramElementHandler);
  
  void removeHandler(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\ElementPath.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */