/*    */ package org.dom4j;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidXPathException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   private static final long serialVersionUID = 3257009869058881592L;
/*    */   
/*    */   public InvalidXPathException(String xpath) {
/* 23 */     super("Invalid XPath expression: " + xpath);
/*    */   }
/*    */   
/*    */   public InvalidXPathException(String xpath, String reason) {
/* 27 */     super("Invalid XPath expression: " + xpath + " " + reason);
/*    */   }
/*    */   
/*    */   public InvalidXPathException(String xpath, Throwable t) {
/* 31 */     super("Invalid XPath expression: '" + xpath + "'. Caused by: " + t.getMessage());
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\InvalidXPathException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */