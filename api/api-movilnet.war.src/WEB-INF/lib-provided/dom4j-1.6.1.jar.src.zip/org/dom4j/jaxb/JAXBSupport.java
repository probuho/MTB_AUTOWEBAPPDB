/*     */ package org.dom4j.jaxb;
/*     */ 
/*     */ import java.io.StringReader;
/*     */ import javax.xml.bind.Element;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.dom.DOMDocument;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class JAXBSupport
/*     */ {
/*     */   private String contextPath;
/*     */   private ClassLoader classloader;
/*     */   private JAXBContext jaxbContext;
/*     */   private Marshaller marshaller;
/*     */   private Unmarshaller unmarshaller;
/*     */   
/*     */   public JAXBSupport(String contextPath) {
/*  38 */     this.contextPath = contextPath;
/*     */   }
/*     */   
/*     */   public JAXBSupport(String contextPath, ClassLoader classloader) {
/*  42 */     this.contextPath = contextPath;
/*  43 */     this.classloader = classloader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Element marshal(Element element) throws JAXBException {
/*  60 */     DOMDocument doc = new DOMDocument();
/*  61 */     getMarshaller().marshal(element, (Node)doc);
/*     */     
/*  63 */     return doc.getRootElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Element unmarshal(Element element) throws JAXBException {
/*  80 */     Source source = new StreamSource(new StringReader(element.asXML()));
/*     */     
/*  82 */     return (Element)getUnmarshaller().unmarshal(source);
/*     */   }
/*     */   
/*     */   private Marshaller getMarshaller() throws JAXBException {
/*  86 */     if (this.marshaller == null) {
/*  87 */       this.marshaller = getContext().createMarshaller();
/*     */     }
/*     */     
/*  90 */     return this.marshaller;
/*     */   }
/*     */   
/*     */   private Unmarshaller getUnmarshaller() throws JAXBException {
/*  94 */     if (this.unmarshaller == null) {
/*  95 */       this.unmarshaller = getContext().createUnmarshaller();
/*     */     }
/*     */     
/*  98 */     return this.unmarshaller;
/*     */   }
/*     */   
/*     */   private JAXBContext getContext() throws JAXBException {
/* 102 */     if (this.jaxbContext == null) {
/* 103 */       if (this.classloader == null) {
/* 104 */         this.jaxbContext = JAXBContext.newInstance(this.contextPath);
/*     */       } else {
/* 106 */         this.jaxbContext = JAXBContext.newInstance(this.contextPath, this.classloader);
/*     */       } 
/*     */     }
/*     */     
/* 110 */     return this.jaxbContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\jaxb\JAXBSupport.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */