package org.dom4j.jaxb;

import javax.xml.bind.Element;

public interface JAXBObjectModifier {
  Element modifyObject(Element paramElement) throws Exception;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\jaxb\JAXBObjectModifier.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */