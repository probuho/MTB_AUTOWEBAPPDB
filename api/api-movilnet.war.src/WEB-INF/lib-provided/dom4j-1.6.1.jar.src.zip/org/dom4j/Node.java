package org.dom4j;

import java.io.IOException;
import java.io.Writer;
import java.util.List;

public interface Node extends Cloneable {
  public static final short ANY_NODE = 0;
  
  public static final short ELEMENT_NODE = 1;
  
  public static final short ATTRIBUTE_NODE = 2;
  
  public static final short TEXT_NODE = 3;
  
  public static final short CDATA_SECTION_NODE = 4;
  
  public static final short ENTITY_REFERENCE_NODE = 5;
  
  public static final short PROCESSING_INSTRUCTION_NODE = 7;
  
  public static final short COMMENT_NODE = 8;
  
  public static final short DOCUMENT_NODE = 9;
  
  public static final short DOCUMENT_TYPE_NODE = 10;
  
  public static final short NAMESPACE_NODE = 13;
  
  public static final short UNKNOWN_NODE = 14;
  
  public static final short MAX_NODE_TYPE = 14;
  
  boolean supportsParent();
  
  Element getParent();
  
  void setParent(Element paramElement);
  
  Document getDocument();
  
  void setDocument(Document paramDocument);
  
  boolean isReadOnly();
  
  boolean hasContent();
  
  String getName();
  
  void setName(String paramString);
  
  String getText();
  
  void setText(String paramString);
  
  String getStringValue();
  
  String getPath();
  
  String getPath(Element paramElement);
  
  String getUniquePath();
  
  String getUniquePath(Element paramElement);
  
  String asXML();
  
  void write(Writer paramWriter) throws IOException;
  
  short getNodeType();
  
  String getNodeTypeName();
  
  Node detach();
  
  List selectNodes(String paramString);
  
  Object selectObject(String paramString);
  
  List selectNodes(String paramString1, String paramString2);
  
  List selectNodes(String paramString1, String paramString2, boolean paramBoolean);
  
  Node selectSingleNode(String paramString);
  
  String valueOf(String paramString);
  
  Number numberValueOf(String paramString);
  
  boolean matches(String paramString);
  
  XPath createXPath(String paramString) throws InvalidXPathException;
  
  Node asXPathResult(Element paramElement);
  
  void accept(Visitor paramVisitor);
  
  Object clone();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\Node.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */