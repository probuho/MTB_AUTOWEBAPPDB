/*    */ package org.dom4j.swing;
/*    */ 
/*    */ import javax.swing.tree.DefaultTreeModel;
/*    */ import org.dom4j.Branch;
/*    */ import org.dom4j.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentTreeModel
/*    */   extends DefaultTreeModel
/*    */ {
/*    */   protected Document document;
/*    */   
/*    */   public DocumentTreeModel(Document document) {
/* 29 */     super(new BranchTreeNode((Branch)document));
/* 30 */     this.document = document;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Document getDocument() {
/* 43 */     return this.document;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDocument(Document document) {
/* 54 */     this.document = document;
/* 55 */     setRoot(new BranchTreeNode((Branch)document));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\swing\DocumentTreeModel.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */