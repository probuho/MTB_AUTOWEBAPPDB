/*     */ package org.dom4j;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.dom4j.rule.Pattern;
/*     */ import org.dom4j.tree.AbstractDocument;
/*     */ import org.dom4j.tree.DefaultAttribute;
/*     */ import org.dom4j.tree.DefaultCDATA;
/*     */ import org.dom4j.tree.DefaultComment;
/*     */ import org.dom4j.tree.DefaultDocument;
/*     */ import org.dom4j.tree.DefaultDocumentType;
/*     */ import org.dom4j.tree.DefaultElement;
/*     */ import org.dom4j.tree.DefaultEntity;
/*     */ import org.dom4j.tree.DefaultProcessingInstruction;
/*     */ import org.dom4j.tree.DefaultText;
/*     */ import org.dom4j.tree.QNameCache;
/*     */ import org.dom4j.util.SimpleSingleton;
/*     */ import org.dom4j.util.SingletonStrategy;
/*     */ import org.dom4j.xpath.DefaultXPath;
/*     */ import org.dom4j.xpath.XPathPattern;
/*     */ import org.jaxen.VariableContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentFactory
/*     */   implements Serializable
/*     */ {
/*  48 */   private static SingletonStrategy singleton = null;
/*     */   
/*     */   protected transient QNameCache cache;
/*     */   private Map xpathNamespaceURIs;
/*     */   
/*     */   private static SingletonStrategy createSingleton() {
/*     */     SimpleSingleton simpleSingleton;
/*     */     String documentFactoryClassName;
/*  56 */     SingletonStrategy result = null;
/*     */ 
/*     */     
/*     */     try {
/*  60 */       documentFactoryClassName = System.getProperty("org.dom4j.factory", "org.dom4j.DocumentFactory");
/*     */     }
/*  62 */     catch (Exception e) {
/*  63 */       documentFactoryClassName = "org.dom4j.DocumentFactory";
/*     */     } 
/*     */     
/*     */     try {
/*  67 */       String singletonClass = System.getProperty("org.dom4j.DocumentFactory.singleton.strategy", "org.dom4j.util.SimpleSingleton");
/*     */ 
/*     */       
/*  70 */       Class clazz = Class.forName(singletonClass);
/*  71 */       result = (SingletonStrategy)clazz.newInstance();
/*  72 */     } catch (Exception e) {
/*  73 */       simpleSingleton = new SimpleSingleton();
/*     */     } 
/*     */     
/*  76 */     simpleSingleton.setSingletonClassName(documentFactoryClassName);
/*     */     
/*  78 */     return (SingletonStrategy)simpleSingleton;
/*     */   }
/*     */   
/*     */   public DocumentFactory() {
/*  82 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized DocumentFactory getInstance() {
/*  94 */     if (singleton == null) {
/*  95 */       singleton = createSingleton();
/*     */     }
/*  97 */     return (DocumentFactory)singleton.instance();
/*     */   }
/*     */ 
/*     */   
/*     */   public Document createDocument() {
/* 102 */     DefaultDocument answer = new DefaultDocument();
/* 103 */     answer.setDocumentFactory(this);
/*     */     
/* 105 */     return (Document)answer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document createDocument(String encoding) {
/* 122 */     Document answer = createDocument();
/*     */     
/* 124 */     if (answer instanceof AbstractDocument) {
/* 125 */       ((AbstractDocument)answer).setXMLEncoding(encoding);
/*     */     }
/*     */     
/* 128 */     return answer;
/*     */   }
/*     */   
/*     */   public Document createDocument(Element rootElement) {
/* 132 */     Document answer = createDocument();
/* 133 */     answer.setRootElement(rootElement);
/*     */     
/* 135 */     return answer;
/*     */   }
/*     */ 
/*     */   
/*     */   public DocumentType createDocType(String name, String publicId, String systemId) {
/* 140 */     return (DocumentType)new DefaultDocumentType(name, publicId, systemId);
/*     */   }
/*     */   
/*     */   public Element createElement(QName qname) {
/* 144 */     return (Element)new DefaultElement(qname);
/*     */   }
/*     */   
/*     */   public Element createElement(String name) {
/* 148 */     return createElement(createQName(name));
/*     */   }
/*     */   
/*     */   public Element createElement(String qualifiedName, String namespaceURI) {
/* 152 */     return createElement(createQName(qualifiedName, namespaceURI));
/*     */   }
/*     */   
/*     */   public Attribute createAttribute(Element owner, QName qname, String value) {
/* 156 */     return (Attribute)new DefaultAttribute(qname, value);
/*     */   }
/*     */   
/*     */   public Attribute createAttribute(Element owner, String name, String value) {
/* 160 */     return createAttribute(owner, createQName(name), value);
/*     */   }
/*     */   
/*     */   public CDATA createCDATA(String text) {
/* 164 */     return (CDATA)new DefaultCDATA(text);
/*     */   }
/*     */   
/*     */   public Comment createComment(String text) {
/* 168 */     return (Comment)new DefaultComment(text);
/*     */   }
/*     */   
/*     */   public Text createText(String text) {
/* 172 */     if (text == null) {
/* 173 */       String msg = "Adding text to an XML document must not be null";
/* 174 */       throw new IllegalArgumentException(msg);
/*     */     } 
/*     */     
/* 177 */     return (Text)new DefaultText(text);
/*     */   }
/*     */   
/*     */   public Entity createEntity(String name, String text) {
/* 181 */     return (Entity)new DefaultEntity(name, text);
/*     */   }
/*     */   
/*     */   public Namespace createNamespace(String prefix, String uri) {
/* 185 */     return Namespace.get(prefix, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProcessingInstruction createProcessingInstruction(String target, String data) {
/* 190 */     return (ProcessingInstruction)new DefaultProcessingInstruction(target, data);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProcessingInstruction createProcessingInstruction(String target, Map data) {
/* 195 */     return (ProcessingInstruction)new DefaultProcessingInstruction(target, data);
/*     */   }
/*     */   
/*     */   public QName createQName(String localName, Namespace namespace) {
/* 199 */     return this.cache.get(localName, namespace);
/*     */   }
/*     */   
/*     */   public QName createQName(String localName) {
/* 203 */     return this.cache.get(localName);
/*     */   }
/*     */   
/*     */   public QName createQName(String name, String prefix, String uri) {
/* 207 */     return this.cache.get(name, Namespace.get(prefix, uri));
/*     */   }
/*     */   
/*     */   public QName createQName(String qualifiedName, String uri) {
/* 211 */     return this.cache.get(qualifiedName, uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XPath createXPath(String xpathExpression) throws InvalidXPathException {
/* 230 */     DefaultXPath xpath = new DefaultXPath(xpathExpression);
/*     */     
/* 232 */     if (this.xpathNamespaceURIs != null) {
/* 233 */       xpath.setNamespaceURIs(this.xpathNamespaceURIs);
/*     */     }
/*     */     
/* 236 */     return (XPath)xpath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XPath createXPath(String xpathExpression, VariableContext variableContext) {
/* 254 */     XPath xpath = createXPath(xpathExpression);
/* 255 */     xpath.setVariableContext(variableContext);
/*     */     
/* 257 */     return xpath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeFilter createXPathFilter(String xpathFilterExpression, VariableContext variableContext) {
/* 276 */     XPath answer = createXPath(xpathFilterExpression);
/*     */ 
/*     */     
/* 279 */     answer.setVariableContext(variableContext);
/*     */     
/* 281 */     return answer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeFilter createXPathFilter(String xpathFilterExpression) {
/* 297 */     return createXPath(xpathFilterExpression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pattern createPattern(String xpathPattern) {
/* 315 */     return (Pattern)new XPathPattern(xpathPattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getQNames() {
/* 328 */     return this.cache.getQNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getXPathNamespaceURIs() {
/* 341 */     return this.xpathNamespaceURIs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXPathNamespaceURIs(Map namespaceURIs) {
/* 353 */     this.xpathNamespaceURIs = namespaceURIs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static DocumentFactory createSingleton(String className) {
/*     */     try {
/* 375 */       Class theClass = Class.forName(className, true, DocumentFactory.class.getClassLoader());
/*     */ 
/*     */       
/* 378 */       return (DocumentFactory)theClass.newInstance();
/* 379 */     } catch (Throwable e) {
/* 380 */       System.out.println("WARNING: Cannot load DocumentFactory: " + className);
/*     */ 
/*     */       
/* 383 */       return new DocumentFactory();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected QName intern(QName qname) {
/* 397 */     return this.cache.intern(qname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected QNameCache createQNameCache() {
/* 407 */     return new QNameCache(this);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 412 */     in.defaultReadObject();
/* 413 */     init();
/*     */   }
/*     */   
/*     */   protected void init() {
/* 417 */     this.cache = createQNameCache();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\DocumentFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */