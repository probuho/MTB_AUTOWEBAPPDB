/*    */ package org.dom4j.tree;
/*    */ 
/*    */ import org.dom4j.CDATA;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlyweightCDATA
/*    */   extends AbstractCDATA
/*    */   implements CDATA
/*    */ {
/*    */   protected String text;
/*    */   
/*    */   public FlyweightCDATA(String text) {
/* 39 */     this.text = text;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 43 */     return this.text;
/*    */   }
/*    */   
/*    */   protected Node createXPathResult(Element parent) {
/* 47 */     return new DefaultCDATA(parent, getText());
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\tree\FlyweightCDATA.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */