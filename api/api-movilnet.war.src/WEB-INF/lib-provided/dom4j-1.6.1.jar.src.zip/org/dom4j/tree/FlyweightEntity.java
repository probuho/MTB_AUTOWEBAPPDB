/*     */ package org.dom4j.tree;
/*     */ 
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlyweightEntity
/*     */   extends AbstractEntity
/*     */ {
/*     */   protected String name;
/*     */   protected String text;
/*     */   
/*     */   protected FlyweightEntity() {}
/*     */   
/*     */   public FlyweightEntity(String name) {
/*  53 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlyweightEntity(String name, String text) {
/*  65 */     this.name = name;
/*  66 */     this.text = text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  75 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/*  84 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/*  99 */     if (this.text != null) {
/* 100 */       this.text = text;
/*     */     } else {
/* 102 */       throw new UnsupportedOperationException("This Entity is read-only. It cannot be modified");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Node createXPathResult(Element parent) {
/* 108 */     return new DefaultEntity(parent, getName(), getText());
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\tree\FlyweightEntity.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */