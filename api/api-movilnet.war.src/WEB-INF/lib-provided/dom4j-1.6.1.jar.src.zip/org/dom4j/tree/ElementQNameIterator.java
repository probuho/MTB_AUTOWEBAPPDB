/*    */ package org.dom4j.tree;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementQNameIterator
/*    */   extends FilterIterator
/*    */ {
/*    */   private QName qName;
/*    */   
/*    */   public ElementQNameIterator(Iterator proxy, QName qName) {
/* 31 */     super(proxy);
/* 32 */     this.qName = qName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean matches(Object object) {
/* 45 */     if (object instanceof Element) {
/* 46 */       Element element = (Element)object;
/*    */       
/* 48 */       return this.qName.equals(element.getQName());
/*    */     } 
/*    */     
/* 51 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\tree\ElementQNameIterator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */