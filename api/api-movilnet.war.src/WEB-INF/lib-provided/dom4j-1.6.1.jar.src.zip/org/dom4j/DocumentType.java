package org.dom4j;

import java.util.List;

public interface DocumentType extends Node {
  String getElementName();
  
  void setElementName(String paramString);
  
  String getPublicID();
  
  void setPublicID(String paramString);
  
  String getSystemID();
  
  void setSystemID(String paramString);
  
  List getInternalDeclarations();
  
  void setInternalDeclarations(List paramList);
  
  List getExternalDeclarations();
  
  void setExternalDeclarations(List paramList);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\DocumentType.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */