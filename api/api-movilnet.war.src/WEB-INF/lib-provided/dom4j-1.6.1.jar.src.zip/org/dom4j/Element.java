package org.dom4j;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public interface Element extends Branch {
  QName getQName();
  
  void setQName(QName paramQName);
  
  Namespace getNamespace();
  
  QName getQName(String paramString);
  
  Namespace getNamespaceForPrefix(String paramString);
  
  Namespace getNamespaceForURI(String paramString);
  
  List getNamespacesForURI(String paramString);
  
  String getNamespacePrefix();
  
  String getNamespaceURI();
  
  String getQualifiedName();
  
  List additionalNamespaces();
  
  List declaredNamespaces();
  
  Element addAttribute(String paramString1, String paramString2);
  
  Element addAttribute(QName paramQName, String paramString);
  
  Element addComment(String paramString);
  
  Element addCDATA(String paramString);
  
  Element addEntity(String paramString1, String paramString2);
  
  Element addNamespace(String paramString1, String paramString2);
  
  Element addProcessingInstruction(String paramString1, String paramString2);
  
  Element addProcessingInstruction(String paramString, Map paramMap);
  
  Element addText(String paramString);
  
  void add(Attribute paramAttribute);
  
  void add(CDATA paramCDATA);
  
  void add(Entity paramEntity);
  
  void add(Text paramText);
  
  void add(Namespace paramNamespace);
  
  boolean remove(Attribute paramAttribute);
  
  boolean remove(CDATA paramCDATA);
  
  boolean remove(Entity paramEntity);
  
  boolean remove(Namespace paramNamespace);
  
  boolean remove(Text paramText);
  
  String getText();
  
  String getTextTrim();
  
  String getStringValue();
  
  Object getData();
  
  void setData(Object paramObject);
  
  List attributes();
  
  void setAttributes(List paramList);
  
  int attributeCount();
  
  Iterator attributeIterator();
  
  Attribute attribute(int paramInt);
  
  Attribute attribute(String paramString);
  
  Attribute attribute(QName paramQName);
  
  String attributeValue(String paramString);
  
  String attributeValue(String paramString1, String paramString2);
  
  String attributeValue(QName paramQName);
  
  String attributeValue(QName paramQName, String paramString);
  
  void setAttributeValue(String paramString1, String paramString2);
  
  void setAttributeValue(QName paramQName, String paramString);
  
  Element element(String paramString);
  
  Element element(QName paramQName);
  
  List elements();
  
  List elements(String paramString);
  
  List elements(QName paramQName);
  
  Iterator elementIterator();
  
  Iterator elementIterator(String paramString);
  
  Iterator elementIterator(QName paramQName);
  
  boolean isRootElement();
  
  boolean hasMixedContent();
  
  boolean isTextOnly();
  
  void appendAttributes(Element paramElement);
  
  Element createCopy();
  
  Element createCopy(String paramString);
  
  Element createCopy(QName paramQName);
  
  String elementText(String paramString);
  
  String elementText(QName paramQName);
  
  String elementTextTrim(String paramString);
  
  String elementTextTrim(QName paramQName);
  
  Node getXPathResult(int paramInt);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\Element.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */