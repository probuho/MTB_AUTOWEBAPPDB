package org.dom4j;

public interface Visitor {
  void visit(Document paramDocument);
  
  void visit(DocumentType paramDocumentType);
  
  void visit(Element paramElement);
  
  void visit(Attribute paramAttribute);
  
  void visit(CDATA paramCDATA);
  
  void visit(Comment paramComment);
  
  void visit(Entity paramEntity);
  
  void visit(Namespace paramNamespace);
  
  void visit(ProcessingInstruction paramProcessingInstruction);
  
  void visit(Text paramText);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\Visitor.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */