/*     */ package org.dom4j.io;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentException;
/*     */ import org.dom4j.DocumentFactory;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.ElementHandler;
/*     */ import org.dom4j.QName;
/*     */ import org.xmlpull.v1.XmlPullParser;
/*     */ import org.xmlpull.v1.XmlPullParserException;
/*     */ import org.xmlpull.v1.XmlPullParserFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPP3Reader
/*     */ {
/*     */   private DocumentFactory factory;
/*     */   private XmlPullParser xppParser;
/*     */   private XmlPullParserFactory xppFactory;
/*     */   private DispatchHandler dispatchHandler;
/*     */   
/*     */   public XPP3Reader() {}
/*     */   
/*     */   public XPP3Reader(DocumentFactory factory) {
/*  59 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(File file) throws DocumentException, IOException, XmlPullParserException {
/*  81 */     String systemID = file.getAbsolutePath();
/*     */     
/*  83 */     return read(new BufferedReader(new FileReader(file)), systemID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(URL url) throws DocumentException, IOException, XmlPullParserException {
/* 105 */     String systemID = url.toExternalForm();
/*     */     
/* 107 */     return read(createReader(url.openStream()), systemID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(String systemID) throws DocumentException, IOException, XmlPullParserException {
/* 137 */     if (systemID.indexOf(':') >= 0)
/*     */     {
/* 139 */       return read(new URL(systemID));
/*     */     }
/*     */     
/* 142 */     return read(new File(systemID));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(InputStream in) throws DocumentException, IOException, XmlPullParserException {
/* 165 */     return read(createReader(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(Reader reader) throws DocumentException, IOException, XmlPullParserException {
/* 187 */     getXPPParser().setInput(reader);
/*     */     
/* 189 */     return parseDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(char[] text) throws DocumentException, IOException, XmlPullParserException {
/* 211 */     getXPPParser().setInput(new CharArrayReader(text));
/*     */     
/* 213 */     return parseDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(InputStream in, String systemID) throws DocumentException, IOException, XmlPullParserException {
/* 237 */     return read(createReader(in), systemID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document read(Reader reader, String systemID) throws DocumentException, IOException, XmlPullParserException {
/* 261 */     Document document = read(reader);
/* 262 */     document.setName(systemID);
/*     */     
/* 264 */     return document;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlPullParser getXPPParser() throws XmlPullParserException {
/* 270 */     if (this.xppParser == null) {
/* 271 */       this.xppParser = getXPPFactory().newPullParser();
/*     */     }
/*     */     
/* 274 */     return this.xppParser;
/*     */   }
/*     */   
/*     */   public XmlPullParserFactory getXPPFactory() throws XmlPullParserException {
/* 278 */     if (this.xppFactory == null) {
/* 279 */       this.xppFactory = XmlPullParserFactory.newInstance();
/*     */     }
/*     */     
/* 282 */     this.xppFactory.setNamespaceAware(true);
/*     */     
/* 284 */     return this.xppFactory;
/*     */   }
/*     */   
/*     */   public void setXPPFactory(XmlPullParserFactory xPPfactory) {
/* 288 */     this.xppFactory = xPPfactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentFactory getDocumentFactory() {
/* 298 */     if (this.factory == null) {
/* 299 */       this.factory = DocumentFactory.getInstance();
/*     */     }
/*     */     
/* 302 */     return this.factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentFactory(DocumentFactory documentFactory) {
/* 317 */     this.factory = documentFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHandler(String path, ElementHandler handler) {
/* 331 */     getDispatchHandler().addHandler(path, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHandler(String path) {
/* 342 */     getDispatchHandler().removeHandler(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultHandler(ElementHandler handler) {
/* 355 */     getDispatchHandler().setDefaultHandler(handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Document parseDocument() throws DocumentException, IOException, XmlPullParserException {
/* 362 */     DocumentFactory df = getDocumentFactory();
/* 363 */     Document document = df.createDocument();
/* 364 */     Element parent = null;
/* 365 */     XmlPullParser pp = getXPPParser();
/* 366 */     pp.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", true); while (true) {
/*     */       String str2, str1; QName qname; String text; int loc;
/*     */       Element newElement;
/* 369 */       int nsStart, nsEnd, i, type = pp.nextToken();
/*     */       
/* 371 */       switch (type) {
/*     */         case 8:
/* 373 */           str2 = pp.getText();
/* 374 */           loc = str2.indexOf(" ");
/*     */           
/* 376 */           if (loc >= 0) {
/* 377 */             String target = str2.substring(0, loc);
/* 378 */             String txt = str2.substring(loc + 1);
/* 379 */             document.addProcessingInstruction(target, txt); continue;
/*     */           } 
/* 381 */           document.addProcessingInstruction(str2, "");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 9:
/* 388 */           if (parent != null) {
/* 389 */             parent.addComment(pp.getText()); continue;
/*     */           } 
/* 391 */           document.addComment(pp.getText());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 5:
/* 398 */           if (parent != null) {
/* 399 */             parent.addCDATA(pp.getText()); continue;
/*     */           } 
/* 401 */           str1 = "Cannot have text content outside of the root document";
/*     */           
/* 403 */           throw new DocumentException(str1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 413 */           return document;
/*     */         
/*     */         case 2:
/* 416 */           qname = (pp.getPrefix() == null) ? df.createQName(pp.getName(), pp.getNamespace()) : df.createQName(pp.getName(), pp.getPrefix(), pp.getNamespace());
/*     */ 
/*     */           
/* 419 */           newElement = df.createElement(qname);
/* 420 */           nsStart = pp.getNamespaceCount(pp.getDepth() - 1);
/* 421 */           nsEnd = pp.getNamespaceCount(pp.getDepth());
/*     */           
/* 423 */           for (i = nsStart; i < nsEnd; i++) {
/* 424 */             if (pp.getNamespacePrefix(i) != null) {
/* 425 */               newElement.addNamespace(pp.getNamespacePrefix(i), pp.getNamespaceUri(i));
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 430 */           for (i = 0; i < pp.getAttributeCount(); i++) {
/* 431 */             QName qa = (pp.getAttributePrefix(i) == null) ? df.createQName(pp.getAttributeName(i)) : df.createQName(pp.getAttributeName(i), pp.getAttributePrefix(i), pp.getAttributeNamespace(i));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 436 */             newElement.addAttribute(qa, pp.getAttributeValue(i));
/*     */           } 
/*     */           
/* 439 */           if (parent != null) {
/* 440 */             parent.add(newElement);
/*     */           } else {
/* 442 */             document.add(newElement);
/*     */           } 
/*     */           
/* 445 */           parent = newElement;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/* 451 */           if (parent != null) {
/* 452 */             parent = parent.getParent();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/* 459 */           text = pp.getText();
/*     */           
/* 461 */           if (parent != null)
/* 462 */           { parent.addText(text); continue; }  break;
/*     */       } 
/* 464 */     }  String msg = "Cannot have text content outside of the root document";
/*     */     
/* 466 */     throw new DocumentException(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DispatchHandler getDispatchHandler() {
/* 479 */     if (this.dispatchHandler == null) {
/* 480 */       this.dispatchHandler = new DispatchHandler();
/*     */     }
/*     */     
/* 483 */     return this.dispatchHandler;
/*     */   }
/*     */   
/*     */   protected void setDispatchHandler(DispatchHandler dispatchHandler) {
/* 487 */     this.dispatchHandler = dispatchHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Reader createReader(InputStream in) throws IOException {
/* 502 */     return new BufferedReader(new InputStreamReader(in));
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\io\XPP3Reader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */