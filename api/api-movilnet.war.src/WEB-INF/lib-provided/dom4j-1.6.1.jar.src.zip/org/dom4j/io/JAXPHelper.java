/*    */ package org.dom4j.io;
/*    */ 
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import javax.xml.parsers.SAXParser;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ import org.w3c.dom.Document;
/*    */ import org.xml.sax.XMLReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JAXPHelper
/*    */ {
/*    */   public static XMLReader createXMLReader(boolean validating, boolean namespaceAware) throws Exception {
/* 46 */     SAXParserFactory factory = SAXParserFactory.newInstance();
/* 47 */     factory.setValidating(validating);
/* 48 */     factory.setNamespaceAware(namespaceAware);
/*    */     
/* 50 */     SAXParser parser = factory.newSAXParser();
/*    */     
/* 52 */     return parser.getXMLReader();
/*    */   }
/*    */ 
/*    */   
/*    */   public static Document createDocument(boolean validating, boolean namespaceAware) throws Exception {
/* 57 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 58 */     factory.setValidating(validating);
/* 59 */     factory.setNamespaceAware(namespaceAware);
/*    */     
/* 61 */     DocumentBuilder builder = factory.newDocumentBuilder();
/*    */     
/* 63 */     return builder.newDocument();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\io\JAXPHelper.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */