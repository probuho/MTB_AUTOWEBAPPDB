/*     */ package org.dom4j.io;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.ElementHandler;
/*     */ import org.dom4j.ElementPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DispatchHandler
/*     */   implements ElementHandler
/*     */ {
/*     */   private boolean atRoot = true;
/*  59 */   private String path = "/";
/*  60 */   private ArrayList pathStack = new ArrayList();
/*  61 */   private ArrayList handlerStack = new ArrayList();
/*  62 */   private HashMap handlers = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ElementHandler defaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHandler(String handlerPath, ElementHandler handler) {
/*  76 */     this.handlers.put(handlerPath, handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementHandler removeHandler(String handlerPath) {
/*  89 */     return (ElementHandler)this.handlers.remove(handlerPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsHandler(String handlerPath) {
/* 102 */     return this.handlers.containsKey(handlerPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementHandler getHandler(String handlerPath) {
/* 114 */     return (ElementHandler)this.handlers.get(handlerPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActiveHandlerCount() {
/* 124 */     return this.handlerStack.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultHandler(ElementHandler handler) {
/* 137 */     this.defaultHandler = handler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetHandlers() {
/* 145 */     this.atRoot = true;
/* 146 */     this.path = "/";
/* 147 */     this.pathStack.clear();
/* 148 */     this.handlerStack.clear();
/* 149 */     this.handlers.clear();
/* 150 */     this.defaultHandler = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 159 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStart(ElementPath elementPath) {
/* 164 */     Element element = elementPath.getCurrent();
/*     */ 
/*     */     
/* 167 */     this.pathStack.add(this.path);
/*     */ 
/*     */     
/* 170 */     if (this.atRoot) {
/* 171 */       this.path += element.getName();
/* 172 */       this.atRoot = false;
/*     */     } else {
/* 174 */       this.path += "/" + element.getName();
/*     */     } 
/*     */     
/* 177 */     if (this.handlers != null && this.handlers.containsKey(this.path)) {
/*     */ 
/*     */       
/* 180 */       ElementHandler handler = (ElementHandler)this.handlers.get(this.path);
/* 181 */       this.handlerStack.add(handler);
/*     */ 
/*     */       
/* 184 */       handler.onStart(elementPath);
/*     */ 
/*     */     
/*     */     }
/* 188 */     else if (this.handlerStack.isEmpty() && this.defaultHandler != null) {
/* 189 */       this.defaultHandler.onStart(elementPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnd(ElementPath elementPath) {
/* 195 */     if (this.handlers != null && this.handlers.containsKey(this.path)) {
/*     */ 
/*     */       
/* 198 */       ElementHandler handler = (ElementHandler)this.handlers.get(this.path);
/* 199 */       this.handlerStack.remove(this.handlerStack.size() - 1);
/*     */ 
/*     */       
/* 202 */       handler.onEnd(elementPath);
/*     */ 
/*     */     
/*     */     }
/* 206 */     else if (this.handlerStack.isEmpty() && this.defaultHandler != null) {
/* 207 */       this.defaultHandler.onEnd(elementPath);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 212 */     this.path = this.pathStack.remove(this.pathStack.size() - 1);
/*     */     
/* 214 */     if (this.pathStack.size() == 0)
/* 215 */       this.atRoot = true; 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\io\DispatchHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */