/*     */ package org.dom4j.io;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.dom4j.Branch;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentFactory;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Namespace;
/*     */ import org.dom4j.QName;
/*     */ import org.dom4j.tree.NamespaceStack;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMReader
/*     */ {
/*     */   private DocumentFactory factory;
/*     */   private NamespaceStack namespaceStack;
/*     */   
/*     */   public DOMReader() {
/*  38 */     this.factory = DocumentFactory.getInstance();
/*  39 */     this.namespaceStack = new NamespaceStack(this.factory);
/*     */   }
/*     */   
/*     */   public DOMReader(DocumentFactory factory) {
/*  43 */     this.factory = factory;
/*  44 */     this.namespaceStack = new NamespaceStack(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentFactory getDocumentFactory() {
/*  54 */     return this.factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentFactory(DocumentFactory docFactory) {
/*  69 */     this.factory = docFactory;
/*  70 */     this.namespaceStack.setDocumentFactory(this.factory);
/*     */   }
/*     */   
/*     */   public Document read(Document domDocument) {
/*  74 */     if (domDocument instanceof Document) {
/*  75 */       return (Document)domDocument;
/*     */     }
/*     */     
/*  78 */     Document document = createDocument();
/*     */     
/*  80 */     clearNamespaceStack();
/*     */     
/*  82 */     NodeList nodeList = domDocument.getChildNodes();
/*     */     
/*  84 */     for (int i = 0, size = nodeList.getLength(); i < size; i++) {
/*  85 */       readTree(nodeList.item(i), (Branch)document);
/*     */     }
/*     */     
/*  88 */     return document;
/*     */   }
/*     */   protected void readTree(Node node, Branch current) {
/*     */     DocumentType domDocType;
/*     */     Node firstChild;
/*  93 */     Element element = null;
/*  94 */     Document document = null;
/*     */     
/*  96 */     if (current instanceof Element) {
/*  97 */       element = (Element)current;
/*     */     } else {
/*  99 */       document = (Document)current;
/*     */     } 
/*     */     
/* 102 */     switch (node.getNodeType()) {
/*     */       case 1:
/* 104 */         readElement(node, current);
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 110 */         if (current instanceof Element) {
/* 111 */           Element currentEl = (Element)current;
/* 112 */           currentEl.addProcessingInstruction(node.getNodeName(), node.getNodeValue());
/*     */         } else {
/*     */           
/* 115 */           Document currentDoc = (Document)current;
/* 116 */           currentDoc.addProcessingInstruction(node.getNodeName(), node.getNodeValue());
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 124 */         if (current instanceof Element) {
/* 125 */           ((Element)current).addComment(node.getNodeValue());
/*     */         } else {
/* 127 */           ((Document)current).addComment(node.getNodeValue());
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 10:
/* 134 */         domDocType = (DocumentType)node;
/*     */         
/* 136 */         document.addDocType(domDocType.getName(), domDocType.getPublicId(), domDocType.getSystemId());
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 142 */         element.addText(node.getNodeValue());
/*     */         return;
/*     */ 
/*     */       
/*     */       case 4:
/* 147 */         element.addCDATA(node.getNodeValue());
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 154 */         firstChild = node.getFirstChild();
/*     */         
/* 156 */         if (firstChild != null) {
/* 157 */           element.addEntity(node.getNodeName(), firstChild.getNodeValue());
/*     */         } else {
/*     */           
/* 160 */           element.addEntity(node.getNodeName(), "");
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 6:
/* 166 */         element.addEntity(node.getNodeName(), node.getNodeValue());
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     System.out.println("WARNING: Unknown DOM node type: " + node.getNodeType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readElement(Node node, Branch current) {
/* 177 */     int previouslyDeclaredNamespaces = this.namespaceStack.size();
/*     */     
/* 179 */     String namespaceUri = node.getNamespaceURI();
/* 180 */     String elementPrefix = node.getPrefix();
/*     */     
/* 182 */     if (elementPrefix == null) {
/* 183 */       elementPrefix = "";
/*     */     }
/*     */     
/* 186 */     NamedNodeMap attributeList = node.getAttributes();
/*     */     
/* 188 */     if (attributeList != null && namespaceUri == null) {
/*     */       
/* 190 */       Node attribute = attributeList.getNamedItem("xmlns");
/*     */       
/* 192 */       if (attribute != null) {
/* 193 */         namespaceUri = attribute.getNodeValue();
/* 194 */         elementPrefix = "";
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     QName qName = this.namespaceStack.getQName(namespaceUri, node.getLocalName(), node.getNodeName());
/*     */     
/* 200 */     Element element = current.addElement(qName);
/*     */     
/* 202 */     if (attributeList != null) {
/* 203 */       int j = attributeList.getLength();
/* 204 */       List attributes = new ArrayList(j);
/*     */       int k;
/* 206 */       for (k = 0; k < j; k++) {
/* 207 */         Node attribute = attributeList.item(k);
/*     */ 
/*     */         
/* 210 */         String name = attribute.getNodeName();
/*     */         
/* 212 */         if (name.startsWith("xmlns")) {
/* 213 */           String prefix = getPrefix(name);
/* 214 */           String uri = attribute.getNodeValue();
/*     */           
/* 216 */           Namespace namespace = this.namespaceStack.addNamespace(prefix, uri);
/*     */           
/* 218 */           element.add(namespace);
/*     */         } else {
/* 220 */           attributes.add(attribute);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 225 */       j = attributes.size();
/*     */       
/* 227 */       for (k = 0; k < j; k++) {
/* 228 */         Node attribute = attributes.get(k);
/*     */         
/* 230 */         QName attributeQName = this.namespaceStack.getQName(attribute.getNamespaceURI(), attribute.getLocalName(), attribute.getNodeName());
/*     */ 
/*     */         
/* 233 */         element.addAttribute(attributeQName, attribute.getNodeValue());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 238 */     NodeList children = node.getChildNodes();
/*     */     
/* 240 */     for (int i = 0, size = children.getLength(); i < size; i++) {
/* 241 */       Node child = children.item(i);
/* 242 */       readTree(child, (Branch)element);
/*     */     } 
/*     */ 
/*     */     
/* 246 */     while (this.namespaceStack.size() > previouslyDeclaredNamespaces) {
/* 247 */       this.namespaceStack.pop();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Namespace getNamespace(String prefix, String uri) {
/* 252 */     return getDocumentFactory().createNamespace(prefix, uri);
/*     */   }
/*     */   
/*     */   protected Document createDocument() {
/* 256 */     return getDocumentFactory().createDocument();
/*     */   }
/*     */   
/*     */   protected void clearNamespaceStack() {
/* 260 */     this.namespaceStack.clear();
/*     */     
/* 262 */     if (!this.namespaceStack.contains(Namespace.XML_NAMESPACE)) {
/* 263 */       this.namespaceStack.push(Namespace.XML_NAMESPACE);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getPrefix(String xmlnsDecl) {
/* 268 */     int index = xmlnsDecl.indexOf(':', 5);
/*     */     
/* 270 */     if (index != -1) {
/* 271 */       return xmlnsDecl.substring(index + 1);
/*     */     }
/* 273 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\io\DOMReader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */