/*     */ package org.dom4j.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import org.dom4j.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DocumentInputSource
/*     */   extends InputSource
/*     */ {
/*     */   private Document document;
/*     */   
/*     */   public DocumentInputSource() {}
/*     */   
/*     */   public DocumentInputSource(Document document) {
/*  36 */     this.document = document;
/*  37 */     setSystemId(document.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document getDocument() {
/*  49 */     return this.document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocument(Document document) {
/*  59 */     this.document = document;
/*  60 */     setSystemId(document.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharacterStream(Reader characterStream) throws UnsupportedOperationException {
/*  78 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream() {
/*     */     try {
/*  90 */       StringWriter out = new StringWriter();
/*  91 */       XMLWriter writer = new XMLWriter(out);
/*  92 */       writer.write(this.document);
/*  93 */       writer.flush();
/*     */       
/*  95 */       return new StringReader(out.toString());
/*  96 */     } catch (IOException e) {
/*     */ 
/*     */ 
/*     */       
/* 100 */       return new Reader(this, e)
/*     */         {
/*     */           public int read(char[] ch, int offset, int length) throws IOException {
/* 103 */             throw this.val$e;
/*     */           }
/*     */           
/*     */           private final IOException val$e;
/*     */           private final DocumentInputSource this$0;
/*     */           
/*     */           public void close() throws IOException {}
/*     */         };
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\io\DocumentInputSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */