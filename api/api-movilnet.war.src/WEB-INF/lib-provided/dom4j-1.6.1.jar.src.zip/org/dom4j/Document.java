package org.dom4j;

import java.util.Map;
import org.xml.sax.EntityResolver;

public interface Document extends Branch {
  Element getRootElement();
  
  void setRootElement(Element paramElement);
  
  Document addComment(String paramString);
  
  Document addProcessingInstruction(String paramString1, String paramString2);
  
  Document addProcessingInstruction(String paramString, Map paramMap);
  
  Document addDocType(String paramString1, String paramString2, String paramString3);
  
  DocumentType getDocType();
  
  void setDocType(DocumentType paramDocumentType);
  
  EntityResolver getEntityResolver();
  
  void setEntityResolver(EntityResolver paramEntityResolver);
  
  String getXMLEncoding();
  
  void setXMLEncoding(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\dom4j-1.6.1.jar!\org\dom4j\Document.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */