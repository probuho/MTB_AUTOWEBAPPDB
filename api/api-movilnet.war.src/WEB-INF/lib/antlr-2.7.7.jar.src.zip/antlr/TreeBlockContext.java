/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TreeBlockContext
/*    */   extends BlockContext
/*    */ {
/*    */   protected boolean nextElementIsRoot = true;
/*    */   
/*    */   public void addAlternativeElement(AlternativeElement paramAlternativeElement) {
/* 26 */     TreeElement treeElement = (TreeElement)this.block;
/* 27 */     if (this.nextElementIsRoot) {
/* 28 */       treeElement.root = (GrammarAtom)paramAlternativeElement;
/* 29 */       this.nextElementIsRoot = false;
/*    */     } else {
/*    */       
/* 32 */       super.addAlternativeElement(paramAlternativeElement);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\TreeBlockContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */