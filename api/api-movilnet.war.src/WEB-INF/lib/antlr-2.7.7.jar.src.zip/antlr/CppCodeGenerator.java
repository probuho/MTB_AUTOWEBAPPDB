/*      */ package antlr;
/*      */ 
/*      */ import antlr.actions.cpp.ActionLexer;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.IOException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CppCodeGenerator
/*      */   extends CodeGenerator
/*      */ {
/*      */   boolean DEBUG_CPP_CODE_GENERATOR = false;
/*   27 */   protected int syntacticPredLevel = 0;
/*      */   
/*      */   protected boolean genAST = false;
/*      */   
/*      */   protected boolean saveText = false;
/*      */   
/*      */   protected boolean genHashLines = true;
/*      */   
/*      */   protected boolean noConstructors = false;
/*      */   
/*      */   protected int outputLine;
/*      */   
/*      */   protected String outputFile;
/*      */   
/*      */   boolean usingCustomAST = false;
/*      */   
/*      */   String labeledElementType;
/*      */   
/*      */   String labeledElementASTType;
/*      */   
/*      */   String labeledElementASTInit;
/*      */   
/*      */   String labeledElementInit;
/*      */   
/*      */   String commonExtraArgs;
/*      */   
/*      */   String commonExtraParams;
/*      */   
/*      */   String commonLocalVars;
/*      */   
/*      */   String lt1Value;
/*      */   
/*      */   String exceptionThrown;
/*      */   
/*      */   String throwNoViable;
/*      */   RuleBlock currentRule;
/*      */   String currentASTResult;
/*   64 */   Hashtable treeVariableMap = new Hashtable();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   69 */   Hashtable declaredASTVariables = new Hashtable();
/*      */ 
/*      */   
/*   72 */   int astVarNumber = 1;
/*      */   
/*   74 */   protected static final String NONUNIQUE = new String();
/*      */ 
/*      */   
/*      */   public static final int caseSizeThreshold = 127;
/*      */ 
/*      */   
/*      */   private Vector semPreds;
/*      */   
/*      */   private Vector astTypes;
/*      */   
/*   84 */   private static String namespaceStd = "ANTLR_USE_NAMESPACE(std)";
/*   85 */   private static String namespaceAntlr = "ANTLR_USE_NAMESPACE(antlr)";
/*   86 */   private static NameSpace nameSpace = null;
/*      */ 
/*      */   
/*      */   private static final String preIncludeCpp = "pre_include_cpp";
/*      */   
/*      */   private static final String preIncludeHpp = "pre_include_hpp";
/*      */   
/*      */   private static final String postIncludeCpp = "post_include_cpp";
/*      */   
/*      */   private static final String postIncludeHpp = "post_include_hpp";
/*      */ 
/*      */   
/*      */   public CppCodeGenerator() {
/*   99 */     this.charFormatter = new CppCharFormatter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int addSemPred(String paramString) {
/*  107 */     this.semPreds.appendElement(paramString);
/*  108 */     return this.semPreds.size() - 1;
/*      */   }
/*      */   
/*      */   public void exitIfError() {
/*  112 */     if (this.antlrTool.hasError())
/*      */     {
/*  114 */       this.antlrTool.fatalError("Exiting due to errors.");
/*      */     }
/*      */   }
/*      */   
/*      */   protected int countLines(String paramString) {
/*  119 */     byte b1 = 0;
/*  120 */     for (byte b2 = 0; b2 < paramString.length(); b2++) {
/*      */       
/*  122 */       if (paramString.charAt(b2) == '\n')
/*  123 */         b1++; 
/*      */     } 
/*  125 */     return b1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _print(String paramString) {
/*  133 */     if (paramString != null) {
/*      */       
/*  135 */       this.outputLine += countLines(paramString);
/*  136 */       this.currentOutput.print(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _printAction(String paramString) {
/*  146 */     if (paramString != null) {
/*      */       
/*  148 */       this.outputLine += countLines(paramString) + 1;
/*  149 */       super._printAction(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void printAction(Token paramToken) {
/*  155 */     if (paramToken != null) {
/*      */       
/*  157 */       genLineNo(paramToken.getLine());
/*  158 */       printTabs();
/*  159 */       _printAction(processActionForSpecialSymbols(paramToken.getText(), paramToken.getLine(), (RuleBlock)null, (ActionTransInfo)null));
/*      */       
/*  161 */       genLineNo2();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printHeaderAction(String paramString) {
/*  169 */     Token token = (Token)this.behavior.headerActions.get(paramString);
/*  170 */     if (token != null) {
/*      */       
/*  172 */       genLineNo(token.getLine());
/*  173 */       println(processActionForSpecialSymbols(token.getText(), token.getLine(), (RuleBlock)null, (ActionTransInfo)null));
/*      */       
/*  175 */       genLineNo2();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _println(String paramString) {
/*  183 */     if (paramString != null) {
/*  184 */       this.outputLine += countLines(paramString) + 1;
/*  185 */       this.currentOutput.println(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void println(String paramString) {
/*  193 */     if (paramString != null) {
/*  194 */       printTabs();
/*  195 */       this.outputLine += countLines(paramString) + 1;
/*  196 */       this.currentOutput.println(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void genLineNo(int paramInt) {
/*  202 */     if (paramInt == 0) {
/*  203 */       paramInt++;
/*      */     }
/*  205 */     if (this.genHashLines) {
/*  206 */       _println("#line " + paramInt + " \"" + this.antlrTool.fileMinusPath(this.antlrTool.grammarFile) + "\"");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void genLineNo(GrammarElement paramGrammarElement) {
/*  212 */     if (paramGrammarElement != null) {
/*  213 */       genLineNo(paramGrammarElement.getLine());
/*      */     }
/*      */   }
/*      */   
/*      */   public void genLineNo(Token paramToken) {
/*  218 */     if (paramToken != null) {
/*  219 */       genLineNo(paramToken.getLine());
/*      */     }
/*      */   }
/*      */   
/*      */   public void genLineNo2() {
/*  224 */     if (this.genHashLines)
/*      */     {
/*  226 */       _println("#line " + (this.outputLine + 1) + " \"" + this.outputFile + "\"");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean charIsDigit(String paramString, int paramInt) {
/*  232 */     return (paramInt < paramString.length() && Character.isDigit(paramString.charAt(paramInt)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String convertJavaToCppString(String paramString, boolean paramBoolean) {
/*  249 */     String str1 = new String();
/*  250 */     String str2 = paramString;
/*      */     
/*  252 */     byte b = 0;
/*  253 */     int i = 0;
/*      */     
/*  255 */     if (paramBoolean) {
/*      */       
/*  257 */       if (!paramString.startsWith("'") || !paramString.endsWith("'")) {
/*  258 */         this.antlrTool.error("Invalid character literal: '" + paramString + "'");
/*      */       
/*      */       }
/*      */     }
/*  262 */     else if (!paramString.startsWith("\"") || !paramString.endsWith("\"")) {
/*  263 */       this.antlrTool.error("Invalid character string: '" + paramString + "'");
/*      */     } 
/*  265 */     str2 = paramString.substring(1, paramString.length() - 1);
/*      */     
/*  267 */     String str3 = "";
/*  268 */     int j = 255;
/*  269 */     if (this.grammar instanceof LexerGrammar) {
/*      */ 
/*      */       
/*  272 */       j = ((LexerGrammar)this.grammar).charVocabulary.size() - 1;
/*  273 */       if (j > 255) {
/*  274 */         str3 = "L";
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  279 */     while (b < str2.length()) {
/*      */       
/*  281 */       if (str2.charAt(b) == '\\') {
/*      */         
/*  283 */         if (str2.length() == b + 1) {
/*  284 */           this.antlrTool.error("Invalid escape in char literal: '" + paramString + "' looking at '" + str2.substring(b) + "'");
/*      */         }
/*      */         
/*  287 */         switch (str2.charAt(b + 1)) {
/*      */           case 'a':
/*  289 */             i = 7;
/*  290 */             b += 2;
/*      */             break;
/*      */           case 'b':
/*  293 */             i = 8;
/*  294 */             b += 2;
/*      */             break;
/*      */           case 't':
/*  297 */             i = 9;
/*  298 */             b += 2;
/*      */             break;
/*      */           case 'n':
/*  301 */             i = 10;
/*  302 */             b += 2;
/*      */             break;
/*      */           case 'f':
/*  305 */             i = 12;
/*  306 */             b += 2;
/*      */             break;
/*      */           case 'r':
/*  309 */             i = 13;
/*  310 */             b += 2;
/*      */             break;
/*      */           case '"':
/*      */           case '\'':
/*      */           case '\\':
/*  315 */             i = str2.charAt(b + 1);
/*  316 */             b += 2;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 'u':
/*  321 */             if (b + 5 < str2.length()) {
/*      */               
/*  323 */               i = Character.digit(str2.charAt(b + 2), 16) * 16 * 16 * 16 + Character.digit(str2.charAt(b + 3), 16) * 16 * 16 + Character.digit(str2.charAt(b + 4), 16) * 16 + Character.digit(str2.charAt(b + 5), 16);
/*      */ 
/*      */ 
/*      */               
/*  327 */               b += 6;
/*      */               break;
/*      */             } 
/*  330 */             this.antlrTool.error("Invalid escape in char literal: '" + paramString + "' looking at '" + str2.substring(b) + "'");
/*      */             break;
/*      */           
/*      */           case '0':
/*      */           case '1':
/*      */           case '2':
/*      */           case '3':
/*  337 */             if (charIsDigit(str2, b + 2)) {
/*      */               
/*  339 */               if (charIsDigit(str2, b + 3)) {
/*      */                 
/*  341 */                 i = (str2.charAt(b + 1) - 48) * 8 * 8 + (str2.charAt(b + 2) - 48) * 8 + str2.charAt(b + 3) - 48;
/*      */                 
/*  343 */                 b += 4;
/*      */                 
/*      */                 break;
/*      */               } 
/*  347 */               i = (str2.charAt(b + 1) - 48) * 8 + str2.charAt(b + 2) - 48;
/*  348 */               b += 3;
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/*  353 */             i = str2.charAt(b + 1) - 48;
/*  354 */             b += 2;
/*      */             break;
/*      */ 
/*      */           
/*      */           case '4':
/*      */           case '5':
/*      */           case '6':
/*      */           case '7':
/*  362 */             if (charIsDigit(str2, b + 2)) {
/*      */               
/*  364 */               i = (str2.charAt(b + 1) - 48) * 8 + str2.charAt(b + 2) - 48;
/*  365 */               b += 3;
/*      */             }
/*      */             else {
/*      */               
/*  369 */               i = str2.charAt(b + 1) - 48;
/*  370 */               b += 2;
/*      */             } 
/*      */           default:
/*  373 */             this.antlrTool.error("Unhandled escape in char literal: '" + paramString + "' looking at '" + str2.substring(b) + "'");
/*  374 */             i = 0;
/*      */             break;
/*      */         } 
/*      */       } else {
/*  378 */         i = str2.charAt(b++);
/*      */       } 
/*  380 */       if (this.grammar instanceof LexerGrammar)
/*      */       {
/*  382 */         if (i > j) {
/*      */           String str;
/*      */           
/*  385 */           if (32 <= i && i < 127) {
/*  386 */             str = this.charFormatter.escapeChar(i, true);
/*      */           } else {
/*  388 */             str = "0x" + Integer.toString(i, 16);
/*      */           } 
/*  390 */           this.antlrTool.error("Character out of range in " + (paramBoolean ? "char literal" : "string constant") + ": '" + str2 + "'");
/*  391 */           this.antlrTool.error("Vocabulary size: " + j + " Character " + str);
/*      */         } 
/*      */       }
/*      */       
/*  395 */       if (paramBoolean) {
/*      */ 
/*      */         
/*  398 */         if (b != str2.length()) {
/*  399 */           this.antlrTool.error("Invalid char literal: '" + paramString + "'");
/*      */         }
/*  401 */         if (j <= 255) {
/*      */           
/*  403 */           if (i <= 255 && (i & 0x80) != 0) {
/*      */ 
/*      */ 
/*      */             
/*  407 */             str1 = "static_cast<unsigned char>('" + this.charFormatter.escapeChar(i, true) + "')"; continue;
/*      */           } 
/*  409 */           str1 = "'" + this.charFormatter.escapeChar(i, true) + "'";
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*  416 */         str1 = "L'" + this.charFormatter.escapeChar(i, true) + "'";
/*      */         
/*      */         continue;
/*      */       } 
/*  420 */       str1 = str1 + this.charFormatter.escapeChar(i, true);
/*      */     } 
/*  422 */     if (!paramBoolean)
/*  423 */       str1 = str3 + "\"" + str1 + "\""; 
/*  424 */     return str1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen() {
/*      */     try {
/*  432 */       Enumeration enumeration = this.behavior.grammars.elements();
/*  433 */       while (enumeration.hasMoreElements()) {
/*  434 */         Grammar grammar = enumeration.nextElement();
/*  435 */         if (grammar.debuggingOutput) {
/*  436 */           this.antlrTool.error(grammar.getFilename() + ": C++ mode does not support -debug");
/*      */         }
/*      */         
/*  439 */         grammar.setGrammarAnalyzer(this.analyzer);
/*  440 */         grammar.setCodeGenerator(this);
/*  441 */         this.analyzer.setGrammar(grammar);
/*      */         
/*  443 */         setupGrammarParameters(grammar);
/*  444 */         grammar.generate();
/*  445 */         exitIfError();
/*      */       } 
/*      */ 
/*      */       
/*  449 */       Enumeration enumeration1 = this.behavior.tokenManagers.elements();
/*  450 */       while (enumeration1.hasMoreElements()) {
/*  451 */         TokenManager tokenManager = enumeration1.nextElement();
/*  452 */         if (!tokenManager.isReadOnly()) {
/*      */ 
/*      */ 
/*      */           
/*  456 */           genTokenTypes(tokenManager);
/*      */           
/*  458 */           genTokenInterchange(tokenManager);
/*      */         } 
/*  460 */         exitIfError();
/*      */       }
/*      */     
/*  463 */     } catch (IOException iOException) {
/*  464 */       this.antlrTool.reportException(iOException, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ActionElement paramActionElement) {
/*  471 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genAction(" + paramActionElement + ")"); 
/*  472 */     if (paramActionElement.isSemPred) {
/*  473 */       genSemPred(paramActionElement.actionText, paramActionElement.line);
/*      */     } else {
/*      */       
/*  476 */       if (this.grammar.hasSyntacticPredicate) {
/*  477 */         println("if ( inputState->guessing==0 ) {");
/*  478 */         this.tabs++;
/*      */       } 
/*      */       
/*  481 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/*  482 */       String str = processActionForSpecialSymbols(paramActionElement.actionText, paramActionElement.getLine(), this.currentRule, actionTransInfo);
/*      */ 
/*      */ 
/*      */       
/*  486 */       if (actionTransInfo.refRuleRoot != null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  491 */         println(actionTransInfo.refRuleRoot + " = " + this.labeledElementASTType + "(currentAST.root);");
/*      */       }
/*      */ 
/*      */       
/*  495 */       genLineNo(paramActionElement);
/*  496 */       printAction(str);
/*  497 */       genLineNo2();
/*      */       
/*  499 */       if (actionTransInfo.assignToRoot) {
/*      */         
/*  501 */         println("currentAST.root = " + actionTransInfo.refRuleRoot + ";");
/*      */ 
/*      */         
/*  504 */         println("if ( " + actionTransInfo.refRuleRoot + "!=" + this.labeledElementASTInit + " &&");
/*  505 */         this.tabs++;
/*  506 */         println(actionTransInfo.refRuleRoot + "->getFirstChild() != " + this.labeledElementASTInit + " )");
/*  507 */         println("  currentAST.child = " + actionTransInfo.refRuleRoot + "->getFirstChild();");
/*  508 */         this.tabs--;
/*  509 */         println("else");
/*  510 */         this.tabs++;
/*  511 */         println("currentAST.child = " + actionTransInfo.refRuleRoot + ";");
/*  512 */         this.tabs--;
/*  513 */         println("currentAST.advanceChildToEnd();");
/*      */       } 
/*      */       
/*  516 */       if (this.grammar.hasSyntacticPredicate) {
/*  517 */         this.tabs--;
/*  518 */         println("}");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(AlternativeBlock paramAlternativeBlock) {
/*  527 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("gen(" + paramAlternativeBlock + ")"); 
/*  528 */     println("{");
/*  529 */     genBlockPreamble(paramAlternativeBlock);
/*  530 */     genBlockInitAction(paramAlternativeBlock);
/*      */ 
/*      */     
/*  533 */     String str = this.currentASTResult;
/*  534 */     if (paramAlternativeBlock.getLabel() != null) {
/*  535 */       this.currentASTResult = paramAlternativeBlock.getLabel();
/*      */     }
/*      */     
/*  538 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramAlternativeBlock);
/*      */     
/*  540 */     CppBlockFinishingInfo cppBlockFinishingInfo = genCommonBlock(paramAlternativeBlock, true);
/*  541 */     genBlockFinish(cppBlockFinishingInfo, this.throwNoViable);
/*      */     
/*  543 */     println("}");
/*      */ 
/*      */     
/*  546 */     this.currentASTResult = str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(BlockEndElement paramBlockEndElement) {
/*  554 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genRuleEnd(" + paramBlockEndElement + ")");
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(CharLiteralElement paramCharLiteralElement) {
/*  561 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) {
/*  562 */       System.out.println("genChar(" + paramCharLiteralElement + ")");
/*      */     }
/*  564 */     if (!(this.grammar instanceof LexerGrammar)) {
/*  565 */       this.antlrTool.error("cannot ref character literals in grammar: " + paramCharLiteralElement);
/*      */     }
/*  567 */     if (paramCharLiteralElement.getLabel() != null) {
/*  568 */       println(paramCharLiteralElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */     
/*  571 */     boolean bool = this.saveText;
/*  572 */     this.saveText = (this.saveText && paramCharLiteralElement.getAutoGenType() == 1);
/*      */ 
/*      */     
/*  575 */     if (!this.saveText || paramCharLiteralElement.getAutoGenType() == 3) {
/*  576 */       println("_saveIndex = text.length();");
/*      */     }
/*  578 */     print(paramCharLiteralElement.not ? "matchNot(" : "match(");
/*  579 */     _print(convertJavaToCppString(paramCharLiteralElement.atomText, true));
/*  580 */     _println(" /* charlit */ );");
/*      */     
/*  582 */     if (!this.saveText || paramCharLiteralElement.getAutoGenType() == 3) {
/*  583 */       println("text.erase(_saveIndex);");
/*      */     }
/*  585 */     this.saveText = bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(CharRangeElement paramCharRangeElement) {
/*  592 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) {
/*  593 */       System.out.println("genCharRangeElement(" + paramCharRangeElement.beginText + ".." + paramCharRangeElement.endText + ")");
/*      */     }
/*  595 */     if (!(this.grammar instanceof LexerGrammar)) {
/*  596 */       this.antlrTool.error("cannot ref character range in grammar: " + paramCharRangeElement);
/*      */     }
/*  598 */     if (paramCharRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  599 */       println(paramCharRangeElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */     
/*  602 */     boolean bool = (this.grammar instanceof LexerGrammar && (!this.saveText || paramCharRangeElement.getAutoGenType() == 3)) ? true : false;
/*      */ 
/*      */ 
/*      */     
/*  606 */     if (bool) {
/*  607 */       println("_saveIndex=text.length();");
/*      */     }
/*  609 */     println("matchRange(" + convertJavaToCppString(paramCharRangeElement.beginText, true) + "," + convertJavaToCppString(paramCharRangeElement.endText, true) + ");");
/*      */ 
/*      */     
/*  612 */     if (bool) {
/*  613 */       println("text.erase(_saveIndex);");
/*      */     }
/*      */   }
/*      */   
/*      */   public void gen(LexerGrammar paramLexerGrammar) throws IOException {
/*  618 */     if (paramLexerGrammar.debuggingOutput) {
/*  619 */       this.semPreds = new Vector();
/*      */     }
/*  621 */     if (paramLexerGrammar.charVocabulary.size() > 256) {
/*  622 */       this.antlrTool.warning(paramLexerGrammar.getFilename() + ": Vocabularies of this size still experimental in C++ mode (vocabulary size now: " + paramLexerGrammar.charVocabulary.size() + ")");
/*      */     }
/*  624 */     setGrammar(paramLexerGrammar);
/*  625 */     if (!(this.grammar instanceof LexerGrammar)) {
/*  626 */       this.antlrTool.panic("Internal error generating lexer");
/*      */     }
/*      */     
/*  629 */     genBody(paramLexerGrammar);
/*  630 */     genInclude(paramLexerGrammar);
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(OneOrMoreBlock paramOneOrMoreBlock) {
/*      */     String str1, str2;
/*  636 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("gen+(" + paramOneOrMoreBlock + ")");
/*      */ 
/*      */     
/*  639 */     println("{ // ( ... )+");
/*  640 */     genBlockPreamble(paramOneOrMoreBlock);
/*  641 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*  642 */       str2 = "_cnt_" + paramOneOrMoreBlock.getLabel();
/*      */     } else {
/*      */       
/*  645 */       str2 = "_cnt" + paramOneOrMoreBlock.ID;
/*      */     } 
/*  647 */     println("int " + str2 + "=0;");
/*  648 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*  649 */       str1 = paramOneOrMoreBlock.getLabel();
/*      */     } else {
/*      */       
/*  652 */       str1 = "_loop" + paramOneOrMoreBlock.ID;
/*      */     } 
/*      */     
/*  655 */     println("for (;;) {");
/*  656 */     this.tabs++;
/*      */ 
/*      */     
/*  659 */     genBlockInitAction(paramOneOrMoreBlock);
/*      */ 
/*      */     
/*  662 */     String str3 = this.currentASTResult;
/*  663 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*  664 */       this.currentASTResult = paramOneOrMoreBlock.getLabel();
/*      */     }
/*      */     
/*  667 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramOneOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  679 */     boolean bool1 = false;
/*  680 */     int i = this.grammar.maxk;
/*      */     
/*  682 */     if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramOneOrMoreBlock.exitCache[paramOneOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */ 
/*      */       
/*  686 */       bool1 = true;
/*  687 */       i = paramOneOrMoreBlock.exitLookaheadDepth;
/*      */     }
/*  689 */     else if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */ 
/*      */       
/*  692 */       bool1 = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  697 */     if (bool1) {
/*  698 */       if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) {
/*  699 */         System.out.println("nongreedy (...)+ loop; exit depth is " + paramOneOrMoreBlock.exitLookaheadDepth);
/*      */       }
/*      */       
/*  702 */       String str = getLookaheadTestExpression(paramOneOrMoreBlock.exitCache, i);
/*      */ 
/*      */       
/*  705 */       println("// nongreedy exit test");
/*  706 */       println("if ( " + str2 + ">=1 && " + str + ") goto " + str1 + ";");
/*      */     } 
/*      */     
/*  709 */     CppBlockFinishingInfo cppBlockFinishingInfo = genCommonBlock(paramOneOrMoreBlock, false);
/*  710 */     genBlockFinish(cppBlockFinishingInfo, "if ( " + str2 + ">=1 ) { goto " + str1 + "; } else {" + this.throwNoViable + "}");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  715 */     println(str2 + "++;");
/*  716 */     this.tabs--;
/*  717 */     println("}");
/*  718 */     println(str1 + ":;");
/*  719 */     println("}  // ( ... )+");
/*      */ 
/*      */     
/*  722 */     this.currentASTResult = str3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ParserGrammar paramParserGrammar) throws IOException {
/*  729 */     if (paramParserGrammar.debuggingOutput) {
/*  730 */       this.semPreds = new Vector();
/*      */     }
/*  732 */     setGrammar(paramParserGrammar);
/*  733 */     if (!(this.grammar instanceof ParserGrammar)) {
/*  734 */       this.antlrTool.panic("Internal error generating parser");
/*      */     }
/*      */     
/*  737 */     genBody(paramParserGrammar);
/*  738 */     genInclude(paramParserGrammar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(RuleRefElement paramRuleRefElement) {
/*  745 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genRR(" + paramRuleRefElement + ")"); 
/*  746 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/*  747 */     if (ruleSymbol == null || !ruleSymbol.isDefined()) {
/*      */ 
/*      */       
/*  750 */       this.antlrTool.error("Rule '" + paramRuleRefElement.targetRule + "' is not defined", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       return;
/*      */     } 
/*  753 */     if (!(ruleSymbol instanceof RuleSymbol)) {
/*      */ 
/*      */       
/*  756 */       this.antlrTool.error("'" + paramRuleRefElement.targetRule + "' does not name a grammar rule", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       
/*      */       return;
/*      */     } 
/*  760 */     genErrorTryForElement(paramRuleRefElement);
/*      */ 
/*      */ 
/*      */     
/*  764 */     if (this.grammar instanceof TreeWalkerGrammar && paramRuleRefElement.getLabel() != null && this.syntacticPredLevel == 0)
/*      */     {
/*      */ 
/*      */       
/*  768 */       println(paramRuleRefElement.getLabel() + " = (_t == ASTNULL) ? " + this.labeledElementASTInit + " : " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  773 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3))
/*      */     {
/*  775 */       println("_saveIndex = text.length();");
/*      */     }
/*      */ 
/*      */     
/*  779 */     printTabs();
/*  780 */     if (paramRuleRefElement.idAssign != null) {
/*      */ 
/*      */       
/*  783 */       if (ruleSymbol.block.returnAction == null)
/*      */       {
/*  785 */         this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' has no return type", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       }
/*  787 */       _print(paramRuleRefElement.idAssign + "=");
/*      */     
/*      */     }
/*  790 */     else if (!(this.grammar instanceof LexerGrammar) && this.syntacticPredLevel == 0 && ruleSymbol.block.returnAction != null) {
/*      */       
/*  792 */       this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' returns a value", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  797 */     GenRuleInvocation(paramRuleRefElement);
/*      */ 
/*      */     
/*  800 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3)) {
/*  801 */       println("text.erase(_saveIndex);");
/*      */     }
/*      */ 
/*      */     
/*  805 */     if (this.syntacticPredLevel == 0) {
/*      */       
/*  807 */       boolean bool = (this.grammar.hasSyntacticPredicate && ((this.grammar.buildAST && paramRuleRefElement.getLabel() != null) || (this.genAST && paramRuleRefElement.getAutoGenType() == 1))) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  815 */       if (bool) {
/*  816 */         println("if (inputState->guessing==0) {");
/*  817 */         this.tabs++;
/*      */       } 
/*      */       
/*  820 */       if (this.grammar.buildAST && paramRuleRefElement.getLabel() != null)
/*      */       {
/*      */ 
/*      */         
/*  824 */         println(paramRuleRefElement.getLabel() + "_AST = returnAST;");
/*      */       }
/*      */       
/*  827 */       if (this.genAST)
/*      */       {
/*  829 */         switch (paramRuleRefElement.getAutoGenType()) {
/*      */           
/*      */           case 1:
/*  832 */             if (this.usingCustomAST) {
/*  833 */               println("astFactory->addASTChild(currentAST, " + namespaceAntlr + "RefAST(returnAST));"); break;
/*      */             } 
/*  835 */             println("astFactory->addASTChild( currentAST, returnAST );");
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/*  840 */             this.antlrTool.error("Internal: encountered ^ after rule reference");
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  848 */       if (this.grammar instanceof LexerGrammar && paramRuleRefElement.getLabel() != null)
/*      */       {
/*  850 */         println(paramRuleRefElement.getLabel() + "=_returnToken;");
/*      */       }
/*      */       
/*  853 */       if (bool) {
/*      */         
/*  855 */         this.tabs--;
/*  856 */         println("}");
/*      */       } 
/*      */     } 
/*  859 */     genErrorCatchForElement(paramRuleRefElement);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(StringLiteralElement paramStringLiteralElement) {
/*  865 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genString(" + paramStringLiteralElement + ")");
/*      */ 
/*      */     
/*  868 */     if (paramStringLiteralElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  869 */       println(paramStringLiteralElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  873 */     genElementAST(paramStringLiteralElement);
/*      */ 
/*      */     
/*  876 */     boolean bool = this.saveText;
/*  877 */     this.saveText = (this.saveText && paramStringLiteralElement.getAutoGenType() == 1);
/*      */ 
/*      */     
/*  880 */     genMatch(paramStringLiteralElement);
/*      */     
/*  882 */     this.saveText = bool;
/*      */ 
/*      */     
/*  885 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  886 */       println("_t = _t->getNextSibling();");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRangeElement paramTokenRangeElement) {
/*  893 */     genErrorTryForElement(paramTokenRangeElement);
/*  894 */     if (paramTokenRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  895 */       println(paramTokenRangeElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  899 */     genElementAST(paramTokenRangeElement);
/*      */ 
/*      */     
/*  902 */     println("matchRange(" + paramTokenRangeElement.beginText + "," + paramTokenRangeElement.endText + ");");
/*  903 */     genErrorCatchForElement(paramTokenRangeElement);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRefElement paramTokenRefElement) {
/*  909 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genTokenRef(" + paramTokenRefElement + ")"); 
/*  910 */     if (this.grammar instanceof LexerGrammar) {
/*  911 */       this.antlrTool.panic("Token reference found in lexer");
/*      */     }
/*  913 */     genErrorTryForElement(paramTokenRefElement);
/*      */     
/*  915 */     if (paramTokenRefElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  916 */       println(paramTokenRefElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/*  920 */     genElementAST(paramTokenRefElement);
/*      */     
/*  922 */     genMatch(paramTokenRefElement);
/*  923 */     genErrorCatchForElement(paramTokenRefElement);
/*      */ 
/*      */     
/*  926 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  927 */       println("_t = _t->getNextSibling();");
/*      */     }
/*      */   }
/*      */   
/*      */   public void gen(TreeElement paramTreeElement) {
/*  932 */     println(this.labeledElementType + " __t" + paramTreeElement.ID + " = _t;");
/*      */ 
/*      */     
/*  935 */     if (paramTreeElement.root.getLabel() != null) {
/*  936 */       println(paramTreeElement.root.getLabel() + " = (_t == " + this.labeledElementType + "(ASTNULL)) ? " + this.labeledElementASTInit + " : _t;");
/*      */     }
/*      */ 
/*      */     
/*  940 */     if (paramTreeElement.root.getAutoGenType() == 3) {
/*  941 */       this.antlrTool.error("Suffixing a root node with '!' is not implemented", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */       
/*  943 */       paramTreeElement.root.setAutoGenType(1);
/*      */     } 
/*  945 */     if (paramTreeElement.root.getAutoGenType() == 2) {
/*  946 */       this.antlrTool.warning("Suffixing a root node with '^' is redundant; already a root", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */       
/*  948 */       paramTreeElement.root.setAutoGenType(1);
/*      */     } 
/*      */ 
/*      */     
/*  952 */     genElementAST(paramTreeElement.root);
/*  953 */     if (this.grammar.buildAST) {
/*      */       
/*  955 */       println(namespaceAntlr + "ASTPair __currentAST" + paramTreeElement.ID + " = currentAST;");
/*      */       
/*  957 */       println("currentAST.root = currentAST.child;");
/*  958 */       println("currentAST.child = " + this.labeledElementASTInit + ";");
/*      */     } 
/*      */ 
/*      */     
/*  962 */     if (paramTreeElement.root instanceof WildcardElement) {
/*  963 */       println("if ( _t == ASTNULL ) throw " + namespaceAntlr + "MismatchedTokenException();");
/*      */     } else {
/*      */       
/*  966 */       genMatch(paramTreeElement.root);
/*      */     } 
/*      */     
/*  969 */     println("_t = _t->getFirstChild();");
/*      */ 
/*      */     
/*  972 */     for (byte b = 0; b < paramTreeElement.getAlternatives().size(); b++) {
/*  973 */       Alternative alternative = paramTreeElement.getAlternativeAt(b);
/*  974 */       AlternativeElement alternativeElement = alternative.head;
/*  975 */       while (alternativeElement != null) {
/*  976 */         alternativeElement.generate();
/*  977 */         alternativeElement = alternativeElement.next;
/*      */       } 
/*      */     } 
/*      */     
/*  981 */     if (this.grammar.buildAST)
/*      */     {
/*      */       
/*  984 */       println("currentAST = __currentAST" + paramTreeElement.ID + ";");
/*      */     }
/*      */     
/*  987 */     println("_t = __t" + paramTreeElement.ID + ";");
/*      */     
/*  989 */     println("_t = _t->getNextSibling();");
/*      */   }
/*      */   
/*      */   public void gen(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/*  993 */     setGrammar(paramTreeWalkerGrammar);
/*  994 */     if (!(this.grammar instanceof TreeWalkerGrammar)) {
/*  995 */       this.antlrTool.panic("Internal error generating tree-walker");
/*      */     }
/*      */     
/*  998 */     genBody(paramTreeWalkerGrammar);
/*  999 */     genInclude(paramTreeWalkerGrammar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(WildcardElement paramWildcardElement) {
/* 1006 */     if (paramWildcardElement.getLabel() != null && this.syntacticPredLevel == 0) {
/* 1007 */       println(paramWildcardElement.getLabel() + " = " + this.lt1Value + ";");
/*      */     }
/*      */ 
/*      */     
/* 1011 */     genElementAST(paramWildcardElement);
/*      */     
/* 1013 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 1014 */       println("if ( _t == " + this.labeledElementASTInit + " ) throw " + namespaceAntlr + "MismatchedTokenException();");
/*      */     }
/* 1016 */     else if (this.grammar instanceof LexerGrammar) {
/* 1017 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3))
/*      */       {
/* 1019 */         println("_saveIndex = text.length();");
/*      */       }
/* 1021 */       println("matchNot(EOF/*_CHAR*/);");
/* 1022 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3))
/*      */       {
/* 1024 */         println("text.erase(_saveIndex);");
/*      */       }
/*      */     } else {
/*      */       
/* 1028 */       println("matchNot(" + getValueString(1) + ");");
/*      */     } 
/*      */ 
/*      */     
/* 1032 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 1033 */       println("_t = _t->getNextSibling();");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(ZeroOrMoreBlock paramZeroOrMoreBlock) {
/*      */     String str1;
/* 1040 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("gen*(" + paramZeroOrMoreBlock + ")"); 
/* 1041 */     println("{ // ( ... )*");
/* 1042 */     genBlockPreamble(paramZeroOrMoreBlock);
/*      */     
/* 1044 */     if (paramZeroOrMoreBlock.getLabel() != null) {
/* 1045 */       str1 = paramZeroOrMoreBlock.getLabel();
/*      */     } else {
/*      */       
/* 1048 */       str1 = "_loop" + paramZeroOrMoreBlock.ID;
/*      */     } 
/* 1050 */     println("for (;;) {");
/* 1051 */     this.tabs++;
/*      */ 
/*      */     
/* 1054 */     genBlockInitAction(paramZeroOrMoreBlock);
/*      */ 
/*      */     
/* 1057 */     String str2 = this.currentASTResult;
/* 1058 */     if (paramZeroOrMoreBlock.getLabel() != null) {
/* 1059 */       this.currentASTResult = paramZeroOrMoreBlock.getLabel();
/*      */     }
/*      */     
/* 1062 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramZeroOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1074 */     boolean bool1 = false;
/* 1075 */     int i = this.grammar.maxk;
/*      */     
/* 1077 */     if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramZeroOrMoreBlock.exitCache[paramZeroOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */ 
/*      */       
/* 1081 */       bool1 = true;
/* 1082 */       i = paramZeroOrMoreBlock.exitLookaheadDepth;
/*      */     }
/* 1084 */     else if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */ 
/*      */       
/* 1087 */       bool1 = true;
/*      */     } 
/* 1089 */     if (bool1) {
/* 1090 */       if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) {
/* 1091 */         System.out.println("nongreedy (...)* loop; exit depth is " + paramZeroOrMoreBlock.exitLookaheadDepth);
/*      */       }
/*      */       
/* 1094 */       String str = getLookaheadTestExpression(paramZeroOrMoreBlock.exitCache, i);
/*      */ 
/*      */       
/* 1097 */       println("// nongreedy exit test");
/* 1098 */       println("if (" + str + ") goto " + str1 + ";");
/*      */     } 
/*      */     
/* 1101 */     CppBlockFinishingInfo cppBlockFinishingInfo = genCommonBlock(paramZeroOrMoreBlock, false);
/* 1102 */     genBlockFinish(cppBlockFinishingInfo, "goto " + str1 + ";");
/*      */     
/* 1104 */     this.tabs--;
/* 1105 */     println("}");
/* 1106 */     println(str1 + ":;");
/* 1107 */     println("} // ( ... )*");
/*      */ 
/*      */     
/* 1110 */     this.currentASTResult = str2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genAlt(Alternative paramAlternative, AlternativeBlock paramAlternativeBlock) {
/* 1119 */     boolean bool1 = this.genAST;
/* 1120 */     this.genAST = (this.genAST && paramAlternative.getAutoGen());
/*      */     
/* 1122 */     boolean bool2 = this.saveText;
/* 1123 */     this.saveText = (this.saveText && paramAlternative.getAutoGen());
/*      */ 
/*      */     
/* 1126 */     Hashtable hashtable = this.treeVariableMap;
/* 1127 */     this.treeVariableMap = new Hashtable();
/*      */ 
/*      */     
/* 1130 */     if (paramAlternative.exceptionSpec != null) {
/* 1131 */       println("try {      // for error handling");
/* 1132 */       this.tabs++;
/*      */     } 
/*      */     
/* 1135 */     AlternativeElement alternativeElement = paramAlternative.head;
/* 1136 */     while (!(alternativeElement instanceof BlockEndElement)) {
/* 1137 */       alternativeElement.generate();
/* 1138 */       alternativeElement = alternativeElement.next;
/*      */     } 
/*      */     
/* 1141 */     if (this.genAST)
/*      */     {
/* 1143 */       if (paramAlternativeBlock instanceof RuleBlock) {
/*      */ 
/*      */         
/* 1146 */         RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/* 1147 */         if (this.usingCustomAST) {
/* 1148 */           println(ruleBlock.getRuleName() + "_AST = " + this.labeledElementASTType + "(currentAST.root);");
/*      */         } else {
/* 1150 */           println(ruleBlock.getRuleName() + "_AST = currentAST.root;");
/*      */         } 
/* 1152 */       } else if (paramAlternativeBlock.getLabel() != null) {
/*      */ 
/*      */         
/* 1155 */         this.antlrTool.warning("Labeled subrules are not implemented", this.grammar.getFilename(), paramAlternativeBlock.getLine(), paramAlternativeBlock.getColumn());
/*      */       } 
/*      */     }
/*      */     
/* 1159 */     if (paramAlternative.exceptionSpec != null) {
/*      */ 
/*      */       
/* 1162 */       this.tabs--;
/* 1163 */       println("}");
/* 1164 */       genErrorHandler(paramAlternative.exceptionSpec);
/*      */     } 
/*      */     
/* 1167 */     this.genAST = bool1;
/* 1168 */     this.saveText = bool2;
/*      */     
/* 1170 */     this.treeVariableMap = hashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBitsets(Vector paramVector, int paramInt, String paramString) {
/* 1192 */     TokenManager tokenManager = this.grammar.tokenManager;
/*      */     
/* 1194 */     println("");
/*      */     
/* 1196 */     for (byte b = 0; b < paramVector.size(); b++) {
/*      */       
/* 1198 */       BitSet bitSet = (BitSet)paramVector.elementAt(b);
/*      */       
/* 1200 */       bitSet.growToInclude(paramInt);
/*      */ 
/*      */       
/* 1203 */       println("const unsigned long " + paramString + getBitsetName(b) + "_data_" + "[] = { " + bitSet.toStringOfHalfWords() + " };");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1210 */       String str = "// ";
/*      */       
/* 1212 */       for (byte b1 = 0; b1 < tokenManager.getVocabulary().size(); b1++) {
/*      */         
/* 1214 */         if (bitSet.member(b1)) {
/*      */           
/* 1216 */           if (this.grammar instanceof LexerGrammar) {
/*      */ 
/*      */             
/* 1219 */             if (32 <= b1 && b1 < 127 && b1 != 92) {
/* 1220 */               str = str + this.charFormatter.escapeChar(b1, true) + " ";
/*      */             } else {
/* 1222 */               str = str + "0x" + Integer.toString(b1, 16) + " ";
/*      */             } 
/*      */           } else {
/* 1225 */             str = str + tokenManager.getTokenStringAt(b1) + " ";
/*      */           } 
/* 1227 */           if (str.length() > 70) {
/*      */             
/* 1229 */             println(str);
/* 1230 */             str = "// ";
/*      */           } 
/*      */         } 
/*      */       } 
/* 1234 */       if (str != "// ") {
/* 1235 */         println(str);
/*      */       }
/*      */       
/* 1238 */       println("const " + namespaceAntlr + "BitSet " + paramString + getBitsetName(b) + "(" + getBitsetName(b) + "_data_," + (bitSet.size() / 32) + ");");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBitsetsHeader(Vector paramVector, int paramInt) {
/* 1249 */     println("");
/* 1250 */     for (byte b = 0; b < paramVector.size(); b++) {
/*      */       
/* 1252 */       BitSet bitSet = (BitSet)paramVector.elementAt(b);
/*      */       
/* 1254 */       bitSet.growToInclude(paramInt);
/*      */       
/* 1256 */       println("static const unsigned long " + getBitsetName(b) + "_data_" + "[];");
/*      */       
/* 1258 */       println("static const " + namespaceAntlr + "BitSet " + getBitsetName(b) + ";");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genBlockFinish(CppBlockFinishingInfo paramCppBlockFinishingInfo, String paramString) {
/* 1269 */     if (paramCppBlockFinishingInfo.needAnErrorClause && (paramCppBlockFinishingInfo.generatedAnIf || paramCppBlockFinishingInfo.generatedSwitch)) {
/*      */       
/* 1271 */       if (paramCppBlockFinishingInfo.generatedAnIf) {
/* 1272 */         println("else {");
/*      */       } else {
/*      */         
/* 1275 */         println("{");
/*      */       } 
/* 1277 */       this.tabs++;
/* 1278 */       println(paramString);
/* 1279 */       this.tabs--;
/* 1280 */       println("}");
/*      */     } 
/*      */     
/* 1283 */     if (paramCppBlockFinishingInfo.postscript != null) {
/* 1284 */       println(paramCppBlockFinishingInfo.postscript);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockInitAction(AlternativeBlock paramAlternativeBlock) {
/* 1294 */     if (paramAlternativeBlock.initAction != null) {
/* 1295 */       genLineNo(paramAlternativeBlock);
/* 1296 */       printAction(processActionForSpecialSymbols(paramAlternativeBlock.initAction, paramAlternativeBlock.line, this.currentRule, (ActionTransInfo)null));
/*      */       
/* 1298 */       genLineNo2();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockPreamble(AlternativeBlock paramAlternativeBlock) {
/* 1308 */     if (paramAlternativeBlock instanceof RuleBlock) {
/* 1309 */       RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/* 1310 */       if (ruleBlock.labeledElements != null) {
/* 1311 */         for (byte b = 0; b < ruleBlock.labeledElements.size(); b++) {
/*      */           
/* 1313 */           AlternativeElement alternativeElement = (AlternativeElement)ruleBlock.labeledElements.elementAt(b);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1319 */           if (alternativeElement instanceof RuleRefElement || (alternativeElement instanceof AlternativeBlock && !(alternativeElement instanceof RuleBlock) && !(alternativeElement instanceof SynPredBlock))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1325 */             if (!(alternativeElement instanceof RuleRefElement) && ((AlternativeBlock)alternativeElement).not && this.analyzer.subruleCanBeInverted((AlternativeBlock)alternativeElement, this.grammar instanceof LexerGrammar))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1332 */               println(this.labeledElementType + " " + alternativeElement.getLabel() + " = " + this.labeledElementInit + ";");
/* 1333 */               if (this.grammar.buildAST) {
/* 1334 */                 genASTDeclaration(alternativeElement);
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 1339 */               if (this.grammar.buildAST)
/*      */               {
/*      */ 
/*      */                 
/* 1343 */                 genASTDeclaration(alternativeElement);
/*      */               }
/* 1345 */               if (this.grammar instanceof LexerGrammar) {
/* 1346 */                 println(namespaceAntlr + "RefToken " + alternativeElement.getLabel() + ";");
/*      */               }
/* 1348 */               if (this.grammar instanceof TreeWalkerGrammar)
/*      */               {
/* 1350 */                 println(this.labeledElementType + " " + alternativeElement.getLabel() + " = " + this.labeledElementInit + ";");
/*      */               
/*      */               }
/*      */             }
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1358 */             println(this.labeledElementType + " " + alternativeElement.getLabel() + " = " + this.labeledElementInit + ";");
/*      */             
/* 1360 */             if (this.grammar.buildAST)
/*      */             {
/* 1362 */               if (alternativeElement instanceof GrammarAtom && ((GrammarAtom)alternativeElement).getASTNodeType() != null) {
/*      */ 
/*      */                 
/* 1365 */                 GrammarAtom grammarAtom = (GrammarAtom)alternativeElement;
/* 1366 */                 genASTDeclaration(alternativeElement, "Ref" + grammarAtom.getASTNodeType());
/*      */               }
/*      */               else {
/*      */                 
/* 1370 */                 genASTDeclaration(alternativeElement);
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void genBody(LexerGrammar paramLexerGrammar) throws IOException {
/* 1380 */     this.outputFile = this.grammar.getClassName() + ".cpp";
/* 1381 */     this.outputLine = 1;
/* 1382 */     this.currentOutput = this.antlrTool.openOutputFile(this.outputFile);
/*      */ 
/*      */     
/* 1385 */     this.genAST = false;
/* 1386 */     this.saveText = true;
/*      */     
/* 1388 */     this.tabs = 0;
/*      */ 
/*      */     
/* 1391 */     genHeader(this.outputFile);
/*      */     
/* 1393 */     printHeaderAction("pre_include_cpp");
/*      */     
/* 1395 */     println("#include \"" + this.grammar.getClassName() + ".hpp\"");
/* 1396 */     println("#include <antlr/CharBuffer.hpp>");
/* 1397 */     println("#include <antlr/TokenStreamException.hpp>");
/* 1398 */     println("#include <antlr/TokenStreamIOException.hpp>");
/* 1399 */     println("#include <antlr/TokenStreamRecognitionException.hpp>");
/* 1400 */     println("#include <antlr/CharStreamException.hpp>");
/* 1401 */     println("#include <antlr/CharStreamIOException.hpp>");
/* 1402 */     println("#include <antlr/NoViableAltForCharException.hpp>");
/* 1403 */     if (this.grammar.debuggingOutput)
/* 1404 */       println("#include <antlr/DebuggingInputBuffer.hpp>"); 
/* 1405 */     println("");
/* 1406 */     printHeaderAction("post_include_cpp");
/*      */     
/* 1408 */     if (nameSpace != null) {
/* 1409 */       nameSpace.emitDeclarations(this.currentOutput);
/*      */     }
/*      */     
/* 1412 */     printAction(this.grammar.preambleAction);
/*      */ 
/*      */     
/* 1415 */     String str = null;
/* 1416 */     if (this.grammar.superClass != null) {
/* 1417 */       str = this.grammar.superClass;
/*      */     } else {
/*      */       
/* 1420 */       str = this.grammar.getSuperClass();
/* 1421 */       if (str.lastIndexOf('.') != -1)
/* 1422 */         str = str.substring(str.lastIndexOf('.') + 1); 
/* 1423 */       str = namespaceAntlr + str;
/*      */     } 
/*      */     
/* 1426 */     if (this.noConstructors) {
/*      */       
/* 1428 */       println("#if 0");
/* 1429 */       println("// constructor creation turned of with 'noConstructor' option");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1434 */     println(this.grammar.getClassName() + "::" + this.grammar.getClassName() + "(" + namespaceStd + "istream& in)");
/* 1435 */     this.tabs++;
/*      */     
/* 1437 */     if (this.grammar.debuggingOutput) {
/* 1438 */       println(": " + str + "(new " + namespaceAntlr + "DebuggingInputBuffer(new " + namespaceAntlr + "CharBuffer(in))," + paramLexerGrammar.caseSensitive + ")");
/*      */     } else {
/* 1440 */       println(": " + str + "(new " + namespaceAntlr + "CharBuffer(in)," + paramLexerGrammar.caseSensitive + ")");
/* 1441 */     }  this.tabs--;
/* 1442 */     println("{");
/* 1443 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 1447 */     if (this.grammar.debuggingOutput) {
/* 1448 */       println("setRuleNames(_ruleNames);");
/* 1449 */       println("setSemPredNames(_semPredNames);");
/* 1450 */       println("setupDebugging();");
/*      */     } 
/*      */ 
/*      */     
/* 1454 */     println("initLiterals();");
/* 1455 */     this.tabs--;
/* 1456 */     println("}");
/* 1457 */     println("");
/*      */ 
/*      */     
/* 1460 */     println(this.grammar.getClassName() + "::" + this.grammar.getClassName() + "(" + namespaceAntlr + "InputBuffer& ib)");
/* 1461 */     this.tabs++;
/*      */     
/* 1463 */     if (this.grammar.debuggingOutput) {
/* 1464 */       println(": " + str + "(new " + namespaceAntlr + "DebuggingInputBuffer(ib)," + paramLexerGrammar.caseSensitive + ")");
/*      */     } else {
/* 1466 */       println(": " + str + "(ib," + paramLexerGrammar.caseSensitive + ")");
/* 1467 */     }  this.tabs--;
/* 1468 */     println("{");
/* 1469 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 1473 */     if (this.grammar.debuggingOutput) {
/* 1474 */       println("setRuleNames(_ruleNames);");
/* 1475 */       println("setSemPredNames(_semPredNames);");
/* 1476 */       println("setupDebugging();");
/*      */     } 
/*      */ 
/*      */     
/* 1480 */     println("initLiterals();");
/* 1481 */     this.tabs--;
/* 1482 */     println("}");
/* 1483 */     println("");
/*      */ 
/*      */     
/* 1486 */     println(this.grammar.getClassName() + "::" + this.grammar.getClassName() + "(const " + namespaceAntlr + "LexerSharedInputState& state)");
/* 1487 */     this.tabs++;
/* 1488 */     println(": " + str + "(state," + paramLexerGrammar.caseSensitive + ")");
/* 1489 */     this.tabs--;
/* 1490 */     println("{");
/* 1491 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 1495 */     if (this.grammar.debuggingOutput) {
/* 1496 */       println("setRuleNames(_ruleNames);");
/* 1497 */       println("setSemPredNames(_semPredNames);");
/* 1498 */       println("setupDebugging();");
/*      */     } 
/*      */ 
/*      */     
/* 1502 */     println("initLiterals();");
/* 1503 */     this.tabs--;
/* 1504 */     println("}");
/* 1505 */     println("");
/*      */     
/* 1507 */     if (this.noConstructors) {
/*      */       
/* 1509 */       println("// constructor creation turned of with 'noConstructor' option");
/* 1510 */       println("#endif");
/*      */     } 
/*      */     
/* 1513 */     println("void " + this.grammar.getClassName() + "::initLiterals()");
/* 1514 */     println("{");
/* 1515 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 1519 */     Enumeration enumeration = this.grammar.tokenManager.getTokenSymbolKeys();
/* 1520 */     while (enumeration.hasMoreElements()) {
/* 1521 */       String str1 = enumeration.nextElement();
/* 1522 */       if (str1.charAt(0) != '"') {
/*      */         continue;
/*      */       }
/* 1525 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str1);
/* 1526 */       if (tokenSymbol instanceof StringLiteralSymbol) {
/* 1527 */         StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/* 1528 */         println("literals[" + stringLiteralSymbol.getId() + "] = " + stringLiteralSymbol.getTokenType() + ";");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1533 */     this.tabs--;
/* 1534 */     println("}");
/*      */ 
/*      */ 
/*      */     
/* 1538 */     if (this.grammar.debuggingOutput) {
/* 1539 */       println("const char* " + this.grammar.getClassName() + "::_ruleNames[] = {");
/* 1540 */       this.tabs++;
/*      */       
/* 1542 */       Enumeration enumeration2 = this.grammar.rules.elements();
/* 1543 */       boolean bool = false;
/* 1544 */       while (enumeration2.hasMoreElements()) {
/* 1545 */         GrammarSymbol grammarSymbol = enumeration2.nextElement();
/* 1546 */         if (grammarSymbol instanceof RuleSymbol)
/* 1547 */           println("\"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */       } 
/* 1549 */       println("0");
/* 1550 */       this.tabs--;
/* 1551 */       println("};");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1557 */     genNextToken();
/*      */ 
/*      */     
/* 1560 */     Enumeration enumeration1 = this.grammar.rules.elements();
/* 1561 */     byte b = 0;
/* 1562 */     while (enumeration1.hasMoreElements()) {
/* 1563 */       RuleSymbol ruleSymbol = enumeration1.nextElement();
/*      */       
/* 1565 */       if (!ruleSymbol.getId().equals("mnextToken")) {
/* 1566 */         genRule(ruleSymbol, false, b++, this.grammar.getClassName() + "::");
/*      */       }
/* 1568 */       exitIfError();
/*      */     } 
/*      */ 
/*      */     
/* 1572 */     if (this.grammar.debuggingOutput) {
/* 1573 */       genSemPredMap(this.grammar.getClassName() + "::");
/*      */     }
/*      */     
/* 1576 */     genBitsets(this.bitsetsUsed, ((LexerGrammar)this.grammar).charVocabulary.size(), this.grammar.getClassName() + "::");
/*      */     
/* 1578 */     println("");
/* 1579 */     if (nameSpace != null) {
/* 1580 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 1583 */     this.currentOutput.close();
/* 1584 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void genInitFactory(Grammar paramGrammar) {
/* 1590 */     String str = "factory ";
/* 1591 */     if (!paramGrammar.buildAST) {
/* 1592 */       str = "";
/*      */     }
/* 1594 */     println("void " + paramGrammar.getClassName() + "::initializeASTFactory( " + namespaceAntlr + "ASTFactory& " + str + ")");
/* 1595 */     println("{");
/* 1596 */     this.tabs++;
/*      */     
/* 1598 */     if (paramGrammar.buildAST) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1603 */       TokenManager tokenManager = this.grammar.tokenManager;
/* 1604 */       Enumeration enumeration = tokenManager.getTokenSymbolKeys();
/* 1605 */       while (enumeration.hasMoreElements()) {
/*      */         
/* 1607 */         String str1 = enumeration.nextElement();
/* 1608 */         TokenSymbol tokenSymbol = tokenManager.getTokenSymbol(str1);
/*      */ 
/*      */         
/* 1611 */         if (tokenSymbol.getASTNodeType() != null) {
/*      */ 
/*      */           
/* 1614 */           this.astTypes.ensureCapacity(tokenSymbol.getTokenType());
/* 1615 */           String str2 = (String)this.astTypes.elementAt(tokenSymbol.getTokenType());
/* 1616 */           if (str2 == null) {
/* 1617 */             this.astTypes.setElementAt(tokenSymbol.getASTNodeType(), tokenSymbol.getTokenType());
/*      */             
/*      */             continue;
/*      */           } 
/* 1621 */           if (!tokenSymbol.getASTNodeType().equals(str2)) {
/*      */             
/* 1623 */             this.antlrTool.warning("Token " + str1 + " taking most specific AST type", this.grammar.getFilename(), 1, 1);
/* 1624 */             this.antlrTool.warning("  using " + str2 + " ignoring " + tokenSymbol.getASTNodeType(), this.grammar.getFilename(), 1, 1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1631 */       for (byte b = 0; b < this.astTypes.size(); b++) {
/*      */         
/* 1633 */         String str1 = (String)this.astTypes.elementAt(b);
/* 1634 */         if (str1 != null)
/*      */         {
/* 1636 */           println("factory.registerFactory(" + b + ", \"" + str1 + "\", " + str1 + "::factory);");
/*      */         }
/*      */       } 
/*      */       
/* 1640 */       println("factory.setMaxNodeType(" + this.grammar.tokenManager.maxTokenType() + ");");
/*      */     } 
/* 1642 */     this.tabs--;
/* 1643 */     println("}");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genBody(ParserGrammar paramParserGrammar) throws IOException {
/* 1650 */     this.outputFile = this.grammar.getClassName() + ".cpp";
/* 1651 */     this.outputLine = 1;
/* 1652 */     this.currentOutput = this.antlrTool.openOutputFile(this.outputFile);
/*      */     
/* 1654 */     this.genAST = this.grammar.buildAST;
/*      */     
/* 1656 */     this.tabs = 0;
/*      */ 
/*      */     
/* 1659 */     genHeader(this.outputFile);
/*      */     
/* 1661 */     printHeaderAction("pre_include_cpp");
/*      */ 
/*      */     
/* 1664 */     println("#include \"" + this.grammar.getClassName() + ".hpp\"");
/* 1665 */     println("#include <antlr/NoViableAltException.hpp>");
/* 1666 */     println("#include <antlr/SemanticException.hpp>");
/* 1667 */     println("#include <antlr/ASTFactory.hpp>");
/*      */     
/* 1669 */     printHeaderAction("post_include_cpp");
/*      */     
/* 1671 */     if (nameSpace != null) {
/* 1672 */       nameSpace.emitDeclarations(this.currentOutput);
/*      */     }
/*      */     
/* 1675 */     printAction(this.grammar.preambleAction);
/*      */     
/* 1677 */     String str = null;
/* 1678 */     if (this.grammar.superClass != null) {
/* 1679 */       str = this.grammar.superClass;
/*      */     } else {
/* 1681 */       str = this.grammar.getSuperClass();
/* 1682 */       if (str.lastIndexOf('.') != -1)
/* 1683 */         str = str.substring(str.lastIndexOf('.') + 1); 
/* 1684 */       str = namespaceAntlr + str;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1689 */     if (this.grammar.debuggingOutput) {
/* 1690 */       println("const char* " + this.grammar.getClassName() + "::_ruleNames[] = {");
/* 1691 */       this.tabs++;
/*      */       
/* 1693 */       Enumeration enumeration1 = this.grammar.rules.elements();
/* 1694 */       boolean bool = false;
/* 1695 */       while (enumeration1.hasMoreElements()) {
/* 1696 */         GrammarSymbol grammarSymbol = enumeration1.nextElement();
/* 1697 */         if (grammarSymbol instanceof RuleSymbol)
/* 1698 */           println("\"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */       } 
/* 1700 */       println("0");
/* 1701 */       this.tabs--;
/* 1702 */       println("};");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1721 */     if (this.noConstructors) {
/*      */       
/* 1723 */       println("#if 0");
/* 1724 */       println("// constructor creation turned of with 'noConstructor' option");
/*      */     } 
/*      */ 
/*      */     
/* 1728 */     print(this.grammar.getClassName() + "::" + this.grammar.getClassName());
/* 1729 */     println("(" + namespaceAntlr + "TokenBuffer& tokenBuf, int k)");
/* 1730 */     println(": " + str + "(tokenBuf,k)");
/* 1731 */     println("{");
/*      */ 
/*      */ 
/*      */     
/* 1735 */     println("}");
/* 1736 */     println("");
/*      */     
/* 1738 */     print(this.grammar.getClassName() + "::" + this.grammar.getClassName());
/* 1739 */     println("(" + namespaceAntlr + "TokenBuffer& tokenBuf)");
/* 1740 */     println(": " + str + "(tokenBuf," + this.grammar.maxk + ")");
/* 1741 */     println("{");
/*      */ 
/*      */ 
/*      */     
/* 1745 */     println("}");
/* 1746 */     println("");
/*      */ 
/*      */     
/* 1749 */     print(this.grammar.getClassName() + "::" + this.grammar.getClassName());
/* 1750 */     println("(" + namespaceAntlr + "TokenStream& lexer, int k)");
/* 1751 */     println(": " + str + "(lexer,k)");
/* 1752 */     println("{");
/*      */ 
/*      */ 
/*      */     
/* 1756 */     println("}");
/* 1757 */     println("");
/*      */     
/* 1759 */     print(this.grammar.getClassName() + "::" + this.grammar.getClassName());
/* 1760 */     println("(" + namespaceAntlr + "TokenStream& lexer)");
/* 1761 */     println(": " + str + "(lexer," + this.grammar.maxk + ")");
/* 1762 */     println("{");
/*      */ 
/*      */ 
/*      */     
/* 1766 */     println("}");
/* 1767 */     println("");
/*      */     
/* 1769 */     print(this.grammar.getClassName() + "::" + this.grammar.getClassName());
/* 1770 */     println("(const " + namespaceAntlr + "ParserSharedInputState& state)");
/* 1771 */     println(": " + str + "(state," + this.grammar.maxk + ")");
/* 1772 */     println("{");
/*      */ 
/*      */ 
/*      */     
/* 1776 */     println("}");
/* 1777 */     println("");
/*      */     
/* 1779 */     if (this.noConstructors) {
/*      */       
/* 1781 */       println("// constructor creation turned of with 'noConstructor' option");
/* 1782 */       println("#endif");
/*      */     } 
/*      */     
/* 1785 */     this.astTypes = new Vector();
/*      */ 
/*      */     
/* 1788 */     Enumeration enumeration = this.grammar.rules.elements();
/* 1789 */     byte b = 0;
/* 1790 */     while (enumeration.hasMoreElements()) {
/* 1791 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 1792 */       if (grammarSymbol instanceof RuleSymbol) {
/* 1793 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 1794 */         genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++, this.grammar.getClassName() + "::");
/*      */       } 
/* 1796 */       exitIfError();
/*      */     } 
/*      */     
/* 1799 */     genInitFactory(paramParserGrammar);
/*      */ 
/*      */     
/* 1802 */     genTokenStrings(this.grammar.getClassName() + "::");
/*      */ 
/*      */     
/* 1805 */     genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType(), this.grammar.getClassName() + "::");
/*      */ 
/*      */     
/* 1808 */     if (this.grammar.debuggingOutput) {
/* 1809 */       genSemPredMap(this.grammar.getClassName() + "::");
/*      */     }
/*      */     
/* 1812 */     println("");
/* 1813 */     println("");
/* 1814 */     if (nameSpace != null) {
/* 1815 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 1818 */     this.currentOutput.close();
/* 1819 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void genBody(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/* 1824 */     this.outputFile = this.grammar.getClassName() + ".cpp";
/* 1825 */     this.outputLine = 1;
/* 1826 */     this.currentOutput = this.antlrTool.openOutputFile(this.outputFile);
/*      */ 
/*      */     
/* 1829 */     this.genAST = this.grammar.buildAST;
/* 1830 */     this.tabs = 0;
/*      */ 
/*      */     
/* 1833 */     genHeader(this.outputFile);
/*      */     
/* 1835 */     printHeaderAction("pre_include_cpp");
/*      */ 
/*      */     
/* 1838 */     println("#include \"" + this.grammar.getClassName() + ".hpp\"");
/* 1839 */     println("#include <antlr/Token.hpp>");
/* 1840 */     println("#include <antlr/AST.hpp>");
/* 1841 */     println("#include <antlr/NoViableAltException.hpp>");
/* 1842 */     println("#include <antlr/MismatchedTokenException.hpp>");
/* 1843 */     println("#include <antlr/SemanticException.hpp>");
/* 1844 */     println("#include <antlr/BitSet.hpp>");
/*      */     
/* 1846 */     printHeaderAction("post_include_cpp");
/*      */     
/* 1848 */     if (nameSpace != null) {
/* 1849 */       nameSpace.emitDeclarations(this.currentOutput);
/*      */     }
/*      */     
/* 1852 */     printAction(this.grammar.preambleAction);
/*      */ 
/*      */     
/* 1855 */     String str1 = null;
/* 1856 */     if (this.grammar.superClass != null) {
/* 1857 */       str1 = this.grammar.superClass;
/*      */     } else {
/*      */       
/* 1860 */       str1 = this.grammar.getSuperClass();
/* 1861 */       if (str1.lastIndexOf('.') != -1)
/* 1862 */         str1 = str1.substring(str1.lastIndexOf('.') + 1); 
/* 1863 */       str1 = namespaceAntlr + str1;
/*      */     } 
/* 1865 */     if (this.noConstructors) {
/*      */       
/* 1867 */       println("#if 0");
/* 1868 */       println("// constructor creation turned of with 'noConstructor' option");
/*      */     } 
/*      */ 
/*      */     
/* 1872 */     println(this.grammar.getClassName() + "::" + this.grammar.getClassName() + "()");
/* 1873 */     println("\t: " + namespaceAntlr + "TreeParser() {");
/* 1874 */     this.tabs++;
/*      */     
/* 1876 */     this.tabs--;
/* 1877 */     println("}");
/*      */     
/* 1879 */     if (this.noConstructors) {
/*      */       
/* 1881 */       println("// constructor creation turned of with 'noConstructor' option");
/* 1882 */       println("#endif");
/*      */     } 
/* 1884 */     println("");
/*      */     
/* 1886 */     this.astTypes = new Vector();
/*      */ 
/*      */     
/* 1889 */     Enumeration enumeration = this.grammar.rules.elements();
/* 1890 */     byte b = 0;
/* 1891 */     String str2 = "";
/* 1892 */     while (enumeration.hasMoreElements()) {
/* 1893 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 1894 */       if (grammarSymbol instanceof RuleSymbol) {
/* 1895 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 1896 */         genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++, this.grammar.getClassName() + "::");
/*      */       } 
/* 1898 */       exitIfError();
/*      */     } 
/*      */ 
/*      */     
/* 1902 */     genInitFactory(this.grammar);
/*      */     
/* 1904 */     genTokenStrings(this.grammar.getClassName() + "::");
/*      */ 
/*      */     
/* 1907 */     genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType(), this.grammar.getClassName() + "::");
/*      */ 
/*      */     
/* 1910 */     println("");
/* 1911 */     println("");
/*      */     
/* 1913 */     if (nameSpace != null) {
/* 1914 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 1917 */     this.currentOutput.close();
/* 1918 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genCases(BitSet paramBitSet) {
/* 1924 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genCases(" + paramBitSet + ")");
/*      */ 
/*      */     
/* 1927 */     int[] arrayOfInt = paramBitSet.toArray();
/*      */     
/* 1929 */     byte b1 = 1;
/* 1930 */     byte b2 = 1;
/* 1931 */     boolean bool = true;
/* 1932 */     for (byte b3 = 0; b3 < arrayOfInt.length; b3++) {
/* 1933 */       if (b2 == 1) {
/* 1934 */         print("");
/*      */       } else {
/* 1936 */         _print("  ");
/*      */       } 
/* 1938 */       _print("case " + getValueString(arrayOfInt[b3]) + ":");
/*      */       
/* 1940 */       if (b2 == b1) {
/* 1941 */         _println("");
/* 1942 */         bool = true;
/* 1943 */         b2 = 1;
/*      */       } else {
/*      */         
/* 1946 */         b2++;
/* 1947 */         bool = false;
/*      */       } 
/*      */     } 
/* 1950 */     if (!bool) {
/* 1951 */       _println("");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CppBlockFinishingInfo genCommonBlock(AlternativeBlock paramAlternativeBlock, boolean paramBoolean) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_3
/*      */     //   2: iconst_0
/*      */     //   3: istore #4
/*      */     //   5: iconst_0
/*      */     //   6: istore #5
/*      */     //   8: new antlr/CppBlockFinishingInfo
/*      */     //   11: dup
/*      */     //   12: invokespecial <init> : ()V
/*      */     //   15: astore #6
/*      */     //   17: aload_0
/*      */     //   18: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   21: ifne -> 31
/*      */     //   24: aload_0
/*      */     //   25: getfield DEBUG_CPP_CODE_GENERATOR : Z
/*      */     //   28: ifeq -> 62
/*      */     //   31: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   34: new java/lang/StringBuffer
/*      */     //   37: dup
/*      */     //   38: invokespecial <init> : ()V
/*      */     //   41: ldc_w 'genCommonBlk('
/*      */     //   44: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   47: aload_1
/*      */     //   48: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuffer;
/*      */     //   51: ldc ')'
/*      */     //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   56: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   59: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   62: aload_0
/*      */     //   63: getfield genAST : Z
/*      */     //   66: istore #7
/*      */     //   68: aload_0
/*      */     //   69: aload_0
/*      */     //   70: getfield genAST : Z
/*      */     //   73: ifeq -> 87
/*      */     //   76: aload_1
/*      */     //   77: invokevirtual getAutoGen : ()Z
/*      */     //   80: ifeq -> 87
/*      */     //   83: iconst_1
/*      */     //   84: goto -> 88
/*      */     //   87: iconst_0
/*      */     //   88: putfield genAST : Z
/*      */     //   91: aload_0
/*      */     //   92: getfield saveText : Z
/*      */     //   95: istore #8
/*      */     //   97: aload_0
/*      */     //   98: aload_0
/*      */     //   99: getfield saveText : Z
/*      */     //   102: ifeq -> 116
/*      */     //   105: aload_1
/*      */     //   106: invokevirtual getAutoGen : ()Z
/*      */     //   109: ifeq -> 116
/*      */     //   112: iconst_1
/*      */     //   113: goto -> 117
/*      */     //   116: iconst_0
/*      */     //   117: putfield saveText : Z
/*      */     //   120: aload_1
/*      */     //   121: getfield not : Z
/*      */     //   124: ifeq -> 341
/*      */     //   127: aload_0
/*      */     //   128: getfield analyzer : Lantlr/LLkGrammarAnalyzer;
/*      */     //   131: aload_1
/*      */     //   132: aload_0
/*      */     //   133: getfield grammar : Lantlr/Grammar;
/*      */     //   136: instanceof antlr/LexerGrammar
/*      */     //   139: invokeinterface subruleCanBeInverted : (Lantlr/AlternativeBlock;Z)Z
/*      */     //   144: ifeq -> 341
/*      */     //   147: aload_0
/*      */     //   148: getfield analyzer : Lantlr/LLkGrammarAnalyzer;
/*      */     //   151: iconst_1
/*      */     //   152: aload_1
/*      */     //   153: invokeinterface look : (ILantlr/AlternativeBlock;)Lantlr/Lookahead;
/*      */     //   158: astore #9
/*      */     //   160: aload_1
/*      */     //   161: invokevirtual getLabel : ()Ljava/lang/String;
/*      */     //   164: ifnull -> 212
/*      */     //   167: aload_0
/*      */     //   168: getfield syntacticPredLevel : I
/*      */     //   171: ifne -> 212
/*      */     //   174: aload_0
/*      */     //   175: new java/lang/StringBuffer
/*      */     //   178: dup
/*      */     //   179: invokespecial <init> : ()V
/*      */     //   182: aload_1
/*      */     //   183: invokevirtual getLabel : ()Ljava/lang/String;
/*      */     //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   189: ldc ' = '
/*      */     //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   194: aload_0
/*      */     //   195: getfield lt1Value : Ljava/lang/String;
/*      */     //   198: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   201: ldc ';'
/*      */     //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   206: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   209: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   212: aload_0
/*      */     //   213: aload_1
/*      */     //   214: invokespecial genElementAST : (Lantlr/AlternativeElement;)V
/*      */     //   217: ldc ''
/*      */     //   219: astore #10
/*      */     //   221: aload_0
/*      */     //   222: getfield grammar : Lantlr/Grammar;
/*      */     //   225: instanceof antlr/TreeWalkerGrammar
/*      */     //   228: ifeq -> 276
/*      */     //   231: aload_0
/*      */     //   232: getfield usingCustomAST : Z
/*      */     //   235: ifeq -> 271
/*      */     //   238: new java/lang/StringBuffer
/*      */     //   241: dup
/*      */     //   242: invokespecial <init> : ()V
/*      */     //   245: getstatic antlr/CppCodeGenerator.namespaceAntlr : Ljava/lang/String;
/*      */     //   248: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   251: ldc_w 'RefAST'
/*      */     //   254: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   257: ldc_w '(_t),'
/*      */     //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   263: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   266: astore #10
/*      */     //   268: goto -> 276
/*      */     //   271: ldc_w '_t,'
/*      */     //   274: astore #10
/*      */     //   276: aload_0
/*      */     //   277: new java/lang/StringBuffer
/*      */     //   280: dup
/*      */     //   281: invokespecial <init> : ()V
/*      */     //   284: ldc 'match('
/*      */     //   286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   289: aload #10
/*      */     //   291: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   294: aload_0
/*      */     //   295: aload_0
/*      */     //   296: aload #9
/*      */     //   298: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   301: invokevirtual markBitsetForGen : (Lantlr/collections/impl/BitSet;)I
/*      */     //   304: invokevirtual getBitsetName : (I)Ljava/lang/String;
/*      */     //   307: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   310: ldc ');'
/*      */     //   312: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   315: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   318: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   321: aload_0
/*      */     //   322: getfield grammar : Lantlr/Grammar;
/*      */     //   325: instanceof antlr/TreeWalkerGrammar
/*      */     //   328: ifeq -> 338
/*      */     //   331: aload_0
/*      */     //   332: ldc_w '_t = _t->getNextSibling();'
/*      */     //   335: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   338: aload #6
/*      */     //   340: areturn
/*      */     //   341: aload_1
/*      */     //   342: invokevirtual getAlternatives : ()Lantlr/collections/impl/Vector;
/*      */     //   345: invokevirtual size : ()I
/*      */     //   348: iconst_1
/*      */     //   349: if_icmpne -> 441
/*      */     //   352: aload_1
/*      */     //   353: iconst_0
/*      */     //   354: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   357: astore #9
/*      */     //   359: aload #9
/*      */     //   361: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   364: ifnull -> 406
/*      */     //   367: aload_0
/*      */     //   368: getfield antlrTool : Lantlr/Tool;
/*      */     //   371: ldc_w 'Syntactic predicate superfluous for single alternative'
/*      */     //   374: aload_0
/*      */     //   375: getfield grammar : Lantlr/Grammar;
/*      */     //   378: invokevirtual getFilename : ()Ljava/lang/String;
/*      */     //   381: aload_1
/*      */     //   382: iconst_0
/*      */     //   383: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   386: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   389: invokevirtual getLine : ()I
/*      */     //   392: aload_1
/*      */     //   393: iconst_0
/*      */     //   394: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   397: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   400: invokevirtual getColumn : ()I
/*      */     //   403: invokevirtual warning : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   406: iload_2
/*      */     //   407: ifeq -> 441
/*      */     //   410: aload #9
/*      */     //   412: getfield semPred : Ljava/lang/String;
/*      */     //   415: ifnull -> 431
/*      */     //   418: aload_0
/*      */     //   419: aload #9
/*      */     //   421: getfield semPred : Ljava/lang/String;
/*      */     //   424: aload_1
/*      */     //   425: getfield line : I
/*      */     //   428: invokevirtual genSemPred : (Ljava/lang/String;I)V
/*      */     //   431: aload_0
/*      */     //   432: aload #9
/*      */     //   434: aload_1
/*      */     //   435: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   438: aload #6
/*      */     //   440: areturn
/*      */     //   441: iconst_0
/*      */     //   442: istore #9
/*      */     //   444: iconst_0
/*      */     //   445: istore #10
/*      */     //   447: iload #10
/*      */     //   449: aload_1
/*      */     //   450: invokevirtual getAlternatives : ()Lantlr/collections/impl/Vector;
/*      */     //   453: invokevirtual size : ()I
/*      */     //   456: if_icmpge -> 484
/*      */     //   459: aload_1
/*      */     //   460: iload #10
/*      */     //   462: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   465: astore #11
/*      */     //   467: aload #11
/*      */     //   469: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   472: ifeq -> 478
/*      */     //   475: iinc #9, 1
/*      */     //   478: iinc #10, 1
/*      */     //   481: goto -> 447
/*      */     //   484: iload #9
/*      */     //   486: aload_0
/*      */     //   487: getfield makeSwitchThreshold : I
/*      */     //   490: if_icmplt -> 779
/*      */     //   493: aload_0
/*      */     //   494: iconst_1
/*      */     //   495: invokespecial lookaheadString : (I)Ljava/lang/String;
/*      */     //   498: astore #10
/*      */     //   500: iconst_1
/*      */     //   501: istore #4
/*      */     //   503: aload_0
/*      */     //   504: getfield grammar : Lantlr/Grammar;
/*      */     //   507: instanceof antlr/TreeWalkerGrammar
/*      */     //   510: ifeq -> 572
/*      */     //   513: aload_0
/*      */     //   514: new java/lang/StringBuffer
/*      */     //   517: dup
/*      */     //   518: invokespecial <init> : ()V
/*      */     //   521: ldc_w 'if (_t == '
/*      */     //   524: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   527: aload_0
/*      */     //   528: getfield labeledElementASTInit : Ljava/lang/String;
/*      */     //   531: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   534: ldc ' )'
/*      */     //   536: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   539: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   542: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   545: aload_0
/*      */     //   546: dup
/*      */     //   547: getfield tabs : I
/*      */     //   550: iconst_1
/*      */     //   551: iadd
/*      */     //   552: putfield tabs : I
/*      */     //   555: aload_0
/*      */     //   556: ldc_w '_t = ASTNULL;'
/*      */     //   559: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   562: aload_0
/*      */     //   563: dup
/*      */     //   564: getfield tabs : I
/*      */     //   567: iconst_1
/*      */     //   568: isub
/*      */     //   569: putfield tabs : I
/*      */     //   572: aload_0
/*      */     //   573: new java/lang/StringBuffer
/*      */     //   576: dup
/*      */     //   577: invokespecial <init> : ()V
/*      */     //   580: ldc_w 'switch ( '
/*      */     //   583: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   586: aload #10
/*      */     //   588: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   591: ldc_w ') {'
/*      */     //   594: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   597: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   600: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   603: iconst_0
/*      */     //   604: istore #11
/*      */     //   606: iload #11
/*      */     //   608: aload_1
/*      */     //   609: getfield alternatives : Lantlr/collections/impl/Vector;
/*      */     //   612: invokevirtual size : ()I
/*      */     //   615: if_icmpge -> 762
/*      */     //   618: aload_1
/*      */     //   619: iload #11
/*      */     //   621: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   624: astore #12
/*      */     //   626: aload #12
/*      */     //   628: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   631: ifne -> 637
/*      */     //   634: goto -> 756
/*      */     //   637: aload #12
/*      */     //   639: getfield cache : [Lantlr/Lookahead;
/*      */     //   642: iconst_1
/*      */     //   643: aaload
/*      */     //   644: astore #13
/*      */     //   646: aload #13
/*      */     //   648: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   651: invokevirtual degree : ()I
/*      */     //   654: ifne -> 701
/*      */     //   657: aload #13
/*      */     //   659: invokevirtual containsEpsilon : ()Z
/*      */     //   662: ifne -> 701
/*      */     //   665: aload_0
/*      */     //   666: getfield antlrTool : Lantlr/Tool;
/*      */     //   669: ldc_w 'Alternate omitted due to empty prediction set'
/*      */     //   672: aload_0
/*      */     //   673: getfield grammar : Lantlr/Grammar;
/*      */     //   676: invokevirtual getFilename : ()Ljava/lang/String;
/*      */     //   679: aload #12
/*      */     //   681: getfield head : Lantlr/AlternativeElement;
/*      */     //   684: invokevirtual getLine : ()I
/*      */     //   687: aload #12
/*      */     //   689: getfield head : Lantlr/AlternativeElement;
/*      */     //   692: invokevirtual getColumn : ()I
/*      */     //   695: invokevirtual warning : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   698: goto -> 756
/*      */     //   701: aload_0
/*      */     //   702: aload #13
/*      */     //   704: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   707: invokevirtual genCases : (Lantlr/collections/impl/BitSet;)V
/*      */     //   710: aload_0
/*      */     //   711: ldc '{'
/*      */     //   713: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   716: aload_0
/*      */     //   717: dup
/*      */     //   718: getfield tabs : I
/*      */     //   721: iconst_1
/*      */     //   722: iadd
/*      */     //   723: putfield tabs : I
/*      */     //   726: aload_0
/*      */     //   727: aload #12
/*      */     //   729: aload_1
/*      */     //   730: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   733: aload_0
/*      */     //   734: ldc_w 'break;'
/*      */     //   737: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   740: aload_0
/*      */     //   741: dup
/*      */     //   742: getfield tabs : I
/*      */     //   745: iconst_1
/*      */     //   746: isub
/*      */     //   747: putfield tabs : I
/*      */     //   750: aload_0
/*      */     //   751: ldc '}'
/*      */     //   753: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   756: iinc #11, 1
/*      */     //   759: goto -> 606
/*      */     //   762: aload_0
/*      */     //   763: ldc_w 'default:'
/*      */     //   766: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   769: aload_0
/*      */     //   770: dup
/*      */     //   771: getfield tabs : I
/*      */     //   774: iconst_1
/*      */     //   775: iadd
/*      */     //   776: putfield tabs : I
/*      */     //   779: aload_0
/*      */     //   780: getfield grammar : Lantlr/Grammar;
/*      */     //   783: instanceof antlr/LexerGrammar
/*      */     //   786: ifeq -> 799
/*      */     //   789: aload_0
/*      */     //   790: getfield grammar : Lantlr/Grammar;
/*      */     //   793: getfield maxk : I
/*      */     //   796: goto -> 800
/*      */     //   799: iconst_0
/*      */     //   800: istore #10
/*      */     //   802: iload #10
/*      */     //   804: istore #11
/*      */     //   806: iload #11
/*      */     //   808: iflt -> 1772
/*      */     //   811: aload_0
/*      */     //   812: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   815: ifne -> 825
/*      */     //   818: aload_0
/*      */     //   819: getfield DEBUG_CPP_CODE_GENERATOR : Z
/*      */     //   822: ifeq -> 852
/*      */     //   825: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   828: new java/lang/StringBuffer
/*      */     //   831: dup
/*      */     //   832: invokespecial <init> : ()V
/*      */     //   835: ldc_w 'checking depth '
/*      */     //   838: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   841: iload #11
/*      */     //   843: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   846: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   849: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   852: iconst_0
/*      */     //   853: istore #12
/*      */     //   855: iload #12
/*      */     //   857: aload_1
/*      */     //   858: getfield alternatives : Lantlr/collections/impl/Vector;
/*      */     //   861: invokevirtual size : ()I
/*      */     //   864: if_icmpge -> 1766
/*      */     //   867: aload_1
/*      */     //   868: iload #12
/*      */     //   870: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   873: astore #13
/*      */     //   875: aload_0
/*      */     //   876: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   879: ifne -> 889
/*      */     //   882: aload_0
/*      */     //   883: getfield DEBUG_CPP_CODE_GENERATOR : Z
/*      */     //   886: ifeq -> 916
/*      */     //   889: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   892: new java/lang/StringBuffer
/*      */     //   895: dup
/*      */     //   896: invokespecial <init> : ()V
/*      */     //   899: ldc_w 'genAlt: '
/*      */     //   902: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   905: iload #12
/*      */     //   907: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   910: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   913: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   916: iload #4
/*      */     //   918: ifeq -> 955
/*      */     //   921: aload #13
/*      */     //   923: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   926: ifeq -> 955
/*      */     //   929: aload_0
/*      */     //   930: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   933: ifne -> 943
/*      */     //   936: aload_0
/*      */     //   937: getfield DEBUG_CPP_CODE_GENERATOR : Z
/*      */     //   940: ifeq -> 1760
/*      */     //   943: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   946: ldc_w 'ignoring alt because it was in the switch'
/*      */     //   949: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   952: goto -> 1760
/*      */     //   955: iconst_0
/*      */     //   956: istore #15
/*      */     //   958: aload_0
/*      */     //   959: getfield grammar : Lantlr/Grammar;
/*      */     //   962: instanceof antlr/LexerGrammar
/*      */     //   965: ifeq -> 1101
/*      */     //   968: aload #13
/*      */     //   970: getfield lookaheadDepth : I
/*      */     //   973: istore #16
/*      */     //   975: iload #16
/*      */     //   977: ldc 2147483647
/*      */     //   979: if_icmpne -> 991
/*      */     //   982: aload_0
/*      */     //   983: getfield grammar : Lantlr/Grammar;
/*      */     //   986: getfield maxk : I
/*      */     //   989: istore #16
/*      */     //   991: iload #16
/*      */     //   993: iconst_1
/*      */     //   994: if_icmplt -> 1017
/*      */     //   997: aload #13
/*      */     //   999: getfield cache : [Lantlr/Lookahead;
/*      */     //   1002: iload #16
/*      */     //   1004: aaload
/*      */     //   1005: invokevirtual containsEpsilon : ()Z
/*      */     //   1008: ifeq -> 1017
/*      */     //   1011: iinc #16, -1
/*      */     //   1014: goto -> 991
/*      */     //   1017: iload #16
/*      */     //   1019: iload #11
/*      */     //   1021: if_icmpeq -> 1078
/*      */     //   1024: aload_0
/*      */     //   1025: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   1028: ifne -> 1038
/*      */     //   1031: aload_0
/*      */     //   1032: getfield DEBUG_CPP_CODE_GENERATOR : Z
/*      */     //   1035: ifeq -> 1760
/*      */     //   1038: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   1041: new java/lang/StringBuffer
/*      */     //   1044: dup
/*      */     //   1045: invokespecial <init> : ()V
/*      */     //   1048: ldc_w 'ignoring alt because effectiveDepth!=altDepth;'
/*      */     //   1051: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1054: iload #16
/*      */     //   1056: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   1059: ldc '!='
/*      */     //   1061: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1064: iload #11
/*      */     //   1066: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   1069: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1072: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1075: goto -> 1760
/*      */     //   1078: aload_0
/*      */     //   1079: aload #13
/*      */     //   1081: iload #16
/*      */     //   1083: invokevirtual lookaheadIsEmpty : (Lantlr/Alternative;I)Z
/*      */     //   1086: istore #15
/*      */     //   1088: aload_0
/*      */     //   1089: aload #13
/*      */     //   1091: iload #16
/*      */     //   1093: invokevirtual getLookaheadTestExpression : (Lantlr/Alternative;I)Ljava/lang/String;
/*      */     //   1096: astore #14
/*      */     //   1098: goto -> 1131
/*      */     //   1101: aload_0
/*      */     //   1102: aload #13
/*      */     //   1104: aload_0
/*      */     //   1105: getfield grammar : Lantlr/Grammar;
/*      */     //   1108: getfield maxk : I
/*      */     //   1111: invokevirtual lookaheadIsEmpty : (Lantlr/Alternative;I)Z
/*      */     //   1114: istore #15
/*      */     //   1116: aload_0
/*      */     //   1117: aload #13
/*      */     //   1119: aload_0
/*      */     //   1120: getfield grammar : Lantlr/Grammar;
/*      */     //   1123: getfield maxk : I
/*      */     //   1126: invokevirtual getLookaheadTestExpression : (Lantlr/Alternative;I)Ljava/lang/String;
/*      */     //   1129: astore #14
/*      */     //   1131: aload #13
/*      */     //   1133: getfield cache : [Lantlr/Lookahead;
/*      */     //   1136: iconst_1
/*      */     //   1137: aaload
/*      */     //   1138: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   1141: invokevirtual degree : ()I
/*      */     //   1144: bipush #127
/*      */     //   1146: if_icmple -> 1298
/*      */     //   1149: aload #13
/*      */     //   1151: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   1154: ifeq -> 1298
/*      */     //   1157: iload_3
/*      */     //   1158: ifne -> 1264
/*      */     //   1161: aload_0
/*      */     //   1162: getfield grammar : Lantlr/Grammar;
/*      */     //   1165: instanceof antlr/TreeWalkerGrammar
/*      */     //   1168: ifeq -> 1230
/*      */     //   1171: aload_0
/*      */     //   1172: new java/lang/StringBuffer
/*      */     //   1175: dup
/*      */     //   1176: invokespecial <init> : ()V
/*      */     //   1179: ldc_w 'if (_t == '
/*      */     //   1182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1185: aload_0
/*      */     //   1186: getfield labeledElementASTInit : Ljava/lang/String;
/*      */     //   1189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1192: ldc ' )'
/*      */     //   1194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1197: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1200: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1203: aload_0
/*      */     //   1204: dup
/*      */     //   1205: getfield tabs : I
/*      */     //   1208: iconst_1
/*      */     //   1209: iadd
/*      */     //   1210: putfield tabs : I
/*      */     //   1213: aload_0
/*      */     //   1214: ldc_w '_t = ASTNULL;'
/*      */     //   1217: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1220: aload_0
/*      */     //   1221: dup
/*      */     //   1222: getfield tabs : I
/*      */     //   1225: iconst_1
/*      */     //   1226: isub
/*      */     //   1227: putfield tabs : I
/*      */     //   1230: aload_0
/*      */     //   1231: new java/lang/StringBuffer
/*      */     //   1234: dup
/*      */     //   1235: invokespecial <init> : ()V
/*      */     //   1238: ldc_w 'if '
/*      */     //   1241: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1244: aload #14
/*      */     //   1246: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1249: ldc_w ' {'
/*      */     //   1252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1255: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1258: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1261: goto -> 1724
/*      */     //   1264: aload_0
/*      */     //   1265: new java/lang/StringBuffer
/*      */     //   1268: dup
/*      */     //   1269: invokespecial <init> : ()V
/*      */     //   1272: ldc_w 'else if '
/*      */     //   1275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1278: aload #14
/*      */     //   1280: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1283: ldc_w ' {'
/*      */     //   1286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1289: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1292: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1295: goto -> 1724
/*      */     //   1298: iload #15
/*      */     //   1300: ifeq -> 1348
/*      */     //   1303: aload #13
/*      */     //   1305: getfield semPred : Ljava/lang/String;
/*      */     //   1308: ifnonnull -> 1348
/*      */     //   1311: aload #13
/*      */     //   1313: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1316: ifnonnull -> 1348
/*      */     //   1319: iload_3
/*      */     //   1320: ifne -> 1332
/*      */     //   1323: aload_0
/*      */     //   1324: ldc '{'
/*      */     //   1326: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1329: goto -> 1339
/*      */     //   1332: aload_0
/*      */     //   1333: ldc_w 'else {'
/*      */     //   1336: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1339: aload #6
/*      */     //   1341: iconst_0
/*      */     //   1342: putfield needAnErrorClause : Z
/*      */     //   1345: goto -> 1724
/*      */     //   1348: aload #13
/*      */     //   1350: getfield semPred : Ljava/lang/String;
/*      */     //   1353: ifnull -> 1522
/*      */     //   1356: new antlr/ActionTransInfo
/*      */     //   1359: dup
/*      */     //   1360: invokespecial <init> : ()V
/*      */     //   1363: astore #16
/*      */     //   1365: aload_0
/*      */     //   1366: aload #13
/*      */     //   1368: getfield semPred : Ljava/lang/String;
/*      */     //   1371: aload_1
/*      */     //   1372: getfield line : I
/*      */     //   1375: aload_0
/*      */     //   1376: getfield currentRule : Lantlr/RuleBlock;
/*      */     //   1379: aload #16
/*      */     //   1381: invokevirtual processActionForSpecialSymbols : (Ljava/lang/String;ILantlr/RuleBlock;Lantlr/ActionTransInfo;)Ljava/lang/String;
/*      */     //   1384: astore #17
/*      */     //   1386: aload_0
/*      */     //   1387: getfield grammar : Lantlr/Grammar;
/*      */     //   1390: getfield debuggingOutput : Z
/*      */     //   1393: ifeq -> 1482
/*      */     //   1396: aload_0
/*      */     //   1397: getfield grammar : Lantlr/Grammar;
/*      */     //   1400: instanceof antlr/ParserGrammar
/*      */     //   1403: ifne -> 1416
/*      */     //   1406: aload_0
/*      */     //   1407: getfield grammar : Lantlr/Grammar;
/*      */     //   1410: instanceof antlr/LexerGrammar
/*      */     //   1413: ifeq -> 1482
/*      */     //   1416: new java/lang/StringBuffer
/*      */     //   1419: dup
/*      */     //   1420: invokespecial <init> : ()V
/*      */     //   1423: ldc_w '('
/*      */     //   1426: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1429: aload #14
/*      */     //   1431: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1434: ldc_w '&& fireSemanticPredicateEvaluated(antlr.debug.SemanticPredicateEvent.PREDICTING,'
/*      */     //   1437: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1440: aload_0
/*      */     //   1441: aload_0
/*      */     //   1442: getfield charFormatter : Lantlr/CharFormatter;
/*      */     //   1445: aload #17
/*      */     //   1447: invokeinterface escapeString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1452: invokevirtual addSemPred : (Ljava/lang/String;)I
/*      */     //   1455: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   1458: ldc ','
/*      */     //   1460: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1463: aload #17
/*      */     //   1465: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1468: ldc_w '))'
/*      */     //   1471: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1474: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1477: astore #14
/*      */     //   1479: goto -> 1522
/*      */     //   1482: new java/lang/StringBuffer
/*      */     //   1485: dup
/*      */     //   1486: invokespecial <init> : ()V
/*      */     //   1489: ldc_w '('
/*      */     //   1492: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1495: aload #14
/*      */     //   1497: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1500: ldc_w '&&('
/*      */     //   1503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1506: aload #17
/*      */     //   1508: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1511: ldc_w '))'
/*      */     //   1514: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1517: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1520: astore #14
/*      */     //   1522: iload_3
/*      */     //   1523: ifle -> 1602
/*      */     //   1526: aload #13
/*      */     //   1528: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1531: ifnull -> 1568
/*      */     //   1534: aload_0
/*      */     //   1535: ldc_w 'else {'
/*      */     //   1538: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1541: aload_0
/*      */     //   1542: dup
/*      */     //   1543: getfield tabs : I
/*      */     //   1546: iconst_1
/*      */     //   1547: iadd
/*      */     //   1548: putfield tabs : I
/*      */     //   1551: aload_0
/*      */     //   1552: aload #13
/*      */     //   1554: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1557: aload #14
/*      */     //   1559: invokevirtual genSynPred : (Lantlr/SynPredBlock;Ljava/lang/String;)V
/*      */     //   1562: iinc #5, 1
/*      */     //   1565: goto -> 1724
/*      */     //   1568: aload_0
/*      */     //   1569: new java/lang/StringBuffer
/*      */     //   1572: dup
/*      */     //   1573: invokespecial <init> : ()V
/*      */     //   1576: ldc_w 'else if '
/*      */     //   1579: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1582: aload #14
/*      */     //   1584: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1587: ldc_w ' {'
/*      */     //   1590: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1593: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1596: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1599: goto -> 1724
/*      */     //   1602: aload #13
/*      */     //   1604: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1607: ifnull -> 1624
/*      */     //   1610: aload_0
/*      */     //   1611: aload #13
/*      */     //   1613: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1616: aload #14
/*      */     //   1618: invokevirtual genSynPred : (Lantlr/SynPredBlock;Ljava/lang/String;)V
/*      */     //   1621: goto -> 1724
/*      */     //   1624: aload_0
/*      */     //   1625: getfield grammar : Lantlr/Grammar;
/*      */     //   1628: instanceof antlr/TreeWalkerGrammar
/*      */     //   1631: ifeq -> 1693
/*      */     //   1634: aload_0
/*      */     //   1635: new java/lang/StringBuffer
/*      */     //   1638: dup
/*      */     //   1639: invokespecial <init> : ()V
/*      */     //   1642: ldc_w 'if (_t == '
/*      */     //   1645: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1648: aload_0
/*      */     //   1649: getfield labeledElementASTInit : Ljava/lang/String;
/*      */     //   1652: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1655: ldc ' )'
/*      */     //   1657: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1660: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1663: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1666: aload_0
/*      */     //   1667: dup
/*      */     //   1668: getfield tabs : I
/*      */     //   1671: iconst_1
/*      */     //   1672: iadd
/*      */     //   1673: putfield tabs : I
/*      */     //   1676: aload_0
/*      */     //   1677: ldc_w '_t = ASTNULL;'
/*      */     //   1680: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1683: aload_0
/*      */     //   1684: dup
/*      */     //   1685: getfield tabs : I
/*      */     //   1688: iconst_1
/*      */     //   1689: isub
/*      */     //   1690: putfield tabs : I
/*      */     //   1693: aload_0
/*      */     //   1694: new java/lang/StringBuffer
/*      */     //   1697: dup
/*      */     //   1698: invokespecial <init> : ()V
/*      */     //   1701: ldc_w 'if '
/*      */     //   1704: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1707: aload #14
/*      */     //   1709: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1712: ldc_w ' {'
/*      */     //   1715: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1718: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1721: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1724: iinc #3, 1
/*      */     //   1727: aload_0
/*      */     //   1728: dup
/*      */     //   1729: getfield tabs : I
/*      */     //   1732: iconst_1
/*      */     //   1733: iadd
/*      */     //   1734: putfield tabs : I
/*      */     //   1737: aload_0
/*      */     //   1738: aload #13
/*      */     //   1740: aload_1
/*      */     //   1741: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   1744: aload_0
/*      */     //   1745: dup
/*      */     //   1746: getfield tabs : I
/*      */     //   1749: iconst_1
/*      */     //   1750: isub
/*      */     //   1751: putfield tabs : I
/*      */     //   1754: aload_0
/*      */     //   1755: ldc '}'
/*      */     //   1757: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1760: iinc #12, 1
/*      */     //   1763: goto -> 855
/*      */     //   1766: iinc #11, -1
/*      */     //   1769: goto -> 806
/*      */     //   1772: ldc ''
/*      */     //   1774: astore #11
/*      */     //   1776: iconst_1
/*      */     //   1777: istore #12
/*      */     //   1779: iload #12
/*      */     //   1781: iload #5
/*      */     //   1783: if_icmpgt -> 1824
/*      */     //   1786: aload_0
/*      */     //   1787: dup
/*      */     //   1788: getfield tabs : I
/*      */     //   1791: iconst_1
/*      */     //   1792: isub
/*      */     //   1793: putfield tabs : I
/*      */     //   1796: new java/lang/StringBuffer
/*      */     //   1799: dup
/*      */     //   1800: invokespecial <init> : ()V
/*      */     //   1803: aload #11
/*      */     //   1805: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1808: ldc '}'
/*      */     //   1810: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1813: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1816: astore #11
/*      */     //   1818: iinc #12, 1
/*      */     //   1821: goto -> 1779
/*      */     //   1824: aload_0
/*      */     //   1825: iload #7
/*      */     //   1827: putfield genAST : Z
/*      */     //   1830: aload_0
/*      */     //   1831: iload #8
/*      */     //   1833: putfield saveText : Z
/*      */     //   1836: iload #4
/*      */     //   1838: ifeq -> 1899
/*      */     //   1841: aload_0
/*      */     //   1842: dup
/*      */     //   1843: getfield tabs : I
/*      */     //   1846: iconst_1
/*      */     //   1847: isub
/*      */     //   1848: putfield tabs : I
/*      */     //   1851: aload #6
/*      */     //   1853: new java/lang/StringBuffer
/*      */     //   1856: dup
/*      */     //   1857: invokespecial <init> : ()V
/*      */     //   1860: aload #11
/*      */     //   1862: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1865: ldc '}'
/*      */     //   1867: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1870: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1873: putfield postscript : Ljava/lang/String;
/*      */     //   1876: aload #6
/*      */     //   1878: iconst_1
/*      */     //   1879: putfield generatedSwitch : Z
/*      */     //   1882: aload #6
/*      */     //   1884: iload_3
/*      */     //   1885: ifle -> 1892
/*      */     //   1888: iconst_1
/*      */     //   1889: goto -> 1893
/*      */     //   1892: iconst_0
/*      */     //   1893: putfield generatedAnIf : Z
/*      */     //   1896: goto -> 1926
/*      */     //   1899: aload #6
/*      */     //   1901: aload #11
/*      */     //   1903: putfield postscript : Ljava/lang/String;
/*      */     //   1906: aload #6
/*      */     //   1908: iconst_0
/*      */     //   1909: putfield generatedSwitch : Z
/*      */     //   1912: aload #6
/*      */     //   1914: iload_3
/*      */     //   1915: ifle -> 1922
/*      */     //   1918: iconst_1
/*      */     //   1919: goto -> 1923
/*      */     //   1922: iconst_0
/*      */     //   1923: putfield generatedAnIf : Z
/*      */     //   1926: aload #6
/*      */     //   1928: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1968	-> 0
/*      */     //   #1969	-> 2
/*      */     //   #1970	-> 5
/*      */     //   #1971	-> 8
/*      */     //   #1972	-> 17
/*      */     //   #1975	-> 62
/*      */     //   #1976	-> 68
/*      */     //   #1978	-> 91
/*      */     //   #1979	-> 97
/*      */     //   #1982	-> 120
/*      */     //   #1985	-> 147
/*      */     //   #1987	-> 160
/*      */     //   #1988	-> 174
/*      */     //   #1992	-> 212
/*      */     //   #1994	-> 217
/*      */     //   #1995	-> 221
/*      */     //   #1996	-> 231
/*      */     //   #1997	-> 238
/*      */     //   #1999	-> 271
/*      */     //   #2003	-> 276
/*      */     //   #2006	-> 321
/*      */     //   #2008	-> 331
/*      */     //   #2010	-> 338
/*      */     //   #2014	-> 341
/*      */     //   #2016	-> 352
/*      */     //   #2018	-> 359
/*      */     //   #2020	-> 367
/*      */     //   #2027	-> 406
/*      */     //   #2029	-> 410
/*      */     //   #2032	-> 418
/*      */     //   #2034	-> 431
/*      */     //   #2035	-> 438
/*      */     //   #2049	-> 441
/*      */     //   #2050	-> 444
/*      */     //   #2052	-> 459
/*      */     //   #2053	-> 467
/*      */     //   #2054	-> 475
/*      */     //   #2050	-> 478
/*      */     //   #2058	-> 484
/*      */     //   #2061	-> 493
/*      */     //   #2062	-> 500
/*      */     //   #2064	-> 503
/*      */     //   #2066	-> 513
/*      */     //   #2067	-> 545
/*      */     //   #2068	-> 555
/*      */     //   #2069	-> 562
/*      */     //   #2071	-> 572
/*      */     //   #2072	-> 603
/*      */     //   #2074	-> 618
/*      */     //   #2077	-> 626
/*      */     //   #2079	-> 634
/*      */     //   #2081	-> 637
/*      */     //   #2082	-> 646
/*      */     //   #2084	-> 665
/*      */     //   #2090	-> 701
/*      */     //   #2091	-> 710
/*      */     //   #2092	-> 716
/*      */     //   #2093	-> 726
/*      */     //   #2094	-> 733
/*      */     //   #2095	-> 740
/*      */     //   #2096	-> 750
/*      */     //   #2072	-> 756
/*      */     //   #2099	-> 762
/*      */     //   #2100	-> 769
/*      */     //   #2117	-> 779
/*      */     //   #2118	-> 802
/*      */     //   #2119	-> 811
/*      */     //   #2120	-> 852
/*      */     //   #2121	-> 867
/*      */     //   #2122	-> 875
/*      */     //   #2126	-> 916
/*      */     //   #2129	-> 929
/*      */     //   #2130	-> 943
/*      */     //   #2135	-> 955
/*      */     //   #2137	-> 958
/*      */     //   #2140	-> 968
/*      */     //   #2141	-> 975
/*      */     //   #2144	-> 982
/*      */     //   #2146	-> 991
/*      */     //   #2149	-> 1011
/*      */     //   #2153	-> 1017
/*      */     //   #2155	-> 1024
/*      */     //   #2156	-> 1038
/*      */     //   #2159	-> 1078
/*      */     //   #2160	-> 1088
/*      */     //   #2164	-> 1101
/*      */     //   #2165	-> 1116
/*      */     //   #2170	-> 1131
/*      */     //   #2173	-> 1157
/*      */     //   #2177	-> 1161
/*      */     //   #2178	-> 1171
/*      */     //   #2179	-> 1203
/*      */     //   #2180	-> 1213
/*      */     //   #2181	-> 1220
/*      */     //   #2183	-> 1230
/*      */     //   #2186	-> 1264
/*      */     //   #2188	-> 1298
/*      */     //   #2196	-> 1319
/*      */     //   #2197	-> 1323
/*      */     //   #2200	-> 1332
/*      */     //   #2202	-> 1339
/*      */     //   #2208	-> 1348
/*      */     //   #2212	-> 1356
/*      */     //   #2213	-> 1365
/*      */     //   #2221	-> 1386
/*      */     //   #2224	-> 1416
/*      */     //   #2227	-> 1482
/*      */     //   #2231	-> 1522
/*      */     //   #2232	-> 1526
/*      */     //   #2233	-> 1534
/*      */     //   #2234	-> 1541
/*      */     //   #2235	-> 1551
/*      */     //   #2236	-> 1562
/*      */     //   #2239	-> 1568
/*      */     //   #2243	-> 1602
/*      */     //   #2244	-> 1610
/*      */     //   #2249	-> 1624
/*      */     //   #2250	-> 1634
/*      */     //   #2251	-> 1666
/*      */     //   #2252	-> 1676
/*      */     //   #2253	-> 1683
/*      */     //   #2255	-> 1693
/*      */     //   #2261	-> 1724
/*      */     //   #2262	-> 1727
/*      */     //   #2263	-> 1737
/*      */     //   #2264	-> 1744
/*      */     //   #2265	-> 1754
/*      */     //   #2120	-> 1760
/*      */     //   #2118	-> 1766
/*      */     //   #2268	-> 1772
/*      */     //   #2269	-> 1776
/*      */     //   #2270	-> 1786
/*      */     //   #2271	-> 1796
/*      */     //   #2269	-> 1818
/*      */     //   #2275	-> 1824
/*      */     //   #2278	-> 1830
/*      */     //   #2281	-> 1836
/*      */     //   #2282	-> 1841
/*      */     //   #2283	-> 1851
/*      */     //   #2284	-> 1876
/*      */     //   #2285	-> 1882
/*      */     //   #2290	-> 1899
/*      */     //   #2291	-> 1906
/*      */     //   #2292	-> 1912
/*      */     //   #2295	-> 1926
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean suitableForCaseExpression(Alternative paramAlternative) {
/* 2299 */     return (paramAlternative.lookaheadDepth == 1 && paramAlternative.semPred == null && !paramAlternative.cache[1].containsEpsilon() && (paramAlternative.cache[1]).fset.degree() <= 127);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genElementAST(AlternativeElement paramAlternativeElement) {
/* 2311 */     if (this.grammar instanceof TreeWalkerGrammar && !this.grammar.buildAST) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2317 */       if (paramAlternativeElement.getLabel() == null) {
/*      */         
/* 2319 */         String str1 = this.lt1Value;
/*      */         
/* 2321 */         String str2 = "tmp" + this.astVarNumber + "_AST";
/* 2322 */         this.astVarNumber++;
/*      */         
/* 2324 */         mapTreeVariable(paramAlternativeElement, str2);
/*      */         
/* 2326 */         println(this.labeledElementASTType + " " + str2 + "_in = " + str1 + ";");
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/* 2331 */     if (this.grammar.buildAST && this.syntacticPredLevel == 0) {
/*      */       String str1, str2;
/* 2333 */       boolean bool1 = (this.genAST && (paramAlternativeElement.getLabel() != null || paramAlternativeElement.getAutoGenType() != 3)) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2341 */       if (paramAlternativeElement.getAutoGenType() != 3 && paramAlternativeElement instanceof TokenRefElement)
/*      */       {
/* 2343 */         bool1 = true;
/*      */       }
/* 2345 */       boolean bool2 = (this.grammar.hasSyntacticPredicate && bool1) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2352 */       if (paramAlternativeElement.getLabel() != null) {
/*      */ 
/*      */         
/* 2355 */         str1 = paramAlternativeElement.getLabel();
/* 2356 */         str2 = paramAlternativeElement.getLabel();
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2361 */         str1 = this.lt1Value;
/*      */         
/* 2363 */         str2 = "tmp" + this.astVarNumber;
/* 2364 */         this.astVarNumber++;
/*      */       } 
/*      */ 
/*      */       
/* 2368 */       if (bool1)
/*      */       {
/* 2370 */         if (paramAlternativeElement instanceof GrammarAtom) {
/*      */           
/* 2372 */           GrammarAtom grammarAtom = (GrammarAtom)paramAlternativeElement;
/* 2373 */           if (grammarAtom.getASTNodeType() != null)
/*      */           {
/* 2375 */             genASTDeclaration(paramAlternativeElement, str2, "Ref" + grammarAtom.getASTNodeType());
/*      */           
/*      */           }
/*      */           else
/*      */           {
/* 2380 */             genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 2386 */           genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2392 */       String str3 = str2 + "_AST";
/*      */ 
/*      */       
/* 2395 */       mapTreeVariable(paramAlternativeElement, str3);
/* 2396 */       if (this.grammar instanceof TreeWalkerGrammar)
/*      */       {
/*      */         
/* 2399 */         println(this.labeledElementASTType + " " + str3 + "_in = " + this.labeledElementASTInit + ";");
/*      */       }
/*      */ 
/*      */       
/* 2403 */       if (bool2) {
/* 2404 */         println("if ( inputState->guessing == 0 ) {");
/* 2405 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2410 */       if (paramAlternativeElement.getLabel() != null)
/*      */       {
/* 2412 */         if (paramAlternativeElement instanceof GrammarAtom) {
/*      */           
/* 2414 */           println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + ";");
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 2419 */           println(str3 + " = " + getASTCreateString(str1) + ";");
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2425 */       if (paramAlternativeElement.getLabel() == null && bool1) {
/*      */         
/* 2427 */         str1 = this.lt1Value;
/* 2428 */         if (paramAlternativeElement instanceof GrammarAtom) {
/*      */           
/* 2430 */           println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + ";");
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 2435 */           println(str3 + " = " + getASTCreateString(str1) + ";");
/*      */         } 
/*      */ 
/*      */         
/* 2439 */         if (this.grammar instanceof TreeWalkerGrammar)
/*      */         {
/*      */           
/* 2442 */           println(str3 + "_in = " + str1 + ";");
/*      */         }
/*      */       } 
/*      */       
/* 2446 */       if (this.genAST)
/*      */       {
/* 2448 */         switch (paramAlternativeElement.getAutoGenType()) {
/*      */           
/*      */           case 1:
/* 2451 */             if (this.usingCustomAST || (paramAlternativeElement instanceof GrammarAtom && ((GrammarAtom)paramAlternativeElement).getASTNodeType() != null)) {
/*      */ 
/*      */               
/* 2454 */               println("astFactory->addASTChild(currentAST, " + namespaceAntlr + "RefAST(" + str3 + "));"); break;
/*      */             } 
/* 2456 */             println("astFactory->addASTChild(currentAST, " + str3 + ");");
/*      */             break;
/*      */           
/*      */           case 2:
/* 2460 */             if (this.usingCustomAST || (paramAlternativeElement instanceof GrammarAtom && ((GrammarAtom)paramAlternativeElement).getASTNodeType() != null)) {
/*      */ 
/*      */               
/* 2463 */               println("astFactory->makeASTRoot(currentAST, " + namespaceAntlr + "RefAST(" + str3 + "));"); break;
/*      */             } 
/* 2465 */             println("astFactory->makeASTRoot(currentAST, " + str3 + ");");
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       }
/* 2471 */       if (bool2) {
/*      */         
/* 2473 */         this.tabs--;
/* 2474 */         println("}");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorCatchForElement(AlternativeElement paramAlternativeElement) {
/* 2482 */     if (paramAlternativeElement.getLabel() == null)
/* 2483 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2484 */     if (this.grammar instanceof LexerGrammar) {
/* 2485 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2487 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2488 */     if (ruleSymbol == null) {
/* 2489 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2491 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2492 */     if (exceptionSpec != null) {
/* 2493 */       this.tabs--;
/* 2494 */       println("}");
/* 2495 */       genErrorHandler(exceptionSpec);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorHandler(ExceptionSpec paramExceptionSpec) {
/* 2502 */     for (byte b = 0; b < paramExceptionSpec.handlers.size(); b++) {
/*      */       
/* 2504 */       ExceptionHandler exceptionHandler = (ExceptionHandler)paramExceptionSpec.handlers.elementAt(b);
/*      */       
/* 2506 */       println("catch (" + exceptionHandler.exceptionTypeAndName.getText() + ") {");
/* 2507 */       this.tabs++;
/* 2508 */       if (this.grammar.hasSyntacticPredicate) {
/* 2509 */         println("if (inputState->guessing==0) {");
/* 2510 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */       
/* 2514 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 2515 */       genLineNo(exceptionHandler.action);
/* 2516 */       printAction(processActionForSpecialSymbols(exceptionHandler.action.getText(), exceptionHandler.action.getLine(), this.currentRule, actionTransInfo));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2521 */       genLineNo2();
/*      */       
/* 2523 */       if (this.grammar.hasSyntacticPredicate) {
/*      */         
/* 2525 */         this.tabs--;
/* 2526 */         println("} else {");
/* 2527 */         this.tabs++;
/*      */         
/* 2529 */         println("throw;");
/* 2530 */         this.tabs--;
/* 2531 */         println("}");
/*      */       } 
/*      */       
/* 2534 */       this.tabs--;
/* 2535 */       println("}");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void genErrorTryForElement(AlternativeElement paramAlternativeElement) {
/* 2540 */     if (paramAlternativeElement.getLabel() == null)
/* 2541 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2542 */     if (this.grammar instanceof LexerGrammar) {
/* 2543 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2545 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2546 */     if (ruleSymbol == null) {
/* 2547 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2549 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2550 */     if (exceptionSpec != null) {
/* 2551 */       println("try { // for error handling");
/* 2552 */       this.tabs++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genHeader(String paramString) {
/* 2558 */     println("/* $ANTLR " + Tool.version + ": " + "\"" + this.antlrTool.fileMinusPath(this.antlrTool.grammarFile) + "\"" + " -> " + "\"" + paramString + "\"$ */");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genInclude(LexerGrammar paramLexerGrammar) throws IOException {
/* 2567 */     this.outputFile = this.grammar.getClassName() + ".hpp";
/* 2568 */     this.outputLine = 1;
/* 2569 */     this.currentOutput = this.antlrTool.openOutputFile(this.outputFile);
/*      */ 
/*      */     
/* 2572 */     this.genAST = false;
/* 2573 */     this.saveText = true;
/*      */     
/* 2575 */     this.tabs = 0;
/*      */ 
/*      */     
/* 2578 */     println("#ifndef INC_" + this.grammar.getClassName() + "_hpp_");
/* 2579 */     println("#define INC_" + this.grammar.getClassName() + "_hpp_");
/* 2580 */     println("");
/*      */     
/* 2582 */     printHeaderAction("pre_include_hpp");
/*      */     
/* 2584 */     println("#include <antlr/config.hpp>");
/*      */ 
/*      */     
/* 2587 */     genHeader(this.outputFile);
/*      */ 
/*      */     
/* 2590 */     println("#include <antlr/CommonToken.hpp>");
/* 2591 */     println("#include <antlr/InputBuffer.hpp>");
/* 2592 */     println("#include <antlr/BitSet.hpp>");
/* 2593 */     println("#include \"" + this.grammar.tokenManager.getName() + TokenTypesFileSuffix + ".hpp\"");
/*      */ 
/*      */     
/* 2596 */     String str = null;
/* 2597 */     if (this.grammar.superClass != null) {
/* 2598 */       str = this.grammar.superClass;
/*      */       
/* 2600 */       println("\n// Include correct superclass header with a header statement for example:");
/* 2601 */       println("// header \"post_include_hpp\" {");
/* 2602 */       println("// #include \"" + str + ".hpp\"");
/* 2603 */       println("// }");
/* 2604 */       println("// Or....");
/* 2605 */       println("// header {");
/* 2606 */       println("// #include \"" + str + ".hpp\"");
/* 2607 */       println("// }\n");
/*      */     } else {
/*      */       
/* 2610 */       str = this.grammar.getSuperClass();
/* 2611 */       if (str.lastIndexOf('.') != -1)
/* 2612 */         str = str.substring(str.lastIndexOf('.') + 1); 
/* 2613 */       println("#include <antlr/" + str + ".hpp>");
/* 2614 */       str = namespaceAntlr + str;
/*      */     } 
/*      */ 
/*      */     
/* 2618 */     printHeaderAction("post_include_hpp");
/*      */     
/* 2620 */     if (nameSpace != null) {
/* 2621 */       nameSpace.emitDeclarations(this.currentOutput);
/*      */     }
/* 2623 */     printHeaderAction("");
/*      */ 
/*      */     
/* 2626 */     if (this.grammar.comment != null) {
/* 2627 */       _println(this.grammar.comment);
/*      */     }
/*      */ 
/*      */     
/* 2631 */     print("class CUSTOM_API " + this.grammar.getClassName() + " : public " + str);
/* 2632 */     println(", public " + this.grammar.tokenManager.getName() + TokenTypesFileSuffix);
/*      */     
/* 2634 */     Token token = (Token)this.grammar.options.get("classHeaderSuffix");
/* 2635 */     if (token != null) {
/* 2636 */       String str1 = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 2637 */       if (str1 != null) {
/* 2638 */         print(", " + str1);
/*      */       }
/*      */     } 
/* 2641 */     println("{");
/*      */ 
/*      */     
/* 2644 */     if (this.grammar.classMemberAction != null) {
/* 2645 */       genLineNo(this.grammar.classMemberAction);
/* 2646 */       print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2651 */       genLineNo2();
/*      */     } 
/*      */ 
/*      */     
/* 2655 */     this.tabs = 0;
/* 2656 */     println("private:");
/* 2657 */     this.tabs = 1;
/* 2658 */     println("void initLiterals();");
/*      */ 
/*      */     
/* 2661 */     this.tabs = 0;
/* 2662 */     println("public:");
/* 2663 */     this.tabs = 1;
/* 2664 */     println("bool getCaseSensitiveLiterals() const");
/* 2665 */     println("{");
/* 2666 */     this.tabs++;
/* 2667 */     println("return " + paramLexerGrammar.caseSensitiveLiterals + ";");
/* 2668 */     this.tabs--;
/* 2669 */     println("}");
/*      */ 
/*      */     
/* 2672 */     this.tabs = 0;
/* 2673 */     println("public:");
/* 2674 */     this.tabs = 1;
/*      */     
/* 2676 */     if (this.noConstructors) {
/*      */       
/* 2678 */       this.tabs = 0;
/* 2679 */       println("#if 0");
/* 2680 */       println("// constructor creation turned of with 'noConstructor' option");
/* 2681 */       this.tabs = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2685 */     println(this.grammar.getClassName() + "(" + namespaceStd + "istream& in);");
/*      */ 
/*      */     
/* 2688 */     println(this.grammar.getClassName() + "(" + namespaceAntlr + "InputBuffer& ib);");
/*      */     
/* 2690 */     println(this.grammar.getClassName() + "(const " + namespaceAntlr + "LexerSharedInputState& state);");
/* 2691 */     if (this.noConstructors) {
/*      */       
/* 2693 */       this.tabs = 0;
/* 2694 */       println("// constructor creation turned of with 'noConstructor' option");
/* 2695 */       println("#endif");
/* 2696 */       this.tabs = 1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2702 */     println(namespaceAntlr + "RefToken nextToken();");
/*      */ 
/*      */     
/* 2705 */     Enumeration enumeration = this.grammar.rules.elements();
/* 2706 */     while (enumeration.hasMoreElements()) {
/* 2707 */       RuleSymbol ruleSymbol = enumeration.nextElement();
/*      */       
/* 2709 */       if (!ruleSymbol.getId().equals("mnextToken")) {
/* 2710 */         genRuleHeader(ruleSymbol, false);
/*      */       }
/* 2712 */       exitIfError();
/*      */     } 
/*      */ 
/*      */     
/* 2716 */     this.tabs = 0;
/* 2717 */     println("private:");
/* 2718 */     this.tabs = 1;
/*      */ 
/*      */     
/* 2721 */     if (this.grammar.debuggingOutput) {
/* 2722 */       println("static const char* _ruleNames[];");
/*      */     }
/*      */ 
/*      */     
/* 2726 */     if (this.grammar.debuggingOutput) {
/* 2727 */       println("static const char* _semPredNames[];");
/*      */     }
/*      */     
/* 2730 */     genBitsetsHeader(this.bitsetsUsed, ((LexerGrammar)this.grammar).charVocabulary.size());
/*      */     
/* 2732 */     this.tabs = 0;
/* 2733 */     println("};");
/* 2734 */     println("");
/* 2735 */     if (nameSpace != null) {
/* 2736 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 2739 */     println("#endif /*INC_" + this.grammar.getClassName() + "_hpp_*/");
/*      */ 
/*      */     
/* 2742 */     this.currentOutput.close();
/* 2743 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void genInclude(ParserGrammar paramParserGrammar) throws IOException {
/* 2748 */     this.outputFile = this.grammar.getClassName() + ".hpp";
/* 2749 */     this.outputLine = 1;
/* 2750 */     this.currentOutput = this.antlrTool.openOutputFile(this.outputFile);
/*      */ 
/*      */     
/* 2753 */     this.genAST = this.grammar.buildAST;
/*      */     
/* 2755 */     this.tabs = 0;
/*      */ 
/*      */     
/* 2758 */     println("#ifndef INC_" + this.grammar.getClassName() + "_hpp_");
/* 2759 */     println("#define INC_" + this.grammar.getClassName() + "_hpp_");
/* 2760 */     println("");
/* 2761 */     printHeaderAction("pre_include_hpp");
/* 2762 */     println("#include <antlr/config.hpp>");
/*      */ 
/*      */     
/* 2765 */     genHeader(this.outputFile);
/*      */ 
/*      */     
/* 2768 */     println("#include <antlr/TokenStream.hpp>");
/* 2769 */     println("#include <antlr/TokenBuffer.hpp>");
/* 2770 */     println("#include \"" + this.grammar.tokenManager.getName() + TokenTypesFileSuffix + ".hpp\"");
/*      */ 
/*      */     
/* 2773 */     String str = null;
/* 2774 */     if (this.grammar.superClass != null) {
/* 2775 */       str = this.grammar.superClass;
/* 2776 */       println("\n// Include correct superclass header with a header statement for example:");
/* 2777 */       println("// header \"post_include_hpp\" {");
/* 2778 */       println("// #include \"" + str + ".hpp\"");
/* 2779 */       println("// }");
/* 2780 */       println("// Or....");
/* 2781 */       println("// header {");
/* 2782 */       println("// #include \"" + str + ".hpp\"");
/* 2783 */       println("// }\n");
/*      */     } else {
/*      */       
/* 2786 */       str = this.grammar.getSuperClass();
/* 2787 */       if (str.lastIndexOf('.') != -1)
/* 2788 */         str = str.substring(str.lastIndexOf('.') + 1); 
/* 2789 */       println("#include <antlr/" + str + ".hpp>");
/* 2790 */       str = namespaceAntlr + str;
/*      */     } 
/* 2792 */     println("");
/*      */ 
/*      */     
/* 2795 */     printHeaderAction("post_include_hpp");
/*      */     
/* 2797 */     if (nameSpace != null) {
/* 2798 */       nameSpace.emitDeclarations(this.currentOutput);
/*      */     }
/* 2800 */     printHeaderAction("");
/*      */ 
/*      */     
/* 2803 */     if (this.grammar.comment != null) {
/* 2804 */       _println(this.grammar.comment);
/*      */     }
/*      */ 
/*      */     
/* 2808 */     print("class CUSTOM_API " + this.grammar.getClassName() + " : public " + str);
/* 2809 */     println(", public " + this.grammar.tokenManager.getName() + TokenTypesFileSuffix);
/*      */     
/* 2811 */     Token token = (Token)this.grammar.options.get("classHeaderSuffix");
/* 2812 */     if (token != null) {
/* 2813 */       String str1 = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 2814 */       if (str1 != null)
/* 2815 */         print(", " + str1); 
/*      */     } 
/* 2817 */     println("{");
/*      */ 
/*      */ 
/*      */     
/* 2821 */     if (this.grammar.debuggingOutput) {
/* 2822 */       println("public: static const char* _ruleNames[];");
/*      */     }
/*      */     
/* 2825 */     if (this.grammar.classMemberAction != null) {
/* 2826 */       genLineNo(this.grammar.classMemberAction.getLine());
/* 2827 */       print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2832 */       genLineNo2();
/*      */     } 
/* 2834 */     println("public:");
/* 2835 */     this.tabs = 1;
/* 2836 */     println("void initializeASTFactory( " + namespaceAntlr + "ASTFactory& factory );");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2841 */     this.tabs = 0;
/* 2842 */     if (this.noConstructors) {
/*      */       
/* 2844 */       println("#if 0");
/* 2845 */       println("// constructor creation turned of with 'noConstructor' option");
/*      */     } 
/* 2847 */     println("protected:");
/* 2848 */     this.tabs = 1;
/* 2849 */     println(this.grammar.getClassName() + "(" + namespaceAntlr + "TokenBuffer& tokenBuf, int k);");
/* 2850 */     this.tabs = 0;
/* 2851 */     println("public:");
/* 2852 */     this.tabs = 1;
/* 2853 */     println(this.grammar.getClassName() + "(" + namespaceAntlr + "TokenBuffer& tokenBuf);");
/*      */ 
/*      */     
/* 2856 */     this.tabs = 0;
/* 2857 */     println("protected:");
/* 2858 */     this.tabs = 1;
/* 2859 */     println(this.grammar.getClassName() + "(" + namespaceAntlr + "TokenStream& lexer, int k);");
/* 2860 */     this.tabs = 0;
/* 2861 */     println("public:");
/* 2862 */     this.tabs = 1;
/* 2863 */     println(this.grammar.getClassName() + "(" + namespaceAntlr + "TokenStream& lexer);");
/*      */     
/* 2865 */     println(this.grammar.getClassName() + "(const " + namespaceAntlr + "ParserSharedInputState& state);");
/* 2866 */     if (this.noConstructors) {
/*      */       
/* 2868 */       this.tabs = 0;
/* 2869 */       println("// constructor creation turned of with 'noConstructor' option");
/* 2870 */       println("#endif");
/* 2871 */       this.tabs = 1;
/*      */     } 
/*      */     
/* 2874 */     println("int getNumTokens() const");
/* 2875 */     println("{"); this.tabs++;
/* 2876 */     println("return " + this.grammar.getClassName() + "::NUM_TOKENS;");
/* 2877 */     this.tabs--; println("}");
/* 2878 */     println("const char* getTokenName( int type ) const");
/* 2879 */     println("{"); this.tabs++;
/* 2880 */     println("if( type > getNumTokens() ) return 0;");
/* 2881 */     println("return " + this.grammar.getClassName() + "::tokenNames[type];");
/* 2882 */     this.tabs--; println("}");
/* 2883 */     println("const char* const* getTokenNames() const");
/* 2884 */     println("{"); this.tabs++;
/* 2885 */     println("return " + this.grammar.getClassName() + "::tokenNames;");
/* 2886 */     this.tabs--; println("}");
/*      */ 
/*      */     
/* 2889 */     Enumeration enumeration = this.grammar.rules.elements();
/* 2890 */     while (enumeration.hasMoreElements()) {
/* 2891 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 2892 */       if (grammarSymbol instanceof RuleSymbol) {
/* 2893 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 2894 */         genRuleHeader(ruleSymbol, (ruleSymbol.references.size() == 0));
/*      */       } 
/* 2896 */       exitIfError();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2904 */     this.tabs = 0; println("public:"); this.tabs = 1;
/* 2905 */     println(namespaceAntlr + "RefAST getAST()");
/* 2906 */     println("{");
/* 2907 */     if (this.usingCustomAST) {
/*      */       
/* 2909 */       this.tabs++;
/* 2910 */       println("return " + namespaceAntlr + "RefAST(returnAST);");
/* 2911 */       this.tabs--;
/*      */     }
/*      */     else {
/*      */       
/* 2915 */       this.tabs++;
/* 2916 */       println("return returnAST;");
/* 2917 */       this.tabs--;
/*      */     } 
/* 2919 */     println("}");
/* 2920 */     println("");
/*      */     
/* 2922 */     this.tabs = 0; println("protected:"); this.tabs = 1;
/* 2923 */     println(this.labeledElementASTType + " returnAST;");
/*      */ 
/*      */     
/* 2926 */     this.tabs = 0;
/* 2927 */     println("private:");
/* 2928 */     this.tabs = 1;
/*      */ 
/*      */     
/* 2931 */     println("static const char* tokenNames[];");
/*      */     
/* 2933 */     _println("#ifndef NO_STATIC_CONSTS");
/* 2934 */     println("static const int NUM_TOKENS = " + this.grammar.tokenManager.getVocabulary().size() + ";");
/* 2935 */     _println("#else");
/* 2936 */     println("enum {");
/* 2937 */     println("\tNUM_TOKENS = " + this.grammar.tokenManager.getVocabulary().size());
/* 2938 */     println("};");
/* 2939 */     _println("#endif");
/*      */ 
/*      */     
/* 2942 */     genBitsetsHeader(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */ 
/*      */     
/* 2945 */     if (this.grammar.debuggingOutput) {
/* 2946 */       println("static const char* _semPredNames[];");
/*      */     }
/*      */     
/* 2949 */     this.tabs = 0;
/* 2950 */     println("};");
/* 2951 */     println("");
/* 2952 */     if (nameSpace != null) {
/* 2953 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 2956 */     println("#endif /*INC_" + this.grammar.getClassName() + "_hpp_*/");
/*      */ 
/*      */     
/* 2959 */     this.currentOutput.close();
/* 2960 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void genInclude(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/* 2965 */     this.outputFile = this.grammar.getClassName() + ".hpp";
/* 2966 */     this.outputLine = 1;
/* 2967 */     this.currentOutput = this.antlrTool.openOutputFile(this.outputFile);
/*      */ 
/*      */     
/* 2970 */     this.genAST = this.grammar.buildAST;
/* 2971 */     this.tabs = 0;
/*      */ 
/*      */     
/* 2974 */     println("#ifndef INC_" + this.grammar.getClassName() + "_hpp_");
/* 2975 */     println("#define INC_" + this.grammar.getClassName() + "_hpp_");
/* 2976 */     println("");
/* 2977 */     printHeaderAction("pre_include_hpp");
/* 2978 */     println("#include <antlr/config.hpp>");
/* 2979 */     println("#include \"" + this.grammar.tokenManager.getName() + TokenTypesFileSuffix + ".hpp\"");
/*      */ 
/*      */     
/* 2982 */     genHeader(this.outputFile);
/*      */ 
/*      */     
/* 2985 */     String str1 = null;
/* 2986 */     if (this.grammar.superClass != null) {
/* 2987 */       str1 = this.grammar.superClass;
/* 2988 */       println("\n// Include correct superclass header with a header statement for example:");
/* 2989 */       println("// header \"post_include_hpp\" {");
/* 2990 */       println("// #include \"" + str1 + ".hpp\"");
/* 2991 */       println("// }");
/* 2992 */       println("// Or....");
/* 2993 */       println("// header {");
/* 2994 */       println("// #include \"" + str1 + ".hpp\"");
/* 2995 */       println("// }\n");
/*      */     } else {
/*      */       
/* 2998 */       str1 = this.grammar.getSuperClass();
/* 2999 */       if (str1.lastIndexOf('.') != -1)
/* 3000 */         str1 = str1.substring(str1.lastIndexOf('.') + 1); 
/* 3001 */       println("#include <antlr/" + str1 + ".hpp>");
/* 3002 */       str1 = namespaceAntlr + str1;
/*      */     } 
/* 3004 */     println("");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3009 */     printHeaderAction("post_include_hpp");
/*      */     
/* 3011 */     if (nameSpace != null) {
/* 3012 */       nameSpace.emitDeclarations(this.currentOutput);
/*      */     }
/* 3014 */     printHeaderAction("");
/*      */ 
/*      */     
/* 3017 */     if (this.grammar.comment != null) {
/* 3018 */       _println(this.grammar.comment);
/*      */     }
/*      */ 
/*      */     
/* 3022 */     print("class CUSTOM_API " + this.grammar.getClassName() + " : public " + str1);
/* 3023 */     println(", public " + this.grammar.tokenManager.getName() + TokenTypesFileSuffix);
/*      */     
/* 3025 */     Token token = (Token)this.grammar.options.get("classHeaderSuffix");
/* 3026 */     if (token != null) {
/* 3027 */       String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3028 */       if (str != null) {
/* 3029 */         print(", " + str);
/*      */       }
/*      */     } 
/* 3032 */     println("{");
/*      */ 
/*      */     
/* 3035 */     if (this.grammar.classMemberAction != null) {
/* 3036 */       genLineNo(this.grammar.classMemberAction.getLine());
/* 3037 */       print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3042 */       genLineNo2();
/*      */     } 
/*      */ 
/*      */     
/* 3046 */     this.tabs = 0;
/* 3047 */     println("public:");
/*      */     
/* 3049 */     if (this.noConstructors) {
/*      */       
/* 3051 */       println("#if 0");
/* 3052 */       println("// constructor creation turned of with 'noConstructor' option");
/*      */     } 
/* 3054 */     this.tabs = 1;
/* 3055 */     println(this.grammar.getClassName() + "();");
/* 3056 */     if (this.noConstructors) {
/*      */       
/* 3058 */       this.tabs = 0;
/* 3059 */       println("#endif");
/* 3060 */       this.tabs = 1;
/*      */     } 
/*      */ 
/*      */     
/* 3064 */     println("static void initializeASTFactory( " + namespaceAntlr + "ASTFactory& factory );");
/*      */     
/* 3066 */     println("int getNumTokens() const");
/* 3067 */     println("{"); this.tabs++;
/* 3068 */     println("return " + this.grammar.getClassName() + "::NUM_TOKENS;");
/* 3069 */     this.tabs--; println("}");
/* 3070 */     println("const char* getTokenName( int type ) const");
/* 3071 */     println("{"); this.tabs++;
/* 3072 */     println("if( type > getNumTokens() ) return 0;");
/* 3073 */     println("return " + this.grammar.getClassName() + "::tokenNames[type];");
/* 3074 */     this.tabs--; println("}");
/* 3075 */     println("const char* const* getTokenNames() const");
/* 3076 */     println("{"); this.tabs++;
/* 3077 */     println("return " + this.grammar.getClassName() + "::tokenNames;");
/* 3078 */     this.tabs--; println("}");
/*      */ 
/*      */     
/* 3081 */     Enumeration enumeration = this.grammar.rules.elements();
/* 3082 */     String str2 = "";
/* 3083 */     while (enumeration.hasMoreElements()) {
/* 3084 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 3085 */       if (grammarSymbol instanceof RuleSymbol) {
/* 3086 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 3087 */         genRuleHeader(ruleSymbol, (ruleSymbol.references.size() == 0));
/*      */       } 
/* 3089 */       exitIfError();
/*      */     } 
/* 3091 */     this.tabs = 0; println("public:"); this.tabs = 1;
/* 3092 */     println(namespaceAntlr + "RefAST getAST()");
/* 3093 */     println("{");
/* 3094 */     if (this.usingCustomAST) {
/*      */       
/* 3096 */       this.tabs++;
/* 3097 */       println("return " + namespaceAntlr + "RefAST(returnAST);");
/* 3098 */       this.tabs--;
/*      */     }
/*      */     else {
/*      */       
/* 3102 */       this.tabs++;
/* 3103 */       println("return returnAST;");
/* 3104 */       this.tabs--;
/*      */     } 
/* 3106 */     println("}");
/* 3107 */     println("");
/*      */     
/* 3109 */     this.tabs = 0; println("protected:"); this.tabs = 1;
/* 3110 */     println(this.labeledElementASTType + " returnAST;");
/* 3111 */     println(this.labeledElementASTType + " _retTree;");
/*      */ 
/*      */     
/* 3114 */     this.tabs = 0;
/* 3115 */     println("private:");
/* 3116 */     this.tabs = 1;
/*      */ 
/*      */     
/* 3119 */     println("static const char* tokenNames[];");
/*      */     
/* 3121 */     _println("#ifndef NO_STATIC_CONSTS");
/* 3122 */     println("static const int NUM_TOKENS = " + this.grammar.tokenManager.getVocabulary().size() + ";");
/* 3123 */     _println("#else");
/* 3124 */     println("enum {");
/* 3125 */     println("\tNUM_TOKENS = " + this.grammar.tokenManager.getVocabulary().size());
/* 3126 */     println("};");
/* 3127 */     _println("#endif");
/*      */ 
/*      */     
/* 3130 */     genBitsetsHeader(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */ 
/*      */     
/* 3133 */     this.tabs = 0;
/* 3134 */     println("};");
/* 3135 */     println("");
/* 3136 */     if (nameSpace != null) {
/* 3137 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 3140 */     println("#endif /*INC_" + this.grammar.getClassName() + "_hpp_*/");
/*      */ 
/*      */     
/* 3143 */     this.currentOutput.close();
/* 3144 */     this.currentOutput = null;
/*      */   }
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement) {
/* 3148 */     genASTDeclaration(paramAlternativeElement, this.labeledElementASTType);
/*      */   }
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString) {
/* 3152 */     genASTDeclaration(paramAlternativeElement, paramAlternativeElement.getLabel(), paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString1, String paramString2) {
/* 3157 */     if (this.declaredASTVariables.contains(paramAlternativeElement)) {
/*      */       return;
/*      */     }
/* 3160 */     String str = this.labeledElementASTInit;
/*      */     
/* 3162 */     if (paramAlternativeElement instanceof GrammarAtom && ((GrammarAtom)paramAlternativeElement).getASTNodeType() != null)
/*      */     {
/* 3164 */       str = "Ref" + ((GrammarAtom)paramAlternativeElement).getASTNodeType() + "(" + this.labeledElementASTInit + ")";
/*      */     }
/*      */     
/* 3167 */     println(paramString2 + " " + paramString1 + "_AST = " + str + ";");
/*      */ 
/*      */     
/* 3170 */     this.declaredASTVariables.put(paramAlternativeElement, paramAlternativeElement);
/*      */   }
/*      */   private void genLiteralsTest() {
/* 3173 */     println("_ttype = testLiteralsTable(_ttype);");
/*      */   }
/*      */   private void genLiteralsTestForPartialToken() {
/* 3176 */     println("_ttype = testLiteralsTable(text.substr(_begin, text.length()-_begin),_ttype);");
/*      */   }
/*      */   protected void genMatch(BitSet paramBitSet) {}
/*      */   
/*      */   protected void genMatch(GrammarAtom paramGrammarAtom) {
/* 3181 */     if (paramGrammarAtom instanceof StringLiteralElement) {
/* 3182 */       if (this.grammar instanceof LexerGrammar) {
/* 3183 */         genMatchUsingAtomText(paramGrammarAtom);
/*      */       } else {
/*      */         
/* 3186 */         genMatchUsingAtomTokenType(paramGrammarAtom);
/*      */       }
/*      */     
/* 3189 */     } else if (paramGrammarAtom instanceof CharLiteralElement) {
/*      */       
/* 3191 */       this.antlrTool.error("cannot ref character literals in grammar: " + paramGrammarAtom);
/*      */     }
/* 3193 */     else if (paramGrammarAtom instanceof TokenRefElement) {
/* 3194 */       genMatchUsingAtomTokenType(paramGrammarAtom);
/* 3195 */     } else if (paramGrammarAtom instanceof WildcardElement) {
/* 3196 */       gen((WildcardElement)paramGrammarAtom);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void genMatchUsingAtomText(GrammarAtom paramGrammarAtom) {
/* 3201 */     String str = "";
/* 3202 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3203 */       if (this.usingCustomAST) {
/* 3204 */         str = namespaceAntlr + "RefAST" + "(_t),";
/*      */       } else {
/* 3206 */         str = "_t,";
/*      */       } 
/*      */     }
/*      */     
/* 3210 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3)) {
/* 3211 */       println("_saveIndex = text.length();");
/*      */     }
/*      */     
/* 3214 */     print(paramGrammarAtom.not ? "matchNot(" : "match(");
/* 3215 */     _print(str);
/*      */ 
/*      */     
/* 3218 */     if (paramGrammarAtom.atomText.equals("EOF")) {
/*      */       
/* 3220 */       _print(namespaceAntlr + "Token::EOF_TYPE");
/*      */ 
/*      */     
/*      */     }
/* 3224 */     else if (this.grammar instanceof LexerGrammar) {
/*      */       
/* 3226 */       String str1 = convertJavaToCppString(paramGrammarAtom.atomText, false);
/* 3227 */       _print(str1);
/*      */     } else {
/*      */       
/* 3230 */       _print(paramGrammarAtom.atomText);
/*      */     } 
/*      */     
/* 3233 */     _println(");");
/*      */     
/* 3235 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3)) {
/* 3236 */       println("text.erase(_saveIndex);");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void genMatchUsingAtomTokenType(GrammarAtom paramGrammarAtom) {
/* 3241 */     String str1 = "";
/* 3242 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3243 */       if (this.usingCustomAST) {
/* 3244 */         str1 = namespaceAntlr + "RefAST" + "(_t),";
/*      */       } else {
/* 3246 */         str1 = "_t,";
/*      */       } 
/*      */     }
/*      */     
/* 3250 */     String str2 = str1 + getValueString(paramGrammarAtom.getType());
/*      */ 
/*      */     
/* 3253 */     println((paramGrammarAtom.not ? "matchNot(" : "match(") + str2 + ");");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genNextToken() {
/* 3263 */     boolean bool = false;
/* 3264 */     for (byte b1 = 0; b1 < this.grammar.rules.size(); b1++) {
/* 3265 */       RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.rules.elementAt(b1);
/* 3266 */       if (ruleSymbol1.isDefined() && ruleSymbol1.access.equals("public")) {
/* 3267 */         bool = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 3271 */     if (!bool) {
/* 3272 */       println("");
/* 3273 */       println(namespaceAntlr + "RefToken " + this.grammar.getClassName() + "::nextToken() { return " + namespaceAntlr + "RefToken(new " + namespaceAntlr + "CommonToken(" + namespaceAntlr + "Token::EOF_TYPE, \"\")); }");
/* 3274 */       println("");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3279 */     RuleBlock ruleBlock = MakeGrammar.createNextTokenRule(this.grammar, this.grammar.rules, "nextToken");
/*      */     
/* 3281 */     RuleSymbol ruleSymbol = new RuleSymbol("mnextToken");
/* 3282 */     ruleSymbol.setDefined();
/* 3283 */     ruleSymbol.setBlock(ruleBlock);
/* 3284 */     ruleSymbol.access = "private";
/* 3285 */     this.grammar.define(ruleSymbol);
/*      */     
/* 3287 */     boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */ 
/*      */     
/* 3290 */     String str1 = null;
/* 3291 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 3292 */       str1 = ((LexerGrammar)this.grammar).filterRule;
/*      */     }
/*      */     
/* 3295 */     println("");
/* 3296 */     println(namespaceAntlr + "RefToken " + this.grammar.getClassName() + "::nextToken()");
/* 3297 */     println("{");
/* 3298 */     this.tabs++;
/* 3299 */     println(namespaceAntlr + "RefToken theRetToken;");
/* 3300 */     println("for (;;) {");
/* 3301 */     this.tabs++;
/* 3302 */     println(namespaceAntlr + "RefToken theRetToken;");
/* 3303 */     println("int _ttype = " + namespaceAntlr + "Token::INVALID_TYPE;");
/* 3304 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 3305 */       println("setCommitToPath(false);");
/* 3306 */       if (str1 != null) {
/*      */         
/* 3308 */         if (!this.grammar.isDefined(CodeGenerator.encodeLexerRuleName(str1))) {
/* 3309 */           this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */         } else {
/*      */           
/* 3312 */           RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.getSymbol(CodeGenerator.encodeLexerRuleName(str1));
/* 3313 */           if (!ruleSymbol1.isDefined()) {
/* 3314 */             this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */           }
/* 3316 */           else if (ruleSymbol1.access.equals("public")) {
/* 3317 */             this.grammar.antlrTool.error("Filter rule " + str1 + " must be protected");
/*      */           } 
/*      */         } 
/* 3320 */         println("int _m;");
/* 3321 */         println("_m = mark();");
/*      */       } 
/*      */     } 
/* 3324 */     println("resetText();");
/*      */ 
/*      */     
/* 3327 */     println("try {   // for lexical and char stream error handling");
/* 3328 */     this.tabs++;
/*      */ 
/*      */     
/* 3331 */     for (byte b2 = 0; b2 < ruleBlock.getAlternatives().size(); b2++) {
/* 3332 */       Alternative alternative = ruleBlock.getAlternativeAt(b2);
/* 3333 */       if (alternative.cache[1].containsEpsilon()) {
/* 3334 */         this.antlrTool.warning("found optional path in nextToken()");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3339 */     String str2 = System.getProperty("line.separator");
/* 3340 */     CppBlockFinishingInfo cppBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/* 3341 */     String str3 = "if (LA(1)==EOF_CHAR)" + str2 + "\t\t\t\t{" + str2 + "\t\t\t\t\tuponEOF();" + str2 + "\t\t\t\t\t_returnToken = makeToken(" + namespaceAntlr + "Token::EOF_TYPE);" + str2 + "\t\t\t\t}";
/*      */ 
/*      */ 
/*      */     
/* 3345 */     str3 = str3 + str2 + "\t\t\t\t";
/* 3346 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 3347 */       if (str1 == null) {
/* 3348 */         str3 = str3 + "else {consume(); goto tryAgain;}";
/*      */       } else {
/*      */         
/* 3351 */         str3 = str3 + "else {" + str2 + "\t\t\t\t\tcommit();" + str2 + "\t\t\t\t\ttry {m" + str1 + "(false);}" + str2 + "\t\t\t\t\tcatch(" + namespaceAntlr + "RecognitionException& e) {" + str2 + "\t\t\t\t\t\t// catastrophic failure" + str2 + "\t\t\t\t\t\treportError(e);" + str2 + "\t\t\t\t\t\tconsume();" + str2 + "\t\t\t\t\t}" + str2 + "\t\t\t\t\tgoto tryAgain;" + str2 + "\t\t\t\t}";
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 3364 */       str3 = str3 + "else {" + this.throwNoViable + "}";
/*      */     } 
/* 3366 */     genBlockFinish(cppBlockFinishingInfo, str3);
/*      */ 
/*      */     
/* 3369 */     if (((LexerGrammar)this.grammar).filterMode && str1 != null) {
/* 3370 */       println("commit();");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3376 */     println("if ( !_returnToken )" + str2 + "\t\t\t\tgoto tryAgain; // found SKIP token" + str2);
/*      */     
/* 3378 */     println("_ttype = _returnToken->getType();");
/* 3379 */     if (((LexerGrammar)this.grammar).getTestLiterals()) {
/* 3380 */       genLiteralsTest();
/*      */     }
/*      */ 
/*      */     
/* 3384 */     println("_returnToken->setType(_ttype);");
/* 3385 */     println("return _returnToken;");
/*      */ 
/*      */     
/* 3388 */     this.tabs--;
/* 3389 */     println("}");
/* 3390 */     println("catch (" + namespaceAntlr + "RecognitionException& e) {");
/* 3391 */     this.tabs++;
/* 3392 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 3393 */       if (str1 == null) {
/* 3394 */         println("if ( !getCommitToPath() ) {");
/* 3395 */         this.tabs++;
/* 3396 */         println("consume();");
/* 3397 */         println("goto tryAgain;");
/* 3398 */         this.tabs--;
/* 3399 */         println("}");
/*      */       } else {
/*      */         
/* 3402 */         println("if ( !getCommitToPath() ) {");
/* 3403 */         this.tabs++;
/* 3404 */         println("rewind(_m);");
/* 3405 */         println("resetText();");
/* 3406 */         println("try {m" + str1 + "(false);}");
/* 3407 */         println("catch(" + namespaceAntlr + "RecognitionException& ee) {");
/* 3408 */         println("\t// horrendous failure: error in filter rule");
/* 3409 */         println("\treportError(ee);");
/* 3410 */         println("\tconsume();");
/* 3411 */         println("}");
/*      */         
/* 3413 */         this.tabs--;
/* 3414 */         println("}");
/* 3415 */         println("else");
/*      */       } 
/*      */     }
/* 3418 */     if (ruleBlock.getDefaultErrorHandler()) {
/* 3419 */       println("{");
/* 3420 */       this.tabs++;
/* 3421 */       println("reportError(e);");
/* 3422 */       println("consume();");
/* 3423 */       this.tabs--;
/* 3424 */       println("}");
/*      */     }
/*      */     else {
/*      */       
/* 3428 */       this.tabs++;
/* 3429 */       println("throw " + namespaceAntlr + "TokenStreamRecognitionException(e);");
/* 3430 */       this.tabs--;
/*      */     } 
/*      */ 
/*      */     
/* 3434 */     this.tabs--;
/* 3435 */     println("}");
/* 3436 */     println("catch (" + namespaceAntlr + "CharStreamIOException& csie) {");
/* 3437 */     println("\tthrow " + namespaceAntlr + "TokenStreamIOException(csie.io);");
/* 3438 */     println("}");
/* 3439 */     println("catch (" + namespaceAntlr + "CharStreamException& cse) {");
/* 3440 */     println("\tthrow " + namespaceAntlr + "TokenStreamException(cse.getMessage());");
/* 3441 */     println("}");
/*      */ 
/*      */     
/* 3444 */     _println("tryAgain:;");
/* 3445 */     this.tabs--;
/* 3446 */     println("}");
/*      */ 
/*      */     
/* 3449 */     this.tabs--;
/* 3450 */     println("}");
/* 3451 */     println("");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genRule(RuleSymbol paramRuleSymbol, boolean paramBoolean, int paramInt, String paramString) {
/* 3471 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genRule(" + paramRuleSymbol.getId() + ")"); 
/* 3472 */     if (!paramRuleSymbol.isDefined()) {
/* 3473 */       this.antlrTool.error("undefined rule: " + paramRuleSymbol.getId());
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3478 */     RuleBlock ruleBlock = paramRuleSymbol.getBlock();
/*      */     
/* 3480 */     this.currentRule = ruleBlock;
/* 3481 */     this.currentASTResult = paramRuleSymbol.getId();
/*      */ 
/*      */     
/* 3484 */     this.declaredASTVariables.clear();
/*      */ 
/*      */     
/* 3487 */     boolean bool = this.genAST;
/* 3488 */     this.genAST = (this.genAST && ruleBlock.getAutoGen());
/*      */ 
/*      */     
/* 3491 */     this.saveText = ruleBlock.getAutoGen();
/*      */ 
/*      */     
/* 3494 */     if (paramRuleSymbol.comment != null) {
/* 3495 */       _println(paramRuleSymbol.comment);
/*      */     }
/*      */ 
/*      */     
/* 3499 */     if (ruleBlock.returnAction != null) {
/*      */ 
/*      */       
/* 3502 */       _print(extractTypeOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + " ");
/*      */     } else {
/*      */       
/* 3505 */       _print("void ");
/*      */     } 
/*      */ 
/*      */     
/* 3509 */     _print(paramString + paramRuleSymbol.getId() + "(");
/*      */ 
/*      */     
/* 3512 */     _print(this.commonExtraParams);
/* 3513 */     if (this.commonExtraParams.length() != 0 && ruleBlock.argAction != null) {
/* 3514 */       _print(",");
/*      */     }
/*      */ 
/*      */     
/* 3518 */     if (ruleBlock.argAction != null) {
/*      */ 
/*      */       
/* 3521 */       _println("");
/*      */ 
/*      */       
/* 3524 */       this.tabs++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3534 */       String str1 = ruleBlock.argAction;
/* 3535 */       String str2 = "";
/*      */       
/* 3537 */       String str3 = "";
/* 3538 */       int i = str1.indexOf('=');
/* 3539 */       if (i != -1) {
/*      */         
/* 3541 */         int j = 0;
/* 3542 */         while (j != -1 && i != -1) {
/*      */           
/* 3544 */           str2 = str2 + str3 + str1.substring(0, i).trim();
/* 3545 */           str3 = ", ";
/* 3546 */           j = str1.indexOf(',', i);
/* 3547 */           if (j != -1) {
/*      */ 
/*      */             
/* 3550 */             str1 = str1.substring(j + 1).trim();
/* 3551 */             i = str1.indexOf('=');
/* 3552 */             if (i == -1) {
/* 3553 */               str2 = str2 + str3 + str1;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } else {
/* 3558 */         str2 = str1;
/*      */       } 
/* 3560 */       println(str2);
/*      */ 
/*      */       
/* 3563 */       this.tabs--;
/* 3564 */       print(") ");
/*      */     }
/*      */     else {
/*      */       
/* 3568 */       _print(") ");
/*      */     } 
/* 3570 */     _println("{");
/* 3571 */     this.tabs++;
/*      */     
/* 3573 */     if (this.grammar.traceRules) {
/* 3574 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 3575 */         if (this.usingCustomAST) {
/* 3576 */           println("Tracer traceInOut(this,\"" + paramRuleSymbol.getId() + "\"," + namespaceAntlr + "RefAST" + "(_t));");
/*      */         } else {
/* 3578 */           println("Tracer traceInOut(this,\"" + paramRuleSymbol.getId() + "\",_t);");
/*      */         } 
/*      */       } else {
/* 3581 */         println("Tracer traceInOut(this, \"" + paramRuleSymbol.getId() + "\");");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3586 */     if (ruleBlock.returnAction != null) {
/*      */       
/* 3588 */       genLineNo(ruleBlock);
/* 3589 */       println(ruleBlock.returnAction + ";");
/* 3590 */       genLineNo2();
/*      */     } 
/*      */ 
/*      */     
/* 3594 */     if (!this.commonLocalVars.equals("")) {
/* 3595 */       println(this.commonLocalVars);
/*      */     }
/* 3597 */     if (this.grammar instanceof LexerGrammar) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3602 */       if (paramRuleSymbol.getId().equals("mEOF")) {
/* 3603 */         println("_ttype = " + namespaceAntlr + "Token::EOF_TYPE;");
/*      */       } else {
/* 3605 */         println("_ttype = " + paramRuleSymbol.getId().substring(1) + ";");
/* 3606 */       }  println(namespaceStd + "string::size_type _saveIndex;");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3616 */     if (this.grammar.debuggingOutput) {
/* 3617 */       if (this.grammar instanceof ParserGrammar) {
/* 3618 */         println("fireEnterRule(" + paramInt + ",0);");
/* 3619 */       } else if (this.grammar instanceof LexerGrammar) {
/* 3620 */         println("fireEnterRule(" + paramInt + ",_ttype);");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3629 */     if (this.grammar instanceof TreeWalkerGrammar)
/*      */     {
/*      */       
/* 3632 */       println(this.labeledElementASTType + " " + paramRuleSymbol.getId() + "_AST_in = (_t == " + this.labeledElementASTType + "(ASTNULL)) ? " + this.labeledElementASTInit + " : _t;");
/*      */     }
/* 3634 */     if (this.grammar.buildAST) {
/*      */       
/* 3636 */       println("returnAST = " + this.labeledElementASTInit + ";");
/*      */       
/* 3638 */       println(namespaceAntlr + "ASTPair currentAST;");
/*      */       
/* 3640 */       println(this.labeledElementASTType + " " + paramRuleSymbol.getId() + "_AST = " + this.labeledElementASTInit + ";");
/*      */     } 
/*      */     
/* 3643 */     genBlockPreamble(ruleBlock);
/* 3644 */     genBlockInitAction(ruleBlock);
/* 3645 */     println("");
/*      */ 
/*      */     
/* 3648 */     ExceptionSpec exceptionSpec = ruleBlock.findExceptionSpec("");
/*      */ 
/*      */     
/* 3651 */     if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/* 3652 */       println("try {      // for error handling");
/* 3653 */       this.tabs++;
/*      */     } 
/*      */ 
/*      */     
/* 3657 */     if (ruleBlock.alternatives.size() == 1) {
/*      */ 
/*      */       
/* 3660 */       Alternative alternative = ruleBlock.getAlternativeAt(0);
/* 3661 */       String str = alternative.semPred;
/* 3662 */       if (str != null)
/* 3663 */         genSemPred(str, this.currentRule.line); 
/* 3664 */       if (alternative.synPred != null) {
/* 3665 */         this.antlrTool.warning("Syntactic predicate ignored for single alternative", this.grammar.getFilename(), alternative.synPred.getLine(), alternative.synPred.getColumn());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3672 */       genAlt(alternative, ruleBlock);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3677 */       boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */       
/* 3679 */       CppBlockFinishingInfo cppBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/* 3680 */       genBlockFinish(cppBlockFinishingInfo, this.throwNoViable);
/*      */     } 
/*      */ 
/*      */     
/* 3684 */     if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/*      */       
/* 3686 */       this.tabs--;
/* 3687 */       println("}");
/*      */     } 
/*      */ 
/*      */     
/* 3691 */     if (exceptionSpec != null) {
/*      */       
/* 3693 */       genErrorHandler(exceptionSpec);
/*      */     }
/* 3695 */     else if (ruleBlock.getDefaultErrorHandler()) {
/*      */ 
/*      */       
/* 3698 */       println("catch (" + this.exceptionThrown + "& ex) {");
/* 3699 */       this.tabs++;
/*      */       
/* 3701 */       if (this.grammar.hasSyntacticPredicate) {
/* 3702 */         println("if( inputState->guessing == 0 ) {");
/* 3703 */         this.tabs++;
/*      */       } 
/* 3705 */       println("reportError(ex);");
/* 3706 */       if (!(this.grammar instanceof TreeWalkerGrammar)) {
/*      */ 
/*      */         
/* 3709 */         Lookahead lookahead = this.grammar.theLLkAnalyzer.FOLLOW(1, ruleBlock.endNode);
/* 3710 */         String str = getBitsetName(markBitsetForGen(lookahead.fset));
/* 3711 */         println("recover(ex," + str + ");");
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 3716 */         println("if ( _t != " + this.labeledElementASTInit + " )");
/* 3717 */         this.tabs++;
/* 3718 */         println("_t = _t->getNextSibling();");
/* 3719 */         this.tabs--;
/*      */       } 
/* 3721 */       if (this.grammar.hasSyntacticPredicate) {
/*      */         
/* 3723 */         this.tabs--;
/*      */         
/* 3725 */         println("} else {");
/* 3726 */         this.tabs++;
/* 3727 */         println("throw;");
/* 3728 */         this.tabs--;
/* 3729 */         println("}");
/*      */       } 
/*      */       
/* 3732 */       this.tabs--;
/* 3733 */       println("}");
/*      */     } 
/*      */ 
/*      */     
/* 3737 */     if (this.grammar.buildAST) {
/* 3738 */       println("returnAST = " + paramRuleSymbol.getId() + "_AST;");
/*      */     }
/*      */ 
/*      */     
/* 3742 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3743 */       println("_retTree = _t;");
/*      */     }
/*      */ 
/*      */     
/* 3747 */     if (ruleBlock.getTestLiterals()) {
/* 3748 */       if (paramRuleSymbol.access.equals("protected")) {
/* 3749 */         genLiteralsTestForPartialToken();
/*      */       } else {
/*      */         
/* 3752 */         genLiteralsTest();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3757 */     if (this.grammar instanceof LexerGrammar) {
/* 3758 */       println("if ( _createToken && _token==" + namespaceAntlr + "nullToken && _ttype!=" + namespaceAntlr + "Token::SKIP ) {");
/* 3759 */       println("   _token = makeToken(_ttype);");
/* 3760 */       println("   _token->setText(text.substr(_begin, text.length()-_begin));");
/* 3761 */       println("}");
/* 3762 */       println("_returnToken = _token;");
/*      */ 
/*      */       
/* 3765 */       println("_saveIndex=0;");
/*      */     } 
/*      */ 
/*      */     
/* 3769 */     if (ruleBlock.returnAction != null) {
/* 3770 */       println("return " + extractIdOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + ";");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3798 */     this.tabs--;
/* 3799 */     println("}");
/* 3800 */     println("");
/*      */ 
/*      */     
/* 3803 */     this.genAST = bool;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void genRuleHeader(RuleSymbol paramRuleSymbol, boolean paramBoolean) {
/* 3809 */     this.tabs = 1;
/* 3810 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("genRuleHeader(" + paramRuleSymbol.getId() + ")"); 
/* 3811 */     if (!paramRuleSymbol.isDefined()) {
/* 3812 */       this.antlrTool.error("undefined rule: " + paramRuleSymbol.getId());
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3817 */     RuleBlock ruleBlock = paramRuleSymbol.getBlock();
/* 3818 */     this.currentRule = ruleBlock;
/* 3819 */     this.currentASTResult = paramRuleSymbol.getId();
/*      */ 
/*      */     
/* 3822 */     boolean bool = this.genAST;
/* 3823 */     this.genAST = (this.genAST && ruleBlock.getAutoGen());
/*      */ 
/*      */     
/* 3826 */     this.saveText = ruleBlock.getAutoGen();
/*      */ 
/*      */     
/* 3829 */     print(paramRuleSymbol.access + ": ");
/*      */ 
/*      */     
/* 3832 */     if (ruleBlock.returnAction != null) {
/*      */ 
/*      */       
/* 3835 */       _print(extractTypeOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + " ");
/*      */     } else {
/*      */       
/* 3838 */       _print("void ");
/*      */     } 
/*      */ 
/*      */     
/* 3842 */     _print(paramRuleSymbol.getId() + "(");
/*      */ 
/*      */     
/* 3845 */     _print(this.commonExtraParams);
/* 3846 */     if (this.commonExtraParams.length() != 0 && ruleBlock.argAction != null) {
/* 3847 */       _print(",");
/*      */     }
/*      */ 
/*      */     
/* 3851 */     if (ruleBlock.argAction != null) {
/*      */ 
/*      */       
/* 3854 */       _println("");
/* 3855 */       this.tabs++;
/* 3856 */       println(ruleBlock.argAction);
/* 3857 */       this.tabs--;
/* 3858 */       print(")");
/*      */     } else {
/*      */       
/* 3861 */       _print(")");
/*      */     } 
/* 3863 */     _println(";");
/*      */     
/* 3865 */     this.tabs--;
/*      */ 
/*      */     
/* 3868 */     this.genAST = bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void GenRuleInvocation(RuleRefElement paramRuleRefElement) {
/* 3875 */     _print(paramRuleRefElement.targetRule + "(");
/*      */ 
/*      */     
/* 3878 */     if (this.grammar instanceof LexerGrammar) {
/*      */       
/* 3880 */       if (paramRuleRefElement.getLabel() != null) {
/* 3881 */         _print("true");
/*      */       } else {
/*      */         
/* 3884 */         _print("false");
/*      */       } 
/* 3886 */       if (this.commonExtraArgs.length() != 0 || paramRuleRefElement.args != null) {
/* 3887 */         _print(",");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3892 */     _print(this.commonExtraArgs);
/* 3893 */     if (this.commonExtraArgs.length() != 0 && paramRuleRefElement.args != null) {
/* 3894 */       _print(",");
/*      */     }
/*      */ 
/*      */     
/* 3898 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/* 3899 */     if (paramRuleRefElement.args != null) {
/*      */ 
/*      */       
/* 3902 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/*      */ 
/*      */       
/* 3905 */       String str = processActionForSpecialSymbols(paramRuleRefElement.args, paramRuleRefElement.line, this.currentRule, actionTransInfo);
/*      */       
/* 3907 */       if (actionTransInfo.assignToRoot || actionTransInfo.refRuleRoot != null)
/*      */       {
/* 3909 */         this.antlrTool.error("Arguments of rule reference '" + paramRuleRefElement.targetRule + "' cannot set or ref #" + this.currentRule.getRuleName() + " on line " + paramRuleRefElement.getLine());
/*      */       }
/*      */       
/* 3912 */       _print(str);
/*      */ 
/*      */       
/* 3915 */       if (ruleSymbol.block.argAction == null)
/*      */       {
/* 3917 */         this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' accepts no arguments", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3930 */     _println(");");
/*      */ 
/*      */     
/* 3933 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3934 */       println("_t = _retTree;");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void genSemPred(String paramString, int paramInt) {
/* 3939 */     ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 3940 */     paramString = processActionForSpecialSymbols(paramString, paramInt, this.currentRule, actionTransInfo);
/*      */     
/* 3942 */     String str = this.charFormatter.escapeString(paramString);
/*      */ 
/*      */ 
/*      */     
/* 3946 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar))
/*      */     {
/* 3948 */       paramString = "fireSemanticPredicateEvaluated(antlr.debug.SemanticPredicateEvent.VALIDATING," + addSemPred(str) + "," + paramString + ")";
/*      */     }
/* 3950 */     println("if (!(" + paramString + "))");
/* 3951 */     this.tabs++;
/* 3952 */     println("throw " + namespaceAntlr + "SemanticException(\"" + str + "\");");
/* 3953 */     this.tabs--;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genSemPredMap(String paramString) {
/* 3959 */     Enumeration enumeration = this.semPreds.elements();
/* 3960 */     println("const char* " + paramString + "_semPredNames[] = {");
/* 3961 */     this.tabs++;
/* 3962 */     while (enumeration.hasMoreElements())
/* 3963 */       println("\"" + enumeration.nextElement() + "\","); 
/* 3964 */     println("0");
/* 3965 */     this.tabs--;
/* 3966 */     println("};");
/*      */   }
/*      */   protected void genSynPred(SynPredBlock paramSynPredBlock, String paramString) {
/* 3969 */     if (this.DEBUG_CODE_GENERATOR || this.DEBUG_CPP_CODE_GENERATOR) System.out.println("gen=>(" + paramSynPredBlock + ")");
/*      */ 
/*      */     
/* 3972 */     println("bool synPredMatched" + paramSynPredBlock.ID + " = false;");
/*      */     
/* 3974 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3975 */       println("if (_t == " + this.labeledElementASTInit + " )");
/* 3976 */       this.tabs++;
/* 3977 */       println("_t = ASTNULL;");
/* 3978 */       this.tabs--;
/*      */     } 
/*      */ 
/*      */     
/* 3982 */     println("if (" + paramString + ") {");
/* 3983 */     this.tabs++;
/*      */ 
/*      */     
/* 3986 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3987 */       println(this.labeledElementType + " __t" + paramSynPredBlock.ID + " = _t;");
/*      */     } else {
/*      */       
/* 3990 */       println("int _m" + paramSynPredBlock.ID + " = mark();");
/*      */     } 
/*      */ 
/*      */     
/* 3994 */     println("synPredMatched" + paramSynPredBlock.ID + " = true;");
/* 3995 */     println("inputState->guessing++;");
/*      */ 
/*      */     
/* 3998 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar))
/*      */     {
/* 4000 */       println("fireSyntacticPredicateStarted();");
/*      */     }
/*      */     
/* 4003 */     this.syntacticPredLevel++;
/* 4004 */     println("try {");
/* 4005 */     this.tabs++;
/* 4006 */     gen(paramSynPredBlock);
/* 4007 */     this.tabs--;
/*      */     
/* 4009 */     println("}");
/* 4010 */     println("catch (" + this.exceptionThrown + "& pe) {");
/* 4011 */     this.tabs++;
/* 4012 */     println("synPredMatched" + paramSynPredBlock.ID + " = false;");
/*      */     
/* 4014 */     this.tabs--;
/* 4015 */     println("}");
/*      */ 
/*      */     
/* 4018 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 4019 */       println("_t = __t" + paramSynPredBlock.ID + ";");
/*      */     } else {
/*      */       
/* 4022 */       println("rewind(_m" + paramSynPredBlock.ID + ");");
/*      */     } 
/*      */     
/* 4025 */     println("inputState->guessing--;");
/*      */ 
/*      */     
/* 4028 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar)) {
/*      */       
/* 4030 */       println("if (synPredMatched" + paramSynPredBlock.ID + ")");
/* 4031 */       println("  fireSyntacticPredicateSucceeded();");
/* 4032 */       println("else");
/* 4033 */       println("  fireSyntacticPredicateFailed();");
/*      */     } 
/*      */     
/* 4036 */     this.syntacticPredLevel--;
/* 4037 */     this.tabs--;
/*      */ 
/*      */     
/* 4040 */     println("}");
/*      */ 
/*      */     
/* 4043 */     println("if ( synPredMatched" + paramSynPredBlock.ID + " ) {");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genTokenStrings(String paramString) {
/* 4057 */     println("const char* " + paramString + "tokenNames[] = {");
/* 4058 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 4062 */     Vector vector = this.grammar.tokenManager.getVocabulary();
/* 4063 */     for (byte b = 0; b < vector.size(); b++) {
/*      */       
/* 4065 */       String str = (String)vector.elementAt(b);
/* 4066 */       if (str == null)
/*      */       {
/* 4068 */         str = "<" + String.valueOf(b) + ">";
/*      */       }
/* 4070 */       if (!str.startsWith("\"") && !str.startsWith("<")) {
/* 4071 */         TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 4072 */         if (tokenSymbol != null && tokenSymbol.getParaphrase() != null) {
/* 4073 */           str = StringUtils.stripFrontBack(tokenSymbol.getParaphrase(), "\"", "\"");
/*      */         }
/*      */       } 
/* 4076 */       print(this.charFormatter.literalString(str));
/* 4077 */       _println(",");
/*      */     } 
/* 4079 */     println("0");
/*      */ 
/*      */     
/* 4082 */     this.tabs--;
/* 4083 */     println("};");
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genTokenTypes(TokenManager paramTokenManager) throws IOException {
/* 4088 */     this.outputFile = paramTokenManager.getName() + TokenTypesFileSuffix + ".hpp";
/* 4089 */     this.outputLine = 1;
/* 4090 */     this.currentOutput = this.antlrTool.openOutputFile(this.outputFile);
/*      */ 
/*      */     
/* 4093 */     this.tabs = 0;
/*      */ 
/*      */     
/* 4096 */     println("#ifndef INC_" + paramTokenManager.getName() + TokenTypesFileSuffix + "_hpp_");
/* 4097 */     println("#define INC_" + paramTokenManager.getName() + TokenTypesFileSuffix + "_hpp_");
/* 4098 */     println("");
/*      */     
/* 4100 */     if (nameSpace != null) {
/* 4101 */       nameSpace.emitDeclarations(this.currentOutput);
/*      */     }
/*      */     
/* 4104 */     genHeader(this.outputFile);
/*      */ 
/*      */ 
/*      */     
/* 4108 */     println("");
/* 4109 */     println("#ifndef CUSTOM_API");
/* 4110 */     println("# define CUSTOM_API");
/* 4111 */     println("#endif");
/* 4112 */     println("");
/*      */ 
/*      */     
/* 4115 */     println("#ifdef __cplusplus");
/* 4116 */     println("struct CUSTOM_API " + paramTokenManager.getName() + TokenTypesFileSuffix + " {");
/* 4117 */     println("#endif");
/* 4118 */     this.tabs++;
/* 4119 */     println("enum {");
/* 4120 */     this.tabs++;
/*      */ 
/*      */     
/* 4123 */     Vector vector = paramTokenManager.getVocabulary();
/*      */ 
/*      */     
/* 4126 */     println("EOF_ = 1,");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4131 */     for (byte b = 4; b < vector.size(); b++) {
/* 4132 */       String str = (String)vector.elementAt(b);
/* 4133 */       if (str != null) {
/* 4134 */         if (str.startsWith("\"")) {
/*      */           
/* 4136 */           StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)paramTokenManager.getTokenSymbol(str);
/* 4137 */           if (stringLiteralSymbol == null) {
/* 4138 */             this.antlrTool.panic("String literal " + str + " not in symbol table");
/*      */           }
/* 4140 */           else if (stringLiteralSymbol.label != null) {
/* 4141 */             println(stringLiteralSymbol.label + " = " + b + ",");
/*      */           } else {
/*      */             
/* 4144 */             String str1 = mangleLiteral(str);
/* 4145 */             if (str1 != null) {
/*      */               
/* 4147 */               println(str1 + " = " + b + ",");
/*      */               
/* 4149 */               stringLiteralSymbol.label = str1;
/*      */             } else {
/*      */               
/* 4152 */               println("// " + str + " = " + b);
/*      */             }
/*      */           
/*      */           } 
/* 4156 */         } else if (!str.startsWith("<")) {
/* 4157 */           println(str + " = " + b + ",");
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 4163 */     println("NULL_TREE_LOOKAHEAD = 3");
/*      */ 
/*      */     
/* 4166 */     this.tabs--;
/* 4167 */     println("};");
/*      */ 
/*      */     
/* 4170 */     this.tabs--;
/* 4171 */     println("#ifdef __cplusplus");
/* 4172 */     println("};");
/* 4173 */     println("#endif");
/*      */     
/* 4175 */     if (nameSpace != null) {
/* 4176 */       nameSpace.emitClosures(this.currentOutput);
/*      */     }
/*      */     
/* 4179 */     println("#endif /*INC_" + paramTokenManager.getName() + TokenTypesFileSuffix + "_hpp_*/");
/*      */ 
/*      */     
/* 4182 */     this.currentOutput.close();
/* 4183 */     this.currentOutput = null;
/* 4184 */     exitIfError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String processStringForASTConstructor(String paramString) {
/* 4194 */     if (this.usingCustomAST && (this.grammar instanceof TreeWalkerGrammar || this.grammar instanceof ParserGrammar) && !this.grammar.tokenManager.tokenDefined(paramString))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4200 */       return namespaceAntlr + "RefAST(" + paramString + ")";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4205 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(Vector paramVector) {
/* 4213 */     if (paramVector.size() == 0) {
/* 4214 */       return "";
/*      */     }
/* 4216 */     StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */     
/* 4219 */     stringBuffer.append(this.labeledElementASTType + "(astFactory->make((new " + namespaceAntlr + "ASTArray(" + paramVector.size() + "))");
/*      */ 
/*      */     
/* 4222 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 4223 */       stringBuffer.append("->add(" + paramVector.elementAt(b) + ")");
/*      */     }
/* 4225 */     stringBuffer.append("))");
/* 4226 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(GrammarAtom paramGrammarAtom, String paramString) {
/* 4232 */     if (paramGrammarAtom != null && paramGrammarAtom.getASTNodeType() != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4238 */       this.astTypes.ensureCapacity(paramGrammarAtom.getType());
/* 4239 */       String str = (String)this.astTypes.elementAt(paramGrammarAtom.getType());
/* 4240 */       if (str == null) {
/* 4241 */         this.astTypes.setElementAt(paramGrammarAtom.getASTNodeType(), paramGrammarAtom.getType());
/*      */ 
/*      */       
/*      */       }
/* 4245 */       else if (!paramGrammarAtom.getASTNodeType().equals(str)) {
/*      */         
/* 4247 */         this.antlrTool.warning("Attempt to redefine AST type for " + paramGrammarAtom.getText(), this.grammar.getFilename(), paramGrammarAtom.getLine(), paramGrammarAtom.getColumn());
/* 4248 */         this.antlrTool.warning(" from \"" + str + "\" to \"" + paramGrammarAtom.getASTNodeType() + "\" sticking to \"" + str + "\"", this.grammar.getFilename(), paramGrammarAtom.getLine(), paramGrammarAtom.getColumn());
/*      */       } else {
/*      */         
/* 4251 */         this.astTypes.setElementAt(paramGrammarAtom.getASTNodeType(), paramGrammarAtom.getType());
/*      */       } 
/*      */       
/* 4254 */       return "astFactory->create(" + paramString + ")";
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4262 */     boolean bool = false;
/* 4263 */     if (paramString.indexOf(',') != -1) {
/* 4264 */       bool = this.grammar.tokenManager.tokenDefined(paramString.substring(0, paramString.indexOf(',')));
/*      */     }
/*      */     
/* 4267 */     if (this.usingCustomAST && this.grammar instanceof TreeWalkerGrammar && !this.grammar.tokenManager.tokenDefined(paramString) && !bool)
/*      */     {
/*      */ 
/*      */       
/* 4271 */       return "astFactory->create(" + namespaceAntlr + "RefAST(" + paramString + "))";
/*      */     }
/* 4273 */     return "astFactory->create(" + paramString + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(String paramString) {
/* 4282 */     if (this.usingCustomAST) {
/* 4283 */       return this.labeledElementASTType + "(astFactory->create(" + namespaceAntlr + "RefAST(" + paramString + ")))";
/*      */     }
/* 4285 */     return "astFactory->create(" + paramString + ")";
/*      */   }
/*      */   
/*      */   protected String getLookaheadTestExpression(Lookahead[] paramArrayOfLookahead, int paramInt) {
/* 4289 */     StringBuffer stringBuffer = new StringBuffer(100);
/* 4290 */     boolean bool = true;
/*      */     
/* 4292 */     stringBuffer.append("(");
/* 4293 */     for (byte b = 1; b <= paramInt; b++) {
/* 4294 */       BitSet bitSet = (paramArrayOfLookahead[b]).fset;
/* 4295 */       if (!bool) {
/* 4296 */         stringBuffer.append(") && (");
/*      */       }
/* 4298 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4303 */       if (paramArrayOfLookahead[b].containsEpsilon()) {
/* 4304 */         stringBuffer.append("true");
/*      */       } else {
/* 4306 */         stringBuffer.append(getLookaheadTestTerm(b, bitSet));
/*      */       } 
/*      */     } 
/* 4309 */     stringBuffer.append(")");
/*      */     
/* 4311 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestExpression(Alternative paramAlternative, int paramInt) {
/* 4318 */     int i = paramAlternative.lookaheadDepth;
/* 4319 */     if (i == Integer.MAX_VALUE)
/*      */     {
/*      */       
/* 4322 */       i = this.grammar.maxk;
/*      */     }
/*      */     
/* 4325 */     if (paramInt == 0)
/*      */     {
/*      */       
/* 4328 */       return "true";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4354 */     return "(" + getLookaheadTestExpression(paramAlternative.cache, i) + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestTerm(int paramInt, BitSet paramBitSet) {
/* 4366 */     String str = lookaheadString(paramInt);
/*      */ 
/*      */     
/* 4369 */     int[] arrayOfInt = paramBitSet.toArray();
/* 4370 */     if (elementsAreRange(arrayOfInt)) {
/* 4371 */       return getRangeExpression(paramInt, arrayOfInt);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4376 */     int i = paramBitSet.degree();
/* 4377 */     if (i == 0) {
/* 4378 */       return "true";
/*      */     }
/*      */     
/* 4381 */     if (i >= this.bitsetTestThreshold) {
/* 4382 */       int j = markBitsetForGen(paramBitSet);
/* 4383 */       return getBitsetName(j) + ".member(" + str + ")";
/*      */     } 
/*      */ 
/*      */     
/* 4387 */     StringBuffer stringBuffer = new StringBuffer();
/* 4388 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/* 4390 */       String str1 = getValueString(arrayOfInt[b]);
/*      */ 
/*      */       
/* 4393 */       if (b > 0) stringBuffer.append(" || "); 
/* 4394 */       stringBuffer.append(str);
/* 4395 */       stringBuffer.append(" == ");
/* 4396 */       stringBuffer.append(str1);
/*      */     } 
/* 4398 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRangeExpression(int paramInt, int[] paramArrayOfint) {
/* 4406 */     if (!elementsAreRange(paramArrayOfint)) {
/* 4407 */       this.antlrTool.panic("getRangeExpression called with non-range");
/*      */     }
/* 4409 */     int i = paramArrayOfint[0];
/* 4410 */     int j = paramArrayOfint[paramArrayOfint.length - 1];
/* 4411 */     return "(" + lookaheadString(paramInt) + " >= " + getValueString(i) + " && " + lookaheadString(paramInt) + " <= " + getValueString(j) + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getValueString(int paramInt) {
/*      */     String str;
/* 4420 */     if (this.grammar instanceof LexerGrammar) {
/* 4421 */       str = this.charFormatter.literalChar(paramInt);
/*      */     }
/*      */     else {
/*      */       
/* 4425 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbolAt(paramInt);
/* 4426 */       if (tokenSymbol == null) {
/* 4427 */         return "" + paramInt;
/*      */       }
/*      */       
/* 4430 */       String str1 = tokenSymbol.getId();
/* 4431 */       if (tokenSymbol instanceof StringLiteralSymbol) {
/*      */ 
/*      */ 
/*      */         
/* 4435 */         StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/* 4436 */         String str2 = stringLiteralSymbol.getLabel();
/* 4437 */         if (str2 != null) {
/* 4438 */           str = str2;
/*      */         } else {
/*      */           
/* 4441 */           str = mangleLiteral(str1);
/* 4442 */           if (str == null) {
/* 4443 */             str = String.valueOf(paramInt);
/*      */           }
/*      */         }
/*      */       
/*      */       }
/* 4448 */       else if (str1.equals("EOF")) {
/* 4449 */         str = namespaceAntlr + "Token::EOF_TYPE";
/*      */       } else {
/* 4451 */         str = str1;
/*      */       } 
/*      */     } 
/* 4454 */     return str;
/*      */   }
/*      */   
/*      */   protected boolean lookaheadIsEmpty(Alternative paramAlternative, int paramInt) {
/* 4458 */     int i = paramAlternative.lookaheadDepth;
/* 4459 */     if (i == Integer.MAX_VALUE) {
/* 4460 */       i = this.grammar.maxk;
/*      */     }
/* 4462 */     for (byte b = 1; b <= i && b <= paramInt; b++) {
/* 4463 */       BitSet bitSet = (paramAlternative.cache[b]).fset;
/* 4464 */       if (bitSet.degree() != 0) {
/* 4465 */         return false;
/*      */       }
/*      */     } 
/* 4468 */     return true;
/*      */   }
/*      */   private String lookaheadString(int paramInt) {
/* 4471 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 4472 */       return "_t->getType()";
/*      */     }
/* 4474 */     return "LA(" + paramInt + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String mangleLiteral(String paramString) {
/* 4483 */     String str = this.antlrTool.literalsPrefix;
/* 4484 */     for (byte b = 1; b < paramString.length() - 1; b++) {
/* 4485 */       if (!Character.isLetter(paramString.charAt(b)) && paramString.charAt(b) != '_')
/*      */       {
/* 4487 */         return null;
/*      */       }
/* 4489 */       str = str + paramString.charAt(b);
/*      */     } 
/* 4491 */     if (this.antlrTool.upperCaseMangledLiterals) {
/* 4492 */       str = str.toUpperCase();
/*      */     }
/* 4494 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String mapTreeId(String paramString, ActionTransInfo paramActionTransInfo) {
/* 4504 */     if (this.currentRule == null) return paramString;
/*      */ 
/*      */     
/* 4507 */     boolean bool = false;
/* 4508 */     String str1 = paramString;
/* 4509 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4514 */       if (!this.grammar.buildAST)
/*      */       {
/* 4516 */         bool = true;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4521 */       if (str1.length() > 3 && str1.lastIndexOf("_in") == str1.length() - 3) {
/*      */ 
/*      */         
/* 4524 */         str1 = str1.substring(0, str1.length() - 3);
/* 4525 */         bool = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4533 */     for (byte b = 0; b < this.currentRule.labeledElements.size(); b++) {
/*      */       
/* 4535 */       AlternativeElement alternativeElement = (AlternativeElement)this.currentRule.labeledElements.elementAt(b);
/* 4536 */       if (alternativeElement.getLabel().equals(str1))
/*      */       {
/*      */ 
/*      */         
/* 4540 */         return bool ? str1 : (str1 + "_AST");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4547 */     String str2 = (String)this.treeVariableMap.get(str1);
/* 4548 */     if (str2 != null) {
/*      */       
/* 4550 */       if (str2 == NONUNIQUE) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4555 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */         
/* 4557 */         return null;
/*      */       } 
/* 4559 */       if (str2.equals(this.currentRule.getRuleName())) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4565 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */         
/* 4567 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4573 */       return bool ? (str2 + "_in") : str2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4580 */     if (str1.equals(this.currentRule.getRuleName())) {
/*      */       
/* 4582 */       String str = bool ? (str1 + "_AST_in") : (str1 + "_AST");
/* 4583 */       if (paramActionTransInfo != null && 
/* 4584 */         !bool) {
/* 4585 */         paramActionTransInfo.refRuleRoot = str;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4590 */       return str;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4597 */     return str1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void mapTreeVariable(AlternativeElement paramAlternativeElement, String paramString) {
/* 4606 */     if (paramAlternativeElement instanceof TreeElement) {
/* 4607 */       mapTreeVariable(((TreeElement)paramAlternativeElement).root, paramString);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 4612 */     String str = null;
/*      */ 
/*      */     
/* 4615 */     if (paramAlternativeElement.getLabel() == null) {
/* 4616 */       if (paramAlternativeElement instanceof TokenRefElement) {
/*      */         
/* 4618 */         str = ((TokenRefElement)paramAlternativeElement).atomText;
/*      */       }
/* 4620 */       else if (paramAlternativeElement instanceof RuleRefElement) {
/*      */         
/* 4622 */         str = ((RuleRefElement)paramAlternativeElement).targetRule;
/*      */       } 
/*      */     }
/*      */     
/* 4626 */     if (str != null) {
/* 4627 */       if (this.treeVariableMap.get(str) != null) {
/*      */         
/* 4629 */         this.treeVariableMap.remove(str);
/* 4630 */         this.treeVariableMap.put(str, NONUNIQUE);
/*      */       } else {
/*      */         
/* 4633 */         this.treeVariableMap.put(str, paramString);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String processActionForSpecialSymbols(String paramString, int paramInt, RuleBlock paramRuleBlock, ActionTransInfo paramActionTransInfo) {
/* 4647 */     if (paramString == null || paramString.length() == 0) {
/* 4648 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 4652 */     if (this.grammar == null) {
/* 4653 */       return paramString;
/*      */     }
/* 4655 */     if ((this.grammar.buildAST && paramString.indexOf('#') != -1) || this.grammar instanceof TreeWalkerGrammar || ((this.grammar instanceof LexerGrammar || this.grammar instanceof ParserGrammar) && paramString.indexOf('$') != -1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4662 */       ActionLexer actionLexer = new ActionLexer(paramString, paramRuleBlock, this, paramActionTransInfo);
/*      */       
/* 4664 */       actionLexer.setLineOffset(paramInt);
/* 4665 */       actionLexer.setFilename(this.grammar.getFilename());
/* 4666 */       actionLexer.setTool(this.antlrTool);
/*      */       
/*      */       try {
/* 4669 */         actionLexer.mACTION(true);
/* 4670 */         paramString = actionLexer.getTokenObject().getText();
/*      */ 
/*      */       
/*      */       }
/* 4674 */       catch (RecognitionException recognitionException) {
/* 4675 */         actionLexer.reportError(recognitionException);
/* 4676 */         return paramString;
/*      */       }
/* 4678 */       catch (TokenStreamException tokenStreamException) {
/* 4679 */         this.antlrTool.panic("Error reading action:" + paramString);
/* 4680 */         return paramString;
/*      */       }
/* 4682 */       catch (CharStreamException charStreamException) {
/* 4683 */         this.antlrTool.panic("Error reading action:" + paramString);
/* 4684 */         return paramString;
/*      */       } 
/*      */     } 
/* 4687 */     return paramString;
/*      */   }
/*      */ 
/*      */   
/*      */   private String fixNameSpaceOption(String paramString) {
/* 4692 */     paramString = StringUtils.stripFrontBack(paramString, "\"", "\"");
/* 4693 */     if (paramString.length() > 2 && !paramString.substring(paramString.length() - 2, paramString.length()).equals("::"))
/*      */     {
/* 4695 */       paramString = paramString + "::"; } 
/* 4696 */     return paramString;
/*      */   }
/*      */   
/*      */   private void setupGrammarParameters(Grammar paramGrammar) {
/* 4700 */     if (paramGrammar instanceof ParserGrammar || paramGrammar instanceof LexerGrammar || paramGrammar instanceof TreeWalkerGrammar) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4710 */       if (this.antlrTool.nameSpace != null) {
/* 4711 */         nameSpace = this.antlrTool.nameSpace;
/*      */       }
/* 4713 */       if (this.antlrTool.namespaceStd != null) {
/* 4714 */         namespaceStd = fixNameSpaceOption(this.antlrTool.namespaceStd);
/*      */       }
/* 4716 */       if (this.antlrTool.namespaceAntlr != null) {
/* 4717 */         namespaceAntlr = fixNameSpaceOption(this.antlrTool.namespaceAntlr);
/*      */       }
/* 4719 */       this.genHashLines = this.antlrTool.genHashLines;
/*      */ 
/*      */ 
/*      */       
/* 4723 */       if (paramGrammar.hasOption("namespace")) {
/* 4724 */         Token token = paramGrammar.getOption("namespace");
/* 4725 */         if (token != null) {
/* 4726 */           nameSpace = new NameSpace(token.getText());
/*      */         }
/*      */       } 
/* 4729 */       if (paramGrammar.hasOption("namespaceAntlr")) {
/* 4730 */         Token token = paramGrammar.getOption("namespaceAntlr");
/* 4731 */         if (token != null) {
/* 4732 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 4733 */           if (str != null) {
/* 4734 */             if (str.length() > 2 && !str.substring(str.length() - 2, str.length()).equals("::"))
/*      */             {
/* 4736 */               str = str + "::"; } 
/* 4737 */             namespaceAntlr = str;
/*      */           } 
/*      */         } 
/*      */       } 
/* 4741 */       if (paramGrammar.hasOption("namespaceStd")) {
/* 4742 */         Token token = paramGrammar.getOption("namespaceStd");
/* 4743 */         if (token != null) {
/* 4744 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 4745 */           if (str != null) {
/* 4746 */             if (str.length() > 2 && !str.substring(str.length() - 2, str.length()).equals("::"))
/*      */             {
/* 4748 */               str = str + "::"; } 
/* 4749 */             namespaceStd = str;
/*      */           } 
/*      */         } 
/*      */       } 
/* 4753 */       if (paramGrammar.hasOption("genHashLines")) {
/* 4754 */         Token token = paramGrammar.getOption("genHashLines");
/* 4755 */         if (token != null) {
/* 4756 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 4757 */           this.genHashLines = str.equals("true");
/*      */         } 
/*      */       } 
/* 4760 */       this.noConstructors = this.antlrTool.noConstructors;
/* 4761 */       if (paramGrammar.hasOption("noConstructors")) {
/* 4762 */         Token token = paramGrammar.getOption("noConstructors");
/* 4763 */         if (token != null && !token.getText().equals("true") && !token.getText().equals("false"))
/* 4764 */           this.antlrTool.error("noConstructors option must be true or false", this.antlrTool.getGrammarFile(), token.getLine(), token.getColumn()); 
/* 4765 */         this.noConstructors = token.getText().equals("true");
/*      */       } 
/*      */     } 
/* 4768 */     if (paramGrammar instanceof ParserGrammar) {
/* 4769 */       this.labeledElementASTType = namespaceAntlr + "RefAST";
/* 4770 */       this.labeledElementASTInit = namespaceAntlr + "nullAST";
/* 4771 */       if (paramGrammar.hasOption("ASTLabelType")) {
/* 4772 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 4773 */         if (token != null) {
/* 4774 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 4775 */           if (str != null) {
/* 4776 */             this.usingCustomAST = true;
/* 4777 */             this.labeledElementASTType = str;
/* 4778 */             this.labeledElementASTInit = str + "(" + namespaceAntlr + "nullAST)";
/*      */           } 
/*      */         } 
/*      */       } 
/* 4782 */       this.labeledElementType = namespaceAntlr + "RefToken ";
/* 4783 */       this.labeledElementInit = namespaceAntlr + "nullToken";
/* 4784 */       this.commonExtraArgs = "";
/* 4785 */       this.commonExtraParams = "";
/* 4786 */       this.commonLocalVars = "";
/* 4787 */       this.lt1Value = "LT(1)";
/* 4788 */       this.exceptionThrown = namespaceAntlr + "RecognitionException";
/* 4789 */       this.throwNoViable = "throw " + namespaceAntlr + "NoViableAltException(LT(1), getFilename());";
/*      */     }
/* 4791 */     else if (paramGrammar instanceof LexerGrammar) {
/* 4792 */       this.labeledElementType = "char ";
/* 4793 */       this.labeledElementInit = "'\\0'";
/* 4794 */       this.commonExtraArgs = "";
/* 4795 */       this.commonExtraParams = "bool _createToken";
/* 4796 */       this.commonLocalVars = "int _ttype; " + namespaceAntlr + "RefToken _token; " + namespaceStd + "string::size_type _begin = text.length();";
/* 4797 */       this.lt1Value = "LA(1)";
/* 4798 */       this.exceptionThrown = namespaceAntlr + "RecognitionException";
/* 4799 */       this.throwNoViable = "throw " + namespaceAntlr + "NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());";
/*      */     }
/* 4801 */     else if (paramGrammar instanceof TreeWalkerGrammar) {
/* 4802 */       this.labeledElementInit = namespaceAntlr + "nullAST";
/* 4803 */       this.labeledElementASTInit = namespaceAntlr + "nullAST";
/* 4804 */       this.labeledElementASTType = namespaceAntlr + "RefAST";
/* 4805 */       this.labeledElementType = namespaceAntlr + "RefAST";
/* 4806 */       this.commonExtraParams = namespaceAntlr + "RefAST _t";
/* 4807 */       this.throwNoViable = "throw " + namespaceAntlr + "NoViableAltException(_t);";
/* 4808 */       this.lt1Value = "_t";
/* 4809 */       if (paramGrammar.hasOption("ASTLabelType")) {
/* 4810 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 4811 */         if (token != null) {
/* 4812 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 4813 */           if (str != null) {
/* 4814 */             this.usingCustomAST = true;
/* 4815 */             this.labeledElementASTType = str;
/* 4816 */             this.labeledElementType = str;
/* 4817 */             this.labeledElementInit = str + "(" + namespaceAntlr + "nullAST)";
/* 4818 */             this.labeledElementASTInit = this.labeledElementInit;
/* 4819 */             this.commonExtraParams = str + " _t";
/* 4820 */             this.throwNoViable = "throw " + namespaceAntlr + "NoViableAltException(" + namespaceAntlr + "RefAST(_t));";
/* 4821 */             this.lt1Value = "_t";
/*      */           } 
/*      */         } 
/*      */       } 
/* 4825 */       if (!paramGrammar.hasOption("ASTLabelType")) {
/* 4826 */         paramGrammar.setOption("ASTLabelType", new Token(6, namespaceAntlr + "RefAST"));
/*      */       }
/* 4828 */       this.commonExtraArgs = "_t";
/* 4829 */       this.commonLocalVars = "";
/* 4830 */       this.exceptionThrown = namespaceAntlr + "RecognitionException";
/*      */     } else {
/*      */       
/* 4833 */       this.antlrTool.panic("Unknown grammar type");
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\CppCodeGenerator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */