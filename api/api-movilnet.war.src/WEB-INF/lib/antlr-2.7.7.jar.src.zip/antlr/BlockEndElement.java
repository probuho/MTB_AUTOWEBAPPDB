/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BlockEndElement
/*    */   extends AlternativeElement
/*    */ {
/*    */   protected boolean[] lock;
/*    */   protected AlternativeBlock block;
/*    */   
/*    */   public BlockEndElement(Grammar paramGrammar) {
/* 19 */     super(paramGrammar);
/* 20 */     this.lock = new boolean[paramGrammar.maxk + 1];
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 24 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     return "";
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\BlockEndElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */