/*    */ package antlr;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ParseTree
/*    */   extends BaseAST
/*    */ {
/*    */   public String getLeftmostDerivationStep(int paramInt) {
/* 18 */     if (paramInt <= 0) {
/* 19 */       return toString();
/*    */     }
/* 21 */     StringBuffer stringBuffer = new StringBuffer(2000);
/* 22 */     getLeftmostDerivation(stringBuffer, paramInt);
/* 23 */     return stringBuffer.toString();
/*    */   }
/*    */   
/*    */   public String getLeftmostDerivation(int paramInt) {
/* 27 */     StringBuffer stringBuffer = new StringBuffer(2000);
/* 28 */     stringBuffer.append("    " + toString());
/* 29 */     stringBuffer.append("\n");
/* 30 */     for (byte b = 1; b < paramInt; b++) {
/* 31 */       stringBuffer.append(" =>");
/* 32 */       stringBuffer.append(getLeftmostDerivationStep(b));
/* 33 */       stringBuffer.append("\n");
/*    */     } 
/* 35 */     return stringBuffer.toString();
/*    */   }
/*    */   
/*    */   protected abstract int getLeftmostDerivation(StringBuffer paramStringBuffer, int paramInt);
/*    */   
/*    */   public void initialize(int paramInt, String paramString) {}
/*    */   
/*    */   public void initialize(AST paramAST) {}
/*    */   
/*    */   public void initialize(Token paramToken) {}
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\ParseTree.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */