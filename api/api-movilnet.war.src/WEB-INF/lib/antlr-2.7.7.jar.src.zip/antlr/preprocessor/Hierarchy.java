/*     */ package antlr.preprocessor;
/*     */ 
/*     */ import antlr.ANTLRException;
/*     */ import antlr.TokenStreamException;
/*     */ import antlr.Tool;
/*     */ import antlr.collections.impl.IndexedVector;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hierarchy
/*     */ {
/*  20 */   protected Grammar LexerRoot = null;
/*  21 */   protected Grammar ParserRoot = null;
/*  22 */   protected Grammar TreeParserRoot = null;
/*     */   protected Hashtable symbols;
/*     */   protected Hashtable files;
/*     */   protected Tool antlrTool;
/*     */   
/*     */   public Hierarchy(Tool paramTool) {
/*  28 */     this.antlrTool = paramTool;
/*  29 */     this.LexerRoot = new Grammar(paramTool, "Lexer", null, null);
/*  30 */     this.ParserRoot = new Grammar(paramTool, "Parser", null, null);
/*  31 */     this.TreeParserRoot = new Grammar(paramTool, "TreeParser", null, null);
/*  32 */     this.symbols = new Hashtable(10);
/*  33 */     this.files = new Hashtable(10);
/*     */     
/*  35 */     this.LexerRoot.setPredefined(true);
/*  36 */     this.ParserRoot.setPredefined(true);
/*  37 */     this.TreeParserRoot.setPredefined(true);
/*     */     
/*  39 */     this.symbols.put(this.LexerRoot.getName(), this.LexerRoot);
/*  40 */     this.symbols.put(this.ParserRoot.getName(), this.ParserRoot);
/*  41 */     this.symbols.put(this.TreeParserRoot.getName(), this.TreeParserRoot);
/*     */   }
/*     */   
/*     */   public void addGrammar(Grammar paramGrammar) {
/*  45 */     paramGrammar.setHierarchy(this);
/*     */     
/*  47 */     this.symbols.put(paramGrammar.getName(), paramGrammar);
/*     */     
/*  49 */     GrammarFile grammarFile = getFile(paramGrammar.getFileName());
/*  50 */     grammarFile.addGrammar(paramGrammar);
/*     */   }
/*     */   
/*     */   public void addGrammarFile(GrammarFile paramGrammarFile) {
/*  54 */     this.files.put(paramGrammarFile.getName(), paramGrammarFile);
/*     */   }
/*     */   
/*     */   public void expandGrammarsInFile(String paramString) {
/*  58 */     GrammarFile grammarFile = getFile(paramString);
/*  59 */     for (Enumeration enumeration = grammarFile.getGrammars().elements(); enumeration.hasMoreElements(); ) {
/*  60 */       Grammar grammar = enumeration.nextElement();
/*  61 */       grammar.expandInPlace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Grammar findRoot(Grammar paramGrammar) {
/*  66 */     if (paramGrammar.getSuperGrammarName() == null) {
/*  67 */       return paramGrammar;
/*     */     }
/*     */     
/*  70 */     Grammar grammar = paramGrammar.getSuperGrammar();
/*  71 */     if (grammar == null) return paramGrammar; 
/*  72 */     return findRoot(grammar);
/*     */   }
/*     */   
/*     */   public GrammarFile getFile(String paramString) {
/*  76 */     return (GrammarFile)this.files.get(paramString);
/*     */   }
/*     */   
/*     */   public Grammar getGrammar(String paramString) {
/*  80 */     return (Grammar)this.symbols.get(paramString);
/*     */   }
/*     */   
/*     */   public static String optionsToString(IndexedVector paramIndexedVector) {
/*  84 */     String str = "options {" + System.getProperty("line.separator");
/*  85 */     for (Enumeration enumeration = paramIndexedVector.elements(); enumeration.hasMoreElements();) {
/*  86 */       str = str + (Option)enumeration.nextElement() + System.getProperty("line.separator");
/*     */     }
/*  88 */     str = str + "}" + System.getProperty("line.separator") + System.getProperty("line.separator");
/*     */ 
/*     */     
/*  91 */     return str;
/*     */   }
/*     */   
/*     */   public void readGrammarFile(String paramString) throws FileNotFoundException {
/*  95 */     BufferedReader bufferedReader = new BufferedReader(new FileReader(paramString));
/*  96 */     addGrammarFile(new GrammarFile(this.antlrTool, paramString));
/*     */ 
/*     */     
/*  99 */     PreprocessorLexer preprocessorLexer = new PreprocessorLexer(bufferedReader);
/* 100 */     preprocessorLexer.setFilename(paramString);
/* 101 */     Preprocessor preprocessor = new Preprocessor(preprocessorLexer);
/* 102 */     preprocessor.setTool(this.antlrTool);
/* 103 */     preprocessor.setFilename(paramString);
/*     */ 
/*     */     
/*     */     try {
/* 107 */       preprocessor.grammarFile(this, paramString);
/*     */     }
/* 109 */     catch (TokenStreamException tokenStreamException) {
/* 110 */       this.antlrTool.toolError("Token stream error reading grammar(s):\n" + tokenStreamException);
/*     */     }
/* 112 */     catch (ANTLRException aNTLRException) {
/* 113 */       this.antlrTool.toolError("error reading grammar(s):\n" + aNTLRException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean verifyThatHierarchyIsComplete() {
/* 119 */     boolean bool = true;
/*     */     Enumeration enumeration;
/* 121 */     for (enumeration = this.symbols.elements(); enumeration.hasMoreElements(); ) {
/* 122 */       Grammar grammar1 = enumeration.nextElement();
/* 123 */       if (grammar1.getSuperGrammarName() == null) {
/*     */         continue;
/*     */       }
/* 126 */       Grammar grammar2 = grammar1.getSuperGrammar();
/* 127 */       if (grammar2 == null) {
/* 128 */         this.antlrTool.toolError("grammar " + grammar1.getSuperGrammarName() + " not defined");
/* 129 */         bool = false;
/* 130 */         this.symbols.remove(grammar1.getName());
/*     */       } 
/*     */     } 
/*     */     
/* 134 */     if (!bool) return false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     for (enumeration = this.symbols.elements(); enumeration.hasMoreElements(); ) {
/* 140 */       Grammar grammar = enumeration.nextElement();
/* 141 */       if (grammar.getSuperGrammarName() == null) {
/*     */         continue;
/*     */       }
/* 144 */       grammar.setType(findRoot(grammar).getName());
/*     */     } 
/*     */     
/* 147 */     return true;
/*     */   }
/*     */   
/*     */   public Tool getTool() {
/* 151 */     return this.antlrTool;
/*     */   }
/*     */   
/*     */   public void setTool(Tool paramTool) {
/* 155 */     this.antlrTool = paramTool;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\preprocessor\Hierarchy.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */