/*     */ package antlr.preprocessor;
/*     */ 
/*     */ import antlr.collections.impl.Vector;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tool
/*     */ {
/*     */   protected Hierarchy theHierarchy;
/*     */   protected String grammarFileName;
/*     */   protected String[] args;
/*     */   protected int nargs;
/*     */   protected Vector grammars;
/*     */   protected antlr.Tool antlrTool;
/*     */   
/*     */   public Tool(antlr.Tool paramTool, String[] paramArrayOfString) {
/*  24 */     this.antlrTool = paramTool;
/*  25 */     processArguments(paramArrayOfString);
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*  29 */     antlr.Tool tool = new antlr.Tool();
/*  30 */     Tool tool1 = new Tool(tool, paramArrayOfString);
/*  31 */     tool1.preprocess();
/*  32 */     String[] arrayOfString = tool1.preprocessedArgList();
/*  33 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  34 */       System.out.print(" " + arrayOfString[b]);
/*     */     }
/*  36 */     System.out.println();
/*     */   }
/*     */   
/*     */   public boolean preprocess() {
/*  40 */     if (this.grammarFileName == null) {
/*  41 */       this.antlrTool.toolError("no grammar file specified");
/*  42 */       return false;
/*     */     } 
/*  44 */     if (this.grammars != null) {
/*  45 */       this.theHierarchy = new Hierarchy(this.antlrTool);
/*  46 */       for (Enumeration enumeration = this.grammars.elements(); enumeration.hasMoreElements(); ) {
/*  47 */         String str1 = enumeration.nextElement();
/*     */         try {
/*  49 */           this.theHierarchy.readGrammarFile(str1);
/*     */         }
/*  51 */         catch (FileNotFoundException fileNotFoundException) {
/*  52 */           this.antlrTool.toolError("file " + str1 + " not found");
/*  53 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  59 */     boolean bool = this.theHierarchy.verifyThatHierarchyIsComplete();
/*  60 */     if (!bool)
/*  61 */       return false; 
/*  62 */     this.theHierarchy.expandGrammarsInFile(this.grammarFileName);
/*  63 */     GrammarFile grammarFile = this.theHierarchy.getFile(this.grammarFileName);
/*  64 */     String str = grammarFile.nameForExpandedGrammarFile(this.grammarFileName);
/*     */ 
/*     */     
/*  67 */     if (str.equals(this.grammarFileName)) {
/*  68 */       this.args[this.nargs++] = this.grammarFileName;
/*     */     } else {
/*     */       
/*     */       try {
/*  72 */         grammarFile.generateExpandedFile();
/*  73 */         this.args[this.nargs++] = this.antlrTool.getOutputDirectory() + System.getProperty("file.separator") + str;
/*     */ 
/*     */       
/*     */       }
/*  77 */       catch (IOException iOException) {
/*  78 */         this.antlrTool.toolError("cannot write expanded grammar file " + str);
/*  79 */         return false;
/*     */       } 
/*     */     } 
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] preprocessedArgList() {
/*  87 */     String[] arrayOfString = new String[this.nargs];
/*  88 */     System.arraycopy(this.args, 0, arrayOfString, 0, this.nargs);
/*  89 */     this.args = arrayOfString;
/*  90 */     return this.args;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processArguments(String[] paramArrayOfString) {
/*  98 */     this.nargs = 0;
/*  99 */     this.args = new String[paramArrayOfString.length];
/* 100 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 101 */       if (paramArrayOfString[b].length() == 0) {
/*     */         
/* 103 */         this.antlrTool.warning("Zero length argument ignoring...");
/*     */       
/*     */       }
/* 106 */       else if (paramArrayOfString[b].equals("-glib")) {
/*     */         
/* 108 */         if (File.separator.equals("\\") && paramArrayOfString[b].indexOf('/') != -1) {
/*     */           
/* 110 */           this.antlrTool.warning("-glib cannot deal with '/' on a PC: use '\\'; ignoring...");
/*     */         } else {
/*     */           
/* 113 */           this.grammars = antlr.Tool.parseSeparatedList(paramArrayOfString[b + 1], ';');
/* 114 */           b++;
/*     */         }
/*     */       
/* 117 */       } else if (paramArrayOfString[b].equals("-o")) {
/* 118 */         this.args[this.nargs++] = paramArrayOfString[b];
/* 119 */         if (b + 1 >= paramArrayOfString.length) {
/* 120 */           this.antlrTool.error("missing output directory with -o option; ignoring");
/*     */         } else {
/*     */           
/* 123 */           b++;
/* 124 */           this.args[this.nargs++] = paramArrayOfString[b];
/* 125 */           this.antlrTool.setOutputDirectory(paramArrayOfString[b]);
/*     */         }
/*     */       
/* 128 */       } else if (paramArrayOfString[b].charAt(0) == '-') {
/* 129 */         this.args[this.nargs++] = paramArrayOfString[b];
/*     */       }
/*     */       else {
/*     */         
/* 133 */         this.grammarFileName = paramArrayOfString[b];
/* 134 */         if (this.grammars == null) {
/* 135 */           this.grammars = new Vector(10);
/*     */         }
/* 137 */         this.grammars.appendElement(this.grammarFileName);
/* 138 */         if (b + 1 < paramArrayOfString.length) {
/* 139 */           this.antlrTool.warning("grammar file must be last; ignoring other arguments...");
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\preprocessor\Tool.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */