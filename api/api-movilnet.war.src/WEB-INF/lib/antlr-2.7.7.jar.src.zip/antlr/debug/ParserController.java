package antlr.debug;

public interface ParserController extends ParserListener {
  void checkBreak();
  
  void setParserEventSupport(ParserEventSupport paramParserEventSupport);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\ParserController.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */