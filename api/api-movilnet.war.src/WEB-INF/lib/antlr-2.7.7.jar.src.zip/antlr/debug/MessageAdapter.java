package antlr.debug;

public class MessageAdapter implements MessageListener {
  public void doneParsing(TraceEvent paramTraceEvent) {}
  
  public void refresh() {}
  
  public void reportError(MessageEvent paramMessageEvent) {}
  
  public void reportWarning(MessageEvent paramMessageEvent) {}
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\MessageAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */