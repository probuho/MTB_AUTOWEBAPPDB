/*    */ package antlr.debug;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ public abstract class Event
/*    */   extends EventObject {
/*    */   private int type;
/*    */   
/*    */   public Event(Object paramObject) {
/* 10 */     super(paramObject);
/*    */   }
/*    */   public Event(Object paramObject, int paramInt) {
/* 13 */     super(paramObject);
/* 14 */     setType(paramInt);
/*    */   }
/*    */   public int getType() {
/* 17 */     return this.type;
/*    */   }
/*    */   void setType(int paramInt) {
/* 20 */     this.type = paramInt;
/*    */   }
/*    */   
/*    */   void setValues(int paramInt) {
/* 24 */     setType(paramInt);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\Event.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */