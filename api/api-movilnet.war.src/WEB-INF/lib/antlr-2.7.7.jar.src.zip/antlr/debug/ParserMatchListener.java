package antlr.debug;

public interface ParserMatchListener extends ListenerBase {
  void parserMatch(ParserMatchEvent paramParserMatchEvent);
  
  void parserMatchNot(ParserMatchEvent paramParserMatchEvent);
  
  void parserMismatch(ParserMatchEvent paramParserMatchEvent);
  
  void parserMismatchNot(ParserMatchEvent paramParserMatchEvent);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\ParserMatchListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */