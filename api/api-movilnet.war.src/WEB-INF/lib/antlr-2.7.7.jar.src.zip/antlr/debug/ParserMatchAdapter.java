package antlr.debug;

public class ParserMatchAdapter implements ParserMatchListener {
  public void doneParsing(TraceEvent paramTraceEvent) {}
  
  public void parserMatch(ParserMatchEvent paramParserMatchEvent) {}
  
  public void parserMatchNot(ParserMatchEvent paramParserMatchEvent) {}
  
  public void parserMismatch(ParserMatchEvent paramParserMatchEvent) {}
  
  public void parserMismatchNot(ParserMatchEvent paramParserMatchEvent) {}
  
  public void refresh() {}
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\ParserMatchAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */