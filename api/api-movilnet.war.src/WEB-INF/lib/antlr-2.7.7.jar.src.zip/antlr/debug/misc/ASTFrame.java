/*    */ package antlr.debug.misc;
/*    */ 
/*    */ import antlr.ASTFactory;
/*    */ import antlr.CommonAST;
/*    */ import antlr.collections.AST;
/*    */ import java.awt.Container;
/*    */ import java.awt.Frame;
/*    */ import java.awt.event.WindowAdapter;
/*    */ import java.awt.event.WindowEvent;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.event.TreeSelectionEvent;
/*    */ import javax.swing.event.TreeSelectionListener;
/*    */ import javax.swing.tree.TreePath;
/*    */ 
/*    */ public class ASTFrame
/*    */   extends JFrame {
/*    */   static final int WIDTH = 200;
/*    */   static final int HEIGHT = 300;
/*    */   
/*    */   class MyTreeSelectionListener implements TreeSelectionListener {
/*    */     private final ASTFrame this$0;
/*    */     
/*    */     MyTreeSelectionListener(ASTFrame this$0) {
/* 24 */       this.this$0 = this$0;
/*    */     }
/*    */     public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
/* 27 */       TreePath treePath = param1TreeSelectionEvent.getPath();
/* 28 */       System.out.println("Selected: " + treePath.getLastPathComponent());
/*    */       
/* 30 */       Object[] arrayOfObject = treePath.getPath();
/* 31 */       for (byte b = 0; b < arrayOfObject.length; b++) {
/* 32 */         System.out.print("->" + arrayOfObject[b]);
/*    */       }
/* 34 */       System.out.println();
/*    */     }
/*    */   }
/*    */   
/*    */   public ASTFrame(String paramString, AST paramAST) {
/* 39 */     super(paramString);
/*    */ 
/*    */     
/* 42 */     MyTreeSelectionListener myTreeSelectionListener = new MyTreeSelectionListener(this);
/* 43 */     JTreeASTPanel jTreeASTPanel = new JTreeASTPanel(new JTreeASTModel(paramAST), null);
/* 44 */     Container container = getContentPane();
/* 45 */     container.add(jTreeASTPanel, "Center");
/* 46 */     addWindowListener(new WindowAdapter(this) {
/*    */           public void windowClosing(WindowEvent param1WindowEvent) {
/* 48 */             Frame frame = (Frame)param1WindowEvent.getSource();
/* 49 */             frame.setVisible(false);
/* 50 */             frame.dispose();
/*    */           }
/*    */           private final ASTFrame this$0;
/*    */         });
/* 54 */     setSize(200, 300);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/* 59 */     ASTFactory aSTFactory = new ASTFactory();
/* 60 */     CommonAST commonAST = (CommonAST)aSTFactory.create(0, "ROOT");
/* 61 */     commonAST.addChild(aSTFactory.create(0, "C1"));
/* 62 */     commonAST.addChild(aSTFactory.create(0, "C2"));
/* 63 */     commonAST.addChild(aSTFactory.create(0, "C3"));
/*    */     
/* 65 */     ASTFrame aSTFrame = new ASTFrame("AST JTree Example", (AST)commonAST);
/* 66 */     aSTFrame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\misc\ASTFrame.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */