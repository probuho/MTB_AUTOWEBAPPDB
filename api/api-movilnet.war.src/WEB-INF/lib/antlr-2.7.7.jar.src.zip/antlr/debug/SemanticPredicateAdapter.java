package antlr.debug;

public class SemanticPredicateAdapter implements SemanticPredicateListener {
  public void doneParsing(TraceEvent paramTraceEvent) {}
  
  public void refresh() {}
  
  public void semanticPredicateEvaluated(SemanticPredicateEvent paramSemanticPredicateEvent) {}
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\debug\SemanticPredicateAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */