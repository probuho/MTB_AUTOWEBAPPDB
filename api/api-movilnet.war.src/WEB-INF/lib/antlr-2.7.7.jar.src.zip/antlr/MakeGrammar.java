/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.Stack;
/*     */ import antlr.collections.impl.LList;
/*     */ import antlr.collections.impl.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MakeGrammar
/*     */   extends DefineGrammarSymbols
/*     */ {
/*  16 */   protected Stack blocks = (Stack)new LList();
/*     */   
/*     */   protected RuleRefElement lastRuleRef;
/*     */   protected RuleEndElement ruleEnd;
/*     */   protected RuleBlock ruleBlock;
/*  21 */   protected int nested = 0;
/*     */   
/*     */   protected boolean grammarError = false;
/*  24 */   ExceptionSpec currentExceptionSpec = null;
/*     */   
/*     */   public MakeGrammar(Tool paramTool, String[] paramArrayOfString, LLkAnalyzer paramLLkAnalyzer) {
/*  27 */     super(paramTool, paramArrayOfString, paramLLkAnalyzer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void abortGrammar() {
/*  32 */     String str = "unknown grammar";
/*  33 */     if (this.grammar != null) {
/*  34 */       str = this.grammar.getClassName();
/*     */     }
/*  36 */     this.tool.error("aborting grammar '" + str + "' due to errors");
/*  37 */     super.abortGrammar();
/*     */   }
/*     */   
/*     */   protected void addElementToCurrentAlt(AlternativeElement paramAlternativeElement) {
/*  41 */     paramAlternativeElement.enclosingRuleName = this.ruleBlock.ruleName;
/*  42 */     context().addAlternativeElement(paramAlternativeElement);
/*     */   }
/*     */   
/*     */   public void beginAlt(boolean paramBoolean) {
/*  46 */     super.beginAlt(paramBoolean);
/*  47 */     Alternative alternative = new Alternative();
/*  48 */     alternative.setAutoGen(paramBoolean);
/*  49 */     (context()).block.addAlternative(alternative);
/*     */   }
/*     */   
/*     */   public void beginChildList() {
/*  53 */     super.beginChildList();
/*  54 */     (context()).block.addAlternative(new Alternative());
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginExceptionGroup() {
/*  59 */     super.beginExceptionGroup();
/*  60 */     if (!((context()).block instanceof RuleBlock)) {
/*  61 */       this.tool.panic("beginExceptionGroup called outside of rule block");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginExceptionSpec(Token paramToken) {
/*  68 */     if (paramToken != null) {
/*  69 */       paramToken.setText(StringUtils.stripFront(StringUtils.stripBack(paramToken.getText(), " \n\r\t"), " \n\r\t"));
/*     */     }
/*  71 */     super.beginExceptionSpec(paramToken);
/*     */ 
/*     */     
/*  74 */     this.currentExceptionSpec = new ExceptionSpec(paramToken);
/*     */   }
/*     */   
/*     */   public void beginSubRule(Token paramToken1, Token paramToken2, boolean paramBoolean) {
/*  78 */     super.beginSubRule(paramToken1, paramToken2, paramBoolean);
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.blocks.push(new BlockContext());
/*  83 */     (context()).block = new AlternativeBlock(this.grammar, paramToken2, paramBoolean);
/*  84 */     (context()).altNum = 0;
/*  85 */     this.nested++;
/*     */ 
/*     */     
/*  88 */     (context()).blockEnd = new BlockEndElement(this.grammar);
/*     */     
/*  90 */     (context()).blockEnd.block = (context()).block;
/*  91 */     labelElement((context()).block, paramToken1);
/*     */   }
/*     */   
/*     */   public void beginTree(Token paramToken) throws SemanticException {
/*  95 */     if (!(this.grammar instanceof TreeWalkerGrammar)) {
/*  96 */       this.tool.error("Trees only allowed in TreeParser", this.grammar.getFilename(), paramToken.getLine(), paramToken.getColumn());
/*  97 */       throw new SemanticException("Trees only allowed in TreeParser");
/*     */     } 
/*  99 */     super.beginTree(paramToken);
/* 100 */     this.blocks.push(new TreeBlockContext());
/* 101 */     (context()).block = new TreeElement(this.grammar, paramToken);
/* 102 */     (context()).altNum = 0;
/*     */   }
/*     */   
/*     */   public BlockContext context() {
/* 106 */     if (this.blocks.height() == 0) {
/* 107 */       return null;
/*     */     }
/*     */     
/* 110 */     return (BlockContext)this.blocks.top();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuleBlock createNextTokenRule(Grammar paramGrammar, Vector paramVector, String paramString) {
/* 123 */     RuleBlock ruleBlock = new RuleBlock(paramGrammar, paramString);
/* 124 */     ruleBlock.setDefaultErrorHandler(paramGrammar.getDefaultErrorHandler());
/* 125 */     RuleEndElement ruleEndElement = new RuleEndElement(paramGrammar);
/* 126 */     ruleBlock.setEndElement(ruleEndElement);
/* 127 */     ruleEndElement.block = ruleBlock;
/*     */     
/* 129 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 130 */       RuleSymbol ruleSymbol = (RuleSymbol)paramVector.elementAt(b);
/* 131 */       if (!ruleSymbol.isDefined()) {
/* 132 */         paramGrammar.antlrTool.error("Lexer rule " + ruleSymbol.id.substring(1) + " is not defined");
/*     */       
/*     */       }
/* 135 */       else if (ruleSymbol.access.equals("public")) {
/* 136 */         Alternative alternative = new Alternative();
/* 137 */         RuleBlock ruleBlock1 = ruleSymbol.getBlock();
/* 138 */         Vector vector = ruleBlock1.getAlternatives();
/*     */ 
/*     */         
/* 141 */         if (vector != null && vector.size() == 1) {
/* 142 */           Alternative alternative1 = (Alternative)vector.elementAt(0);
/* 143 */           if (alternative1.semPred != null)
/*     */           {
/* 145 */             alternative.semPred = alternative1.semPred;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 154 */         RuleRefElement ruleRefElement = new RuleRefElement(paramGrammar, new CommonToken(41, ruleSymbol.getId()), 1);
/*     */ 
/*     */ 
/*     */         
/* 158 */         ruleRefElement.setLabel("theRetToken");
/* 159 */         ruleRefElement.enclosingRuleName = "nextToken";
/* 160 */         ruleRefElement.next = ruleEndElement;
/* 161 */         alternative.addElement(ruleRefElement);
/* 162 */         alternative.setAutoGen(true);
/* 163 */         ruleBlock.addAlternative(alternative);
/* 164 */         ruleSymbol.addReference(ruleRefElement);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 169 */     ruleBlock.setAutoGen(true);
/* 170 */     ruleBlock.prepareForAnalysis();
/*     */     
/* 172 */     return ruleBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private AlternativeBlock createOptionalRuleRef(String paramString, Token paramToken) {
/* 178 */     AlternativeBlock alternativeBlock = new AlternativeBlock(this.grammar, paramToken, false);
/*     */ 
/*     */     
/* 181 */     String str = CodeGenerator.encodeLexerRuleName(paramString);
/* 182 */     if (!this.grammar.isDefined(str)) {
/* 183 */       this.grammar.define(new RuleSymbol(str));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 188 */     CommonToken commonToken = new CommonToken(24, paramString);
/* 189 */     commonToken.setLine(paramToken.getLine());
/* 190 */     commonToken.setLine(paramToken.getColumn());
/* 191 */     RuleRefElement ruleRefElement = new RuleRefElement(this.grammar, commonToken, 1);
/*     */ 
/*     */     
/* 194 */     ruleRefElement.enclosingRuleName = this.ruleBlock.ruleName;
/*     */ 
/*     */     
/* 197 */     BlockEndElement blockEndElement = new BlockEndElement(this.grammar);
/* 198 */     blockEndElement.block = alternativeBlock;
/*     */ 
/*     */     
/* 201 */     Alternative alternative1 = new Alternative(ruleRefElement);
/* 202 */     alternative1.addElement(blockEndElement);
/*     */ 
/*     */     
/* 205 */     alternativeBlock.addAlternative(alternative1);
/*     */ 
/*     */     
/* 208 */     Alternative alternative2 = new Alternative();
/* 209 */     alternative2.addElement(blockEndElement);
/*     */     
/* 211 */     alternativeBlock.addAlternative(alternative2);
/*     */     
/* 213 */     alternativeBlock.prepareForAnalysis();
/* 214 */     return alternativeBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defineRuleName(Token paramToken, String paramString1, boolean paramBoolean, String paramString2) throws SemanticException {
/* 223 */     if (paramToken.type == 24) {
/* 224 */       if (!(this.grammar instanceof LexerGrammar)) {
/* 225 */         this.tool.error("Lexical rule " + paramToken.getText() + " defined outside of lexer", this.grammar.getFilename(), paramToken.getLine(), paramToken.getColumn());
/*     */ 
/*     */         
/* 228 */         paramToken.setText(paramToken.getText().toLowerCase());
/*     */       }
/*     */     
/*     */     }
/* 232 */     else if (this.grammar instanceof LexerGrammar) {
/* 233 */       this.tool.error("Lexical rule names must be upper case, '" + paramToken.getText() + "' is not", this.grammar.getFilename(), paramToken.getLine(), paramToken.getColumn());
/*     */ 
/*     */       
/* 236 */       paramToken.setText(paramToken.getText().toUpperCase());
/*     */     } 
/*     */ 
/*     */     
/* 240 */     super.defineRuleName(paramToken, paramString1, paramBoolean, paramString2);
/* 241 */     String str = paramToken.getText();
/*     */     
/* 243 */     if (paramToken.type == 24) {
/* 244 */       str = CodeGenerator.encodeLexerRuleName(str);
/*     */     }
/* 246 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 247 */     RuleBlock ruleBlock = new RuleBlock(this.grammar, paramToken.getText(), paramToken.getLine(), paramBoolean);
/*     */ 
/*     */     
/* 250 */     ruleBlock.setDefaultErrorHandler(this.grammar.getDefaultErrorHandler());
/*     */     
/* 252 */     this.ruleBlock = ruleBlock;
/* 253 */     this.blocks.push(new BlockContext());
/* 254 */     (context()).block = ruleBlock;
/* 255 */     ruleSymbol.setBlock(ruleBlock);
/* 256 */     this.ruleEnd = new RuleEndElement(this.grammar);
/* 257 */     ruleBlock.setEndElement(this.ruleEnd);
/* 258 */     this.nested = 0;
/*     */   }
/*     */   
/*     */   public void endAlt() {
/* 262 */     super.endAlt();
/* 263 */     if (this.nested == 0) {
/* 264 */       addElementToCurrentAlt(this.ruleEnd);
/*     */     } else {
/*     */       
/* 267 */       addElementToCurrentAlt((context()).blockEnd);
/*     */     } 
/* 269 */     (context()).altNum++;
/*     */   }
/*     */   
/*     */   public void endChildList() {
/* 273 */     super.endChildList();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     BlockEndElement blockEndElement = new BlockEndElement(this.grammar);
/* 279 */     blockEndElement.block = (context()).block;
/* 280 */     addElementToCurrentAlt(blockEndElement);
/*     */   }
/*     */   
/*     */   public void endExceptionGroup() {
/* 284 */     super.endExceptionGroup();
/*     */   }
/*     */   
/*     */   public void endExceptionSpec() {
/* 288 */     super.endExceptionSpec();
/* 289 */     if (this.currentExceptionSpec == null) {
/* 290 */       this.tool.panic("exception processing internal error -- no active exception spec");
/*     */     }
/* 292 */     if ((context()).block instanceof RuleBlock) {
/*     */       
/* 294 */       ((RuleBlock)(context()).block).addExceptionSpec(this.currentExceptionSpec);
/*     */ 
/*     */     
/*     */     }
/* 298 */     else if ((context().currentAlt()).exceptionSpec != null) {
/* 299 */       this.tool.error("Alternative already has an exception specification", this.grammar.getFilename(), (context()).block.getLine(), (context()).block.getColumn());
/*     */     } else {
/*     */       
/* 302 */       (context().currentAlt()).exceptionSpec = this.currentExceptionSpec;
/*     */     } 
/*     */     
/* 305 */     this.currentExceptionSpec = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void endGrammar() {
/* 310 */     if (this.grammarError) {
/* 311 */       abortGrammar();
/*     */     } else {
/*     */       
/* 314 */       super.endGrammar();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endRule(String paramString) {
/* 319 */     super.endRule(paramString);
/* 320 */     BlockContext blockContext = (BlockContext)this.blocks.pop();
/*     */     
/* 322 */     this.ruleEnd.block = blockContext.block;
/* 323 */     this.ruleEnd.block.prepareForAnalysis();
/*     */   }
/*     */ 
/*     */   
/*     */   public void endSubRule() {
/* 328 */     super.endSubRule();
/* 329 */     this.nested--;
/*     */     
/* 331 */     BlockContext blockContext = (BlockContext)this.blocks.pop();
/* 332 */     AlternativeBlock alternativeBlock = blockContext.block;
/*     */ 
/*     */ 
/*     */     
/* 336 */     if (alternativeBlock.not && !(alternativeBlock instanceof SynPredBlock) && !(alternativeBlock instanceof ZeroOrMoreBlock) && !(alternativeBlock instanceof OneOrMoreBlock))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 342 */       if (!this.analyzer.subruleCanBeInverted(alternativeBlock, this.grammar instanceof LexerGrammar)) {
/* 343 */         String str = System.getProperty("line.separator");
/* 344 */         this.tool.error("This subrule cannot be inverted.  Only subrules of the form:" + str + "    (T1|T2|T3...) or" + str + "    ('c1'|'c2'|'c3'...)" + str + "may be inverted (ranges are also allowed).", this.grammar.getFilename(), alternativeBlock.getLine(), alternativeBlock.getColumn());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 356 */     if (alternativeBlock instanceof SynPredBlock) {
/*     */ 
/*     */       
/* 359 */       SynPredBlock synPredBlock = (SynPredBlock)alternativeBlock;
/* 360 */       (context()).block.hasASynPred = true;
/* 361 */       (context().currentAlt()).synPred = synPredBlock;
/* 362 */       this.grammar.hasSyntacticPredicate = true;
/* 363 */       synPredBlock.removeTrackingOfRuleRefs(this.grammar);
/*     */     } else {
/*     */       
/* 366 */       addElementToCurrentAlt(alternativeBlock);
/*     */     } 
/* 368 */     blockContext.blockEnd.block.prepareForAnalysis();
/*     */   }
/*     */   
/*     */   public void endTree() {
/* 372 */     super.endTree();
/* 373 */     BlockContext blockContext = (BlockContext)this.blocks.pop();
/* 374 */     addElementToCurrentAlt(blockContext.block);
/*     */   }
/*     */ 
/*     */   
/*     */   public void hasError() {
/* 379 */     this.grammarError = true;
/*     */   }
/*     */   
/*     */   private void labelElement(AlternativeElement paramAlternativeElement, Token paramToken) {
/* 383 */     if (paramToken != null) {
/*     */       
/* 385 */       for (byte b = 0; b < this.ruleBlock.labeledElements.size(); b++) {
/* 386 */         AlternativeElement alternativeElement = (AlternativeElement)this.ruleBlock.labeledElements.elementAt(b);
/* 387 */         String str = alternativeElement.getLabel();
/* 388 */         if (str != null && str.equals(paramToken.getText())) {
/* 389 */           this.tool.error("Label '" + paramToken.getText() + "' has already been defined", this.grammar.getFilename(), paramToken.getLine(), paramToken.getColumn());
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 394 */       paramAlternativeElement.setLabel(paramToken.getText());
/* 395 */       this.ruleBlock.labeledElements.appendElement(paramAlternativeElement);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void noAutoGenSubRule() {
/* 400 */     (context()).block.setAutoGen(false);
/*     */   }
/*     */   
/*     */   public void oneOrMoreSubRule() {
/* 404 */     if ((context()).block.not) {
/* 405 */       this.tool.error("'~' cannot be applied to (...)* subrule", this.grammar.getFilename(), (context()).block.getLine(), (context()).block.getColumn());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 410 */     OneOrMoreBlock oneOrMoreBlock = new OneOrMoreBlock(this.grammar);
/* 411 */     setBlock(oneOrMoreBlock, (context()).block);
/* 412 */     BlockContext blockContext = (BlockContext)this.blocks.pop();
/* 413 */     this.blocks.push(new BlockContext());
/* 414 */     (context()).block = oneOrMoreBlock;
/* 415 */     (context()).blockEnd = blockContext.blockEnd;
/* 416 */     (context()).blockEnd.block = oneOrMoreBlock;
/*     */   }
/*     */   
/*     */   public void optionalSubRule() {
/* 420 */     if ((context()).block.not) {
/* 421 */       this.tool.error("'~' cannot be applied to (...)? subrule", this.grammar.getFilename(), (context()).block.getLine(), (context()).block.getColumn());
/*     */     }
/*     */ 
/*     */     
/* 425 */     beginAlt(false);
/* 426 */     endAlt();
/*     */   }
/*     */   
/*     */   public void refAction(Token paramToken) {
/* 430 */     super.refAction(paramToken);
/* 431 */     (context()).block.hasAnAction = true;
/* 432 */     addElementToCurrentAlt(new ActionElement(this.grammar, paramToken));
/*     */   }
/*     */   
/*     */   public void setUserExceptions(String paramString) {
/* 436 */     ((RuleBlock)(context()).block).throwsSpec = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public void refArgAction(Token paramToken) {
/* 441 */     ((RuleBlock)(context()).block).argAction = paramToken.getText();
/*     */   }
/*     */   
/*     */   public void refCharLiteral(Token paramToken1, Token paramToken2, boolean paramBoolean1, int paramInt, boolean paramBoolean2) {
/* 445 */     if (!(this.grammar instanceof LexerGrammar)) {
/* 446 */       this.tool.error("Character literal only valid in lexer", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       return;
/*     */     } 
/* 449 */     super.refCharLiteral(paramToken1, paramToken2, paramBoolean1, paramInt, paramBoolean2);
/* 450 */     CharLiteralElement charLiteralElement = new CharLiteralElement((LexerGrammar)this.grammar, paramToken1, paramBoolean1, paramInt);
/*     */ 
/*     */     
/* 453 */     if (!((LexerGrammar)this.grammar).caseSensitive && charLiteralElement.getType() < 128 && Character.toLowerCase((char)charLiteralElement.getType()) != (char)charLiteralElement.getType())
/*     */     {
/*     */ 
/*     */       
/* 457 */       this.tool.warning("Character literal must be lowercase when caseSensitive=false", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */     }
/*     */     
/* 460 */     addElementToCurrentAlt(charLiteralElement);
/* 461 */     labelElement(charLiteralElement, paramToken2);
/*     */ 
/*     */     
/* 464 */     String str = this.ruleBlock.getIgnoreRule();
/* 465 */     if (!paramBoolean2 && str != null) {
/* 466 */       addElementToCurrentAlt(createOptionalRuleRef(str, paramToken1));
/*     */     }
/*     */   }
/*     */   
/*     */   public void refCharRange(Token paramToken1, Token paramToken2, Token paramToken3, int paramInt, boolean paramBoolean) {
/* 471 */     if (!(this.grammar instanceof LexerGrammar)) {
/* 472 */       this.tool.error("Character range only valid in lexer", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       return;
/*     */     } 
/* 475 */     int i = ANTLRLexer.tokenTypeForCharLiteral(paramToken1.getText());
/* 476 */     int j = ANTLRLexer.tokenTypeForCharLiteral(paramToken2.getText());
/* 477 */     if (j < i) {
/* 478 */       this.tool.error("Malformed range.", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 483 */     if (!((LexerGrammar)this.grammar).caseSensitive) {
/* 484 */       if (i < 128 && Character.toLowerCase((char)i) != (char)i) {
/* 485 */         this.tool.warning("Character literal must be lowercase when caseSensitive=false", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       }
/* 487 */       if (j < 128 && Character.toLowerCase((char)j) != (char)j) {
/* 488 */         this.tool.warning("Character literal must be lowercase when caseSensitive=false", this.grammar.getFilename(), paramToken2.getLine(), paramToken2.getColumn());
/*     */       }
/*     */     } 
/*     */     
/* 492 */     super.refCharRange(paramToken1, paramToken2, paramToken3, paramInt, paramBoolean);
/* 493 */     CharRangeElement charRangeElement = new CharRangeElement((LexerGrammar)this.grammar, paramToken1, paramToken2, paramInt);
/* 494 */     addElementToCurrentAlt(charRangeElement);
/* 495 */     labelElement(charRangeElement, paramToken3);
/*     */ 
/*     */     
/* 498 */     String str = this.ruleBlock.getIgnoreRule();
/* 499 */     if (!paramBoolean && str != null) {
/* 500 */       addElementToCurrentAlt(createOptionalRuleRef(str, paramToken1));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refTokensSpecElementOption(Token paramToken1, Token paramToken2, Token paramToken3) {
/* 511 */     TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(paramToken1.getText());
/*     */     
/* 513 */     if (tokenSymbol == null) {
/* 514 */       this.tool.panic("cannot find " + paramToken1.getText() + "in tokens {...}");
/*     */     }
/* 516 */     if (paramToken2.getText().equals("AST")) {
/* 517 */       tokenSymbol.setASTNodeType(paramToken3.getText());
/*     */     } else {
/*     */       
/* 520 */       this.grammar.antlrTool.error("invalid tokens {...} element option:" + paramToken2.getText(), this.grammar.getFilename(), paramToken2.getLine(), paramToken2.getColumn());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refElementOption(Token paramToken1, Token paramToken2) {
/* 532 */     AlternativeElement alternativeElement = context().currentElement();
/* 533 */     if (alternativeElement instanceof StringLiteralElement || alternativeElement instanceof TokenRefElement || alternativeElement instanceof WildcardElement) {
/*     */ 
/*     */       
/* 536 */       ((GrammarAtom)alternativeElement).setOption(paramToken1, paramToken2);
/*     */     } else {
/*     */       
/* 539 */       this.tool.error("cannot use element option (" + paramToken1.getText() + ") for this kind of element", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refExceptionHandler(Token paramToken1, Token paramToken2) {
/* 547 */     super.refExceptionHandler(paramToken1, paramToken2);
/* 548 */     if (this.currentExceptionSpec == null) {
/* 549 */       this.tool.panic("exception handler processing internal error");
/*     */     }
/* 551 */     this.currentExceptionSpec.addHandler(new ExceptionHandler(paramToken1, paramToken2));
/*     */   }
/*     */   
/*     */   public void refInitAction(Token paramToken) {
/* 555 */     super.refAction(paramToken);
/* 556 */     (context()).block.setInitAction(paramToken.getText());
/*     */   }
/*     */   
/*     */   public void refMemberAction(Token paramToken) {
/* 560 */     this.grammar.classMemberAction = paramToken;
/*     */   }
/*     */   
/*     */   public void refPreambleAction(Token paramToken) {
/* 564 */     super.refPreambleAction(paramToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public void refReturnAction(Token paramToken) {
/* 569 */     if (this.grammar instanceof LexerGrammar) {
/* 570 */       String str = CodeGenerator.encodeLexerRuleName(((RuleBlock)(context()).block).getRuleName());
/* 571 */       RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 572 */       if (ruleSymbol.access.equals("public")) {
/* 573 */         this.tool.warning("public Lexical rules cannot specify return type", this.grammar.getFilename(), paramToken.getLine(), paramToken.getColumn());
/*     */         return;
/*     */       } 
/*     */     } 
/* 577 */     ((RuleBlock)(context()).block).returnAction = paramToken.getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refRule(Token paramToken1, Token paramToken2, Token paramToken3, Token paramToken4, int paramInt) {
/* 586 */     if (this.grammar instanceof LexerGrammar) {
/*     */       
/* 588 */       if (paramToken2.type != 24) {
/* 589 */         this.tool.error("Parser rule " + paramToken2.getText() + " referenced in lexer");
/*     */         return;
/*     */       } 
/* 592 */       if (paramInt == 2) {
/* 593 */         this.tool.error("AST specification ^ not allowed in lexer", this.grammar.getFilename(), paramToken2.getLine(), paramToken2.getColumn());
/*     */       }
/*     */     } 
/*     */     
/* 597 */     super.refRule(paramToken1, paramToken2, paramToken3, paramToken4, paramInt);
/* 598 */     this.lastRuleRef = new RuleRefElement(this.grammar, paramToken2, paramInt);
/* 599 */     if (paramToken4 != null) {
/* 600 */       this.lastRuleRef.setArgs(paramToken4.getText());
/*     */     }
/* 602 */     if (paramToken1 != null) {
/* 603 */       this.lastRuleRef.setIdAssign(paramToken1.getText());
/*     */     }
/* 605 */     addElementToCurrentAlt(this.lastRuleRef);
/*     */     
/* 607 */     String str = paramToken2.getText();
/*     */     
/* 609 */     if (paramToken2.type == 24) {
/* 610 */       str = CodeGenerator.encodeLexerRuleName(str);
/*     */     }
/*     */     
/* 613 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 614 */     ruleSymbol.addReference(this.lastRuleRef);
/* 615 */     labelElement(this.lastRuleRef, paramToken3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void refSemPred(Token paramToken) {
/* 620 */     super.refSemPred(paramToken);
/*     */     
/* 622 */     if (context().currentAlt().atStart()) {
/* 623 */       (context().currentAlt()).semPred = paramToken.getText();
/*     */     } else {
/*     */       
/* 626 */       ActionElement actionElement = new ActionElement(this.grammar, paramToken);
/* 627 */       actionElement.isSemPred = true;
/* 628 */       addElementToCurrentAlt(actionElement);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void refStringLiteral(Token paramToken1, Token paramToken2, int paramInt, boolean paramBoolean) {
/* 634 */     super.refStringLiteral(paramToken1, paramToken2, paramInt, paramBoolean);
/* 635 */     if (this.grammar instanceof TreeWalkerGrammar && paramInt == 2) {
/* 636 */       this.tool.error("^ not allowed in here for tree-walker", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */     }
/* 638 */     StringLiteralElement stringLiteralElement = new StringLiteralElement(this.grammar, paramToken1, paramInt);
/*     */ 
/*     */     
/* 641 */     if (this.grammar instanceof LexerGrammar && !((LexerGrammar)this.grammar).caseSensitive) {
/* 642 */       for (byte b = 1; b < paramToken1.getText().length() - 1; b++) {
/* 643 */         char c = paramToken1.getText().charAt(b);
/* 644 */         if (c < '' && Character.toLowerCase(c) != c) {
/* 645 */           this.tool.warning("Characters of string literal must be lowercase when caseSensitive=false", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 651 */     addElementToCurrentAlt(stringLiteralElement);
/* 652 */     labelElement(stringLiteralElement, paramToken2);
/*     */ 
/*     */     
/* 655 */     String str = this.ruleBlock.getIgnoreRule();
/* 656 */     if (!paramBoolean && str != null) {
/* 657 */       addElementToCurrentAlt(createOptionalRuleRef(str, paramToken1));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void refToken(Token paramToken1, Token paramToken2, Token paramToken3, Token paramToken4, boolean paramBoolean1, int paramInt, boolean paramBoolean2) {
/* 663 */     if (this.grammar instanceof LexerGrammar) {
/*     */       
/* 665 */       if (paramInt == 2) {
/* 666 */         this.tool.error("AST specification ^ not allowed in lexer", this.grammar.getFilename(), paramToken2.getLine(), paramToken2.getColumn());
/*     */       }
/* 668 */       if (paramBoolean1) {
/* 669 */         this.tool.error("~TOKEN is not allowed in lexer", this.grammar.getFilename(), paramToken2.getLine(), paramToken2.getColumn());
/*     */       }
/* 671 */       refRule(paramToken1, paramToken2, paramToken3, paramToken4, paramInt);
/*     */ 
/*     */       
/* 674 */       String str = this.ruleBlock.getIgnoreRule();
/* 675 */       if (!paramBoolean2 && str != null) {
/* 676 */         addElementToCurrentAlt(createOptionalRuleRef(str, paramToken2));
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 681 */       if (paramToken1 != null) {
/* 682 */         this.tool.error("Assignment from token reference only allowed in lexer", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       }
/* 684 */       if (paramToken4 != null) {
/* 685 */         this.tool.error("Token reference arguments only allowed in lexer", this.grammar.getFilename(), paramToken4.getLine(), paramToken4.getColumn());
/*     */       }
/* 687 */       super.refToken(paramToken1, paramToken2, paramToken3, paramToken4, paramBoolean1, paramInt, paramBoolean2);
/* 688 */       TokenRefElement tokenRefElement = new TokenRefElement(this.grammar, paramToken2, paramBoolean1, paramInt);
/* 689 */       addElementToCurrentAlt(tokenRefElement);
/* 690 */       labelElement(tokenRefElement, paramToken3);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void refTokenRange(Token paramToken1, Token paramToken2, Token paramToken3, int paramInt, boolean paramBoolean) {
/* 695 */     if (this.grammar instanceof LexerGrammar) {
/* 696 */       this.tool.error("Token range not allowed in lexer", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       return;
/*     */     } 
/* 699 */     super.refTokenRange(paramToken1, paramToken2, paramToken3, paramInt, paramBoolean);
/* 700 */     TokenRangeElement tokenRangeElement = new TokenRangeElement(this.grammar, paramToken1, paramToken2, paramInt);
/* 701 */     if (tokenRangeElement.end < tokenRangeElement.begin) {
/* 702 */       this.tool.error("Malformed range.", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       return;
/*     */     } 
/* 705 */     addElementToCurrentAlt(tokenRangeElement);
/* 706 */     labelElement(tokenRangeElement, paramToken3);
/*     */   }
/*     */   
/*     */   public void refTreeSpecifier(Token paramToken) {
/* 710 */     (context().currentAlt()).treeSpecifier = paramToken;
/*     */   }
/*     */   
/*     */   public void refWildcard(Token paramToken1, Token paramToken2, int paramInt) {
/* 714 */     super.refWildcard(paramToken1, paramToken2, paramInt);
/* 715 */     WildcardElement wildcardElement = new WildcardElement(this.grammar, paramToken1, paramInt);
/* 716 */     addElementToCurrentAlt(wildcardElement);
/* 717 */     labelElement(wildcardElement, paramToken2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 722 */     super.reset();
/* 723 */     this.blocks = (Stack)new LList();
/* 724 */     this.lastRuleRef = null;
/* 725 */     this.ruleEnd = null;
/* 726 */     this.ruleBlock = null;
/* 727 */     this.nested = 0;
/* 728 */     this.currentExceptionSpec = null;
/* 729 */     this.grammarError = false;
/*     */   }
/*     */   
/*     */   public void setArgOfRuleRef(Token paramToken) {
/* 733 */     super.setArgOfRuleRef(paramToken);
/* 734 */     this.lastRuleRef.setArgs(paramToken.getText());
/*     */   }
/*     */   
/*     */   public static void setBlock(AlternativeBlock paramAlternativeBlock1, AlternativeBlock paramAlternativeBlock2) {
/* 738 */     paramAlternativeBlock1.setAlternatives(paramAlternativeBlock2.getAlternatives());
/* 739 */     paramAlternativeBlock1.initAction = paramAlternativeBlock2.initAction;
/*     */     
/* 741 */     paramAlternativeBlock1.label = paramAlternativeBlock2.label;
/* 742 */     paramAlternativeBlock1.hasASynPred = paramAlternativeBlock2.hasASynPred;
/* 743 */     paramAlternativeBlock1.hasAnAction = paramAlternativeBlock2.hasAnAction;
/* 744 */     paramAlternativeBlock1.warnWhenFollowAmbig = paramAlternativeBlock2.warnWhenFollowAmbig;
/* 745 */     paramAlternativeBlock1.generateAmbigWarnings = paramAlternativeBlock2.generateAmbigWarnings;
/* 746 */     paramAlternativeBlock1.line = paramAlternativeBlock2.line;
/* 747 */     paramAlternativeBlock1.greedy = paramAlternativeBlock2.greedy;
/* 748 */     paramAlternativeBlock1.greedySet = paramAlternativeBlock2.greedySet;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRuleOption(Token paramToken1, Token paramToken2) {
/* 753 */     this.ruleBlock.setOption(paramToken1, paramToken2);
/*     */   }
/*     */   
/*     */   public void setSubruleOption(Token paramToken1, Token paramToken2) {
/* 757 */     (context()).block.setOption(paramToken1, paramToken2);
/*     */   }
/*     */   
/*     */   public void synPred() {
/* 761 */     if ((context()).block.not) {
/* 762 */       this.tool.error("'~' cannot be applied to syntactic predicate", this.grammar.getFilename(), (context()).block.getLine(), (context()).block.getColumn());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 767 */     SynPredBlock synPredBlock = new SynPredBlock(this.grammar);
/* 768 */     setBlock(synPredBlock, (context()).block);
/* 769 */     BlockContext blockContext = (BlockContext)this.blocks.pop();
/* 770 */     this.blocks.push(new BlockContext());
/* 771 */     (context()).block = synPredBlock;
/* 772 */     (context()).blockEnd = blockContext.blockEnd;
/* 773 */     (context()).blockEnd.block = synPredBlock;
/*     */   }
/*     */   
/*     */   public void zeroOrMoreSubRule() {
/* 777 */     if ((context()).block.not) {
/* 778 */       this.tool.error("'~' cannot be applied to (...)+ subrule", this.grammar.getFilename(), (context()).block.getLine(), (context()).block.getColumn());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 783 */     ZeroOrMoreBlock zeroOrMoreBlock = new ZeroOrMoreBlock(this.grammar);
/* 784 */     setBlock(zeroOrMoreBlock, (context()).block);
/* 785 */     BlockContext blockContext = (BlockContext)this.blocks.pop();
/* 786 */     this.blocks.push(new BlockContext());
/* 787 */     (context()).block = zeroOrMoreBlock;
/* 788 */     (context()).blockEnd = blockContext.blockEnd;
/* 789 */     (context()).blockEnd.block = zeroOrMoreBlock;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\MakeGrammar.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */