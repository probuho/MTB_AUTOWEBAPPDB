package antlr;

import antlr.collections.impl.Vector;
import java.util.Enumeration;

interface TokenManager {
  Object clone();
  
  void define(TokenSymbol paramTokenSymbol);
  
  String getName();
  
  String getTokenStringAt(int paramInt);
  
  TokenSymbol getTokenSymbol(String paramString);
  
  TokenSymbol getTokenSymbolAt(int paramInt);
  
  Enumeration getTokenSymbolElements();
  
  Enumeration getTokenSymbolKeys();
  
  Vector getVocabulary();
  
  boolean isReadOnly();
  
  void mapToTokenSymbol(String paramString, TokenSymbol paramTokenSymbol);
  
  int maxTokenType();
  
  int nextTokenType();
  
  void setName(String paramString);
  
  void setReadOnly(boolean paramBoolean);
  
  boolean tokenDefined(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\TokenManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */