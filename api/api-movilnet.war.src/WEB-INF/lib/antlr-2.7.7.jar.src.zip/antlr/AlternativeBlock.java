/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AlternativeBlock
/*     */   extends AlternativeElement
/*     */ {
/*  14 */   protected String initAction = null;
/*     */   
/*     */   protected Vector alternatives;
/*     */   
/*     */   protected String label;
/*     */   
/*     */   protected int alti;
/*     */   
/*     */   protected int altj;
/*     */   protected int analysisAlt;
/*     */   protected boolean hasAnAction = false;
/*     */   protected boolean hasASynPred = false;
/*  26 */   protected int ID = 0;
/*     */   
/*     */   protected static int nblks;
/*     */   
/*     */   boolean not = false;
/*     */   
/*     */   boolean greedy = true;
/*     */   
/*     */   boolean greedySet = false;
/*     */   
/*     */   protected boolean doAutoGen = true;
/*     */   
/*     */   protected boolean warnWhenFollowAmbig = true;
/*     */   
/*     */   protected boolean generateAmbigWarnings = true;
/*     */   
/*     */   public AlternativeBlock(Grammar paramGrammar) {
/*  43 */     super(paramGrammar);
/*  44 */     this.alternatives = new Vector(5);
/*  45 */     this.not = false;
/*     */     
/*  47 */     this.ID = ++nblks;
/*     */   }
/*     */   
/*     */   public AlternativeBlock(Grammar paramGrammar, Token paramToken, boolean paramBoolean) {
/*  51 */     super(paramGrammar, paramToken);
/*  52 */     this.alternatives = new Vector(5);
/*     */ 
/*     */     
/*  55 */     this.not = paramBoolean;
/*     */     
/*  57 */     this.ID = ++nblks;
/*     */   }
/*     */   
/*     */   public void addAlternative(Alternative paramAlternative) {
/*  61 */     this.alternatives.appendElement(paramAlternative);
/*     */   }
/*     */   
/*     */   public void generate() {
/*  65 */     this.grammar.generator.gen(this);
/*     */   }
/*     */   
/*     */   public Alternative getAlternativeAt(int paramInt) {
/*  69 */     return (Alternative)this.alternatives.elementAt(paramInt);
/*     */   }
/*     */   
/*     */   public Vector getAlternatives() {
/*  73 */     return this.alternatives;
/*     */   }
/*     */   
/*     */   public boolean getAutoGen() {
/*  77 */     return this.doAutoGen;
/*     */   }
/*     */   
/*     */   public String getInitAction() {
/*  81 */     return this.initAction;
/*     */   }
/*     */   
/*     */   public String getLabel() {
/*  85 */     return this.label;
/*     */   }
/*     */   
/*     */   public Lookahead look(int paramInt) {
/*  89 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*     */   }
/*     */   
/*     */   public void prepareForAnalysis() {
/*  93 */     for (byte b = 0; b < this.alternatives.size(); b++) {
/*     */       
/*  95 */       Alternative alternative = (Alternative)this.alternatives.elementAt(b);
/*  96 */       alternative.cache = new Lookahead[this.grammar.maxk + 1];
/*  97 */       alternative.lookaheadDepth = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTrackingOfRuleRefs(Grammar paramGrammar) {
/* 106 */     for (byte b = 0; b < this.alternatives.size(); b++) {
/* 107 */       Alternative alternative = getAlternativeAt(b);
/* 108 */       AlternativeElement alternativeElement = alternative.head;
/* 109 */       while (alternativeElement != null) {
/* 110 */         if (alternativeElement instanceof RuleRefElement) {
/* 111 */           RuleRefElement ruleRefElement = (RuleRefElement)alternativeElement;
/* 112 */           RuleSymbol ruleSymbol = (RuleSymbol)paramGrammar.getSymbol(ruleRefElement.targetRule);
/* 113 */           if (ruleSymbol == null) {
/* 114 */             this.grammar.antlrTool.error("rule " + ruleRefElement.targetRule + " referenced in (...)=>, but not defined");
/*     */           } else {
/*     */             
/* 117 */             ruleSymbol.references.removeElement(ruleRefElement);
/*     */           }
/*     */         
/* 120 */         } else if (alternativeElement instanceof AlternativeBlock) {
/* 121 */           ((AlternativeBlock)alternativeElement).removeTrackingOfRuleRefs(paramGrammar);
/*     */         } 
/* 123 */         alternativeElement = alternativeElement.next;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setAlternatives(Vector paramVector) {
/* 129 */     this.alternatives = paramVector;
/*     */   }
/*     */   
/*     */   public void setAutoGen(boolean paramBoolean) {
/* 133 */     this.doAutoGen = paramBoolean;
/*     */   }
/*     */   
/*     */   public void setInitAction(String paramString) {
/* 137 */     this.initAction = paramString;
/*     */   }
/*     */   
/*     */   public void setLabel(String paramString) {
/* 141 */     this.label = paramString;
/*     */   }
/*     */   
/*     */   public void setOption(Token paramToken1, Token paramToken2) {
/* 145 */     if (paramToken1.getText().equals("warnWhenFollowAmbig")) {
/* 146 */       if (paramToken2.getText().equals("true")) {
/* 147 */         this.warnWhenFollowAmbig = true;
/*     */       }
/* 149 */       else if (paramToken2.getText().equals("false")) {
/* 150 */         this.warnWhenFollowAmbig = false;
/*     */       } else {
/*     */         
/* 153 */         this.grammar.antlrTool.error("Value for warnWhenFollowAmbig must be true or false", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       }
/*     */     
/* 156 */     } else if (paramToken1.getText().equals("generateAmbigWarnings")) {
/* 157 */       if (paramToken2.getText().equals("true")) {
/* 158 */         this.generateAmbigWarnings = true;
/*     */       }
/* 160 */       else if (paramToken2.getText().equals("false")) {
/* 161 */         this.generateAmbigWarnings = false;
/*     */       } else {
/*     */         
/* 164 */         this.grammar.antlrTool.error("Value for generateAmbigWarnings must be true or false", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       }
/*     */     
/* 167 */     } else if (paramToken1.getText().equals("greedy")) {
/* 168 */       if (paramToken2.getText().equals("true")) {
/* 169 */         this.greedy = true;
/* 170 */         this.greedySet = true;
/*     */       }
/* 172 */       else if (paramToken2.getText().equals("false")) {
/* 173 */         this.greedy = false;
/* 174 */         this.greedySet = true;
/*     */       } else {
/*     */         
/* 177 */         this.grammar.antlrTool.error("Value for greedy must be true or false", this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */       } 
/*     */     } else {
/*     */       
/* 181 */       this.grammar.antlrTool.error("Invalid subrule option: " + paramToken1.getText(), this.grammar.getFilename(), paramToken1.getLine(), paramToken1.getColumn());
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 186 */     String str = " (";
/* 187 */     if (this.initAction != null) {
/* 188 */       str = str + this.initAction;
/*     */     }
/* 190 */     for (byte b = 0; b < this.alternatives.size(); b++) {
/* 191 */       Alternative alternative = getAlternativeAt(b);
/* 192 */       Lookahead[] arrayOfLookahead = alternative.cache;
/* 193 */       int i = alternative.lookaheadDepth;
/*     */       
/* 195 */       if (i != -1)
/*     */       {
/* 197 */         if (i == Integer.MAX_VALUE) {
/* 198 */           str = str + "{?}:";
/*     */         } else {
/*     */           
/* 201 */           str = str + " {";
/* 202 */           for (byte b1 = 1; b1 <= i; b1++) {
/* 203 */             str = str + arrayOfLookahead[b1].toString(",", this.grammar.tokenManager.getVocabulary());
/* 204 */             if (b1 < i && arrayOfLookahead[b1 + 1] != null) str = str + ";"; 
/*     */           } 
/* 206 */           str = str + "}:";
/*     */         } 
/*     */       }
/* 209 */       AlternativeElement alternativeElement = alternative.head;
/* 210 */       String str1 = alternative.semPred;
/* 211 */       if (str1 != null) {
/* 212 */         str = str + str1;
/*     */       }
/* 214 */       while (alternativeElement != null) {
/* 215 */         str = str + alternativeElement;
/* 216 */         alternativeElement = alternativeElement.next;
/*     */       } 
/* 218 */       if (b < this.alternatives.size() - 1) {
/* 219 */         str = str + " |";
/*     */       }
/*     */     } 
/* 222 */     str = str + " )";
/* 223 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\AlternativeBlock.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */