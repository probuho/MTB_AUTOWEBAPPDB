/*    */ package antlr;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonASTWithHiddenTokens
/*    */   extends CommonAST
/*    */ {
/*    */   protected CommonHiddenStreamToken hiddenBefore;
/*    */   protected CommonHiddenStreamToken hiddenAfter;
/*    */   
/*    */   public CommonASTWithHiddenTokens() {}
/*    */   
/*    */   public CommonASTWithHiddenTokens(Token paramToken) {
/* 23 */     super(paramToken);
/*    */   }
/*    */   
/*    */   public CommonHiddenStreamToken getHiddenAfter() {
/* 27 */     return this.hiddenAfter;
/*    */   }
/*    */   
/*    */   public CommonHiddenStreamToken getHiddenBefore() {
/* 31 */     return this.hiddenBefore;
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize(AST paramAST) {
/* 36 */     this.hiddenBefore = ((CommonASTWithHiddenTokens)paramAST).getHiddenBefore();
/* 37 */     this.hiddenAfter = ((CommonASTWithHiddenTokens)paramAST).getHiddenAfter();
/* 38 */     super.initialize(paramAST);
/*    */   }
/*    */   
/*    */   public void initialize(Token paramToken) {
/* 42 */     CommonHiddenStreamToken commonHiddenStreamToken = (CommonHiddenStreamToken)paramToken;
/* 43 */     super.initialize(commonHiddenStreamToken);
/* 44 */     this.hiddenBefore = commonHiddenStreamToken.getHiddenBefore();
/* 45 */     this.hiddenAfter = commonHiddenStreamToken.getHiddenAfter();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\antlr-2.7.7.jar!\antlr\CommonASTWithHiddenTokens.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */