/*     */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "AplicacionTo", propOrder = {"nombre", "tipoAplicacion", "codigo"})
/*     */ public class AplicacionTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nombre;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoAplicacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigo;
/*     */   
/*     */   public String getNombre() {
/*  55 */     return this.nombre;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNombre(String value) {
/*  67 */     this.nombre = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoAplicacion() {
/*  79 */     return this.tipoAplicacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoAplicacion(String value) {
/*  91 */     this.tipoAplicacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigo() {
/* 103 */     return this.codigo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigo(String value) {
/* 115 */     this.codigo = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\AplicacionTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */