/*     */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "", propOrder = {"string1", "string2", "entradaTo3"})
/*     */ @XmlRootElement(name = "solicitarSaldoElement")
/*     */ public class SolicitarSaldoElement
/*     */ {
/*     */   @XmlElement(name = "String_1", required = true, nillable = true)
/*     */   protected String string1;
/*     */   @XmlElement(name = "String_2", required = true, nillable = true)
/*     */   protected String string2;
/*     */   @XmlElement(name = "EntradaTo_3", required = true, nillable = true)
/*     */   protected EntradaTo entradaTo3;
/*     */   
/*     */   public String getString1() {
/*  57 */     return this.string1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setString1(String value) {
/*  69 */     this.string1 = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString2() {
/*  81 */     return this.string2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setString2(String value) {
/*  93 */     this.string2 = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntradaTo getEntradaTo3() {
/* 105 */     return this.entradaTo3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntradaTo3(EntradaTo value) {
/* 117 */     this.entradaTo3 = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\SolicitarSaldoElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */