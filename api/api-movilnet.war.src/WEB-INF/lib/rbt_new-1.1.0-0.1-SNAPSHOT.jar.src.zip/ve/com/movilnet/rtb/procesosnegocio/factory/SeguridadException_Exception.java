/*    */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*    */ 
/*    */ import javax.xml.ws.WebFault;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebFault(name = "SeguridadExceptionElement", targetNamespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/")
/*    */ public class SeguridadException_Exception
/*    */   extends Exception
/*    */ {
/*    */   private SeguridadException faultInfo;
/*    */   
/*    */   public SeguridadException_Exception(String message, SeguridadException faultInfo) {
/* 30 */     super(message);
/* 31 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SeguridadException_Exception(String message, SeguridadException faultInfo, Throwable cause) {
/* 41 */     super(message, cause);
/* 42 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SeguridadException getFaultInfo() {
/* 51 */     return this.faultInfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\SeguridadException_Exception.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */