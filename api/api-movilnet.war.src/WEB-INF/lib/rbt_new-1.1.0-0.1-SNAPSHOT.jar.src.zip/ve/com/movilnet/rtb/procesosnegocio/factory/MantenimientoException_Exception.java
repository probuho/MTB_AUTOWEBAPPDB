/*    */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*    */ 
/*    */ import javax.xml.ws.WebFault;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebFault(name = "MantenimientoExceptionElement", targetNamespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/")
/*    */ public class MantenimientoException_Exception
/*    */   extends Exception
/*    */ {
/*    */   private MantenimientoException faultInfo;
/*    */   
/*    */   public MantenimientoException_Exception(String message, MantenimientoException faultInfo) {
/* 30 */     super(message);
/* 31 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MantenimientoException_Exception(String message, MantenimientoException faultInfo, Throwable cause) {
/* 41 */     super(message, cause);
/* 42 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MantenimientoException getFaultInfo() {
/* 51 */     return this.faultInfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\MantenimientoException_Exception.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */