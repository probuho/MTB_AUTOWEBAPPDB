/*    */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*    */ 
/*    */ import javax.xml.ws.WebFault;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebFault(name = "ErrorOperacionalExceptionElement", targetNamespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/")
/*    */ public class ErrorOperacionalException_Exception
/*    */   extends Exception
/*    */ {
/*    */   private ErrorOperacionalException faultInfo;
/*    */   
/*    */   public ErrorOperacionalException_Exception(String message, ErrorOperacionalException faultInfo) {
/* 30 */     super(message);
/* 31 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ErrorOperacionalException_Exception(String message, ErrorOperacionalException faultInfo, Throwable cause) {
/* 41 */     super(message, cause);
/* 42 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ErrorOperacionalException getFaultInfo() {
/* 51 */     return this.faultInfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\ErrorOperacionalException_Exception.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */