/*    */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.ws.Service;
/*    */ import javax.xml.ws.WebEndpoint;
/*    */ import javax.xml.ws.WebServiceClient;
/*    */ import javax.xml.ws.WebServiceException;
/*    */ import javax.xml.ws.WebServiceFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebServiceClient(name = "SolicitudSaldoWebService", targetNamespace = "http://bp.procesosnegocio.rtb.movilnet.com.ve/", wsdlLocation = "http://192.168.0.16:8888/SolicitudSaldoServicio/SolicitudSaldoWebServiceSoapHttpPort?WSDL")
/*    */ public class SolicitudSaldoWebService_Service
/*    */   extends Service
/*    */ {
/*    */   private static final URL SOLICITUDSALDOWEBSERVICE_WSDL_LOCATION;
/*    */   private static final WebServiceException SOLICITUDSALDOWEBSERVICE_EXCEPTION;
/* 29 */   private static final QName SOLICITUDSALDOWEBSERVICE_QNAME = new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "SolicitudSaldoWebService");
/*    */   
/*    */   static {
/* 32 */     URL url = null;
/* 33 */     WebServiceException e = null;
/*    */     try {
/* 35 */       url = new URL("http://192.168.0.17:8888/SolicitudSaldoServicio/SolicitudSaldoWebServiceSoapHttpPort?WSDL");
/* 36 */     } catch (MalformedURLException ex) {
/* 37 */       e = new WebServiceException(ex);
/*    */     } 
/* 39 */     SOLICITUDSALDOWEBSERVICE_WSDL_LOCATION = url;
/* 40 */     SOLICITUDSALDOWEBSERVICE_EXCEPTION = e;
/*    */   }
/*    */   
/*    */   public SolicitudSaldoWebService_Service() {
/* 44 */     super(__getWsdlLocation(), SOLICITUDSALDOWEBSERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public SolicitudSaldoWebService_Service(WebServiceFeature... features) {
/* 48 */     super(__getWsdlLocation(), SOLICITUDSALDOWEBSERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public SolicitudSaldoWebService_Service(URL wsdlLocation) {
/* 52 */     super(wsdlLocation, SOLICITUDSALDOWEBSERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public SolicitudSaldoWebService_Service(URL wsdlLocation, WebServiceFeature... features) {
/* 56 */     super(wsdlLocation, SOLICITUDSALDOWEBSERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public SolicitudSaldoWebService_Service(URL wsdlLocation, QName serviceName) {
/* 60 */     super(wsdlLocation, serviceName);
/*    */   }
/*    */   
/*    */   public SolicitudSaldoWebService_Service(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
/* 64 */     super(wsdlLocation, serviceName, features);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @WebEndpoint(name = "SolicitudSaldoWebServiceSoapHttpPort")
/*    */   public SolicitudSaldoWebService getSolicitudSaldoWebServiceSoapHttpPort() {
/* 74 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "SolicitudSaldoWebServiceSoapHttpPort"), SolicitudSaldoWebService.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @WebEndpoint(name = "SolicitudSaldoWebServiceSoapHttpPort")
/*    */   public SolicitudSaldoWebService getSolicitudSaldoWebServiceSoapHttpPort(WebServiceFeature... features) {
/* 86 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "SolicitudSaldoWebServiceSoapHttpPort"), SolicitudSaldoWebService.class, features);
/*    */   }
/*    */   
/*    */   private static URL __getWsdlLocation() {
/* 90 */     if (SOLICITUDSALDOWEBSERVICE_EXCEPTION != null) {
/* 91 */       throw SOLICITUDSALDOWEBSERVICE_EXCEPTION;
/*    */     }
/* 93 */     return SOLICITUDSALDOWEBSERVICE_WSDL_LOCATION;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\SolicitudSaldoWebService_Service.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */