/*    */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "", propOrder = {"result"})
/*    */ @XmlRootElement(name = "solicitarSaldoResponseElement")
/*    */ public class SolicitarSaldoResponseElement
/*    */ {
/*    */   @XmlElement(required = true, nillable = true)
/*    */   protected List result;
/*    */   
/*    */   public List getResult() {
/* 49 */     return this.result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResult(List value) {
/* 61 */     this.result = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\SolicitarSaldoResponseElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */