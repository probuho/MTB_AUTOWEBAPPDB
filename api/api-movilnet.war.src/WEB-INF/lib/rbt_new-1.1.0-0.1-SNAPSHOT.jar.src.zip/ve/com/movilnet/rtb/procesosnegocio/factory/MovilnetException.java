/*     */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlSeeAlso;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "MovilnetException", propOrder = {"aplicacion", "codigo", "mensaje", "origen", "plataforma", "tipoObjeto", "tipoTransaccion", "transaccionId"})
/*     */ @XmlSeeAlso({ErrorOperacionalException.class, AdvertenciaFuncionalException.class})
/*     */ public class MovilnetException
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String aplicacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String mensaje;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String origen;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String plataforma;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoObjeto;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoTransaccion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String transaccionId;
/*     */   
/*     */   public String getAplicacion() {
/*  80 */     return this.aplicacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAplicacion(String value) {
/*  92 */     this.aplicacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigo() {
/* 104 */     return this.codigo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigo(String value) {
/* 116 */     this.codigo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMensaje() {
/* 128 */     return this.mensaje;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMensaje(String value) {
/* 140 */     this.mensaje = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOrigen() {
/* 152 */     return this.origen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrigen(String value) {
/* 164 */     this.origen = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPlataforma() {
/* 176 */     return this.plataforma;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlataforma(String value) {
/* 188 */     this.plataforma = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoObjeto() {
/* 200 */     return this.tipoObjeto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoObjeto(String value) {
/* 212 */     this.tipoObjeto = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoTransaccion() {
/* 224 */     return this.tipoTransaccion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoTransaccion(String value) {
/* 236 */     this.tipoTransaccion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransaccionId() {
/* 248 */     return this.transaccionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransaccionId(String value) {
/* 260 */     this.transaccionId = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\MovilnetException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */