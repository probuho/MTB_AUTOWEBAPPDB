/*     */ package ve.com.movilnet.rtb.procesosnegocio.factory;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlSchemaType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "SaldoTo", propOrder = {"fechaExpiracion", "montoBalance", "unidadBalance", "balanceDisponible", "factorConversion", "codigoBalance", "descripcionBalance"})
/*     */ public class SaldoTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaExpiracion;
/*     */   @XmlElement(required = true, type = Double.class, nillable = true)
/*     */   protected Double montoBalance;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String unidadBalance;
/*     */   @XmlElement(required = true, type = Double.class, nillable = true)
/*     */   protected Double balanceDisponible;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String factorConversion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigoBalance;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String descripcionBalance;
/*     */   
/*     */   public XMLGregorianCalendar getFechaExpiracion() {
/*  74 */     return this.fechaExpiracion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaExpiracion(XMLGregorianCalendar value) {
/*  86 */     this.fechaExpiracion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getMontoBalance() {
/*  98 */     return this.montoBalance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMontoBalance(Double value) {
/* 110 */     this.montoBalance = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnidadBalance() {
/* 122 */     return this.unidadBalance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnidadBalance(String value) {
/* 134 */     this.unidadBalance = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getBalanceDisponible() {
/* 146 */     return this.balanceDisponible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBalanceDisponible(Double value) {
/* 158 */     this.balanceDisponible = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFactorConversion() {
/* 170 */     return this.factorConversion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFactorConversion(String value) {
/* 182 */     this.factorConversion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigoBalance() {
/* 194 */     return this.codigoBalance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigoBalance(String value) {
/* 206 */     this.codigoBalance = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescripcionBalance() {
/* 218 */     return this.descripcionBalance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescripcionBalance(String value) {
/* 230 */     this.descripcionBalance = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\rbt_new-1.1.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\factory\SaldoTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */