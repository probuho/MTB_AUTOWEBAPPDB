/*      */ package HTTPClient;
/*      */ 
/*      */ import java.awt.Button;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Frame;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.GridLayout;
/*      */ import java.awt.Label;
/*      */ import java.awt.Panel;
/*      */ import java.awt.TextArea;
/*      */ import java.awt.TextField;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class BasicCookieBox
/*      */   extends Frame
/*      */ {
/*      */   private static final String title = "Set Cookie Request";
/*      */   private Dimension screen;
/*      */   private GridBagConstraints constr;
/*      */   private Label name_value_label;
/*      */   private Label domain_value;
/*      */   private Label ports_label;
/*      */   private Label ports_value;
/*      */   private Label path_value;
/*      */   private Label expires_value;
/*      */   private Label discard_note;
/*      */   private Label secure_note;
/*      */   private Label c_url_note;
/*      */   private Panel left_panel;
/*      */   private Panel right_panel;
/*      */   private Label comment_label;
/*      */   private TextArea comment_value;
/*      */   private TextField domain;
/*      */   private Button default_focus;
/*      */   private boolean accept;
/*      */   private boolean accept_domain;
/*      */   
/*      */   BasicCookieBox() {
/*  863 */     super("Set Cookie Request");
/*      */     
/*  865 */     this.screen = getToolkit().getScreenSize();
/*      */     
/*  867 */     addNotify();
/*  868 */     addWindowListener(new Close(this));
/*      */     
/*      */     GridBagLayout layout;
/*  871 */     setLayout(layout = new GridBagLayout());
/*  872 */     this.constr = new GridBagConstraints();
/*      */     
/*  874 */     this.constr.gridwidth = 0;
/*  875 */     this.constr.anchor = 17;
/*  876 */     add(new Label("The server would like to set the following cookie:"), this.constr);
/*      */     
/*  878 */     Panel p = new Panel();
/*  879 */     this.left_panel = new Panel();
/*  880 */     this.left_panel.setLayout(new GridLayout(4, 1));
/*  881 */     this.left_panel.add(new Label("Name=Value:"));
/*  882 */     this.left_panel.add(new Label("Domain:"));
/*  883 */     this.left_panel.add(new Label("Path:"));
/*  884 */     this.left_panel.add(new Label("Expires:"));
/*  885 */     this.ports_label = new Label("Ports:");
/*  886 */     p.add(this.left_panel);
/*      */     
/*  888 */     this.right_panel = new Panel();
/*  889 */     this.right_panel.setLayout(new GridLayout(4, 1));
/*  890 */     this.right_panel.add(this.name_value_label = new Label());
/*  891 */     this.right_panel.add(this.domain_value = new Label());
/*  892 */     this.right_panel.add(this.path_value = new Label());
/*  893 */     this.right_panel.add(this.expires_value = new Label());
/*  894 */     this.ports_value = new Label();
/*  895 */     p.add(this.right_panel);
/*  896 */     add(p, this.constr);
/*  897 */     this.secure_note = new Label("This cookie will only be sent over secure connections");
/*  898 */     this.discard_note = new Label("This cookie will be discarded at the end of the session");
/*  899 */     this.c_url_note = new Label("");
/*  900 */     this.comment_label = new Label("Comment:");
/*  901 */     this.comment_value = 
/*  902 */       new TextArea("", 3, 45, 1);
/*  903 */     this.comment_value.setEditable(false);
/*      */     
/*  905 */     add(new Panel(), this.constr);
/*      */     
/*  907 */     this.constr.gridwidth = 1;
/*  908 */     this.constr.anchor = 10;
/*  909 */     this.constr.weightx = 1.0D;
/*  910 */     add(this.default_focus = new Button("Accept"), this.constr);
/*  911 */     this.default_focus.addActionListener(new Accept(this));
/*      */ 
/*      */     
/*  914 */     this.constr.gridwidth = 0; Button b;
/*  915 */     add(b = new Button("Reject"), this.constr);
/*  916 */     b.addActionListener(new Reject(this));
/*      */     
/*  918 */     this.constr.weightx = 0.0D;
/*  919 */     p = new Separator();
/*  920 */     this.constr.fill = 2;
/*  921 */     add(p, this.constr);
/*      */     
/*  923 */     this.constr.fill = 0;
/*  924 */     this.constr.anchor = 17;
/*  925 */     add(new Label("Accept/Reject all cookies from a host or domain:"), this.constr);
/*      */     
/*  927 */     p = new Panel();
/*  928 */     p.add(new Label("Host/Domain:"));
/*  929 */     p.add(this.domain = new TextField(30));
/*  930 */     add(p, this.constr);
/*      */     
/*  932 */     add(new Label("domains are characterized by a leading dot (`.');"), this.constr);
/*  933 */     add(new Label("an empty string matches all hosts"), this.constr);
/*      */     
/*  935 */     this.constr.anchor = 10;
/*  936 */     this.constr.gridwidth = 1;
/*  937 */     this.constr.weightx = 1.0D;
/*  938 */     add(b = new Button("Accept All"), this.constr);
/*  939 */     b.addActionListener(new AcceptDomain(this));
/*      */     
/*  941 */     this.constr.gridwidth = 0;
/*  942 */     add(b = new Button("Reject All"), this.constr);
/*  943 */     b.addActionListener(new RejectDomain(this));
/*      */     
/*  945 */     pack();
/*      */     
/*  947 */     this.constr.anchor = 17;
/*  948 */     this.constr.gridwidth = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Dimension getMaximumSize() {
/*  954 */     return new Dimension(this.screen.width * 3 / 4, this.screen.height * 3 / 4);
/*      */   }
/*      */   
/*      */   private class Accept implements ActionListener {
/*      */     private final BasicCookieBox this$0;
/*      */     
/*      */     Accept(BasicCookieBox this$0) {
/*  961 */       this.this$0 = this$0; this.this$0 = this$0;
/*      */     }
/*      */     
/*      */     public void actionPerformed(ActionEvent ae) {
/*  965 */       this.this$0.accept = true;
/*  966 */       this.this$0.accept_domain = false;
/*  967 */       synchronized (this.this$0) {
/*  968 */         this.this$0.notifyAll();
/*      */       } 
/*      */     } }
/*      */   private class Reject implements ActionListener { Reject(BasicCookieBox this$0) {
/*  972 */       this.this$0 = this$0; this.this$0 = this$0;
/*      */     }
/*      */     private final BasicCookieBox this$0;
/*      */     public void actionPerformed(ActionEvent ae) {
/*  976 */       this.this$0.accept = false;
/*  977 */       this.this$0.accept_domain = false;
/*  978 */       synchronized (this.this$0) {
/*  979 */         this.this$0.notifyAll();
/*      */       } 
/*      */     } } private class AcceptDomain implements ActionListener { private final BasicCookieBox this$0;
/*      */     AcceptDomain(BasicCookieBox this$0) {
/*  983 */       this.this$0 = this$0; this.this$0 = this$0;
/*      */     }
/*      */     
/*      */     public void actionPerformed(ActionEvent ae) {
/*  987 */       this.this$0.accept = true;
/*  988 */       this.this$0.accept_domain = true;
/*  989 */       synchronized (this.this$0) {
/*  990 */         this.this$0.notifyAll();
/*      */       } 
/*      */     } } private class RejectDomain implements ActionListener { private final BasicCookieBox this$0;
/*      */     RejectDomain(BasicCookieBox this$0) {
/*  994 */       this.this$0 = this$0; this.this$0 = this$0;
/*      */     }
/*      */     
/*      */     public void actionPerformed(ActionEvent ae) {
/*  998 */       this.this$0.accept = false;
/*  999 */       this.this$0.accept_domain = true;
/* 1000 */       synchronized (this.this$0) {
/* 1001 */         this.this$0.notifyAll();
/*      */       } 
/*      */     } }
/*      */   private class Close extends WindowAdapter { private final BasicCookieBox this$0;
/*      */     Close(BasicCookieBox this$0) {
/* 1006 */       this.this$0 = this$0; this.this$0 = this$0;
/*      */     }
/*      */     
/*      */     public void windowClosing(WindowEvent we) {
/* 1010 */       (new BasicCookieBox.Reject(this.this$0)).actionPerformed(null);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean accept(Cookie cookie, DefaultCookiePolicyHandler h, String server) {
/* 1026 */     this.name_value_label.setText(String.valueOf(cookie.getName()) + "=" + cookie.getValue());
/* 1027 */     this.domain_value.setText(cookie.getDomain());
/* 1028 */     this.path_value.setText(cookie.getPath());
/* 1029 */     if (cookie.expires() == null) {
/* 1030 */       this.expires_value.setText("never");
/*      */     } else {
/* 1032 */       this.expires_value.setText(cookie.expires().toString());
/* 1033 */     }  int pos = 2;
/* 1034 */     if (cookie.isSecure())
/* 1035 */       add(this.secure_note, this.constr, pos++); 
/* 1036 */     if (cookie.discard()) {
/* 1037 */       add(this.discard_note, this.constr, pos++);
/*      */     }
/* 1039 */     if (cookie instanceof Cookie2) {
/*      */       
/* 1041 */       Cookie2 cookie2 = (Cookie2)cookie;
/*      */ 
/*      */       
/* 1044 */       if (cookie2.getPorts() != null) {
/*      */         
/* 1046 */         ((GridLayout)this.left_panel.getLayout()).setRows(5);
/* 1047 */         this.left_panel.add(this.ports_label, 2);
/* 1048 */         ((GridLayout)this.right_panel.getLayout()).setRows(5);
/* 1049 */         int[] ports = cookie2.getPorts();
/* 1050 */         StringBuffer plist = new StringBuffer();
/* 1051 */         plist.append(ports[0]);
/* 1052 */         for (int idx = 1; idx < ports.length; idx++) {
/*      */           
/* 1054 */           plist.append(", ");
/* 1055 */           plist.append(ports[idx]);
/*      */         } 
/* 1057 */         this.ports_value.setText(plist.toString());
/* 1058 */         this.right_panel.add(this.ports_value, 2);
/*      */       } 
/*      */ 
/*      */       
/* 1062 */       if (cookie2.getCommentURL() != null) {
/*      */         
/* 1064 */         this.c_url_note.setText("For more info on this cookie see: " + 
/* 1065 */             cookie2.getCommentURL());
/* 1066 */         add(this.c_url_note, this.constr, pos++);
/*      */       } 
/*      */ 
/*      */       
/* 1070 */       if (cookie2.getComment() != null) {
/*      */         
/* 1072 */         this.comment_value.setText(cookie2.getComment());
/* 1073 */         add(this.comment_label, this.constr, pos++);
/* 1074 */         add(this.comment_value, this.constr, pos++);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1081 */     this.name_value_label.invalidate();
/* 1082 */     this.domain_value.invalidate();
/* 1083 */     this.ports_value.invalidate();
/* 1084 */     this.path_value.invalidate();
/* 1085 */     this.expires_value.invalidate();
/* 1086 */     this.left_panel.invalidate();
/* 1087 */     this.right_panel.invalidate();
/* 1088 */     this.secure_note.invalidate();
/* 1089 */     this.discard_note.invalidate();
/* 1090 */     this.c_url_note.invalidate();
/* 1091 */     this.comment_value.invalidate();
/* 1092 */     invalidate();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1097 */     this.domain.setText(cookie.getDomain());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1102 */     setResizable(true);
/* 1103 */     pack();
/* 1104 */     setResizable(false);
/* 1105 */     setLocation((this.screen.width - (getPreferredSize()).width) / 2, 
/* 1106 */         (int)(((this.screen.height - (getPreferredSize()).height) / 2) * 0.7D));
/* 1107 */     setVisible(true);
/* 1108 */     this.default_focus.requestFocus();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1113 */     try { wait(); } catch (InterruptedException interruptedException) {}
/*      */     
/* 1115 */     setVisible(false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1120 */     remove(this.secure_note);
/* 1121 */     remove(this.discard_note);
/* 1122 */     this.left_panel.remove(this.ports_label);
/* 1123 */     ((GridLayout)this.left_panel.getLayout()).setRows(4);
/* 1124 */     this.right_panel.remove(this.ports_value);
/* 1125 */     ((GridLayout)this.right_panel.getLayout()).setRows(4);
/* 1126 */     remove(this.c_url_note);
/* 1127 */     remove(this.comment_label);
/* 1128 */     remove(this.comment_value);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1133 */     if (this.accept_domain) {
/*      */       
/* 1135 */       String dom = this.domain.getText().trim().toLowerCase();
/*      */       
/* 1137 */       if (this.accept) {
/* 1138 */         h.addAcceptDomain(dom);
/*      */       } else {
/* 1140 */         h.addRejectDomain(dom);
/*      */       } 
/*      */     } 
/* 1143 */     return this.accept;
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\httpclient-3.0-alpha1.jar!\HTTPClient\BasicCookieBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */