/*     */ package HTTPClient.doc;
/*     */ 
/*     */ import HTTPClient.AuthorizationInfo;
/*     */ import HTTPClient.AuthorizationPrompter;
/*     */ import HTTPClient.NVPair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MyAuthPrompter
/*     */   implements AuthorizationPrompter
/*     */ {
/*     */   private String pa_name;
/*     */   private String pa_pass;
/*     */   private boolean been_here = false;
/*     */   
/*     */   MyAuthPrompter(String paramString1, String paramString2) {
/*  54 */     this.pa_name = paramString1;
/*  55 */     this.pa_pass = paramString2;
/*     */   }
/*     */ 
/*     */   
/*     */   public NVPair getUsernamePassword(AuthorizationInfo paramAuthorizationInfo, boolean paramBoolean) {
/*  60 */     if (paramBoolean && this.pa_name != null) {
/*     */       
/*  62 */       if (this.been_here) {
/*     */         
/*  64 */         System.out.println();
/*  65 */         System.out.println("Proxy authorization failed");
/*  66 */         return null;
/*     */       } 
/*     */       
/*  69 */       this.been_here = true;
/*  70 */       return new NVPair(this.pa_name, this.pa_pass);
/*     */     } 
/*     */     
/*  73 */     if (this.been_here) {
/*     */       
/*  75 */       System.out.println();
/*  76 */       System.out.println("Proxy authorization succeeded");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     System.out.println();
/*  83 */     if (paramBoolean) {
/*  84 */       System.out.println("The proxy requires authorization");
/*     */     } else {
/*  86 */       System.out.println("The server requires authorization for this resource");
/*     */     } 
/*  88 */     System.out.println();
/*  89 */     System.out.println("Scheme: " + paramAuthorizationInfo.getScheme());
/*  90 */     System.out.println("Realm:  " + paramAuthorizationInfo.getRealm());
/*     */     
/*  92 */     System.out.println();
/*  93 */     System.out.println("Add the following line near the beginning of your application:");
/*  94 */     System.out.println();
/*     */     
/*  96 */     if (paramAuthorizationInfo.getScheme().equalsIgnoreCase("Basic")) {
/*  97 */       System.out.println("    AuthorizationInfo.addBasicAuthorization(\"" + 
/*  98 */           paramAuthorizationInfo.getHost() + "\", " + 
/*  99 */           paramAuthorizationInfo.getPort() + ", \"" + 
/* 100 */           paramAuthorizationInfo.getRealm() + "\", " + 
/* 101 */           "<username>, <password>);");
/* 102 */     } else if (paramAuthorizationInfo.getScheme().equalsIgnoreCase("Digest")) {
/* 103 */       System.out.println("    AuthorizationInfo.addDigestAuthorization(\"" + 
/* 104 */           paramAuthorizationInfo.getHost() + "\", " + 
/* 105 */           paramAuthorizationInfo.getPort() + ", \"" + 
/* 106 */           paramAuthorizationInfo.getRealm() + "\", " + 
/* 107 */           "<username>, <password>);");
/*     */     } else {
/* 109 */       System.out.println("    AuthorizationInfo.addAuthorization(\"" + 
/* 110 */           paramAuthorizationInfo.getHost() + "\", " + 
/* 111 */           paramAuthorizationInfo.getPort() + ", \"" + 
/* 112 */           paramAuthorizationInfo.getScheme() + "\", \"" + 
/* 113 */           paramAuthorizationInfo.getRealm() + "\", " + 
/* 114 */           "...);");
/* 115 */     }  System.out.println();
/*     */     
/* 117 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\httpclient-3.0-alpha1.jar!\HTTPClient\doc\MyAuthPrompter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */