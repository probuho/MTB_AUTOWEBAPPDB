/*     */ package HTTPClient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VerifyMD5
/*     */   implements HashVerifier
/*     */ {
/*     */   RoResponse resp;
/*     */   
/*     */   public VerifyMD5(RoResponse resp) {
/* 138 */     this.resp = resp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void verifyHash(byte[] hash, long len) throws IOException {
/*     */     String hdr;
/*     */     try {
/* 147 */       if ((hdr = this.resp.getHeader("Content-MD5")) == null) {
/* 148 */         hdr = this.resp.getTrailer("Content-MD5");
/*     */       }
/* 150 */     } catch (IOException iOException) {
/*     */       return;
/*     */     } 
/* 153 */     if (hdr == null)
/*     */       return; 
/* 155 */     byte[] ContMD5 = Codecs.base64Decode(hdr.trim().getBytes("8859_1"));
/*     */     
/* 157 */     for (int idx = 0; idx < hash.length; idx++) {
/*     */       
/* 159 */       if (hash[idx] != ContMD5[idx]) {
/* 160 */         throw new IOException("MD5-Digest mismatch: expected " + 
/* 161 */             hex(ContMD5) + " but calculated " + 
/* 162 */             hex(hash));
/*     */       }
/*     */     } 
/* 165 */     Log.write(32, "CMD5M: hash successfully verified");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String hex(byte[] buf) {
/* 174 */     StringBuffer str = new StringBuffer(buf.length * 3);
/* 175 */     for (int idx = 0; idx < buf.length; idx++) {
/*     */       
/* 177 */       str.append(Character.forDigit(buf[idx] >>> 4 & 0xF, 16));
/* 178 */       str.append(Character.forDigit(buf[idx] & 0xF, 16));
/* 179 */       str.append(':');
/*     */     } 
/* 181 */     str.setLength(str.length() - 1);
/*     */     
/* 183 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\httpclient-3.0-alpha1.jar!\HTTPClient\VerifyMD5.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */