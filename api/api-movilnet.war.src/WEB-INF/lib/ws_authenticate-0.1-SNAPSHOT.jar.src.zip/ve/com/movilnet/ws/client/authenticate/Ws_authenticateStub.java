/*     */ package ve.com.movilnet.ws.client.authenticate;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import oracle.soap.transport.http.OracleSOAPHTTPConnection;
/*     */ import org.apache.soap.Fault;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.Response;
/*     */ import org.apache.soap.transport.SOAPTransport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ws_authenticateStub
/*     */ {
/*     */   private String _endpoint;
/*     */   private OracleSOAPHTTPConnection m_httpConnection;
/*     */   private SOAPMappingRegistry m_smr;
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*     */       Ws_authenticateStub stub = new Ws_authenticateStub();
/*     */       stub.setEndpoint("http://161.196.198.121:7777/ws_authenticate/Authentication");
/*     */       String w_result_old = stub.Authenticate("6110648", "1011", "AGL");
/*     */       String w_result_new = stub.AuthenticateFullDigit("1586110648", "1011", "AGL");
/*     */       System.out.println("Resultado Antiguo Formato: " + w_result_old);
/*     */       System.out.println("Resultado Antiguo Formato: " + w_result_old);
/*     */     } catch (Exception ex) {
/*     */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Ws_authenticateStub() {
/*  54 */     this._endpoint = "http://kctm15z:8888/ws_authenticate/Authentication";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.m_httpConnection = null;
/*  67 */     this.m_smr = null;
/*     */     this.m_httpConnection = new OracleSOAPHTTPConnection();
/*     */     this.m_smr = new SOAPMappingRegistry();
/*     */   } public String getEndpoint() { return this._endpoint; } public String AuthenticateFullDigit(String p_user, String p_password, String p_app) throws Exception {
/*  71 */     String returnVal = null;
/*     */     
/*  73 */     URL endpointURL = new URL(this._endpoint);
/*  74 */     Call call = new Call();
/*  75 */     call.setSOAPTransport((SOAPTransport)this.m_httpConnection);
/*  76 */     call.setTargetObjectURI("ws_authenticate");
/*  77 */     call.setMethodName("AuthenticateFullDigit");
/*  78 */     call.setEncodingStyleURI("http://schemas.xmlsoap.org/soap/encoding/");
/*     */     
/*  80 */     Vector params = new Vector();
/*  81 */     params.addElement(new Parameter("p_user", String.class, p_user, null));
/*  82 */     params.addElement(new Parameter("p_password", String.class, p_password, null));
/*  83 */     params.addElement(new Parameter("p_app", String.class, p_app, null));
/*  84 */     call.setParams(params);
/*     */     
/*  86 */     call.setSOAPMappingRegistry(this.m_smr);
/*     */     
/*  88 */     Response response = call.invoke(endpointURL, "");
/*     */     
/*  90 */     if (!response.generatedFault()) {
/*     */       
/*  92 */       Parameter result = response.getReturnValue();
/*  93 */       returnVal = (String)result.getValue();
/*     */     }
/*     */     else {
/*     */       
/*  97 */       Fault fault = response.getFault();
/*  98 */       throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
/*     */     } 
/*     */     
/* 101 */     return returnVal;
/*     */   }
/*     */ 
/*     */   
/*     */   public String Authenticate(String p_user, String p_password, String p_app) throws Exception {
/* 106 */     String returnVal = null;
/*     */     
/* 108 */     URL endpointURL = new URL(this._endpoint);
/* 109 */     Call call = new Call();
/* 110 */     call.setSOAPTransport((SOAPTransport)this.m_httpConnection);
/* 111 */     call.setTargetObjectURI("ws_authenticate");
/* 112 */     call.setMethodName("Authenticate");
/* 113 */     call.setEncodingStyleURI("http://schemas.xmlsoap.org/soap/encoding/");
/*     */     
/* 115 */     Vector params = new Vector();
/* 116 */     params.addElement(new Parameter("p_user", String.class, p_user, null));
/* 117 */     params.addElement(new Parameter("p_password", String.class, p_password, null));
/* 118 */     params.addElement(new Parameter("p_app", String.class, p_app, null));
/* 119 */     call.setParams(params);
/*     */     
/* 121 */     call.setSOAPMappingRegistry(this.m_smr);
/*     */     
/* 123 */     Response response = call.invoke(endpointURL, "");
/*     */     
/* 125 */     if (!response.generatedFault()) {
/*     */       
/* 127 */       Parameter result = response.getReturnValue();
/* 128 */       returnVal = (String)result.getValue();
/*     */     }
/*     */     else {
/*     */       
/* 132 */       Fault fault = response.getFault();
/* 133 */       throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
/*     */     } 
/*     */     
/* 136 */     return returnVal;
/*     */   } public void setEndpoint(String endpoint) {
/*     */     this._endpoint = endpoint;
/*     */   }
/*     */   public void setMaintainSession(boolean maintainSession) {
/* 141 */     this.m_httpConnection.setMaintainSession(maintainSession);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getMaintainSession() {
/* 146 */     return this.m_httpConnection.getMaintainSession();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransportProperties(Properties props) {
/* 151 */     this.m_httpConnection.setProperties(props);
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getTransportProperties() {
/* 156 */     return this.m_httpConnection.getProperties();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate-0.1-SNAPSHOT.jar!\ve\com\movilnet\ws\client\authenticate\Ws_authenticateStub.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */