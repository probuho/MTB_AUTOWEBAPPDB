package ws_authenticate.client.proxy;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface INTUNI_AUTHENTICATE_IMPLPortType extends Remote {
  String authenticate(String paramString1, String paramString2, String paramString3) throws RemoteException;
  
  String authenticateFullDigit(String paramString1, String paramString2, String paramString3) throws RemoteException;
  
  String generateKey(String paramString1, String paramString2, String paramString3, String paramString4) throws RemoteException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\INTUNI_AUTHENTICATE_IMPLPortType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */