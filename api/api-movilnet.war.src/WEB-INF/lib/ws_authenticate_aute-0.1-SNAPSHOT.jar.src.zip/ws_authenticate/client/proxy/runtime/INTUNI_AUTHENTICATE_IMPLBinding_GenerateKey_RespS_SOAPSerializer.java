/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.Initializable;
/*    */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*    */ import oracle.j2ee.ws.common.encoding.ObjectSerializerBase;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*    */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*    */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReaderUtil;
/*    */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*    */ import oracle.j2ee.ws.common.wsdl.document.schema.SchemaConstants;
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/* 21 */   private static final QName ns1_return_QNAME = new QName("", "return");
/* 22 */   private static final QName ns2_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*    */   private CombinedSerializer myns2_string__java_lang_String_String_Serializer;
/*    */   private static final int my_return_INDEX = 0;
/*    */   
/*    */   public INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/* 27 */     super(type, encodeType, isNullable, soapVersion);
/*    */   }
/*    */   
/*    */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 31 */     this.myns2_string__java_lang_String_String_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), String.class, ns2_string_TYPE_QNAME);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/* 36 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS instance = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS();
/* 37 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPBuilder builder = null;
/*    */     
/* 39 */     boolean isComplete = true;
/*    */ 
/*    */     
/* 42 */     reader.nextElementContent();
/* 43 */     QName startName = reader.getName();
/* 44 */     if (reader.getState() == 1) {
/* 45 */       context.setNillable(true);
/* 46 */       Object member = this.myns2_string__java_lang_String_String_Serializer.deserialize(null, reader, context);
/* 47 */       if (member instanceof SOAPDeserializationState) {
/* 48 */         if (builder == null) {
/* 49 */           builder = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPBuilder();
/*    */         }
/* 51 */         state = registerWithMemberState(instance, state, member, 0, builder);
/* 52 */         isComplete = false;
/* 53 */       } else if (member != null) {
/* 54 */         instance.set_return((String)member);
/*    */       } 
/* 56 */       reader.nextElementContent();
/*    */     } 
/* 58 */     QName elementName = reader.getName();
/*    */     
/*    */     try {
/* 61 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 62 */     } catch (XMLReaderException xmle) {
/* 63 */       if (startName != null) {
/* 64 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*    */       }
/* 66 */       throw xmle;
/*    */     } 
/*    */     
/* 69 */     return isComplete ? instance : state;
/*    */   }
/*    */   
/*    */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 73 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS)obj;
/*    */     
/* 75 */     context.setNillable(true);
/* 76 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.get_return(), ns1_return_QNAME, null, writer, context);
/*    */   }
/*    */   public void doSerializeAnyAttributes(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 79 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS)obj;
/*    */   }
/*    */   
/*    */   public void doSerializeAttributes(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 83 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS)obj;
/*    */   }
/*    */   
/*    */   protected void verifyName(XMLReader reader, QName expectedName) throws Exception {}
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */