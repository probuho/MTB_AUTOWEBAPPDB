/*    */ package ws_authenticate.client.proxy;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import javax.xml.rpc.ServiceFactory;
/*    */ import javax.xml.rpc.Stub;
/*    */ import oracle.webservices.OracleStub;
/*    */ import oracle.webservices.transport.ClientTransport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLPortClient
/*    */ {
/*    */   private INTUNI_AUTHENTICATE_IMPLPortType _port;
/*    */   
/*    */   public INTUNI_AUTHENTICATE_IMPLPortClient() throws Exception {
/* 17 */     ServiceFactory factory = ServiceFactory.newInstance();
/* 18 */     this._port = ((Ws_authenticate)factory.loadService(Ws_authenticate.class)).getINTUNI_AUTHENTICATE_IMPLPort();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/*    */     try {
/* 26 */       INTUNI_AUTHENTICATE_IMPLPortClient myPort = new INTUNI_AUTHENTICATE_IMPLPortClient();
/* 27 */       System.out.println("calling " + myPort.getEndpoint());
/*    */     
/*    */     }
/* 30 */     catch (Exception ex) {
/* 31 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String authenticate(String p_user, String p_password, String p_app) throws RemoteException {
/* 40 */     return this._port.authenticate(p_user, p_password, p_app);
/*    */   }
/*    */   
/*    */   public String authenticateFullDigit(String p_user, String p_password, String p_app) throws RemoteException {
/* 44 */     return this._port.authenticateFullDigit(p_user, p_password, p_app);
/*    */   }
/*    */   
/*    */   public String generateKey(String p_subscriber, String p_mail, String p_application_name, String p_origin_application) throws RemoteException {
/* 48 */     return this._port.generateKey(p_subscriber, p_mail, p_application_name, p_origin_application);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public INTUNI_AUTHENTICATE_IMPLPortType getPort() {
/* 57 */     return this._port;
/*    */   }
/*    */   
/*    */   public String getEndpoint() {
/* 61 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.service.endpoint.address");
/*    */   }
/*    */   
/*    */   public void setEndpoint(String endpoint) {
/* 65 */     ((Stub)this._port)._setProperty("javax.xml.rpc.service.endpoint.address", endpoint);
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 69 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.security.auth.password");
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 73 */     ((Stub)this._port)._setProperty("javax.xml.rpc.security.auth.password", password);
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 77 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.security.auth.username");
/*    */   }
/*    */   
/*    */   public void setUsername(String username) {
/* 81 */     ((Stub)this._port)._setProperty("javax.xml.rpc.security.auth.username", username);
/*    */   }
/*    */   
/*    */   public void setMaintainSession(boolean maintainSession) {
/* 85 */     ((Stub)this._port)._setProperty("javax.xml.rpc.session.maintain", Boolean.valueOf(maintainSession));
/*    */   }
/*    */   
/*    */   public boolean getMaintainSession() {
/* 89 */     return ((Boolean)((Stub)this._port)._getProperty("javax.xml.rpc.session.maintain")).booleanValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientTransport getClientTransport() {
/* 96 */     return ((OracleStub)this._port).getClientTransport();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\INTUNI_AUTHENTICATE_IMPLPortClient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */