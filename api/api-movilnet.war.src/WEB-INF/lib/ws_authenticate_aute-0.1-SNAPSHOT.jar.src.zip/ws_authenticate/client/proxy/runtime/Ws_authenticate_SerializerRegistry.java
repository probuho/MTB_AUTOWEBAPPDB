/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.encoding.Deserializer;
/*    */ import javax.xml.rpc.encoding.DeserializerFactory;
/*    */ import javax.xml.rpc.encoding.Serializer;
/*    */ import javax.xml.rpc.encoding.SerializerFactory;
/*    */ import javax.xml.rpc.encoding.TypeMapping;
/*    */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*    */ import oracle.j2ee.ws.client.BasicService;
/*    */ import oracle.j2ee.ws.common.encoding.SerializerConstants;
/*    */ import oracle.j2ee.ws.common.encoding.SerializerRegistryBase;
/*    */ import oracle.j2ee.ws.common.encoding.SingletonDeserializerFactory;
/*    */ import oracle.j2ee.ws.common.encoding.SingletonSerializerFactory;
/*    */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*    */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ws_authenticate_SerializerRegistry
/*    */   extends SerializerRegistryBase
/*    */   implements SerializerConstants
/*    */ {
/*    */   public TypeMappingRegistry getRegistry() {
/* 26 */     TypeMappingRegistry registry = BasicService.createStandardTypeMappingRegistry();
/* 27 */     TypeMapping mapping11 = registry.getTypeMapping(SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_11).getURIEncoding());
/* 28 */     TypeMapping mapping = registry.getTypeMapping("");
/*    */     
/* 30 */     QName type = new QName("ws_authenticate", "AuthenticateFullDigitResponse");
/* 31 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer(type, false, false, SOAPVersion.SOAP_11);
/*    */     
/* 33 */     registerSerializer(mapping11, INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS.class, type, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer);
/*    */ 
/*    */     
/* 36 */     QName qName1 = new QName("ws_authenticate", "GenerateKey");
/* 37 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer(qName1, false, false, SOAPVersion.SOAP_11);
/*    */     
/* 39 */     registerSerializer(mapping11, INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.class, qName1, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer);
/*    */ 
/*    */     
/* 42 */     QName qName2 = new QName("ws_authenticate", "GenerateKeyResponse");
/* 43 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer(qName2, false, false, SOAPVersion.SOAP_11);
/*    */     
/* 45 */     registerSerializer(mapping11, INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS.class, qName2, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer);
/*    */ 
/*    */     
/* 48 */     QName qName3 = new QName("ws_authenticate", "AuthenticateFullDigit");
/* 49 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer(qName3, false, false, SOAPVersion.SOAP_11);
/*    */     
/* 51 */     registerSerializer(mapping11, INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS.class, qName3, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer);
/*    */ 
/*    */     
/* 54 */     QName qName4 = new QName("ws_authenticate", "Authenticate");
/* 55 */     INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer(qName4, false, false, SOAPVersion.SOAP_11);
/*    */     
/* 57 */     registerSerializer(mapping11, INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS.class, qName4, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer);
/*    */ 
/*    */     
/* 60 */     QName qName5 = new QName("ws_authenticate", "AuthenticateResponse");
/* 61 */     INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer(qName5, false, false, SOAPVersion.SOAP_11);
/*    */     
/* 63 */     registerSerializer(mapping11, INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS.class, qName5, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer);
/*    */     
/* 65 */     Ws_authenticate_SerializerRegistry12 internal12Registry = new Ws_authenticate_SerializerRegistry12();
/* 66 */     return internal12Registry.getRegistry(registry);
/*    */   }
/*    */ 
/*    */   
/*    */   private static void registerSerializer(TypeMapping mapping, Class javaType, QName xmlType, Serializer ser) {
/* 71 */     mapping.register(javaType, xmlType, (SerializerFactory)new SingletonSerializerFactory(ser), (DeserializerFactory)new SingletonDeserializerFactory((Deserializer)ser));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\Ws_authenticate_SerializerRegistry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */