/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS _instance;
/*    */   private String p_user;
/*    */   private String p_password;
/*    */   private String p_app;
/*    */   private static final int myp_user_INDEX = 0;
/*    */   private static final int myp_password_INDEX = 1;
/*    */   private static final int myp_app_INDEX = 2;
/*    */   
/*    */   public void setP_user(String p_user) {
/* 25 */     this.p_user = p_user;
/*    */   }
/*    */   
/*    */   public void setP_password(String p_password) {
/* 29 */     this.p_password = p_password;
/*    */   }
/*    */   
/*    */   public void setP_app(String p_app) {
/* 33 */     this.p_app = p_app;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 37 */     switch (memberIndex) {
/*    */       case 0:
/* 39 */         return 6;
/*    */       case 1:
/* 41 */         return 6;
/*    */       case 2:
/* 43 */         return 6;
/*    */     } 
/* 45 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 54 */       switch (index) {
/*    */         case 0:
/* 56 */           this._instance.setP_user((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 59 */           this._instance.setP_password((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 62 */           this._instance.setP_app((String)memberValue);
/*    */           return;
/*    */       } 
/* 65 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 68 */     catch (RuntimeException e) {
/* 69 */       throw e;
/*    */     }
/* 71 */     catch (Exception e) {
/* 72 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 80 */     this._instance = (INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 84 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */