/*     */ package ws_authenticate.client.proxy.runtime;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.HandlerChain;
/*     */ import oracle.j2ee.ws.client.ClientTransportException;
/*     */ import oracle.j2ee.ws.client.SenderException;
/*     */ import oracle.j2ee.ws.client.StreamingSenderState;
/*     */ import oracle.j2ee.ws.client.StubBase;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.JAXRPCSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.soap.message.InternalSOAPMessage;
/*     */ import oracle.j2ee.ws.common.soap.message.SOAPBlockInfo;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.webservices.transport.ClientTransport;
/*     */ import ws_authenticate.client.proxy.INTUNI_AUTHENTICATE_IMPLPortType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class INTUNI_AUTHENTICATE_IMPLBinding_Stub
/*     */   extends StubBase
/*     */   implements INTUNI_AUTHENTICATE_IMPLPortType
/*     */ {
/*     */   public INTUNI_AUTHENTICATE_IMPLBinding_Stub(HandlerChain handlerChain) {
/*  42 */     super(handlerChain);
/*  43 */     _setProperty("javax.xml.rpc.service.endpoint.address", "http://clientest2-vm:8888/ws_authenticate/Authentication");
/*  44 */     setSoapVersion(SOAPVersion.SOAP_11);
/*  45 */     setServiceName(new QName("http://ve/com/movilnet/aster_validate/gateway/INTUNI_AUTHENTICATE_IMPL.wsdl", "ws_authenticate"));
/*  46 */     setPortName(new QName("http://ve/com/movilnet/aster_validate/gateway/INTUNI_AUTHENTICATE_IMPL.wsdl", "INTUNI_AUTHENTICATE_IMPLPort"));
/*  47 */     setupConfig("ws_authenticate/client/proxy/runtime/INTUNI_AUTHENTICATE_IMPLBinding_Stub.xml");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String authenticate(String p_user, String p_password, String p_app) throws RemoteException {
/*  56 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/*  59 */       _state = _start(this._handlerChain);
/*  60 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  61 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/*  64 */       InternalSOAPMessage _request = _state.getRequest();
/*  65 */       _request.setOperationCode(0);
/*  66 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "Authenticate"));
/*     */       
/*  68 */       INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS = new INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS();
/*     */       
/*  70 */       _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS.setP_user(p_user);
/*  71 */       _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS.setP_password(p_password);
/*  72 */       _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS.setP_app(p_app);
/*  73 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_Authenticate_Authenticate_QNAME);
/*  74 */       _bodyBlock.setValue(_myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS);
/*  75 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_Authenticate__INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer);
/*  76 */       _request.setBody(_bodyBlock);
/*     */       
/*  78 */       _state.getMessageContext().setProperty("http.soap.action", "");
/*     */ 
/*     */       
/*  81 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/*  83 */       INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS = null;
/*  84 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  85 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  86 */         _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS = (INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/*  89 */         _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS = (INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/*  93 */       return _myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS.get_return();
/*  94 */     } catch (RemoteException e) {
/*     */       
/*  96 */       throw e;
/*  97 */     } catch (ClientTransportException e) {
/*  98 */       throw new RemoteException("", e);
/*  99 */     } catch (JAXRPCException e) {
/* 100 */       throw e;
/* 101 */     } catch (Exception e) {
/* 102 */       if (e instanceof RuntimeException) {
/* 103 */         throw (RuntimeException)e;
/*     */       }
/* 105 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String authenticateFullDigit(String p_user, String p_password, String p_app) throws RemoteException {
/* 116 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/* 119 */       _state = _start(this._handlerChain);
/* 120 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/* 121 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/* 124 */       InternalSOAPMessage _request = _state.getRequest();
/* 125 */       _request.setOperationCode(1);
/* 126 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "AuthenticateFullDigit"));
/*     */       
/* 128 */       INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS();
/*     */       
/* 130 */       _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS.setP_user(p_user);
/* 131 */       _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS.setP_password(p_password);
/* 132 */       _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS.setP_app(p_app);
/* 133 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_AuthenticateFullDigit_AuthenticateFullDigit_QNAME);
/* 134 */       _bodyBlock.setValue(_myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS);
/* 135 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_AuthenticateFullDigit__INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer);
/* 136 */       _request.setBody(_bodyBlock);
/*     */       
/* 138 */       _state.getMessageContext().setProperty("http.soap.action", "");
/*     */ 
/*     */       
/* 141 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/* 143 */       INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS = null;
/* 144 */       Object _responseObj = _state.getResponse().getBody().getValue();
/* 145 */       if (_responseObj instanceof SOAPDeserializationState) {
/* 146 */         _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS = (INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/* 149 */         _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS = (INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/* 153 */       return _myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS.get_return();
/* 154 */     } catch (RemoteException e) {
/*     */       
/* 156 */       throw e;
/* 157 */     } catch (ClientTransportException e) {
/* 158 */       throw new RemoteException("", e);
/* 159 */     } catch (JAXRPCException e) {
/* 160 */       throw e;
/* 161 */     } catch (Exception e) {
/* 162 */       if (e instanceof RuntimeException) {
/* 163 */         throw (RuntimeException)e;
/*     */       }
/* 165 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateKey(String p_subscriber, String p_mail, String p_application_name, String p_origin_application) throws RemoteException {
/* 176 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/* 179 */       _state = _start(this._handlerChain);
/* 180 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/* 181 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/* 184 */       InternalSOAPMessage _request = _state.getRequest();
/* 185 */       _request.setOperationCode(2);
/* 186 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "GenerateKey"));
/*     */       
/* 188 */       INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS();
/*     */       
/* 190 */       _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.setP_subscriber(p_subscriber);
/* 191 */       _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.setP_mail(p_mail);
/* 192 */       _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.setP_application_name(p_application_name);
/* 193 */       _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.setP_origin_application(p_origin_application);
/* 194 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_GenerateKey_GenerateKey_QNAME);
/* 195 */       _bodyBlock.setValue(_myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS);
/* 196 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_GenerateKey__INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer);
/* 197 */       _request.setBody(_bodyBlock);
/*     */       
/* 199 */       _state.getMessageContext().setProperty("http.soap.action", "");
/*     */ 
/*     */       
/* 202 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/* 204 */       INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS = null;
/* 205 */       Object _responseObj = _state.getResponse().getBody().getValue();
/* 206 */       if (_responseObj instanceof SOAPDeserializationState) {
/* 207 */         _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/* 210 */         _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/* 214 */       return _myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS.get_return();
/* 215 */     } catch (RemoteException e) {
/*     */       
/* 217 */       throw e;
/* 218 */     } catch (ClientTransportException e) {
/* 219 */       throw new RemoteException("", e);
/* 220 */     } catch (JAXRPCException e) {
/* 221 */       throw e;
/* 222 */     } catch (Exception e) {
/* 223 */       if (e instanceof RuntimeException) {
/* 224 */         throw (RuntimeException)e;
/*     */       }
/* 226 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _readFirstBodyElement(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/* 236 */     int opcode = state.getRequest().getOperationCode();
/* 237 */     switch (opcode) {
/*     */       case 0:
/* 239 */         _deserialize_Authenticate(bodyReader, deserializationContext, state);
/*     */         return;
/*     */       case 1:
/* 242 */         _deserialize_AuthenticateFullDigit(bodyReader, deserializationContext, state);
/*     */         return;
/*     */       case 2:
/* 245 */         _deserialize_GenerateKey(bodyReader, deserializationContext, state);
/*     */         return;
/*     */     } 
/* 248 */     throw new SenderException("sender.response.unrecognizedOperation", Integer.toString(opcode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_Authenticate(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 259 */       Object myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespSObj = this.myns1_AuthenticateResponse__INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer.deserialize(ns1_Authenticate_AuthenticateResponse_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 263 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_Authenticate_AuthenticateResponse_QNAME);
/* 264 */       bodyBlock.setValue(myINTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespSObj);
/* 265 */       state.getResponse().setBody(bodyBlock);
/* 266 */     } catch (DeserializationException e) {
/* 267 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 268 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 270 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_AuthenticateFullDigit(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 279 */       Object myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespSObj = this.myns1_AuthenticateFullDigitResponse__INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer.deserialize(ns1_AuthenticateFullDigit_AuthenticateFullDigitResponse_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 283 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_AuthenticateFullDigit_AuthenticateFullDigitResponse_QNAME);
/* 284 */       bodyBlock.setValue(myINTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespSObj);
/* 285 */       state.getResponse().setBody(bodyBlock);
/* 286 */     } catch (DeserializationException e) {
/* 287 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 288 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 290 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_GenerateKey(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 299 */       Object myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespSObj = this.myns1_GenerateKeyResponse__INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer.deserialize(ns1_GenerateKey_GenerateKeyResponse_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 303 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_GenerateKey_GenerateKeyResponse_QNAME);
/* 304 */       bodyBlock.setValue(myINTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespSObj);
/* 305 */       state.getResponse().setBody(bodyBlock);
/* 306 */     } catch (DeserializationException e) {
/* 307 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 308 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 310 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String _getEncodingStyle() {
/* 318 */     return SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding();
/*     */   }
/*     */   
/*     */   public void _setEncodingStyle(String encodingStyle) {
/* 322 */     throw new UnsupportedOperationException("cannot set encoding style");
/*     */   }
/*     */   
/*     */   public ClientTransport getClientTransport() {
/* 326 */     return (ClientTransport)_getTransport();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] _getNamespaceDeclarations() {
/* 337 */     return myNamespace_declarations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName[] _getUnderstoodHeaders() {
/* 344 */     return understoodHeaderNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _handleEmptyBody(XMLReader reader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void _initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 354 */     super._initialize(registry);
/* 355 */     this.myns1_AuthenticateFullDigit__INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS.class, ns1_AuthenticateFullDigit_TYPE_QNAME);
/* 356 */     this.myns1_AuthenticateFullDigitResponse__INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS.class, ns1_AuthenticateFullDigitResponse_TYPE_QNAME);
/* 357 */     this.myns1_GenerateKeyResponse__INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS.class, ns1_GenerateKeyResponse_TYPE_QNAME);
/* 358 */     this.myns1_GenerateKey__INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.class, ns1_GenerateKey_TYPE_QNAME);
/* 359 */     this.myns1_AuthenticateResponse__INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS.class, ns1_AuthenticateResponse_TYPE_QNAME);
/* 360 */     this.myns1_Authenticate__INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS.class, ns1_Authenticate_TYPE_QNAME);
/*     */   }
/*     */   
/* 363 */   private static final QName _portName = new QName("http://ve/com/movilnet/aster_validate/gateway/INTUNI_AUTHENTICATE_IMPL.wsdl", "INTUNI_AUTHENTICATE_IMPLPort");
/*     */   private static final int Authenticate_OPCODE = 0;
/*     */   private static final int AuthenticateFullDigit_OPCODE = 1;
/*     */   private static final int GenerateKey_OPCODE = 2;
/* 367 */   private static final QName ns1_Authenticate_Authenticate_QNAME = new QName("ws_authenticate", "Authenticate");
/* 368 */   private static final QName ns1_Authenticate_TYPE_QNAME = new QName("ws_authenticate", "Authenticate");
/*     */   private CombinedSerializer myns1_Authenticate__INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer;
/* 370 */   private static final QName ns1_Authenticate_AuthenticateResponse_QNAME = new QName("ws_authenticate", "AuthenticateResponse");
/* 371 */   private static final QName ns1_AuthenticateResponse_TYPE_QNAME = new QName("ws_authenticate", "AuthenticateResponse");
/*     */   private CombinedSerializer myns1_AuthenticateResponse__INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer;
/* 373 */   private static final QName ns1_AuthenticateFullDigit_AuthenticateFullDigit_QNAME = new QName("ws_authenticate", "AuthenticateFullDigit");
/* 374 */   private static final QName ns1_AuthenticateFullDigit_TYPE_QNAME = new QName("ws_authenticate", "AuthenticateFullDigit");
/*     */   private CombinedSerializer myns1_AuthenticateFullDigit__INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer;
/* 376 */   private static final QName ns1_AuthenticateFullDigit_AuthenticateFullDigitResponse_QNAME = new QName("ws_authenticate", "AuthenticateFullDigitResponse");
/* 377 */   private static final QName ns1_AuthenticateFullDigitResponse_TYPE_QNAME = new QName("ws_authenticate", "AuthenticateFullDigitResponse");
/*     */   private CombinedSerializer myns1_AuthenticateFullDigitResponse__INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer;
/* 379 */   private static final QName ns1_GenerateKey_GenerateKey_QNAME = new QName("ws_authenticate", "GenerateKey");
/* 380 */   private static final QName ns1_GenerateKey_TYPE_QNAME = new QName("ws_authenticate", "GenerateKey");
/*     */   private CombinedSerializer myns1_GenerateKey__INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer;
/* 382 */   private static final QName ns1_GenerateKey_GenerateKeyResponse_QNAME = new QName("ws_authenticate", "GenerateKeyResponse");
/* 383 */   private static final QName ns1_GenerateKeyResponse_TYPE_QNAME = new QName("ws_authenticate", "GenerateKeyResponse");
/*     */   private CombinedSerializer myns1_GenerateKeyResponse__INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer;
/* 385 */   private static final String[] myNamespace_declarations = new String[] { "ns0", "ws_authenticate" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 390 */   private static final QName[] understoodHeaderNames = new QName[0];
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_Stub.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */