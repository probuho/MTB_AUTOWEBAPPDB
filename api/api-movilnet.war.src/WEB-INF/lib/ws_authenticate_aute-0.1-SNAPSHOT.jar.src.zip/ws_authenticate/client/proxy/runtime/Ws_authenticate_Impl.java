/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import java.rmi.Remote;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.ServiceException;
/*    */ import javax.xml.rpc.handler.HandlerChain;
/*    */ import oracle.j2ee.ws.client.BasicService;
/*    */ import oracle.j2ee.ws.client.HandlerChainImpl;
/*    */ import oracle.j2ee.ws.client.ServiceExceptionImpl;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ws_authenticate.client.proxy.INTUNI_AUTHENTICATE_IMPLPortType;
/*    */ import ws_authenticate.client.proxy.Ws_authenticate;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ws_authenticate_Impl
/*    */   extends BasicService
/*    */   implements Ws_authenticate
/*    */ {
/* 21 */   private static final QName serviceName = new QName("http://ve/com/movilnet/aster_validate/gateway/INTUNI_AUTHENTICATE_IMPL.wsdl", "ws_authenticate");
/* 22 */   private static final QName ns1_INTUNI_AUTHENTICATE_IMPLPort_QNAME = new QName("http://ve/com/movilnet/aster_validate/gateway/INTUNI_AUTHENTICATE_IMPL.wsdl", "INTUNI_AUTHENTICATE_IMPLPort");
/* 23 */   private static final Class INTUNI_AUTHENTICATE_IMPLPortType_PortClass = INTUNI_AUTHENTICATE_IMPLPortType.class;
/*    */   
/*    */   public Ws_authenticate_Impl() {
/* 26 */     super(serviceName, new QName[] { ns1_INTUNI_AUTHENTICATE_IMPLPort_QNAME }, (new Ws_authenticate_SerializerRegistry()).getRegistry());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Remote getPort(QName portName, Class serviceDefInterface) throws ServiceException {
/*    */     try {
/* 35 */       if (portName.equals(ns1_INTUNI_AUTHENTICATE_IMPLPort_QNAME) && serviceDefInterface.equals(INTUNI_AUTHENTICATE_IMPLPortType_PortClass))
/*    */       {
/* 37 */         return (Remote)getINTUNI_AUTHENTICATE_IMPLPort();
/*    */       }
/* 39 */     } catch (Exception e) {
/* 40 */       throw new ServiceExceptionImpl(new LocalizableExceptionAdapter(e));
/*    */     } 
/* 42 */     return super.getPort(portName, serviceDefInterface);
/*    */   }
/*    */   
/*    */   public Remote getPort(Class serviceDefInterface) throws ServiceException {
/*    */     try {
/* 47 */       if (serviceDefInterface.equals(INTUNI_AUTHENTICATE_IMPLPortType_PortClass)) {
/* 48 */         return (Remote)getINTUNI_AUTHENTICATE_IMPLPort();
/*    */       }
/* 50 */     } catch (Exception e) {
/* 51 */       throw new ServiceExceptionImpl(new LocalizableExceptionAdapter(e));
/*    */     } 
/* 53 */     return super.getPort(serviceDefInterface);
/*    */   }
/*    */   
/*    */   public INTUNI_AUTHENTICATE_IMPLPortType getINTUNI_AUTHENTICATE_IMPLPort() {
/* 57 */     String[] roles = new String[0];
/* 58 */     HandlerChainImpl handlerChain = new HandlerChainImpl(getHandlerRegistry().getHandlerChain(ns1_INTUNI_AUTHENTICATE_IMPLPort_QNAME));
/* 59 */     handlerChain.setRoles(roles);
/* 60 */     INTUNI_AUTHENTICATE_IMPLBinding_Stub stub = new INTUNI_AUTHENTICATE_IMPLBinding_Stub((HandlerChain)handlerChain);
/*    */     try {
/* 62 */       stub._initialize(this.internalTypeRegistry);
/* 63 */     } catch (JAXRPCException e) {
/* 64 */       throw e;
/* 65 */     } catch (Exception e) {
/* 66 */       throw new JAXRPCException(e.getMessage(), e);
/*    */     } 
/* 68 */     return stub;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\Ws_authenticate_Impl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */