/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS _instance;
/*    */   private String _return;
/*    */   private static final int my_return_INDEX = 0;
/*    */   
/*    */   public void set_return(String _return) {
/* 21 */     this._return = _return;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 25 */     switch (memberIndex) {
/*    */       case 0:
/* 27 */         return 6;
/*    */     } 
/* 29 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 38 */       switch (index) {
/*    */         case 0:
/* 40 */           this._instance.set_return((String)memberValue);
/*    */           return;
/*    */       } 
/* 43 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 46 */     catch (RuntimeException e) {
/* 47 */       throw e;
/*    */     }
/* 49 */     catch (Exception e) {
/* 50 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 58 */     this._instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 62 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */