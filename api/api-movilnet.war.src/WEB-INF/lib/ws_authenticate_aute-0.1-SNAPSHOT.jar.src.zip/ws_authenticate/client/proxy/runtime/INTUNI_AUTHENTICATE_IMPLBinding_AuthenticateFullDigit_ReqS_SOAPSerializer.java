/*     */ package ws_authenticate.client.proxy.runtime;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.Initializable;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.ObjectSerializerBase;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderUtil;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import oracle.j2ee.ws.common.wsdl.document.schema.SchemaConstants;
/*     */ 
/*     */ public class INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*  21 */   private static final QName ns1_p_user_QNAME = new QName("", "p_user");
/*  22 */   private static final QName ns2_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns2_string__java_lang_String_String_Serializer;
/*  24 */   private static final QName ns1_p_password_QNAME = new QName("", "p_password");
/*  25 */   private static final QName ns1_p_app_QNAME = new QName("", "p_app");
/*     */   private static final int myp_user_INDEX = 0;
/*     */   private static final int myp_password_INDEX = 1;
/*     */   private static final int myp_app_INDEX = 2;
/*     */   
/*     */   public INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  31 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  35 */     this.myns2_string__java_lang_String_String_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), String.class, ns2_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  40 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS instance = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS();
/*  41 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPBuilder builder = null;
/*     */     
/*  43 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  46 */     reader.nextElementContent();
/*  47 */     QName startName = reader.getName();
/*  48 */     for (int i = 0; i < 3; i++) {
/*  49 */       QName elementName = reader.getName();
/*  50 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  53 */       if (matchQName(elementName, ns1_p_user_QNAME)) {
/*  54 */         context.setNillable(true);
/*  55 */         Object member = this.myns2_string__java_lang_String_String_Serializer.deserialize(ns1_p_user_QNAME, reader, context);
/*  56 */         if (member instanceof SOAPDeserializationState) {
/*  57 */           if (builder == null) {
/*  58 */             builder = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPBuilder();
/*     */           }
/*  60 */           state = registerWithMemberState(instance, state, member, 0, builder);
/*  61 */           isComplete = false;
/*  62 */         } else if (member != null) {
/*  63 */           instance.setP_user((String)member);
/*     */         } 
/*  65 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  68 */       else if (matchQName(elementName, ns1_p_password_QNAME)) {
/*  69 */         context.setNillable(true);
/*  70 */         Object object = this.myns2_string__java_lang_String_String_Serializer.deserialize(ns1_p_password_QNAME, reader, context);
/*  71 */         if (object instanceof SOAPDeserializationState) {
/*  72 */           if (builder == null) {
/*  73 */             builder = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPBuilder();
/*     */           }
/*  75 */           state = registerWithMemberState(instance, state, object, 1, builder);
/*  76 */           isComplete = false;
/*  77 */         } else if (object != null) {
/*  78 */           instance.setP_password((String)object);
/*     */         } 
/*  80 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  83 */       else if (matchQName(elementName, ns1_p_app_QNAME)) {
/*  84 */         context.setNillable(true);
/*  85 */         Object object = this.myns2_string__java_lang_String_String_Serializer.deserialize(ns1_p_app_QNAME, reader, context);
/*  86 */         if (object instanceof SOAPDeserializationState) {
/*  87 */           if (builder == null) {
/*  88 */             builder = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPBuilder();
/*     */           }
/*  90 */           state = registerWithMemberState(instance, state, object, 2, builder);
/*  91 */           isComplete = false;
/*  92 */         } else if (object != null) {
/*  93 */           instance.setP_app((String)object);
/*     */         } 
/*  95 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/*  98 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns1_p_app_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 103 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 104 */     } catch (XMLReaderException xmle) {
/* 105 */       if (startName != null) {
/* 106 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 108 */       throw xmle;
/*     */     } 
/*     */     
/* 111 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 115 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS instance = (INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS)obj;
/*     */     
/* 117 */     context.setNillable(true);
/* 118 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.getP_user(), ns1_p_user_QNAME, null, writer, context);
/* 119 */     context.setNillable(true);
/* 120 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.getP_password(), ns1_p_password_QNAME, null, writer, context);
/* 121 */     context.setNillable(true);
/* 122 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.getP_app(), ns1_p_app_QNAME, null, writer, context);
/*     */   }
/*     */   public void doSerializeAnyAttributes(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 125 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS instance = (INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS)obj;
/*     */   }
/*     */   
/*     */   public void doSerializeAttributes(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 129 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS instance = (INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS)obj;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */