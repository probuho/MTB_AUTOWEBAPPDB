/*     */ package ws_authenticate.client.proxy.runtime;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.Initializable;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.ObjectSerializerBase;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderUtil;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import oracle.j2ee.ws.common.wsdl.document.schema.SchemaConstants;
/*     */ 
/*     */ public class INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*  21 */   private static final QName ns1_p_subscriber_QNAME = new QName("", "p_subscriber");
/*  22 */   private static final QName ns2_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns2_string__java_lang_String_String_Serializer;
/*  24 */   private static final QName ns1_p_mail_QNAME = new QName("", "p_mail");
/*  25 */   private static final QName ns1_p_application_name_QNAME = new QName("", "p_application_name");
/*  26 */   private static final QName ns1_p_origin_application_QNAME = new QName("", "p_origin_application");
/*     */   private static final int myp_subscriber_INDEX = 0;
/*     */   private static final int myp_mail_INDEX = 1;
/*     */   private static final int myp_application_name_INDEX = 2;
/*     */   private static final int myp_origin_application_INDEX = 3;
/*     */   
/*     */   public INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  33 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  37 */     this.myns2_string__java_lang_String_String_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), String.class, ns2_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  42 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS instance = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS();
/*  43 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPBuilder builder = null;
/*     */     
/*  45 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  48 */     reader.nextElementContent();
/*  49 */     QName startName = reader.getName();
/*  50 */     for (int i = 0; i < 4; i++) {
/*  51 */       QName elementName = reader.getName();
/*  52 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  55 */       if (matchQName(elementName, ns1_p_subscriber_QNAME)) {
/*  56 */         context.setNillable(true);
/*  57 */         Object member = this.myns2_string__java_lang_String_String_Serializer.deserialize(ns1_p_subscriber_QNAME, reader, context);
/*  58 */         if (member instanceof SOAPDeserializationState) {
/*  59 */           if (builder == null) {
/*  60 */             builder = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPBuilder();
/*     */           }
/*  62 */           state = registerWithMemberState(instance, state, member, 0, builder);
/*  63 */           isComplete = false;
/*  64 */         } else if (member != null) {
/*  65 */           instance.setP_subscriber((String)member);
/*     */         } 
/*  67 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  70 */       else if (matchQName(elementName, ns1_p_mail_QNAME)) {
/*  71 */         context.setNillable(true);
/*  72 */         Object object = this.myns2_string__java_lang_String_String_Serializer.deserialize(ns1_p_mail_QNAME, reader, context);
/*  73 */         if (object instanceof SOAPDeserializationState) {
/*  74 */           if (builder == null) {
/*  75 */             builder = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPBuilder();
/*     */           }
/*  77 */           state = registerWithMemberState(instance, state, object, 1, builder);
/*  78 */           isComplete = false;
/*  79 */         } else if (object != null) {
/*  80 */           instance.setP_mail((String)object);
/*     */         } 
/*  82 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  85 */       else if (matchQName(elementName, ns1_p_application_name_QNAME)) {
/*  86 */         context.setNillable(true);
/*  87 */         Object object = this.myns2_string__java_lang_String_String_Serializer.deserialize(ns1_p_application_name_QNAME, reader, context);
/*  88 */         if (object instanceof SOAPDeserializationState) {
/*  89 */           if (builder == null) {
/*  90 */             builder = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPBuilder();
/*     */           }
/*  92 */           state = registerWithMemberState(instance, state, object, 2, builder);
/*  93 */           isComplete = false;
/*  94 */         } else if (object != null) {
/*  95 */           instance.setP_application_name((String)object);
/*     */         } 
/*  97 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 100 */       else if (matchQName(elementName, ns1_p_origin_application_QNAME)) {
/* 101 */         context.setNillable(true);
/* 102 */         Object object = this.myns2_string__java_lang_String_String_Serializer.deserialize(ns1_p_origin_application_QNAME, reader, context);
/* 103 */         if (object instanceof SOAPDeserializationState) {
/* 104 */           if (builder == null) {
/* 105 */             builder = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPBuilder();
/*     */           }
/* 107 */           state = registerWithMemberState(instance, state, object, 3, builder);
/* 108 */           isComplete = false;
/* 109 */         } else if (object != null) {
/* 110 */           instance.setP_origin_application((String)object);
/*     */         } 
/* 112 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 115 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns1_p_origin_application_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 120 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 121 */     } catch (XMLReaderException xmle) {
/* 122 */       if (startName != null) {
/* 123 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 125 */       throw xmle;
/*     */     } 
/*     */     
/* 128 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 132 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS)obj;
/*     */     
/* 134 */     context.setNillable(true);
/* 135 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.getP_subscriber(), ns1_p_subscriber_QNAME, null, writer, context);
/* 136 */     context.setNillable(true);
/* 137 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.getP_mail(), ns1_p_mail_QNAME, null, writer, context);
/* 138 */     context.setNillable(true);
/* 139 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.getP_application_name(), ns1_p_application_name_QNAME, null, writer, context);
/* 140 */     context.setNillable(true);
/* 141 */     this.myns2_string__java_lang_String_String_Serializer.serialize(instance.getP_origin_application(), ns1_p_origin_application_QNAME, null, writer, context);
/*     */   }
/*     */   public void doSerializeAnyAttributes(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 144 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS)obj;
/*     */   }
/*     */   
/*     */   public void doSerializeAttributes(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 148 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS)obj;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */