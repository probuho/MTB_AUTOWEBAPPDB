/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected String p_user;
/*    */   protected String p_password;
/*    */   protected String p_app;
/*    */   
/*    */   public String getP_user() {
/* 19 */     return this.p_user;
/*    */   }
/*    */   
/*    */   public void setP_user(String p_user) {
/* 23 */     this.p_user = p_user;
/*    */   }
/*    */   
/*    */   public String getP_password() {
/* 27 */     return this.p_password;
/*    */   }
/*    */   
/*    */   public void setP_password(String p_password) {
/* 31 */     this.p_password = p_password;
/*    */   }
/*    */   
/*    */   public String getP_app() {
/* 35 */     return this.p_app;
/*    */   }
/*    */   
/*    */   public void setP_app(String p_app) {
/* 39 */     this.p_app = p_app;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */