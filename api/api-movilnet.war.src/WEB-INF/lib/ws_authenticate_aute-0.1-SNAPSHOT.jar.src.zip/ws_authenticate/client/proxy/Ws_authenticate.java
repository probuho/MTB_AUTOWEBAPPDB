package ws_authenticate.client.proxy;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface Ws_authenticate extends Service {
  INTUNI_AUTHENTICATE_IMPLPortType getINTUNI_AUTHENTICATE_IMPLPort() throws ServiceException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\Ws_authenticate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */