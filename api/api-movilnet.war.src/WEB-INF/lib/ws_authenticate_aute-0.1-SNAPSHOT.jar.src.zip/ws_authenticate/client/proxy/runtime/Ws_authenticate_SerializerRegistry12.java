/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.encoding.Deserializer;
/*    */ import javax.xml.rpc.encoding.DeserializerFactory;
/*    */ import javax.xml.rpc.encoding.Serializer;
/*    */ import javax.xml.rpc.encoding.SerializerFactory;
/*    */ import javax.xml.rpc.encoding.TypeMapping;
/*    */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*    */ import oracle.j2ee.ws.common.encoding.SerializerConstants;
/*    */ import oracle.j2ee.ws.common.encoding.SingletonDeserializerFactory;
/*    */ import oracle.j2ee.ws.common.encoding.SingletonSerializerFactory;
/*    */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*    */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ws_authenticate_SerializerRegistry12
/*    */   implements SerializerConstants
/*    */ {
/*    */   public TypeMappingRegistry getRegistry(TypeMappingRegistry registry) {
/* 26 */     TypeMapping mapping12 = registry.getTypeMapping(SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_12).getURIEncoding());
/* 27 */     TypeMapping mapping = registry.getTypeMapping("");
/*    */     
/* 29 */     QName type = new QName("ws_authenticate", "AuthenticateFullDigitResponse");
/* 30 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer(type, false, false, SOAPVersion.SOAP_12);
/*    */     
/* 32 */     registerSerializer(mapping12, INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS.class, type, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS_SOAPSerializer);
/*    */ 
/*    */     
/* 35 */     QName qName1 = new QName("ws_authenticate", "GenerateKey");
/* 36 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer(qName1, false, false, SOAPVersion.SOAP_12);
/*    */     
/* 38 */     registerSerializer(mapping12, INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.class, qName1, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPSerializer);
/*    */ 
/*    */     
/* 41 */     QName qName2 = new QName("ws_authenticate", "GenerateKeyResponse");
/* 42 */     INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer(qName2, false, false, SOAPVersion.SOAP_12);
/*    */     
/* 44 */     registerSerializer(mapping12, INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS.class, qName2, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_RespS_SOAPSerializer);
/*    */ 
/*    */     
/* 47 */     QName qName3 = new QName("ws_authenticate", "AuthenticateFullDigit");
/* 48 */     INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer(qName3, false, false, SOAPVersion.SOAP_12);
/*    */     
/* 50 */     registerSerializer(mapping12, INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS.class, qName3, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_ReqS_SOAPSerializer);
/*    */ 
/*    */     
/* 53 */     QName qName4 = new QName("ws_authenticate", "Authenticate");
/* 54 */     INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer(qName4, false, false, SOAPVersion.SOAP_12);
/*    */     
/* 56 */     registerSerializer(mapping12, INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS.class, qName4, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_ReqS_SOAPSerializer);
/*    */ 
/*    */     
/* 59 */     QName qName5 = new QName("ws_authenticate", "AuthenticateResponse");
/* 60 */     INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer = new INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer(qName5, false, false, SOAPVersion.SOAP_12);
/*    */     
/* 62 */     registerSerializer(mapping12, INTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS.class, qName5, (Serializer)iNTUNI_AUTHENTICATE_IMPLBinding_Authenticate_RespS_SOAPSerializer);
/*    */     
/* 64 */     return registry;
/*    */   }
/*    */ 
/*    */   
/*    */   private static void registerSerializer(TypeMapping mapping, Class javaType, QName xmlType, Serializer ser) {
/* 69 */     mapping.register(javaType, xmlType, (SerializerFactory)new SingletonSerializerFactory(ser), (DeserializerFactory)new SingletonDeserializerFactory((Deserializer)ser));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\Ws_authenticate_SerializerRegistry12.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */