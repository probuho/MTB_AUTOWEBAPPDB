/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected String p_subscriber;
/*    */   protected String p_mail;
/*    */   protected String p_application_name;
/*    */   protected String p_origin_application;
/*    */   
/*    */   public String getP_subscriber() {
/* 20 */     return this.p_subscriber;
/*    */   }
/*    */   
/*    */   public void setP_subscriber(String p_subscriber) {
/* 24 */     this.p_subscriber = p_subscriber;
/*    */   }
/*    */   
/*    */   public String getP_mail() {
/* 28 */     return this.p_mail;
/*    */   }
/*    */   
/*    */   public void setP_mail(String p_mail) {
/* 32 */     this.p_mail = p_mail;
/*    */   }
/*    */   
/*    */   public String getP_application_name() {
/* 36 */     return this.p_application_name;
/*    */   }
/*    */   
/*    */   public void setP_application_name(String p_application_name) {
/* 40 */     this.p_application_name = p_application_name;
/*    */   }
/*    */   
/*    */   public String getP_origin_application() {
/* 44 */     return this.p_origin_application;
/*    */   }
/*    */   
/*    */   public void setP_origin_application(String p_origin_application) {
/* 48 */     this.p_origin_application = p_origin_application;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */