/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS
/*    */   implements Serializable
/*    */ {
/*    */   protected String _return;
/*    */   
/*    */   public String get_return() {
/* 17 */     return this._return;
/*    */   }
/*    */   
/*    */   public void set_return(String _return) {
/* 21 */     this._return = _return;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_AuthenticateFullDigit_RespS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */