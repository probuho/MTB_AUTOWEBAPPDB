/*    */ package ws_authenticate.client.proxy.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS _instance;
/*    */   private String p_subscriber;
/*    */   private String p_mail;
/*    */   private String p_application_name;
/*    */   private String p_origin_application;
/*    */   private static final int myp_subscriber_INDEX = 0;
/*    */   private static final int myp_mail_INDEX = 1;
/*    */   private static final int myp_application_name_INDEX = 2;
/*    */   private static final int myp_origin_application_INDEX = 3;
/*    */   
/*    */   public void setP_subscriber(String p_subscriber) {
/* 27 */     this.p_subscriber = p_subscriber;
/*    */   }
/*    */   
/*    */   public void setP_mail(String p_mail) {
/* 31 */     this.p_mail = p_mail;
/*    */   }
/*    */   
/*    */   public void setP_application_name(String p_application_name) {
/* 35 */     this.p_application_name = p_application_name;
/*    */   }
/*    */   
/*    */   public void setP_origin_application(String p_origin_application) {
/* 39 */     this.p_origin_application = p_origin_application;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 43 */     switch (memberIndex) {
/*    */       case 0:
/* 45 */         return 6;
/*    */       case 1:
/* 47 */         return 6;
/*    */       case 2:
/* 49 */         return 6;
/*    */       case 3:
/* 51 */         return 6;
/*    */     } 
/* 53 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 62 */       switch (index) {
/*    */         case 0:
/* 64 */           this._instance.setP_subscriber((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 67 */           this._instance.setP_mail((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 70 */           this._instance.setP_application_name((String)memberValue);
/*    */           return;
/*    */         case 3:
/* 73 */           this._instance.setP_origin_application((String)memberValue);
/*    */           return;
/*    */       } 
/* 76 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 79 */     catch (RuntimeException e) {
/* 80 */       throw e;
/*    */     }
/* 82 */     catch (Exception e) {
/* 83 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 91 */     this._instance = (INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 95 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\ws_authenticate_aute-0.1-SNAPSHOT.jar!\ws_authenticate\client\proxy\runtime\INTUNI_AUTHENTICATE_IMPLBinding_GenerateKey_ReqS_SOAPBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */