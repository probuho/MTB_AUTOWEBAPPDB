package org.apache.soap.util.xml;

import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.Bean;
import org.w3c.dom.Node;

public interface Deserializer {
  Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\Deserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */