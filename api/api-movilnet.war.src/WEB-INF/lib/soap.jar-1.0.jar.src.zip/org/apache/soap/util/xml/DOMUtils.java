/*     */ package org.apache.soap.util.xml;
/*     */ 
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.CharacterData;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMUtils
/*     */ {
/*  70 */   private static String NS_URI_XMLNS = "http://www.w3.org/2000/xmlns/";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getAttribute(Element paramElement, String paramString) {
/*  82 */     String str = null;
/*  83 */     Attr attr = paramElement.getAttributeNode(paramString);
/*     */     
/*  85 */     if (attr != null) {
/*  86 */       str = attr.getValue();
/*     */     }
/*  88 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getAttributeNS(Element paramElement, String paramString1, String paramString2) {
/* 104 */     String str = null;
/* 105 */     Attr attr = paramElement.getAttributeNodeNS(paramString1, paramString2);
/*     */     
/* 107 */     if (attr != null) {
/* 108 */       str = attr.getValue();
/*     */     }
/*     */     
/* 111 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getChildCharacterData(Element paramElement) {
/* 123 */     if (paramElement == null) {
/* 124 */       return null;
/*     */     }
/* 126 */     Node node = paramElement.getFirstChild();
/* 127 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */     
/* 130 */     while (node != null) {
/* 131 */       CharacterData characterData; switch (node.getNodeType()) { case 3:
/*     */         case 4:
/* 133 */           characterData = (CharacterData)node;
/* 134 */           stringBuffer.append(characterData.getData());
/*     */           break; }
/*     */       
/* 137 */       node = node.getNextSibling();
/*     */     } 
/* 139 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getFirstChildElement(Element paramElement) {
/* 150 */     for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
/* 151 */       if (node.getNodeType() == 1) {
/* 152 */         return (Element)node;
/*     */       }
/*     */     } 
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getNextSiblingElement(Element paramElement) {
/* 166 */     for (Node node = paramElement.getNextSibling(); node != null; node = node.getNextSibling()) {
/* 167 */       if (node.getNodeType() == 1) {
/* 168 */         return (Element)node;
/*     */       }
/*     */     } 
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element findChildElementWithAttribute(Element paramElement, String paramString1, String paramString2) {
/* 187 */     for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
/* 188 */       if (node.getNodeType() == 1 && 
/* 189 */         paramString2.equals(getAttribute((Element)node, paramString1))) {
/* 190 */         return (Element)node;
/*     */       }
/*     */     } 
/*     */     
/* 194 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int countKids(Element paramElement, short paramShort) {
/* 205 */     byte b = 0;
/* 206 */     for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
/* 207 */       if (node.getNodeType() == paramShort) {
/* 208 */         b++;
/*     */       }
/*     */     } 
/* 211 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNamespaceURIFromPrefix(Node paramNode, String paramString) {
/*     */     Node node;
/* 228 */     short s = paramNode.getNodeType();
/* 229 */     Element element = null;
/*     */     
/* 231 */     switch (s) {
/*     */ 
/*     */       
/*     */       case 2:
/* 235 */         element = ((Attr)paramNode).getOwnerElement();
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/* 240 */         node = paramNode;
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 245 */         node = paramNode.getParentNode();
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 250 */     while (node != null && node.getNodeType() == 1) {
/*     */       
/* 252 */       Element element1 = (Element)node;
/* 253 */       String str = (paramString == null) ? getAttribute(element1, "xmlns") : getAttributeNS(element1, NS_URI_XMLNS, paramString);
/*     */ 
/*     */ 
/*     */       
/* 257 */       if (str != null)
/*     */       {
/* 259 */         return str;
/*     */       }
/*     */ 
/*     */       
/* 263 */       node = element1.getParentNode();
/*     */     } 
/*     */ 
/*     */     
/* 267 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Element getElementByID(Element paramElement, String paramString) {
/* 272 */     if (paramElement == null)
/* 273 */       return null; 
/* 274 */     String str = paramElement.getAttribute("id");
/* 275 */     if (paramString.equals(str)) {
/* 276 */       return paramElement;
/*     */     }
/* 278 */     NodeList nodeList = paramElement.getChildNodes();
/* 279 */     for (byte b = 0; b < nodeList.getLength(); b++) {
/* 280 */       Node node = nodeList.item(b);
/* 281 */       if (node instanceof Element) {
/* 282 */         Element element = getElementByID((Element)node, paramString);
/* 283 */         if (element != null) {
/* 284 */           return element;
/*     */         }
/*     */       } 
/*     */     } 
/* 288 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName getQualifiedAttributeValue(Element paramElement, String paramString) throws IllegalArgumentException {
/* 295 */     String str = getAttribute(paramElement, paramString);
/*     */     
/* 297 */     if (str != null) {
/*     */       
/* 299 */       int i = str.indexOf(':');
/* 300 */       String str1 = (i != -1) ? str.substring(0, i) : null;
/*     */ 
/*     */       
/* 303 */       String str2 = str.substring(i + 1);
/* 304 */       String str3 = getNamespaceURIFromPrefix(paramElement, str1);
/*     */ 
/*     */       
/* 307 */       if (str3 != null)
/*     */       {
/* 309 */         return new QName(str3, str2);
/*     */       }
/*     */ 
/*     */       
/* 313 */       throw new IllegalArgumentException("Unable to determine namespace of '" + ((str1 != null) ? (str1 + ":") : "") + str2 + "'.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\DOMUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */