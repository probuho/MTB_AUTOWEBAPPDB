/*    */ package org.apache.soap.encoding.soapenc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiRefContext
/*    */ {
/*    */   private static final int ILLEGAL_ID = -1;
/*    */   private static final String MULTIREF_NAME = "multiRef";
/*    */   private int id;
/*    */   private String name;
/*    */   
/*    */   public MultiRefContext() {
/* 73 */     this(-1, "multiRef");
/*    */   }
/*    */   
/*    */   public MultiRefContext(int paramInt, String paramString) {
/* 77 */     this.id = paramInt;
/* 78 */     this.name = paramString;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 82 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(int paramInt) {
/* 86 */     this.id = paramInt;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 90 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\MultiRefContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */