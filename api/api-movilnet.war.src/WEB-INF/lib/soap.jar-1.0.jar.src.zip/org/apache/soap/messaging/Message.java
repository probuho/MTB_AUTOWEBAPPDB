/*     */ package org.apache.soap.messaging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.net.URL;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import oracle.soap.transport.http.OracleSOAPHTTPConnection;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.transport.SOAPTransport;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Message
/*     */ {
/*     */   SOAPTransport st;
/*  90 */   SOAPContext reqCtx = new SOAPContext(), resCtx = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSOAPTransport(SOAPTransport paramSOAPTransport) {
/*  97 */     this.st = paramSOAPTransport;
/*     */   }
/*     */   
/*     */   public SOAPTransport getSOAPTransport() {
/* 101 */     return this.st;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(URL paramURL, String paramString, Envelope paramEnvelope) throws SOAPException {
/* 118 */     if (this.st == null)
/*     */     {
/*     */       
/* 121 */       this.st = (SOAPTransport)new OracleSOAPHTTPConnection();
/*     */     }
/*     */ 
/*     */     
/* 125 */     this.st.send(paramURL, paramString, null, paramEnvelope, null, this.reqCtx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Envelope receiveEnvelope() throws SOAPException {
/* 139 */     if (this.st == null) {
/* 140 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Unable to receive without sending on an appropriate transport.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 145 */       this.resCtx = this.st.getResponseSOAPContext();
/* 146 */       String str = Call.getEnvelopeString(this.st);
/*     */       
/* 148 */       DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/* 149 */       Document document = documentBuilder.parse(new InputSource(new StringReader(str)));
/*     */ 
/*     */       
/* 152 */       if (document == null) {
/* 153 */         throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Parsing error, response was:\n" + str);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 158 */       return Envelope.unmarshall(document.getDocumentElement(), this.resCtx);
/* 159 */     } catch (MessagingException messagingException) {
/* 160 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, messagingException.getMessage(), messagingException);
/*     */     }
/* 162 */     catch (SAXException sAXException) {
/* 163 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Parsing error, response was:\n" + sAXException.getMessage(), sAXException);
/*     */     
/*     */     }
/* 166 */     catch (IOException iOException) {
/* 167 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, iOException.getMessage(), iOException);
/*     */     }
/* 169 */     catch (IllegalArgumentException illegalArgumentException) {
/* 170 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, illegalArgumentException.getMessage(), illegalArgumentException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler receive() throws SOAPException, MessagingException {
/* 183 */     if (this.st == null) {
/* 184 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Unable to receive without sending on an appropriate transport.");
/*     */     }
/*     */ 
/*     */     
/* 188 */     this.st.receive();
/* 189 */     this.resCtx = this.st.getResponseSOAPContext();
/* 190 */     return this.resCtx.getRootPart().getDataHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPContext getRequestSOAPContext() {
/* 198 */     return this.reqCtx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBodyPart(MimeBodyPart paramMimeBodyPart) throws MessagingException {
/* 208 */     this.reqCtx.addBodyPart(paramMimeBodyPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPContext getResponseSOAPContext() {
/* 216 */     return this.resCtx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart findBodyPart(String paramString) {
/* 236 */     if (this.resCtx == null) {
/* 237 */       return null;
/*     */     }
/* 239 */     return this.resCtx.findBodyPart(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPartCount() throws MessagingException {
/* 250 */     if (this.resCtx == null) {
/* 251 */       return 0;
/*     */     }
/* 253 */     return this.resCtx.getCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart getBodyPart(int paramInt) throws IndexOutOfBoundsException {
/* 265 */     if (this.resCtx == null) {
/* 266 */       return null;
/*     */     }
/* 268 */     return this.resCtx.getBodyPart(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart getRootPart() throws MessagingException {
/* 278 */     if (this.resCtx == null) {
/* 279 */       return null;
/*     */     }
/* 281 */     return this.resCtx.getRootPart();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\messaging\Message.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */