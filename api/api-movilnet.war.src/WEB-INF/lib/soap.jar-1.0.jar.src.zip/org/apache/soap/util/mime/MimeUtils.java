/*     */ package org.apache.soap.util.mime;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import javax.mail.internet.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeUtils
/*     */ {
/*     */   private static final String hexmap = "0123456789ABCDEF";
/*     */   
/*     */   public static String getUniqueValue() {
/*  83 */     String str = null;
/*     */     try {
/*  85 */       str = InetAddress.getLocalHost().getHostName();
/*  86 */     } catch (UnknownHostException unknownHostException) {
/*  87 */       str = "localhost";
/*     */     } 
/*     */     
/*  90 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */     
/*  93 */     stringBuffer.append(stringBuffer.hashCode()).append('.').append(System.currentTimeMillis()).append(".apache-soap.").append(str);
/*     */     
/*  95 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEncoding(String paramString1, String paramString2) {
/* 102 */     String str = null;
/*     */     try {
/* 104 */       if (paramString1 != null && !paramString1.equals(""))
/* 105 */         str = (new ContentType(paramString1)).getParameter("charset"); 
/* 106 */     } catch (ParseException parseException) {}
/*     */     
/* 108 */     if (str == null) {
/* 109 */       str = paramString2;
/*     */     } else {
/* 111 */       str = MimeUtility.javaCharset(str);
/*     */     } 
/* 113 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decode(String paramString) {
/* 121 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 123 */     for (byte b = 0; b < paramString.length(); b++) {
/* 124 */       char c = paramString.charAt(b);
/* 125 */       switch (c) {
/*     */         case '+':
/* 127 */           stringBuffer.append(' ');
/*     */           break;
/*     */         case '%':
/* 130 */           stringBuffer.append((char)(("0123456789ABCDEF".indexOf(paramString.charAt(++b)) << 4) + "0123456789ABCDEF".indexOf(paramString.charAt(++b))));
/*     */           break;
/*     */         
/*     */         default:
/* 134 */           stringBuffer.append(c); break;
/*     */       } 
/*     */     } 
/* 137 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\mime\MimeUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */