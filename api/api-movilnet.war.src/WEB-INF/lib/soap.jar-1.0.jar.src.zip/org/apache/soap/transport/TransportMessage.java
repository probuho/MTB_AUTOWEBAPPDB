/*     */ package org.apache.soap.transport;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import javax.mail.internet.ParseException;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.mime.ByteArrayDataSource;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransportMessage
/*     */   implements Serializable
/*     */ {
/*  82 */   protected String contentType = null;
/*  83 */   protected int offset = 0;
/*  84 */   protected byte[] bytes = null;
/*  85 */   protected byte[] tempBytes = null;
/*  86 */   protected String envelope = null;
/*  87 */   protected Hashtable headers = null;
/*  88 */   protected SOAPContext ctx = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int chunkedPage = 1024;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransportMessage() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransportMessage(String paramString, SOAPContext paramSOAPContext, Hashtable paramHashtable) throws IllegalArgumentException, MessagingException, IOException, SOAPException {
/* 107 */     this.envelope = paramString;
/* 108 */     this.ctx = paramSOAPContext;
/* 109 */     if (paramHashtable != null) {
/* 110 */       this.headers = paramHashtable;
/*     */     } else {
/* 112 */       this.headers = new Hashtable();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransportMessage(InputStream paramInputStream, int paramInt, String paramString, SOAPContext paramSOAPContext, Hashtable paramHashtable) throws IllegalArgumentException, MessagingException, IOException, SOAPException {
/* 126 */     if (paramHashtable != null) {
/* 127 */       this.headers = paramHashtable;
/*     */     } else {
/* 129 */       this.headers = new Hashtable();
/* 130 */     }  this.ctx = paramSOAPContext;
/* 131 */     this.contentType = paramString;
/* 132 */     int i = 0;
/* 133 */     int j = 0;
/*     */     
/* 135 */     if (paramInt < 0) {
/*     */ 
/*     */ 
/*     */       
/* 139 */       ArrayList arrayList = new ArrayList();
/* 140 */       this.tempBytes = new byte[1024];
/* 141 */       int k = 0;
/*     */       
/* 143 */       while ((j = paramInputStream.read(this.tempBytes, k, 1024 - k)) >= 0) {
/* 144 */         i += j;
/* 145 */         k += j;
/*     */         
/* 147 */         if (k >= 1024) {
/* 148 */           arrayList.add(this.tempBytes);
/* 149 */           k = 0;
/* 150 */           this.tempBytes = new byte[1024];
/*     */         } 
/*     */       } 
/*     */       
/* 154 */       arrayList.add(this.tempBytes);
/*     */ 
/*     */ 
/*     */       
/* 158 */       if (i < 0) {
/* 159 */         throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, "no data sent");
/*     */       }
/*     */       
/* 162 */       this.bytes = new byte[i];
/*     */       
/* 164 */       Iterator iterator = arrayList.iterator();
/* 165 */       byte b = 0;
/* 166 */       while (iterator.hasNext())
/*     */       {
/* 168 */         this.tempBytes = (byte[])iterator.next();
/* 169 */         for (byte b1 = 0; b1 < 'Ѐ' && 
/* 170 */           i > b; b1++)
/*     */         {
/*     */           
/* 173 */           this.bytes[b++] = this.tempBytes[b1];
/*     */         }
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 180 */       this.bytes = new byte[paramInt];
/*     */ 
/*     */ 
/*     */       
/* 184 */       while (i < paramInt && j >= 0) {
/* 185 */         j = paramInputStream.read(this.bytes, i, paramInt - i);
/* 186 */         i += j;
/*     */       } 
/* 188 */       if (i < paramInt) {
/* 189 */         throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, "Premature end of stream. Data is truncated. Read " + i + " bytes successfully, expected " + paramInt);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void editIncoming(EnvelopeEditor paramEnvelopeEditor) throws SOAPException, IOException, MessagingException {
/* 203 */     editEnvelope(paramEnvelopeEditor, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void editOutgoing(EnvelopeEditor paramEnvelopeEditor) throws SOAPException, IOException, MessagingException {
/* 213 */     editEnvelope(paramEnvelopeEditor, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void editEnvelope(EnvelopeEditor paramEnvelopeEditor, boolean paramBoolean) throws SOAPException, IOException, MessagingException {
/* 221 */     if (paramEnvelopeEditor != null) {
/*     */       
/* 223 */       if (getEnvelope() == null) {
/*     */         return;
/*     */       }
/* 226 */       StringWriter stringWriter = new StringWriter();
/* 227 */       if (paramBoolean) {
/* 228 */         paramEnvelopeEditor.editIncoming(getEnvelopeReader(), stringWriter);
/*     */       } else {
/* 230 */         paramEnvelopeEditor.editOutgoing(getEnvelopeReader(), stringWriter);
/* 231 */       }  stringWriter.flush();
/* 232 */       this.envelope = stringWriter.toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String read() throws IllegalArgumentException, MessagingException, IOException, SOAPException {
/*     */     ContentType contentType2;
/*     */     byte[] arrayOfByte;
/* 248 */     if (this.contentType == null) {
/* 249 */       throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, "Missing content type.");
/*     */     }
/* 251 */     ContentType contentType1 = null;
/*     */     
/*     */     try {
/* 254 */       int i = this.contentType.indexOf(";;");
/* 255 */       if (i != -1) {
/* 256 */         this.contentType = this.contentType.substring(0, i) + this.contentType.substring(i + 1);
/*     */       }
/* 258 */       contentType1 = new ContentType(this.contentType);
/* 259 */     } catch (ParseException parseException) {}
/*     */     
/* 261 */     if (contentType1 == null) {
/* 262 */       throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, "Missing content type.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 267 */     if (contentType1.match("multipart/*")) {
/*     */ 
/*     */       
/* 270 */       ByteArrayDataSource byteArrayDataSource1 = new ByteArrayDataSource(this.bytes, this.contentType);
/*     */ 
/*     */ 
/*     */       
/* 274 */       this.ctx.readMultipart((DataSource)byteArrayDataSource1);
/*     */ 
/*     */       
/* 277 */       MimeBodyPart mimeBodyPart = this.ctx.getRootPart();
/* 278 */       contentType2 = new ContentType(mimeBodyPart.getContentType());
/* 279 */       ByteArrayDataSource byteArrayDataSource2 = new ByteArrayDataSource(mimeBodyPart.getInputStream(), null);
/*     */       
/* 281 */       arrayOfByte = byteArrayDataSource2.toByteArray();
/*     */     } else {
/* 283 */       arrayOfByte = this.bytes;
/* 284 */       contentType2 = contentType1;
/*     */       
/* 286 */       ByteArrayDataSource byteArrayDataSource = new ByteArrayDataSource(this.bytes, this.contentType);
/*     */       
/* 288 */       DataHandler dataHandler = new DataHandler((DataSource)byteArrayDataSource);
/* 289 */       MimeBodyPart mimeBodyPart = new MimeBodyPart();
/* 290 */       mimeBodyPart.setDataHandler(dataHandler);
/* 291 */       this.ctx.addBodyPart(mimeBodyPart);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (contentType2.match("text/*")) {
/* 298 */       String str = contentType2.getParameter("charset");
/*     */       
/* 300 */       if (str == null || str.equals(""))
/* 301 */         str = "iso-8859-1"; 
/* 302 */       this.envelope = new String(arrayOfByte, MimeUtility.javaCharset(str));
/*     */     } 
/*     */     
/* 305 */     return this.envelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Envelope unmarshall(DocumentBuilder paramDocumentBuilder) throws SOAPException {
/*     */     Document document;
/*     */     try {
/* 315 */       document = paramDocumentBuilder.parse(new InputSource(getEnvelopeReader()));
/* 316 */     } catch (Exception exception) {
/* 317 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "parsing error: " + exception);
/*     */     } 
/*     */     
/* 320 */     if (document == null) {
/* 321 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "parsing error: received empty document");
/*     */     }
/*     */ 
/*     */     
/* 325 */     return Envelope.unmarshall(document.getDocumentElement());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws IllegalArgumentException, MessagingException, IOException {
/* 338 */     String str = null;
/* 339 */     if (this.ctx.isRootPartSet()) {
/* 340 */       MimeBodyPart mimeBodyPart = this.ctx.getRootPart();
/* 341 */       if (mimeBodyPart != null)
/*     */       {
/*     */ 
/*     */         
/* 345 */         str = mimeBodyPart.getHeader("Content-Type", null);
/*     */       }
/*     */     } 
/* 348 */     if (str == null)
/* 349 */       str = "text/xml;charset=utf-8"; 
/* 350 */     if (getEnvelope() != null) {
/* 351 */       this.ctx.setRootPart(this.envelope, str);
/*     */     }
/*     */     
/* 354 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/* 356 */     this.ctx.writeTo(byteArrayOutputStream);
/* 357 */     this.bytes = byteArrayOutputStream.toByteArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 363 */     StringBuffer stringBuffer1 = new StringBuffer();
/* 364 */     StringBuffer stringBuffer2 = new StringBuffer();
/* 365 */     boolean bool = true;
/* 366 */     for (this.offset = 0; this.offset < this.bytes.length; this.offset++) {
/* 367 */       if (this.bytes[this.offset] == 10) {
/*     */ 
/*     */         
/* 370 */         if (this.offset + 1 < this.bytes.length && (this.bytes[this.offset + 1] == 32 || this.bytes[this.offset + 1] == 9)) {
/*     */ 
/*     */           
/* 373 */           while (++this.offset + 1 < this.bytes.length && (this.bytes[this.offset + 1] == 32 || this.bytes[this.offset + 1] == 9));
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 379 */           if (stringBuffer1.length() == 0) {
/* 380 */             this.offset++;
/*     */             break;
/*     */           } 
/* 383 */           String str1 = stringBuffer1.toString();
/*     */ 
/*     */           
/* 386 */           if (str1.equals("Content-Type")) {
/* 387 */             this.contentType = stringBuffer2.toString();
/* 388 */             if (this.ctx.getCount() > 1) {
/* 389 */               String str2 = this.ctx.getRootPart().getContentID();
/*     */               
/* 391 */               str2 = str2.substring(1, str2.length() - 1);
/* 392 */               this.contentType += "; type=\"text/xml\"; start=\"" + str2 + '"';
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 397 */           stringBuffer1 = new StringBuffer();
/* 398 */           stringBuffer2 = new StringBuffer();
/* 399 */           bool = true;
/*     */         } 
/* 401 */       } else if (this.bytes[this.offset] != 13) {
/* 402 */         if (bool) {
/* 403 */           if (this.bytes[this.offset] == 58) {
/* 404 */             bool = false;
/* 405 */             this.offset++;
/*     */           } else {
/*     */             
/* 408 */             stringBuffer1.append((char)this.bytes[this.offset]);
/*     */           } 
/*     */         } else {
/* 411 */           stringBuffer2.append((char)this.bytes[this.offset]);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPContext getSOAPContext() {
/* 420 */     return this.ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEnvelope() throws MessagingException, IOException {
/* 429 */     if (this.envelope == null) {
/* 430 */       MimeBodyPart mimeBodyPart = this.ctx.getRootPart();
/* 431 */       if (mimeBodyPart != null && 
/* 432 */         mimeBodyPart.isMimeType("text/*")) {
/* 433 */         ByteArrayDataSource byteArrayDataSource = new ByteArrayDataSource(mimeBodyPart.getInputStream(), mimeBodyPart.getContentType());
/*     */         
/* 435 */         this.envelope = byteArrayDataSource.getText();
/*     */       } 
/*     */     } 
/* 438 */     return this.envelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getEnvelopeReader() throws MessagingException, IOException {
/* 446 */     if (getEnvelope() == null) {
/* 447 */       return null;
/*     */     }
/* 449 */     return new StringReader(this.envelope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvelope(String paramString) {
/* 456 */     this.envelope = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 463 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContentType(String paramString) {
/* 470 */     this.contentType = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getContentLength() {
/* 477 */     return this.bytes.length - this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeader(String paramString1, String paramString2) {
/* 484 */     this.headers.put(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHeader(String paramString) {
/* 491 */     return (String)this.headers.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration getHeaderNames() {
/* 498 */     return this.headers.keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getHeaders() {
/* 505 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream paramOutputStream) throws IOException {
/* 512 */     paramOutputStream.write(this.bytes, this.offset, this.bytes.length - this.offset);
/* 513 */     paramOutputStream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBytes(byte[] paramArrayOfbyte) {
/* 520 */     this.offset = 0;
/* 521 */     this.bytes = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFully(InputStream paramInputStream) throws IOException {
/* 528 */     this.offset = 0;
/* 529 */     ByteArrayDataSource byteArrayDataSource = new ByteArrayDataSource(paramInputStream, null);
/* 530 */     this.bytes = byteArrayDataSource.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 538 */     if (this.offset != 0) {
/* 539 */       byte[] arrayOfByte = new byte[this.bytes.length - this.offset];
/* 540 */       System.arraycopy(this.bytes, this.offset, arrayOfByte, 0, arrayOfByte.length);
/* 541 */       this.bytes = arrayOfByte;
/* 542 */       this.offset = 0;
/*     */     } 
/* 544 */     return this.bytes;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\transport\TransportMessage.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */