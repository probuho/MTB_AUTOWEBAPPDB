package org.apache.soap.util.xml;

import java.io.IOException;
import java.io.Writer;
import org.apache.soap.rpc.SOAPContext;

public interface Serializer {
  void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\Serializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */