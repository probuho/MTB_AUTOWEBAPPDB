/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Method;
/*     */ import oracle.soap.encoding.soapenc.EncUtils;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.RPCConstants;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.soapCycleDetect;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*  82 */   soapCycleDetect cycleDetect = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  88 */     paramNSStack.pushScope();
/*  89 */     if (this.cycleDetect == null)
/*     */     {
/*  91 */       this.cycleDetect = new soapCycleDetect();
/*     */     }
/*  93 */     SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     paramWriter.write(StringUtils.lineSeparator);
/*     */     
/* 102 */     PropertyDescriptor[] arrayOfPropertyDescriptor = getPropertyDescriptors(paramClass);
/*     */     
/* 104 */     for (byte b = 0; b < arrayOfPropertyDescriptor.length; b++) {
/*     */       
/* 106 */       String str = arrayOfPropertyDescriptor[b].getName();
/* 107 */       Class clazz = arrayOfPropertyDescriptor[b].getPropertyType();
/*     */ 
/*     */       
/* 110 */       if (!clazz.equals(Class.class)) {
/*     */         
/* 112 */         Method method = arrayOfPropertyDescriptor[b].getReadMethod();
/*     */ 
/*     */         
/* 115 */         if (method != null) {
/*     */           
/* 117 */           Object object = null;
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 122 */             if (paramObject1 != null)
/*     */             {
/* 124 */               object = method.invoke(paramObject1, new Object[0]);
/*     */             }
/*     */           }
/* 127 */           catch (Exception exception) {
/*     */             
/* 129 */             throw new IllegalArgumentException("Unable to retrieve '" + str + "' property " + "value: " + exception.getMessage() + '.');
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 136 */           Parameter parameter = new Parameter(str, clazz, object, null);
/*     */           
/*     */           try {
/* 139 */             this.cycleDetect.push(object);
/* 140 */           } catch (Exception exception) {
/* 141 */             this.cycleDetect = null;
/* 142 */             throw new IllegalArgumentException(exception.getMessage() + " " + str + " - " + clazz + " - " + object);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 148 */           paramXMLJavaMappingRegistry.marshall("http://schemas.xmlsoap.org/soap/encoding/", Parameter.class, parameter, null, paramWriter, paramNSStack, paramSOAPContext);
/*     */ 
/*     */           
/* 151 */           this.cycleDetect.pop();
/* 152 */           paramWriter.write(StringUtils.lineSeparator);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 157 */     paramWriter.write("</" + paramObject2 + '>');
/*     */     
/* 159 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 166 */     Element element1 = (Element)paramNode;
/* 167 */     Element element2 = DOMUtils.getFirstChildElement(element1);
/* 168 */     Class clazz = paramXMLJavaMappingRegistry.queryJavaType(paramQName, paramString);
/* 169 */     Object object = instantiateBean(clazz);
/* 170 */     PropertyDescriptor[] arrayOfPropertyDescriptor = getPropertyDescriptors(clazz);
/*     */ 
/*     */     
/* 173 */     String str = paramSOAPContext.getCurrentId();
/* 174 */     if (str != null) {
/* 175 */       paramSOAPContext.addDeserializedMultiRef(str, object);
/* 176 */       paramSOAPContext.setCurrentId(null);
/*     */     } 
/*     */     
/* 179 */     while (element2 != null) {
/*     */       
/* 181 */       Bean bean = paramXMLJavaMappingRegistry.unmarshall(paramString, RPCConstants.Q_ELEM_PARAMETER, element2, paramSOAPContext);
/*     */ 
/*     */       
/* 184 */       Parameter parameter = (Parameter)bean.value;
/* 185 */       Method method = getWriteMethod(parameter.getName(), arrayOfPropertyDescriptor, clazz);
/*     */ 
/*     */ 
/*     */       
/* 189 */       if (method != null) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 194 */           method.invoke(object, new Object[] { parameter.getValue() });
/*     */         }
/* 196 */         catch (Exception exception) {
/*     */ 
/*     */ 
/*     */           
/* 200 */           Class clazz1 = method.getParameterTypes()[0];
/*     */ 
/*     */           
/* 203 */           Object object1 = parameter.getValue();
/* 204 */           Object[] arrayOfObject = EncUtils.mapArrayInbuiltToWrapper(clazz1, object1);
/*     */ 
/*     */           
/* 207 */           if (object1 != null && arrayOfObject == null)
/*     */           {
/*     */             
/* 210 */             throw new IllegalArgumentException("Unable to set '" + parameter.getName() + "' property: " + exception.getMessage() + '.');
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 218 */             method.invoke(object, new Object[] { arrayOfObject });
/* 219 */           } catch (Exception exception1) {
/* 220 */             throw new IllegalArgumentException("Unable to set '" + parameter.getName() + "' property: " + exception1.getMessage() + '.');
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       element2 = DOMUtils.getNextSiblingElement(element2);
/*     */     } 
/*     */     
/* 231 */     return new Bean(clazz, object);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private PropertyDescriptor[] getPropertyDescriptors(Class paramClass) throws IllegalArgumentException {
/* 237 */     BeanInfo beanInfo = null;
/*     */ 
/*     */     
/*     */     try {
/* 241 */       beanInfo = Introspector.getBeanInfo(paramClass);
/*     */     }
/* 243 */     catch (IntrospectionException introspectionException) {}
/*     */ 
/*     */ 
/*     */     
/* 247 */     if (beanInfo != null) {
/*     */       
/* 249 */       PropertyDescriptor[] arrayOfPropertyDescriptor = beanInfo.getPropertyDescriptors();
/*     */       
/* 251 */       if (arrayOfPropertyDescriptor != null)
/*     */       {
/* 253 */         return arrayOfPropertyDescriptor;
/*     */       }
/*     */ 
/*     */       
/* 257 */       throw new IllegalArgumentException("Unable to retrieve property descriptors for '" + StringUtils.getClassName(paramClass) + "'.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     throw new IllegalArgumentException("Unable to retrieve BeanInfo for '" + StringUtils.getClassName(paramClass) + "'.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getWriteMethod(String paramString, PropertyDescriptor[] paramArrayOfPropertyDescriptor, Class paramClass) {
/* 275 */     for (byte b = 0; b < paramArrayOfPropertyDescriptor.length; b++) {
/*     */       
/* 277 */       if (Introspector.decapitalize(paramString).equals(paramArrayOfPropertyDescriptor[b].getName()))
/*     */       {
/* 279 */         return paramArrayOfPropertyDescriptor[b].getWriteMethod();
/*     */       }
/*     */     } 
/*     */     
/* 283 */     throw new IllegalArgumentException("Unable to retrieve PropertyDescriptor for property '" + paramString + "' of class '" + paramClass + "'.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object instantiateBean(Class paramClass) throws IllegalArgumentException {
/*     */     try {
/* 294 */       return paramClass.newInstance();
/*     */     }
/* 296 */     catch (Throwable throwable) {
/*     */       
/* 298 */       throw new IllegalArgumentException("Unable to instantiate '" + StringUtils.getClassName(paramClass) + "': " + throwable.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\BeanSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */