/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  83 */     paramNSStack.pushScope();
/*     */     
/*  85 */     Parameter parameter = (Parameter)paramObject1;
/*  86 */     Class clazz = parameter.getType();
/*  87 */     String str = parameter.getName();
/*  88 */     Object object = parameter.getValue();
/*     */     
/*  90 */     if (!(paramObject2 instanceof org.apache.soap.util.xml.PrefixedName))
/*     */     {
/*  92 */       paramObject2 = str;
/*     */     }
/*     */     
/*  95 */     if (object == null && !clazz.isArray()) {
/*     */       
/*  97 */       SoapEncUtils.generateNullStructure(paramString, clazz, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 102 */       String str1 = parameter.getEncodingStyleURI();
/* 103 */       String str2 = (str1 != null) ? str1 : paramString;
/*     */ 
/*     */       
/* 106 */       Serializer serializer = paramXMLJavaMappingRegistry.querySerializer(clazz, str2);
/*     */       
/* 108 */       serializer.marshall(paramString, clazz, object, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */     } 
/*     */ 
/*     */     
/* 112 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 119 */     Element element = (Element)paramNode;
/* 120 */     String str1 = element.getTagName();
/* 121 */     Bean bean = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     String str2 = DOMUtils.getAttribute(element, "href");
/*     */     
/* 129 */     if (str2 != null) {
/*     */ 
/*     */       
/* 132 */       if (str2.length() > 0 && str2.charAt(0) == '#') {
/*     */         
/* 134 */         str2 = str2.substring(1);
/*     */ 
/*     */         
/* 137 */         Object object = paramSOAPContext.getDeserializedMultiRef(str2);
/* 138 */         if (object == null)
/*     */         {
/* 140 */           Element element1 = DOMUtils.getElementByID(paramNode.getOwnerDocument().getDocumentElement(), str2);
/*     */ 
/*     */ 
/*     */           
/* 144 */           if (element1 == null)
/*     */           {
/* 146 */             throw new IllegalArgumentException("No such ID '" + str2 + "'.");
/*     */           }
/*     */           
/* 149 */           QName qName = SoapEncUtils.getTypeQName(element1);
/*     */           
/* 151 */           if (qName == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 160 */             String str = element.getNamespaceURI();
/*     */             
/* 162 */             if (str != null) {
/*     */               
/* 164 */               qName = new QName(str, str1);
/*     */             }
/*     */             else {
/*     */               
/* 168 */               qName = new QName("", str1);
/*     */             } 
/*     */           } 
/*     */           
/* 172 */           paramSOAPContext.setCurrentId(str2);
/* 173 */           bean = paramXMLJavaMappingRegistry.unmarshall(paramString, qName, element1, paramSOAPContext);
/* 174 */           paramSOAPContext.setCurrentId(null);
/*     */         }
/*     */         else
/*     */         {
/* 178 */           bean = new Bean(object.getClass(), object);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 183 */         bean = (new MimePartSerializer()).unmarshall(paramString, paramQName, paramNode, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 190 */       QName qName = SoapEncUtils.getTypeQName(element);
/*     */       
/* 192 */       if (qName == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 201 */         String str = element.getNamespaceURI();
/*     */         
/* 203 */         if (str != null) {
/*     */           
/* 205 */           qName = new QName(str, str1);
/*     */         }
/*     */         else {
/*     */           
/* 209 */           qName = new QName("", str1);
/*     */         } 
/*     */       } 
/*     */       
/* 213 */       bean = (SoapEncUtils.isNull(element) && !(new QName("http://schemas.xmlsoap.org/soap/encoding/", "Array")).equals(qName)) ? new Bean(paramXMLJavaMappingRegistry.queryJavaType(qName, paramString), null) : paramXMLJavaMappingRegistry.unmarshall(paramString, qName, element, paramSOAPContext);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     Parameter parameter = new Parameter(str1, bean.type, bean.value, null);
/*     */ 
/*     */     
/* 224 */     return new Bean(Parameter.class, parameter);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\ParameterSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */