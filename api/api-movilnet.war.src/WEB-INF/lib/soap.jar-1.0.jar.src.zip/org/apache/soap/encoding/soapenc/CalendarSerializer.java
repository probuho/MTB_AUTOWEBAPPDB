/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CalendarSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*  91 */   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 101 */     if (!paramClass.equals(GregorianCalendar.class))
/*     */     {
/* 103 */       throw new IllegalArgumentException("Can only serialize GregorianCalendar instances");
/*     */     }
/* 105 */     paramNSStack.pushScope();
/* 106 */     if (paramObject1 != null) {
/*     */       
/* 108 */       SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       Date date = ((GregorianCalendar)paramObject1).getTime();
/* 115 */       String str = null;
/*     */       
/* 117 */       synchronized (this.sdf) {
/*     */         
/* 119 */         str = this.sdf.format(date);
/*     */       } 
/*     */       
/* 122 */       paramWriter.write(str);
/* 123 */       paramWriter.write("</" + paramObject2 + '>');
/*     */     }
/*     */     else {
/*     */       
/* 127 */       SoapEncUtils.generateNullStructure(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 140 */     Date date = null;
/* 141 */     GregorianCalendar gregorianCalendar = new GregorianCalendar();
/* 142 */     Element element = (Element)paramNode;
/* 143 */     String str = DOMUtils.getChildCharacterData(element);
/* 144 */     if (str != null && !(str = str.trim()).equals("")) {
/*     */       
/*     */       try {
/*     */         
/* 148 */         synchronized (this.sdf) {
/*     */           
/* 150 */           date = this.sdf.parse(str);
/*     */         } 
/* 152 */         gregorianCalendar.setTime(date);
/*     */       }
/* 154 */       catch (ParseException parseException) {
/*     */         
/* 156 */         throw new IllegalArgumentException("String represents no valid Date for this Deserializer");
/*     */       } 
/*     */     }
/* 159 */     return new Bean(GregorianCalendar.class, gregorianCalendar);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\CalendarSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */