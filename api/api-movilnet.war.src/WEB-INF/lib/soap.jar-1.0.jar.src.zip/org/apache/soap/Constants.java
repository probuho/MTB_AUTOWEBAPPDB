/*     */ package org.apache.soap;
/*     */ 
/*     */ import org.apache.soap.util.xml.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Constants
/*     */ {
/*     */   public static final String NS_PRE_XMLNS = "xmlns";
/*     */   public static final String NS_PRE_SOAP = "SOAP";
/*     */   public static final String NS_PRE_SOAP_ENV = "SOAP-ENV";
/*     */   public static final String NS_PRE_SOAP_ENC = "SOAP-ENC";
/*     */   public static final String NS_PRE_SCHEMA_XSI = "xsi";
/*     */   public static final String NS_PRE_SCHEMA_XSD = "xsd";
/*     */   public static final String NS_URI_XMLNS = "http://www.w3.org/2000/xmlns/";
/*     */   public static final String NS_URI_SOAP_ENV = "http://schemas.xmlsoap.org/soap/envelope/";
/*     */   public static final String NS_URI_SOAP_ENC = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */   public static final String NS_URI_1999_SCHEMA_XSI = "http://www.w3.org/1999/XMLSchema-instance";
/*     */   public static final String NS_URI_1999_SCHEMA_XSD = "http://www.w3.org/1999/XMLSchema";
/*     */   public static final String NS_URI_2000_SCHEMA_XSI = "http://www.w3.org/2000/10/XMLSchema-instance";
/*     */   public static final String NS_URI_2000_SCHEMA_XSD = "http://www.w3.org/2000/10/XMLSchema";
/*     */   public static final String NS_URI_2001_SCHEMA_XSI = "http://www.w3.org/2001/XMLSchema-instance";
/*     */   public static final String NS_URI_2001_SCHEMA_XSD = "http://www.w3.org/2001/XMLSchema";
/*     */   public static final String NS_URI_CURRENT_SCHEMA_XSI = "http://www.w3.org/2001/XMLSchema-instance";
/*     */   public static final String NS_URI_CURRENT_SCHEMA_XSD = "http://www.w3.org/2001/XMLSchema";
/*     */   public static final String NS_URI_XML_SOAP = "http://xml.apache.org/xml-soap";
/*     */   public static final String NS_URI_XML_SOAP_DEPLOYMENT = "http://xml.apache.org/xml-soap/deployment";
/*     */   public static final String NS_URI_LITERAL_XML = "http://xml.apache.org/xml-soap/literalxml";
/*     */   public static final String NS_URI_XMI_ENC = "http://www.ibm.com/namespaces/xmi";
/*     */   public static final String HEADER_POST = "POST";
/*     */   public static final String HEADER_HOST = "Host";
/*     */   public static final String HEADER_CONTENT_TYPE = "Content-Type";
/*     */   public static final String HEADER_CONTENT_TYPE_JMS = "ContentType";
/*     */   public static final String HEADER_CONTENT_LENGTH = "Content-Length";
/*     */   public static final String HEADER_CONTENT_LOCATION = "Content-Location";
/*     */   public static final String HEADER_CONTENT_ID = "Content-ID";
/*     */   public static final String HEADER_SOAP_ACTION = "SOAPAction";
/*     */   public static final String HEADER_AUTHORIZATION = "Authorization";
/*     */   public static final String HEADER_PROXY_AUTHORIZATION = "Proxy-Authorization";
/*     */   public static final String HEADERVAL_DEFAULT_CHARSET = "iso-8859-1";
/*     */   public static final String HEADERVAL_CHARSET_UTF8 = "utf-8";
/*     */   public static final String HEADERVAL_CONTENT_TYPE = "text/xml";
/*     */   public static final String HEADERVAL_CONTENT_TYPE_UTF8 = "text/xml;charset=utf-8";
/*     */   public static final String HEADERVAL_CONTENT_TYPE_MULTIPART_PRIMARY = "multipart";
/*     */   public static final String HEADERVAL_MULTIPART_CONTENT_SUBTYPE = "related";
/*     */   public static final String HEADERVAL_CONTENT_TYPE_MULTIPART = "multipart/related";
/*     */   public static final String XML_DECL = "<?xml version='1.0' encoding='UTF-8'?>\r\n";
/*     */   public static final String ELEM_ENVELOPE = "Envelope";
/*     */   public static final String ELEM_BODY = "Body";
/*     */   public static final String ELEM_HEADER = "Header";
/*     */   public static final String ELEM_FAULT = "Fault";
/*     */   public static final String ELEM_FAULT_CODE = "faultcode";
/*     */   public static final String ELEM_FAULT_STRING = "faultstring";
/*     */   public static final String ELEM_FAULT_ACTOR = "faultactor";
/*     */   public static final String ELEM_DETAIL = "detail";
/*     */   public static final String ELEM_FAULT_DETAIL_ENTRY = "detailEntry";
/* 155 */   public static QName Q_ELEM_ENVELOPE = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Envelope");
/*     */   
/* 157 */   public static QName Q_ELEM_HEADER = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Header");
/*     */   
/* 159 */   public static QName Q_ELEM_BODY = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Body");
/*     */   
/* 161 */   public static QName Q_ELEM_FAULT = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Fault");
/*     */   
/*     */   public static final String ATTR_ENCODING_STYLE = "encodingStyle";
/*     */   
/*     */   public static final String ATTR_MUST_UNDERSTAND = "mustUnderstand";
/*     */   
/*     */   public static final String ATTR_TYPE = "type";
/*     */   
/*     */   public static final String ATTR_NULL = "null";
/*     */   
/*     */   public static final String ATTR_NIL = "nil";
/*     */   public static final String ATTR_ARRAY_TYPE = "arrayType";
/*     */   public static final String ATTR_REFERENCE = "href";
/*     */   public static final String ATTR_ID = "id";
/* 175 */   public static QName Q_ATTR_MUST_UNDERSTAND = new QName("http://schemas.xmlsoap.org/soap/envelope/", "mustUnderstand");
/*     */ 
/*     */ 
/*     */   
/* 179 */   public static String ATTRVAL_TRUE = "true";
/* 180 */   public static String ATTRVAL_MULTIREF_ID_PREFIX = "id";
/*     */ 
/*     */   
/* 183 */   public static String FAULT_CODE_VERSION_MISMATCH = "SOAP-ENV:VersionMismatch";
/*     */   
/* 185 */   public static String FAULT_CODE_MUST_UNDERSTAND = "SOAP-ENV:MustUnderstand";
/*     */   
/* 187 */   public static String FAULT_CODE_CLIENT = "SOAP-ENV:Client";
/* 188 */   public static String FAULT_CODE_SERVER = "SOAP-ENV:Server";
/* 189 */   public static String FAULT_CODE_PROTOCOL = "SOAP-ENV:Protocol";
/* 190 */   public static String FAULT_CODE_IOEXCEPTION = "SOAP-ENV:IOException";
/* 191 */   public static String FAULT_CODE_INTERRUPTED_IOEXCEPTION = FAULT_CODE_IOEXCEPTION + ".Interrupted";
/*     */ 
/*     */ 
/*     */   
/* 195 */   public static String FAULT_CODE_SERVER_BAD_TARGET_OBJECT_URI = FAULT_CODE_SERVER + ".BadTargetObjectURI";
/*     */ 
/*     */ 
/*     */   
/* 199 */   public static String ERR_MSG_VERSION_MISMATCH = FAULT_CODE_VERSION_MISMATCH + ": Envelope element must " + "be associated with " + "the '" + "http://schemas.xmlsoap.org/soap/envelope/" + "' namespace.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 208 */   public static String BAG_HTTPSERVLET = "HttpServlet";
/* 209 */   public static String BAG_HTTPSESSION = "HttpSession";
/* 210 */   public static String BAG_HTTPSERVLETREQUEST = "HttpServletRequest";
/* 211 */   public static String BAG_HTTPSERVLETRESPONSE = "HttpServletResponse";
/* 212 */   public static String BAG_DEPLOYMENTDESCRIPTOR = "DeploymentDescriptor";
/*     */ 
/*     */   
/*     */   public static final String ENVELOPE_EDITOR_FACTORY = "EnvelopeEditorFactory";
/*     */   
/*     */   public static final String XML_PARSER = "XMLParser";
/*     */   
/*     */   public static final String CONFIGFILENAME = "ConfigFile";
/*     */   
/* 221 */   public static final QName string1999QName = new QName("http://www.w3.org/1999/XMLSchema", "string");
/*     */   
/* 223 */   public static final QName int1999QName = new QName("http://www.w3.org/1999/XMLSchema", "int");
/*     */   
/* 225 */   public static final QName decimal1999QName = new QName("http://www.w3.org/1999/XMLSchema", "decimal");
/*     */   
/* 227 */   public static final QName float1999QName = new QName("http://www.w3.org/1999/XMLSchema", "float");
/*     */   
/* 229 */   public static final QName double1999QName = new QName("http://www.w3.org/1999/XMLSchema", "double");
/*     */   
/* 231 */   public static final QName date1999QName = new QName("http://www.w3.org/1999/XMLSchema", "date");
/*     */   
/* 233 */   public static final QName boolean1999QName = new QName("http://www.w3.org/1999/XMLSchema", "boolean");
/*     */   
/* 235 */   public static final QName long1999QName = new QName("http://www.w3.org/1999/XMLSchema", "long");
/*     */   
/* 237 */   public static final QName short1999QName = new QName("http://www.w3.org/1999/XMLSchema", "short");
/*     */   
/* 239 */   public static final QName byte1999QName = new QName("http://www.w3.org/1999/XMLSchema", "byte");
/*     */   
/* 241 */   public static final QName hex1999QName = new QName("http://www.w3.org/1999/XMLSchema", "hex");
/*     */   
/* 243 */   public static final QName qName1999QName = new QName("http://www.w3.org/1999/XMLSchema", "QName");
/*     */   
/* 245 */   public static final QName timeInst1999QName = new QName("http://www.w3.org/1999/XMLSchema", "timeInstant");
/*     */   
/* 247 */   public static final QName object1999QName = new QName("http://www.w3.org/1999/XMLSchema", "ur-type");
/*     */ 
/*     */   
/* 250 */   public static final QName string2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "string");
/*     */   
/* 252 */   public static final QName int2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "int");
/*     */   
/* 254 */   public static final QName decimal2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "decimal");
/*     */   
/* 256 */   public static final QName float2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "float");
/*     */   
/* 258 */   public static final QName double2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "double");
/*     */   
/* 260 */   public static final QName date2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "date");
/*     */   
/* 262 */   public static final QName boolean2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "boolean");
/*     */   
/* 264 */   public static final QName long2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "long");
/*     */   
/* 266 */   public static final QName short2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "short");
/*     */   
/* 268 */   public static final QName byte2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "byte");
/*     */   
/* 270 */   public static final QName hex2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "hex");
/*     */   
/* 272 */   public static final QName qName2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "QName");
/*     */   
/* 274 */   public static final QName timeInst2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "timeInstant");
/*     */   
/* 276 */   public static final QName object2000QName = new QName("http://www.w3.org/2000/10/XMLSchema", "anyType");
/*     */ 
/*     */   
/* 279 */   public static final QName string2001QName = new QName("http://www.w3.org/2001/XMLSchema", "string");
/*     */   
/* 281 */   public static final QName int2001QName = new QName("http://www.w3.org/2001/XMLSchema", "int");
/*     */   
/* 283 */   public static final QName decimal2001QName = new QName("http://www.w3.org/2001/XMLSchema", "decimal");
/*     */   
/* 285 */   public static final QName float2001QName = new QName("http://www.w3.org/2001/XMLSchema", "float");
/*     */   
/* 287 */   public static final QName double2001QName = new QName("http://www.w3.org/2001/XMLSchema", "double");
/*     */   
/* 289 */   public static final QName date2001QName = new QName("http://www.w3.org/2001/XMLSchema", "date");
/*     */   
/* 291 */   public static final QName boolean2001QName = new QName("http://www.w3.org/2001/XMLSchema", "boolean");
/*     */   
/* 293 */   public static final QName long2001QName = new QName("http://www.w3.org/2001/XMLSchema", "long");
/*     */   
/* 295 */   public static final QName short2001QName = new QName("http://www.w3.org/2001/XMLSchema", "short");
/*     */   
/* 297 */   public static final QName byte2001QName = new QName("http://www.w3.org/2001/XMLSchema", "byte");
/*     */   
/* 299 */   public static final QName hex2001QName = new QName("http://www.w3.org/2001/XMLSchema", "hexBinary");
/*     */   
/* 301 */   public static final QName qName2001QName = new QName("http://www.w3.org/2001/XMLSchema", "QName");
/*     */   
/* 303 */   public static final QName timeInst2001QName = new QName("http://www.w3.org/2001/XMLSchema", "dateTime");
/*     */   
/* 305 */   public static final QName object2001QName = new QName("http://www.w3.org/2001/XMLSchema", "anyType");
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\Constants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */