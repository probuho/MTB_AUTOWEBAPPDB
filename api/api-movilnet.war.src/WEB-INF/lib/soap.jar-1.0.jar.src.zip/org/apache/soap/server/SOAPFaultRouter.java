/*     */ package org.apache.soap.server;
/*     */ 
/*     */ import org.apache.soap.Fault;
/*     */ import org.apache.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPFaultRouter
/*     */ {
/*     */   SOAPFaultListener[] faultListener;
/*     */   
/*     */   public void setFaultListener(SOAPFaultListener[] paramArrayOfSOAPFaultListener) {
/*  75 */     this.faultListener = paramArrayOfSOAPFaultListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFaultListener(int paramInt, SOAPFaultListener paramSOAPFaultListener) {
/*  80 */     this.faultListener[paramInt] = paramSOAPFaultListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public SOAPFaultListener[] getFaultListener() {
/*  85 */     return this.faultListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public SOAPFaultListener getFaultListener(int paramInt) {
/*  90 */     return this.faultListener[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyListeners(Fault paramFault, SOAPException paramSOAPException) {
/*  96 */     if (this.faultListener == null)
/*     */       return; 
/*  98 */     SOAPFaultEvent sOAPFaultEvent = new SOAPFaultEvent(paramFault, paramSOAPException);
/*     */     
/* 100 */     for (byte b = 0; b < this.faultListener.length; b++)
/* 101 */       this.faultListener[b].fault(sOAPFaultEvent); 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\SOAPFaultRouter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */