/*    */ package org.apache.soap.server;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.soap.util.xml.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeMapping
/*    */   implements Serializable
/*    */ {
/*    */   public String encodingStyle;
/*    */   public QName elementType;
/*    */   public String javaType;
/*    */   public String java2XMLClassName;
/*    */   public String xml2JavaClassName;
/* 76 */   public String sqlType = null;
/*    */ 
/*    */   
/*    */   public TypeMapping(String paramString1, QName paramQName, String paramString2, String paramString3, String paramString4) {
/* 80 */     this.encodingStyle = paramString1;
/* 81 */     this.elementType = paramQName;
/* 82 */     this.javaType = paramString2;
/* 83 */     this.java2XMLClassName = paramString3;
/* 84 */     this.xml2JavaClassName = paramString4;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeMapping(String paramString1, QName paramQName, String paramString2, String paramString3, String paramString4, String paramString5) {
/* 90 */     this(paramString1, paramQName, paramString2, paramString3, paramString4);
/* 91 */     this.sqlType = paramString5;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 95 */     String str = "";
/* 96 */     if (this.sqlType != null) {
/* 97 */       str = "sqlType=" + this.sqlType + ",";
/*    */     }
/* 99 */     return "[TypeMapping encodingStyle=" + this.encodingStyle + "," + "elementType=" + this.elementType + "," + "javaType=" + this.javaType + "," + str + "java2XMLClassName=" + this.java2XMLClassName + "," + "xml2JavaClassName=" + this.xml2JavaClassName + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\TypeMapping.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */