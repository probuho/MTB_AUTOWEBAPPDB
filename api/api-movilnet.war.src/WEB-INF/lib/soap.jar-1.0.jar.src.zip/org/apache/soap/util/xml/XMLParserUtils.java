/*     */ package org.apache.soap.util.xml;
/*     */ 
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLParserUtils
/*     */ {
/*  76 */   private static DocumentBuilderFactory dbf = null;
/*     */ 
/*     */   
/*     */   static {
/*  80 */     refreshDocumentBuilderFactory(null, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void refreshDocumentBuilderFactory(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 107 */     if (paramString != null) {
/* 108 */       System.setProperty("javax.xml.parsers.DocumentBuilderFactory", paramString);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 113 */     dbf = DocumentBuilderFactory.newInstance();
/*     */ 
/*     */     
/* 116 */     dbf.setNamespaceAware(paramBoolean1);
/* 117 */     dbf.setValidating(paramBoolean2);
/*     */ 
/*     */     
/* 120 */     dbf.setExpandEntityReferences(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized DocumentBuilder getXMLDocBuilder() throws IllegalArgumentException {
/*     */     try {
/* 142 */       return dbf.newDocumentBuilder();
/* 143 */     } catch (ParserConfigurationException parserConfigurationException) {
/* 144 */       throw new IllegalArgumentException(parserConfigurationException.toString());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\XMLParserUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */