/*     */ package org.apache.soap;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Vector;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.apache.soap.util.xml.DOM2Writer;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*     */   public static String cleanString(String paramString) {
/*  77 */     if (paramString == null)
/*     */     {
/*  79 */       return "";
/*     */     }
/*     */     
/*  82 */     StringBuffer stringBuffer = new StringBuffer();
/*  83 */     char[] arrayOfChar = paramString.toCharArray();
/*     */     
/*  85 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/*     */       
/*  87 */       switch (arrayOfChar[b]) {
/*     */         case '&':
/*  89 */           stringBuffer.append("&amp;"); break;
/*     */         case '"':
/*  91 */           stringBuffer.append("&quot;"); break;
/*     */         case '\'':
/*  93 */           stringBuffer.append("&apos;"); break;
/*     */         case '<':
/*  95 */           stringBuffer.append("&lt;"); break;
/*     */         case '>':
/*  97 */           stringBuffer.append("&gt;"); break;
/*     */         default:
/*  99 */           stringBuffer.append(arrayOfChar[b]);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 104 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void marshallNode(Node paramNode, Writer paramWriter) {
/* 109 */     DOM2Writer.serializeAsXML(paramNode, paramWriter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector buildFaultDetailsFromThrowable(Throwable paramThrowable) {
/* 119 */     Vector vector = new Vector();
/* 120 */     DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/* 121 */     Document document = documentBuilder.newDocument();
/* 122 */     Element element = document.createElement("stackTrace");
/* 123 */     StringWriter stringWriter = new StringWriter();
/* 124 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/* 125 */     paramThrowable.printStackTrace(printWriter);
/* 126 */     printWriter.close();
/* 127 */     Text text = document.createTextNode(cleanString(stringWriter.toString()));
/* 128 */     element.appendChild(text);
/* 129 */     vector.addElement(element);
/* 130 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkMustUnderstands(Header paramHeader) throws SOAPException {
/* 139 */     Vector vector = paramHeader.getHeaderEntries();
/*     */     
/* 141 */     for (byte b = 0; b < vector.size(); b++) {
/*     */       
/* 143 */       Element element = vector.elementAt(b);
/* 144 */       String str = element.getAttributeNS("http://schemas.xmlsoap.org/soap/envelope/", "mustUnderstand");
/*     */ 
/*     */       
/* 147 */       if (str != null && str.equals("1"))
/*     */       {
/* 149 */         throw new SOAPException(Constants.FAULT_CODE_MUST_UNDERSTAND, "Didn't understand header '" + element.getLocalName() + "'");
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\Utils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */