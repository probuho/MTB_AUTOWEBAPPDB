/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*  81 */   private final HashtableSerializer hashtableSer = new HashtableSerializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  93 */     Hashtable hashtable = null;
/*     */     
/*  95 */     if (paramObject1 instanceof Hashtable) {
/*     */       
/*  97 */       hashtable = (Hashtable)paramObject1;
/*     */     }
/*  99 */     else if (paramObject1 instanceof Map) {
/*     */       
/* 101 */       hashtable = new Hashtable();
/* 102 */       hashtable.putAll((Map)paramObject1);
/*     */     }
/*     */     else {
/*     */       
/* 106 */       throw new IllegalArgumentException("Tried to pass a '" + paramObject1.getClass().toString() + "' to MapSerializer");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.hashtableSer.marshall(paramString, Hashtable.class, hashtable, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 128 */     return this.hashtableSer.unmarshall(paramString, paramQName, paramNode, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\MapSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */