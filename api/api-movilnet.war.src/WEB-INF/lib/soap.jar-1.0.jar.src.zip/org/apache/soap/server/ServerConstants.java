package org.apache.soap.server;

public class ServerConstants {
  public static final String SERVICE_MANAGER_SERVICE_NAME = "urn:xml-soap-service-management-service";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\ServerConstants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */