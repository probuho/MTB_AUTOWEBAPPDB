/*     */ package org.apache.soap.transport;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URL;
/*     */ import java.util.Hashtable;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterTransport
/*     */   implements SOAPTransport
/*     */ {
/*     */   private EnvelopeEditor editor;
/*     */   private SOAPTransport transport;
/*     */   
/*     */   public FilterTransport(EnvelopeEditor paramEnvelopeEditor, SOAPTransport paramSOAPTransport) {
/*  87 */     this.editor = paramEnvelopeEditor;
/*  88 */     this.transport = paramSOAPTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(URL paramURL, String paramString, Hashtable paramHashtable, Envelope paramEnvelope, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws SOAPException {
/*     */     try {
/* 114 */       StringWriter stringWriter = new StringWriter();
/* 115 */       paramEnvelope.marshall(stringWriter, (XMLJavaMappingRegistry)paramSOAPMappingRegistry, paramSOAPContext);
/*     */       
/* 117 */       StringReader stringReader = new StringReader(stringWriter.getBuffer().toString());
/* 118 */       if (this.editor != null) {
/* 119 */         stringWriter = new StringWriter();
/* 120 */         this.editor.editOutgoing(stringReader, stringWriter);
/* 121 */         stringWriter.flush();
/* 122 */         stringReader = new StringReader(stringWriter.getBuffer().toString());
/*     */       } 
/*     */       
/* 125 */       DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/* 126 */       Element element = documentBuilder.parse(new InputSource(stringReader)).getDocumentElement();
/*     */       
/* 128 */       Envelope envelope = Envelope.unmarshall(element);
/* 129 */       this.transport.send(paramURL, paramString, paramHashtable, envelope, paramSOAPMappingRegistry, paramSOAPContext);
/* 130 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 131 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, illegalArgumentException.getMessage(), illegalArgumentException);
/*     */     
/*     */     }
/* 134 */     catch (SAXException sAXException) {
/* 135 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, sAXException.getMessage(), sAXException);
/*     */     
/*     */     }
/* 138 */     catch (IOException iOException) {
/* 139 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, iOException.getMessage(), iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedReader receive() {
/*     */     try {
/* 154 */       BufferedReader bufferedReader = this.transport.receive();
/* 155 */       if (this.editor == null || bufferedReader == null) {
/* 156 */         return bufferedReader;
/*     */       }
/* 158 */       StringWriter stringWriter = new StringWriter();
/* 159 */       this.editor.editIncoming(bufferedReader, stringWriter);
/* 160 */       stringWriter.flush();
/* 161 */       StringReader stringReader = new StringReader(stringWriter.getBuffer().toString());
/* 162 */       return new BufferedReader(stringReader);
/*     */     }
/* 164 */     catch (SOAPException sOAPException) {
/* 165 */       sOAPException.printStackTrace();
/*     */       
/* 167 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getHeaders() {
/* 177 */     return this.transport.getHeaders();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPContext getResponseSOAPContext() {
/* 186 */     return this.transport.getResponseSOAPContext();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\transport\FilterTransport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */