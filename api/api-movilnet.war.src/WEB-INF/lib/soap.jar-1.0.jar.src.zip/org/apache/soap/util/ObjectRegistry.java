/*     */ package org.apache.soap.util;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectRegistry
/*     */ {
/*  77 */   Hashtable reg = new Hashtable();
/*  78 */   ObjectRegistry parent = null;
/*     */ 
/*     */   
/*     */   public ObjectRegistry() {}
/*     */   
/*     */   public ObjectRegistry(ObjectRegistry paramObjectRegistry) {
/*  84 */     this.parent = paramObjectRegistry;
/*     */   }
/*     */ 
/*     */   
/*     */   public void register(String paramString, Object paramObject) {
/*  89 */     this.reg.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public void unregister(String paramString) {
/*  94 */     this.reg.remove(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object lookup(String paramString) throws IllegalArgumentException {
/*  99 */     Object object = this.reg.get(paramString);
/*     */     
/* 101 */     if (object == null && this.parent != null) {
/* 102 */       object = this.parent.lookup(paramString);
/*     */     }
/*     */     
/* 105 */     if (object == null) {
/* 106 */       throw new IllegalArgumentException("object '" + paramString + "' not in registry");
/*     */     }
/*     */     
/* 109 */     return object;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\ObjectRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */