/*     */ package org.apache.soap.util.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import sun.net.www.protocol.http.HttpURLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLUtils
/*     */ {
/*     */   static String tunnelHost;
/*     */   static int tunnelPort;
/*     */   
/*     */   public static Socket buildSSLSocket(String paramString1, int paramInt1, String paramString2, int paramInt2) throws IOException, UnknownHostException {
/*  80 */     SSLSocket sSLSocket = null;
/*  81 */     SSLSocketFactory sSLSocketFactory = (SSLSocketFactory)SSLSocketFactory.getDefault();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     tunnelHost = System.getProperty("https.proxyHost");
/*  87 */     tunnelPort = Integer.getInteger("https.proxyPort", 80).intValue();
/*     */     
/*  89 */     if (tunnelHost == null) {
/*     */       
/*  91 */       tunnelHost = paramString2;
/*  92 */       tunnelPort = paramInt2;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     if (tunnelHost == null) {
/* 109 */       sSLSocket = (SSLSocket)sSLSocketFactory.createSocket(paramString1, paramInt1);
/*     */     } else {
/* 111 */       Socket socket = new Socket(tunnelHost, tunnelPort);
/* 112 */       doTunnelHandshake(socket, paramString1, paramInt1);
/*     */ 
/*     */       
/* 115 */       sSLSocket = (SSLSocket)sSLSocketFactory.createSocket(socket, paramString1, paramInt1, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     sSLSocket.startHandshake();
/*     */     
/* 131 */     return sSLSocket;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void doTunnelHandshake(Socket paramSocket, String paramString, int paramInt) throws IOException {
/*     */     byte[] arrayOfByte1;
/*     */     String str2;
/* 138 */     OutputStream outputStream = paramSocket.getOutputStream();
/* 139 */     String str1 = "CONNECT " + paramString + ":" + paramInt + " HTTP/1.0\n" + "User-Agent: " + HttpURLConnection.userAgent + "\r\n\r\n";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 149 */       arrayOfByte1 = str1.getBytes("ASCII7");
/* 150 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 155 */       arrayOfByte1 = str1.getBytes();
/*     */     } 
/* 157 */     outputStream.write(arrayOfByte1);
/* 158 */     outputStream.flush();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     byte[] arrayOfByte2 = new byte[200];
/* 165 */     byte b1 = 0;
/* 166 */     byte b2 = 0;
/* 167 */     boolean bool1 = false;
/*     */     
/* 169 */     InputStream inputStream = paramSocket.getInputStream();
/* 170 */     boolean bool2 = false;
/*     */     
/* 172 */     while (b2 < 2) {
/* 173 */       int i = inputStream.read();
/* 174 */       if (i < 0) {
/* 175 */         throw new IOException("Unexpected EOF from proxy");
/*     */       }
/* 177 */       if (i == 10) {
/* 178 */         bool1 = true;
/* 179 */         b2++; continue;
/* 180 */       }  if (i != 13) {
/* 181 */         b2 = 0;
/* 182 */         if (!bool1 && b1 < arrayOfByte2.length) {
/* 183 */           arrayOfByte2[b1++] = (byte)i;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 195 */       str2 = new String(arrayOfByte2, 0, b1, "ASCII7");
/* 196 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 197 */       str2 = new String(arrayOfByte2, 0, b1);
/*     */     } 
/*     */ 
/*     */     
/* 201 */     StringTokenizer stringTokenizer = new StringTokenizer(str2);
/* 202 */     stringTokenizer.nextToken();
/* 203 */     if (!stringTokenizer.nextToken().startsWith("200"))
/* 204 */       throw new IOException("Unable to tunnel through " + tunnelHost + ":" + tunnelPort + ".  Proxy returns \"" + str2 + "\""); 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\net\SSLUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */