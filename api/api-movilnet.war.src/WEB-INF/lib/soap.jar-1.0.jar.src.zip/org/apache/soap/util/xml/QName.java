/*     */ package org.apache.soap.util.xml;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QName
/*     */   implements Serializable
/*     */ {
/*     */   private String namespaceURI;
/*     */   private String localPart;
/*     */   
/*     */   public QName() {}
/*     */   
/*     */   public QName(Node paramNode) throws IllegalArgumentException {
/*  80 */     String str1 = paramNode.getNamespaceURI();
/*     */     
/*  82 */     if (str1 == null || str1 == "")
/*     */     {
/*  84 */       throw new IllegalArgumentException("Can't create QName: NamespaceURI must not be null.");
/*     */     }
/*     */ 
/*     */     
/*  88 */     String str2 = paramNode.getLocalName();
/*     */     
/*  90 */     if (str2 == null)
/*     */     {
/*  92 */       throw new IllegalArgumentException("Can't create QName: LocalName must not be null.");
/*     */     }
/*     */ 
/*     */     
/*  96 */     setNamespaceURI(str1);
/*  97 */     setLocalPart(str2);
/*     */   }
/*     */ 
/*     */   
/*     */   public QName(String paramString1, String paramString2) {
/* 102 */     setNamespaceURI(paramString1);
/* 103 */     setLocalPart(paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNamespaceURI(String paramString) {
/* 108 */     this.namespaceURI = ((paramString == null) ? "" : paramString).intern();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespaceURI() {
/* 113 */     return this.namespaceURI;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocalPart(String paramString) {
/* 118 */     this.localPart = ((paramString == null) ? "" : paramString).intern();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalPart() {
/* 123 */     return this.localPart;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 128 */     String str1 = this.namespaceURI.hashCode() + "";
/* 129 */     String str2 = this.localPart.hashCode() + "";
/* 130 */     String str3 = str1 + '_' + str2;
/*     */     
/* 132 */     return str3.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 137 */     return (paramObject != null && this.namespaceURI == ((QName)paramObject).getNamespaceURI() && this.localPart == ((QName)paramObject).getLocalPart());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Node paramNode) {
/*     */     try {
/* 146 */       return (paramNode != null && equals(new QName(paramNode)));
/*     */     }
/* 148 */     catch (IllegalArgumentException illegalArgumentException) {
/*     */       
/* 150 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 156 */     return this.namespaceURI + ':' + this.localPart;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\QName.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */