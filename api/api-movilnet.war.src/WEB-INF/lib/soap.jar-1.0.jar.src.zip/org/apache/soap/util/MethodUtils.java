/*     */ package org.apache.soap.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodUtils
/*     */ {
/*     */   private static Object getEntryPoint(Class paramClass, String paramString, Class[] paramArrayOfClass, boolean paramBoolean) throws SecurityException, NoSuchMethodException {
/* 105 */     Method method = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 112 */       if (paramString != null) {
/*     */         
/* 114 */         method = paramClass.getMethod(paramString, paramArrayOfClass);
/* 115 */         if (paramBoolean && !Modifier.isStatic(entryGetModifiers(method)))
/*     */         {
/*     */           
/* 118 */           throw new NoSuchMethodException(callToString(paramClass, paramString, paramArrayOfClass, paramBoolean) + " resolved to instance " + method);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 125 */         return method;
/*     */       } 
/*     */       
/* 128 */       return paramClass.getConstructor(paramArrayOfClass);
/*     */     }
/* 130 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       Constructor[] arrayOfConstructor;
/* 132 */       if (paramArrayOfClass == null || paramArrayOfClass.length == 0)
/*     */       {
/* 134 */         throw new NoSuchMethodException(callToString(paramClass, paramString, paramArrayOfClass, paramBoolean) + " not found.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 150 */       if (paramString != null) {
/*     */         
/* 152 */         Method[] arrayOfMethod = paramClass.getMethods();
/*     */       }
/*     */       else {
/*     */         
/* 156 */         arrayOfConstructor = (Constructor[])paramClass.getConstructors();
/*     */       } 
/* 158 */       if (0 == arrayOfConstructor.length)
/*     */       {
/* 160 */         throw new NoSuchMethodException("No methods!");
/*     */       }
/*     */       
/* 163 */       MoreSpecific moreSpecific = new MoreSpecific();
/* 164 */       for (byte b = 0; b < arrayOfConstructor.length; b++) {
/*     */         
/* 166 */         Constructor constructor = arrayOfConstructor[b];
/* 167 */         if (Modifier.isPublic(entryGetModifiers(constructor)) && (paramString == null || entryGetName(constructor).equals(paramString)) && areMethodConvertable(entryGetParameterTypes(constructor), paramArrayOfClass, false))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 178 */           moreSpecific.addItem(constructor);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 183 */       Object object = moreSpecific.getMostSpecific(paramClass, paramString, paramArrayOfClass, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 192 */       if (object == null)
/*     */       {
/* 194 */         throw new NoSuchMethodException(callToString(paramClass, paramString, paramArrayOfClass, paramBoolean) + " -- no signature match");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       if (paramString != null && paramBoolean && !Modifier.isStatic(entryGetModifiers(object)))
/*     */       {
/*     */ 
/*     */         
/* 205 */         throw new NoSuchMethodException(callToString(paramClass, paramString, paramArrayOfClass, paramBoolean) + " resolved to instance: " + object);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 212 */       return object;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String callToString(Class paramClass, String paramString, Class[] paramArrayOfClass, boolean paramBoolean) {
/* 222 */     StringBuffer stringBuffer = new StringBuffer();
/* 223 */     if (paramBoolean)
/* 224 */       stringBuffer.append("static "); 
/* 225 */     stringBuffer.append(StringUtils.getClassName(paramClass));
/* 226 */     if (paramString != null)
/* 227 */       stringBuffer.append(".").append(paramString); 
/* 228 */     stringBuffer.append("(");
/* 229 */     if (paramArrayOfClass != null && paramArrayOfClass.length > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       stringBuffer.append(StringUtils.getClassName(paramArrayOfClass[0]));
/* 238 */       for (byte b = 1; b < paramArrayOfClass.length; b++) {
/* 239 */         stringBuffer.append(",").append(StringUtils.getClassName(paramArrayOfClass[b]));
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 244 */       stringBuffer.append("[none]");
/* 245 */     }  stringBuffer.append(")");
/* 246 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isWrapperClass(Class paramClass1, Class paramClass2) {
/* 254 */     if ((paramClass1.equals(Byte.class) && paramClass2.equals(byte.class)) || (paramClass1.equals(Character.class) && paramClass2.equals(char.class)) || (paramClass1.equals(Boolean.class) && paramClass2.equals(boolean.class)) || (paramClass1.equals(Short.class) && paramClass2.equals(short.class)) || (paramClass1.equals(Integer.class) && paramClass2.equals(int.class)) || (paramClass1.equals(Long.class) && paramClass2.equals(long.class)) || (paramClass1.equals(Float.class) && paramClass2.equals(float.class)) || (paramClass1.equals(Double.class) && paramClass2.equals(double.class)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       return true;
/*     */     }
/* 264 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isMethodConvertable(Class paramClass1, Class paramClass2, boolean paramBoolean) {
/* 293 */     if (paramClass1.equals(paramClass2)) {
/* 294 */       return true;
/*     */     }
/*     */     
/* 297 */     if (paramClass2 == null)
/*     */     {
/* 299 */       return !paramClass1.isPrimitive();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     while (paramClass1.isArray()) {
/*     */       
/* 307 */       if (!paramClass2.isArray()) {
/* 308 */         return false;
/*     */       }
/*     */       
/* 311 */       paramClass1 = paramClass1.getComponentType();
/* 312 */       paramClass2 = paramClass2.getComponentType();
/*     */     } 
/*     */     
/* 315 */     if (paramClass2.isArray()) {
/* 316 */       return false;
/*     */     }
/*     */     
/* 319 */     if (isWrapperClass(paramClass1, paramClass2)) {
/* 320 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 324 */     if (!paramBoolean && isWrapperClass(paramClass2, paramClass1)) {
/* 325 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     if (paramClass1.isAssignableFrom(paramClass2)) {
/* 336 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 343 */     if (paramClass1.equals(void.class) || paramClass1.equals(boolean.class) || paramClass2.equals(void.class) || paramClass2.equals(boolean.class))
/*     */     {
/* 345 */       return false;
/*     */     }
/* 347 */     Class[] arrayOfClass = { char.class, byte.class, short.class, int.class, long.class, float.class, double.class };
/*     */     
/*     */     byte b1;
/*     */     
/* 351 */     for (b1 = 0; b1 < arrayOfClass.length && 
/* 352 */       !paramClass1.equals(arrayOfClass[b1]); b1++);
/*     */     
/* 354 */     if (b1 >= arrayOfClass.length)
/* 355 */       return false; 
/*     */     byte b2;
/* 357 */     for (b2 = 0; b2 < arrayOfClass.length && 
/* 358 */       !paramClass2.equals(arrayOfClass[b2]); b2++);
/*     */     
/* 360 */     if (b2 >= arrayOfClass.length) {
/* 361 */       return false;
/*     */     }
/*     */     
/* 364 */     return (b2 < b1 && (b2 != 0 || b1 > 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isAssignmentConvertable(Class paramClass1, Class paramClass2, boolean paramBoolean) {
/* 381 */     return ((paramClass2.equals(int.class) && (paramClass1.equals(byte.class) || paramClass1.equals(short.class) || paramClass1.equals(char.class))) || isMethodConvertable(paramClass1, paramClass2, paramBoolean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean areMethodConvertable(Class[] paramArrayOfClass1, Class[] paramArrayOfClass2, boolean paramBoolean) {
/* 398 */     if (paramArrayOfClass1.length != paramArrayOfClass2.length) {
/* 399 */       return false;
/*     */     }
/* 401 */     for (byte b = 0; b < paramArrayOfClass1.length; b++) {
/* 402 */       if (!isMethodConvertable(paramArrayOfClass1[b], paramArrayOfClass2[b], paramBoolean))
/* 403 */         return false; 
/*     */     } 
/* 405 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MoreSpecific
/*     */     extends Vector
/*     */   {
/*     */     private MoreSpecific() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void addItem(Object param1Object) {
/* 441 */       if (size() == 0) {
/* 442 */         addElement((E)param1Object);
/*     */       } else {
/*     */         
/* 445 */         Class[] arrayOfClass = MethodUtils.entryGetParameterTypes(param1Object);
/* 446 */         boolean bool = true;
/* 447 */         Enumeration enumeration = elements();
/* 448 */         while (bool & enumeration.hasMoreElements()) {
/*     */ 
/*     */           
/* 451 */           E e = enumeration.nextElement();
/*     */           
/* 453 */           Class[] arrayOfClass1 = MethodUtils.entryGetParameterTypes(e);
/* 454 */           if (MethodUtils.areMethodConvertable(arrayOfClass1, arrayOfClass, true)) {
/* 455 */             removeElement(e); continue;
/* 456 */           }  if (MethodUtils.areMethodConvertable(arrayOfClass, arrayOfClass1, true)) {
/* 457 */             bool = false;
/*     */           }
/*     */         } 
/* 460 */         if (bool) {
/* 461 */           addElement((E)param1Object);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object getMostSpecific(Class param1Class, String param1String, Class[] param1ArrayOfClass, boolean param1Boolean) throws NoSuchMethodException {
/* 475 */       if (size() == 1)
/* 476 */         return firstElement(); 
/* 477 */       if (size() > 1) {
/*     */         
/* 479 */         StringBuffer stringBuffer = new StringBuffer();
/* 480 */         Enumeration enumeration = elements();
/* 481 */         stringBuffer.append(enumeration.nextElement());
/* 482 */         while (enumeration.hasMoreElements())
/* 483 */           stringBuffer.append(" and ").append(enumeration.nextElement()); 
/* 484 */         throw new NoSuchMethodException(MethodUtils.callToString(param1Class, param1String, param1ArrayOfClass, param1Boolean) + " is ambiguous. It matches " + stringBuffer.toString());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 491 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String entryGetName(Object paramObject) {
/* 508 */     return (paramObject instanceof Method) ? ((Method)paramObject).getName() : ((Constructor)paramObject).getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int entryGetModifiers(Object paramObject) {
/* 516 */     return (paramObject instanceof Method) ? ((Method)paramObject).getModifiers() : ((Constructor)paramObject).getModifiers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class[] entryGetParameterTypes(Object paramObject) {
/* 524 */     return (paramObject instanceof Method) ? ((Method)paramObject).getParameterTypes() : ((Constructor)paramObject).getParameterTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String entryToString(Object paramObject) {
/* 532 */     return (paramObject instanceof Method) ? ((Method)paramObject).toString() : ((Constructor)paramObject).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getMethod(Object paramObject, String paramString, Class[] paramArrayOfClass) throws SecurityException, NoSuchMethodException {
/* 563 */     boolean bool = paramObject instanceof Class;
/* 564 */     return getMethod(bool ? (Class)paramObject : paramObject.getClass(), paramString, paramArrayOfClass, bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getMethod(Class paramClass, String paramString, Class[] paramArrayOfClass, boolean paramBoolean) throws SecurityException, NoSuchMethodException {
/* 584 */     return (Method)getEntryPoint(paramClass, paramString, paramArrayOfClass, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Constructor getConstructor(Class paramClass, Class[] paramArrayOfClass) throws SecurityException, NoSuchMethodException {
/* 602 */     return (Constructor)getEntryPoint(paramClass, null, paramArrayOfClass, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\MethodUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */