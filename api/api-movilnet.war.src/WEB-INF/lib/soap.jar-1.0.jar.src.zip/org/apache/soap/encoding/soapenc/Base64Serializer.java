/*    */ package org.apache.soap.encoding.soapenc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.apache.soap.rpc.SOAPContext;
/*    */ import org.apache.soap.util.Bean;
/*    */ import org.apache.soap.util.xml.DOMUtils;
/*    */ import org.apache.soap.util.xml.Deserializer;
/*    */ import org.apache.soap.util.xml.NSStack;
/*    */ import org.apache.soap.util.xml.QName;
/*    */ import org.apache.soap.util.xml.Serializer;
/*    */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Base64Serializer
/*    */   implements Serializer, Deserializer
/*    */ {
/*    */   static Class array$B;
/*    */   
/*    */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 24 */     paramNSStack.pushScope();
/*    */     
/* 26 */     byte[] arrayOfByte = (byte[])paramObject1;
/*    */     
/* 28 */     if (arrayOfByte == null) {
/*    */       
/* 30 */       SoapEncUtils.generateNullStructure(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*    */ 
/*    */ 
/*    */     
/*    */     }
/*    */     else {
/*    */ 
/*    */ 
/*    */       
/* 39 */       SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 46 */       paramWriter.write(Base64.encode(arrayOfByte) + "</" + paramObject2 + '>');
/*    */     } 
/*    */     
/* 49 */     paramNSStack.popScope();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 56 */     Element element = (Element)paramNode;
/* 57 */     String str = DOMUtils.getChildCharacterData(element);
/*    */     
/* 59 */     return new Bean((array$B == null) ? (array$B = class$("[B")) : array$B, Base64.decode(str)); } static Class class$(String paramString) { try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(classNotFoundException.getMessage()); }
/*    */      }
/*    */ 
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\Base64Serializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */