/*    */ package org.apache.soap.encoding.soapenc;
/*    */ 
/*    */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*    */ import org.apache.soap.rpc.SOAPContext;
/*    */ import org.apache.soap.util.Bean;
/*    */ import org.apache.soap.util.xml.Deserializer;
/*    */ import org.apache.soap.util.xml.QName;
/*    */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrTypeDeserializer
/*    */   implements Deserializer
/*    */ {
/*    */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 85 */     Element element = (Element)paramNode;
/*    */     
/* 87 */     if (!SoapEncUtils.isNull(element)) {
/* 88 */       String str = element.getAttribute("href");
/* 89 */       if (str != null && !str.equals("")) {
/* 90 */         return SOAPMappingRegistry.partSer.unmarshall(paramString, paramQName, paramNode, paramXMLJavaMappingRegistry, paramSOAPContext);
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 96 */       throw new IllegalArgumentException("Can't yet deserialize non-null Objects");
/*    */     } 
/*    */     
/* 99 */     return new Bean(Object.class, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\UrTypeDeserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */