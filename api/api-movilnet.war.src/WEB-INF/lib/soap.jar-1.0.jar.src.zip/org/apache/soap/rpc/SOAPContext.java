/*     */ package org.apache.soap.rpc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.activation.MimeType;
/*     */ import javax.activation.MimeTypeParseException;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import org.apache.soap.util.mime.ByteArrayDataSource;
/*     */ import org.apache.soap.util.mime.MimeUtils;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPContext
/*     */ {
/*     */   protected MimeMultipart parts;
/*  84 */   protected Hashtable bag = new Hashtable();
/*  85 */   protected ClassLoader loader = null;
/*  86 */   protected Vector multiRef = new Vector();
/*  87 */   protected Hashtable deserializedMultiRef = new Hashtable();
/*  88 */   protected String currentId = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean rootPartSet = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private static final String[] ignoreHeaders = new String[] { "Message-ID", "Mime-Version" };
/*     */   private static final String DEFAULT_BASEURI = "thismessage:/";
/*     */   
/*     */   private class MultiRefInfo {
/*     */     public Object obj;
/*     */     public Serializer ser;
/*     */     private final SOAPContext this$0;
/*     */     
/*     */     public MultiRefInfo(SOAPContext this$0, Object param1Object, Serializer param1Serializer) {
/* 110 */       this.this$0 = this$0;
/* 111 */       this.obj = param1Object;
/* 112 */       this.ser = param1Serializer;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPContext() {
/* 120 */     this.parts = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readMultipart(DataSource paramDataSource) throws MessagingException {
/* 129 */     this.parts = new MimeMultipart(paramDataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart getBodyPart(int paramInt) {
/* 143 */     if (this.parts == null) {
/* 144 */       return null;
/*     */     }
/*     */     try {
/* 147 */       return (MimeBodyPart)this.parts.getBodyPart(paramInt);
/*     */     }
/* 149 */     catch (MessagingException messagingException) {
/* 150 */       throw new IndexOutOfBoundsException(messagingException.getMessage());
/*     */     }
/* 152 */     catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 153 */       return null;
/*     */     }
/* 155 */     catch (NullPointerException nullPointerException) {
/* 156 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart getBodyPart(String paramString) {
/* 168 */     if (this.parts == null) {
/* 169 */       return null;
/*     */     }
/*     */     try {
/* 172 */       return (MimeBodyPart)this.parts.getBodyPart(paramString);
/*     */     }
/* 174 */     catch (MessagingException messagingException) {
/* 175 */       return null;
/*     */     }
/* 177 */     catch (NullPointerException nullPointerException) {
/* 178 */       return null;
/*     */     }
/* 180 */     catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 181 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart findBodyPart(String paramString) {
/* 201 */     if (this.parts == null || paramString == null) {
/* 202 */       return null;
/*     */     }
/*     */     
/* 205 */     try { if (paramString.length() > 4 && paramString.substring(0, 4).equalsIgnoreCase("cid:"))
/*     */       {
/*     */         
/* 208 */         String str = MimeUtils.decode(paramString.substring(4));
/*     */ 
/*     */         
/* 211 */         if (str.charAt(0) != '<' || str.charAt(str.length()) != '>') {
/* 212 */           str = '<' + str + '>';
/*     */         }
/*     */         try {
/* 215 */           return (MimeBodyPart)this.parts.getBodyPart(str);
/* 216 */         } catch (NullPointerException nullPointerException) {}
/*     */       }
/*     */       else
/*     */       {
/* 220 */         return findPartByLocation(paramString);
/*     */       }
/*     */        }
/* 223 */     catch (MessagingException messagingException) {  }
/* 224 */     catch (NullPointerException nullPointerException) {}
/*     */     
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseURI() {
/* 238 */     String str = null;
/*     */     try {
/* 240 */       str = getRootPart().getHeader("Content-Location", null);
/*     */     }
/* 242 */     catch (MessagingException messagingException) {}
/*     */     
/* 244 */     if (str == null)
/* 245 */       str = "thismessage:/"; 
/* 246 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart findPartByLocation(String paramString) {
/*     */     try {
/* 266 */       String str = getBaseURI();
/* 267 */       paramString = normalizeURI(paramString, str);
/* 268 */       if (paramString == null)
/* 269 */         return null; 
/* 270 */       for (byte b = 0; b < this.parts.getCount(); b++) {
/* 271 */         MimeBodyPart mimeBodyPart = getBodyPart(b);
/* 272 */         if (mimeBodyPart != null) {
/* 273 */           String str1 = mimeBodyPart.getHeader("Content-Location", null);
/*     */           
/* 275 */           if (paramString.equals(normalizeURI(str1, str)))
/* 276 */             return mimeBodyPart; 
/*     */         } 
/*     */       } 
/* 279 */     } catch (MessagingException messagingException) {}
/*     */     
/* 281 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String normalizeURI(String paramString1, String paramString2) {
/* 291 */     int i = paramString1.indexOf(':');
/* 292 */     if (i >= 0) {
/* 293 */       String str = paramString1.substring(0, i);
/* 294 */       if (str.indexOf('/') == -1 && str.indexOf('?') == -1 && str.indexOf('#') == -1)
/*     */       {
/*     */ 
/*     */         
/* 298 */         return paramString1;
/*     */       }
/*     */     } 
/* 301 */     return paramString2 + paramString1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBodyPart(MimeBodyPart paramMimeBodyPart) throws MessagingException {
/* 316 */     addBodyPart(paramMimeBodyPart, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBodyPart(MimeBodyPart paramMimeBodyPart, int paramInt) throws MessagingException, IllegalArgumentException {
/* 337 */     if (this.parts == null) {
/* 338 */       this.parts = new MimeMultipart("related");
/*     */     }
/*     */ 
/*     */     
/* 342 */     DataHandler dataHandler = paramMimeBodyPart.getDataHandler();
/*     */     try {
/* 344 */       MimeType mimeType = new MimeType(dataHandler.getContentType());
/* 345 */       paramMimeBodyPart.setHeader("Content-Type", mimeType.toString());
/*     */       
/* 347 */       if (dataHandler.getDataSource() instanceof ByteArrayDataSource) {
/* 348 */         paramMimeBodyPart.setHeader("Content-Length", String.valueOf(((ByteArrayDataSource)dataHandler.getDataSource()).getSize()));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 361 */       if (mimeType.match("application/octet-stream") || mimeType.match("image/*") || mimeType.match("audio/*") || mimeType.match("video/*"))
/*     */       {
/*     */ 
/*     */         
/* 365 */         paramMimeBodyPart.setHeader("Content-Transfer-Encoding", "8bit"); } 
/* 366 */     } catch (MessagingException messagingException) {
/* 367 */       throw new IllegalArgumentException("Invalid InputStream/DataSource/DataHandler metadata: " + messagingException);
/*     */     
/*     */     }
/* 370 */     catch (MimeTypeParseException mimeTypeParseException) {
/* 371 */       throw new IllegalArgumentException("Invalid Mime type \"" + dataHandler.getContentType() + "\": " + mimeTypeParseException);
/*     */     } 
/*     */ 
/*     */     
/* 375 */     if (paramInt == -1) {
/* 376 */       this.parts.addBodyPart((BodyPart)paramMimeBodyPart);
/*     */     } else {
/* 378 */       this.parts.addBodyPart((BodyPart)paramMimeBodyPart, paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeBodyPart(MimeBodyPart paramMimeBodyPart) throws MessagingException {
/* 385 */     this.parts.removeBodyPart((BodyPart)paramMimeBodyPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRootPart(MimeBodyPart paramMimeBodyPart) throws MessagingException {
/* 399 */     String str = '<' + MimeUtils.getUniqueValue() + '>';
/* 400 */     paramMimeBodyPart.setHeader("Content-ID", str);
/* 401 */     if (this.rootPartSet)
/* 402 */       this.parts.removeBodyPart((BodyPart)getRootPart()); 
/* 403 */     addBodyPart(paramMimeBodyPart, 0);
/* 404 */     this.rootPartSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRootPart(String paramString1, String paramString2) throws MessagingException, IOException {
/* 417 */     setRootPart(paramString1.getBytes("UTF8"), paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRootPart(byte[] paramArrayOfbyte, String paramString) throws MessagingException {
/* 431 */     ByteArrayDataSource byteArrayDataSource = new ByteArrayDataSource(paramArrayOfbyte, paramString);
/* 432 */     DataHandler dataHandler = new DataHandler((DataSource)byteArrayDataSource);
/* 433 */     MimeBodyPart mimeBodyPart = new MimeBodyPart();
/* 434 */     mimeBodyPart.setDataHandler(dataHandler);
/* 435 */     mimeBodyPart.setHeader("Content-Length", String.valueOf(byteArrayDataSource.getSize()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 440 */     mimeBodyPart.setHeader("Content-Transfer-Encoding", "8bit");
/*     */     
/* 442 */     setRootPart(mimeBodyPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart getRootPart() throws MessagingException {
/* 454 */     MimeBodyPart mimeBodyPart = null;
/* 455 */     if (getCount() > 1) {
/* 456 */       String str = (new ContentType(this.parts.getContentType())).getParameter("start");
/*     */       
/* 458 */       if (str != null)
/* 459 */         mimeBodyPart = getBodyPart(MimeUtils.decode(str)); 
/*     */     } 
/* 461 */     if (mimeBodyPart == null)
/* 462 */       mimeBodyPart = getBodyPart(0); 
/* 463 */     return mimeBodyPart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubType(String paramString) throws MessagingException {
/* 475 */     if (this.parts == null) {
/* 476 */       this.parts = new MimeMultipart(paramString);
/*     */     } else {
/* 478 */       this.parts.setSubType(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRootPartSet() {
/* 485 */     return this.rootPartSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() throws MessagingException {
/* 494 */     if (this.parts == null) {
/* 495 */       return 0;
/*     */     }
/* 497 */     return this.parts.getCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() throws MessagingException {
/* 508 */     if (this.parts == null) {
/* 509 */       return null;
/*     */     }
/* 511 */     if (this.parts.getCount() == 1) {
/* 512 */       return getRootPart().getContentType();
/*     */     }
/* 514 */     return this.parts.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException {
/* 526 */     int i = getCount();
/* 527 */     if (i == 0)
/* 528 */       throw new IOException("Message is empty!"); 
/* 529 */     if (i == 1) {
/* 530 */       getRootPart().writeTo(paramOutputStream);
/*     */     } else {
/*     */       
/* 533 */       Session session = Session.getDefaultInstance(new Properties(), null);
/* 534 */       MimeMessage mimeMessage = new MimeMessage(session);
/* 535 */       mimeMessage.setContent((Multipart)this.parts);
/* 536 */       mimeMessage.saveChanges();
/* 537 */       mimeMessage.writeTo(paramOutputStream, ignoreHeaders);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String paramString, Object paramObject) {
/* 545 */     this.bag.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String paramString) {
/* 552 */     return this.bag.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object removeProperty(String paramString) {
/* 559 */     return this.bag.remove(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration getPropertyNames() {
/* 566 */     return this.bag.keys();
/*     */   }
/*     */   
/*     */   public void setClassLoader(ClassLoader paramClassLoader) {
/* 570 */     this.loader = paramClassLoader;
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 574 */     return this.loader;
/*     */   }
/*     */   
/*     */   public Class loadClass(String paramString) throws ClassNotFoundException {
/* 578 */     if (this.loader == null)
/* 579 */       return Class.forName(paramString); 
/* 580 */     return Class.forName(paramString, true, this.loader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCurrentId() {
/* 590 */     return this.currentId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentId(String paramString) {
/* 600 */     this.currentId = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addMultiRef(Object paramObject, Serializer paramSerializer) {
/* 617 */     for (byte b = 0; b < this.multiRef.size(); b++) {
/* 618 */       if (((MultiRefInfo)this.multiRef.elementAt(b)).obj == paramObject)
/* 619 */         return b; 
/*     */     } 
/* 621 */     this.multiRef.addElement(new MultiRefInfo(this, paramObject, paramSerializer));
/* 622 */     return this.multiRef.size() - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getMultiRefObject(int paramInt) {
/* 632 */     return ((MultiRefInfo)this.multiRef.elementAt(paramInt)).obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Serializer getMultiRefSerializer(int paramInt) {
/* 642 */     return ((MultiRefInfo)this.multiRef.elementAt(paramInt)).ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMultiRefCount() {
/* 651 */     return this.multiRef.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDeserializedMultiRef(String paramString, Object paramObject) {
/* 661 */     this.deserializedMultiRef.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDeserializedMultiRef(String paramString) {
/* 671 */     return this.deserializedMultiRef.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 678 */     StringWriter stringWriter = new StringWriter();
/* 679 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 681 */     printWriter.print("[Parts={");
/*     */     
/* 683 */     if (this.parts != null) {
/*     */       try {
/* 685 */         for (byte b = 0; b < getCount(); b++) {
/* 686 */           if (b > 0) {
/* 687 */             printWriter.print(", ");
/*     */           }
/*     */           
/* 690 */           MimeBodyPart mimeBodyPart = getBodyPart(b);
/* 691 */           printWriter.print("[cid:" + mimeBodyPart.getContentID() + " type: " + mimeBodyPart.getContentType() + " enc: " + mimeBodyPart.getEncoding() + "]");
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 696 */       catch (MessagingException messagingException) {
/* 697 */         messagingException.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 701 */     printWriter.print("}]");
/*     */     
/* 703 */     printWriter.print(" multiRefs: " + this.multiRef.size() + " deserializedMultiRefs: " + this.deserializedMultiRef.size());
/*     */     
/* 705 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\rpc\SOAPContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */