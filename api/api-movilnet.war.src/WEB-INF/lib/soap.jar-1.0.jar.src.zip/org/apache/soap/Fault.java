/*     */ package org.apache.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.RPCConstants;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOM2Writer;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Fault
/*     */ {
/*  81 */   private String faultCode = null;
/*  82 */   private String faultString = null;
/*  83 */   private String faultActorURI = null;
/*  84 */   private Vector detailEntries = null;
/*  85 */   private Vector faultEntries = null;
/*  86 */   private AttributeHandler attrHandler = new AttributeHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fault(SOAPException paramSOAPException) {
/*  92 */     this.faultCode = paramSOAPException.getFaultCode();
/*  93 */     this.faultString = paramSOAPException.getMessage();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(QName paramQName, String paramString) {
/*  98 */     this.attrHandler.setAttribute(paramQName, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(QName paramQName) {
/* 103 */     return this.attrHandler.getAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAttribute(QName paramQName) {
/* 108 */     this.attrHandler.removeAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void declareNamespace(String paramString1, String paramString2) {
/* 113 */     this.attrHandler.declareNamespace(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFaultCode(String paramString) {
/* 118 */     this.faultCode = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFaultCode() {
/* 123 */     return this.faultCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFaultString(String paramString) {
/* 128 */     this.faultString = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFaultString() {
/* 133 */     return this.faultString;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFaultActorURI(String paramString) {
/* 138 */     this.faultActorURI = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFaultActorURI() {
/* 143 */     return this.faultActorURI;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDetailEntries(Vector paramVector) {
/* 148 */     this.detailEntries = paramVector;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector getDetailEntries() {
/* 153 */     return this.detailEntries;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFaultEntries(Vector paramVector) {
/* 158 */     this.faultEntries = paramVector;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector getFaultEntries() {
/* 163 */     return this.faultEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 171 */     this.attrHandler.populateNSStack(paramNSStack);
/*     */     
/* 173 */     String str1 = getFaultCode();
/* 174 */     String str2 = getFaultString();
/* 175 */     String str3 = getFaultActorURI();
/* 176 */     Vector vector1 = getDetailEntries();
/* 177 */     Vector vector2 = getFaultEntries();
/*     */ 
/*     */     
/* 180 */     String str4 = this.attrHandler.getUniquePrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", "SOAP-ENV", paramNSStack);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     paramWriter.write('<' + str4 + ':' + "Fault");
/*     */ 
/*     */     
/* 188 */     this.attrHandler.marshall(paramWriter, paramSOAPContext);
/*     */     
/* 190 */     paramWriter.write('>' + StringUtils.lineSeparator + '<' + "faultcode" + '>' + str1 + "</" + "faultcode" + '>' + StringUtils.lineSeparator + '<' + "faultstring" + '>' + str2 + "</" + "faultstring" + '>' + StringUtils.lineSeparator);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     if (str3 != null)
/*     */     {
/* 201 */       paramWriter.write("<faultactor>" + str3 + "</" + "faultactor" + '>' + StringUtils.lineSeparator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (vector1 != null) {
/*     */       
/* 210 */       paramWriter.write("<detail>" + StringUtils.lineSeparator);
/*     */ 
/*     */ 
/*     */       
/* 214 */       for (Enumeration enumeration = vector1.elements(); enumeration.hasMoreElements(); ) {
/*     */         
/* 216 */         Element element = (Element)enumeration.nextElement();
/*     */ 
/*     */         
/* 219 */         if (element instanceof Element) {
/*     */           
/* 221 */           Element element1 = element;
/*     */           
/* 223 */           Utils.marshallNode(element1, paramWriter);
/* 224 */           paramWriter.write(StringUtils.lineSeparator);
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 230 */         if (element instanceof Parameter) {
/*     */           
/*     */           try {
/*     */             
/* 234 */             Parameter parameter = (Parameter)element;
/* 235 */             Serializer serializer = paramXMLJavaMappingRegistry.querySerializer(Parameter.class, paramString);
/*     */             
/* 237 */             if (serializer != null) {
/*     */               
/* 239 */               serializer.marshall(null, Parameter.class, parameter, "detailEntry", paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 247 */               paramWriter.write(StringUtils.lineSeparator);
/*     */               
/*     */               continue;
/*     */             } 
/* 251 */             throw new IllegalArgumentException("Could not find Parameter serializer.");
/*     */ 
/*     */           
/*     */           }
/* 255 */           catch (IllegalArgumentException illegalArgumentException) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 261 */       paramWriter.write("</detail>" + StringUtils.lineSeparator);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     if (vector2 != null)
/*     */     {
/* 269 */       for (Enumeration enumeration = vector2.elements(); enumeration.hasMoreElements(); ) {
/*     */         
/* 271 */         Element element = enumeration.nextElement();
/*     */         
/* 273 */         Utils.marshallNode(element, paramWriter);
/*     */         
/* 275 */         paramWriter.write(StringUtils.lineSeparator);
/*     */       } 
/*     */     }
/*     */     
/* 279 */     paramWriter.write("</" + str4 + ':' + "Fault" + '>' + StringUtils.lineSeparator);
/*     */ 
/*     */     
/* 282 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fault unmarshall(String paramString, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 289 */     Element element = (Element)paramNode;
/* 290 */     Fault fault = new Fault();
/*     */ 
/*     */     
/* 293 */     if (Constants.Q_ELEM_FAULT.matches(element)) {
/*     */       
/* 295 */       Element element1 = null;
/* 296 */       Element element2 = null;
/* 297 */       Element element3 = null;
/* 298 */       Element element4 = null;
/* 299 */       Vector vector = new Vector();
/* 300 */       Element element5 = DOMUtils.getFirstChildElement(element);
/*     */ 
/*     */       
/* 303 */       fault.attrHandler = AttributeHandler.unmarshall(element, paramSOAPContext);
/*     */ 
/*     */       
/* 306 */       while (element5 != null) {
/*     */         
/* 308 */         String str1 = element5.getNamespaceURI();
/* 309 */         String str2 = element5.getLocalName();
/*     */         
/* 311 */         if (str2 == null)
/*     */         {
/* 313 */           str2 = element5.getTagName();
/*     */         }
/*     */ 
/*     */         
/* 317 */         if (str1 == "" || str1 == null || str1.equals("http://schemas.xmlsoap.org/soap/envelope/")) {
/*     */ 
/*     */           
/* 320 */           if (str2.equals("faultcode"))
/*     */           {
/* 322 */             element1 = element5;
/*     */           }
/* 324 */           else if (str2.equals("faultstring"))
/*     */           {
/* 326 */             element2 = element5;
/*     */           }
/* 328 */           else if (str2.equals("faultactor"))
/*     */           {
/* 330 */             element3 = element5;
/*     */           }
/* 332 */           else if (str2.equals("detail"))
/*     */           {
/* 334 */             element4 = element5;
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 339 */             vector.addElement(element5);
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 345 */           vector.addElement(element5);
/*     */         } 
/*     */         
/* 348 */         element5 = DOMUtils.getNextSiblingElement(element5);
/*     */       } 
/*     */ 
/*     */       
/* 352 */       if (element1 != null) {
/*     */         
/* 354 */         String str = DOMUtils.getChildCharacterData(element1);
/*     */         
/* 356 */         fault.setFaultCode(str);
/*     */       }
/*     */       else {
/*     */         
/* 360 */         throw new IllegalArgumentException("A '" + Constants.Q_ELEM_FAULT + "' element must contain a: '" + "faultcode" + "' element.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 367 */       if (element2 != null) {
/*     */         
/* 369 */         String str = DOMUtils.getChildCharacterData(element2);
/*     */         
/* 371 */         fault.setFaultString(str);
/*     */       }
/*     */       else {
/*     */         
/* 375 */         throw new IllegalArgumentException("A '" + Constants.Q_ELEM_FAULT + "' element must contain a: '" + "faultstring" + "' element.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 382 */       if (element3 != null) {
/*     */         
/* 384 */         String str = DOMUtils.getChildCharacterData(element3);
/*     */         
/* 386 */         fault.setFaultActorURI(str);
/*     */       } 
/*     */ 
/*     */       
/* 390 */       if (element4 != null) {
/*     */         
/* 392 */         Vector vector1 = new Vector();
/*     */         
/* 394 */         Element element6 = DOMUtils.getFirstChildElement(element4);
/* 395 */         for (; element6 != null; 
/* 396 */           element6 = DOMUtils.getNextSiblingElement(element6)) {
/*     */ 
/*     */           
/*     */           try {
/*     */             
/* 401 */             String str1 = DOMUtils.getAttributeNS(element6, "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle");
/*     */ 
/*     */ 
/*     */             
/* 405 */             String str2 = (str1 != null) ? str1 : paramString;
/*     */ 
/*     */             
/* 408 */             Bean bean = paramXMLJavaMappingRegistry.unmarshall(str1, RPCConstants.Q_ELEM_PARAMETER, element6, paramSOAPContext);
/*     */ 
/*     */ 
/*     */             
/* 412 */             Parameter parameter = (Parameter)bean.value;
/*     */             
/* 414 */             vector1.addElement(parameter);
/*     */           }
/* 416 */           catch (Exception exception) {
/*     */             
/* 418 */             vector1.addElement(element6);
/*     */           } 
/*     */         } 
/*     */         
/* 422 */         fault.setDetailEntries(vector1);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 427 */       if (vector.size() > 0)
/*     */       {
/* 429 */         fault.setFaultEntries(vector);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 434 */       throw new IllegalArgumentException("Root element of a SOAP Fault must be: '" + Constants.Q_ELEM_FAULT + "'.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 439 */     return fault;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 444 */     StringWriter stringWriter = new StringWriter();
/* 445 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 447 */     printWriter.print("[Attributes=" + this.attrHandler + "] " + "[faultCode=" + this.faultCode + "] " + "[faultString=" + this.faultString + "] " + "[faultActorURI=" + this.faultActorURI + "] " + "[DetailEntries=");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 453 */     if (this.detailEntries != null) {
/*     */       
/* 455 */       printWriter.println();
/*     */       
/* 457 */       for (byte b = 0; b < this.detailEntries.size(); b++) {
/*     */         
/* 459 */         Parameter parameter = (Parameter)this.detailEntries.elementAt(b);
/*     */         
/* 461 */         if (parameter instanceof Parameter) {
/*     */           
/* 463 */           Parameter parameter1 = parameter;
/*     */           
/* 465 */           printWriter.println("[(" + b + ")=" + parameter1 + "]");
/*     */         }
/*     */         else {
/*     */           
/* 469 */           printWriter.println("[(" + b + ")=" + DOM2Writer.nodeToString((Element)parameter) + "]");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 475 */     printWriter.print("] [FaultEntries=");
/*     */     
/* 477 */     if (this.faultEntries != null) {
/*     */       
/* 479 */       printWriter.println();
/*     */       
/* 481 */       for (byte b = 0; b < this.faultEntries.size(); b++)
/*     */       {
/* 483 */         printWriter.println("[(" + b + ")=" + DOM2Writer.nodeToString(this.faultEntries.elementAt(b)) + "]");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 489 */     printWriter.print("]");
/*     */     
/* 491 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */   public Fault() {}
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\Fault.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */