package org.apache.soap.server;

import java.util.EventListener;

public interface SOAPEventListener extends EventListener {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\SOAPEventListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */