/*     */ package org.apache.soap.rpc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Vector;
/*     */ import org.apache.soap.Body;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.Fault;
/*     */ import org.apache.soap.Header;
/*     */ import org.apache.soap.Utils;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RPCMessage
/*     */   implements Serializer
/*     */ {
/*     */   protected String targetObjectURI;
/*     */   protected String fullTargetObjectURI;
/*     */   protected String methodName;
/*     */   protected Vector params;
/*     */   protected Header header;
/*     */   protected String encodingStyleURI;
/*     */   protected SOAPContext ctx;
/*     */   
/*     */   protected RPCMessage(String paramString1, String paramString2, Vector paramVector, Header paramHeader, String paramString3, SOAPContext paramSOAPContext) {
/*  89 */     setTargetObjectURI(paramString1);
/*  90 */     this.methodName = paramString2;
/*  91 */     this.params = paramVector;
/*  92 */     this.header = paramHeader;
/*  93 */     this.encodingStyleURI = paramString3;
/*  94 */     this.ctx = paramSOAPContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTargetObjectURI(String paramString) {
/*  99 */     this.fullTargetObjectURI = paramString;
/*     */ 
/*     */ 
/*     */     
/* 103 */     this.targetObjectURI = StringUtils.parseFullTargetObjectURI(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetObjectURI() {
/* 108 */     return this.targetObjectURI;
/*     */   }
/*     */   
/*     */   public void setFullTargetObjectURI(String paramString) {
/* 112 */     setTargetObjectURI(paramString);
/*     */   }
/*     */   
/*     */   public String getFullTargetObjectURI() {
/* 116 */     return this.fullTargetObjectURI;
/*     */   }
/*     */   
/*     */   public void setMethodName(String paramString) {
/* 120 */     this.methodName = paramString;
/*     */   }
/*     */   
/*     */   public String getMethodName() {
/* 124 */     return this.methodName;
/*     */   }
/*     */   
/*     */   public void setParams(Vector paramVector) {
/* 128 */     this.params = paramVector;
/*     */   }
/*     */   
/*     */   public Vector getParams() {
/* 132 */     return this.params;
/*     */   }
/*     */   
/*     */   public void setHeader(Header paramHeader) {
/* 136 */     this.header = paramHeader;
/*     */   }
/*     */   
/*     */   public Header getHeader() {
/* 140 */     return this.header;
/*     */   }
/*     */   
/*     */   public void setEncodingStyleURI(String paramString) {
/* 144 */     this.encodingStyleURI = paramString;
/*     */   }
/*     */   
/*     */   public String getEncodingStyleURI() {
/* 148 */     return this.encodingStyleURI;
/*     */   }
/*     */   
/*     */   protected void setSOAPContext(SOAPContext paramSOAPContext) {
/* 152 */     this.ctx = paramSOAPContext;
/*     */   }
/*     */   
/*     */   public SOAPContext getSOAPContext() {
/* 156 */     return this.ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Envelope buildEnvelope(boolean paramBoolean) {
/* 161 */     Envelope envelope = new Envelope();
/* 162 */     Body body = new Body();
/* 163 */     Vector vector = new Vector();
/*     */     
/* 165 */     vector.addElement(new Bean(paramBoolean ? Response.class : Call.class, this));
/*     */ 
/*     */     
/* 168 */     body.setBodyEntries(vector);
/* 169 */     envelope.setBody(body);
/* 170 */     envelope.setHeader(this.header);
/*     */     
/* 172 */     return envelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static RPCMessage extractFromEnvelope(Envelope paramEnvelope, boolean paramBoolean, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 180 */     Body body = paramEnvelope.getBody();
/* 181 */     Vector vector = body.getBodyEntries();
/* 182 */     RPCMessage rPCMessage = null;
/*     */ 
/*     */     
/* 185 */     if (vector.size() > 0) {
/* 186 */       Element element = vector.elementAt(0);
/* 187 */       Class clazz = (Class)(paramBoolean ? Response.class : Call.class);
/* 188 */       String str1 = paramEnvelope.getAttribute(new QName("http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle"));
/*     */       
/* 190 */       String str2 = body.getAttribute(new QName("http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle"));
/*     */       
/* 192 */       String str3 = (str2 != null) ? str2 : str1;
/*     */ 
/*     */ 
/*     */       
/* 196 */       rPCMessage = unmarshall(str3, element, clazz, paramSOAPMappingRegistry, paramSOAPContext);
/* 197 */       rPCMessage.setHeader(paramEnvelope.getHeader());
/*     */       
/* 199 */       return rPCMessage;
/*     */     } 
/* 201 */     throw new IllegalArgumentException("An '" + Constants.Q_ELEM_BODY + "' element must contain a " + "child element.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 211 */     paramNSStack.pushScope();
/*     */     
/* 213 */     RPCMessage rPCMessage = (RPCMessage)paramObject1;
/* 214 */     boolean bool = (paramClass == Response.class) ? true : false;
/* 215 */     String str1 = Utils.cleanString(rPCMessage.getFullTargetObjectURI());
/*     */     
/* 217 */     String str2 = rPCMessage.getMethodName();
/* 218 */     Vector vector = rPCMessage.getParams();
/* 219 */     String str3 = bool ? RPCConstants.RESPONSE_SUFFIX : "";
/*     */ 
/*     */     
/* 222 */     String str4 = rPCMessage.getEncodingStyleURI();
/* 223 */     String str5 = (str4 != null) ? str4 : paramString;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     if (bool) {
/* 229 */       Response response = (Response)rPCMessage;
/*     */       
/* 231 */       if (!response.generatedFault()) {
/*     */         
/* 233 */         StringWriter stringWriter = new StringWriter();
/* 234 */         String str6 = paramNSStack.getPrefixFromURI(str1, stringWriter);
/*     */ 
/*     */         
/* 237 */         paramWriter.write('<' + str6 + ':' + str2 + str3 + stringWriter);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 242 */         String str7 = paramNSStack.getPrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", paramWriter);
/*     */ 
/*     */         
/* 245 */         if (str4 != null && !str4.equals(paramString))
/*     */         {
/* 247 */           paramWriter.write(' ' + str7 + ':' + "encodingStyle" + "=\"" + str4 + '"');
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 252 */         paramWriter.write('>' + StringUtils.lineSeparator);
/*     */ 
/*     */         
/* 255 */         Parameter parameter = response.getReturnValue();
/*     */         
/* 257 */         if (parameter != null) {
/* 258 */           String str8 = parameter.getEncodingStyleURI();
/* 259 */           String str9 = (str8 != null) ? str8 : str5;
/*     */ 
/*     */           
/* 262 */           Serializer serializer = paramXMLJavaMappingRegistry.querySerializer(Parameter.class, str9);
/*     */ 
/*     */           
/* 265 */           serializer.marshall(str5, Parameter.class, parameter, null, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */ 
/*     */           
/* 268 */           paramWriter.write(StringUtils.lineSeparator);
/*     */         } 
/*     */         
/* 271 */         serializeParams(vector, str5, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */         
/* 273 */         paramWriter.write("</" + str6 + ':' + str2 + str3 + '>' + StringUtils.lineSeparator);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 278 */         Fault fault = response.getFault();
/*     */         
/* 280 */         fault.marshall(str5, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */       } 
/*     */     } else {
/*     */       
/* 284 */       StringWriter stringWriter = new StringWriter();
/* 285 */       String str6 = paramNSStack.getPrefixFromURI(str1, stringWriter);
/*     */ 
/*     */       
/* 288 */       paramWriter.write('<' + str6 + ':' + str2 + str3 + stringWriter);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 293 */       String str7 = paramNSStack.getPrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", paramWriter);
/*     */ 
/*     */       
/* 296 */       if (str4 != null && !str4.equals(paramString))
/*     */       {
/* 298 */         paramWriter.write(' ' + str7 + ':' + "encodingStyle" + "=\"" + str4 + '"');
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 303 */       paramWriter.write('>' + StringUtils.lineSeparator);
/*     */       
/* 305 */       serializeParams(vector, str5, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */       
/* 307 */       paramWriter.write("</" + str6 + ':' + str2 + str3 + '>');
/*     */     } 
/*     */ 
/*     */     
/* 311 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void serializeParams(Vector paramVector, String paramString, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IOException {
/* 319 */     if (paramVector != null) {
/* 320 */       int i = paramVector.size();
/*     */       
/* 322 */       for (byte b = 0; b < i; b++) {
/* 323 */         Parameter parameter = paramVector.elementAt(b);
/* 324 */         String str1 = parameter.getEncodingStyleURI();
/* 325 */         String str2 = (str1 != null) ? str1 : paramString;
/*     */ 
/*     */         
/* 328 */         Serializer serializer = paramXMLJavaMappingRegistry.querySerializer(Parameter.class, str2);
/*     */ 
/*     */         
/* 331 */         serializer.marshall(paramString, Parameter.class, parameter, null, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */ 
/*     */         
/* 334 */         paramWriter.write(StringUtils.lineSeparator);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RPCMessage unmarshall(String paramString, Node paramNode, Class paramClass, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 344 */     Element element = (Element)paramNode;
/* 345 */     boolean bool = (paramClass == Response.class) ? true : false;
/* 346 */     String str1 = null;
/* 347 */     String str2 = null;
/* 348 */     String str3 = null;
/* 349 */     Parameter parameter = null;
/* 350 */     Fault fault = null;
/* 351 */     Vector vector = null;
/* 352 */     String str4 = DOMUtils.getAttributeNS(element, "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle");
/*     */     
/* 354 */     String str5 = (str4 != null) ? str4 : paramString;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 359 */     if (bool && Constants.Q_ELEM_FAULT.matches(element)) {
/* 360 */       fault = Fault.unmarshall(str5, element, (XMLJavaMappingRegistry)paramSOAPMappingRegistry, paramSOAPContext);
/*     */     } else {
/*     */       
/* 363 */       String str = element.getLocalName();
/*     */ 
/*     */       
/* 366 */       str1 = element.getNamespaceURI();
/* 367 */       str2 = StringUtils.parseFullTargetObjectURI(str1);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 372 */       paramSOAPMappingRegistry.setDefaultEncodingStyle("http://schemas.xmlsoap.org/soap/encoding/");
/*     */       
/* 374 */       str3 = str;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 382 */       if (bool && str3.endsWith(RPCConstants.RESPONSE_SUFFIX))
/*     */       {
/* 384 */         str3 = str3.substring(0, str3.length() - 8);
/*     */       }
/*     */       
/* 387 */       Element element1 = DOMUtils.getFirstChildElement(element);
/*     */ 
/*     */       
/* 390 */       if (bool && element1 != null) {
/* 391 */         String str6 = DOMUtils.getAttributeNS(element1, "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle");
/*     */         
/* 393 */         String str7 = (str6 != null) ? str6 : str5;
/*     */ 
/*     */         
/* 396 */         Bean bean = paramSOAPMappingRegistry.unmarshall(str7, RPCConstants.Q_ELEM_PARAMETER, element1, paramSOAPContext);
/*     */ 
/*     */ 
/*     */         
/* 400 */         parameter = (Parameter)bean.value;
/*     */         
/* 402 */         if (str6 != null)
/*     */         {
/* 404 */           parameter.setEncodingStyleURI(str6);
/*     */         }
/*     */         
/* 407 */         element1 = DOMUtils.getNextSiblingElement(element1);
/*     */       } 
/*     */ 
/*     */       
/* 411 */       if (element1 != null) {
/* 412 */         vector = new Vector();
/* 413 */         for (; element1 != null; 
/* 414 */           element1 = DOMUtils.getNextSiblingElement(element1)) {
/* 415 */           String str6 = DOMUtils.getAttributeNS(element1, "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle");
/*     */           
/* 417 */           String str7 = (str6 != null) ? str6 : str5;
/*     */ 
/*     */           
/* 420 */           Bean bean = paramSOAPMappingRegistry.unmarshall(str7, RPCConstants.Q_ELEM_PARAMETER, element1, paramSOAPContext);
/*     */ 
/*     */           
/* 423 */           Parameter parameter1 = (Parameter)bean.value;
/*     */           
/* 425 */           if (str6 != null) {
/* 426 */             parameter1.setEncodingStyleURI(str6);
/*     */           }
/*     */           
/* 429 */           vector.addElement(parameter1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 434 */     Call call = (Call)(bool ? ((fault == null) ? new Response(str1, str3, parameter, vector, null, str5, paramSOAPContext) : new Response(str1, str3, fault, vector, null, str5, paramSOAPContext)) : new Call(str1, str3, vector, null, str5, paramSOAPContext));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     if (call instanceof Call) {
/* 446 */       ((Call)call).setSOAPMappingRegistry(paramSOAPMappingRegistry);
/*     */     }
/*     */     
/* 449 */     return call;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 453 */     StringWriter stringWriter = new StringWriter();
/* 454 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/* 455 */     boolean bool = this instanceof Response;
/*     */     
/* 457 */     printWriter.print("[Header=" + this.header + "] " + "[methodName=" + this.methodName + "] " + "[targetObjectURI=" + this.targetObjectURI + "] " + "[encodingStyleURI=" + this.encodingStyleURI + "] " + "[SOAPContext=" + this.ctx + "] ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     if (bool) {
/* 464 */       Response response = (Response)this;
/*     */       
/* 466 */       if (response.generatedFault()) {
/* 467 */         printWriter.print("[fault=" + response.getFault() + "] ");
/*     */       } else {
/* 469 */         printWriter.println("[return=" + response.getReturnValue() + "] ");
/*     */       } 
/*     */     } 
/*     */     
/* 473 */     printWriter.print("[Params={");
/*     */     
/* 475 */     if (this.params != null) {
/* 476 */       for (byte b = 0; b < this.params.size(); b++) {
/* 477 */         if (b > 0) {
/* 478 */           printWriter.print(", ");
/*     */         }
/*     */         
/* 481 */         printWriter.print("[" + this.params.elementAt(b) + "]");
/*     */       } 
/*     */     }
/*     */     
/* 485 */     printWriter.print("}]");
/*     */     
/* 487 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\rpc\RPCMessage.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */