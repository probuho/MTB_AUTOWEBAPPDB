/*     */ package org.apache.soap.util.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NSStack
/*     */ {
/*  84 */   Vector nss = new Vector();
/*  85 */   int nssCount = 0;
/*     */   Vector tos;
/*     */   private static final String nsPrefixPrefix = "ns";
/*  88 */   private int nsPrefixCount = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushScope() {
/*  95 */     this.nss.addElement(this.tos = new Vector());
/*  96 */     this.nssCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void popScope() {
/* 105 */     this.nss.removeElementAt(--this.nssCount);
/* 106 */     this.tos = (this.nssCount != 0) ? this.nss.elementAt(this.nssCount - 1) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addNSDeclaration(String paramString1, String paramString2) {
/* 117 */     this.tos.addElement(new NSDecl(paramString1, paramString2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String addNSDeclaration(String paramString) {
/* 132 */     String str = getPrefixFromURI(paramString);
/* 133 */     if (str == null)
/*     */       while (true) {
/* 135 */         str = "ns" + this.nsPrefixCount++;
/* 136 */         if (getURIFromPrefix(str) == null) {
/* 137 */           addNSDeclaration(str, paramString); break;
/*     */         } 
/* 139 */       }   return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefixFromURI(String paramString) {
/* 150 */     for (int i = this.nssCount - 1; i >= 0; i--) {
/* 151 */       Vector vector = this.nss.elementAt(i);
/* 152 */       for (Enumeration enumeration = vector.elements(); enumeration.hasMoreElements(); ) {
/* 153 */         NSDecl nSDecl = enumeration.nextElement();
/* 154 */         if (nSDecl.URI.equals(paramString)) {
/* 155 */           return nSDecl.prefix;
/*     */         }
/*     */       } 
/*     */     } 
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String getPrefixFromURI(String paramString, Writer paramWriter) throws IOException {
/* 174 */     String str = getPrefixFromURI(paramString);
/*     */     
/* 176 */     if (str == null) {
/* 177 */       str = addNSDeclaration(paramString);
/*     */       
/* 179 */       paramWriter.write(" xmlns:" + str + "=\"" + paramString + '"');
/*     */     } 
/*     */     
/* 182 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getURIFromPrefix(String paramString) {
/* 193 */     for (int i = this.nssCount - 1; i >= 0; i--) {
/* 194 */       Vector vector = this.nss.elementAt(i);
/* 195 */       for (Enumeration enumeration = vector.elements(); enumeration.hasMoreElements(); ) {
/* 196 */         NSDecl nSDecl = enumeration.nextElement();
/* 197 */         if (nSDecl.prefix.equals(paramString)) {
/* 198 */           return nSDecl.URI;
/*     */         }
/*     */       } 
/*     */     } 
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 208 */     return this.nss.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\NSStack.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */