package org.apache.soap.transport;

import java.io.BufferedReader;
import java.net.URL;
import java.util.Hashtable;
import org.apache.soap.Envelope;
import org.apache.soap.SOAPException;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.rpc.SOAPContext;

public interface SOAPTransport {
  void send(URL paramURL, String paramString, Hashtable paramHashtable, Envelope paramEnvelope, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws SOAPException;
  
  BufferedReader receive();
  
  Hashtable getHeaders();
  
  SOAPContext getResponseSOAPContext();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\transport\SOAPTransport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */