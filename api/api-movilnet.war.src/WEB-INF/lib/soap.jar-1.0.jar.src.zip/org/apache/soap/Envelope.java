/*     */ package org.apache.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOM2Writer;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Envelope
/*     */ {
/*  77 */   private Header header = null;
/*  78 */   private Body body = null;
/*  79 */   private Vector envelopeEntries = null;
/*  80 */   private AttributeHandler attrHandler = new AttributeHandler();
/*     */ 
/*     */ 
/*     */   
/*     */   public Envelope() {
/*  85 */     declareNamespace("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */ 
/*     */     
/*  89 */     declareNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
/*     */ 
/*     */ 
/*     */     
/*  93 */     declareNamespace("xsd", "http://www.w3.org/2001/XMLSchema");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(QName paramQName, String paramString) {
/*  99 */     this.attrHandler.setAttribute(paramQName, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(QName paramQName) {
/* 104 */     return this.attrHandler.getAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAttribute(QName paramQName) {
/* 109 */     this.attrHandler.removeAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void declareNamespace(String paramString1, String paramString2) {
/* 114 */     this.attrHandler.declareNamespace(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHeader(Header paramHeader) {
/* 119 */     this.header = paramHeader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Header getHeader() {
/* 124 */     return this.header;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBody(Body paramBody) {
/* 129 */     this.body = paramBody;
/*     */   }
/*     */ 
/*     */   
/*     */   public Body getBody() {
/* 134 */     return this.body;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnvelopeEntries(Vector paramVector) {
/* 139 */     this.envelopeEntries = paramVector;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector getEnvelopeEntries() {
/* 144 */     return this.envelopeEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(Writer paramWriter, XMLJavaMappingRegistry paramXMLJavaMappingRegistry) throws IllegalArgumentException, IOException {
/* 154 */     marshall(paramWriter, paramXMLJavaMappingRegistry, new SOAPContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(Writer paramWriter, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 161 */     marshall(paramWriter, paramXMLJavaMappingRegistry, paramSOAPContext, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(Writer paramWriter, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext, boolean paramBoolean) throws IllegalArgumentException, IOException {
/* 169 */     NSStack nSStack = new NSStack();
/*     */     
/* 171 */     this.attrHandler.populateNSStack(nSStack);
/*     */     
/* 173 */     Header header = getHeader();
/* 174 */     Body body = getBody();
/* 175 */     Vector vector = getEnvelopeEntries();
/* 176 */     String str1 = getAttribute(new QName("http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle"));
/*     */ 
/*     */ 
/*     */     
/* 180 */     String str2 = this.attrHandler.getUniquePrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", "SOAP-ENV", nSStack);
/*     */ 
/*     */ 
/*     */     
/* 184 */     if (paramBoolean) {
/* 185 */       paramWriter.write("<?xml version='1.0' encoding='UTF-8'?>\r\n");
/*     */     }
/* 187 */     paramWriter.write('<' + str2 + ':' + "Envelope");
/*     */ 
/*     */     
/* 190 */     this.attrHandler.marshall(paramWriter, paramSOAPContext);
/*     */     
/* 192 */     paramWriter.write('>' + StringUtils.lineSeparator);
/*     */ 
/*     */     
/* 195 */     if (header != null)
/*     */     {
/* 197 */       header.marshall(paramWriter, nSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */     }
/*     */ 
/*     */     
/* 201 */     if (body != null) {
/*     */       
/* 203 */       body.marshall(str1, paramWriter, nSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */     }
/*     */     else {
/*     */       
/* 207 */       throw new IllegalArgumentException("An '" + Constants.Q_ELEM_ENVELOPE + "' must contain a: '" + Constants.Q_ELEM_BODY + "'.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (vector != null)
/*     */     {
/* 215 */       for (Enumeration enumeration = vector.elements(); enumeration.hasMoreElements(); ) {
/*     */         
/* 217 */         Element element = enumeration.nextElement();
/*     */         
/* 219 */         Utils.marshallNode(element, paramWriter);
/*     */         
/* 221 */         paramWriter.write(StringUtils.lineSeparator);
/*     */       } 
/*     */     }
/*     */     
/* 225 */     paramWriter.write("</" + str2 + ':' + "Envelope" + '>' + StringUtils.lineSeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Envelope unmarshall(Node paramNode) throws IllegalArgumentException {
/* 236 */     return unmarshall(paramNode, new SOAPContext());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Envelope unmarshall(Node paramNode, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 242 */     Element element = (Element)paramNode;
/* 243 */     Envelope envelope = new Envelope();
/*     */     
/* 245 */     if (Constants.Q_ELEM_ENVELOPE.matches(element)) {
/*     */ 
/*     */       
/* 248 */       envelope.attrHandler = AttributeHandler.unmarshall(element, paramSOAPContext);
/*     */ 
/*     */       
/* 251 */       Element element1 = null;
/* 252 */       Element element2 = null;
/* 253 */       Element element3 = DOMUtils.getFirstChildElement(element);
/*     */       
/* 255 */       if (Constants.Q_ELEM_HEADER.matches(element3)) {
/*     */         
/* 257 */         element1 = element3;
/* 258 */         element3 = DOMUtils.getNextSiblingElement(element3);
/*     */       } 
/*     */       
/* 261 */       if (Constants.Q_ELEM_BODY.matches(element3)) {
/*     */         
/* 263 */         element2 = element3;
/* 264 */         element3 = DOMUtils.getNextSiblingElement(element3);
/*     */       } 
/*     */ 
/*     */       
/* 268 */       if (element1 != null) {
/*     */         
/* 270 */         Header header = Header.unmarshall(element1, paramSOAPContext);
/*     */         
/* 272 */         envelope.setHeader(header);
/*     */       } 
/*     */ 
/*     */       
/* 276 */       if (element2 != null) {
/*     */         
/* 278 */         Body body = Body.unmarshall(element2, paramSOAPContext);
/*     */         
/* 280 */         envelope.setBody(body);
/*     */       }
/*     */       else {
/*     */         
/* 284 */         throw new IllegalArgumentException("An '" + Constants.Q_ELEM_ENVELOPE + "' element must contain a: '" + Constants.Q_ELEM_BODY + "' element.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 291 */       if (element3 != null)
/*     */       {
/* 293 */         Vector vector = new Vector();
/*     */         
/* 295 */         while (element3 != null) {
/*     */           
/* 297 */           vector.addElement(element3);
/* 298 */           element3 = DOMUtils.getNextSiblingElement(element3);
/*     */         } 
/*     */         
/* 301 */         envelope.setEnvelopeEntries(vector);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 306 */       String str = element.getLocalName();
/*     */       
/* 308 */       if (str != null && str.equals("Envelope"))
/*     */       {
/* 310 */         throw new IllegalArgumentException(Constants.ERR_MSG_VERSION_MISMATCH);
/*     */       }
/*     */ 
/*     */       
/* 314 */       throw new IllegalArgumentException("Root element of a SOAP message must be: '" + Constants.Q_ELEM_ENVELOPE + "'.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     return envelope;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 325 */     StringWriter stringWriter = new StringWriter();
/* 326 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 328 */     printWriter.print("[Attributes=" + this.attrHandler + "] " + "[Header=" + this.header + "] " + "[Body=" + this.body + "] " + "[EnvelopeEntries=");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 333 */     if (this.envelopeEntries != null) {
/*     */       
/* 335 */       printWriter.println();
/*     */       
/* 337 */       for (byte b = 0; b < this.envelopeEntries.size(); b++)
/*     */       {
/* 339 */         printWriter.println("[(" + b + ")=" + DOM2Writer.nodeToString(this.envelopeEntries.elementAt(b)) + "]");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 345 */     printWriter.print("]");
/*     */     
/* 347 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\Envelope.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */