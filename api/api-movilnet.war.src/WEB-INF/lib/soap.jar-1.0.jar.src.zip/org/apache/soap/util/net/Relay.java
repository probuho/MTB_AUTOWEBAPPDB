/*    */ package org.apache.soap.util.net;
/*    */ 
/*    */ import java.awt.TextArea;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Relay
/*    */   extends Thread
/*    */ {
/*    */   static final int BUFSIZ = 1000;
/*    */   InputStream in;
/*    */   OutputStream out;
/* 75 */   byte[] buf = new byte[1000];
/*    */   TextArea ta;
/*    */   
/*    */   Relay(InputStream paramInputStream, OutputStream paramOutputStream, TextArea paramTextArea) {
/* 79 */     this.in = paramInputStream;
/* 80 */     this.out = paramOutputStream;
/* 81 */     this.ta = paramTextArea;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     
/*    */     try { int i;
/* 88 */       while ((i = this.in.read(this.buf)) > 0) {
/* 89 */         this.out.write(this.buf, 0, i);
/* 90 */         this.out.flush();
/* 91 */         if (this.ta != null) {
/* 92 */           this.ta.append(new String(this.buf, 0, i, "8859_1"));
/*    */         }
/*    */       }  }
/* 95 */     catch (IOException iOException)
/*    */     
/*    */     { try {
/* 98 */         this.in.close();
/* 99 */         this.out.close();
/* :0 */       } catch (IOException iOException1) {} } finally { try { this.in.close(); this.out.close(); } catch (IOException iOException) {} }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\net\Relay.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */