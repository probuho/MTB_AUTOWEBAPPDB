/*     */ package org.apache.soap.rpc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.net.URL;
/*     */ import java.util.Vector;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import oracle.soap.transport.http.OracleSOAPHTTPConnection;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.Header;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.transport.SOAPTransport;
/*     */ import org.apache.soap.transport.http.SOAPHTTPConnection;
/*     */ import org.apache.soap.util.IOUtils;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Call
/*     */   extends RPCMessage
/*     */ {
/*  89 */   private SOAPMappingRegistry smr = null;
/*  90 */   private SOAPTransport st = null;
/*  91 */   private int to = 0;
/*     */ 
/*     */   
/*     */   public Call() {
/*  95 */     this((String)null, (String)null, (Vector)null, (Header)null, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Call(String paramString1, String paramString2, Vector paramVector, Header paramHeader, String paramString3) {
/* 101 */     this(paramString1, paramString2, paramVector, paramHeader, paramString3, new SOAPContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call(String paramString1, String paramString2, Vector paramVector, Header paramHeader, String paramString3, SOAPContext paramSOAPContext) {
/* 108 */     super(paramString1, paramString2, paramVector, paramHeader, paramString3, paramSOAPContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSOAPMappingRegistry(SOAPMappingRegistry paramSOAPMappingRegistry) {
/* 113 */     this.smr = paramSOAPMappingRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPMappingRegistry getSOAPMappingRegistry() {
/* 119 */     if (this.smr == null)
/*     */     {
/* 121 */       this.smr = new SOAPMappingRegistry();
/*     */     }
/*     */     
/* 124 */     return this.smr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSOAPTransport(SOAPTransport paramSOAPTransport) {
/* 129 */     this.st = paramSOAPTransport;
/*     */   }
/*     */ 
/*     */   
/*     */   public SOAPTransport getSOAPTransport() {
/* 134 */     return this.st;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(int paramInt) {
/* 143 */     this.to = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeout() {
/* 152 */     return this.to;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBodyPart(MimeBodyPart paramMimeBodyPart) throws MessagingException {
/* 163 */     this.ctx.addBodyPart(paramMimeBodyPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeBodyPart(MimeBodyPart paramMimeBodyPart) throws MessagingException {
/* 171 */     this.ctx.removeBodyPart(paramMimeBodyPart);
/*     */   }
/*     */ 
/*     */   
/*     */   public Envelope buildEnvelope() {
/* 176 */     return buildEnvelope(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Call extractFromEnvelope(Envelope paramEnvelope, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 183 */     return (Call)RPCMessage.extractFromEnvelope(paramEnvelope, false, paramSOAPMappingRegistry, paramSOAPContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEnvelopeString(SOAPTransport paramSOAPTransport) throws SOAPException, MessagingException, IOException {
/* 195 */     SOAPContext sOAPContext = paramSOAPTransport.getResponseSOAPContext();
/* 196 */     BufferedReader bufferedReader = null;
/* 197 */     String str = null;
/*     */     
/* 199 */     MimeBodyPart mimeBodyPart = sOAPContext.getRootPart();
/* 200 */     if (mimeBodyPart.isMimeType("text/*")) {
/*     */       
/* 202 */       bufferedReader = paramSOAPTransport.receive();
/* 203 */       str = IOUtils.getStringFromReader(bufferedReader);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (!mimeBodyPart.isMimeType("text/xml")) {
/* 209 */       throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, "Unsupported response content type \"" + mimeBodyPart.getContentType() + "\", must be: \"" + "text/xml" + "\"." + ((str == null) ? "" : (" Response was:\n" + str)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response invoke(URL paramURL, String paramString) throws SOAPException {
/* 224 */     if (paramString == null)
/*     */     {
/* 226 */       paramString = "";
/*     */     }
/*     */ 
/*     */     
/* 230 */     if (this.smr == null)
/*     */     {
/* 232 */       this.smr = new SOAPMappingRegistry();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 238 */       Envelope envelope1 = buildEnvelope();
/*     */ 
/*     */       
/* 241 */       if (this.st == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 248 */         this.st = (SOAPTransport)new OracleSOAPHTTPConnection();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 253 */       if (this.to != 0 && this.st instanceof SOAPHTTPConnection) {
/* 254 */         ((SOAPHTTPConnection)this.st).setTimeout(this.to);
/*     */       }
/*     */       
/* 257 */       if (this.to != 0 && this.st instanceof OracleSOAPHTTPConnection) {
/* 258 */         ((OracleSOAPHTTPConnection)this.st).setTimeout(this.to);
/*     */       }
/*     */       
/* 261 */       this.st.send(paramURL, paramString, null, envelope1, this.smr, this.ctx);
/*     */ 
/*     */       
/* 264 */       SOAPContext sOAPContext = this.st.getResponseSOAPContext();
/*     */ 
/*     */ 
/*     */       
/* 268 */       String str1 = getEnvelopeString(this.st);
/*     */ 
/*     */       
/* 271 */       DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/* 272 */       Document document = documentBuilder.parse(new InputSource(new StringReader(str1)));
/*     */       
/* 274 */       Element element = null;
/*     */       
/* 276 */       if (document != null) {
/*     */         
/* 278 */         element = document.getDocumentElement();
/*     */       }
/*     */       else {
/*     */         
/* 282 */         throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, "Parsing error, response was:\n" + str1);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 287 */       Envelope envelope2 = Envelope.unmarshall(element, sOAPContext);
/*     */ 
/*     */       
/* 290 */       Response response = Response.extractFromEnvelope(envelope2, this.smr, sOAPContext);
/*     */ 
/*     */       
/* 293 */       String str2 = response.getFullTargetObjectURI();
/*     */       
/* 295 */       if (str2 != null)
/*     */       {
/* 297 */         setTargetObjectURI(str2);
/*     */       }
/*     */       
/* 300 */       return response;
/*     */     }
/* 302 */     catch (MessagingException messagingException) {
/*     */       
/* 304 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, messagingException.getMessage(), messagingException);
/*     */     }
/* 306 */     catch (IllegalArgumentException illegalArgumentException) {
/*     */       
/* 308 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, illegalArgumentException.getMessage(), illegalArgumentException);
/*     */     }
/* 310 */     catch (SAXException sAXException) {
/*     */       
/* 312 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Parsing error, response was:\n" + sAXException.getMessage(), sAXException);
/*     */ 
/*     */     
/*     */     }
/* 316 */     catch (IOException iOException) {
/*     */       
/* 318 */       throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, iOException.getMessage(), iOException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\rpc\Call.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */