/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FPDeserUtil
/*     */ {
/*     */   public static Float newFloat(String paramString) {
/*  93 */     Float float_ = null;
/*     */     try {
/*  95 */       float_ = new Float(paramString);
/*  96 */     } catch (NumberFormatException numberFormatException) {
/*  97 */       if (paramString.equals("INF") || paramString.toLowerCase().equals("infinity"))
/*     */       {
/*  99 */         return new Float(Float.POSITIVE_INFINITY); } 
/* 100 */       if (paramString.equals("-INF") || paramString.toLowerCase().equals("-infinity"))
/*     */       {
/* 102 */         return new Float(Float.NEGATIVE_INFINITY); } 
/* 103 */       if (paramString.equals("NaN")) {
/* 104 */         return new Float(Float.NaN);
/*     */       }
/* 106 */       throw numberFormatException;
/*     */     } 
/* 108 */     return float_;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Double newDouble(String paramString) {
/* 113 */     Double double_ = null;
/*     */     try {
/* 115 */       double_ = new Double(paramString);
/* 116 */     } catch (NumberFormatException numberFormatException) {
/* 117 */       if (paramString.equals("INF") || paramString.toLowerCase().equals("infinity"))
/*     */       {
/* 119 */         return new Double(Double.POSITIVE_INFINITY); } 
/* 120 */       if (paramString.equals("-INF") || paramString.toLowerCase().equals("-infinity"))
/*     */       {
/* 122 */         return new Double(Double.NEGATIVE_INFINITY); } 
/* 123 */       if (paramString.equals("NaN")) {
/* 124 */         return new Double(Double.NaN);
/*     */       }
/* 126 */       throw numberFormatException;
/*     */     } 
/* 128 */     return double_;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\FPDeserUtil.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */