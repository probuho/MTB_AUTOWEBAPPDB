/*     */ package org.apache.soap.server.http;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.server.ServerUtils;
/*     */ import org.apache.soap.transport.EnvelopeEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerHTTPUtils
/*     */ {
/*     */   private static final String SERVICE_MANAGER_ID = "serviceManager";
/*     */   private static final String SCRIPT_CLASS = "com.ibm.bsf.BSFManager";
/*     */   private static final String SCRIPT_INVOKER = "org.apache.soap.server.InvokeBSF";
/*     */   private static final String SERVLET_CLASSLOADER = "servletClassLoader";
/*     */   
/*     */   public static ClassLoader getServletClassLoaderFromContext(ServletContext paramServletContext) {
/* 133 */     if (paramServletContext != null) {
/*     */       Object object;
/*     */       
/* 136 */       synchronized (paramServletContext) {
/* 137 */         object = paramServletContext.getAttribute("servletClassLoader");
/*     */       } 
/*     */       
/* 140 */       return (ClassLoader)object;
/*     */     } 
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setServletClassLoaderIntoContext(ServletContext paramServletContext, ClassLoader paramClassLoader) {
/* 151 */     synchronized (paramServletContext) {
/* 152 */       paramServletContext.setAttribute("servletClassLoader", paramClassLoader);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getFileFromNameAndContext(String paramString, ServletContext paramServletContext) {
/* 166 */     File file = new File(paramString);
/*     */     
/* 168 */     if (!file.isAbsolute())
/*     */     {
/* 170 */       if (paramServletContext != null) {
/*     */         
/* 172 */         String str = paramServletContext.getRealPath(File.separator + paramString);
/*     */         
/* 174 */         if (str != null)
/*     */         {
/* 176 */           file = new File(str);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 181 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Envelope readEnvelopeFromRequest(DocumentBuilder paramDocumentBuilder, String paramString, int paramInt, InputStream paramInputStream, EnvelopeEditor paramEnvelopeEditor, HttpServletResponse paramHttpServletResponse, SOAPContext paramSOAPContext) throws SOAPException, IOException {
/*     */     try {
/* 205 */       return ServerUtils.readEnvelopeFromInputStream(paramDocumentBuilder, paramInputStream, paramInt, paramString, paramEnvelopeEditor, paramSOAPContext);
/*     */ 
/*     */     
/*     */     }
/* 209 */     catch (IllegalArgumentException illegalArgumentException) {
/* 210 */       String str = illegalArgumentException.getMessage();
/* 211 */       paramHttpServletResponse.sendError(400, "Error unmarshalling envelope: " + str);
/*     */       
/* 213 */       return null;
/* 214 */     } catch (MessagingException messagingException) {
/* 215 */       paramHttpServletResponse.sendError(400, "Error unmarshalling envelope: " + messagingException);
/*     */       
/* 217 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SOAPMappingRegistry getSMRFromContext(ServletContext paramServletContext) {
/* 376 */     SOAPMappingRegistry sOAPMappingRegistry = null;
/* 377 */     synchronized (paramServletContext) {
/* 378 */       sOAPMappingRegistry = (SOAPMappingRegistry)paramServletContext.getAttribute("__cached_servlet_SMR__");
/*     */       
/* 380 */       if (sOAPMappingRegistry == null) {
/* 381 */         sOAPMappingRegistry = new SOAPMappingRegistry();
/* 382 */         paramServletContext.setAttribute("__cached_servlet_SMR__", sOAPMappingRegistry);
/*     */       } 
/*     */     } 
/* 385 */     return sOAPMappingRegistry;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\http\ServerHTTPUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */