/*     */ package org.apache.soap.transport.http;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cookie
/*     */ {
/*     */   private static final int DEFAULT_HTTP_PORT = 80;
/*     */   private long createdMillis;
/*     */   private URL url;
/*     */   private String defaultDomain;
/*     */   private int defaultPort;
/*     */   private String defaultPath;
/*     */   private String name;
/*     */   private String value;
/*     */   private String comment;
/*     */   private String domain;
/*     */   private long maxAge;
/*     */   private String path;
/*     */   private boolean secure;
/*     */   private String version;
/*     */   private String commentURL;
/*     */   private boolean discard;
/*     */   private int[] port;
/*     */   private long expires;
/* 111 */   private static SimpleDateFormat dateParser = new SimpleDateFormat("EEE, dd-MMM-yyyy HH:mm:ss z");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie(URL paramURL, String paramString) {
/*     */     String str1, str2;
/*     */     this.comment = null;
/*     */     this.domain = null;
/*     */     this.maxAge = Long.MAX_VALUE;
/*     */     this.path = null;
/*     */     this.secure = false;
/*     */     this.version = null;
/*     */     this.commentURL = null;
/*     */     this.discard = false;
/*     */     this.port = null;
/*     */     this.expires = Long.MAX_VALUE;
/* 129 */     paramString = removeLeadingSpaces(paramString);
/* 130 */     int i = paramString.indexOf(';');
/* 131 */     if (i != -1)
/* 132 */     { str1 = paramString.substring(0, i);
/* 133 */       if (paramString.length() > i) {
/* 134 */         str2 = paramString.substring(i + 1);
/*     */       } else {
/* 136 */         str2 = "";
/*     */       }  }
/* 138 */     else { str1 = paramString;
/* 139 */       str2 = ""; }
/*     */ 
/*     */ 
/*     */     
/* 143 */     i = str1.indexOf('=');
/* 144 */     if (i != -1) {
/* 145 */       this.name = str1.substring(0, i);
/* 146 */       if (str1.length() > i) {
/* 147 */         this.value = removeEnclosingQuotes(str1.substring(i + 1));
/*     */       } else {
/* 149 */         this.value = "";
/*     */       } 
/*     */     } else {
/* 152 */       this.name = str1;
/* 153 */       this.value = "";
/*     */     } 
/*     */ 
/*     */     
/* 157 */     StringTokenizer stringTokenizer = new StringTokenizer(str2, ";");
/* 158 */     while (stringTokenizer.hasMoreTokens()) {
/* 159 */       String str3, str4; str1 = removeLeadingSpaces(stringTokenizer.nextToken());
/* 160 */       i = str1.indexOf('=');
/* 161 */       if (i != -1) {
/* 162 */         str3 = str1.substring(0, i);
/* 163 */         if (str1.length() > i) {
/* 164 */           str4 = removeEnclosingQuotes(str1.substring(i + 1));
/*     */         } else {
/* 166 */           str4 = "";
/*     */         } 
/*     */       } else {
/* 169 */         str3 = str1;
/* 170 */         str4 = "";
/*     */       } 
/* 172 */       if (str3.equalsIgnoreCase("Comment")) {
/* 173 */         if (this.comment == null)
/* 174 */           this.comment = str4;  continue;
/* 175 */       }  if (str3.equalsIgnoreCase("Domain")) {
/*     */         
/* 177 */         if (this.domain == null)
/* 178 */           this.domain = str4;  continue;
/* 179 */       }  if (str3.equalsIgnoreCase("Max-Age")) {
/* 180 */         if (this.maxAge == Long.MAX_VALUE)
/*     */           try {
/* 182 */             this.maxAge = Long.parseLong(str4);
/* 183 */             this.expires = System.currentTimeMillis() + this.maxAge * 1000L;
/* 184 */           } catch (NumberFormatException numberFormatException) {} 
/*     */         continue;
/*     */       } 
/* 187 */       if (str3.equalsIgnoreCase("Path")) {
/* 188 */         if (this.path == null)
/* 189 */           this.path = str4;  continue;
/* 190 */       }  if (str3.equalsIgnoreCase("Secure")) {
/* 191 */         this.secure = true; continue;
/* 192 */       }  if (str3.equalsIgnoreCase("Version")) {
/* 193 */         if (this.version == null)
/* 194 */           this.version = str4;  continue;
/* 195 */       }  if (str3.equalsIgnoreCase("CommentURL")) {
/* 196 */         if (this.commentURL == null)
/* 197 */           this.commentURL = str4;  continue;
/* 198 */       }  if (str3.equalsIgnoreCase("Discard")) {
/* 199 */         this.version = str4; continue;
/* 200 */       }  if (str3.equalsIgnoreCase("Port")) {
/* 201 */         if (this.port == null) {
/* 202 */           if (str4.length() == 0) {
/* 203 */             this.port = new int[0]; continue;
/*     */           } 
/*     */           try {
/* 206 */             StringTokenizer stringTokenizer1 = new StringTokenizer(str4, ",");
/* 207 */             int[] arrayOfInt = new int[stringTokenizer1.countTokens()];
/* 208 */             byte b = 0;
/* 209 */             while (stringTokenizer1.hasMoreTokens())
/* 210 */               arrayOfInt[b++] = Integer.parseInt(stringTokenizer1.nextToken()); 
/* 211 */             this.port = arrayOfInt;
/* 212 */           } catch (NumberFormatException numberFormatException) {}
/*     */         } 
/*     */         continue;
/*     */       } 
/* 216 */       if (str3.equalsIgnoreCase("Expires") && 
/* 217 */         this.expires == Long.MAX_VALUE) {
/*     */         try {
/* 219 */           this.expires = dateParser.parse(str4).getTime();
/* 220 */         } catch (ParseException parseException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     setURL(paramURL);
/* 229 */     this.createdMillis = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String buildCookieValue(URL paramURL, Cookie[] paramArrayOfCookie) {
/* 241 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */     
/* 244 */     for (byte b = 0; b < paramArrayOfCookie.length; b++) {
/* 245 */       Cookie cookie = paramArrayOfCookie[b];
/* 246 */       if (!cookie.getExpired() && cookie.sendToURL(paramURL)) {
/* 247 */         if (stringBuffer.length() > 0)
/* 248 */           stringBuffer.append(';'); 
/* 249 */         stringBuffer.append(cookie.toString());
/*     */       } 
/*     */     } 
/*     */     
/* 253 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 264 */     if (!(paramObject instanceof Cookie)) {
/* 265 */       return false;
/*     */     }
/* 267 */     Cookie cookie = (Cookie)paramObject;
/* 268 */     return (this.name.equals(cookie.name) && this.value.equals(cookie.value) && sameAttribute(this.domain, this.defaultDomain, cookie.domain, cookie.defaultDomain) && sameAttribute(this.path, this.defaultPath, cookie.path, cookie.defaultPath) && samePort(this.port, this.defaultPort, cookie.port, cookie.defaultPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getExpired() {
/* 280 */     return (System.currentTimeMillis() > this.expires);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cookie[] parseCookies(URL paramURL, String paramString) {
/* 296 */     int i = 0;
/* 297 */     boolean bool = false;
/* 298 */     Vector vector = new Vector();
/*     */     
/* 300 */     for (byte b1 = 0; b1 < paramString.length(); b1++) {
/* 301 */       char c = paramString.charAt(b1);
/* 302 */       if (c == '"') {
/* 303 */         bool = !bool ? true : false;
/* 304 */       } else if (c == ',' && !bool) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 309 */         if (b1 < 11 || !paramString.substring(b1 - 11, b1 - 3).equalsIgnoreCase("expires=")) {
/* 310 */           vector.addElement(new Cookie(paramURL, paramString.substring(i, b1)));
/* 311 */           i = b1 + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 316 */     if (i < paramString.length()) {
/* 317 */       vector.addElement(new Cookie(paramURL, paramString.substring(i)));
/*     */     }
/* 319 */     Cookie[] arrayOfCookie = new Cookie[vector.size()];
/* 320 */     for (byte b2 = 0; b2 < vector.size(); b2++)
/* 321 */       arrayOfCookie[b2] = vector.elementAt(b2); 
/* 322 */     return arrayOfCookie;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String removeEnclosingQuotes(String paramString) {
/* 332 */     return (paramString.startsWith("\"") && paramString.endsWith("\"")) ? paramString.substring(1, paramString.length() - 1) : paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String removeLeadingSpaces(String paramString) {
/*     */     byte b;
/* 343 */     for (b = 0; b < paramString.length() && paramString.charAt(b) == ' '; b++);
/*     */     
/* 345 */     return (b == 0) ? paramString : paramString.substring(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean sameAttribute(String paramString1, String paramString2, String paramString3, String paramString4) {
/* 358 */     if (paramString1 != null && paramString3 != null)
/* 359 */       return paramString1.equals(paramString3); 
/* 360 */     if (paramString1 == null && paramString3 == null)
/* 361 */       return paramString2.equals(paramString4); 
/* 362 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean sameCookie(Cookie paramCookie1, Cookie paramCookie2) {
/* 374 */     return (paramCookie1.name.equals(paramCookie2.name) && sameAttribute(paramCookie1.domain, paramCookie1.defaultDomain, paramCookie2.domain, paramCookie2.defaultDomain) && sameAttribute(paramCookie1.path, paramCookie1.defaultPath, paramCookie2.path, paramCookie2.defaultPath) && samePort(paramCookie1.port, paramCookie1.defaultPort, paramCookie2.port, paramCookie2.defaultPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean samePort(int[] paramArrayOfint1, int paramInt1, int[] paramArrayOfint2, int paramInt2) {
/* 390 */     if (paramArrayOfint1 != null && paramArrayOfint2 != null) {
/*     */       
/* 392 */       if (paramArrayOfint1.length != paramArrayOfint2.length)
/* 393 */         return false; 
/* 394 */       if (paramArrayOfint1.length == 0)
/* 395 */         return (paramInt1 == paramInt2); 
/* 396 */       for (byte b = 0; b < paramArrayOfint1.length; b++) {
/* 397 */         byte b1; for (b1 = 0; b1 < paramArrayOfint2.length && 
/* 398 */           paramArrayOfint1[b] != paramArrayOfint2[b1]; b1++);
/*     */         
/* 400 */         if (b1 >= paramArrayOfint2.length)
/* 401 */           return false; 
/*     */       } 
/* 403 */       return true;
/*     */     } 
/*     */     
/* 406 */     if (paramArrayOfint1 == null && paramArrayOfint2 == null) {
/* 407 */       return true;
/*     */     }
/* 409 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sendToURL(URL paramURL) {
/* 424 */     if (this.domain != null) {
/* 425 */       if (paramURL.getHost().indexOf(this.domain) == -1) {
/* 426 */         return false;
/*     */       }
/* 428 */     } else if (paramURL.getHost().indexOf(this.defaultDomain) == -1) {
/* 429 */       return false;
/*     */     } 
/*     */     
/* 432 */     if (this.path != null) {
/*     */       
/* 434 */       if (!getPath(paramURL).startsWith(this.path)) {
/* 435 */         return false;
/*     */       }
/*     */     }
/* 438 */     else if (!getPath(paramURL).startsWith(this.defaultPath)) {
/* 439 */       return false;
/*     */     } 
/*     */     
/* 442 */     if (this.port != null) {
/* 443 */       int i = paramURL.getPort();
/* 444 */       if (i == -1)
/* 445 */         i = 80; 
/* 446 */       if (this.port.length == 0) {
/* 447 */         if (this.defaultPort != i)
/* 448 */           return false; 
/*     */       } else {
/*     */         byte b;
/* 451 */         for (b = 0; b < this.port.length && 
/* 452 */           this.port[b] != i; b++);
/*     */         
/* 454 */         if (b >= this.port.length) {
/* 455 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 459 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setURL(URL paramURL) {
/* 468 */     this.url = paramURL;
/* 469 */     this.defaultDomain = paramURL.getHost();
/* 470 */     this.defaultPort = paramURL.getPort();
/* 471 */     if (this.defaultPort == -1) {
/* 472 */       this.defaultPort = 80;
/*     */     }
/* 474 */     this.defaultPath = getPath(paramURL);
/* 475 */     int i = this.defaultPath.lastIndexOf('/');
/* 476 */     if (i != -1) {
/* 477 */       this.defaultPath = this.defaultPath.substring(0, i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 486 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 494 */     if (this.version != null) {
/* 495 */       stringBuffer.append(";$version=");
/* 496 */       stringBuffer.append(this.version);
/*     */     } 
/* 498 */     stringBuffer.append(this.name);
/* 499 */     stringBuffer.append('=');
/* 500 */     stringBuffer.append(this.value);
/* 501 */     if (this.domain != null) {
/* 502 */       stringBuffer.append(";$domain=");
/* 503 */       stringBuffer.append(this.domain);
/*     */     } 
/* 505 */     if (this.path != null) {
/* 506 */       stringBuffer.append(";$path=");
/* 507 */       stringBuffer.append(this.path);
/*     */     } 
/* 509 */     if (this.port != null) {
/* 510 */       stringBuffer.append(";$port");
/* 511 */       if (this.port.length > 0) {
/* 512 */         stringBuffer.append("=\"");
/* 513 */         for (byte b = 0; b < this.port.length; b++) {
/* 514 */           if (b > 0)
/* 515 */             stringBuffer.append(','); 
/* 516 */           stringBuffer.append(this.port[b]);
/*     */         } 
/* 518 */         stringBuffer.append('"');
/*     */       } 
/*     */     } 
/*     */     
/* 522 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cookie[] updateCookies(Cookie[] paramArrayOfCookie1, Cookie[] paramArrayOfCookie2) {
/* 535 */     Vector vector = new Vector();
/*     */     
/*     */     byte b1;
/*     */     
/* 539 */     for (b1 = 0; b1 < paramArrayOfCookie2.length; b1++) {
/* 540 */       Cookie cookie1 = paramArrayOfCookie2[b1];
/* 541 */       Cookie cookie2 = null;
/*     */       byte b;
/* 543 */       for (b = 0; b < paramArrayOfCookie1.length; b++) {
/* 544 */         cookie2 = paramArrayOfCookie1[b];
/* 545 */         if (sameCookie(cookie2, cookie1))
/*     */           break; 
/*     */       } 
/* 548 */       if (b < paramArrayOfCookie1.length) {
/*     */         
/* 550 */         cookie2.value = cookie1.value;
/* 551 */         cookie2.comment = cookie1.comment;
/* 552 */         cookie2.commentURL = cookie1.commentURL;
/* 553 */         cookie2.maxAge = cookie1.maxAge;
/* 554 */         cookie2.secure = cookie1.secure;
/* 555 */         cookie2.version = cookie1.version;
/* 556 */         cookie2.expires = cookie1.expires;
/*     */       } else {
/*     */         
/* 559 */         vector.addElement(cookie1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 564 */     if (vector.size() == 0) {
/* 565 */       return paramArrayOfCookie1;
/*     */     }
/*     */     
/* 568 */     Cookie[] arrayOfCookie = new Cookie[paramArrayOfCookie1.length + vector.size()];
/* 569 */     for (b1 = 0; b1 < paramArrayOfCookie1.length; b1++)
/* 570 */       arrayOfCookie[b1] = paramArrayOfCookie1[b1]; 
/* 571 */     for (byte b2 = 0; b2 < vector.size(); b2++) {
/* 572 */       arrayOfCookie[b1 + b2] = vector.elementAt(b2);
/*     */     }
/* 574 */     return arrayOfCookie;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPath(URL paramURL) {
/* 586 */     String str = paramURL.getFile();
/* 587 */     int i = str.indexOf('?');
/* 588 */     if (i != -1)
/* 589 */       str = str.substring(0, i); 
/* 590 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\transport\http\Cookie.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */