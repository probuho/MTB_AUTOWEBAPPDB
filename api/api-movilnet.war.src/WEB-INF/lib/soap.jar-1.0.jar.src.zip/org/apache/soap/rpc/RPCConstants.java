/*    */ package org.apache.soap.rpc;
/*    */ 
/*    */ import org.apache.soap.util.xml.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RPCConstants
/*    */ {
/* 72 */   public static String ELEM_PARAMETER = "Parameter";
/* 73 */   public static String ELEM_RETURN = "return";
/*    */ 
/*    */   
/* 76 */   public static QName Q_ELEM_PARAMETER = new QName("http://schemas.xmlsoap.org/soap/envelope/", ELEM_PARAMETER);
/*    */ 
/*    */ 
/*    */   
/* 80 */   public static String RESPONSE_SUFFIX = "Response";
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\rpc\RPCConstants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */