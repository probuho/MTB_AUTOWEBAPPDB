/*     */ package org.apache.soap.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.soap.encoding.soapenc.SoapEncUtils;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeMappingSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  93 */     TypeMapping typeMapping = (TypeMapping)paramObject1;
/*     */     
/*  95 */     paramNSStack.pushScope();
/*  96 */     SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */     
/*  98 */     paramWriter.write(StringUtils.lineSeparator);
/*     */ 
/*     */     
/* 101 */     String str1 = paramNSStack.getPrefixFromURI("http://www.w3.org/2001/XMLSchema-instance");
/* 102 */     String str2 = paramNSStack.getPrefixFromURI("http://www.w3.org/2001/XMLSchema");
/* 103 */     if (str1 == null || str2 == null) {
/* 104 */       throw new IllegalArgumentException("required namespace names 'http://www.w3.org/2001/XMLSchema-instance' and/or 'http://www.w3.org/2001/XMLSchema' is not defined.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (typeMapping.encodingStyle != null) {
/* 112 */       paramWriter.write("<encodingStyle " + str1 + ":type=\"" + str2 + ":string\">" + typeMapping.encodingStyle + "</encodingStyle>");
/*     */       
/* 114 */       paramWriter.write(StringUtils.lineSeparator);
/*     */     } 
/*     */     
/* 117 */     if (typeMapping.elementType != null) {
/* 118 */       paramWriter.write("<elementType-ns " + str1 + ":type=\"" + str2 + ":string\">" + typeMapping.elementType.getNamespaceURI() + "</elementType-ns>");
/*     */ 
/*     */       
/* 121 */       paramWriter.write(StringUtils.lineSeparator);
/*     */       
/* 123 */       paramWriter.write("<elementType-lp " + str1 + ":type=\"" + str2 + ":string\">" + typeMapping.elementType.getLocalPart() + "</elementType-lp>");
/*     */ 
/*     */       
/* 126 */       paramWriter.write(StringUtils.lineSeparator);
/*     */     } 
/*     */     
/* 129 */     if (typeMapping.sqlType != null) {
/* 130 */       paramWriter.write("<sqlType " + str1 + ":type=\"" + str2 + ":string\">" + typeMapping.sqlType + "</sqlType>");
/*     */       
/* 132 */       paramWriter.write(StringUtils.lineSeparator);
/*     */     } 
/*     */     
/* 135 */     if (typeMapping.javaType != null) {
/* 136 */       paramWriter.write("<javaType " + str1 + ":type=\"" + str2 + ":string\">" + typeMapping.javaType + "</javaType>");
/*     */       
/* 138 */       paramWriter.write(StringUtils.lineSeparator);
/*     */     } 
/*     */     
/* 141 */     if (typeMapping.xml2JavaClassName != null) {
/* 142 */       paramWriter.write("<xml2JavaClassName " + str1 + ":type=\"" + str2 + ":string\">" + typeMapping.xml2JavaClassName + "</xml2JavaClassName>");
/*     */ 
/*     */       
/* 145 */       paramWriter.write(StringUtils.lineSeparator);
/*     */     } 
/*     */     
/* 148 */     if (typeMapping.java2XMLClassName != null) {
/* 149 */       paramWriter.write("<java2XMLClassName " + str1 + ":type=\"" + str2 + ":string\">" + typeMapping.java2XMLClassName + "</java2XMLClassName>");
/*     */ 
/*     */       
/* 152 */       paramWriter.write(StringUtils.lineSeparator);
/*     */     } 
/*     */     
/* 155 */     paramWriter.write("</" + paramObject2 + '>');
/* 156 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 166 */     NodeList nodeList = paramNode.getChildNodes();
/* 167 */     int i = nodeList.getLength();
/*     */ 
/*     */     
/* 170 */     String str1 = null;
/* 171 */     String str2 = null;
/* 172 */     String str3 = null;
/* 173 */     QName qName = null;
/* 174 */     String str4 = null;
/* 175 */     String str5 = null;
/* 176 */     String str6 = null;
/* 177 */     String str7 = null;
/*     */     
/* 179 */     for (byte b = 0; b < i; b++) {
/* 180 */       Node node = nodeList.item(b);
/* 181 */       if (node.getNodeType() == 1) {
/*     */ 
/*     */         
/* 184 */         Element element = (Element)node;
/* 185 */         String str8 = element.getTagName();
/* 186 */         String str9 = DOMUtils.getChildCharacterData(element);
/* 187 */         if (str8.equals("encodingStyle")) {
/* 188 */           str1 = str9;
/* 189 */         } else if (str8.equals("elementType-ns")) {
/* 190 */           str2 = str9;
/* 191 */         } else if (str8.equals("elementType-lp")) {
/* 192 */           str3 = str9;
/* 193 */         } else if (str8.equals("javaType")) {
/* 194 */           str4 = str9;
/* 195 */         } else if (str8.equals("sqlType")) {
/* 196 */           str5 = str9;
/* 197 */         } else if (str8.equals("java2XMLClassName")) {
/* 198 */           str6 = str9;
/* 199 */         } else if (str8.equals("xml2JavaClassName")) {
/* 200 */           str7 = str9;
/*     */         } else {
/* 202 */           throw new IllegalArgumentException("unknown element '" + str8 + "' while " + "unmarshalling a TypeMapping");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 208 */     if (str2 != null && str3 != null) {
/* 209 */       qName = new QName(str2, str3);
/*     */     }
/*     */     
/* 212 */     return new Bean(TypeMapping.class, new TypeMapping(str1, qName, str4, str6, str7, str5));
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\TypeMappingSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */