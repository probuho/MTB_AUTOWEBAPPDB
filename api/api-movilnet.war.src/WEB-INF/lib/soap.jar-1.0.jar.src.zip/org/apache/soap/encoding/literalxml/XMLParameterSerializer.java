/*     */ package org.apache.soap.encoding.literalxml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.soap.Utils;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLParameterSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  83 */     paramNSStack.pushScope();
/*     */     
/*  85 */     Parameter parameter = (Parameter)paramObject1;
/*  86 */     Class clazz = parameter.getType();
/*  87 */     String str = parameter.getName();
/*     */     
/*  89 */     if (clazz == Element.class) {
/*     */       
/*  91 */       Element element = (Element)parameter.getValue();
/*     */       
/*  93 */       paramWriter.write('<' + str);
/*     */       
/*  95 */       if (paramString == null || !paramString.equals("http://xml.apache.org/xml-soap/literalxml")) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 100 */         String str1 = paramNSStack.getPrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", paramWriter);
/*     */ 
/*     */         
/* 103 */         paramWriter.write(' ' + str1 + ':' + "encodingStyle" + "=\"" + "http://xml.apache.org/xml-soap/literalxml" + '"');
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 108 */       paramWriter.write('>' + StringUtils.lineSeparator);
/* 109 */       Utils.marshallNode(element, paramWriter);
/* 110 */       paramWriter.write(StringUtils.lineSeparator + "</" + str + '>');
/*     */     }
/*     */     else {
/*     */       
/* 114 */       throw new IllegalArgumentException("I only know how to serialize an 'org.w3c.dom.Element'.");
/*     */     } 
/*     */ 
/*     */     
/* 118 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 125 */     Element element1 = (Element)paramNode;
/* 126 */     String str = element1.getTagName();
/* 127 */     Element element2 = DOMUtils.getFirstChildElement(element1);
/* 128 */     Parameter parameter = new Parameter(str, Element.class, element2, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     return new Bean(Parameter.class, parameter);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\literalxml\XMLParameterSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */