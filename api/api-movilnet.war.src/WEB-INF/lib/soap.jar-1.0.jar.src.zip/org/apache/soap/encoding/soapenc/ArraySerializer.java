/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Array;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArraySerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  83 */     paramNSStack.pushScope();
/*     */     
/*  85 */     String str = (paramObject1 != null) ? (Array.getLength(paramObject1) + "") : "";
/*     */ 
/*     */     
/*  88 */     Class clazz = paramClass.getComponentType();
/*  89 */     QName qName = paramXMLJavaMappingRegistry.queryElementType(clazz, "http://schemas.xmlsoap.org/soap/encoding/");
/*     */ 
/*     */     
/*  92 */     if (paramObject1 == null) {
/*     */       
/*  94 */       SoapEncUtils.generateNullArray(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, qName, str);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 105 */       SoapEncUtils.generateArrayHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, qName, str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       paramWriter.write(StringUtils.lineSeparator);
/*     */       
/* 116 */       int i = Array.getLength(paramObject1);
/*     */       
/* 118 */       for (byte b = 0; b < i; b++) {
/*     */         
/* 120 */         paramNSStack.pushScope();
/*     */         
/* 122 */         Object object = Array.get(paramObject1, b);
/*     */         
/* 124 */         if (object == null) {
/*     */           
/* 126 */           SoapEncUtils.generateNullStructure(paramString, clazz, "item", paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 131 */           Class clazz1 = object.getClass();
/*     */ 
/*     */           
/* 134 */           String str1 = clazz.getName();
/*     */           
/* 136 */           if ("org.w3c.dom.Document".equals(str1) || "org.w3c.dom.DocumentFragment".equals(str1)) {
/*     */ 
/*     */             
/* 139 */             paramXMLJavaMappingRegistry.marshall("http://schemas.xmlsoap.org/soap/encoding/", clazz, object, "item", paramWriter, paramNSStack, paramSOAPContext);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 144 */             paramXMLJavaMappingRegistry.marshall("http://schemas.xmlsoap.org/soap/encoding/", clazz1, object, "item", paramWriter, paramNSStack, paramSOAPContext);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 149 */         paramWriter.write(StringUtils.lineSeparator);
/* 150 */         paramNSStack.popScope();
/*     */       } 
/*     */       
/* 153 */       paramWriter.write("</" + paramObject2 + '>');
/*     */     } 
/*     */     
/* 156 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 163 */     Element element1 = (Element)paramNode;
/* 164 */     String str = element1.getTagName();
/* 165 */     QName qName = new QName("", "");
/* 166 */     Object object = getNewArray(paramString, element1, qName, paramXMLJavaMappingRegistry);
/*     */     
/* 168 */     if (SoapEncUtils.isNull(element1))
/*     */     {
/* 170 */       return new Bean(object.getClass(), null);
/*     */     }
/*     */     
/* 173 */     Element element2 = DOMUtils.getFirstChildElement(element1);
/* 174 */     int i = Array.getLength(object);
/*     */     
/* 176 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 178 */       String str1 = DOMUtils.getAttributeNS(element2, "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle");
/*     */       
/* 180 */       String str2 = (str1 != null) ? str1 : paramString;
/*     */ 
/*     */       
/* 183 */       QName qName1 = SoapEncUtils.getTypeQName(element2);
/* 184 */       QName qName2 = (qName1 != null) ? qName1 : qName;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       String str3 = element2.getAttribute("href");
/* 190 */       Element element = element2;
/*     */       
/* 192 */       if (str3 != null && !str3.equals("") && str3.charAt(0) == '#') {
/*     */         
/* 194 */         str3 = str3.substring(1);
/* 195 */         element = DOMUtils.getElementByID(paramNode.getOwnerDocument().getDocumentElement(), str3);
/* 196 */         if (element == null) {
/* 197 */           throw new IllegalArgumentException("No such ID '" + str3 + "'");
/*     */         }
/*     */       } 
/*     */       
/* 201 */       if (!SoapEncUtils.isNull(element)) {
/*     */         
/* 203 */         Bean bean = paramXMLJavaMappingRegistry.unmarshall(str2, qName2, element, paramSOAPContext);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 208 */         Array.set(object, b, bean.value);
/*     */       } 
/*     */       
/* 211 */       element2 = DOMUtils.getNextSiblingElement(element2);
/*     */     } 
/*     */     
/* 214 */     return new Bean(object.getClass(), object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getNewArray(String paramString, Element paramElement, QName paramQName, XMLJavaMappingRegistry paramXMLJavaMappingRegistry) throws IllegalArgumentException {
/* 222 */     QName qName = SoapEncUtils.getAttributeValue(paramElement, "http://schemas.xmlsoap.org/soap/encoding/", "arrayType", "array", true);
/*     */     
/* 224 */     String str1 = qName.getNamespaceURI();
/* 225 */     String str2 = qName.getLocalPart();
/* 226 */     int i = str2.lastIndexOf('[');
/* 227 */     int j = str2.lastIndexOf(']');
/*     */     
/* 229 */     if (i == -1 || j == -1 || j < i)
/*     */     {
/*     */ 
/*     */       
/* 233 */       throw new IllegalArgumentException("Malformed arrayTypeValue '" + qName + "'.");
/*     */     }
/*     */ 
/*     */     
/* 237 */     String str3 = str2.substring(0, i);
/*     */ 
/*     */     
/* 240 */     if (str3.endsWith("]"))
/*     */     {
/* 242 */       throw new IllegalArgumentException("Arrays of arrays are not supported '" + qName + "'.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 247 */     paramQName.setNamespaceURI(str1);
/* 248 */     paramQName.setLocalPart(str3);
/*     */     
/* 250 */     int k = DOMUtils.countKids(paramElement, (short)1);
/* 251 */     String str4 = str2.substring(i + 1, j);
/*     */ 
/*     */ 
/*     */     
/* 255 */     if (str4.length() > 0) {
/*     */       
/* 257 */       if (str4.indexOf(',') != -1)
/*     */       {
/* 259 */         throw new IllegalArgumentException("Multi-dimensional arrays are not supported '" + str4 + "'.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 266 */         int m = Integer.parseInt(str4);
/*     */         
/* 268 */         if (k != m)
/*     */         {
/* 270 */           throw new IllegalArgumentException("Explicit array length is not equal to the number of items '" + m + " != " + k + "'.");
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 276 */       catch (NumberFormatException numberFormatException) {
/*     */         
/* 278 */         throw new IllegalArgumentException("Explicit array length is not a valid integer '" + str4 + "'.");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 284 */     Class clazz = paramXMLJavaMappingRegistry.queryJavaType(paramQName, paramString);
/*     */     
/* 286 */     return Array.newInstance(clazz, k);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\ArraySerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */