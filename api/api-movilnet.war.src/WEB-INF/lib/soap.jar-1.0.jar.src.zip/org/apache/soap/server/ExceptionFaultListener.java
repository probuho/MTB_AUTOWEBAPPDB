/*    */ package org.apache.soap.server;
/*    */ 
/*    */ import java.util.Vector;
/*    */ import org.apache.soap.rpc.Parameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionFaultListener
/*    */   implements SOAPFaultListener
/*    */ {
/*    */   public void fault(SOAPFaultEvent paramSOAPFaultEvent) {
/* 79 */     Vector vector = new Vector();
/*    */     
/* 81 */     Parameter parameter = new Parameter("detailEntry", paramSOAPFaultEvent.getSOAPException().getRootException().getClass(), paramSOAPFaultEvent.getSOAPException().getRootException(), "http://schemas.xmlsoap.org/soap/encoding/");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 87 */     vector.addElement(parameter);
/* 88 */     paramSOAPFaultEvent.getFault().setDetailEntries(vector);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\ExceptionFaultListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */