/*     */ package org.apache.soap.rpc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parameter
/*     */ {
/*  78 */   private String name = null;
/*  79 */   private Class type = null;
/*  80 */   private Object value = null;
/*  81 */   private String encodingStyleURI = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parameter(String paramString1, Class paramClass, Object paramObject, String paramString2) {
/*  88 */     this.name = paramString1;
/*  89 */     this.type = paramClass;
/*  90 */     this.value = paramObject;
/*  91 */     this.encodingStyleURI = paramString2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/*  96 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 101 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(Class paramClass) {
/* 106 */     this.type = paramClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getType() {
/* 111 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(Object paramObject) {
/* 116 */     this.value = paramObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 121 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEncodingStyleURI(String paramString) {
/* 126 */     this.encodingStyleURI = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEncodingStyleURI() {
/* 131 */     return this.encodingStyleURI;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "[name=" + this.name + "] " + "[type=" + this.type + "] " + "[value=" + this.value + "] " + "[encodingStyleURI=" + this.encodingStyleURI + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\rpc\Parameter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */