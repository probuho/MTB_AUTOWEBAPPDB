/*     */ package org.apache.soap.util.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.encoding.soapenc.MimePartSerializer;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLJavaMappingRegistry
/*     */ {
/*  78 */   private Hashtable sReg = new Hashtable();
/*  79 */   private Hashtable dsReg = new Hashtable();
/*  80 */   private Hashtable xml2JavaReg = new Hashtable();
/*  81 */   private Hashtable java2XMLReg = new Hashtable();
/*  82 */   private String defaultEncodingStyle = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultEncodingStyle(String paramString) {
/*  90 */     this.defaultEncodingStyle = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mapTypes(String paramString, QName paramQName, Class paramClass, Serializer paramSerializer, Deserializer paramDeserializer) {
/*  97 */     String str1 = getKey(paramClass, paramString);
/*  98 */     String str2 = getKey(paramQName, paramString);
/*     */     
/* 100 */     if (paramSerializer != null)
/*     */     {
/* 102 */       this.sReg.put(str1, paramSerializer);
/*     */     }
/*     */     
/* 105 */     if (paramDeserializer != null)
/*     */     {
/* 107 */       this.dsReg.put(str2, paramDeserializer);
/*     */     }
/*     */ 
/*     */     
/* 111 */     if (paramQName != null && paramClass != null) {
/*     */       
/* 113 */       this.java2XMLReg.put(str1, paramQName);
/* 114 */       this.xml2JavaReg.put(str2, paramClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Serializer querySerializer_(Class paramClass, String paramString) {
/* 126 */     if (paramString == null) {
/* 127 */       paramString = this.defaultEncodingStyle;
/*     */     }
/* 129 */     String str = getKey(paramClass, paramString);
/* 130 */     Serializer serializer = (Serializer)this.sReg.get(str);
/*     */     
/* 132 */     if (serializer != null)
/*     */     {
/* 134 */       return serializer;
/*     */     }
/*     */ 
/*     */     
/* 138 */     str = getKey(null, paramString);
/* 139 */     return (Serializer)this.sReg.get(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Serializer querySerializer(Class paramClass, String paramString) throws IllegalArgumentException {
/* 150 */     Serializer serializer = querySerializer_(paramClass, paramString);
/* 151 */     if (serializer != null)
/*     */     {
/* 153 */       return serializer;
/*     */     }
/*     */ 
/*     */     
/* 157 */     throw new IllegalArgumentException("No Serializer found to serialize a '" + getClassName(paramClass) + "' using encoding style '" + paramString + "'.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Deserializer queryDeserializer_(QName paramQName, String paramString) {
/* 173 */     if (paramString == null) {
/* 174 */       paramString = this.defaultEncodingStyle;
/*     */     }
/*     */     
/* 177 */     String str = getKey(paramQName, paramString);
/* 178 */     Deserializer deserializer = (Deserializer)this.dsReg.get(str);
/*     */     
/* 180 */     if (deserializer != null)
/*     */     {
/* 182 */       return deserializer;
/*     */     }
/*     */ 
/*     */     
/* 186 */     str = getKey(null, paramString);
/* 187 */     return (Deserializer)this.dsReg.get(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Deserializer queryDeserializer(QName paramQName, String paramString) throws IllegalArgumentException {
/* 199 */     Deserializer deserializer = queryDeserializer_(paramQName, paramString);
/* 200 */     if (deserializer != null)
/*     */     {
/* 202 */       return deserializer;
/*     */     }
/*     */ 
/*     */     
/* 206 */     throw new IllegalArgumentException("No Deserializer found to deserialize a '" + paramQName + "' using encoding style '" + paramString + "'.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected QName queryElementType_(Class paramClass, String paramString) {
/* 220 */     if (paramString == null) {
/* 221 */       paramString = this.defaultEncodingStyle;
/*     */     }
/*     */     
/* 224 */     String str = getKey(paramClass, paramString);
/* 225 */     return (QName)this.java2XMLReg.get(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName queryElementType(Class paramClass, String paramString) throws IllegalArgumentException {
/* 235 */     QName qName = queryElementType_(paramClass, paramString);
/* 236 */     if (qName != null)
/*     */     {
/* 238 */       return qName;
/*     */     }
/*     */ 
/*     */     
/* 242 */     throw new IllegalArgumentException("No mapping found for '" + getClassName(paramClass) + "' using encoding style '" + paramString + "'.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class queryJavaType_(QName paramQName, String paramString) {
/* 256 */     if (paramString == null) {
/* 257 */       paramString = this.defaultEncodingStyle;
/*     */     }
/*     */     
/* 260 */     String str = getKey(paramQName, paramString);
/* 261 */     return (Class)this.xml2JavaReg.get(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class queryJavaType(QName paramQName, String paramString) throws IllegalArgumentException {
/* 271 */     Class clazz = queryJavaType_(paramQName, paramString);
/* 272 */     if (clazz != null)
/*     */     {
/* 274 */       return clazz;
/*     */     }
/*     */ 
/*     */     
/* 278 */     throw new IllegalArgumentException("No mapping found for '" + paramQName + "' using encoding style '" + paramString + "'.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 290 */     Serializer serializer = querySerializer(paramClass, paramString);
/*     */     
/* 292 */     serializer.marshall(paramString, paramClass, paramObject1, paramObject2, paramWriter, paramNSStack, this, paramSOAPContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/*     */     MimePartSerializer mimePartSerializer;
/* 300 */     Deserializer deserializer = null;
/*     */     try {
/* 302 */       deserializer = queryDeserializer(paramQName, paramString);
/*     */     }
/* 304 */     catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */       
/* 307 */       String str = ((Element)paramNode).getAttribute("href");
/* 308 */       if (str != null && !str.equals("")) {
/* 309 */         mimePartSerializer = SOAPMappingRegistry.partSer;
/*     */       } else {
/* 311 */         throw illegalArgumentException;
/*     */       } 
/*     */     } 
/* 314 */     return mimePartSerializer.unmarshall(paramString, paramQName, paramNode, this, paramSOAPContext);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getKey(Object paramObject, String paramString) {
/* 319 */     return paramObject + " + " + paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String getClassName(Class paramClass) {
/* 324 */     return (paramClass != null) ? StringUtils.getClassName(paramClass) : "null";
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\XMLJavaMappingRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */