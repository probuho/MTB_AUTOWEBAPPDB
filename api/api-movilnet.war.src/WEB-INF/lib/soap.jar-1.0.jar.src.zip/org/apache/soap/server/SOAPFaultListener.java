package org.apache.soap.server;

public interface SOAPFaultListener extends SOAPEventListener {
  void fault(SOAPFaultEvent paramSOAPFaultEvent);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\SOAPFaultListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */