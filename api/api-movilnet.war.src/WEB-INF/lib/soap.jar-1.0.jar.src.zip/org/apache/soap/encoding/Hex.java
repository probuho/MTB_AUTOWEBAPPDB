/*     */ package org.apache.soap.encoding;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hex
/*     */ {
/*  66 */   byte[] m_value = null;
/*     */   
/*     */   public static final String ERROR_ODD_NUMBER_OF_DIGITS = "Odd number of digits in hex string";
/*     */ 
/*     */   
/*     */   public Hex(String paramString) {
/*  72 */     this.m_value = decode(paramString);
/*     */   } public static final String ERROR_BAD_CHARACTER_IN_HEX_STRING = "Bad character or insufficient number of characters in hex string";
/*     */   public Hex() {}
/*     */   public byte[] getBytes() {
/*  76 */     return this.m_value;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  80 */     return encode(this.m_value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  85 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  90 */     String str1 = paramObject.toString();
/*  91 */     String str2 = toString();
/*  92 */     return str1.equals(str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static final int[] DEC = new int[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(String paramString) {
/* 134 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 135 */     for (byte b = 0; b < paramString.length(); b += 2) {
/* 136 */       char c1 = paramString.charAt(b);
/* 137 */       if (b + 1 >= paramString.length()) {
/* 138 */         throw new IllegalArgumentException("Odd number of digits in hex string");
/*     */       }
/* 140 */       char c2 = paramString.charAt(b + 1);
/* 141 */       byte b1 = 0;
/* 142 */       if (c1 >= '0' && c1 <= '9') {
/* 143 */         b1 = (byte)(b1 + (c1 - 48) * 16);
/* 144 */       } else if (c1 >= 'a' && c1 <= 'f') {
/* 145 */         b1 = (byte)(b1 + (c1 - 97 + 10) * 16);
/* 146 */       } else if (c1 >= 'A' && c1 <= 'F') {
/* 147 */         b1 = (byte)(b1 + (c1 - 65 + 10) * 16);
/*     */       } else {
/* 149 */         throw new IllegalArgumentException("Bad character or insufficient number of characters in hex string");
/*     */       } 
/* 151 */       if (c2 >= '0' && c2 <= '9') {
/* 152 */         b1 = (byte)(b1 + c2 - 48);
/* 153 */       } else if (c2 >= 'a' && c2 <= 'f') {
/* 154 */         b1 = (byte)(b1 + c2 - 97 + 10);
/* 155 */       } else if (c2 >= 'A' && c2 <= 'F') {
/* 156 */         b1 = (byte)(b1 + c2 - 65 + 10);
/*     */       } else {
/* 158 */         throw new IllegalArgumentException("Bad character or insufficient number of characters in hex string");
/*     */       } 
/* 160 */       byteArrayOutputStream.write(b1);
/*     */     } 
/* 162 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(byte[] paramArrayOfbyte) {
/* 175 */     StringBuffer stringBuffer = new StringBuffer(paramArrayOfbyte.length * 2);
/* 176 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/* 177 */       stringBuffer.append(convertDigit(paramArrayOfbyte[b] >> 4));
/* 178 */       stringBuffer.append(convertDigit(paramArrayOfbyte[b] & 0xF));
/*     */     } 
/* 180 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int convert2Int(byte[] paramArrayOfbyte) {
/* 199 */     if (paramArrayOfbyte.length < 4) return 0; 
/* 200 */     if (DEC[paramArrayOfbyte[0]] < 0)
/* 201 */       throw new IllegalArgumentException("Bad character or insufficient number of characters in hex string"); 
/* 202 */     int i = DEC[paramArrayOfbyte[0]];
/* 203 */     i <<= 4;
/* 204 */     if (DEC[paramArrayOfbyte[1]] < 0)
/* 205 */       throw new IllegalArgumentException("Bad character or insufficient number of characters in hex string"); 
/* 206 */     i += DEC[paramArrayOfbyte[1]];
/* 207 */     i <<= 4;
/* 208 */     if (DEC[paramArrayOfbyte[2]] < 0)
/* 209 */       throw new IllegalArgumentException("Bad character or insufficient number of characters in hex string"); 
/* 210 */     i += DEC[paramArrayOfbyte[2]];
/* 211 */     i <<= 4;
/* 212 */     if (DEC[paramArrayOfbyte[3]] < 0)
/* 213 */       throw new IllegalArgumentException("Bad character or insufficient number of characters in hex string"); 
/* 214 */     i += DEC[paramArrayOfbyte[3]];
/* 215 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char convertDigit(int paramInt) {
/* 226 */     paramInt &= 0xF;
/* 227 */     if (paramInt >= 10) {
/* 228 */       return (char)(paramInt - 10 + 97);
/*     */     }
/* 230 */     return (char)(paramInt + 48);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\Hex.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */