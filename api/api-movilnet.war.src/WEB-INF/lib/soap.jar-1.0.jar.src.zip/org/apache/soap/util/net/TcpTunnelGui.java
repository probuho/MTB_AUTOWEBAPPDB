/*     */ package org.apache.soap.util.net;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.Font;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextArea;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.IOException;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TcpTunnelGui
/*     */   extends Frame
/*     */ {
/*     */   int listenPort;
/*     */   String tunnelHost;
/*     */   int tunnelPort;
/*     */   TextArea listenText;
/*     */   TextArea tunnelText;
/*     */   Label status;
/*     */   Relay inRelay;
/*     */   Relay outRelay;
/*     */   
/*     */   public TcpTunnelGui(int paramInt1, String paramString, int paramInt2) {
/*  84 */     this.listenPort = paramInt1;
/*  85 */     this.tunnelHost = paramString;
/*  86 */     this.tunnelPort = paramInt2;
/*     */     
/*  88 */     addWindowListener(new WindowAdapter(this) {
/*     */           public void windowClosing(WindowEvent param1WindowEvent) {
/*  90 */             System.exit(0);
/*     */           }
/*     */           
/*     */           private final TcpTunnelGui this$0;
/*     */         });
/*  95 */     setTitle("TCP Tunnel/Monitor: Tunneling localhost:" + paramInt1 + " to " + paramString + ":" + paramInt2);
/*     */ 
/*     */ 
/*     */     
/*  99 */     Panel panel1 = new Panel();
/* 100 */     panel1.setLayout(new BorderLayout());
/*     */     Label label1;
/* 102 */     panel1.add("West", label1 = new Label("From localhost:" + paramInt1, 1));
/*     */     Label label2;
/* 104 */     panel1.add("East", label2 = new Label("From " + paramString + ":" + paramInt2, 1));
/*     */ 
/*     */     
/* 107 */     add("North", panel1);
/*     */ 
/*     */     
/* 110 */     panel1 = new Panel();
/* 111 */     panel1.setLayout(new GridLayout(-1, 2));
/* 112 */     panel1.add(this.listenText = new TextArea());
/* 113 */     panel1.add(this.tunnelText = new TextArea());
/* 114 */     add("Center", panel1);
/*     */ 
/*     */     
/* 117 */     Panel panel2 = new Panel();
/* 118 */     panel2.setLayout(new BorderLayout());
/*     */     
/* 120 */     panel1 = new Panel();
/* 121 */     Button button = new Button("Clear");
/* 122 */     button.addActionListener(new ActionListener(this) {
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/* 124 */             this.this$0.listenText.setText("");
/* 125 */             this.this$0.tunnelText.setText("");
/*     */           } private final TcpTunnelGui this$0;
/*     */         });
/* 128 */     panel1.add(button);
/* 129 */     panel2.add("Center", panel1);
/*     */     
/* 131 */     panel2.add("South", this.status = new Label());
/* 132 */     add("South", panel2);
/*     */     
/* 134 */     pack();
/* 135 */     show();
/*     */     
/* 137 */     Font font = label1.getFont();
/* 138 */     label1.setFont(new Font(font.getName(), 1, font.getSize()));
/* 139 */     label2.setFont(new Font(font.getName(), 1, font.getSize()));
/*     */   }
/*     */   
/*     */   public int getListenPort() {
/* 143 */     return this.listenPort;
/*     */   }
/*     */   
/*     */   public String getTunnelHost() {
/* 147 */     return this.tunnelHost;
/*     */   }
/*     */   
/*     */   public int getTunnelPort() {
/* 151 */     return this.tunnelPort;
/*     */   }
/*     */   
/*     */   public TextArea getListenText() {
/* 155 */     return this.listenText;
/*     */   }
/*     */   
/*     */   public TextArea getTunnelText() {
/* 159 */     return this.tunnelText;
/*     */   }
/*     */   
/*     */   public Label getStatus() {
/* 163 */     return this.status;
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws IOException {
/* 167 */     if (paramArrayOfString.length != 3) {
/* 168 */       System.err.println("Usage: java TcpTunnelGui listenport tunnelhost tunnelport");
/*     */       
/* 170 */       System.exit(1);
/*     */     } 
/*     */     
/* 173 */     int i = Integer.parseInt(paramArrayOfString[0]);
/* 174 */     String str = paramArrayOfString[1];
/* 175 */     int j = Integer.parseInt(paramArrayOfString[2]);
/* 176 */     TcpTunnelGui tcpTunnelGui = new TcpTunnelGui(i, str, j);
/*     */ 
/*     */ 
/*     */     
/* 180 */     Thread thread = new Thread(tcpTunnelGui) { private final TcpTunnelGui val$ttg;
/*     */         public void run() {
/* 182 */           ServerSocket serverSocket = null;
/* 183 */           Label label = this.val$ttg.getStatus();
/*     */           try {
/* 185 */             serverSocket = new ServerSocket(this.val$ttg.getListenPort());
/* 186 */           } catch (Exception exception) {
/* 187 */             exception.printStackTrace();
/* 188 */             System.exit(1);
/*     */           }  while (true) {
/*     */             try {
/*     */               while (true) {
/* 192 */                 label.setText("Listening for connections on port " + this.val$ttg.getListenPort() + " ...");
/*     */ 
/*     */                 
/* 195 */                 Socket socket1 = serverSocket.accept();
/*     */ 
/*     */                 
/* 198 */                 Socket socket2 = new Socket(this.val$ttg.getTunnelHost(), this.val$ttg.getTunnelPort());
/*     */ 
/*     */                 
/* 201 */                 label.setText("Tunnelling port " + this.val$ttg.getListenPort() + " to port " + this.val$ttg.getTunnelPort() + " on host " + this.val$ttg.getTunnelHost() + " ...");
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 206 */                 (new Relay(socket1.getInputStream(), socket2.getOutputStream(), this.val$ttg.getListenText())).start();
/*     */                 
/* 208 */                 (new Relay(socket2.getInputStream(), socket1.getOutputStream(), this.val$ttg.getTunnelText())).start();
/*     */               } 
/*     */               
/*     */               break;
/* 212 */             } catch (Exception exception) {
/* 213 */               label.setText("Ouch! [See console for details]: " + exception.getMessage());
/*     */               
/* 215 */               exception.printStackTrace();
/*     */             } 
/*     */           } 
/*     */         } }
/*     */       ;
/* 220 */     thread.start();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\net\TcpTunnelGui.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */