/*     */ package org.apache.soap.transport.http;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.mail.MessagingException;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.encoding.soapenc.Base64;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.transport.SOAPTransport;
/*     */ import org.apache.soap.transport.TransportMessage;
/*     */ import org.apache.soap.util.net.HTTPUtils;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPHTTPConnection
/*     */   implements SOAPTransport
/*     */ {
/*     */   private BufferedReader responseReader;
/*     */   private Hashtable responseHeaders;
/*     */   private SOAPContext responseSOAPContext;
/*     */   private String httpProxyHost;
/*  92 */   private int httpProxyPort = 80;
/*     */   private int timeout;
/*     */   private String userName;
/*     */   private String password;
/*     */   private String proxyUserName;
/*     */   private String proxyPassword;
/*     */   private boolean maintainSession = true;
/*     */   private Cookie[] cookies;
/*     */   private Cookie[] cookies2;
/* 101 */   private int outputBufferSize = 512;
/* 102 */   private Boolean tcpNoDelay = null;
/* 103 */   private StringBuffer requestCopy = null;
/* 104 */   private StringBuffer responseCopy = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxyHost(String paramString) {
/* 112 */     this.httpProxyHost = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxyPort(int paramInt) {
/* 121 */     this.httpProxyPort = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProxyHost() {
/* 130 */     return this.httpProxyHost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getProxyPort() {
/* 139 */     return this.httpProxyPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserName(String paramString) {
/* 146 */     this.userName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String paramString) {
/* 153 */     this.password = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxyUserName(String paramString) {
/* 160 */     this.proxyUserName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxyPassword(String paramString) {
/* 167 */     this.proxyPassword = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestCopy(StringBuffer paramStringBuffer) {
/* 174 */     this.requestCopy = paramStringBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponseCopy(StringBuffer paramStringBuffer) {
/* 181 */     this.responseCopy = paramStringBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer getRequestCopy() {
/* 191 */     return this.requestCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer getResponseCopy() {
/* 201 */     return this.responseCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String encodeAuth(String paramString1, String paramString2) throws SOAPException {
/*     */     try {
/* 209 */       return Base64.encode((paramString1 + ":" + paramString2).getBytes("8859_1"));
/*     */     }
/* 211 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/* 213 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, unsupportedEncodingException.getMessage(), unsupportedEncodingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaintainSession(boolean paramBoolean) {
/* 221 */     this.maintainSession = paramBoolean;
/* 222 */     if (!paramBoolean) {
/* 223 */       this.cookies = null;
/* 224 */       this.cookies2 = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMaintainSession() {
/* 232 */     return this.maintainSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie[] getCookies() {
/* 243 */     return this.cookies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookies(Cookie[] paramArrayOfCookie) {
/* 254 */     this.cookies = paramArrayOfCookie;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie[] getCookies2() {
/* 265 */     return this.cookies2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookies2(Cookie[] paramArrayOfCookie) {
/* 276 */     this.cookies2 = paramArrayOfCookie;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(int paramInt) {
/* 286 */     this.timeout = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeout() {
/* 295 */     return this.timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputBufferSize(int paramInt) {
/* 304 */     this.outputBufferSize = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOutputBufferSize() {
/* 313 */     return this.outputBufferSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getTcpNoDelay() {
/* 322 */     return this.tcpNoDelay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTcpNoDelay(Boolean paramBoolean) {
/* 330 */     this.tcpNoDelay = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(URL paramURL, String paramString, Hashtable paramHashtable, Envelope paramEnvelope, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws SOAPException {
/*     */     try {
/*     */       TransportMessage transportMessage;
/* 351 */       String str = null;
/* 352 */       if (paramEnvelope != null) {
/* 353 */         StringWriter stringWriter = new StringWriter();
/* 354 */         paramEnvelope.marshall(stringWriter, (XMLJavaMappingRegistry)paramSOAPMappingRegistry, paramSOAPContext);
/* 355 */         str = stringWriter.toString();
/*     */       } 
/*     */       
/* 358 */       if (paramHashtable == null) {
/* 359 */         paramHashtable = new Hashtable();
/*     */       }
/* 361 */       if (this.maintainSession) {
/*     */         
/* 363 */         if (this.cookies2 != null) {
/* 364 */           paramHashtable.put("Cookie2", Cookie.buildCookieValue(paramURL, this.cookies2));
/*     */         }
/* 366 */         if (this.cookies != null) {
/* 367 */           paramHashtable.put("Cookie", Cookie.buildCookieValue(paramURL, this.cookies));
/*     */         }
/*     */       } 
/*     */       
/* 371 */       paramHashtable.put("SOAPAction", (paramString != null) ? ('"' + paramString + '"') : "");
/*     */       
/* 373 */       if (this.userName != null)
/*     */       {
/* 375 */         paramHashtable.put("Authorization", "Basic " + encodeAuth(this.userName, this.password));
/*     */       }
/*     */ 
/*     */       
/* 379 */       if (this.proxyUserName != null)
/*     */       {
/* 381 */         paramHashtable.put("Proxy-Authorization", "Basic " + encodeAuth(this.proxyUserName, this.proxyPassword));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 388 */         TransportMessage transportMessage1 = new TransportMessage(str, paramSOAPContext, paramHashtable);
/* 389 */         transportMessage1.save();
/*     */         
/* 391 */         transportMessage = HTTPUtils.post(paramURL, transportMessage1, this.timeout, this.httpProxyHost, this.httpProxyPort, this.outputBufferSize, this.tcpNoDelay, this.requestCopy, this.responseCopy);
/*     */ 
/*     */       
/*     */       }
/* 395 */       catch (MessagingException messagingException) {
/* 396 */         throw new IOException("Failed to encode mime multipart: " + messagingException);
/* 397 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 398 */         throw new IOException("Failed to encode mime multipart: " + unsupportedEncodingException);
/*     */       } 
/*     */       
/* 401 */       Reader reader = transportMessage.getEnvelopeReader();
/* 402 */       if (reader != null) {
/* 403 */         this.responseReader = new BufferedReader(reader);
/*     */       } else {
/* 405 */         this.responseReader = null;
/* 406 */       }  this.responseSOAPContext = transportMessage.getSOAPContext();
/* 407 */       this.responseHeaders = transportMessage.getHeaders();
/* 408 */       if (this.maintainSession) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 415 */         String str1 = getHeaderValue(this.responseHeaders, "Set-Cookie2");
/*     */         
/* 417 */         if (str1 != null) {
/* 418 */           Cookie[] arrayOfCookie = Cookie.parseCookies(paramURL, str1);
/* 419 */           if (this.cookies2 != null) {
/* 420 */             this.cookies2 = Cookie.updateCookies(this.cookies2, arrayOfCookie);
/*     */           } else {
/* 422 */             this.cookies2 = arrayOfCookie;
/*     */           } 
/*     */         } 
/* 425 */         str1 = getHeaderValue(this.responseHeaders, "Set-Cookie");
/*     */         
/* 427 */         if (str1 != null) {
/* 428 */           Cookie[] arrayOfCookie = Cookie.parseCookies(paramURL, str1);
/* 429 */           if (this.cookies != null)
/* 430 */           { this.cookies = Cookie.updateCookies(this.cookies, arrayOfCookie); }
/*     */           else
/* 432 */           { this.cookies = arrayOfCookie; } 
/*     */         } 
/*     */       } 
/* 435 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 436 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, illegalArgumentException.getMessage(), illegalArgumentException);
/* 437 */     } catch (MessagingException messagingException) {
/* 438 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, messagingException.getMessage(), messagingException);
/* 439 */     } catch (IOException iOException) {
/* 440 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, iOException.getMessage(), iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedReader receive() {
/* 452 */     return this.responseReader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getHeaders() {
/* 461 */     return this.responseHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPContext getResponseSOAPContext() {
/* 470 */     return this.responseSOAPContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getHeaderValue(Hashtable paramHashtable, String paramString) {
/* 482 */     for (Enumeration enumeration = paramHashtable.keys(); enumeration.hasMoreElements(); ) {
/* 483 */       String str = enumeration.nextElement();
/*     */       
/* 485 */       if (str.equalsIgnoreCase(paramString)) {
/* 486 */         return (String)paramHashtable.get(str);
/*     */       }
/*     */     } 
/*     */     
/* 490 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\transport\http\SOAPHTTPConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */