/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */ {
/*  28 */   private static final char[] S_BASE64CHAR = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final char S_BASE64PAD = '=';
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   private static final byte[] S_DECODETABLE = new byte[128]; static {
/*     */     byte b;
/*  40 */     for (b = 0; b < S_DECODETABLE.length; b++)
/*  41 */       S_DECODETABLE[b] = Byte.MAX_VALUE; 
/*  42 */     for (b = 0; b < S_BASE64CHAR.length; b++)
/*  43 */       S_DECODETABLE[S_BASE64CHAR[b]] = (byte)b; 
/*     */   }
/*     */   
/*     */   private static int decode0(char[] paramArrayOfchar, byte[] paramArrayOfbyte, int paramInt) {
/*  47 */     byte b = 3;
/*  48 */     if (paramArrayOfchar[3] == '=') b = 2; 
/*  49 */     if (paramArrayOfchar[2] == '=') b = 1; 
/*  50 */     byte b1 = S_DECODETABLE[paramArrayOfchar[0]];
/*  51 */     byte b2 = S_DECODETABLE[paramArrayOfchar[1]];
/*  52 */     byte b3 = S_DECODETABLE[paramArrayOfchar[2]];
/*  53 */     byte b4 = S_DECODETABLE[paramArrayOfchar[3]];
/*  54 */     switch (b) {
/*     */       case 1:
/*  56 */         paramArrayOfbyte[paramInt] = (byte)(b1 << 2 & 0xFC | b2 >> 4 & 0x3);
/*  57 */         return 1;
/*     */       case 2:
/*  59 */         paramArrayOfbyte[paramInt++] = (byte)(b1 << 2 & 0xFC | b2 >> 4 & 0x3);
/*  60 */         paramArrayOfbyte[paramInt] = (byte)(b2 << 4 & 0xF0 | b3 >> 2 & 0xF);
/*  61 */         return 2;
/*     */       case 3:
/*  63 */         paramArrayOfbyte[paramInt++] = (byte)(b1 << 2 & 0xFC | b2 >> 4 & 0x3);
/*  64 */         paramArrayOfbyte[paramInt++] = (byte)(b2 << 4 & 0xF0 | b3 >> 2 & 0xF);
/*  65 */         paramArrayOfbyte[paramInt] = (byte)(b3 << 6 & 0xC0 | b4 & 0x3F);
/*  66 */         return 3;
/*     */     } 
/*  68 */     throw new RuntimeException("Internal Errror");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/*  80 */     char[] arrayOfChar = new char[4];
/*  81 */     byte b = 0;
/*  82 */     byte[] arrayOfByte1 = new byte[paramInt2 / 4 * 3 + 3];
/*  83 */     int i = 0;
/*  84 */     for (int j = paramInt1; j < paramInt1 + paramInt2; j++) {
/*  85 */       char c = paramArrayOfchar[j];
/*  86 */       if (c == '=' || (c < S_DECODETABLE.length && S_DECODETABLE[c] != Byte.MAX_VALUE)) {
/*     */         
/*  88 */         arrayOfChar[b++] = c;
/*  89 */         if (b == arrayOfChar.length) {
/*  90 */           b = 0;
/*  91 */           i += decode0(arrayOfChar, arrayOfByte1, i);
/*     */         } 
/*     */       } 
/*     */     } 
/*  95 */     if (i == arrayOfByte1.length)
/*  96 */       return arrayOfByte1; 
/*  97 */     byte[] arrayOfByte2 = new byte[i];
/*  98 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
/*  99 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(String paramString) {
/* 108 */     char[] arrayOfChar = new char[4];
/* 109 */     byte b1 = 0;
/* 110 */     byte[] arrayOfByte1 = new byte[paramString.length() / 4 * 3 + 3];
/* 111 */     int i = 0;
/* 112 */     for (byte b2 = 0; b2 < paramString.length(); b2++) {
/* 113 */       char c = paramString.charAt(b2);
/* 114 */       if (c == '=' || (c < S_DECODETABLE.length && S_DECODETABLE[c] != Byte.MAX_VALUE)) {
/*     */         
/* 116 */         arrayOfChar[b1++] = c;
/* 117 */         if (b1 == arrayOfChar.length) {
/* 118 */           b1 = 0;
/* 119 */           i += decode0(arrayOfChar, arrayOfByte1, i);
/*     */         } 
/*     */       } 
/*     */     } 
/* 123 */     if (i == arrayOfByte1.length)
/* 124 */       return arrayOfByte1; 
/* 125 */     byte[] arrayOfByte2 = new byte[i];
/* 126 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
/* 127 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void decode(char[] paramArrayOfchar, int paramInt1, int paramInt2, OutputStream paramOutputStream) throws IOException {
/* 139 */     char[] arrayOfChar = new char[4];
/* 140 */     byte b = 0;
/* 141 */     byte[] arrayOfByte = new byte[3];
/* 142 */     for (int i = paramInt1; i < paramInt1 + paramInt2; i++) {
/* 143 */       char c = paramArrayOfchar[i];
/* 144 */       if (c == '=' || (c < S_DECODETABLE.length && S_DECODETABLE[c] != Byte.MAX_VALUE)) {
/*     */         
/* 146 */         arrayOfChar[b++] = c;
/* 147 */         if (b == arrayOfChar.length) {
/* 148 */           b = 0;
/* 149 */           int j = decode0(arrayOfChar, arrayOfByte, 0);
/* 150 */           paramOutputStream.write(arrayOfByte, 0, j);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void decode(String paramString, OutputStream paramOutputStream) throws IOException {
/* 163 */     char[] arrayOfChar = new char[4];
/* 164 */     byte b1 = 0;
/* 165 */     byte[] arrayOfByte = new byte[3];
/* 166 */     for (byte b2 = 0; b2 < paramString.length(); b2++) {
/* 167 */       char c = paramString.charAt(b2);
/* 168 */       if (c == '=' || (c < S_DECODETABLE.length && S_DECODETABLE[c] != Byte.MAX_VALUE)) {
/*     */         
/* 170 */         arrayOfChar[b1++] = c;
/* 171 */         if (b1 == arrayOfChar.length) {
/* 172 */           b1 = 0;
/* 173 */           int i = decode0(arrayOfChar, arrayOfByte, 0);
/* 174 */           paramOutputStream.write(arrayOfByte, 0, i);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(byte[] paramArrayOfbyte) {
/* 186 */     return encode(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 197 */     if (paramInt2 <= 0) return ""; 
/* 198 */     char[] arrayOfChar = new char[paramInt2 / 3 * 4 + 4];
/* 199 */     int i = paramInt1;
/* 200 */     byte b = 0;
/* 201 */     int j = paramInt2;
/* 202 */     while (j >= 3) {
/* 203 */       int k = ((paramArrayOfbyte[i] & 0xFF) << 16) + ((paramArrayOfbyte[i + 1] & 0xFF) << 8) + (paramArrayOfbyte[i + 2] & 0xFF);
/*     */ 
/*     */       
/* 206 */       arrayOfChar[b++] = S_BASE64CHAR[k >> 18];
/* 207 */       arrayOfChar[b++] = S_BASE64CHAR[k >> 12 & 0x3F];
/* 208 */       arrayOfChar[b++] = S_BASE64CHAR[k >> 6 & 0x3F];
/* 209 */       arrayOfChar[b++] = S_BASE64CHAR[k & 0x3F];
/* 210 */       i += 3;
/* 211 */       j -= 3;
/*     */     } 
/* 213 */     if (j == 1) {
/* 214 */       int k = paramArrayOfbyte[i] & 0xFF;
/* 215 */       arrayOfChar[b++] = S_BASE64CHAR[k >> 2];
/* 216 */       arrayOfChar[b++] = S_BASE64CHAR[k << 4 & 0x3F];
/* 217 */       arrayOfChar[b++] = '=';
/* 218 */       arrayOfChar[b++] = '=';
/* 219 */     } else if (j == 2) {
/* 220 */       int k = ((paramArrayOfbyte[i] & 0xFF) << 8) + (paramArrayOfbyte[i + 1] & 0xFF);
/* 221 */       arrayOfChar[b++] = S_BASE64CHAR[k >> 10];
/* 222 */       arrayOfChar[b++] = S_BASE64CHAR[k >> 4 & 0x3F];
/* 223 */       arrayOfChar[b++] = S_BASE64CHAR[k << 2 & 0x3F];
/* 224 */       arrayOfChar[b++] = '=';
/*     */     } 
/* 226 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void encode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, OutputStream paramOutputStream) throws IOException {
/* 238 */     if (paramInt2 <= 0)
/* 239 */       return;  byte[] arrayOfByte = new byte[4];
/* 240 */     int i = paramInt1;
/* 241 */     int j = paramInt2;
/* 242 */     while (j >= 3) {
/* 243 */       int k = ((paramArrayOfbyte[i] & 0xFF) << 16) + ((paramArrayOfbyte[i + 1] & 0xFF) << 8) + (paramArrayOfbyte[i + 2] & 0xFF);
/*     */ 
/*     */       
/* 246 */       arrayOfByte[0] = (byte)S_BASE64CHAR[k >> 18];
/* 247 */       arrayOfByte[1] = (byte)S_BASE64CHAR[k >> 12 & 0x3F];
/* 248 */       arrayOfByte[2] = (byte)S_BASE64CHAR[k >> 6 & 0x3F];
/* 249 */       arrayOfByte[3] = (byte)S_BASE64CHAR[k & 0x3F];
/* 250 */       paramOutputStream.write(arrayOfByte, 0, 4);
/* 251 */       i += 3;
/* 252 */       j -= 3;
/*     */     } 
/* 254 */     if (j == 1) {
/* 255 */       int k = paramArrayOfbyte[i] & 0xFF;
/* 256 */       arrayOfByte[0] = (byte)S_BASE64CHAR[k >> 2];
/* 257 */       arrayOfByte[1] = (byte)S_BASE64CHAR[k << 4 & 0x3F];
/* 258 */       arrayOfByte[2] = 61;
/* 259 */       arrayOfByte[3] = 61;
/* 260 */       paramOutputStream.write(arrayOfByte, 0, 4);
/* 261 */     } else if (j == 2) {
/* 262 */       int k = ((paramArrayOfbyte[i] & 0xFF) << 8) + (paramArrayOfbyte[i + 1] & 0xFF);
/* 263 */       arrayOfByte[0] = (byte)S_BASE64CHAR[k >> 10];
/* 264 */       arrayOfByte[1] = (byte)S_BASE64CHAR[k >> 4 & 0x3F];
/* 265 */       arrayOfByte[2] = (byte)S_BASE64CHAR[k << 2 & 0x3F];
/* 266 */       arrayOfByte[3] = 61;
/* 267 */       paramOutputStream.write(arrayOfByte, 0, 4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void encode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, Writer paramWriter) throws IOException {
/* 280 */     if (paramInt2 <= 0)
/* 281 */       return;  char[] arrayOfChar = new char[4];
/* 282 */     int i = paramInt1;
/* 283 */     int j = paramInt2;
/* 284 */     byte b = 0;
/* 285 */     while (j >= 3) {
/* 286 */       int k = ((paramArrayOfbyte[i] & 0xFF) << 16) + ((paramArrayOfbyte[i + 1] & 0xFF) << 8) + (paramArrayOfbyte[i + 2] & 0xFF);
/*     */ 
/*     */       
/* 289 */       arrayOfChar[0] = S_BASE64CHAR[k >> 18];
/* 290 */       arrayOfChar[1] = S_BASE64CHAR[k >> 12 & 0x3F];
/* 291 */       arrayOfChar[2] = S_BASE64CHAR[k >> 6 & 0x3F];
/* 292 */       arrayOfChar[3] = S_BASE64CHAR[k & 0x3F];
/* 293 */       paramWriter.write(arrayOfChar, 0, 4);
/* 294 */       i += 3;
/* 295 */       j -= 3;
/* 296 */       b += true;
/* 297 */       if (b % 76 == 0)
/* 298 */         paramWriter.write("\n"); 
/*     */     } 
/* 300 */     if (j == 1) {
/* 301 */       int k = paramArrayOfbyte[i] & 0xFF;
/* 302 */       arrayOfChar[0] = S_BASE64CHAR[k >> 2];
/* 303 */       arrayOfChar[1] = S_BASE64CHAR[k << 4 & 0x3F];
/* 304 */       arrayOfChar[2] = '=';
/* 305 */       arrayOfChar[3] = '=';
/* 306 */       paramWriter.write(arrayOfChar, 0, 4);
/* 307 */     } else if (j == 2) {
/* 308 */       int k = ((paramArrayOfbyte[i] & 0xFF) << 8) + (paramArrayOfbyte[i + 1] & 0xFF);
/* 309 */       arrayOfChar[0] = S_BASE64CHAR[k >> 10];
/* 310 */       arrayOfChar[1] = S_BASE64CHAR[k >> 4 & 0x3F];
/* 311 */       arrayOfChar[2] = S_BASE64CHAR[k << 2 & 0x3F];
/* 312 */       arrayOfChar[3] = '=';
/* 313 */       paramWriter.write(arrayOfChar, 0, 4);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\Base64.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */