/*    */ package org.apache.soap.server;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import org.apache.soap.Fault;
/*    */ import org.apache.soap.SOAPException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPFaultEvent
/*    */   extends EventObject
/*    */ {
/*    */   private Fault fault;
/*    */   private SOAPException soapException;
/*    */   
/*    */   public SOAPFaultEvent(Fault paramFault, SOAPException paramSOAPException) {
/* 73 */     super(paramFault);
/* 74 */     this.fault = paramFault;
/* 75 */     this.soapException = paramSOAPException;
/*    */   }
/*    */   public Fault getFault() {
/* 78 */     return this.fault;
/*    */   } public SOAPException getSOAPException() {
/* 80 */     return this.soapException;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\SOAPFaultEvent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */