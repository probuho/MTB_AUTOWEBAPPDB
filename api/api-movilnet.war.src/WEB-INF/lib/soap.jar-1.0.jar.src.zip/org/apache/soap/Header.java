/*     */ package org.apache.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Header
/*     */ {
/*  77 */   private Vector headerEntries = null;
/*  78 */   private AttributeHandler attrHandler = new AttributeHandler();
/*     */ 
/*     */   
/*     */   public void setAttribute(QName paramQName, String paramString) {
/*  82 */     this.attrHandler.setAttribute(paramQName, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(QName paramQName) {
/*  87 */     return this.attrHandler.getAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAttribute(QName paramQName) {
/*  92 */     this.attrHandler.removeAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void declareNamespace(String paramString1, String paramString2) {
/*  97 */     this.attrHandler.declareNamespace(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHeaderEntries(Vector paramVector) {
/* 102 */     this.headerEntries = paramVector;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector getHeaderEntries() {
/* 107 */     return this.headerEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 114 */     this.attrHandler.populateNSStack(paramNSStack);
/*     */ 
/*     */     
/* 117 */     String str = this.attrHandler.getUniquePrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", "SOAP-ENV", paramNSStack);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     if (this.headerEntries != null) {
/*     */       
/* 124 */       paramWriter.write('<' + str + ':' + "Header");
/*     */ 
/*     */       
/* 127 */       this.attrHandler.marshall(paramWriter, paramSOAPContext);
/*     */       
/* 129 */       paramWriter.write('>' + StringUtils.lineSeparator);
/*     */ 
/*     */       
/* 132 */       for (Enumeration enumeration = this.headerEntries.elements(); enumeration.hasMoreElements(); ) {
/*     */         
/* 134 */         Element element = enumeration.nextElement();
/*     */         
/* 136 */         Utils.marshallNode(element, paramWriter);
/*     */         
/* 138 */         paramWriter.write(StringUtils.lineSeparator);
/*     */       } 
/*     */       
/* 141 */       paramWriter.write("</" + str + ':' + "Header" + '>' + StringUtils.lineSeparator);
/*     */     } 
/*     */ 
/*     */     
/* 145 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Header unmarshall(Node paramNode, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 151 */     Element element1 = (Element)paramNode;
/* 152 */     Header header = new Header();
/* 153 */     Vector vector = new Vector();
/*     */ 
/*     */     
/* 156 */     header.attrHandler = AttributeHandler.unmarshall(element1, paramSOAPContext);
/*     */     
/* 158 */     Element element2 = DOMUtils.getFirstChildElement(element1);
/* 159 */     for (; element2 != null; 
/* 160 */       element2 = DOMUtils.getNextSiblingElement(element2))
/*     */     {
/* 162 */       vector.addElement(element2);
/*     */     }
/*     */     
/* 165 */     header.setHeaderEntries(vector);
/*     */     
/* 167 */     return header;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     StringWriter stringWriter = new StringWriter();
/* 173 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 175 */     printWriter.print("[Attributes=" + this.attrHandler + "] " + "[HeaderEntries={");
/*     */ 
/*     */     
/* 178 */     if (this.headerEntries != null)
/*     */     {
/* 180 */       for (byte b = 0; b < this.headerEntries.size(); b++) {
/*     */         
/* 182 */         if (b > 0)
/*     */         {
/* 184 */           printWriter.print(", ");
/*     */         }
/*     */         
/* 187 */         printWriter.print("[" + this.headerEntries.elementAt(b) + "]");
/*     */       } 
/*     */     }
/*     */     
/* 191 */     printWriter.print("}]");
/*     */     
/* 193 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\Header.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */