/*    */ package org.apache.soap.util;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IOUtils
/*    */ {
/*    */   static boolean debug = false;
/*    */   
/*    */   public static String getStringFromReader(Reader paramReader) throws IOException {
/* 75 */     BufferedReader bufferedReader = new BufferedReader(paramReader);
/* 76 */     StringWriter stringWriter = new StringWriter();
/* 77 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*    */     
/*    */     String str;
/* 80 */     while ((str = bufferedReader.readLine()) != null) {
/* 81 */       printWriter.println(str);
/*    */     }
/*    */     
/* 84 */     printWriter.flush();
/*    */     
/* 86 */     return stringWriter.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\IOUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */