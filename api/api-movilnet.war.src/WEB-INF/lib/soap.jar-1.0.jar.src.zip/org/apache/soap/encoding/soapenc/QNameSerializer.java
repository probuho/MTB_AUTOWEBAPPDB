/*    */ package org.apache.soap.encoding.soapenc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.apache.soap.rpc.SOAPContext;
/*    */ import org.apache.soap.util.Bean;
/*    */ import org.apache.soap.util.xml.DOMUtils;
/*    */ import org.apache.soap.util.xml.Deserializer;
/*    */ import org.apache.soap.util.xml.NSStack;
/*    */ import org.apache.soap.util.xml.QName;
/*    */ import org.apache.soap.util.xml.Serializer;
/*    */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class QNameSerializer
/*    */   implements Serializer, Deserializer
/*    */ {
/*    */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 20 */     paramWriter.write('<' + paramObject2.toString());
/*    */     
/* 22 */     QName qName1 = (QName)paramObject1;
/*    */ 
/*    */     
/* 25 */     String str1 = paramNSStack.getPrefixFromURI(qName1.getNamespaceURI(), paramWriter);
/*    */     
/* 27 */     QName qName2 = paramXMLJavaMappingRegistry.queryElementType(paramClass, "http://schemas.xmlsoap.org/soap/encoding/");
/*    */ 
/*    */     
/* 30 */     String str2 = paramNSStack.getPrefixFromURI("http://www.w3.org/2001/XMLSchema-instance", paramWriter);
/*    */     
/* 32 */     String str3 = paramNSStack.getPrefixFromURI(qName2.getNamespaceURI(), paramWriter);
/*    */ 
/*    */     
/* 35 */     paramWriter.write(' ' + str2 + ':' + "type" + "=\"" + str3 + ':' + qName2.getLocalPart() + '"');
/*    */ 
/*    */ 
/*    */     
/* 39 */     paramWriter.write('>' + str1 + ':' + qName1.getLocalPart());
/* 40 */     paramWriter.write("</" + paramObject2.toString() + '>');
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 48 */     Element element = (Element)paramNode;
/* 49 */     String str1 = DOMUtils.getChildCharacterData(element);
/*    */     
/* 51 */     int i = str1.indexOf(":");
/* 52 */     if (i <= 0) {
/* 53 */       throw new IllegalArgumentException("No NamespaceURI while deserializing QName");
/*    */     }
/* 55 */     String str2 = str1.substring(0, i);
/* 56 */     String str3 = DOMUtils.getNamespaceURIFromPrefix(paramNode, str2);
/*    */     
/* 58 */     QName qName = new QName(str3, str1.substring(i + 1));
/*    */     
/* 60 */     return new Bean(QName.class, qName);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\QNameSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */