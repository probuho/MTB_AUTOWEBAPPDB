/*     */ package org.apache.soap.util.xml;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMWriter
/*     */ {
/*     */   public static String nodeToString(Node paramNode) {
/*  82 */     StringWriter stringWriter = new StringWriter();
/*     */     
/*  84 */     serializeAsXML(paramNode, stringWriter);
/*     */     
/*  86 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void serializeAsXML(Node paramNode, Writer paramWriter) {
/*  94 */     print(paramNode, new PrintWriter(paramWriter)); } private static void print(Node paramNode, PrintWriter paramPrintWriter) { NodeList nodeList1;
/*     */     NamedNodeMap namedNodeMap;
/*     */     String str;
/*     */     byte b1, b2;
/*     */     NodeList nodeList2;
/*  99 */     if (paramNode == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 104 */     boolean bool = false;
/* 105 */     short s = paramNode.getNodeType();
/*     */     
/* 107 */     switch (s) {
/*     */ 
/*     */       
/*     */       case 9:
/* 111 */         paramPrintWriter.println("<?xml version=\"1.0\"?>");
/*     */         
/* 113 */         nodeList1 = paramNode.getChildNodes();
/*     */         
/* 115 */         if (nodeList1 != null) {
/*     */           
/* 117 */           int i = nodeList1.getLength();
/*     */           
/* 119 */           for (byte b = 0; b < i; b++)
/*     */           {
/* 121 */             print(nodeList1.item(b), paramPrintWriter);
/*     */           }
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 129 */         paramPrintWriter.print('<' + paramNode.getNodeName());
/*     */         
/* 131 */         namedNodeMap = paramNode.getAttributes();
/* 132 */         b1 = (namedNodeMap != null) ? namedNodeMap.getLength() : 0;
/*     */         
/* 134 */         for (b2 = 0; b2 < b1; b2++) {
/*     */           
/* 136 */           Attr attr = (Attr)namedNodeMap.item(b2);
/*     */           
/* 138 */           paramPrintWriter.print(' ' + attr.getNodeName() + "=\"" + normalize(attr.getValue()) + '"');
/*     */         } 
/*     */ 
/*     */         
/* 142 */         nodeList2 = paramNode.getChildNodes();
/*     */         
/* 144 */         if (nodeList2 != null) {
/*     */           
/* 146 */           int i = nodeList2.getLength();
/*     */           
/* 148 */           bool = (i > 0) ? true : false;
/*     */           
/* 150 */           if (bool)
/*     */           {
/* 152 */             paramPrintWriter.print('>');
/*     */           }
/*     */           
/* 155 */           for (byte b = 0; b < i; b++)
/*     */           {
/* 157 */             print(nodeList2.item(b), paramPrintWriter);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 162 */           bool = false;
/*     */         } 
/*     */         
/* 165 */         if (!bool)
/*     */         {
/* 167 */           paramPrintWriter.print("/>");
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 174 */         paramPrintWriter.print('&');
/* 175 */         paramPrintWriter.print(paramNode.getNodeName());
/* 176 */         paramPrintWriter.print(';');
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 182 */         paramPrintWriter.print("<![CDATA[");
/* 183 */         paramPrintWriter.print(paramNode.getNodeValue());
/* 184 */         paramPrintWriter.print("]]>");
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 190 */         paramPrintWriter.print(normalize(paramNode.getNodeValue()));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 196 */         paramPrintWriter.print("<!--");
/* 197 */         paramPrintWriter.print(paramNode.getNodeValue());
/* 198 */         paramPrintWriter.print("-->");
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 204 */         paramPrintWriter.print("<?");
/* 205 */         paramPrintWriter.print(paramNode.getNodeName());
/*     */         
/* 207 */         str = paramNode.getNodeValue();
/*     */         
/* 209 */         if (str != null && str.length() > 0) {
/*     */           
/* 211 */           paramPrintWriter.print(' ');
/* 212 */           paramPrintWriter.print(str);
/*     */         } 
/*     */         
/* 215 */         paramPrintWriter.println("?>");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 220 */     if (s == 1 && bool == true) {
/*     */       
/* 222 */       paramPrintWriter.print("</");
/* 223 */       paramPrintWriter.print(paramNode.getNodeName());
/* 224 */       paramPrintWriter.print('>');
/* 225 */       bool = false;
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String normalize(String paramString) {
/* 231 */     StringBuffer stringBuffer = new StringBuffer();
/* 232 */     byte b1 = (paramString != null) ? paramString.length() : 0;
/*     */     
/* 234 */     for (byte b2 = 0; b2 < b1; b2++) {
/*     */       
/* 236 */       char c = paramString.charAt(b2);
/*     */       
/* 238 */       switch (c) {
/*     */ 
/*     */         
/*     */         case '<':
/* 242 */           stringBuffer.append("&lt;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '>':
/* 247 */           stringBuffer.append("&gt;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '&':
/* 252 */           stringBuffer.append("&amp;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '"':
/* 257 */           stringBuffer.append("&quot;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '\n':
/* 262 */           if (b2 > 0) {
/*     */             
/* 264 */             char c1 = stringBuffer.charAt(stringBuffer.length() - 1);
/*     */             
/* 266 */             if (c1 != '\r') {
/*     */               
/* 268 */               stringBuffer.append(StringUtils.lineSeparator);
/*     */               
/*     */               break;
/*     */             } 
/* 272 */             stringBuffer.append('\n');
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 277 */           stringBuffer.append(StringUtils.lineSeparator);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 283 */           stringBuffer.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 288 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\DOMWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */