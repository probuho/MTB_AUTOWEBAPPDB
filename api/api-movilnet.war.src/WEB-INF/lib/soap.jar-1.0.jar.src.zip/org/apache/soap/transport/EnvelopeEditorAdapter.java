/*     */ package org.apache.soap.transport;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnvelopeEditorAdapter
/*     */   implements EnvelopeEditor
/*     */ {
/*     */   private static final int BUF_SIZE = 4096;
/*     */   
/*     */   public void editIncoming(Reader paramReader, Writer paramWriter) throws SOAPException {
/*  76 */     passThrough(paramReader, paramWriter);
/*     */   }
/*     */   
/*     */   public void editOutgoing(Reader paramReader, Writer paramWriter) throws SOAPException {
/*  80 */     passThrough(paramReader, paramWriter);
/*     */   }
/*     */   
/*     */   protected void passThrough(Reader paramReader, Writer paramWriter) throws SOAPException {
/*     */     try {
/*  85 */       char[] arrayOfChar = new char[4096];
/*     */ 
/*     */       
/*     */       while (true) {
/*  89 */         int i = 0; while (true)
/*     */         { int j;
/*  91 */           if ((j = paramReader.read(arrayOfChar, i, arrayOfChar.length - i)) == -1) {
/*  92 */             paramWriter.write(arrayOfChar, 0, i);
/*     */             break;
/*     */           } 
/*  95 */           if ((i += j) >= arrayOfChar.length)
/*  96 */             paramWriter.write(arrayOfChar);  }  break;
/*     */       } 
/*  98 */     } catch (IOException iOException) {
/*  99 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, iOException.getMessage(), iOException);
/*     */     } finally {
/*     */       
/*     */       try {
/* 103 */         paramWriter.flush();
/* 104 */       } catch (IOException iOException) {
/* 105 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, iOException.getMessage(), iOException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\transport\EnvelopeEditorAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */