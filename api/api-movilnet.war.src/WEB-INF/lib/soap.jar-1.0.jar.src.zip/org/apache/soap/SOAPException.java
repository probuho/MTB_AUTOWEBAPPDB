/*     */ package org.apache.soap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPException
/*     */   extends Exception
/*     */ {
/*     */   private String faultCode;
/*     */   private Throwable targetException;
/*     */   
/*     */   public SOAPException(String paramString1, String paramString2) {
/*  71 */     super(Utils.cleanString(paramString2));
/*  72 */     this.faultCode = Utils.cleanString(paramString1);
/*     */   }
/*     */ 
/*     */   
/*     */   public SOAPException(String paramString1, String paramString2, Throwable paramThrowable) {
/*  77 */     this(paramString1, paramString2);
/*  78 */     this.targetException = paramThrowable;
/*     */   }
/*     */   
/*     */   public void setFaultCode(String paramString) {
/*  82 */     this.faultCode = Utils.cleanString(paramString);
/*     */   }
/*     */   
/*     */   public String getFaultCode() {
/*  86 */     return this.faultCode;
/*     */   }
/*     */   
/*     */   public void setTargetException(Throwable paramThrowable) {
/*  90 */     this.targetException = paramThrowable;
/*     */   }
/*     */   
/*     */   public Throwable getTargetException() {
/*  94 */     return this.targetException;
/*     */   }
/*     */   
/*     */   public Throwable getRootException() {
/*  98 */     return (this.targetException != null) ? this.targetException : this;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 102 */     String str1 = super.getMessage();
/* 103 */     String str2 = (this.targetException != null) ? this.targetException.getMessage() : null;
/*     */ 
/*     */     
/* 106 */     String str3 = (this.targetException != null) ? (" [" + this.targetException.getClass().getName() + "]") : "";
/*     */     
/* 108 */     String str4 = ((str1 == null || str1.equals("")) && str2 != null && !str2.equals("")) ? str2 : (str1 + str3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     if (str4 == null || str4.equals("")) {
/* 114 */       str4 = (this.targetException != null) ? this.targetException.toString() : toString();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 119 */     return str4;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 123 */     return "[SOAPException: faultCode=" + this.faultCode + "; msg=" + super.getMessage() + ((this.targetException != null) ? ("; targetException=" + this.targetException) : "") + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\SOAPException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */