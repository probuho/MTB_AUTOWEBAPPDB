/*     */ package org.apache.soap.util.xml;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import org.apache.soap.util.ObjectRegistry;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOM2Writer
/*     */ {
/*  79 */   private static String NS_URI_XMLNS = "http://www.w3.org/2000/xmlns/";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nodeToString(Node paramNode) {
/*  86 */     StringWriter stringWriter = new StringWriter();
/*     */     
/*  88 */     serializeAsXML(paramNode, stringWriter);
/*     */     
/*  90 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void serializeAsXML(Node paramNode, Writer paramWriter) {
/*  98 */     print(paramNode, null, new PrintWriter(paramWriter)); } private static void print(Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter) {
/*     */     NodeList nodeList1;
/*     */     String str1, str2;
/*     */     NamedNodeMap namedNodeMap;
/*     */     byte b1, b2;
/*     */     NodeList nodeList2;
/* 104 */     if (paramNode == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 109 */     boolean bool = false;
/* 110 */     short s = paramNode.getNodeType();
/*     */     
/* 112 */     switch (s) {
/*     */ 
/*     */       
/*     */       case 9:
/* 116 */         paramPrintWriter.println("<?xml version=\"1.0\"?>");
/*     */         
/* 118 */         nodeList1 = paramNode.getChildNodes();
/*     */         
/* 120 */         if (nodeList1 != null) {
/*     */           
/* 122 */           int i = nodeList1.getLength();
/*     */           
/* 124 */           for (byte b = 0; b < i; b++)
/*     */           {
/* 126 */             print(nodeList1.item(b), paramObjectRegistry, paramPrintWriter);
/*     */           }
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 134 */         paramObjectRegistry = new ObjectRegistry(paramObjectRegistry);
/*     */         
/* 136 */         paramPrintWriter.print('<' + paramNode.getNodeName());
/*     */         
/* 138 */         str1 = paramNode.getPrefix();
/* 139 */         str2 = paramNode.getNamespaceURI();
/*     */         
/* 141 */         if (str1 != null && str2 != null && str1.length() > 0 && str2.length() > 0) {
/*     */ 
/*     */           
/* 144 */           boolean bool1 = false;
/*     */ 
/*     */           
/*     */           try {
/* 148 */             String str = (String)paramObjectRegistry.lookup(str1);
/*     */             
/* 150 */             if (str2.equals(str))
/*     */             {
/* 152 */               bool1 = true;
/*     */             }
/*     */           }
/* 155 */           catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */           
/* 159 */           if (!bool1)
/*     */           {
/* 161 */             printNamespaceDecl(paramNode, paramObjectRegistry, paramPrintWriter);
/*     */           }
/*     */         } 
/*     */         
/* 165 */         namedNodeMap = paramNode.getAttributes();
/* 166 */         b1 = (namedNodeMap != null) ? namedNodeMap.getLength() : 0;
/*     */         
/* 168 */         for (b2 = 0; b2 < b1; b2++) {
/*     */           
/* 170 */           Attr attr = (Attr)namedNodeMap.item(b2);
/*     */           
/* 172 */           paramPrintWriter.print(' ' + attr.getNodeName() + "=\"" + normalize(attr.getValue()) + '"');
/*     */ 
/*     */           
/* 175 */           String str3 = attr.getPrefix();
/* 176 */           String str4 = attr.getNamespaceURI();
/*     */           
/* 178 */           if (str3 != null && str4 != null && str3.length() > 0 && str4.length() > 0) {
/*     */ 
/*     */             
/* 181 */             boolean bool1 = false;
/*     */ 
/*     */             
/*     */             try {
/* 185 */               String str = (String)paramObjectRegistry.lookup(str3);
/*     */               
/* 187 */               if (str4.equals(str))
/*     */               {
/* 189 */                 bool1 = true;
/*     */               }
/*     */             }
/* 192 */             catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */             
/* 196 */             if (!bool1)
/*     */             {
/* 198 */               printNamespaceDecl(attr, paramObjectRegistry, paramPrintWriter);
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 203 */         nodeList2 = paramNode.getChildNodes();
/*     */         
/* 205 */         if (nodeList2 != null) {
/*     */           
/* 207 */           int i = nodeList2.getLength();
/*     */           
/* 209 */           bool = (i > 0) ? true : false;
/*     */           
/* 211 */           if (bool)
/*     */           {
/* 213 */             paramPrintWriter.print('>');
/*     */           }
/*     */           
/* 216 */           for (byte b = 0; b < i; b++)
/*     */           {
/* 218 */             print(nodeList2.item(b), paramObjectRegistry, paramPrintWriter);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 223 */           bool = false;
/*     */         } 
/*     */         
/* 226 */         if (!bool)
/*     */         {
/* 228 */           paramPrintWriter.print("/>");
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 235 */         paramPrintWriter.print('&');
/* 236 */         paramPrintWriter.print(paramNode.getNodeName());
/* 237 */         paramPrintWriter.print(';');
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 243 */         paramPrintWriter.print("<![CDATA[");
/* 244 */         paramPrintWriter.print(paramNode.getNodeValue());
/* 245 */         paramPrintWriter.print("]]>");
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 251 */         paramPrintWriter.print(normalize(paramNode.getNodeValue()));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 257 */         paramPrintWriter.print("<!--");
/* 258 */         paramPrintWriter.print(paramNode.getNodeValue());
/* 259 */         paramPrintWriter.print("-->");
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 265 */         paramPrintWriter.print("<?");
/* 266 */         paramPrintWriter.print(paramNode.getNodeName());
/*     */         
/* 268 */         str1 = paramNode.getNodeValue();
/*     */         
/* 270 */         if (str1 != null && str1.length() > 0) {
/*     */           
/* 272 */           paramPrintWriter.print(' ');
/* 273 */           paramPrintWriter.print(str1);
/*     */         } 
/*     */         
/* 276 */         paramPrintWriter.println("?>");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 281 */     if (s == 1 && bool == true) {
/*     */       
/* 283 */       paramPrintWriter.print("</");
/* 284 */       paramPrintWriter.print(paramNode.getNodeName());
/* 285 */       paramPrintWriter.print('>');
/* 286 */       bool = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printNamespaceDecl(Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter) {
/* 294 */     switch (paramNode.getNodeType()) {
/*     */ 
/*     */       
/*     */       case 2:
/* 298 */         printNamespaceDecl(((Attr)paramNode).getOwnerElement(), paramNode, paramObjectRegistry, paramPrintWriter);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 305 */         printNamespaceDecl((Element)paramNode, paramNode, paramObjectRegistry, paramPrintWriter);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printNamespaceDecl(Element paramElement, Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter) {
/* 315 */     String str1 = paramNode.getNamespaceURI();
/* 316 */     String str2 = paramNode.getPrefix();
/*     */     
/* 318 */     if (!str1.equals(NS_URI_XMLNS) || !str2.equals("xmlns")) {
/*     */       
/* 320 */       if (DOMUtils.getAttributeNS(paramElement, NS_URI_XMLNS, str2) == null)
/*     */       {
/* 322 */         paramPrintWriter.print(" xmlns:" + str2 + "=\"" + str1 + '"');
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 327 */       str2 = paramNode.getLocalName();
/* 328 */       str1 = paramNode.getNodeValue();
/*     */     } 
/*     */     
/* 331 */     paramObjectRegistry.register(str2, str1);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String normalize(String paramString) {
/* 336 */     StringBuffer stringBuffer = new StringBuffer();
/* 337 */     byte b1 = (paramString != null) ? paramString.length() : 0;
/*     */     
/* 339 */     for (byte b2 = 0; b2 < b1; b2++) {
/*     */       
/* 341 */       char c = paramString.charAt(b2);
/*     */       
/* 343 */       switch (c) {
/*     */ 
/*     */         
/*     */         case '<':
/* 347 */           stringBuffer.append("&lt;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '>':
/* 352 */           stringBuffer.append("&gt;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '&':
/* 357 */           stringBuffer.append("&amp;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '"':
/* 362 */           stringBuffer.append("&quot;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '\n':
/* 367 */           if (b2 > 0) {
/*     */             
/* 369 */             char c1 = stringBuffer.charAt(stringBuffer.length() - 1);
/*     */             
/* 371 */             if (c1 != '\r') {
/*     */               
/* 373 */               stringBuffer.append(StringUtils.lineSeparator);
/*     */               
/*     */               break;
/*     */             } 
/* 377 */             stringBuffer.append('\n');
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 382 */           stringBuffer.append(StringUtils.lineSeparator);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 388 */           stringBuffer.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 393 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\DOM2Writer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */