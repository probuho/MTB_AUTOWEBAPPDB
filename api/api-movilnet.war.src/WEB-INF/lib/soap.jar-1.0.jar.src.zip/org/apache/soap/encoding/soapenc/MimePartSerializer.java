/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Writer;
/*     */ import java.net.URLEncoder;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.mime.ByteArrayDataSource;
/*     */ import org.apache.soap.util.mime.MimeUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimePartSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  95 */     paramNSStack.pushScope();
/*     */     
/*  97 */     if (paramObject1 != null && !(paramObject1 instanceof InputStream) && !(paramObject1 instanceof DataSource) && !(paramObject1 instanceof MimeBodyPart) && !(paramObject1 instanceof DataHandler))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 102 */       throw new IllegalArgumentException("Tried to pass a '" + paramObject1.getClass().toString() + "' to MimePartSerializer");
/*     */     }
/*     */     
/* 105 */     if (paramObject1 == null) {
/* 106 */       SoapEncUtils.generateNullStructure(paramString, Object.class, null, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */     } else {
/*     */       DataSource dataSource;
/*     */       
/* 110 */       ByteArrayDataSource byteArrayDataSource = null;
/* 111 */       DataHandler dataHandler = null;
/* 112 */       MimeBodyPart mimeBodyPart = null;
/* 113 */       if (paramObject1 instanceof InputStream) {
/* 114 */         byteArrayDataSource = new ByteArrayDataSource((InputStream)paramObject1, "application/octet-stream");
/*     */       }
/* 116 */       else if (paramObject1 instanceof DataSource) {
/* 117 */         dataSource = (DataSource)paramObject1;
/* 118 */       }  if (dataSource != null) {
/* 119 */         dataHandler = new DataHandler(dataSource);
/* 120 */       } else if (paramObject1 instanceof DataHandler) {
/* 121 */         dataHandler = (DataHandler)paramObject1;
/* 122 */       }  if (dataHandler != null) {
/* 123 */         mimeBodyPart = new MimeBodyPart();
/*     */         try {
/* 125 */           mimeBodyPart.setDataHandler(dataHandler);
/* 126 */         } catch (MessagingException messagingException) {
/* 127 */           throw new IllegalArgumentException("Invalid InputStream/DataSource/DataHandler: " + messagingException);
/*     */         }
/*     */       
/* 130 */       } else if (paramObject1 instanceof MimeBodyPart) {
/* 131 */         mimeBodyPart = (MimeBodyPart)paramObject1;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 136 */       String str = null;
/*     */       try {
/* 138 */         str = mimeBodyPart.getContentID();
/* 139 */       } catch (MessagingException messagingException) {}
/*     */       
/* 141 */       if (str == null) {
/* 142 */         str = MimeUtils.getUniqueValue();
/*     */         try {
/* 144 */           mimeBodyPart.setHeader("Content-ID", '<' + str + '>');
/* 145 */         } catch (MessagingException messagingException) {
/* 146 */           throw new IllegalArgumentException("Could not set Content-ID: " + messagingException);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 153 */         paramSOAPContext.addBodyPart(mimeBodyPart);
/* 154 */       } catch (MessagingException messagingException) {
/* 155 */         throw new IllegalArgumentException("Could not add attachment: " + messagingException);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 160 */       paramWriter.write('<' + paramObject2.toString());
/*     */ 
/*     */       
/* 163 */       paramWriter.write(" href =\"cid:" + URLEncoder.encode(str) + '"');
/*     */ 
/*     */       
/* 166 */       paramWriter.write("/>");
/*     */     } 
/*     */     
/* 169 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 177 */     Element element = (Element)paramNode;
/*     */     
/* 179 */     DataHandler dataHandler = null;
/* 180 */     if (!SoapEncUtils.isNull(element)) {
/* 181 */       String str = element.getAttribute("href");
/*     */       
/*     */       try {
/* 184 */         MimeBodyPart mimeBodyPart = null;
/*     */         
/* 186 */         try { mimeBodyPart = paramSOAPContext.findBodyPart(str); }
/* 187 */         catch (NullPointerException nullPointerException) {  }
/* 188 */         catch (ClassCastException classCastException) {}
/*     */         
/* 190 */         if (mimeBodyPart == null) {
/* 191 */           throw new IllegalArgumentException("Attachment tag \"" + element.getTagName() + "\" refers to a Mime attachment with label \"" + str + "\" which could not be found.");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 196 */         dataHandler = mimeBodyPart.getDataHandler();
/* 197 */       } catch (MessagingException messagingException) {
/* 198 */         throw new IllegalArgumentException("Failed to read attachment for tag \"" + element.getTagName() + "\" with label \"" + str + "\": " + messagingException);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 204 */     return new Bean(DataHandler.class, dataHandler);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\MimePartSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */