/*    */ package org.apache.soap.util;
/*    */ 
/*    */ import java.util.EmptyStackException;
/*    */ import java.util.Iterator;
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class soapCycleDetect
/*    */ {
/* 38 */   Stack cycleStack = new Stack();
/*    */   
/*    */   private int stackCount;
/*    */ 
/*    */   
/*    */   private boolean findDuplicates(Object paramObject) {
/* 44 */     boolean bool = false;
/* 45 */     Object object = null;
/* 46 */     Iterator iterator = this.cycleStack.iterator();
/* 47 */     while (iterator.hasNext()) {
/*    */       
/* 49 */       object = iterator.next();
/* 50 */       if (paramObject == object)
/*    */       {
/*    */         
/* 53 */         return true;
/*    */       }
/*    */     } 
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void push(Object paramObject) throws Exception {
/* 61 */     if (this.stackCount > 2)
/*    */     {
/* 63 */       if (findDuplicates(paramObject))
/*    */       {
/* 65 */         throw new Exception("Invalid cycle detected ");
/*    */       }
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 72 */     this.cycleStack.push(paramObject);
/* 73 */     this.stackCount++;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void pop() {
/*    */     try {
/* 80 */       this.cycleStack.pop();
/* 81 */     } catch (EmptyStackException emptyStackException) {
/* 82 */       System.out.println(" EmptyStackException cycleDetection:pop stackCount = " + this.stackCount);
/*    */     } 
/*    */     
/* 85 */     this.stackCount--;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\soapCycleDetect.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */