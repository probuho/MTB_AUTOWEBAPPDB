/*    */ package org.apache.soap.util.net;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.ServerSocket;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TcpTunnel
/*    */ {
/*    */   public static void main(String[] paramArrayOfString) throws IOException {
/* 72 */     if (paramArrayOfString.length != 3) {
/* 73 */       System.err.println("Usage: java TcpTunnel listenport tunnelhost tunnelport");
/* 74 */       System.exit(1);
/*    */     } 
/*    */     
/* 77 */     int i = Integer.parseInt(paramArrayOfString[0]);
/* 78 */     String str = paramArrayOfString[1];
/* 79 */     int j = Integer.parseInt(paramArrayOfString[2]);
/*    */     
/* 81 */     System.out.println("TcpTunnel: ready to rock and roll on port " + i);
/*    */ 
/*    */     
/* 84 */     ServerSocket serverSocket = new ServerSocket(i);
/*    */     
/*    */     while (true) {
/* 87 */       Socket socket1 = serverSocket.accept();
/*    */ 
/*    */       
/* 90 */       Socket socket2 = new Socket(str, j);
/*    */       
/* 92 */       System.out.println("TcpTunnel: tunnelling port " + i + " to port " + j + " on host " + str);
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 97 */       (new Relay(socket1.getInputStream(), socket2.getOutputStream(), null)).start();
/* 98 */       (new Relay(socket2.getInputStream(), socket1.getOutputStream(), null)).start();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\net\TcpTunnel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */