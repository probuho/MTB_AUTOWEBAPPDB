/*     */ package org.apache.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import org.apache.soap.encoding.soapenc.MultiRefContext;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Body
/*     */ {
/*  80 */   private Vector bodyEntries = null;
/*  81 */   private AttributeHandler attrHandler = new AttributeHandler();
/*     */ 
/*     */   
/*     */   public void setAttribute(QName paramQName, String paramString) {
/*  85 */     this.attrHandler.setAttribute(paramQName, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(QName paramQName) {
/*  90 */     return this.attrHandler.getAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAttribute(QName paramQName) {
/*  95 */     this.attrHandler.removeAttribute(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void declareNamespace(String paramString1, String paramString2) {
/* 100 */     this.attrHandler.declareNamespace(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBodyEntries(Vector paramVector) {
/* 105 */     this.bodyEntries = paramVector;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector getBodyEntries() {
/* 110 */     return this.bodyEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 117 */     this.attrHandler.populateNSStack(paramNSStack);
/*     */     
/* 119 */     String str1 = getAttribute(new QName("http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle"));
/*     */     
/* 121 */     String str2 = (str1 != null) ? str1 : paramString;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     String str3 = this.attrHandler.getUniquePrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", "SOAP-ENV", paramNSStack);
/*     */ 
/*     */     
/* 129 */     paramWriter.write('<' + str3 + ':' + "Body");
/*     */ 
/*     */     
/* 132 */     this.attrHandler.marshall(paramWriter, paramSOAPContext);
/*     */     
/* 134 */     paramWriter.write('>' + StringUtils.lineSeparator);
/*     */ 
/*     */     
/* 137 */     if (this.bodyEntries != null)
/*     */     {
/* 139 */       for (Enumeration enumeration = this.bodyEntries.elements(); enumeration.hasMoreElements(); ) {
/*     */         
/* 141 */         Bean bean = (Bean)enumeration.nextElement();
/* 142 */         if (bean instanceof Bean) {
/*     */           
/* 144 */           Bean bean1 = bean;
/*     */           
/* 146 */           if (Serializer.class.isAssignableFrom(bean1.type))
/*     */           {
/* 148 */             ((Serializer)bean1.value).marshall(str2, bean1.type, bean1.value, null, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 159 */             throw new IllegalArgumentException("Body entries must implement the Serializer interface.");
/*     */           }
/*     */         
/*     */         }
/* 163 */         else if (bean instanceof Element) {
/*     */           
/* 165 */           Utils.marshallNode((Element)bean, paramWriter);
/*     */         }
/*     */         else {
/*     */           
/* 169 */           throw new IllegalArgumentException("Unknown type of body entry: '" + bean.getClass() + "'");
/*     */         } 
/*     */         
/* 172 */         paramWriter.write(StringUtils.lineSeparator);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 177 */     if (paramSOAPContext.getMultiRefCount() > 0) {
/*     */       
/* 179 */       MultiRefContext multiRefContext = new MultiRefContext();
/*     */ 
/*     */ 
/*     */       
/* 183 */       for (byte b = 0; b < paramSOAPContext.getMultiRefCount(); b++) {
/* 184 */         Object object = paramSOAPContext.getMultiRefObject(b);
/* 185 */         Serializer serializer = paramSOAPContext.getMultiRefSerializer(b);
/* 186 */         multiRefContext.setId(b);
/* 187 */         serializer.marshall(str2, object.getClass(), object, multiRefContext, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramSOAPContext);
/*     */         
/* 189 */         paramWriter.write(StringUtils.lineSeparator);
/*     */       } 
/*     */     } 
/*     */     
/* 193 */     paramWriter.write("</" + str3 + ':' + "Body" + '>' + StringUtils.lineSeparator);
/*     */ 
/*     */     
/* 196 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Body unmarshall(Node paramNode, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 201 */     Element element1 = (Element)paramNode;
/* 202 */     Body body = new Body();
/* 203 */     Vector vector = new Vector();
/*     */ 
/*     */     
/* 206 */     body.attrHandler = AttributeHandler.unmarshall(element1, paramSOAPContext);
/*     */     
/* 208 */     Element element2 = DOMUtils.getFirstChildElement(element1);
/* 209 */     for (; element2 != null; 
/* 210 */       element2 = DOMUtils.getNextSiblingElement(element2))
/*     */     {
/* 212 */       vector.addElement(element2);
/*     */     }
/*     */     
/* 215 */     body.setBodyEntries(vector);
/*     */     
/* 217 */     return body;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 222 */     StringWriter stringWriter = new StringWriter();
/* 223 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 225 */     printWriter.print("[Attributes=" + this.attrHandler + "] " + "[BodyEntries=");
/*     */ 
/*     */     
/* 228 */     if (this.bodyEntries != null) {
/*     */       
/* 230 */       printWriter.println();
/*     */       
/* 232 */       for (byte b = 0; b < this.bodyEntries.size(); b++)
/*     */       {
/* 234 */         printWriter.println("[(" + b + ")=" + this.bodyEntries.elementAt(b) + "]");
/*     */       }
/*     */     } 
/*     */     
/* 238 */     printWriter.print("]");
/*     */     
/* 240 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\Body.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */