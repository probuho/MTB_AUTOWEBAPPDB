/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VectorSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*     */     Enumeration enumeration;
/*  86 */     paramNSStack.pushScope();
/*     */     
/*  88 */     if (paramObject1 != null && !(paramObject1 instanceof Vector) && !(paramObject1 instanceof Enumeration))
/*     */     {
/*     */       
/*  91 */       throw new IllegalArgumentException("Tried to pass a '" + paramObject1.getClass().toString() + "' to VectorSerializer");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (paramObject1 instanceof Enumeration) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       enumeration = (Enumeration)paramObject1;
/* 104 */       String str = "";
/*     */     } else {
/* 106 */       Vector vector = (Vector)paramObject1;
/* 107 */       enumeration = vector.elements();
/*     */       
/* 109 */       String str = (paramObject1 != null) ? (vector.size() + "") : "";
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (paramObject1 == null) {
/*     */       
/* 117 */       SoapEncUtils.generateNullStructure(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 126 */       SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 133 */       paramWriter.write(StringUtils.lineSeparator);
/*     */       
/* 135 */       for (Enumeration enumeration1 = enumeration; enumeration1.hasMoreElements(); ) {
/*     */         
/* 137 */         paramNSStack.pushScope();
/*     */         
/* 139 */         Object object = enumeration1.nextElement();
/*     */         
/* 141 */         if (object == null) {
/*     */           
/* 143 */           SoapEncUtils.generateNullStructure("http://schemas.xmlsoap.org/soap/encoding/", Object.class, "item", paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 149 */           Class clazz = object.getClass();
/*     */           
/* 151 */           paramXMLJavaMappingRegistry.marshall("http://schemas.xmlsoap.org/soap/encoding/", clazz, object, "item", paramWriter, paramNSStack, paramSOAPContext);
/*     */         } 
/*     */ 
/*     */         
/* 155 */         paramWriter.write(StringUtils.lineSeparator);
/* 156 */         paramNSStack.popScope();
/*     */       } 
/*     */       
/* 159 */       paramWriter.write("</" + paramObject2 + '>');
/*     */     } 
/*     */     
/* 162 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 169 */     Element element1 = (Element)paramNode;
/* 170 */     if (SoapEncUtils.isNull(element1)) {
/* 171 */       return new Bean(Vector.class, null);
/*     */     }
/*     */     
/* 174 */     Vector vector = new Vector();
/*     */     
/* 176 */     Element element2 = DOMUtils.getFirstChildElement(element1);
/* 177 */     while (element2 != null) {
/* 178 */       String str1 = DOMUtils.getAttributeNS(element2, "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle");
/*     */       
/* 180 */       String str2 = (str1 != null) ? str1 : paramString;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       String str3 = element2.getAttribute("href");
/* 186 */       Element element = element2;
/* 187 */       if (str3 != null && !str3.equals("") && str3.charAt(0) == '#') {
/*     */         
/* 189 */         str3 = str3.substring(1);
/* 190 */         element = DOMUtils.getElementByID(paramNode.getOwnerDocument().getDocumentElement(), str3);
/* 191 */         if (element == null) {
/* 192 */           throw new IllegalArgumentException("No such ID '" + str3 + "'");
/*     */         }
/*     */       } 
/*     */       
/* 196 */       QName qName1 = SoapEncUtils.getTypeQName(element);
/* 197 */       QName qName2 = qName1;
/*     */       
/* 199 */       Bean bean = paramXMLJavaMappingRegistry.unmarshall(str2, qName2, element, paramSOAPContext);
/*     */ 
/*     */       
/* 202 */       vector.addElement(bean.value);
/*     */       
/* 204 */       element2 = DOMUtils.getNextSiblingElement(element2);
/*     */     } 
/*     */     
/* 207 */     return new Bean(Vector.class, vector);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\VectorSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */