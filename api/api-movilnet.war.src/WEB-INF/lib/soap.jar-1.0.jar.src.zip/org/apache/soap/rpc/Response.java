/*     */ package org.apache.soap.rpc;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.Fault;
/*     */ import org.apache.soap.Header;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Response
/*     */   extends RPCMessage
/*     */ {
/*     */   private Parameter returnValue;
/*     */   private Fault fault;
/*     */   
/*     */   public Response(String paramString1, String paramString2, Parameter paramParameter, Vector paramVector, Header paramHeader, String paramString3, SOAPContext paramSOAPContext) {
/*  89 */     super(paramString1, paramString2, paramVector, paramHeader, paramString3, paramSOAPContext);
/*     */     
/*  91 */     this.returnValue = paramParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response(String paramString1, String paramString2, Fault paramFault, Vector paramVector, Header paramHeader, String paramString3, SOAPContext paramSOAPContext) {
/* 101 */     super(paramString1, paramString2, paramVector, paramHeader, paramString3, paramSOAPContext);
/*     */ 
/*     */     
/* 104 */     this.fault = paramFault;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReturnValue(Parameter paramParameter) {
/* 109 */     this.returnValue = paramParameter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Parameter getReturnValue() {
/* 114 */     return this.returnValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFault(Fault paramFault) {
/* 119 */     this.fault = paramFault;
/*     */   }
/*     */ 
/*     */   
/*     */   public Fault getFault() {
/* 124 */     return this.fault;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean generatedFault() {
/* 129 */     return (this.fault != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Envelope buildEnvelope() {
/* 134 */     return buildEnvelope(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Response extractFromEnvelope(Envelope paramEnvelope, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 142 */     return (Response)RPCMessage.extractFromEnvelope(paramEnvelope, true, paramSOAPMappingRegistry, paramSOAPContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BodyPart findBodyPart(String paramString) {
/* 161 */     return (BodyPart)this.ctx.findBodyPart(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPartCount() throws MessagingException {
/* 171 */     return this.ctx.getCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BodyPart getBodyPart(int paramInt) throws IndexOutOfBoundsException {
/* 182 */     return (BodyPart)this.ctx.getBodyPart(paramInt);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\rpc\Response.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */