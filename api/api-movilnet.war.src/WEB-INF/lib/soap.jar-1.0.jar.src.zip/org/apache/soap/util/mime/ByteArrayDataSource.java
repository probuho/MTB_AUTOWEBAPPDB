/*     */ package org.apache.soap.util.mime;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.activation.DataSource;
/*     */ import javax.activation.FileTypeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteArrayDataSource
/*     */   implements DataSource
/*     */ {
/*     */   private byte[] data;
/*     */   private String type;
/*     */   
/*     */   public ByteArrayDataSource(File paramFile, String paramString) throws IOException {
/*  86 */     this(new FileInputStream(paramFile), paramString);
/*  87 */     if (this.type == null) {
/*  88 */       this.type = FileTypeMap.getDefaultFileTypeMap().getContentType(paramFile);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayDataSource(InputStream paramInputStream, String paramString) throws IOException {
/*  99 */     this.type = paramString;
/*     */     
/* 101 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/* 103 */     byte[] arrayOfByte = new byte[4096];
/*     */     
/*     */     while (true) {
/* 106 */       int i = paramInputStream.read(arrayOfByte);
/* 107 */       if (i < 0)
/*     */         break; 
/* 109 */       byteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */     } 
/* 111 */     this.data = byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayDataSource(byte[] paramArrayOfbyte, String paramString) {
/* 122 */     this.type = paramString;
/* 123 */     this.data = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayDataSource(String paramString1, String paramString2) {
/* 136 */     this.type = paramString2;
/*     */     try {
/* 138 */       this.data = paramString1.getBytes(MimeUtils.getEncoding(paramString2, "iso-8859-1"));
/*     */     }
/* 140 */     catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 150 */     if (this.data == null)
/* 151 */       throw new IOException("No data."); 
/* 152 */     return new ByteArrayInputStream(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 160 */     throw new IOException("getOutputStream() not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 169 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContentType(String paramString) {
/* 178 */     this.type = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 185 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream paramOutputStream) throws IOException {
/* 194 */     paramOutputStream.write(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toByteArray() {
/* 203 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 212 */     if (this.data == null) {
/* 213 */       return -1;
/*     */     }
/* 215 */     return this.data.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/*     */     try {
/* 227 */       return new String(this.data, MimeUtils.getEncoding(this.type, "iso-8859-1"));
/*     */     }
/* 229 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       try {
/* 231 */         return new String(this.data, "iso-8859-1");
/* 232 */       } catch (UnsupportedEncodingException unsupportedEncodingException1) {
/* 233 */         return null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\mime\ByteArrayDataSource.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */