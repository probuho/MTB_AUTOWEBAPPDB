/*     */ package org.apache.soap.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringUtils
/*     */ {
/*  73 */   public static final String lineSeparator = System.getProperty("line.separator", "\n");
/*     */   
/*  75 */   public static String URI_SEPARATION_CHAR = "@";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getClassName(Class paramClass) {
/*  90 */     String str = paramClass.getName();
/*     */     
/*  92 */     return paramClass.isArray() ? parseDescriptor(str) : str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String parseDescriptor(String paramString) {
/* 100 */     char[] arrayOfChar = paramString.toCharArray();
/* 101 */     byte b1 = 0;
/* 102 */     byte b2 = 0;
/*     */     
/* 104 */     while (arrayOfChar[b2] == '[') {
/*     */       
/* 106 */       b1++;
/* 107 */       b2++;
/*     */     } 
/*     */     
/* 110 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 112 */     switch (arrayOfChar[b2++]) {
/*     */       case 'B':
/* 114 */         stringBuffer.append("byte"); break;
/*     */       case 'C':
/* 116 */         stringBuffer.append("char"); break;
/*     */       case 'D':
/* 118 */         stringBuffer.append("double"); break;
/*     */       case 'F':
/* 120 */         stringBuffer.append("float"); break;
/*     */       case 'I':
/* 122 */         stringBuffer.append("int"); break;
/*     */       case 'J':
/* 124 */         stringBuffer.append("long"); break;
/*     */       case 'S':
/* 126 */         stringBuffer.append("short"); break;
/*     */       case 'Z':
/* 128 */         stringBuffer.append("boolean"); break;
/*     */       case 'L':
/* 130 */         stringBuffer.append(arrayOfChar, b2, arrayOfChar.length - b2 - 1);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 135 */     for (b2 = 0; b2 < b1; b2++) {
/* 136 */       stringBuffer.append("[]");
/*     */     }
/* 138 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URL getURL(URL paramURL, String paramString, int paramInt) throws MalformedURLException {
/* 148 */     URL uRL = null;
/*     */ 
/*     */     
/*     */     try {
/* 152 */       uRL = new URL(paramURL, paramString);
/*     */ 
/*     */       
/*     */       try {
/* 156 */         uRL.openStream();
/*     */       }
/* 158 */       catch (IOException iOException) {
/*     */         
/* 160 */         throw new MalformedURLException("This file was not found: " + uRL);
/*     */       }
/*     */     
/* 163 */     } catch (MalformedURLException malformedURLException) {
/*     */       
/* 165 */       uRL = new URL("file", "", paramString);
/*     */ 
/*     */       
/*     */       try {
/* 169 */         uRL.openStream();
/*     */       }
/* 171 */       catch (IOException iOException) {
/*     */         
/* 173 */         if (paramURL != null) {
/*     */           
/* 175 */           String str1 = paramURL.getFile();
/* 176 */           String str2 = (new File(str1)).getParent();
/*     */           
/* 178 */           if (str2 != null && paramInt < 3)
/*     */           {
/* 180 */             return getURL(new URL("file", "", str2 + '/'), paramString, paramInt + 1);
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 186 */         throw new MalformedURLException("This file was not found: " + uRL);
/*     */       } 
/*     */     } 
/*     */     
/* 190 */     return uRL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getURL(URL paramURL, String paramString) throws MalformedURLException {
/* 197 */     return getURL(paramURL, paramString, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Reader getContentAsReader(URL paramURL) throws SecurityException, IllegalArgumentException, IOException {
/* 208 */     if (paramURL == null)
/*     */     {
/* 210 */       throw new IllegalArgumentException("URL cannot be null.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 215 */       Object object = paramURL.getContent();
/*     */       
/* 217 */       if (object == null)
/*     */       {
/* 219 */         throw new IllegalArgumentException("No content.");
/*     */       }
/*     */       
/* 222 */       if (object instanceof InputStream) {
/*     */         
/* 224 */         InputStreamReader inputStreamReader = new InputStreamReader((InputStream)object);
/*     */         
/* 226 */         if (inputStreamReader.ready())
/*     */         {
/* 228 */           return inputStreamReader;
/*     */         }
/*     */ 
/*     */         
/* 232 */         throw new FileNotFoundException();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 237 */       throw new IllegalArgumentException((object instanceof String) ? (String)object : ("This URL points to a: " + getClassName(object.getClass())));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 243 */     catch (SecurityException securityException) {
/*     */       
/* 245 */       throw new SecurityException("Your JVM's SecurityManager has disallowed this.");
/*     */     }
/* 247 */     catch (FileNotFoundException fileNotFoundException) {
/*     */       
/* 249 */       throw new FileNotFoundException("This file was not found: " + paramURL);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getContentAsString(URL paramURL) throws SecurityException, IllegalArgumentException, IOException {
/* 260 */     return IOUtils.getStringFromReader(getContentAsReader(paramURL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseFullTargetObjectURI(String paramString) {
/* 274 */     if (paramString == null) return null; 
/* 275 */     int i = paramString.indexOf(URI_SEPARATION_CHAR);
/* 276 */     if (paramString != null && i != -1) {
/* 277 */       return paramString.substring(0, i);
/*     */     }
/* 279 */     return paramString;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\StringUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */