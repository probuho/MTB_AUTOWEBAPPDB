/*    */ package org.apache.soap.util.xml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrefixedName
/*    */ {
/* 67 */   private String prefix = null;
/* 68 */   private QName qname = null;
/*    */ 
/*    */   
/*    */   public PrefixedName(String paramString, QName paramQName) {
/* 72 */     this.prefix = paramString;
/* 73 */     this.qname = paramQName;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrefix(String paramString) {
/* 78 */     this.prefix = paramString;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPrefix() {
/* 83 */     return this.prefix;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setQName(QName paramQName) {
/* 88 */     this.qname = paramQName;
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getQName() {
/* 93 */     return this.qname;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 98 */     return ((this.prefix != null && !this.prefix.equals("")) ? (this.prefix + ':') : "") + this.qname.getLocalPart();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\xml\PrefixedName.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */