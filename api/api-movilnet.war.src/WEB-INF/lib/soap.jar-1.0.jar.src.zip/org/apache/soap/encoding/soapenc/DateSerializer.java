/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   SimpleDateFormat sdf;
/*     */   
/*     */   public DateSerializer() {
/*  88 */     this.sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
/*     */     
/*  90 */     this.sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  98 */     if (!paramClass.equals(Date.class))
/*     */     {
/* 100 */       throw new IllegalArgumentException("Can only serialize java.util.Date instances");
/*     */     }
/* 102 */     paramNSStack.pushScope();
/* 103 */     if (paramObject1 != null) {
/*     */       
/* 105 */       SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       String str = null;
/*     */       
/* 113 */       synchronized (this.sdf) {
/*     */         
/* 115 */         str = this.sdf.format((Date)paramObject1);
/*     */       } 
/*     */       
/* 118 */       paramWriter.write(str);
/* 119 */       paramWriter.write("</" + paramObject2 + '>');
/*     */     }
/*     */     else {
/*     */       
/* 123 */       SoapEncUtils.generateNullStructure(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     paramNSStack.popScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 136 */     Date date = null;
/* 137 */     Element element = (Element)paramNode;
/* 138 */     String str = DOMUtils.getChildCharacterData(element);
/* 139 */     if (str != null && !(str = str.trim()).equals("")) {
/*     */       
/*     */       try {
/*     */         
/* 143 */         synchronized (this.sdf)
/*     */         {
/* 145 */           date = this.sdf.parse(str);
/*     */         }
/*     */       
/* 148 */       } catch (ParseException parseException) {
/*     */ 
/*     */         
/*     */         try {
/*     */           
/* 153 */           if (str.length() < 19) {
/* 154 */             throw new ParseException("", 0);
/*     */           }
/* 156 */           if (str.charAt(4) != '-' || str.charAt(7) != '-' || str.charAt(10) != 'T')
/*     */           {
/* 158 */             throw new ParseException("", 0);
/*     */           }
/* 160 */           if (str.charAt(13) != ':' || str.charAt(16) != ':') {
/* 161 */             throw new ParseException("", 0);
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/* 166 */             synchronized (this.sdf)
/*     */             {
/* 168 */               date = this.sdf.parse(str.substring(0, 19) + ".000Z");
/*     */             }
/*     */           
/* 171 */           } catch (Exception exception) {
/*     */             
/* 173 */             throw new ParseException("", 0);
/*     */           } 
/*     */           
/* 176 */           byte b = 19;
/*     */ 
/*     */           
/* 179 */           if (b < str.length() && str.charAt(b) == '.') {
/* 180 */             int i = 0;
/* 181 */             byte b1 = ++b;
/* 182 */             while (b < str.length() && Character.isDigit(str.charAt(b))) {
/* 183 */               b++;
/*     */             }
/* 185 */             String str1 = str.substring(b1, b);
/* 186 */             if (str1.length() == 3) {
/* 187 */               i = Integer.parseInt(str1);
/* 188 */             } else if (str1.length() < 3) {
/* 189 */               i = Integer.parseInt((str1 + "000").substring(0, 3));
/*     */             } else {
/* 191 */               i = Integer.parseInt(str1.substring(0, 3));
/* 192 */               if (str1.charAt(3) >= '5') i++;
/*     */             
/*     */             } 
/*     */             
/* 196 */             date.setTime(date.getTime() + i);
/*     */           } 
/*     */ 
/*     */           
/* 200 */           if (b + 5 < str.length() && (str.charAt(b) == '+' || str.charAt(b) == '-')) {
/*     */ 
/*     */             
/* 203 */             if (!Character.isDigit(str.charAt(b + 1)) || !Character.isDigit(str.charAt(b + 2)) || str.charAt(b + 3) != ':' || !Character.isDigit(str.charAt(b + 4)) || !Character.isDigit(str.charAt(b + 5)))
/*     */             {
/*     */ 
/*     */ 
/*     */               
/* 208 */               throw new ParseException("", 0);
/*     */             }
/* 210 */             int i = (str.charAt(b + 1) - 48) * 10 + str.charAt(b + 2) - 48;
/* 211 */             int j = (str.charAt(b + 4) - 48) * 10 + str.charAt(b + 5) - 48;
/* 212 */             int k = (i * 60 + j) * 60 * 1000;
/*     */ 
/*     */             
/* 215 */             if (str.charAt(b) == '+') k = -k; 
/* 216 */             date.setTime(date.getTime() + k);
/* 217 */             b += 6;
/*     */           } 
/*     */           
/* 220 */           if (b < str.length() && str.charAt(b) == 'Z') b++;
/*     */           
/* 222 */           if (b < str.length()) {
/* 223 */             throw new ParseException("", 0);
/*     */           }
/* 225 */         } catch (ParseException parseException1) {
/*     */           
/* 227 */           synchronized (this.sdf) {
/*     */             
/* 229 */             throw new IllegalArgumentException("String represents no valid Date for this Deserializer; try " + this.sdf.toPattern() + ".");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 236 */     return new Bean(Date.class, date);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\DateSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */