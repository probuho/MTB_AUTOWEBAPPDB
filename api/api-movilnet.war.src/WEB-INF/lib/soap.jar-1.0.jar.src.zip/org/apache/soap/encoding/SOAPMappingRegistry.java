/*     */ package org.apache.soap.encoding;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Writer;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import oracle.soap.encoding.soapenc.DocumentFragmentSerializer;
/*     */ import oracle.soap.encoding.soapenc.DocumentSerializer;
/*     */ import oracle.soap.encoding.soapenc.DoubleSerializer;
/*     */ import oracle.soap.encoding.soapenc.FloatSerializer;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Utils;
/*     */ import org.apache.soap.encoding.literalxml.XMLParameterSerializer;
/*     */ import org.apache.soap.encoding.soapenc.ArraySerializer;
/*     */ import org.apache.soap.encoding.soapenc.Base64Serializer;
/*     */ import org.apache.soap.encoding.soapenc.BooleanDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.ByteDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.CalendarSerializer;
/*     */ import org.apache.soap.encoding.soapenc.DateSerializer;
/*     */ import org.apache.soap.encoding.soapenc.DecimalDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.DoubleDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.FloatDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.HashtableSerializer;
/*     */ import org.apache.soap.encoding.soapenc.HexDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.IntDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.LongDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.MapSerializer;
/*     */ import org.apache.soap.encoding.soapenc.MimePartSerializer;
/*     */ import org.apache.soap.encoding.soapenc.ParameterSerializer;
/*     */ import org.apache.soap.encoding.soapenc.QNameSerializer;
/*     */ import org.apache.soap.encoding.soapenc.ShortDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.SoapEncUtils;
/*     */ import org.apache.soap.encoding.soapenc.StringDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.UrTypeDeserializer;
/*     */ import org.apache.soap.encoding.soapenc.VectorSerializer;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.RPCConstants;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPMappingRegistry
/*     */   extends XMLJavaMappingRegistry
/*     */ {
/*     */   private static SOAPMappingRegistry baseReg1999;
/*     */   private static SOAPMappingRegistry baseReg2000;
/*     */   private static SOAPMappingRegistry baseReg2001;
/*  91 */   private SOAPMappingRegistry parent = null;
/*     */   
/*     */   private String schemaURI;
/*  94 */   private static String soapEncURI = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */   
/*  96 */   private static QName arrayQName = new QName(soapEncURI, "Array");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private static StringDeserializer stringDeser = new StringDeserializer();
/* 102 */   private static IntDeserializer intDeser = new IntDeserializer();
/* 103 */   private static DecimalDeserializer decimalDeser = new DecimalDeserializer();
/* 104 */   private static FloatDeserializer floatDeser = new FloatDeserializer();
/* 105 */   private static DoubleDeserializer doubleDeser = new DoubleDeserializer();
/* 106 */   private static BooleanDeserializer booleanDeser = new BooleanDeserializer();
/* 107 */   private static LongDeserializer longDeser = new LongDeserializer();
/* 108 */   private static ShortDeserializer shortDeser = new ShortDeserializer();
/* 109 */   private static ByteDeserializer byteDeser = new ByteDeserializer();
/* 110 */   private static HexDeserializer hexDeser = new HexDeserializer();
/*     */   
/* 112 */   private static QNameSerializer qNameSer = new QNameSerializer();
/* 113 */   private static ParameterSerializer paramSer = new ParameterSerializer();
/* 114 */   private static ArraySerializer arraySer = new ArraySerializer();
/* 115 */   private static VectorSerializer vectorSer = new VectorSerializer();
/* 116 */   private static HashtableSerializer hashtableSer = new HashtableSerializer();
/* 117 */   private static XMLParameterSerializer xmlParamSer = new XMLParameterSerializer();
/*     */   
/* 119 */   private static DateSerializer dateSer = new DateSerializer();
/* 120 */   private static CalendarSerializer calSer = new CalendarSerializer();
/* 121 */   private static UrTypeDeserializer objDeser = new UrTypeDeserializer();
/* 122 */   public static MimePartSerializer partSer = new MimePartSerializer();
/*     */   
/* 124 */   private static FloatSerializer fser = new FloatSerializer();
/* 125 */   private static DoubleSerializer dser = new DoubleSerializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   private static QName[] schema1999QNames = new QName[] { Constants.string1999QName, Constants.int1999QName, Constants.int1999QName, Constants.decimal1999QName, Constants.float1999QName, Constants.float1999QName, Constants.double1999QName, Constants.double1999QName, Constants.boolean1999QName, Constants.boolean1999QName, Constants.long1999QName, Constants.long1999QName, Constants.short1999QName, Constants.short1999QName, Constants.byte1999QName, Constants.byte1999QName, Constants.hex1999QName, Constants.qName1999QName, Constants.date1999QName, Constants.timeInst1999QName, Constants.object1999QName, Constants.object1999QName, Constants.object1999QName, Constants.object1999QName, Constants.object1999QName };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   private static QName[] schema2000QNames = new QName[] { Constants.string2000QName, Constants.int2000QName, Constants.int2000QName, Constants.decimal2000QName, Constants.float2000QName, Constants.float2000QName, Constants.double2000QName, Constants.double2000QName, Constants.boolean2000QName, Constants.boolean2000QName, Constants.long2000QName, Constants.long2000QName, Constants.short2000QName, Constants.short2000QName, Constants.byte2000QName, Constants.byte2000QName, Constants.hex2000QName, Constants.qName2000QName, Constants.date2000QName, Constants.timeInst2000QName, Constants.object2000QName, Constants.object2000QName, Constants.object2000QName, Constants.object2000QName, Constants.object2000QName };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   private static QName[] schema2001QNames = new QName[] { Constants.string2001QName, Constants.int2001QName, Constants.int2001QName, Constants.decimal2001QName, Constants.float2001QName, Constants.float2001QName, Constants.double2001QName, Constants.double2001QName, Constants.boolean2001QName, Constants.boolean2001QName, Constants.long2001QName, Constants.long2001QName, Constants.short2001QName, Constants.short2001QName, Constants.byte2001QName, Constants.byte2001QName, Constants.hex2001QName, Constants.qName2001QName, Constants.date2001QName, Constants.timeInst2001QName, Constants.object2001QName, Constants.object2001QName, Constants.object2001QName, Constants.object2001QName, Constants.object2001QName };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   private static Class[] classes = new Class[] { String.class, Integer.class, int.class, BigDecimal.class, Float.class, float.class, Double.class, double.class, Boolean.class, boolean.class, Long.class, long.class, Short.class, short.class, Byte.class, byte.class, Hex.class, QName.class, GregorianCalendar.class, Date.class, MimeBodyPart.class, InputStream.class, DataSource.class, DataHandler.class, Object.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   private static Serializer cleanSer = new Serializer()
/*     */     {
/*     */ 
/*     */       
/*     */       public void marshall(String param1String, Class param1Class, Object param1Object1, Object param1Object2, Writer param1Writer, NSStack param1NSStack, XMLJavaMappingRegistry param1XMLJavaMappingRegistry, SOAPContext param1SOAPContext) throws IllegalArgumentException, IOException
/*     */       {
/* 260 */         param1NSStack.pushScope();
/*     */         
/* 262 */         if (param1Object1 == null) {
/*     */           
/* 264 */           SoapEncUtils.generateNullStructure(param1String, param1Class, param1Object2, param1Writer, param1NSStack, param1XMLJavaMappingRegistry);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 269 */           SoapEncUtils.generateStructureHeader(param1String, param1Class, param1Object2, param1Writer, param1NSStack, param1XMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 276 */           param1Writer.write(Utils.cleanString(param1Object1.toString()) + "</" + param1Object2 + '>');
/*     */         } 
/* 278 */         param1NSStack.popScope();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 287 */   private static Serializer ser = new Serializer()
/*     */     {
/*     */ 
/*     */       
/*     */       public void marshall(String param1String, Class param1Class, Object param1Object1, Object param1Object2, Writer param1Writer, NSStack param1NSStack, XMLJavaMappingRegistry param1XMLJavaMappingRegistry, SOAPContext param1SOAPContext) throws IllegalArgumentException, IOException
/*     */       {
/* 293 */         param1NSStack.pushScope();
/*     */         
/* 295 */         SoapEncUtils.generateStructureHeader(param1String, param1Class, param1Object2, param1Writer, param1NSStack, param1XMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 302 */         param1Writer.write(param1Object1 + "</" + param1Object2 + '>');
/*     */         
/* 304 */         param1NSStack.popScope();
/*     */       }
/*     */     };
/*     */   
/* 308 */   private static Serializer[] serializers = new Serializer[] { cleanSer, ser, ser, ser, (Serializer)fser, (Serializer)fser, (Serializer)dser, (Serializer)dser, ser, ser, ser, ser, ser, ser, ser, ser, ser, (Serializer)qNameSer, (Serializer)calSer, (Serializer)dateSer, (Serializer)partSer, (Serializer)partSer, (Serializer)partSer, (Serializer)partSer, null };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 336 */   private static Deserializer[] deserializers = new Deserializer[] { (Deserializer)stringDeser, null, (Deserializer)intDeser, (Deserializer)decimalDeser, null, (Deserializer)floatDeser, null, (Deserializer)doubleDeser, null, (Deserializer)booleanDeser, null, (Deserializer)longDeser, null, (Deserializer)shortDeser, null, (Deserializer)byteDeser, (Deserializer)hexDeser, (Deserializer)qNameSer, (Deserializer)calSer, (Deserializer)dateSer, null, null, null, null, (Deserializer)objDeser };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class array$B;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPMappingRegistry() {
/* 370 */     this.schemaURI = "http://www.w3.org/2001/XMLSchema";
/* 371 */     this.parent = getBaseRegistry("http://www.w3.org/2001/XMLSchema");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPMappingRegistry(SOAPMappingRegistry paramSOAPMappingRegistry) {
/* 381 */     this(paramSOAPMappingRegistry, "http://www.w3.org/2001/XMLSchema");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPMappingRegistry(SOAPMappingRegistry paramSOAPMappingRegistry, String paramString) {
/* 401 */     this.parent = paramSOAPMappingRegistry;
/* 402 */     if (paramSOAPMappingRegistry == null) {
/* 403 */       initializeRegistry(paramString);
/*     */     }
/* 405 */     this.schemaURI = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SOAPMappingRegistry getBaseRegistry(String paramString) {
/* 414 */     synchronized (SOAPMappingRegistry.class) {
/* 415 */       if (baseReg1999 == null) {
/* 416 */         baseReg1999 = new SOAPMappingRegistry(null, "http://www.w3.org/1999/XMLSchema");
/*     */         
/* 418 */         baseReg2000 = new SOAPMappingRegistry(null, "http://www.w3.org/2000/10/XMLSchema");
/*     */         
/* 420 */         baseReg2001 = new SOAPMappingRegistry(null, "http://www.w3.org/2001/XMLSchema");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 425 */     if (paramString.equals("http://www.w3.org/1999/XMLSchema"))
/* 426 */       return baseReg1999; 
/* 427 */     if (paramString.equals("http://www.w3.org/2000/10/XMLSchema")) {
/* 428 */       return baseReg2000;
/*     */     }
/* 430 */     return baseReg2001;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultEncodingStyle(String paramString) {
/* 439 */     super.setDefaultEncodingStyle(paramString);
/* 440 */     if (this.parent != null) {
/* 441 */       this.parent.setDefaultEncodingStyle(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchemaURI() {
/* 449 */     return this.schemaURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPMappingRegistry getParent() {
/* 457 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeRegistry(String paramString) {
/* 466 */     QName[] arrayOfQName = null;
/*     */     
/* 468 */     if (paramString.equals("http://www.w3.org/1999/XMLSchema")) {
/* 469 */       arrayOfQName = schema1999QNames;
/* 470 */       mapSchemaTypes(schema2000QNames, false);
/* 471 */       mapSchemaTypes(schema2001QNames, false);
/* 472 */     } else if (paramString.equals("http://www.w3.org/2000/10/XMLSchema")) {
/* 473 */       mapSchemaTypes(schema1999QNames, false);
/* 474 */       arrayOfQName = schema2000QNames;
/* 475 */       mapSchemaTypes(schema2001QNames, false);
/*     */     } else {
/* 477 */       if (!paramString.equals("http://www.w3.org/2001/XMLSchema")) {
/* 478 */         System.err.println("WARNING: Unrecognized Schema URI '" + paramString + "' specified.  Defaulting to '" + "http://www.w3.org/2001/XMLSchema" + "'.");
/*     */       }
/*     */ 
/*     */       
/* 482 */       mapSchemaTypes(schema1999QNames, false);
/* 483 */       mapSchemaTypes(schema2000QNames, false);
/* 484 */       arrayOfQName = schema2001QNames;
/*     */     } 
/*     */ 
/*     */     
/* 488 */     mapSchemaTypes(arrayOfQName, true);
/*     */ 
/*     */     
/* 491 */     mapTypes(soapEncURI, RPCConstants.Q_ELEM_PARAMETER, Parameter.class, (Serializer)paramSer, (Deserializer)paramSer);
/*     */ 
/*     */ 
/*     */     
/* 495 */     mapTypes(soapEncURI, arrayQName, null, null, (Deserializer)arraySer);
/*     */ 
/*     */     
/* 498 */     mapTypes("http://xml.apache.org/xml-soap/literalxml", RPCConstants.Q_ELEM_PARAMETER, Parameter.class, (Serializer)xmlParamSer, (Deserializer)xmlParamSer);
/*     */ 
/*     */ 
/*     */     
/* 502 */     try { Class clazz1 = Class.forName("org.apache.soap.util.xml.XMISerializer");
/*     */       
/* 504 */       Class clazz2 = Class.forName("org.apache.soap.encoding.xmi.XMIParameterSerializer");
/*     */ 
/*     */ 
/*     */       
/* 508 */       mapTypes("http://www.ibm.com/namespaces/xmi", null, null, (Serializer)clazz1.newInstance(), (Deserializer)clazz2.newInstance());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 513 */       mapTypes("http://www.ibm.com/namespaces/xmi", null, Parameter.class, (Serializer)clazz2.newInstance(), null); }
/*     */     
/* 515 */     catch (IllegalAccessException illegalAccessException) {  }
/* 516 */     catch (InstantiationException instantiationException) {  }
/* 517 */     catch (ClassNotFoundException classNotFoundException) {  }
/* 518 */     catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 526 */     mapTypes(soapEncURI, new QName("http://xml.apache.org/xml-soap", "Vector"), Vector.class, (Serializer)vectorSer, (Deserializer)vectorSer);
/*     */     
/* 528 */     mapTypes(soapEncURI, new QName("http://xml.apache.org/xml-soap", "Map"), Hashtable.class, (Serializer)hashtableSer, (Deserializer)hashtableSer);
/*     */ 
/*     */ 
/*     */     
/* 532 */     try { Class clazz = Class.forName("java.util.Map");
/* 533 */       MapSerializer mapSerializer = new MapSerializer();
/*     */       
/* 535 */       mapTypes(soapEncURI, new QName("http://xml.apache.org/xml-soap", "Map"), clazz, (Serializer)mapSerializer, (Deserializer)mapSerializer); }
/*     */     
/* 537 */     catch (ClassNotFoundException classNotFoundException) {  }
/* 538 */     catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 545 */     Base64Serializer base64Serializer = new Base64Serializer();
/* 546 */     QName qName = new QName("http://www.w3.org/2001/XMLSchema", "base64Binary");
/* 547 */     mapTypes(soapEncURI, qName, (array$B == null) ? (array$B = class$("[B")) : array$B, (Serializer)base64Serializer, (Deserializer)base64Serializer);
/* 548 */     qName = new QName(soapEncURI, "base64");
/* 549 */     mapTypes(soapEncURI, qName, (array$B == null) ? (array$B = class$("[B")) : array$B, (Serializer)base64Serializer, (Deserializer)base64Serializer);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 554 */     DocumentSerializer documentSerializer = new DocumentSerializer();
/* 555 */     mapTypes(soapEncURI, new QName("http://xmlns.oracle.com/xml-soap", "Document"), Document.class, (Serializer)documentSerializer, (Deserializer)documentSerializer);
/*     */ 
/*     */ 
/*     */     
/* 559 */     DocumentFragmentSerializer documentFragmentSerializer = new DocumentFragmentSerializer();
/* 560 */     mapTypes(soapEncURI, new QName("http://xmlns.oracle.com/xml-soap", "DocumentFragment"), DocumentFragment.class, (Serializer)documentFragmentSerializer, (Deserializer)documentFragmentSerializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mapSchemaTypes(QName[] paramArrayOfQName, boolean paramBoolean) {
/* 574 */     for (byte b = 0; b < paramArrayOfQName.length; b++) {
/* 575 */       QName qName = paramArrayOfQName[b];
/* 576 */       Class clazz = classes[b];
/* 577 */       Serializer serializer = paramBoolean ? serializers[b] : null;
/* 578 */       Deserializer deserializer = deserializers[b];
/*     */       
/* 580 */       mapTypes(soapEncURI, qName, clazz, serializer, deserializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected QName queryElementType_(Class paramClass, String paramString) {
/* 593 */     QName qName = super.queryElementType_(paramClass, paramString);
/* 594 */     if (qName != null) {
/* 595 */       return qName;
/*     */     }
/* 597 */     if (this.parent != null) {
/* 598 */       qName = this.parent.queryElementType_(paramClass, paramString);
/* 599 */       if (qName != null) {
/* 600 */         return qName;
/*     */       }
/*     */     } 
/*     */     
/* 604 */     if (paramClass != null && paramClass.isArray() && paramString != null && paramString.equals(soapEncURI))
/*     */     {
/*     */ 
/*     */       
/* 608 */       return arrayQName;
/*     */     }
/*     */     
/* 611 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Serializer querySerializer_(Class paramClass, String paramString) {
/* 624 */     Serializer serializer = super.querySerializer_(paramClass, paramString);
/* 625 */     if (serializer != null) {
/* 626 */       return serializer;
/*     */     }
/* 628 */     if (this.parent != null) {
/* 629 */       serializer = this.parent.querySerializer_(paramClass, paramString);
/* 630 */       if (serializer != null) {
/* 631 */         return serializer;
/*     */       }
/*     */     } 
/*     */     
/* 635 */     if (paramClass != null && paramString != null && paramString.equals(soapEncURI))
/*     */     {
/*     */       
/* 638 */       if (paramClass.isArray()) {
/* 639 */         return (Serializer)arraySer;
/*     */       }
/*     */     }
/*     */     
/* 643 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Deserializer queryDeserializer_(QName paramQName, String paramString) {
/* 653 */     Deserializer deserializer = super.queryDeserializer_(paramQName, paramString);
/* 654 */     if (deserializer != null) {
/* 655 */       return deserializer;
/*     */     }
/* 657 */     if (this.parent != null) {
/* 658 */       deserializer = this.parent.queryDeserializer_(paramQName, paramString);
/* 659 */       if (deserializer != null) {
/* 660 */         return deserializer;
/*     */       }
/*     */     } 
/* 663 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class queryJavaType_(QName paramQName, String paramString) {
/* 672 */     Class clazz = super.queryJavaType_(paramQName, paramString);
/* 673 */     if (clazz != null) {
/* 674 */       return clazz;
/*     */     }
/* 676 */     if (this.parent != null) {
/* 677 */       clazz = this.parent.queryJavaType_(paramQName, paramString);
/* 678 */       if (clazz != null) {
/* 679 */         return clazz;
/*     */       }
/*     */     } 
/* 682 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\SOAPMappingRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */