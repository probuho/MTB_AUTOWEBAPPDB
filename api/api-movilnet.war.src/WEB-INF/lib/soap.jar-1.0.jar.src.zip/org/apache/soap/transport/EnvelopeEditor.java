package org.apache.soap.transport;

import java.io.Reader;
import java.io.Writer;
import org.apache.soap.SOAPException;

public interface EnvelopeEditor {
  void editIncoming(Reader paramReader, Writer paramWriter) throws SOAPException;
  
  void editOutgoing(Reader paramReader, Writer paramWriter) throws SOAPException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\transport\EnvelopeEditor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */