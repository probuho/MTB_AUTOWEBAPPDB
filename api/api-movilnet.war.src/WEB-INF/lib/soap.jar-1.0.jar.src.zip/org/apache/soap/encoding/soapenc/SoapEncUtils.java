/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.PrefixedName;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoapEncUtils
/*     */ {
/*     */   public static void generateNullStructure(String paramString, Class paramClass, Object paramObject, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry) throws IllegalArgumentException, IOException {
/*  81 */     generateStructureHeader(paramString, paramClass, paramObject, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, (QName)null, (String)null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void generateNullArray(String paramString1, Class paramClass, Object paramObject, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, QName paramQName, String paramString2) throws IllegalArgumentException, IOException {
/*  93 */     generateStructureHeader(paramString1, paramClass, paramObject, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramQName, paramString2, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void generateArrayHeader(String paramString1, Class paramClass, Object paramObject, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, QName paramQName, String paramString2) throws IllegalArgumentException, IOException {
/* 106 */     generateStructureHeader(paramString1, paramClass, paramObject, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramQName, paramString2, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void generateStructureHeader(String paramString, Class paramClass, Object paramObject, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry) throws IllegalArgumentException, IOException {
/* 117 */     generateStructureHeader(paramString, paramClass, paramObject, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, (QName)null, (String)null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void generateStructureHeader(String paramString1, Class paramClass, Object paramObject, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, QName paramQName, String paramString2, boolean paramBoolean) throws IllegalArgumentException, IOException {
/* 130 */     QName qName = paramXMLJavaMappingRegistry.queryElementType(paramClass, "http://schemas.xmlsoap.org/soap/encoding/");
/*     */     
/* 132 */     generateStructureHeader(paramString1, qName, paramObject, paramWriter, paramNSStack, paramXMLJavaMappingRegistry, paramQName, paramString2, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void generateStructureHeader(String paramString1, QName paramQName1, Object paramObject, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, QName paramQName2, String paramString2, boolean paramBoolean) throws IllegalArgumentException, IOException {
/* 146 */     String str1 = "";
/*     */     
/* 148 */     if (paramObject instanceof PrefixedName) {
/*     */       
/* 150 */       PrefixedName prefixedName = (PrefixedName)paramObject;
/* 151 */       QName qName = prefixedName.getQName();
/*     */       
/* 153 */       if (qName != null) {
/*     */         
/* 155 */         String str = qName.getNamespaceURI();
/*     */         
/* 157 */         if (str != null && !str.equals(""))
/*     */         {
/* 159 */           if (prefixedName.getPrefix() == null) {
/*     */             
/* 161 */             String str6 = paramNSStack.getPrefixFromURI(str);
/*     */             
/* 163 */             if (str6 == null) {
/*     */               
/* 165 */               str6 = paramNSStack.addNSDeclaration(str);
/* 166 */               str1 = " xmlns:" + str6 + "=\"" + str + '"';
/*     */             } 
/*     */             
/* 169 */             prefixedName.setPrefix(str6);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 175 */     paramWriter.write('<' + paramObject.toString() + str1);
/*     */ 
/*     */     
/* 178 */     if (paramObject instanceof MultiRefContext) {
/* 179 */       paramWriter.write(" id=\"" + Constants.ATTRVAL_MULTIREF_ID_PREFIX + ((MultiRefContext)paramObject).getId() + "\"");
/*     */     }
/*     */     
/* 182 */     String str2 = paramQName1.getNamespaceURI();
/* 183 */     String str3 = "http://www.w3.org/2001/XMLSchema-instance";
/*     */     
/* 185 */     if (str2.startsWith("http://www.w3.org/") && str2.endsWith("/XMLSchema"))
/*     */     {
/*     */       
/* 188 */       str3 = str2 + "-instance";
/*     */     }
/*     */     
/* 191 */     String str4 = paramNSStack.getPrefixFromURI(str3, paramWriter);
/* 192 */     String str5 = paramNSStack.getPrefixFromURI(str2, paramWriter);
/*     */     
/* 194 */     paramWriter.write(' ' + str4 + ':' + "type" + "=\"" + str5 + ':' + paramQName1.getLocalPart() + '"');
/*     */ 
/*     */ 
/*     */     
/* 198 */     if (paramString1 == null || !paramString1.equals("http://schemas.xmlsoap.org/soap/encoding/")) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       String str = paramNSStack.getPrefixFromURI("http://schemas.xmlsoap.org/soap/envelope/", paramWriter);
/*     */ 
/*     */       
/* 206 */       paramWriter.write(' ' + str + ':' + "encodingStyle" + "=\"" + "http://schemas.xmlsoap.org/soap/encoding/" + '"');
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (paramQName2 != null) {
/*     */       
/* 213 */       String str6 = paramNSStack.getPrefixFromURI(paramQName2.getNamespaceURI(), paramWriter);
/*     */       
/* 215 */       String str7 = str6 + ':' + paramQName2.getLocalPart() + '[' + paramString2 + ']';
/*     */ 
/*     */       
/* 218 */       String str8 = paramNSStack.getPrefixFromURI("http://schemas.xmlsoap.org/soap/encoding/", paramWriter);
/*     */ 
/*     */       
/* 221 */       paramWriter.write(' ' + str8 + ':' + "arrayType" + "=\"" + str7 + '"');
/*     */     } 
/*     */ 
/*     */     
/* 225 */     if (paramBoolean)
/*     */     {
/* 227 */       paramWriter.write(' ' + str4 + ':' + nilName(str3) + "=\"" + Constants.ATTRVAL_TRUE + "\"/");
/*     */     }
/*     */ 
/*     */     
/* 231 */     paramWriter.write(62);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String nilName(String paramString) {
/* 236 */     return paramString.equals("http://www.w3.org/2001/XMLSchema-instance") ? "nil" : "null";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNull(Element paramElement) {
/* 243 */     String str = DOMUtils.getAttributeNS(paramElement, "http://www.w3.org/2001/XMLSchema-instance", "nil");
/*     */ 
/*     */ 
/*     */     
/* 247 */     if (str == null)
/*     */     {
/* 249 */       str = DOMUtils.getAttributeNS(paramElement, "http://www.w3.org/2000/10/XMLSchema-instance", "null");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 254 */     if (str == null)
/*     */     {
/* 256 */       str = DOMUtils.getAttributeNS(paramElement, "http://www.w3.org/1999/XMLSchema-instance", "null");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     if (str == null)
/*     */     {
/* 265 */       str = DOMUtils.getAttributeNS(paramElement, "http://www.w3.org/2001/XMLSchema-instance", "null");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 270 */     return (str != null && decodeBooleanValue(str));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean decodeBooleanValue(String paramString) {
/* 275 */     switch (paramString.charAt(0)) { case '0':
/*     */       case 'F':
/*     */       case 'f':
/* 278 */         return false;
/*     */       case '1': case 'T':
/*     */       case 't':
/* 281 */         return true; }
/*     */ 
/*     */     
/* 284 */     throw new IllegalArgumentException("Invalid boolean value: " + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName getAttributeValue(Element paramElement, String paramString1, String paramString2, String paramString3, boolean paramBoolean) throws IllegalArgumentException {
/* 295 */     String str = DOMUtils.getAttributeNS(paramElement, paramString1, paramString2);
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (str != null) {
/*     */       
/* 301 */       int i = str.indexOf(':');
/*     */       
/* 303 */       if (i != -1) {
/*     */         
/* 305 */         String str1 = str.substring(0, i);
/* 306 */         String str2 = str.substring(i + 1);
/* 307 */         String str3 = DOMUtils.getNamespaceURIFromPrefix(paramElement, str1);
/*     */ 
/*     */         
/* 310 */         if (str3 != null)
/*     */         {
/* 312 */           return new QName(str3, str2);
/*     */         }
/*     */ 
/*     */         
/* 316 */         throw new IllegalArgumentException("Unable to resolve namespace URI for '" + str1 + "'.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 323 */       throw new IllegalArgumentException("The value of the '" + paramString1 + ':' + paramString2 + "' attribute must be " + "namespace-qualified.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 330 */     if (paramBoolean)
/*     */     {
/* 332 */       throw new IllegalArgumentException("The '" + paramString1 + ':' + paramString2 + "' attribute must be " + "specified for every " + paramString3 + '.');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName getTypeQName(Element paramElement) throws IllegalArgumentException {
/* 356 */     QName qName = getAttributeValue(paramElement, "http://www.w3.org/2001/XMLSchema-instance", "type", null, false);
/*     */ 
/*     */     
/* 359 */     if (qName != null) {
/* 360 */       return qName;
/*     */     }
/*     */     
/* 363 */     qName = getAttributeValue(paramElement, "http://www.w3.org/2000/10/XMLSchema-instance", "type", null, false);
/*     */ 
/*     */     
/* 366 */     if (qName != null) {
/* 367 */       return qName;
/*     */     }
/*     */     
/* 370 */     qName = getAttributeValue(paramElement, "http://www.w3.org/1999/XMLSchema-instance", "type", null, false);
/*     */ 
/*     */     
/* 373 */     if (qName != null) {
/* 374 */       return qName;
/*     */     }
/*     */     
/* 377 */     String str = paramElement.getNamespaceURI();
/* 378 */     if (str != null && str.equals("http://schemas.xmlsoap.org/soap/encoding/")) {
/*     */       
/* 380 */       String str1 = paramElement.getLocalName();
/* 381 */       if (str1.equals("Array")) {
/* 382 */         qName = new QName(str, str1);
/*     */       }
/*     */     } 
/* 385 */     return qName;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\SoapEncUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */