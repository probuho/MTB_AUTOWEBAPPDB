/*     */ package org.apache.soap.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.transport.EnvelopeEditor;
/*     */ import org.apache.soap.transport.TransportMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerUtils
/*     */ {
/*     */   public static Envelope readEnvelopeFromInputStream(DocumentBuilder paramDocumentBuilder, InputStream paramInputStream, int paramInt, String paramString, EnvelopeEditor paramEnvelopeEditor, SOAPContext paramSOAPContext) throws SOAPException, IOException, IllegalArgumentException, MessagingException {
/* 105 */     TransportMessage transportMessage = new TransportMessage(paramInputStream, paramInt, paramString, paramSOAPContext, null);
/*     */ 
/*     */ 
/*     */     
/* 109 */     transportMessage.read();
/*     */ 
/*     */     
/* 112 */     MimeBodyPart mimeBodyPart = paramSOAPContext.getRootPart();
/* 113 */     if (!mimeBodyPart.isMimeType("text/xml")) {
/* 114 */       throw new SOAPException(Constants.FAULT_CODE_PROTOCOL, "Unsupported content type \"" + mimeBodyPart.getContentType() + "\", must be: \"" + "text/xml" + "\".");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 119 */     transportMessage.editIncoming(paramEnvelopeEditor);
/*     */     
/* 121 */     return transportMessage.unmarshall(paramDocumentBuilder);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\server\ServerUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */