/*     */ package org.apache.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.StringUtils;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HashtableSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   private static final String STR_KEY = "key";
/*     */   private static final String STR_ITEM = "item";
/*     */   private static final String STR_VALUE = "value";
/*     */   
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  90 */     if (paramObject1 == null) {
/*     */       
/*  92 */       SoapEncUtils.generateNullStructure(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  99 */     else if (paramObject1 instanceof Hashtable) {
/*     */       
/* 101 */       SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 108 */       paramWriter.write(StringUtils.lineSeparator);
/*     */       
/* 110 */       Hashtable hashtable = (Hashtable)paramObject1;
/*     */       
/* 112 */       for (Enumeration enumeration = hashtable.keys(); enumeration.hasMoreElements(); ) {
/*     */         
/* 114 */         Object object = enumeration.nextElement();
/* 115 */         Object object1 = hashtable.get(object);
/*     */         
/* 117 */         paramWriter.write("<item>");
/* 118 */         paramWriter.write(StringUtils.lineSeparator);
/*     */ 
/*     */         
/* 121 */         paramXMLJavaMappingRegistry.marshall("http://schemas.xmlsoap.org/soap/encoding/", object.getClass(), object, "key", paramWriter, paramNSStack, paramSOAPContext);
/*     */         
/* 123 */         paramWriter.write(StringUtils.lineSeparator);
/*     */         
/* 125 */         if (object1 == null) {
/*     */           
/* 127 */           SoapEncUtils.generateNullStructure("http://schemas.xmlsoap.org/soap/encoding/", Object.class, "value", paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 133 */           Class clazz = object1.getClass();
/*     */           
/* 135 */           paramXMLJavaMappingRegistry.marshall("http://schemas.xmlsoap.org/soap/encoding/", clazz, object1, "value", paramWriter, paramNSStack, paramSOAPContext);
/*     */         } 
/*     */ 
/*     */         
/* 139 */         paramWriter.write(StringUtils.lineSeparator);
/* 140 */         paramWriter.write("</item>");
/* 141 */         paramWriter.write(StringUtils.lineSeparator);
/*     */       } 
/*     */       
/* 144 */       paramWriter.write("</" + paramObject2 + '>');
/*     */     }
/*     */     else {
/*     */       
/* 148 */       throw new IllegalArgumentException("Tried to pass a '" + paramObject1.getClass().toString() + "' to HashtableSerializer");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 158 */     Element element1 = (Element)paramNode;
/* 159 */     String str = element1.getTagName();
/*     */     
/* 161 */     if (SoapEncUtils.isNull(element1))
/*     */     {
/* 163 */       return new Bean(Hashtable.class, null);
/*     */     }
/*     */     
/* 166 */     Hashtable hashtable = new Hashtable();
/* 167 */     Element element2 = DOMUtils.getFirstChildElement(element1);
/*     */     
/* 169 */     while (element2 != null) {
/*     */       
/* 171 */       Element element3 = DOMUtils.getFirstChildElement(element2);
/* 172 */       String str1 = element3.getTagName();
/*     */       
/* 174 */       if (!str1.equalsIgnoreCase("key"))
/*     */       {
/* 176 */         throw new IllegalArgumentException("Got <" + str1 + "> tag when expecting <" + "key" + ">");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 181 */       Element element4 = DOMUtils.getNextSiblingElement(element3);
/*     */       
/* 183 */       str1 = element4.getTagName();
/*     */       
/* 185 */       if (!str1.equalsIgnoreCase("value"))
/*     */       {
/* 187 */         throw new IllegalArgumentException("Got <" + str1 + "> tag when expecting <" + "value" + ">");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 192 */       Bean bean1 = unmarshallEl(paramString, paramXMLJavaMappingRegistry, element3, paramSOAPContext);
/* 193 */       Bean bean2 = unmarshallEl(paramString, paramXMLJavaMappingRegistry, element4, paramSOAPContext);
/*     */       
/* 195 */       hashtable.put(bean1.value, bean2.value);
/*     */       
/* 197 */       element2 = DOMUtils.getNextSiblingElement(element2);
/*     */     } 
/*     */     
/* 200 */     return new Bean(Hashtable.class, hashtable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Bean unmarshallEl(String paramString, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, Element paramElement, SOAPContext paramSOAPContext) {
/* 207 */     String str1 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle");
/*     */     
/* 209 */     String str2 = (str1 != null) ? str1 : paramString;
/*     */ 
/*     */     
/* 212 */     QName qName = SoapEncUtils.getTypeQName(paramElement);
/*     */     
/* 214 */     return paramXMLJavaMappingRegistry.unmarshall(str2, qName, paramElement, paramSOAPContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\HashtableSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */