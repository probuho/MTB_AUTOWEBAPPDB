/*     */ package org.apache.soap.util.net;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.mail.MessagingException;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.transport.TransportMessage;
/*     */ import org.apache.soap.util.mime.ByteArrayDataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTTPUtils
/*     */ {
/*     */   private static final String HTTP_VERSION = "1.0";
/*     */   private static final int HTTP_DEFAULT_PORT = 80;
/*     */   private static final int HTTPS_DEFAULT_PORT = 443;
/*     */   public static final int DEFAULT_OUTPUT_BUFFER_SIZE = 512;
/*     */   
/*     */   private static Socket buildSocket(URL paramURL, int paramInt1, String paramString, int paramInt2, Boolean paramBoolean) throws Exception {
/* 102 */     Socket socket = null;
/* 103 */     String str = null;
/* 104 */     int i = paramInt1;
/* 105 */     str = paramURL.getHost();
/*     */     
/* 107 */     if (paramURL.getProtocol().equalsIgnoreCase("HTTPS")) {
/*     */       
/* 109 */       Class clazz = Class.forName("org.apache.soap.util.net.SSLUtils");
/*     */       
/* 111 */       Class[] arrayOfClass = { String.class, int.class, String.class, int.class };
/* 112 */       Method method = clazz.getMethod("buildSSLSocket", arrayOfClass);
/*     */       
/* 114 */       Object[] arrayOfObject = { str, new Integer(i), paramString, new Integer(paramInt2) };
/*     */       
/* 116 */       socket = (Socket)method.invoke(null, arrayOfObject);
/*     */     } else {
/* 118 */       if (paramString != null) {
/* 119 */         str = paramString;
/* 120 */         i = paramInt2;
/*     */       } 
/* 122 */       socket = new Socket(str, i);
/*     */     } 
/*     */     
/* 125 */     if (paramBoolean != null)
/*     */     {
/* 127 */       if (socket != null) {
/* 128 */         socket.setTcpNoDelay(paramBoolean.booleanValue());
/*     */       }
/*     */     }
/* 131 */     return socket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getPort(URL paramURL) throws IOException {
/* 141 */     int i = paramURL.getPort();
/* 142 */     if (i < 0)
/* 143 */       if (paramURL.getProtocol().equalsIgnoreCase("HTTPS")) {
/* 144 */         i = 443;
/*     */       } else {
/* 146 */         i = 80;
/* 147 */       }   return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TransportMessage post(URL paramURL, TransportMessage paramTransportMessage, int paramInt1, String paramString, int paramInt2) throws IllegalArgumentException, IOException, SOAPException {
/* 166 */     return post(paramURL, paramTransportMessage, paramInt1, paramString, paramInt2, 512, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TransportMessage post(URL paramURL, TransportMessage paramTransportMessage, int paramInt1, String paramString, int paramInt2, int paramInt3) throws IllegalArgumentException, IOException, SOAPException {
/* 193 */     return post(paramURL, paramTransportMessage, paramInt1, paramString, paramInt2, paramInt3, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TransportMessage post(URL paramURL, TransportMessage paramTransportMessage, int paramInt1, String paramString, int paramInt2, int paramInt3, Boolean paramBoolean) throws IllegalArgumentException, IOException, SOAPException {
/* 223 */     return post(paramURL, paramTransportMessage, paramInt1, paramString, paramInt2, paramInt3, paramBoolean, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TransportMessage post(URL paramURL, TransportMessage paramTransportMessage, int paramInt1, String paramString, int paramInt2, int paramInt3, Boolean paramBoolean, StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2) throws IllegalArgumentException, IOException, SOAPException {
/*     */     int i;
/*     */     Socket socket;
/*     */     TransportMessage transportMessage;
/* 261 */     OutputStream outputStream = null;
/* 262 */     InputStream inputStream1 = null;
/* 263 */     Object object = null;
/*     */ 
/*     */     
/*     */     try {
/* 267 */       i = getPort(paramURL);
/*     */       
/* 269 */       socket = buildSocket(paramURL, i, paramString, paramInt2, paramBoolean);
/* 270 */       if (paramURL.getProtocol().equalsIgnoreCase("HTTPS"))
/*     */       {
/* 272 */         paramString = null;
/*     */       }
/*     */       
/* 275 */       if (paramInt1 > 0) {
/* 276 */         socket.setSoTimeout(paramInt1);
/*     */       }
/* 278 */       outputStream = socket.getOutputStream();
/* 279 */       inputStream1 = socket.getInputStream();
/*     */     }
/* 281 */     catch (Exception exception) {
/* 282 */       Throwable throwable = exception;
/*     */       
/* 284 */       if (throwable instanceof InvocationTargetException) {
/* 285 */         throwable = ((InvocationTargetException)throwable).getTargetException();
/*     */       }
/*     */       
/* 288 */       throw new IllegalArgumentException("Error opening socket: " + throwable);
/*     */     } 
/*     */ 
/*     */     
/* 292 */     String str1 = (paramString == null) ? paramURL.getFile() : paramURL.toString();
/* 293 */     if (str1.length() == 0) str1 = "/";
/*     */ 
/*     */     
/* 296 */     StringBuffer stringBuffer1 = new StringBuffer();
/* 297 */     stringBuffer1.append("POST").append(' ').append(str1).append(" HTTP/").append("1.0").append("\r\n").append("Host").append(": ").append(paramURL.getHost()).append(':').append(i).append("\r\n").append("Content-Type").append(": ").append(paramTransportMessage.getContentType()).append("\r\n").append("Content-Length").append(": ").append(paramTransportMessage.getContentLength()).append("\r\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     for (Enumeration enumeration = paramTransportMessage.getHeaderNames(); enumeration.hasMoreElements(); ) {
/* 307 */       String str = (String)enumeration.nextElement();
/* 308 */       stringBuffer1.append(str).append(": ").append(paramTransportMessage.getHeader(str)).append("\r\n");
/*     */     } 
/*     */     
/* 311 */     stringBuffer1.append("\r\n");
/*     */ 
/*     */     
/* 314 */     BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(outputStream, paramInt3);
/* 315 */     bufferedOutputStream.write(stringBuffer1.toString().getBytes("iso-8859-1"));
/*     */     
/* 317 */     paramTransportMessage.writeTo(bufferedOutputStream);
/*     */ 
/*     */     
/* 320 */     if (paramStringBuffer1 != null) {
/* 321 */       paramStringBuffer1.append(stringBuffer1).append(new String(paramTransportMessage.getBytes()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     bufferedOutputStream.flush();
/* 328 */     outputStream.flush();
/*     */     
/* 330 */     BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream1);
/*     */     
/* 332 */     int j = 0;
/* 333 */     String str2 = null;
/* 334 */     StringBuffer stringBuffer2 = new StringBuffer();
/* 335 */     int k = 0;
/* 336 */     while (k != 10 && k != -1) {
/* 337 */       k = bufferedInputStream.read();
/* 338 */       if (k != 10 && k != 13 && k != -1)
/* 339 */         stringBuffer2.append((char)k); 
/*     */     } 
/* 341 */     String str3 = stringBuffer2.toString();
/*     */     try {
/* 343 */       StringTokenizer stringTokenizer = new StringTokenizer(str3);
/* 344 */       stringTokenizer.nextToken();
/* 345 */       j = Integer.parseInt(stringTokenizer.nextToken());
/* 346 */       StringBuffer stringBuffer = new StringBuffer();
/* 347 */       while (stringTokenizer.hasMoreTokens()) {
/* 348 */         stringBuffer.append(stringTokenizer.nextToken());
/* 349 */         if (stringTokenizer.hasMoreTokens()) {
/* 350 */           stringBuffer.append(" ");
/*     */         }
/*     */       } 
/* 353 */       str2 = stringBuffer.toString();
/*     */     }
/* 355 */     catch (Exception exception) {
/* 356 */       throw new IllegalArgumentException("Error parsing HTTP status line \"" + str3 + "\": " + exception);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     ByteArrayDataSource byteArrayDataSource = new ByteArrayDataSource(bufferedInputStream, "iso-8859-1");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     byte[] arrayOfByte = byteArrayDataSource.toByteArray();
/* 368 */     Hashtable hashtable = new Hashtable();
/* 369 */     int m = -1;
/* 370 */     String str4 = null;
/* 371 */     StringBuffer stringBuffer3 = new StringBuffer();
/* 372 */     StringBuffer stringBuffer4 = new StringBuffer();
/* 373 */     boolean bool = true;
/*     */     byte b;
/* 375 */     for (b = 0; b < arrayOfByte.length; b++) {
/* 376 */       if (arrayOfByte[b] == 10) {
/* 377 */         if (stringBuffer3.length() == 0)
/*     */           break; 
/* 379 */         String str5 = stringBuffer3.toString();
/*     */ 
/*     */         
/* 382 */         int n = stringBuffer4.length();
/*     */         
/* 384 */         if (n > 0 && stringBuffer4.charAt(n - 1) == ';') {
/* 385 */           stringBuffer4.deleteCharAt(n - 1);
/*     */         }
/*     */         
/* 388 */         String str6 = stringBuffer4.toString();
/* 389 */         if (str5.equalsIgnoreCase("Content-Length")) {
/* 390 */           m = Integer.parseInt(str6);
/* 391 */         } else if (str5.equalsIgnoreCase("Content-Type")) {
/* 392 */           str4 = str6;
/*     */         } else {
/* 394 */           Object object1 = hashtable.put(str5, str6);
/* 395 */           if (object1 != null)
/*     */           {
/*     */             
/* 398 */             if (str5.equalsIgnoreCase("Set-Cookie") || str5.equalsIgnoreCase("Set-Cookie2"))
/*     */             {
/* 400 */               hashtable.put(str5, (String)object1 + "," + str6);
/*     */             }
/*     */           }
/*     */         } 
/* 404 */         stringBuffer3 = new StringBuffer();
/* 405 */         stringBuffer4 = new StringBuffer();
/* 406 */         bool = true;
/*     */       }
/* 408 */       else if (arrayOfByte[b] != 13) {
/* 409 */         if (bool) {
/* 410 */           if (arrayOfByte[b] == 58) {
/* 411 */             bool = false;
/* 412 */             if (b != arrayOfByte.length - 1 && arrayOfByte[b + 1] == 32)
/*     */             {
/* 414 */               b++;
/*     */             }
/*     */           } else {
/* 417 */             stringBuffer3.append((char)arrayOfByte[b]);
/*     */           } 
/*     */         } else {
/* 420 */           stringBuffer4.append((char)arrayOfByte[b]);
/*     */         } 
/*     */       } 
/* 423 */     }  InputStream inputStream2 = byteArrayDataSource.getInputStream();
/* 424 */     inputStream2.skip((b + 1));
/* 425 */     if (m < 0) {
/* 426 */       m = byteArrayDataSource.getSize() - b - 1;
/*     */     }
/*     */     
/* 429 */     if (paramStringBuffer2 != null) {
/* 430 */       paramStringBuffer2.append(str3).append("\r\n").append(new String(arrayOfByte));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 438 */       SOAPContext sOAPContext = new SOAPContext();
/*     */       
/* 440 */       transportMessage = new TransportMessage(inputStream2, m, str4, sOAPContext, hashtable);
/*     */ 
/*     */       
/* 443 */       transportMessage.read();
/* 444 */     } catch (MessagingException messagingException) {
/* 445 */       throw new IllegalArgumentException("Error parsing response: " + messagingException);
/*     */     } 
/*     */ 
/*     */     
/* 449 */     bufferedOutputStream.close();
/* 450 */     outputStream.close();
/* 451 */     bufferedInputStream.close();
/* 452 */     inputStream1.close();
/* 453 */     socket.close();
/* 454 */     return transportMessage;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soa\\util\net\HTTPUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */