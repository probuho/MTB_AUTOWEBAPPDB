/*     */ package org.apache.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AttributeHandler
/*     */ {
/*  74 */   private Hashtable attributes = new Hashtable();
/*  75 */   private Hashtable namespaceURIs2Prefixes = new Hashtable();
/*  76 */   private int nsPrefixIndex = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeHandler() {
/*  81 */     this.namespaceURIs2Prefixes.put("http://www.w3.org/2000/xmlns/", "xmlns");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(QName paramQName, String paramString) {
/*  87 */     this.attributes.put(paramQName, paramString);
/*     */ 
/*     */     
/*  90 */     if (paramQName.getNamespaceURI().equals("http://www.w3.org/2000/xmlns/"))
/*     */     {
/*  92 */       this.namespaceURIs2Prefixes.put(paramString, paramQName.getLocalPart());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(QName paramQName) {
/*  98 */     return (String)this.attributes.get(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAttribute(QName paramQName) {
/* 103 */     this.attributes.remove(paramQName);
/*     */   }
/*     */ 
/*     */   
/*     */   private Enumeration getAttributeQNames() {
/* 108 */     generateNSDeclarations();
/*     */     
/* 110 */     return this.attributes.keys();
/*     */   }
/*     */ 
/*     */   
/*     */   public void declareNamespace(String paramString1, String paramString2) {
/* 115 */     setAttribute(new QName("http://www.w3.org/2000/xmlns/", paramString1), paramString2);
/*     */   }
/*     */ 
/*     */   
/*     */   private void generateNSDeclarations() {
/* 120 */     Enumeration enumeration = this.attributes.keys();
/*     */     
/* 122 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 124 */       QName qName = enumeration.nextElement();
/*     */ 
/*     */       
/* 127 */       getPrefixFromURI(qName.getNamespaceURI());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getPrefixFromURI(String paramString) {
/* 133 */     if ("".equals(paramString)) return null;
/*     */     
/* 135 */     String str = (String)this.namespaceURIs2Prefixes.get(paramString);
/*     */     
/* 137 */     if (str == null) {
/*     */       
/* 139 */       str = "ns" + this.nsPrefixIndex++;
/*     */       
/* 141 */       setAttribute(new QName("http://www.w3.org/2000/xmlns/", str), paramString);
/*     */     } 
/*     */     
/* 144 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public void populateNSStack(NSStack paramNSStack) {
/* 149 */     generateNSDeclarations();
/*     */     
/* 151 */     paramNSStack.pushScope();
/*     */     
/* 153 */     Enumeration enumeration = this.namespaceURIs2Prefixes.keys();
/*     */     
/* 155 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 157 */       String str1 = enumeration.nextElement();
/* 158 */       String str2 = getPrefixFromURI(str1);
/*     */       
/* 160 */       if (str2 != null) {
/* 161 */         paramNSStack.addNSDeclaration(str2, str1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUniquePrefixFromURI(String paramString1, String paramString2, NSStack paramNSStack) {
/* 169 */     String str = paramNSStack.getPrefixFromURI(paramString1);
/*     */     
/* 171 */     if (str == null) {
/*     */       
/* 173 */       byte b = 0;
/*     */       
/* 175 */       if (paramString2 == null) {
/*     */         
/* 177 */         paramString2 = "ns";
/* 178 */         b++;
/*     */       } 
/*     */       
/* 181 */       while (str == null) {
/*     */         
/* 183 */         String str1 = paramString2 + ((b > 0) ? (b + "") : "");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 188 */         if (paramNSStack.getURIFromPrefix(str1) == null) {
/*     */ 
/*     */           
/* 191 */           paramNSStack.popScope();
/* 192 */           declareNamespace(str1, paramString1);
/* 193 */           populateNSStack(paramNSStack);
/* 194 */           str = paramNSStack.getPrefixFromURI(paramString1);
/*     */           
/*     */           continue;
/*     */         } 
/* 198 */         b++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 203 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshall(Writer paramWriter, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 209 */     Enumeration enumeration = getAttributeQNames();
/*     */     
/* 211 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 213 */       QName qName = enumeration.nextElement();
/*     */       
/* 215 */       paramWriter.write(32);
/*     */       String str;
/* 217 */       if ((str = getPrefixFromURI(qName.getNamespaceURI())) != null)
/* 218 */         paramWriter.write(str + ':'); 
/* 219 */       paramWriter.write(qName.getLocalPart() + "=\"" + getAttribute(qName) + '"');
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AttributeHandler unmarshall(Node paramNode, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 227 */     NamedNodeMap namedNodeMap = paramNode.getAttributes();
/* 228 */     AttributeHandler attributeHandler = new AttributeHandler();
/* 229 */     int i = namedNodeMap.getLength();
/*     */     
/* 231 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 233 */       Attr attr = (Attr)namedNodeMap.item(b);
/* 234 */       String str1 = attr.getNamespaceURI();
/* 235 */       String str2 = attr.getLocalName();
/* 236 */       String str3 = attr.getValue();
/*     */       
/* 238 */       attributeHandler.setAttribute(new QName(str1, str2), str3);
/*     */     } 
/*     */     
/* 241 */     return attributeHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 246 */     StringWriter stringWriter = new StringWriter();
/*     */ 
/*     */     
/*     */     try {
/* 250 */       stringWriter.write("{");
/* 251 */       marshall(stringWriter, new SOAPContext());
/* 252 */       stringWriter.write("}");
/*     */     }
/* 254 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 258 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\AttributeHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */