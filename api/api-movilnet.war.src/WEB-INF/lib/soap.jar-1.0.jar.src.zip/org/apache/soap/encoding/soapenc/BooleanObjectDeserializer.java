/*    */ package org.apache.soap.encoding.soapenc;
/*    */ 
/*    */ import org.apache.soap.rpc.SOAPContext;
/*    */ import org.apache.soap.util.Bean;
/*    */ import org.apache.soap.util.xml.DOMUtils;
/*    */ import org.apache.soap.util.xml.Deserializer;
/*    */ import org.apache.soap.util.xml.QName;
/*    */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanObjectDeserializer
/*    */   implements Deserializer
/*    */ {
/*    */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 79 */     Element element = (Element)paramNode;
/* 80 */     String str = DOMUtils.getChildCharacterData(element);
/*    */     
/* 82 */     return new Bean(Boolean.class, new Boolean(str));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\org\apache\soap\encoding\soapenc\BooleanObjectDeserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */