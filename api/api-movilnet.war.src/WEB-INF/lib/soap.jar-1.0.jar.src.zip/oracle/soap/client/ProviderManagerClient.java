/*     */ package oracle.soap.client;
/*     */ 
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.net.URL;
/*     */ import java.util.Vector;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.util.xml.XmlUtils;
/*     */ import org.apache.soap.Fault;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.encoding.soapenc.BeanSerializer;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.Response;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProviderManagerClient
/*     */ {
/*     */   URL routerURL;
/*  31 */   Vector params = new Vector();
/*  32 */   Call call = new Call();
/*     */   
/*     */   public ProviderManagerClient(URL paramURL) {
/*  35 */     BeanSerializer beanSerializer = new BeanSerializer();
/*     */     
/*  37 */     this.routerURL = paramURL;
/*  38 */     SOAPMappingRegistry sOAPMappingRegistry = this.call.getSOAPMappingRegistry();
/*     */ 
/*     */ 
/*     */     
/*  42 */     sOAPMappingRegistry.mapTypes("http://schemas.xmlsoap.org/soap/encoding/", new QName("http://xml.apache.org/xml-soap", "ProviderDeploymentDescriptor"), ProviderDeploymentDescriptor.class, (Serializer)beanSerializer, (Deserializer)beanSerializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Response invokeMethod(String paramString, Parameter paramParameter) throws SOAPException {
/*  50 */     this.call.setTargetObjectURI("urn:soap-provider-manager");
/*  51 */     this.call.setMethodName(paramString);
/*  52 */     this.call.setEncodingStyleURI("http://schemas.xmlsoap.org/soap/encoding/");
/*  53 */     if (paramParameter != null) {
/*  54 */       this.params.removeAllElements();
/*  55 */       this.params.addElement(paramParameter);
/*  56 */       this.call.setParams(this.params);
/*     */     } else {
/*  58 */       this.call.setParams(null);
/*     */     } 
/*  60 */     Response response = this.call.invoke(this.routerURL, "");
/*  61 */     if (response.generatedFault()) {
/*  62 */       Fault fault = response.getFault();
/*  63 */       System.out.println("Ouch, the call failed: ");
/*  64 */       System.out.println("  Fault Code   = " + fault.getFaultCode());
/*  65 */       System.out.println("  Fault String = " + fault.getFaultString());
/*     */     } 
/*  67 */     return response;
/*     */   }
/*     */   
/*     */   public void deploy(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor) throws SOAPException {
/*  71 */     Parameter parameter = new Parameter("descriptor", ProviderDeploymentDescriptor.class, paramProviderDeploymentDescriptor, null);
/*     */     
/*  73 */     invokeMethod("deploy", parameter);
/*     */   }
/*     */   
/*     */   public void undeploy(String paramString) throws SOAPException {
/*  77 */     Parameter parameter = new Parameter("name", String.class, paramString, null);
/*  78 */     invokeMethod("undeploy", parameter);
/*     */   }
/*     */   
/*     */   public String[] list() throws SOAPException {
/*  82 */     Response response = invokeMethod("list", null);
/*  83 */     if (!response.generatedFault()) {
/*  84 */       Parameter parameter = response.getReturnValue();
/*  85 */       return (String[])parameter.getValue();
/*     */     } 
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ProviderDeploymentDescriptor query(String paramString) throws SOAPException {
/*  93 */     Parameter parameter = new Parameter("name", String.class, paramString, null);
/*  94 */     Response response = invokeMethod("query", parameter);
/*  95 */     if (!response.generatedFault()) {
/*  96 */       Parameter parameter1 = response.getReturnValue();
/*  97 */       return (ProviderDeploymentDescriptor)parameter1.getValue();
/*     */     } 
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void badUsage() {
/* 104 */     System.err.println("Usage: java " + ProviderManagerClient.class.getName() + " url operation arguments");
/*     */ 
/*     */     
/* 107 */     System.err.println("where");
/* 108 */     System.err.println("\turl is the XML-SOAP router's URL whose providers are managed");
/*     */     
/* 110 */     System.err.println("\toperation and arguments are:");
/* 111 */     System.err.println("\t\tdeploy provider-descriptor-file.xml");
/* 112 */     System.err.println("\t\tlist");
/* 113 */     System.err.println("\t\tquery provider-name");
/* 114 */     System.err.println("\t\tundeploy provider-name");
/* 115 */     System.exit(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 125 */     if (paramArrayOfString.length < 2) {
/* 126 */       badUsage();
/*     */     }
/*     */     
/* 129 */     ProviderManagerClient providerManagerClient = new ProviderManagerClient(new URL(paramArrayOfString[0]));
/*     */     
/* 131 */     String str = paramArrayOfString[1];
/* 132 */     if (str.equals("deploy")) {
/* 133 */       if (paramArrayOfString.length != 3) {
/* 134 */         badUsage();
/*     */       }
/*     */       
/* 137 */       Document document = null;
/*     */       try {
/* 139 */         document = XmlUtils.parseXml(paramArrayOfString[2]);
/* 140 */       } catch (Exception exception) {
/* 141 */         System.err.println("Error in parsing descriptor file.");
/* 142 */         badUsage();
/*     */       } 
/*     */       
/* 145 */       providerManagerClient.deploy(ProviderDeploymentDescriptor.fromXML(document.getDocumentElement()));
/*     */     }
/* 147 */     else if (str.equals("undeploy")) {
/* 148 */       if (paramArrayOfString.length != 3) {
/* 149 */         badUsage();
/*     */       }
/* 151 */       providerManagerClient.undeploy(paramArrayOfString[2]);
/* 152 */     } else if (str.equals("list")) {
/* 153 */       String[] arrayOfString = providerManagerClient.list();
/* 154 */       if (arrayOfString != null) {
/* 155 */         System.out.println("Deployed Providers:");
/* 156 */         for (byte b = 0; b < arrayOfString.length; b++) {
/* 157 */           System.out.println("\t" + arrayOfString[b]);
/*     */         }
/*     */       } 
/* 160 */     } else if (str.equals("query")) {
/* 161 */       if (paramArrayOfString.length != 3) {
/* 162 */         badUsage();
/*     */       }
/* 164 */       ProviderDeploymentDescriptor providerDeploymentDescriptor = providerManagerClient.query(paramArrayOfString[2]);
/* 165 */       if (providerDeploymentDescriptor != null) {
/* 166 */         providerDeploymentDescriptor.toXML(new OutputStreamWriter(System.out));
/*     */       }
/*     */     } else {
/* 169 */       badUsage();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\client\ProviderManagerClient.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */