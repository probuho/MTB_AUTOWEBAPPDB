/*     */ package oracle.soap.client;
/*     */ 
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.net.URL;
/*     */ import java.util.Vector;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.util.xml.XmlUtils;
/*     */ import org.apache.soap.Fault;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.encoding.soapenc.BeanSerializer;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.Response;
/*     */ import org.apache.soap.server.TypeMapping;
/*     */ import org.apache.soap.server.TypeMappingSerializer;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceManagerClient
/*     */ {
/*     */   URL routerURL;
/*  89 */   Vector params = new Vector();
/*  90 */   Call call = new Call();
/*     */   
/*     */   public ServiceManagerClient(URL paramURL) {
/*  93 */     BeanSerializer beanSerializer = new BeanSerializer();
/*     */     
/*  95 */     this.routerURL = paramURL;
/*  96 */     SOAPMappingRegistry sOAPMappingRegistry = this.call.getSOAPMappingRegistry();
/*     */ 
/*     */ 
/*     */     
/* 100 */     sOAPMappingRegistry.mapTypes("http://schemas.xmlsoap.org/soap/encoding/", new QName("http://xml.apache.org/xml-soap", "ServiceDeploymentDescriptor"), ServiceDeploymentDescriptor.class, (Serializer)beanSerializer, (Deserializer)beanSerializer);
/*     */ 
/*     */ 
/*     */     
/* 104 */     TypeMappingSerializer typeMappingSerializer = new TypeMappingSerializer();
/* 105 */     sOAPMappingRegistry.mapTypes("http://schemas.xmlsoap.org/soap/encoding/", new QName("http://xml.apache.org/xml-soap", "TypeMapping"), TypeMapping.class, (Serializer)typeMappingSerializer, (Deserializer)typeMappingSerializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Response invokeMethod(String paramString, Parameter paramParameter) throws SOAPException {
/* 112 */     this.call.setTargetObjectURI("urn:soap-service-manager");
/* 113 */     this.call.setMethodName(paramString);
/* 114 */     this.call.setEncodingStyleURI("http://schemas.xmlsoap.org/soap/encoding/");
/* 115 */     if (paramParameter != null) {
/* 116 */       this.params.removeAllElements();
/* 117 */       this.params.addElement(paramParameter);
/* 118 */       this.call.setParams(this.params);
/*     */     } else {
/* 120 */       this.call.setParams(null);
/*     */     } 
/* 122 */     Response response = this.call.invoke(this.routerURL, "");
/* 123 */     if (response.generatedFault()) {
/* 124 */       Fault fault = response.getFault();
/* 125 */       System.out.println("Ouch, the call failed: ");
/* 126 */       System.out.println("  Fault Code   = " + fault.getFaultCode());
/* 127 */       System.out.println("  Fault String = " + fault.getFaultString());
/*     */     } 
/* 129 */     return response;
/*     */   }
/*     */   
/*     */   public void deploy(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor) throws SOAPException {
/* 133 */     Parameter parameter = new Parameter("descriptor", ServiceDeploymentDescriptor.class, paramServiceDeploymentDescriptor, null);
/*     */     
/* 135 */     invokeMethod("deploy", parameter);
/*     */   }
/*     */   
/*     */   public void undeploy(String paramString) throws SOAPException {
/* 139 */     Parameter parameter = new Parameter("name", String.class, paramString, null);
/* 140 */     invokeMethod("undeploy", parameter);
/*     */   }
/*     */   
/*     */   public String[] list() throws SOAPException {
/* 144 */     Response response = invokeMethod("list", null);
/* 145 */     if (!response.generatedFault()) {
/* 146 */       Parameter parameter = response.getReturnValue();
/* 147 */       return (String[])parameter.getValue();
/*     */     } 
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String version() throws SOAPException {
/* 155 */     Response response = invokeMethod("version", null);
/* 156 */     if (!response.generatedFault()) {
/*     */       
/* 158 */       Parameter parameter = response.getReturnValue();
/* 159 */       return (String)parameter.getValue();
/*     */     } 
/*     */ 
/*     */     
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceDeploymentDescriptor query(String paramString) throws SOAPException {
/* 170 */     Parameter parameter = new Parameter("name", String.class, paramString, null);
/* 171 */     Response response = invokeMethod("query", parameter);
/* 172 */     if (!response.generatedFault()) {
/* 173 */       Parameter parameter1 = response.getReturnValue();
/* 174 */       return (ServiceDeploymentDescriptor)parameter1.getValue();
/*     */     } 
/* 176 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void badUsage() {
/* 181 */     System.err.println("Usage: java " + ServiceManagerClient.class.getName() + " url operation arguments");
/*     */ 
/*     */     
/* 184 */     System.err.println("where");
/* 185 */     System.err.println("\turl is the XML-SOAP router's URL whose services are managed");
/*     */     
/* 187 */     System.err.println("\toperation and arguments are:");
/* 188 */     System.err.println("\t\tdeploy deployment-descriptor-file.xml");
/* 189 */     System.err.println("\t\tlist");
/* 190 */     System.err.println("\t\tversion");
/* 191 */     System.err.println("\t\tquery service-name");
/* 192 */     System.err.println("\t\tundeploy service-name");
/* 193 */     System.exit(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 203 */     if (paramArrayOfString.length < 2) {
/* 204 */       badUsage();
/*     */     }
/*     */     
/* 207 */     ServiceManagerClient serviceManagerClient = new ServiceManagerClient(new URL(paramArrayOfString[0]));
/*     */     
/* 209 */     String str = paramArrayOfString[1];
/* 210 */     if (str.equals("deploy")) {
/* 211 */       if (paramArrayOfString.length != 3) {
/* 212 */         badUsage();
/*     */       }
/*     */       
/* 215 */       Document document = null;
/*     */       try {
/* 217 */         document = XmlUtils.parseXml(paramArrayOfString[2]);
/* 218 */       } catch (Exception exception) {
/* 219 */         exception.printStackTrace();
/* 220 */         System.err.println("Error in parsing descriptor file.");
/* 221 */         badUsage();
/*     */       } 
/*     */       
/* 224 */       if (document == null) {
/* 225 */         System.err.println("Error in parsing descriptor file.");
/* 226 */         badUsage();
/*     */       } 
/*     */       
/* 229 */       serviceManagerClient.deploy(ServiceDeploymentDescriptor.fromXML(document.getDocumentElement()));
/*     */     }
/* 231 */     else if (str.equals("undeploy")) {
/* 232 */       if (paramArrayOfString.length != 3) {
/* 233 */         badUsage();
/*     */       }
/* 235 */       serviceManagerClient.undeploy(paramArrayOfString[2]);
/* 236 */     } else if (str.equals("list")) {
/* 237 */       String[] arrayOfString = serviceManagerClient.list();
/* 238 */       if (arrayOfString != null) {
/* 239 */         System.out.println("Deployed Services:");
/* 240 */         for (byte b = 0; b < arrayOfString.length; b++) {
/* 241 */           System.out.println("\t" + arrayOfString[b]);
/*     */         }
/*     */       }
/*     */     
/* 245 */     } else if (str.equals("version")) {
/* 246 */       String str1 = serviceManagerClient.version();
/* 247 */       if (str1 != null) {
/* 248 */         System.out.println("Soap Version : " + str1);
/*     */       }
/*     */     }
/* 251 */     else if (str.equals("query")) {
/* 252 */       if (paramArrayOfString.length != 3) {
/* 253 */         badUsage();
/*     */       }
/* 255 */       ServiceDeploymentDescriptor serviceDeploymentDescriptor = serviceManagerClient.query(paramArrayOfString[2]);
/* 256 */       if (serviceDeploymentDescriptor != null) {
/* 257 */         serviceDeploymentDescriptor.toXML(new OutputStreamWriter(System.out));
/*     */       }
/*     */     } else {
/* 260 */       badUsage();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\client\ServiceManagerClient.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */