package oracle.soap.transport;

import java.util.Properties;
import org.apache.soap.transport.SOAPTransport;

public interface OracleSOAPTransport extends SOAPTransport {
  void setProperties(Properties paramProperties);
  
  Properties getProperties();
  
  void close();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\transport\OracleSOAPTransport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */