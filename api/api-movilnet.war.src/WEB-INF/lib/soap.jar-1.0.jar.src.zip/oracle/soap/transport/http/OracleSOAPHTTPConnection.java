/*      */ package oracle.soap.transport.http;
/*      */ 
/*      */ import HTTPClient.AuthorizationInfo;
/*      */ import HTTPClient.Cookie;
/*      */ import HTTPClient.CookieModule;
/*      */ import HTTPClient.CookiePolicyHandler;
/*      */ import HTTPClient.HTTPConnection;
/*      */ import HTTPClient.HTTPResponse;
/*      */ import HTTPClient.ModuleException;
/*      */ import HTTPClient.NVPair;
/*      */ import HTTPClient.RoRequest;
/*      */ import HTTPClient.RoResponse;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.Reader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URL;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.mail.MessagingException;
/*      */ import oracle.net.www.protocol.http.Handler;
/*      */ import oracle.net.www.protocol.http.HttpURLConnection;
/*      */ import oracle.net.www.protocol.https.Handler;
/*      */ import oracle.net.www.protocol.https.HttpsURLConnection;
/*      */ import oracle.security.ssl.OracleSSLCredential;
/*      */ import oracle.soap.transport.OracleSOAPTransport;
/*      */ import org.apache.soap.Constants;
/*      */ import org.apache.soap.Envelope;
/*      */ import org.apache.soap.SOAPException;
/*      */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*      */ import org.apache.soap.rpc.SOAPContext;
/*      */ import org.apache.soap.transport.TransportMessage;
/*      */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleSOAPHTTPConnection
/*      */   implements OracleSOAPTransport
/*      */ {
/*      */   private static boolean s_noHTTPClient = false;
/*      */   public static final String NO_UTF8 = "oracle.soap.transport.1022ContentType";
/*      */   public static final String ALLOW_USER_INTERACTION = "oracle.soap.transport.allowUserInteraction";
/*      */   private static final String STATUS_LINE = "null";
/*      */   public static final String PROXY_HOST = "http.proxyHost";
/*      */   public static final String PROXY_PORT = "http.proxyPort";
/*      */   public static final String PROXY_AUTH_TYPE = "http.proxyAuthType";
/*      */   public static final String PROXY_USERNAME = "http.proxyUsername";
/*      */   public static final String PROXY_PASSWORD = "http.proxyPassword";
/*      */   public static final String AUTH_TYPE = "http.authType";
/*      */   public static final String USERNAME = "http.username";
/*      */   public static final String PASSWORD = "http.password";
/*      */   public static final String REALM = "http.authRealm";
/*      */   public static final String PROXY_REALM = "http.proxyAuthRealm";
/*      */   public static final String WALLET_LOCATION = "oracle.wallet.location";
/*      */   public static final String WALLET_PASSWORD = "oracle.wallet.password";
/*      */   public static final String CIPHERS = "oracle.ssl.ciphers";
/*      */   private BufferedReader m_responseReader;
/*      */   private Hashtable m_responseHeaders;
/*      */   private SOAPContext m_responseSOAPContext;
/*      */   private HttpURLConnection m_urlConn;
/*      */   private HTTPConnection m_httpConn;
/*      */   private Properties m_connProp;
/*      */   
/*      */   static {
/*  105 */     if (System.getProperties().get("oracle.soap.transport.noHTTPClient") != null)
/*      */     {
/*  107 */       s_noHTTPClient = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   private int m_timeout = 0;
/*  179 */   private Boolean m_maintainSession = null;
/*  180 */   private String m_cookieHeader = null;
/*  181 */   private String m_cookieHeader2 = null;
/*  182 */   private int m_outputBufferSize = 512;
/*      */ 
/*      */   
/*      */   private Properties m_requestHeaders;
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleSOAPHTTPConnection() {
/*  190 */     this(System.getProperties());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleSOAPHTTPConnection(Properties paramProperties) {
/*  201 */     this.m_connProp = paramProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProperties(Properties paramProperties) {
/*  211 */     this.m_connProp = paramProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getProperties() {
/*  221 */     return this.m_connProp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserInteraction(boolean paramBoolean) {
/*  231 */     if (!paramBoolean) {
/*  232 */       this.m_connProp.remove("oracle.soap.transport.allowUserInteraction");
/*      */     } else {
/*  234 */       this.m_connProp.put("oracle.soap.transport.allowUserInteraction", "true");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUserInteraction() {
/*  244 */     String str = this.m_connProp.getProperty("oracle.soap.transport.allowUserInteraction");
/*  245 */     if (str == null || !str.equalsIgnoreCase("true"))
/*  246 */       return false; 
/*  247 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyHost(String paramString) {
/*  257 */     if (paramString == null) {
/*  258 */       this.m_connProp.remove("http.proxyHost");
/*      */     } else {
/*  260 */       this.m_connProp.put("http.proxyHost", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProxyHost() {
/*  270 */     return this.m_connProp.getProperty("http.proxyHost");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyPort(int paramInt) {
/*  280 */     if (paramInt <= 0) {
/*  281 */       this.m_connProp.remove("http.proxyPort");
/*      */     } else {
/*  283 */       this.m_connProp.put("http.proxyPort", String.valueOf(paramInt));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getProxyPort() {
/*  293 */     String str = this.m_connProp.getProperty("http.proxyPort");
/*  294 */     if (str == null)
/*  295 */       return -1; 
/*      */     try {
/*  297 */       return Integer.parseInt(str);
/*  298 */     } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */       
/*  301 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAuthType(String paramString) {
/*  309 */     if (paramString == null) {
/*  310 */       this.m_connProp.remove("http.authType");
/*      */     } else {
/*  312 */       this.m_connProp.put("http.authType", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAuthType() {
/*  320 */     return this.m_connProp.getProperty("http.authType");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserName(String paramString) {
/*  328 */     if (paramString == null) {
/*  329 */       this.m_connProp.remove("http.username");
/*      */     } else {
/*  331 */       this.m_connProp.put("http.username", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserName() {
/*  339 */     return this.m_connProp.getProperty("http.username");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPassword(String paramString) {
/*  347 */     if (paramString == null) {
/*  348 */       this.m_connProp.remove("http.password");
/*      */     } else {
/*  350 */       this.m_connProp.put("http.password", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPassword() {
/*  358 */     return this.m_connProp.getProperty("http.password");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRealm(String paramString) {
/*  366 */     if (paramString == null) {
/*  367 */       this.m_connProp.remove("http.authRealm");
/*      */     } else {
/*  369 */       this.m_connProp.put("http.authRealm", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRealm() {
/*  377 */     return this.m_connProp.getProperty("http.authRealm");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyAuthType(String paramString) {
/*  385 */     if (paramString == null) {
/*  386 */       this.m_connProp.remove("http.proxyAuthType");
/*      */     } else {
/*  388 */       this.m_connProp.put("http.proxyAuthType", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProxyAuthType() {
/*  396 */     return this.m_connProp.getProperty("http.proxyAuthType");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyUserName(String paramString) {
/*  404 */     if (paramString == null) {
/*  405 */       this.m_connProp.remove("http.proxyUsername");
/*      */     } else {
/*  407 */       this.m_connProp.put("http.proxyUsername", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProxyUserName() {
/*  415 */     return this.m_connProp.getProperty("http.proxyUsername");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyPassword(String paramString) {
/*  423 */     if (paramString == null) {
/*  424 */       this.m_connProp.remove("http.proxyPassword");
/*      */     } else {
/*  426 */       this.m_connProp.put("http.proxyPassword", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProxyPassword() {
/*  434 */     return this.m_connProp.getProperty("http.proxyPassword");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxyRealm(String paramString) {
/*  442 */     if (paramString == null) {
/*  443 */       this.m_connProp.remove("http.proxyAuthRealm");
/*      */     } else {
/*  445 */       this.m_connProp.put("http.proxyAuthRealm", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProxyRealm() {
/*  453 */     return this.m_connProp.getProperty("http.proxyAuthRealm");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWalletLocation(String paramString) {
/*  461 */     if (paramString == null) {
/*  462 */       this.m_connProp.remove("oracle.wallet.location");
/*      */     } else {
/*  464 */       this.m_connProp.put("oracle.wallet.location", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWalletLocation() {
/*  472 */     return this.m_connProp.getProperty("oracle.wallet.location");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWalletPassword(String paramString) {
/*  480 */     if (paramString == null) {
/*  481 */       this.m_connProp.remove("oracle.wallet.password");
/*      */     } else {
/*  483 */       this.m_connProp.put("oracle.wallet.password", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWalletPassword() {
/*  491 */     return this.m_connProp.getProperty("oracle.wallet.password");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCiphers(String paramString) {
/*  499 */     if (paramString == null) {
/*  500 */       this.m_connProp.remove("oracle.ssl.ciphers");
/*      */     } else {
/*  502 */       this.m_connProp.put("oracle.ssl.ciphers", paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCiphers() {
/*  510 */     return this.m_connProp.getProperty("oracle.ssl.ciphers");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaintainSession(boolean paramBoolean) {
/*  519 */     this.m_maintainSession = new Boolean(paramBoolean);
/*  520 */     if (!paramBoolean) {
/*  521 */       this.m_cookieHeader = null;
/*  522 */       this.m_cookieHeader2 = null;
/*      */     } 
/*      */ 
/*      */     
/*  526 */     if (!s_noHTTPClient)
/*      */     {
/*  528 */       if (paramBoolean) {
/*      */ 
/*      */         
/*  531 */         CookieModule.setCookiePolicyHandler(null);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  536 */         CookieModule.setCookiePolicyHandler(new CookiePolicyHandler(this)
/*      */             {
/*      */               private final OracleSOAPHTTPConnection this$0;
/*      */               
/*      */               public boolean acceptCookie(Cookie param1Cookie, RoRequest param1RoRequest, RoResponse param1RoResponse) {
/*  541 */                 return false;
/*      */               }
/*      */               
/*      */               public boolean sendCookie(Cookie param1Cookie, RoRequest param1RoRequest) {
/*  545 */                 return false;
/*      */               }
/*      */             });
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMaintainSession() {
/*  557 */     if (this.m_maintainSession != null)
/*  558 */       return this.m_maintainSession.booleanValue(); 
/*  559 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeout(int paramInt) {
/*  570 */     if (paramInt < 0) {
/*  571 */       this.m_timeout = 0;
/*      */     } else {
/*  573 */       this.m_timeout = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTimeout() {
/*  583 */     return this.m_timeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOutputBufferSize(int paramInt) {
/*  593 */     if (paramInt > 0) {
/*  594 */       this.m_outputBufferSize = paramInt;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOutputBufferSize() {
/*  604 */     return this.m_outputBufferSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestHeaders(Properties paramProperties) {
/*  623 */     this.m_requestHeaders = paramProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getRequestHeaders() {
/*  637 */     return this.m_requestHeaders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void send(URL paramURL, String paramString, Hashtable paramHashtable, Envelope paramEnvelope, SOAPMappingRegistry paramSOAPMappingRegistry, SOAPContext paramSOAPContext) throws SOAPException {
/*      */     try {
/*      */       TransportMessage transportMessage;
/*  660 */       String str = null;
/*  661 */       if (paramEnvelope != null) {
/*      */         
/*  663 */         StringWriter stringWriter = new StringWriter();
/*  664 */         paramEnvelope.marshall(stringWriter, (XMLJavaMappingRegistry)paramSOAPMappingRegistry, paramSOAPContext);
/*  665 */         str = stringWriter.toString();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  672 */       if (paramHashtable == null) {
/*  673 */         paramHashtable = new Hashtable();
/*  674 */         if (this.m_requestHeaders != null) {
/*      */           
/*  676 */           Enumeration enumeration = this.m_requestHeaders.propertyNames();
/*      */           
/*  678 */           while (enumeration.hasMoreElements()) {
/*      */             
/*  680 */             String str1 = (String)enumeration.nextElement();
/*  681 */             paramHashtable.put(str1, this.m_requestHeaders.getProperty(str1));
/*      */           } 
/*      */         } 
/*      */       } 
/*  685 */       if (s_noHTTPClient && (this.m_maintainSession == null || this.m_maintainSession.booleanValue())) {
/*      */ 
/*      */ 
/*      */         
/*  689 */         if (this.m_cookieHeader2 != null) {
/*  690 */           paramHashtable.put("Cookie2", this.m_cookieHeader2);
/*      */         }
/*  692 */         if (this.m_cookieHeader != null) {
/*  693 */           paramHashtable.put("Cookie", this.m_cookieHeader);
/*      */         }
/*      */       } 
/*      */       
/*  697 */       paramHashtable.put("SOAPAction", (paramString != null) ? ('"' + paramString + '"') : "");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  703 */         TransportMessage transportMessage1 = new TransportMessage(str, paramSOAPContext, paramHashtable);
/*  704 */         transportMessage1.save();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  713 */         transportMessage = post(paramURL, transportMessage1);
/*  714 */       } catch (MessagingException messagingException) {
/*  715 */         throw new IOException("Failed to encode mime multipart: " + messagingException);
/*  716 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  717 */         throw new IOException("Failed to encode mime multipart: " + unsupportedEncodingException);
/*      */       } 
/*      */       
/*  720 */       Reader reader = transportMessage.getEnvelopeReader();
/*  721 */       if (reader != null) {
/*  722 */         this.m_responseReader = new BufferedReader(reader);
/*      */       } else {
/*  724 */         this.m_responseReader = null;
/*  725 */       }  this.m_responseSOAPContext = transportMessage.getSOAPContext();
/*  726 */       this.m_responseHeaders = transportMessage.getHeaders();
/*  727 */       if (s_noHTTPClient && (this.m_maintainSession == null || this.m_maintainSession.booleanValue()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  736 */         String str1 = (String)this.m_responseHeaders.get("set-cookie2");
/*  737 */         if (str1 != null) {
/*  738 */           this.m_cookieHeader2 = str1;
/*  739 */           int i = this.m_cookieHeader2.indexOf(';');
/*  740 */           if (i != -1) {
/*  741 */             this.m_cookieHeader2 = this.m_cookieHeader2.substring(0, i);
/*      */           }
/*      */         } 
/*      */         
/*  745 */         str1 = (String)this.m_responseHeaders.get("set-cookie");
/*  746 */         if (str1 != null) {
/*  747 */           this.m_cookieHeader = str1;
/*  748 */           int i = this.m_cookieHeader.indexOf(';');
/*  749 */           if (i != -1) {
/*  750 */             this.m_cookieHeader = this.m_cookieHeader.substring(0, i);
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  761 */     catch (InterruptedIOException interruptedIOException) {
/*  762 */       throw new SOAPException(Constants.FAULT_CODE_INTERRUPTED_IOEXCEPTION, interruptedIOException.getMessage(), interruptedIOException);
/*      */     }
/*  764 */     catch (IOException iOException) {
/*  765 */       throw new SOAPException(Constants.FAULT_CODE_IOEXCEPTION, iOException.getMessage(), iOException);
/*      */     }
/*  767 */     catch (MessagingException messagingException) {
/*  768 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, messagingException.getMessage(), messagingException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedReader receive() {
/*  783 */     return this.m_responseReader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Hashtable getHeaders() {
/*  795 */     return this.m_responseHeaders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SOAPContext getResponseSOAPContext() {
/*  805 */     return this.m_responseSOAPContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TransportMessage post(URL paramURL, TransportMessage paramTransportMessage) throws IOException, SOAPException {
/*      */     InputStream inputStream;
/*      */     int i;
/*      */     Hashtable hashtable;
/*      */     TransportMessage transportMessage;
/*  826 */     close();
/*  827 */     this.m_responseHeaders = null;
/*  828 */     this.m_responseSOAPContext = null;
/*  829 */     String str = paramTransportMessage.getContentType();
/*      */     
/*  831 */     if (s_noHTTPClient) {
/*      */       
/*  833 */       this.m_urlConn = getConnection(paramURL);
/*  834 */       this.m_urlConn.setTimeout(this.m_timeout);
/*  835 */       this.m_urlConn.setDoOutput(true);
/*  836 */       this.m_urlConn.setRequestMethod("POST");
/*      */ 
/*      */ 
/*      */       
/*  840 */       for (Enumeration enumeration = paramTransportMessage.getHeaderNames(); enumeration.hasMoreElements(); ) {
/*      */         
/*  842 */         String str1 = (String)enumeration.nextElement();
/*  843 */         this.m_urlConn.setRequestProperty(str1.toString(), paramTransportMessage.getHeader(str1));
/*      */       } 
/*      */ 
/*      */       
/*  847 */       this.m_urlConn.setRequestProperty("Content-Length", String.valueOf(paramTransportMessage.getContentLength()));
/*      */       
/*  849 */       if (Boolean.valueOf(this.m_connProp.getProperty("oracle.soap.transport.1022ContentType")).booleanValue() && "text/xml".regionMatches(true, 0, str, 0, 8)) {
/*      */ 
/*      */         
/*  852 */         this.m_urlConn.setRequestProperty("Content-Type", "text/xml");
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  857 */         this.m_urlConn.setRequestProperty("Content-Type", str);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  862 */       BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(this.m_urlConn.getOutputStream(), this.m_outputBufferSize);
/*      */ 
/*      */       
/*  865 */       paramTransportMessage.writeTo(bufferedOutputStream);
/*  866 */       bufferedOutputStream.flush();
/*      */ 
/*      */       
/*  869 */       inputStream = this.m_urlConn.getInputStream();
/*  870 */       i = this.m_urlConn.getContentLength();
/*  871 */       str = this.m_urlConn.getContentType();
/*  872 */       hashtable = this.m_urlConn.getResponseHeaders();
/*      */     } else {
/*      */       HTTPResponse hTTPResponse;
/*      */ 
/*      */       
/*  877 */       this.m_httpConn = getHTTPConnection(paramURL);
/*  878 */       this.m_httpConn.setTimeout(this.m_timeout);
/*      */ 
/*      */       
/*  881 */       NVPair[] arrayOfNVPair = new NVPair[paramTransportMessage.getHeaders().size() + 1];
/*      */       
/*  883 */       byte b = 0;
/*  884 */       for (Enumeration enumeration = paramTransportMessage.getHeaderNames(); enumeration.hasMoreElements(); ) {
/*      */         
/*  886 */         String str2 = enumeration.nextElement();
/*  887 */         arrayOfNVPair[b++] = new NVPair(str2, paramTransportMessage.getHeader(str2));
/*      */       } 
/*  889 */       if (Boolean.valueOf(this.m_connProp.getProperty("oracle.soap.transport.1022ContentType")).booleanValue() && "text/xml".regionMatches(true, 0, str, 0, 8)) {
/*      */ 
/*      */         
/*  892 */         arrayOfNVPair[arrayOfNVPair.length - 1] = new NVPair("Content-Type", "text/xml");
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  897 */         arrayOfNVPair[arrayOfNVPair.length - 1] = new NVPair("Content-Type", str);
/*      */       } 
/*      */       
/*  900 */       String str1 = paramURL.getFile();
/*  901 */       if (paramURL.getRef() != null)
/*  902 */         str1 = str1 + "#" + paramURL.getRef(); 
/*      */       try {
/*  904 */         hTTPResponse = this.m_httpConn.Post(str1, paramTransportMessage.getBytes(), arrayOfNVPair);
/*  905 */       } catch (ModuleException moduleException) {
/*  906 */         throw new IOException("ModuleException thrown by HTTPClient while posting." + moduleException.toString());
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  911 */         inputStream = hTTPResponse.getInputStream();
/*      */         try {
/*  913 */           i = hTTPResponse.getHeaderAsInt("Content-Length");
/*  914 */         } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */ 
/*      */           
/*  918 */           i = -1;
/*      */         } 
/*  920 */         str = hTTPResponse.getHeader("Content-Type");
/*      */ 
/*      */         
/*  923 */         hashtable = new Hashtable();
/*  924 */         for (Enumeration enumeration1 = hTTPResponse.listHeaders(); enumeration1.hasMoreElements(); ) {
/*      */           
/*  926 */           String str2 = enumeration1.nextElement();
/*  927 */           hashtable.put(str2, hTTPResponse.getHeader(str2));
/*      */         } 
/*  929 */       } catch (ModuleException moduleException) {
/*  930 */         throw new IOException("ModuleException thrown by HTTPClient while getting the response." + moduleException.toString());
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  939 */     if (i <= 0) {
/*      */       
/*  941 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  942 */       byte[] arrayOfByte1 = new byte[4096];
/*      */ 
/*      */       
/*      */       while (true) {
/*  946 */         int j = inputStream.read(arrayOfByte1);
/*  947 */         if (j < 0)
/*      */           break; 
/*  949 */         byteArrayOutputStream.write(arrayOfByte1, 0, j);
/*      */       } 
/*  951 */       byte[] arrayOfByte2 = byteArrayOutputStream.toByteArray();
/*  952 */       i = arrayOfByte2.length;
/*  953 */       inputStream = new ByteArrayInputStream(arrayOfByte2);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  960 */       SOAPContext sOAPContext = new SOAPContext();
/*  961 */       transportMessage = new TransportMessage(inputStream, i, str, sOAPContext, hashtable);
/*      */ 
/*      */       
/*  964 */       transportMessage.read();
/*  965 */     } catch (MessagingException messagingException) {
/*  966 */       throw new IOException("Error parsing response: " + messagingException);
/*      */     } 
/*      */     
/*  969 */     return transportMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/*  981 */     if (this.m_urlConn != null)
/*      */     {
/*  983 */       this.m_urlConn.disconnect();
/*      */     }
/*  985 */     if (this.m_httpConn != null)
/*      */     {
/*  987 */       this.m_httpConn.stop();
/*      */     }
/*  989 */     this.m_urlConn = null;
/*  990 */     if (this.m_responseReader != null) {
/*      */       
/*      */       try {
/*  993 */         this.m_responseReader.close();
/*  994 */       } catch (IOException iOException) {}
/*      */ 
/*      */       
/*  997 */       this.m_responseReader = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpURLConnection getConnection(URL paramURL) throws IllegalArgumentException, IOException {
/*      */     HttpsURLConnection httpsURLConnection;
/* 1008 */     String str1 = this.m_connProp.getProperty("http.proxyHost");
/*      */     
/* 1010 */     String str2 = this.m_connProp.getProperty("http.proxyPort");
/* 1011 */     if (str2 == null) {
/* 1012 */       str2 = "80";
/*      */     }
/*      */     
/* 1015 */     if (paramURL.getProtocol().equalsIgnoreCase("http")) {
/*      */       Handler handler;
/*      */       
/* 1018 */       if (str1 != null) {
/* 1019 */         handler = new Handler(str1, Integer.parseInt(str2));
/*      */       } else {
/* 1021 */         handler = new Handler();
/* 1022 */       }  HttpURLConnection httpURLConnection = new HttpURLConnection(paramURL, handler);
/*      */     }
/* 1024 */     else if (paramURL.getProtocol().equalsIgnoreCase("https")) {
/*      */       Handler handler;
/*      */       
/* 1027 */       if (str1 != null) {
/* 1028 */         handler = new Handler(str1, Integer.parseInt(str2));
/*      */       } else {
/*      */         
/* 1031 */         handler = new Handler();
/* 1032 */       }  httpsURLConnection = new HttpsURLConnection(paramURL, handler);
/*      */     } else {
/*      */       
/* 1035 */       throw new IllegalArgumentException("Unknown protocol. Currently only http and https protocols are supported");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1040 */     String str3 = this.m_connProp.getProperty("oracle.soap.transport.allowUserInteraction");
/* 1041 */     if (str3 != null && str3.equalsIgnoreCase("true")) {
/* 1042 */       httpsURLConnection.setAllowUserInteraction(true);
/*      */     }
/*      */     
/* 1045 */     str3 = this.m_connProp.getProperty("http.proxyAuthType");
/* 1046 */     if (str3 != null) {
/* 1047 */       httpsURLConnection.setProxyAuthType(str3);
/*      */     }
/*      */     
/* 1050 */     str3 = this.m_connProp.getProperty("http.proxyUsername");
/* 1051 */     if (str3 != null) {
/* 1052 */       httpsURLConnection.setProxyUsername(str3);
/*      */     }
/*      */     
/* 1055 */     str3 = this.m_connProp.getProperty("http.proxyPassword");
/* 1056 */     if (str3 != null) {
/* 1057 */       httpsURLConnection.setProxyPassword(str3);
/*      */     }
/*      */     
/* 1060 */     str3 = this.m_connProp.getProperty("http.authType");
/* 1061 */     if (str3 != null) {
/* 1062 */       httpsURLConnection.setHttpAuthType(str3);
/*      */     }
/*      */     
/* 1065 */     str3 = this.m_connProp.getProperty("http.username");
/* 1066 */     if (str3 != null) {
/* 1067 */       httpsURLConnection.setHttpUsername(str3);
/*      */     }
/*      */     
/* 1070 */     str3 = this.m_connProp.getProperty("http.password");
/* 1071 */     if (str3 != null) {
/* 1072 */       httpsURLConnection.setHttpPassword(str3);
/*      */     }
/* 1074 */     if (httpsURLConnection instanceof HttpsURLConnection) {
/*      */ 
/*      */       
/* 1077 */       str3 = this.m_connProp.getProperty("oracle.wallet.location");
/* 1078 */       if (str3 != null)
/*      */       {
/* 1080 */         httpsURLConnection.setWallet(str3, this.m_connProp.getProperty("oracle.wallet.password"));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1085 */       str3 = this.m_connProp.getProperty("oracle.ssl.ciphers");
/* 1086 */       if (str3 != null)
/*      */       {
/* 1088 */         httpsURLConnection.setCipherSuites(str3);
/*      */       }
/*      */     } 
/*      */     
/* 1092 */     return (HttpURLConnection)httpsURLConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HTTPConnection getHTTPConnection(URL paramURL) throws IllegalArgumentException, IOException {
/* 1099 */     String str2 = "80";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1105 */     String str1 = this.m_connProp.getProperty("http.proxyHost");
/* 1106 */     if (str1 != null) {
/*      */ 
/*      */       
/* 1109 */       str2 = this.m_connProp.getProperty("http.proxyPort");
/* 1110 */       if (str2 == null)
/* 1111 */         str2 = "80"; 
/*      */       try {
/* 1113 */         HTTPConnection.setProxyServer(str1, Integer.parseInt(str2));
/* 1114 */       } catch (NumberFormatException numberFormatException) {
/* 1115 */         throw new IllegalArgumentException("http.proxyPort must be set to a integer value. Value set is '" + str2 + "'");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1121 */     String str12 = paramURL.getProtocol();
/* 1122 */     HTTPConnection hTTPConnection = new HTTPConnection(str12, paramURL.getHost(), paramURL.getPort());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1127 */     hTTPConnection.setContext(this);
/*      */ 
/*      */     
/* 1130 */     String str11 = this.m_connProp.getProperty("oracle.soap.transport.allowUserInteraction");
/* 1131 */     if (str11 != null && str11.equalsIgnoreCase("true")) {
/* 1132 */       hTTPConnection.setAllowUserInteraction(true);
/*      */     } else {
/* 1134 */       hTTPConnection.setAllowUserInteraction(false);
/*      */     } 
/*      */     
/* 1137 */     String str3 = this.m_connProp.getProperty("http.proxyAuthType");
/*      */ 
/*      */     
/* 1140 */     String str4 = this.m_connProp.getProperty("http.proxyUsername");
/*      */ 
/*      */     
/* 1143 */     String str5 = this.m_connProp.getProperty("http.proxyPassword");
/*      */ 
/*      */     
/* 1146 */     String str6 = this.m_connProp.getProperty("http.proxyAuthRealm");
/*      */ 
/*      */     
/* 1149 */     String str7 = this.m_connProp.getProperty("http.authType");
/*      */ 
/*      */     
/* 1152 */     String str8 = this.m_connProp.getProperty("http.username");
/*      */ 
/*      */     
/* 1155 */     String str9 = this.m_connProp.getProperty("http.password");
/*      */ 
/*      */     
/* 1158 */     String str10 = this.m_connProp.getProperty("http.authRealm");
/*      */ 
/*      */     
/* 1161 */     if (str1 != null && str6 != null && str4 != null && str5 != null && str3 != null)
/*      */     {
/*      */       
/* 1164 */       if (str3.equalsIgnoreCase("basic")) {
/* 1165 */         AuthorizationInfo.addBasicAuthorization(str1, Integer.parseInt(str2), str6, str4, str5);
/*      */       
/*      */       }
/* 1168 */       else if (str3.equalsIgnoreCase("digest")) {
/* 1169 */         AuthorizationInfo.addDigestAuthorization(str1, Integer.parseInt(str2), str6, str4, str5);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1175 */     if (str10 != null && str8 != null && str9 != null && str7 != null)
/*      */     {
/*      */       
/* 1178 */       if (str7.equalsIgnoreCase("basic")) {
/* 1179 */         hTTPConnection.addBasicAuthorization(str10, str8, str9);
/* 1180 */       } else if (str7.equalsIgnoreCase("digest")) {
/* 1181 */         hTTPConnection.addDigestAuthorization(str10, str8, str9);
/*      */       } 
/*      */     }
/* 1184 */     if (str12 != null && str12.equalsIgnoreCase("https")) {
/*      */ 
/*      */       
/* 1187 */       str11 = this.m_connProp.getProperty("oracle.wallet.location");
/* 1188 */       if (str11 != null) {
/*      */         
/* 1190 */         ckWltLoc(str11);
/* 1191 */         OracleSSLCredential oracleSSLCredential = new OracleSSLCredential();
/* 1192 */         oracleSSLCredential.setWallet(str11, this.m_connProp.getProperty("oracle.wallet.password"));
/*      */         
/* 1194 */         hTTPConnection.setSSLCredential(oracleSSLCredential);
/*      */       } 
/*      */ 
/*      */       
/* 1198 */       str11 = this.m_connProp.getProperty("oracle.ssl.ciphers");
/* 1199 */       if (str11 != null)
/*      */       {
/* 1201 */         hTTPConnection.setSSLEnabledCipherSuites(parseCiphers(str11));
/*      */       }
/*      */     } 
/* 1204 */     return hTTPConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void ckWltLoc(String paramString) throws IOException {
/* 1210 */     File file = new File(paramString);
/*      */     
/* 1212 */     if (!file.exists()) {
/* 1213 */       throw new IOException("The wallet \"" + paramString + "\" does not exist.");
/*      */     }
/* 1215 */     if (!file.canRead()) {
/* 1216 */       throw new IOException("The wallet \"" + paramString + "\" cannot be read.");
/*      */     }
/* 1218 */     if (!file.isFile()) {
/* 1219 */       throw new IOException("The wallet \"" + paramString + "\" is not a 'normal' file.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] parseCiphers(String paramString) {
/* 1227 */     if (paramString == null || paramString.equals("")) {
/* 1228 */       return null;
/*      */     }
/* 1230 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ":");
/* 1231 */     String[] arrayOfString = new String[stringTokenizer.countTokens()];
/* 1232 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 1233 */       arrayOfString[b] = stringTokenizer.nextToken();
/*      */     }
/* 1235 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() throws Throwable {
/*      */     try {
/* 1242 */       close();
/*      */     } finally {
/* 1244 */       super.finalize();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\transport\http\OracleSOAPHTTPConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */