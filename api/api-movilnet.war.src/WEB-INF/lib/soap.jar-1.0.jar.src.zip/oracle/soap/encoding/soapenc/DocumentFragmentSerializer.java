/*    */ package oracle.soap.encoding.soapenc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import java.util.Vector;
/*    */ import org.apache.soap.Utils;
/*    */ import org.apache.soap.encoding.soapenc.SoapEncUtils;
/*    */ import org.apache.soap.rpc.SOAPContext;
/*    */ import org.apache.soap.util.Bean;
/*    */ import org.apache.soap.util.xml.Deserializer;
/*    */ import org.apache.soap.util.xml.NSStack;
/*    */ import org.apache.soap.util.xml.QName;
/*    */ import org.apache.soap.util.xml.Serializer;
/*    */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*    */ import org.w3c.dom.DocumentFragment;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentFragmentSerializer
/*    */   implements Serializer, Deserializer
/*    */ {
/*    */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 30 */     if (paramObject1 == null) {
/* 31 */       SoapEncUtils.generateNullStructure(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 36 */     SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 41 */     DocumentFragment documentFragment = (DocumentFragment)paramObject1;
/*    */     
/* 43 */     NodeList nodeList = documentFragment.getChildNodes();
/* 44 */     for (byte b = 0; b < nodeList.getLength(); b++) {
/* 45 */       Node node = nodeList.item(b);
/* 46 */       Utils.marshallNode(node, paramWriter);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 57 */     paramWriter.write("</" + paramObject2 + '>');
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/* 65 */     Element element = (Element)paramNode;
/*    */     
/* 67 */     if (SoapEncUtils.isNull(element)) {
/* 68 */       return new Bean(DocumentFragment.class, null);
/*    */     }
/* 70 */     DocumentFragment documentFragment = element.getOwnerDocument().createDocumentFragment();
/* 71 */     NodeList nodeList = element.getChildNodes();
/*    */     
/* 73 */     Vector vector = new Vector();
/*    */     byte b;
/* 75 */     for (b = 0; b < nodeList.getLength(); b++) {
/* 76 */       Node node = nodeList.item(b);
/* 77 */       vector.add(node);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 89 */     for (b = 0; b < vector.size(); b++) {
/* 90 */       documentFragment.appendChild(vector.elementAt(b));
/*    */     }
/* 92 */     return new Bean(DocumentFragment.class, documentFragment);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\encoding\soapenc\DocumentFragmentSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */