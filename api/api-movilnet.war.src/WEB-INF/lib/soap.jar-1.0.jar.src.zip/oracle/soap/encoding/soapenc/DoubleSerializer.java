/*    */ package oracle.soap.encoding.soapenc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.apache.soap.encoding.soapenc.SoapEncUtils;
/*    */ import org.apache.soap.rpc.SOAPContext;
/*    */ import org.apache.soap.util.xml.NSStack;
/*    */ import org.apache.soap.util.xml.Serializer;
/*    */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleSerializer
/*    */   implements Serializer
/*    */ {
/* 25 */   public static final Double POSITIVE_INFINITY = new Double(Double.POSITIVE_INFINITY);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/* 32 */     paramNSStack.pushScope();
/*    */     
/* 34 */     SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 41 */     Double double_ = (Double)paramObject1;
/* 42 */     String str = null;
/*    */     
/* 44 */     if (double_.isNaN()) {
/*    */       
/* 46 */       str = "NaN";
/*    */     }
/* 48 */     else if (double_.isInfinite()) {
/*    */       
/* 50 */       if (double_.compareTo(POSITIVE_INFINITY) == 0) {
/*    */         
/* 52 */         str = "INF";
/*    */       } else {
/*    */         
/* 55 */         str = "-INF";
/*    */       } 
/*    */     } else {
/* 58 */       str = double_.toString();
/*    */     } 
/*    */     
/* 61 */     paramWriter.write(str + "</" + paramObject2 + '>');
/*    */     
/* 63 */     paramNSStack.popScope();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\encoding\soapenc\DoubleSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */