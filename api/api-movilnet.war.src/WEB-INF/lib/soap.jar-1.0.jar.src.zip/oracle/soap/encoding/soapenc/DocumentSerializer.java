/*     */ package oracle.soap.encoding.soapenc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.apache.soap.Utils;
/*     */ import org.apache.soap.encoding.soapenc.SoapEncUtils;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.xml.Deserializer;
/*     */ import org.apache.soap.util.xml.NSStack;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ import org.apache.soap.util.xml.Serializer;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentSerializer
/*     */   implements Serializer, Deserializer
/*     */ {
/*     */   public void marshall(String paramString, Class paramClass, Object paramObject1, Object paramObject2, Writer paramWriter, NSStack paramNSStack, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException, IOException {
/*  30 */     if (paramObject1 == null) {
/*  31 */       SoapEncUtils.generateNullStructure(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  36 */     SoapEncUtils.generateStructureHeader(paramString, paramClass, paramObject2, paramWriter, paramNSStack, paramXMLJavaMappingRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  41 */     Document document = (Document)paramObject1;
/*  42 */     NodeList nodeList = document.getChildNodes();
/*  43 */     for (byte b = 0; b < nodeList.getLength(); b++) {
/*  44 */       Node node = nodeList.item(b);
/*  45 */       Utils.marshallNode(node, paramWriter);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     paramWriter.write("</" + paramObject2 + '>');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean unmarshall(String paramString, QName paramQName, Node paramNode, XMLJavaMappingRegistry paramXMLJavaMappingRegistry, SOAPContext paramSOAPContext) throws IllegalArgumentException {
/*  65 */     Element element = (Element)paramNode;
/*     */     
/*  67 */     if (SoapEncUtils.isNull(element)) {
/*  68 */       return new Bean(Document.class, null);
/*     */     }
/*     */ 
/*     */     
/*  72 */     Document document1 = element.getOwnerDocument();
/*     */     
/*  74 */     StringWriter stringWriter = new StringWriter();
/*     */     
/*  76 */     NodeList nodeList = element.getChildNodes();
/*  77 */     for (byte b = 0; b < nodeList.getLength(); b++) {
/*  78 */       Node node = nodeList.item(b);
/*  79 */       Utils.marshallNode(node, stringWriter);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     stringWriter.flush();
/*     */     
/*  93 */     DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*  94 */     Document document2 = null;
/*     */     try {
/*  96 */       document2 = documentBuilder.parse(new ByteArrayInputStream(stringWriter.toString().getBytes()));
/*  97 */     } catch (Exception exception) {
/*  98 */       throw new IllegalArgumentException(exception.getClass().getName() + " " + exception.getMessage());
/*     */     } 
/*     */     
/* 101 */     return new Bean(Document.class, document2);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\encoding\soapenc\DocumentSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */