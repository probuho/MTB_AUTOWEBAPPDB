/*     */ package oracle.soap.encoding.soapenc;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncUtils
/*     */ {
/*     */   public static Object[] mapArrayInbuiltToWrapper(Class paramClass, Object paramObject) {
/*  56 */     if (paramClass == null || paramObject == null) {
/*  57 */       return null;
/*     */     }
/*  59 */     Byte[] arrayOfByte = null;
/*     */     
/*  61 */     Class clazz1 = paramClass.getComponentType();
/*  62 */     Class clazz2 = paramObject.getClass().getComponentType();
/*     */ 
/*     */     
/*  65 */     if (clazz1 == null || clazz2 == null) {
/*  66 */       return null;
/*     */     }
/*     */     
/*  69 */     if (clazz1.getComponentType() != null || clazz2.getComponentType() != null)
/*     */     {
/*  71 */       return null;
/*     */     }
/*  73 */     int i = Array.getLength(paramObject);
/*  74 */     if (clazz1.equals(Byte.class) && clazz2.equals(byte.class)) {
/*     */ 
/*     */       
/*  77 */       arrayOfByte = (Byte[])Array.newInstance(Byte.class, i);
/*  78 */       for (byte b = 0; b < i; b++)
/*     */       {
/*  80 */         arrayOfByte[b] = new Byte(((byte[])paramObject)[b]);
/*     */       }
/*     */     }
/*  83 */     else if (clazz1.equals(Character.class) && clazz2.equals(char.class)) {
/*     */ 
/*     */       
/*  86 */       Character[] arrayOfCharacter = (Character[])Array.newInstance(Character.class, i);
/*  87 */       for (byte b = 0; b < i; b++)
/*     */       {
/*  89 */         arrayOfCharacter[b] = new Character(((char[])paramObject)[b]);
/*     */       }
/*     */     }
/*  92 */     else if (clazz1.equals(Boolean.class) && clazz2.equals(boolean.class)) {
/*     */ 
/*     */       
/*  95 */       Boolean[] arrayOfBoolean = (Boolean[])Array.newInstance(Boolean.class, i);
/*  96 */       for (byte b = 0; b < i; b++)
/*     */       {
/*  98 */         arrayOfBoolean[b] = new Boolean(((boolean[])paramObject)[b]);
/*     */       }
/*     */     }
/* 101 */     else if (clazz1.equals(Short.class) && clazz2.equals(short.class)) {
/*     */ 
/*     */       
/* 104 */       Short[] arrayOfShort = (Short[])Array.newInstance(Short.class, i);
/* 105 */       for (byte b = 0; b < i; b++)
/*     */       {
/* 107 */         arrayOfShort[b] = new Short(((short[])paramObject)[b]);
/*     */       }
/*     */     }
/* 110 */     else if (clazz1.equals(Integer.class) && clazz2.equals(int.class)) {
/*     */ 
/*     */       
/* 113 */       Integer[] arrayOfInteger = (Integer[])Array.newInstance(Integer.class, i);
/* 114 */       for (byte b = 0; b < i; b++)
/*     */       {
/* 116 */         arrayOfInteger[b] = new Integer(((int[])paramObject)[b]);
/*     */       }
/*     */     }
/* 119 */     else if (clazz1.equals(Long.class) && clazz2.equals(long.class)) {
/*     */ 
/*     */       
/* 122 */       Long[] arrayOfLong = (Long[])Array.newInstance(Long.class, i);
/* 123 */       for (byte b = 0; b < i; b++)
/*     */       {
/* 125 */         arrayOfLong[b] = new Long(((long[])paramObject)[b]);
/*     */       }
/*     */     }
/* 128 */     else if (clazz1.equals(Float.class) && clazz2.equals(float.class)) {
/*     */ 
/*     */       
/* 131 */       Float[] arrayOfFloat = (Float[])Array.newInstance(Float.class, i);
/* 132 */       for (byte b = 0; b < i; b++)
/*     */       {
/* 134 */         arrayOfFloat[b] = new Float(((float[])paramObject)[b]);
/*     */       }
/*     */     }
/* 137 */     else if (clazz1.equals(Double.class) && clazz2.equals(double.class)) {
/*     */ 
/*     */       
/* 140 */       Double[] arrayOfDouble = (Double[])Array.newInstance(Double.class, i);
/* 141 */       for (byte b = 0; b < i; b++)
/*     */       {
/* 143 */         arrayOfDouble[b] = new Double(((double[])paramObject)[b]);
/*     */       }
/*     */     } else {
/*     */       
/* 147 */       arrayOfByte = null;
/*     */     } 
/* 149 */     return (Object[])arrayOfByte;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\encoding\soapenc\EncUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */