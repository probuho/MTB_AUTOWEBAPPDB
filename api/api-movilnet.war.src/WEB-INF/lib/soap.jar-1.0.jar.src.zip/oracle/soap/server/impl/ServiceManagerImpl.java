/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import oracle.soap.server.ConfigManager;
/*     */ import oracle.soap.server.DeploymentDescriptor;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.ProviderManager;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.server.ServiceManager;
/*     */ import oracle.soap.server.VersionInfo;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.server.TypeMapping;
/*     */ import org.apache.soap.util.xml.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceManagerImpl
/*     */   implements ServiceManager
/*     */ {
/*     */   public static final String DEFAULT_CONFIG_MANAGER = "oracle.soap.server.impl.XMLServiceConfigManager";
/*     */   public static final String OPTION_REQUIRED_REQUEST_URI = "requiredRequestURI";
/*     */   public static final String OPTION_AUTO_DEPLOY = "autoDeploy";
/*  71 */   private ServiceDeploymentDescriptor m_smsdd = null;
/*  72 */   private ServiceDeploymentDescriptor m_pmsdd = null;
/*  73 */   private String m_requiredRequestURI = null;
/*  74 */   private ProviderManager m_providerManager = null;
/*  75 */   private ServletContext m_context = null;
/*  76 */   private ConfigManager m_configManager = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultConfigManagerClassname() {
/*  89 */     return "oracle.soap.server.impl.XMLServiceConfigManager";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Properties paramProperties, ProviderManager paramProviderManager, ServletContext paramServletContext, ConfigManager paramConfigManager) throws SOAPException {
/* 124 */     boolean bool = false;
/*     */     
/* 126 */     this.m_context = paramServletContext;
/* 127 */     this.m_providerManager = paramProviderManager;
/* 128 */     this.m_configManager = paramConfigManager;
/* 129 */     this.m_requiredRequestURI = paramProperties.getProperty("requiredRequestURI");
/*     */     
/* 131 */     String str = paramProperties.getProperty("autoDeploy");
/*     */     
/* 133 */     if (!ServerUtils.isNull(str))
/*     */     {
/* 135 */       bool = (new Boolean(str)).booleanValue();
/*     */     }
/*     */ 
/*     */     
/* 139 */     if (ServerUtils.isNull(this.m_requiredRequestURI)) {
/* 140 */       this.m_requiredRequestURI = null;
/*     */     }
/* 142 */     String[] arrayOfString = null;
/* 143 */     Object object = null;
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (bool) {
/*     */       
/* 149 */       this.m_smsdd = new ServiceDeploymentDescriptor();
/* 150 */       this.m_smsdd.setId("urn:soap-service-manager");
/* 151 */       this.m_smsdd.setServiceType(0);
/*     */       
/* 153 */       arrayOfString = new String[] { "deploy", "undeploy", "list", "query", "version" };
/* 154 */       this.m_smsdd.setMethods(arrayOfString);
/*     */       
/* 156 */       this.m_smsdd.setProviderId("java-provider");
/* 157 */       this.m_smsdd.setScope(2);
/* 158 */       this.m_smsdd.setServiceClass("oracle.soap.server.impl.ServiceManagerImpl");
/* 159 */       this.m_smsdd.setIsStatic(false);
/*     */       
/* 161 */       this.m_smsdd.setTypeMappings(new TypeMapping[] { new TypeMapping("http://schemas.xmlsoap.org/soap/encoding/", new QName("http://xml.apache.org/xml-soap", "ServiceDeploymentDescriptor"), "oracle.soap.server.ServiceDeploymentDescriptor", "org.apache.soap.encoding.soapenc.BeanSerializer", "org.apache.soap.encoding.soapenc.BeanSerializer"), new TypeMapping("http://schemas.xmlsoap.org/soap/encoding/", new QName("http://xml.apache.org/xml-soap", "TypeMapping"), "org.apache.soap.server.TypeMapping", "org.apache.soap.server.TypeMappingSerializer", "org.apache.soap.server.TypeMappingSerializer") });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       this.m_pmsdd = new ServiceDeploymentDescriptor();
/* 178 */       this.m_pmsdd.setId("urn:soap-provider-manager");
/* 179 */       this.m_pmsdd.setServiceType(0);
/*     */       
/* 181 */       arrayOfString = new String[] { "deploy", "undeploy", "list", "query" };
/* 182 */       this.m_pmsdd.setMethods(arrayOfString);
/*     */       
/* 184 */       this.m_pmsdd.setProviderId("java-provider");
/* 185 */       this.m_pmsdd.setScope(2);
/* 186 */       this.m_pmsdd.setServiceClass("oracle.soap.server.impl.ProviderManagerImpl");
/* 187 */       this.m_pmsdd.setIsStatic(false);
/*     */       
/* 189 */       this.m_pmsdd.setTypeMappings(new TypeMapping[] { new TypeMapping("http://schemas.xmlsoap.org/soap/encoding/", new QName("http://xml.apache.org/xml-soap", "ProviderDeploymentDescriptor"), "oracle.soap.server.ProviderDeploymentDescriptor", "org.apache.soap.encoding.soapenc.BeanSerializer", "org.apache.soap.encoding.soapenc.BeanSerializer") });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws SOAPException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequiredRequestURI() {
/* 228 */     return this.m_requiredRequestURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceDeploymentDescriptor undeploy(String paramString) throws SOAPException {
/* 250 */     if (paramString.equals("urn:soap-service-manager"))
/*     */     {
/*     */       
/* 253 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + paramString + "' may not be undeployed");
/*     */     }
/*     */ 
/*     */     
/* 257 */     if (paramString.equals("urn:soap-provider-manager"))
/*     */     {
/*     */       
/* 260 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + paramString + "' may not be undeployed");
/*     */     }
/*     */ 
/*     */     
/* 264 */     ServiceDeploymentDescriptor serviceDeploymentDescriptor = (ServiceDeploymentDescriptor)this.m_configManager.undeploy(paramString);
/*     */ 
/*     */     
/* 267 */     if (serviceDeploymentDescriptor == null)
/*     */     {
/* 269 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + paramString + "' is unknown");
/*     */     }
/*     */ 
/*     */     
/* 273 */     return serviceDeploymentDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deploy(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor) throws SOAPException {
/* 291 */     String str = paramServiceDeploymentDescriptor.getId();
/*     */     
/* 293 */     if (str.equals("urn:soap-service-manager"))
/*     */     {
/*     */       
/* 296 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + str + "' may not be deployed");
/*     */     }
/*     */ 
/*     */     
/* 300 */     if (str.equals("urn:soap-provider-manager"))
/*     */     {
/*     */       
/* 303 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + str + "' may not be deployed");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 311 */       if (this.m_configManager.query(str) != null)
/*     */       {
/* 313 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + str + "' is already deployed");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 320 */       if (!paramServiceDeploymentDescriptor.getIsApacheDescriptor() && this.m_providerManager != null) {
/*     */         
/*     */         try {
/*     */           
/* 324 */           ProviderDeploymentDescriptor providerDeploymentDescriptor = this.m_providerManager.query(paramServiceDeploymentDescriptor.getProviderId());
/*     */         
/*     */         }
/* 327 */         catch (Exception exception) {
/*     */           
/* 329 */           throw new SOAPException(Constants.FAULT_CODE_SERVER, "unable to deploy service '" + str + "'.  Provider '" + paramServiceDeploymentDescriptor.getProviderId() + "' does not exist");
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 336 */       this.m_configManager.deploy((DeploymentDescriptor)paramServiceDeploymentDescriptor);
/*     */     }
/* 338 */     catch (Exception exception) {
/*     */       
/* 340 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceDeploymentDescriptor query(String paramString) throws SOAPException {
/* 363 */     if (ServerUtils.isNull(paramString))
/*     */     {
/* 365 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + paramString + "' invalid");
/*     */     }
/*     */     
/* 368 */     if (paramString.equals("urn:soap-service-manager") && this.m_smsdd != null)
/*     */     {
/*     */ 
/*     */       
/* 372 */       return this.m_smsdd;
/*     */     }
/* 374 */     if (paramString.equals("urn:soap-provider-manager") && this.m_pmsdd != null)
/*     */     {
/*     */ 
/*     */       
/* 378 */       return this.m_pmsdd;
/*     */     }
/*     */     
/* 381 */     ServiceDeploymentDescriptor serviceDeploymentDescriptor = (ServiceDeploymentDescriptor)this.m_configManager.query(paramString);
/*     */     
/* 383 */     if (serviceDeploymentDescriptor == null)
/*     */     {
/* 385 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "service '" + paramString + "' unknown");
/*     */     }
/*     */ 
/*     */     
/* 389 */     return serviceDeploymentDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list() throws SOAPException {
/* 405 */     byte b1 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 410 */     if (this.m_pmsdd != null) {
/* 411 */       b1++;
/*     */     }
/* 413 */     if (this.m_smsdd != null) {
/* 414 */       b1++;
/*     */     }
/* 416 */     String[] arrayOfString = this.m_configManager.list(b1);
/*     */     
/* 418 */     byte b2 = 0;
/* 419 */     if (this.m_pmsdd != null)
/*     */     {
/* 421 */       arrayOfString[b2++] = "urn:soap-provider-manager";
/*     */     }
/*     */ 
/*     */     
/* 425 */     if (this.m_smsdd != null)
/*     */     {
/* 427 */       arrayOfString[b2++] = "urn:soap-service-manager";
/*     */     }
/*     */ 
/*     */     
/* 431 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String version() throws SOAPException {
/* 450 */     return VersionInfo.getVersion();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\ServiceManagerImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */