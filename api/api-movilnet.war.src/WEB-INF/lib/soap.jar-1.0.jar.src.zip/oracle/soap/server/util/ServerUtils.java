/*      */ package oracle.soap.server.util;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.servlet.ServletContext;
/*      */ import oracle.soap.server.ConfigManager;
/*      */ import oracle.soap.server.ContainerContext;
/*      */ import oracle.soap.server.Handler;
/*      */ import oracle.soap.server.Logger;
/*      */ import oracle.soap.server.Provider;
/*      */ import oracle.soap.server.ProviderManager;
/*      */ import oracle.soap.server.ServiceManager;
/*      */ import oracle.soap.server.impl.ServletLogger;
/*      */ import org.apache.soap.Constants;
/*      */ import org.apache.soap.SOAPException;
/*      */ import org.apache.soap.server.SOAPFaultListener;
/*      */ import org.apache.soap.server.SOAPFaultRouter;
/*      */ import org.apache.soap.util.xml.DOMUtils;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ServerUtils
/*      */ {
/*      */   private static final String defaultProviderManagerClassname = "oracle.soap.server.impl.ProviderManagerImpl";
/*      */   private static final String defaultServiceManagerClassname = "oracle.soap.server.impl.ServiceManagerImpl";
/*      */   
/*      */   public static Object createObject(String paramString, ClassLoader paramClassLoader, StringBuffer paramStringBuffer) {
/*   64 */     Object object = null;
/*      */     try {
/*   66 */       if (paramClassLoader != null) {
/*      */         
/*   68 */         object = paramClassLoader.loadClass(paramString).newInstance();
/*      */       }
/*      */       else {
/*      */         
/*   72 */         object = Class.forName(paramString).newInstance();
/*      */       } 
/*   74 */     } catch (ClassNotFoundException classNotFoundException) {
/*   75 */       paramStringBuffer.append("Unable to find class '" + paramString + "'");
/*   76 */     } catch (InstantiationException instantiationException) {
/*   77 */       paramStringBuffer.append("Unable to instantiate class '" + paramString + "'");
/*   78 */     } catch (IllegalAccessException illegalAccessException) {
/*   79 */       paramStringBuffer.append("Unable to access constructor of class '" + paramString + "'");
/*      */     } 
/*      */     
/*   82 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ConfigManager createConfigManager(Element paramElement, String paramString, ClassLoader paramClassLoader, ServletContext paramServletContext) throws SOAPException {
/*      */     String str;
/*      */     Properties properties;
/*  119 */     StringBuffer stringBuffer = new StringBuffer();
/*  120 */     ConfigManager configManager = null;
/*      */     
/*  122 */     if (paramElement != null) {
/*      */       
/*  124 */       str = DOMUtils.getAttribute(paramElement, "class");
/*  125 */       if (str == null)
/*      */       {
/*  127 */         str = paramString;
/*      */       }
/*      */ 
/*      */       
/*  131 */       properties = parseOptions("http://xmlns.oracle.com/soap/2001/04/config", paramElement, "configManager");
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  136 */       str = paramString;
/*  137 */       properties = new Properties();
/*      */     } 
/*      */     
/*  140 */     Object object = createObject(str, paramClassLoader, stringBuffer);
/*      */     
/*  142 */     if (object == null)
/*      */     {
/*  144 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, stringBuffer.toString());
/*      */     }
/*      */ 
/*      */     
/*  148 */     if (!(object instanceof ConfigManager))
/*      */     {
/*  150 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Class '" + str + "' is not a ConfigManager.");
/*      */     }
/*      */ 
/*      */     
/*  154 */     configManager = (ConfigManager)object;
/*      */     
/*  156 */     configManager.setContext(paramServletContext);
/*  157 */     configManager.setOptions(properties);
/*  158 */     configManager.init();
/*      */     
/*  160 */     return (ConfigManager)object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Provider createProvider(String paramString, ClassLoader paramClassLoader) throws SOAPException {
/*  181 */     StringBuffer stringBuffer = new StringBuffer();
/*      */     
/*  183 */     Object object = createObject(paramString, paramClassLoader, stringBuffer);
/*      */     
/*  185 */     if (object == null)
/*      */     {
/*  187 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, stringBuffer.toString());
/*      */     }
/*      */ 
/*      */     
/*  191 */     if (!(object instanceof Provider))
/*      */     {
/*  193 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Class '" + paramString + "' is not a Provider.");
/*      */     }
/*      */ 
/*      */     
/*  197 */     return (Provider)object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Handler createHandler(String paramString, ClassLoader paramClassLoader) throws SOAPException {
/*  219 */     StringBuffer stringBuffer = new StringBuffer();
/*      */     
/*  221 */     Object object = createObject(paramString, paramClassLoader, stringBuffer);
/*      */     
/*  223 */     if (object == null)
/*      */     {
/*  225 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, stringBuffer.toString());
/*      */     }
/*      */ 
/*      */     
/*  229 */     if (!(object instanceof Handler))
/*      */     {
/*  231 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Class '" + paramString + "' is not a Handler.");
/*      */     }
/*      */ 
/*      */     
/*  235 */     return (Handler)object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ProviderManager createProviderManager(Element paramElement, ClassLoader paramClassLoader, ServletContext paramServletContext) throws SOAPException {
/*  273 */     String str = null;
/*  274 */     Properties properties = null;
/*  275 */     Element element = null;
/*      */ 
/*      */     
/*      */     try {
/*  279 */       NodeList nodeList = paramElement.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "providerManager");
/*      */ 
/*      */ 
/*      */       
/*  283 */       if (nodeList == null || nodeList.getLength() == 0)
/*      */       {
/*  285 */         properties = new Properties();
/*  286 */         str = "oracle.soap.server.impl.ProviderManagerImpl";
/*      */       }
/*  288 */       else if (nodeList.getLength() == 1)
/*      */       {
/*  290 */         Element element1 = (Element)nodeList.item(0);
/*  291 */         str = DOMUtils.getAttribute(element1, "class");
/*  292 */         if (str == null)
/*      */         {
/*      */           
/*  295 */           str = "oracle.soap.server.impl.ProviderManagerImpl";
/*      */         }
/*      */ 
/*      */         
/*  299 */         properties = parseOptions("http://xmlns.oracle.com/soap/2001/04/config", element1, "providerManager");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  304 */         nodeList = element1.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "configManager");
/*      */ 
/*      */         
/*  307 */         if (nodeList != null && nodeList.getLength() != 0)
/*      */         {
/*      */ 
/*      */           
/*  311 */           if (nodeList.getLength() == 1)
/*      */           {
/*  313 */             element = (Element)nodeList.item(0);
/*      */           }
/*      */           else
/*      */           {
/*  317 */             throw new IllegalArgumentException("At most one 'configManager' element per 'providerManager' may be specified");
/*      */           }
/*      */         
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  324 */         throw new IllegalArgumentException("At most one 'providerManager' element may be specified");
/*      */       }
/*      */     
/*      */     }
/*  328 */     catch (Exception exception) {
/*      */       
/*  330 */       rethrow(Constants.FAULT_CODE_SERVER, exception);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  335 */     StringBuffer stringBuffer = new StringBuffer();
/*  336 */     Object object = createObject(str, paramClassLoader, stringBuffer);
/*      */     
/*  338 */     if (object == null)
/*      */     {
/*  340 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, stringBuffer.toString());
/*      */     }
/*      */ 
/*      */     
/*  344 */     if (!(object instanceof ProviderManager))
/*      */     {
/*  346 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "'" + str + "' is not a ProviderManager");
/*      */     }
/*      */ 
/*      */     
/*  350 */     ProviderManager providerManager = (ProviderManager)object;
/*      */     
/*  352 */     ConfigManager configManager = createConfigManager(element, providerManager.getDefaultConfigManagerClassname(), paramClassLoader, paramServletContext);
/*      */ 
/*      */ 
/*      */     
/*  356 */     providerManager.init(properties, paramServletContext, configManager);
/*      */     
/*  358 */     return providerManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Properties parseOptions(String paramString1, Element paramElement, String paramString2) {
/*  386 */     Properties properties = new Properties();
/*      */     
/*  388 */     NodeList nodeList = paramElement.getElementsByTagNameNS(paramString1, "option");
/*      */     
/*  390 */     for (byte b = 0; nodeList != null && b < nodeList.getLength(); b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  396 */       Element element = (Element)nodeList.item(b);
/*  397 */       String str1 = DOMUtils.getAttribute(element, "name");
/*  398 */       String str2 = DOMUtils.getAttribute(element, "value");
/*      */       
/*  400 */       if (str1 == null || str1.equals(""))
/*      */       {
/*  402 */         throw new IllegalArgumentException("Missing 'name' attribute on 'option' element in " + paramString2);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  407 */       if (str2 == null || str2.equals(""))
/*      */       {
/*  409 */         throw new IllegalArgumentException("Missing 'value' attribute on 'option' element in " + paramString2);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  414 */       properties.put(str1, str2);
/*      */     } 
/*      */     
/*  417 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkSoapConfigRootElement(Element paramElement) {
/*  423 */     if (!paramElement.getNamespaceURI().equals("http://xmlns.oracle.com/soap/2001/04/config") || !paramElement.getLocalName().equals("soapConfig"))
/*      */     {
/*      */ 
/*      */       
/*  427 */       throw new IllegalArgumentException("Root element must be http://xmlns.oracle.com/soap/2001/04/config:soapConfig, not '" + paramElement.getNamespaceURI() + ":" + paramElement.getLocalName() + "'");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getPathAuth(Element paramElement) {
/*  438 */     boolean bool = false;
/*      */     
/*  440 */     String str = DOMUtils.getAttribute(paramElement, "pathAuth");
/*  441 */     if (str != null)
/*      */     {
/*  443 */       if (str.equals("true") || str.equals("1"))
/*  444 */         bool = true; 
/*      */     }
/*  446 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ServiceManager createServiceManager(Element paramElement, ProviderManager paramProviderManager, ClassLoader paramClassLoader, ServletContext paramServletContext) throws SOAPException {
/*  489 */     String str = null;
/*  490 */     Properties properties = null;
/*  491 */     Element element = null;
/*      */ 
/*      */     
/*      */     try {
/*  495 */       NodeList nodeList = paramElement.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "serviceManager");
/*      */ 
/*      */ 
/*      */       
/*  499 */       if (nodeList == null || nodeList.getLength() == 0)
/*      */       {
/*  501 */         properties = new Properties();
/*  502 */         str = "oracle.soap.server.impl.ServiceManagerImpl";
/*      */       }
/*  504 */       else if (nodeList.getLength() == 1)
/*      */       {
/*  506 */         Element element1 = (Element)nodeList.item(0);
/*  507 */         str = DOMUtils.getAttribute(element1, "class");
/*  508 */         if (str == null)
/*      */         {
/*      */           
/*  511 */           str = "oracle.soap.server.impl.ServiceManagerImpl";
/*      */         }
/*      */ 
/*      */         
/*  515 */         properties = parseOptions("http://xmlns.oracle.com/soap/2001/04/config", element1, "serviceManager");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  520 */         nodeList = element1.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "configManager");
/*      */ 
/*      */         
/*  523 */         if (nodeList != null && nodeList.getLength() != 0)
/*      */         {
/*      */ 
/*      */           
/*  527 */           if (nodeList.getLength() == 1)
/*      */           {
/*  529 */             element = (Element)nodeList.item(0);
/*      */           }
/*      */           else
/*      */           {
/*  533 */             throw new IllegalArgumentException("At most one 'configManager' element per 'serviceManager' may be specified");
/*      */           }
/*      */         
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  540 */         throw new IllegalArgumentException("At most one 'serviceManager' element may be specified");
/*      */       }
/*      */     
/*      */     }
/*  544 */     catch (Exception exception) {
/*      */       
/*  546 */       rethrow(Constants.FAULT_CODE_SERVER, exception);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  551 */     StringBuffer stringBuffer = new StringBuffer();
/*  552 */     Object object = createObject(str, paramClassLoader, stringBuffer);
/*      */     
/*  554 */     if (object == null)
/*      */     {
/*  556 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, stringBuffer.toString());
/*      */     }
/*      */ 
/*      */     
/*  560 */     if (!(object instanceof ServiceManager))
/*      */     {
/*  562 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "'" + str + "' is not a ServiceManager");
/*      */     }
/*      */ 
/*      */     
/*  566 */     ServiceManager serviceManager = (ServiceManager)object;
/*      */     
/*  568 */     ConfigManager configManager = createConfigManager(element, serviceManager.getDefaultConfigManagerClassname(), paramClassLoader, paramServletContext);
/*      */ 
/*      */ 
/*      */     
/*  572 */     serviceManager.init(properties, paramProviderManager, paramServletContext, configManager);
/*      */     
/*  574 */     return serviceManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Logger createLogger(Element paramElement, ContainerContext paramContainerContext, ClassLoader paramClassLoader) throws SOAPException {
/*  604 */     String str = null;
/*  605 */     Properties properties = null;
/*  606 */     ServletLogger servletLogger = null;
/*      */ 
/*      */     
/*      */     try {
/*  610 */       NodeList nodeList = paramElement.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "logger");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  615 */       if (nodeList == null || nodeList.getLength() == 0) {
/*      */         
/*  617 */         servletLogger = new ServletLogger();
/*  618 */         servletLogger.init(new Properties(), paramContainerContext);
/*  619 */         return (Logger)servletLogger;
/*      */       } 
/*      */       
/*  622 */       if (nodeList.getLength() > 1)
/*      */       {
/*  624 */         throw new IllegalArgumentException("Only one 'logger' element is allowed");
/*      */       }
/*      */ 
/*      */       
/*  628 */       Element element = (Element)nodeList.item(0);
/*  629 */       str = DOMUtils.getAttribute(element, "class");
/*  630 */       if (str == null)
/*      */       {
/*  632 */         throw new IllegalArgumentException("'class' attribute is required in logger element");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  638 */       properties = parseOptions("http://xmlns.oracle.com/soap/2001/04/config", element, "logger");
/*      */     
/*      */     }
/*  641 */     catch (Exception exception) {
/*      */       
/*  643 */       rethrow(Constants.FAULT_CODE_SERVER, exception);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  648 */     StringBuffer stringBuffer = new StringBuffer();
/*  649 */     Object object = createObject(str, paramClassLoader, stringBuffer);
/*      */     
/*  651 */     if (object == null)
/*      */     {
/*  653 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, stringBuffer.toString());
/*      */     }
/*      */ 
/*      */     
/*  657 */     if (!(object instanceof Logger))
/*      */     {
/*  659 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "'" + str + "' is not a Logger");
/*      */     }
/*      */ 
/*      */     
/*  663 */     Logger logger = (Logger)object;
/*  664 */     logger.init(properties, paramContainerContext);
/*      */     
/*  666 */     return logger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Properties createHandlers(Element paramElement, ClassLoader paramClassLoader) throws SOAPException {
/*  691 */     Properties properties = new Properties();
/*      */ 
/*      */     
/*      */     try {
/*  695 */       NodeList nodeList = null;
/*      */       
/*  697 */       nodeList = paramElement.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "handlers");
/*      */ 
/*      */ 
/*      */       
/*  701 */       if (nodeList == null || nodeList.getLength() == 0) {
/*  702 */         return properties;
/*      */       }
/*  704 */       if (nodeList.getLength() > 1)
/*      */       {
/*  706 */         throw new IllegalArgumentException("At most one 'handlers' element is allowed");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  712 */       Element element = (Element)nodeList.item(0);
/*      */ 
/*      */       
/*  715 */       nodeList = element.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "handler");
/*      */ 
/*      */       
/*  718 */       int i = nodeList.getLength();
/*      */ 
/*      */ 
/*      */       
/*  722 */       for (byte b = 0; nodeList != null && b < i; b++)
/*      */       {
/*  724 */         Element element1 = (Element)nodeList.item(b);
/*  725 */         String str1 = DOMUtils.getAttribute(element1, "name");
/*  726 */         String str2 = DOMUtils.getAttribute(element1, "class");
/*      */         
/*  728 */         if (str1 == null)
/*      */         {
/*  730 */           throw new IllegalArgumentException("'name' attribute is required in handler element");
/*      */         }
/*      */         
/*  733 */         if (str2 == null)
/*      */         {
/*  735 */           throw new IllegalArgumentException("'class' attribute is required in handler element ");
/*      */         }
/*      */         
/*  738 */         if (properties.get(str1) != null)
/*      */         {
/*  740 */           throw new IllegalArgumentException("handler '" + str1 + "' is multiply defined ");
/*      */         }
/*      */         
/*  743 */         Properties properties1 = parseOptions("http://xmlns.oracle.com/soap/2001/04/config", element1, "handler " + str1);
/*      */ 
/*      */ 
/*      */         
/*  747 */         Handler handler = createHandler(str2, paramClassLoader);
/*  748 */         handler.setOptions(properties1);
/*  749 */         handler.setName(str1);
/*  750 */         properties.put(str1, handler);
/*      */       }
/*      */     
/*  753 */     } catch (Exception exception) {
/*      */       
/*  755 */       rethrow(Constants.FAULT_CODE_SERVER, exception);
/*      */     } 
/*      */     
/*  758 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getRequestHandlers(Element paramElement) throws SOAPException {
/*  777 */     return getHandlerList(paramElement, "requestHandlers");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getResponseHandlers(Element paramElement) throws SOAPException {
/*  796 */     return getHandlerList(paramElement, "responseHandlers");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getErrorHandlers(Element paramElement) throws SOAPException {
/*  815 */     return getHandlerList(paramElement, "errorHandlers");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] getHandlerList(Element paramElement, String paramString) throws SOAPException {
/*  834 */     String[] arrayOfString = null;
/*      */ 
/*      */     
/*      */     try {
/*  838 */       NodeList nodeList = paramElement.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", paramString);
/*      */ 
/*      */       
/*  841 */       if (nodeList == null || nodeList.getLength() == 0) {
/*  842 */         return new String[0];
/*      */       }
/*  844 */       if (nodeList.getLength() > 1)
/*      */       {
/*  846 */         throw new IllegalArgumentException("At most one '" + paramString + "' element is allowed");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  852 */       Element element = (Element)nodeList.item(0);
/*  853 */       String str = DOMUtils.getAttribute(element, "names");
/*      */       
/*  855 */       StringTokenizer stringTokenizer = new StringTokenizer(str, ", ");
/*  856 */       int i = stringTokenizer.countTokens();
/*      */       
/*  858 */       arrayOfString = new String[i];
/*      */       
/*  860 */       for (byte b = 0; b < i; b++) {
/*  861 */         arrayOfString[b] = stringTokenizer.nextToken();
/*      */       }
/*      */     }
/*  864 */     catch (Exception exception) {
/*      */       
/*  866 */       rethrow(Constants.FAULT_CODE_SERVER, exception);
/*      */     } 
/*      */     
/*  869 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getFaultListeners(Element paramElement) throws SOAPException {
/*  891 */     String[] arrayOfString = null;
/*      */ 
/*      */     
/*      */     try {
/*  895 */       NodeList nodeList = null;
/*      */       
/*  897 */       nodeList = paramElement.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "faultListeners");
/*      */ 
/*      */ 
/*      */       
/*  901 */       if (nodeList == null || nodeList.getLength() == 0) {
/*  902 */         return new String[0];
/*      */       }
/*  904 */       if (nodeList.getLength() > 1)
/*      */       {
/*  906 */         throw new IllegalArgumentException("At most one 'faultListeners' element is allowed");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  912 */       Element element = (Element)nodeList.item(0);
/*      */ 
/*      */       
/*  915 */       nodeList = element.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/config", "faultListener");
/*      */ 
/*      */ 
/*      */       
/*  919 */       byte b1 = (nodeList == null) ? 0 : nodeList.getLength();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  924 */       arrayOfString = new String[b1];
/*      */       
/*  926 */       for (byte b2 = 0; nodeList != null && b2 < b1; b2++)
/*      */       {
/*  928 */         Element element1 = (Element)nodeList.item(b2);
/*  929 */         arrayOfString[b2] = DOMUtils.getAttribute(element1, "class");
/*  930 */         if (arrayOfString[b2] == null)
/*      */         {
/*  932 */           throw new IllegalArgumentException("'class' attribute is required in faultListener element");
/*      */         
/*      */         }
/*      */       }
/*      */     
/*      */     }
/*  938 */     catch (Exception exception) {
/*      */       
/*  940 */       rethrow(Constants.FAULT_CODE_SERVER, exception);
/*      */     } 
/*      */     
/*  943 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SOAPFaultRouter buildFaultRouter(String[] paramArrayOfString, ClassLoader paramClassLoader) {
/*  958 */     StringBuffer stringBuffer = new StringBuffer();
/*  959 */     SOAPFaultRouter sOAPFaultRouter = new SOAPFaultRouter();
/*  960 */     byte b = (paramArrayOfString != null) ? paramArrayOfString.length : 0;
/*      */     
/*  962 */     SOAPFaultListener[] arrayOfSOAPFaultListener = new SOAPFaultListener[b];
/*      */ 
/*      */     
/*      */     try {
/*  966 */       for (byte b1 = 0; b1 < b; b1++)
/*      */       {
/*  968 */         arrayOfSOAPFaultListener[b1] = (SOAPFaultListener)createObject(paramArrayOfString[b1], paramClassLoader, stringBuffer);
/*      */       
/*      */       }
/*      */     }
/*  972 */     catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  977 */     sOAPFaultRouter.setFaultListener(arrayOfSOAPFaultListener);
/*      */     
/*  979 */     return sOAPFaultRouter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rethrow(String paramString1, Throwable paramThrowable, String paramString2) throws SOAPException {
/* 1006 */     if (paramThrowable instanceof SOAPException)
/* 1007 */       throw (SOAPException)paramThrowable; 
/* 1008 */     throw new SOAPException(paramString1, paramString2, paramThrowable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rethrow(String paramString, Throwable paramThrowable) throws SOAPException {
/* 1030 */     rethrow(paramString, paramThrowable, paramThrowable.getMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rethrow(Throwable paramThrowable) throws SOAPException {
/* 1049 */     rethrow(Constants.FAULT_CODE_SERVER, paramThrowable, paramThrowable.getMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getStackTrace(Throwable paramThrowable) {
/* 1061 */     StringWriter stringWriter = new StringWriter();
/* 1062 */     paramThrowable.printStackTrace(new PrintWriter(stringWriter));
/*      */     
/* 1064 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNull(String paramString) {
/* 1082 */     if (paramString == null || paramString.equals("")) {
/* 1083 */       return true;
/*      */     }
/* 1085 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\serve\\util\ServerUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */