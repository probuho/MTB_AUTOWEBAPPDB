/*     */ package oracle.soap.server;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Logger
/*     */ {
/*     */   public static final int SEVERITY_ERROR = 0;
/*     */   public static final int SEVERITY_STATUS = 1;
/*     */   public static final int SEVERITY_DEBUG = 2;
/*     */   protected static final int SEVERITY_INVALID = 3;
/*  42 */   public static String[] SEVERITY_NAMES = new String[] { "error", "status", "debug" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_SEVERITY = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String OPTION_SEVERITY = "severity";
/*     */ 
/*     */ 
/*     */   
/*  56 */   protected int m_severity = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getSeverityValue(String paramString) {
/*  72 */     char c = '\003';
/*     */     
/*  74 */     if (paramString.equals("debug999"))
/*     */     {
/*  76 */       c = 'ϧ';
/*     */     }
/*  78 */     for (byte b = 0; b < 3; b++) {
/*     */       
/*  80 */       if (paramString.equals(SEVERITY_NAMES[b])) {
/*     */         
/*  82 */         c = b;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  87 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getSeverityName(int paramInt) {
/* 104 */     String str = "unknown";
/*     */     
/* 106 */     if (paramInt >= 0 && paramInt < 3)
/*     */     {
/* 108 */       str = SEVERITY_NAMES[paramInt];
/*     */     }
/*     */     
/* 111 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void init(Properties paramProperties, ContainerContext paramContainerContext) throws SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeverity() {
/* 144 */     return this.m_severity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSeverity(int paramInt) {
/* 158 */     this.m_severity = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLoggable(int paramInt) {
/* 176 */     if (paramInt <= this.m_severity)
/* 177 */       return true; 
/* 178 */     return false;
/*     */   }
/*     */   
/*     */   public abstract void log(String paramString, int paramInt);
/*     */   
/*     */   public abstract void log(String paramString, Throwable paramThrowable, int paramInt);
/*     */   
/*     */   public abstract void log(Throwable paramThrowable, int paramInt);
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\Logger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */