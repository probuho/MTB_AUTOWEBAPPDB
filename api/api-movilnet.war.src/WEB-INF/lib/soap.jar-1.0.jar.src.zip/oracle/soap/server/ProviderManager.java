package oracle.soap.server;

import java.util.Properties;
import javax.servlet.ServletContext;
import org.apache.soap.SOAPException;

public interface ProviderManager {
  String getDefaultConfigManagerClassname();
  
  void init(Properties paramProperties, ServletContext paramServletContext, ConfigManager paramConfigManager) throws SOAPException;
  
  void destroy() throws SOAPException;
  
  void setServiceManager(ServiceManager paramServiceManager);
  
  String getRequiredRequestURI();
  
  ProviderDeploymentDescriptor undeploy(String paramString) throws SOAPException;
  
  void deploy(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor) throws SOAPException;
  
  ProviderDeploymentDescriptor query(String paramString) throws SOAPException;
  
  String[] list() throws SOAPException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\ProviderManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */