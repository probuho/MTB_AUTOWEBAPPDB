/*     */ package oracle.soap.server;
/*     */ 
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleSOAPContext
/*     */   extends SOAPContext
/*     */ {
/*     */   private static final String SECURE_CHANNEL = "oracle.soap.transport.secureChannel";
/*     */   private static final String REMOTE_ADDR = "oracle.soap.transport.remoteAddress";
/*     */   private static final String REMOTE_HOST = "oracle.soap.transport.remoteHost";
/*     */   private static final String USERNAME = "oracle.soap.transport.username";
/*     */   private static final String CERTIFICATE = "oracle.soap.transport.certificate";
/*     */   private static final String REQUEST_URI = "oracle.soap.transport.requestURI";
/*     */   private static final String SERVICE_DEPLOYMENT_DESCRIPTOR = "oracle.soap.server.sdd";
/*     */   
/*     */   public String getRequestURI() {
/*  78 */     return (String)getProperty("oracle.soap.transport.requestURI");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestURI(String paramString) {
/*  90 */     setProperty("oracle.soap.transport.requestURI", paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCertificate() {
/* 104 */     return getProperty("oracle.soap.transport.certificate");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCertificate(Object paramObject) {
/* 118 */     setProperty("oracle.soap.transport.certificate", paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServlet getHttpServlet() {
/* 133 */     return (HttpServlet)getProperty(Constants.BAG_HTTPSERVLET);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpServlet(HttpServlet paramHttpServlet) {
/* 147 */     setProperty(Constants.BAG_HTTPSERVLET, paramHttpServlet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServletRequest getHttpServletRequest() {
/* 162 */     return (HttpServletRequest)getProperty(Constants.BAG_HTTPSERVLETREQUEST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpServletRequest(HttpServletRequest paramHttpServletRequest) {
/* 177 */     setProperty(Constants.BAG_HTTPSERVLETREQUEST, paramHttpServletRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServletResponse getHttpServletResponse() {
/* 192 */     return (HttpServletResponse)getProperty(Constants.BAG_HTTPSERVLETRESPONSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpServletResponse(HttpServletResponse paramHttpServletResponse) {
/* 207 */     setProperty(Constants.BAG_HTTPSERVLETRESPONSE, paramHttpServletResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpSession getHttpSession() {
/* 222 */     return (HttpSession)getProperty(Constants.BAG_HTTPSESSION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpSession(HttpSession paramHttpSession) {
/* 236 */     setProperty(Constants.BAG_HTTPSESSION, paramHttpSession);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRemoteAddress() {
/* 251 */     return (String)getProperty("oracle.soap.transport.remoteAddress");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteAddress(String paramString) {
/* 265 */     setProperty("oracle.soap.transport.remoteAddress", paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRemoteHost() {
/* 279 */     return (String)getProperty("oracle.soap.transport.remoteHost");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteHost(String paramString) {
/* 293 */     setProperty("oracle.soap.transport.remoteHost", paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSecureChannel() {
/* 308 */     return ((Boolean)getProperty("oracle.soap.transport.secureChannel")).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecureChannel(boolean paramBoolean) {
/* 323 */     setProperty("oracle.soap.transport.secureChannel", new Boolean(paramBoolean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUsername() {
/* 338 */     return (String)getProperty("oracle.soap.transport.username");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsername(String paramString) {
/* 352 */     setProperty("oracle.soap.transport.username", paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceDeploymentDescriptor getServiceDeploymentDescriptor() {
/* 367 */     return (ServiceDeploymentDescriptor)getProperty("oracle.soap.server.sdd");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceDeploymentDescriptor(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor) {
/* 384 */     setProperty("oracle.soap.server.sdd", paramServiceDeploymentDescriptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\OracleSOAPContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */