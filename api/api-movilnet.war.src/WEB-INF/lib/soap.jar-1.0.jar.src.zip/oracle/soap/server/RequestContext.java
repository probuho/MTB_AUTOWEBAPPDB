/*     */ package oracle.soap.server;
/*     */ 
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestContext
/*     */ {
/*  63 */   private String m_serviceId = null;
/*  64 */   private String m_methodName = null;
/*  65 */   private Envelope m_requestEnvelope = null;
/*  66 */   private OracleSOAPContext m_requestSOAPContext = null;
/*  67 */   private Envelope m_responseEnvelope = null;
/*  68 */   private OracleSOAPContext m_responseSOAPContext = null;
/*  69 */   private String m_requestEncodingStyle = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */   
/*  71 */   private SOAPMappingRegistry m_responseMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestEnvelope(Envelope paramEnvelope) {
/*  84 */     this.m_requestEnvelope = paramEnvelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Envelope getRequestEnvelope() {
/*  98 */     return this.m_requestEnvelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestSOAPContext(OracleSOAPContext paramOracleSOAPContext) {
/* 112 */     this.m_requestSOAPContext = paramOracleSOAPContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSOAPContext getRequestSOAPContext() {
/* 126 */     return this.m_requestSOAPContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponseEnvelope(Envelope paramEnvelope) {
/* 140 */     this.m_responseEnvelope = paramEnvelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Envelope getResponseEnvelope() {
/* 154 */     return this.m_responseEnvelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponseMap(SOAPMappingRegistry paramSOAPMappingRegistry) {
/* 169 */     this.m_responseMap = paramSOAPMappingRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPMappingRegistry getResponseMap() {
/* 184 */     return this.m_responseMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponseSOAPContext(OracleSOAPContext paramOracleSOAPContext) {
/* 198 */     this.m_responseSOAPContext = paramOracleSOAPContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSOAPContext getResponseSOAPContext() {
/* 213 */     return this.m_responseSOAPContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestEncodingStyle(String paramString) {
/* 228 */     this.m_requestEncodingStyle = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequestEncodingStyle() {
/* 242 */     return this.m_requestEncodingStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethodName(String paramString) {
/* 258 */     this.m_methodName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodName() {
/* 272 */     return this.m_methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceId(String paramString) {
/* 286 */     this.m_serviceId = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServiceId() {
/* 300 */     return this.m_serviceId;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\RequestContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */