package oracle.soap.server;

import java.util.Properties;
import javax.servlet.ServletContext;
import org.apache.soap.SOAPException;

public interface ServiceManager {
  String getDefaultConfigManagerClassname();
  
  void init(Properties paramProperties, ProviderManager paramProviderManager, ServletContext paramServletContext, ConfigManager paramConfigManager) throws SOAPException;
  
  void destroy() throws SOAPException;
  
  String getRequiredRequestURI();
  
  ServiceDeploymentDescriptor undeploy(String paramString) throws SOAPException;
  
  void deploy(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor) throws SOAPException;
  
  ServiceDeploymentDescriptor query(String paramString) throws SOAPException;
  
  String[] list() throws SOAPException;
  
  String version() throws SOAPException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\ServiceManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */