/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.server.http.ServerHTTPUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryProviderConfigManager
/*     */   extends BaseConfigManager
/*     */ {
/*     */   public static final String OPTION_FILENAME = "filename";
/*  39 */   public static final String DEFAULT_FILENAME = "WEB-INF" + File.separator + "providers.dd";
/*     */ 
/*     */   
/*  42 */   private String m_registryFilename = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptions(Properties paramProperties) throws SOAPException {
/*  58 */     this.m_registryFilename = paramProperties.getProperty("filename");
/*     */     
/*  60 */     if (ServerUtils.isNull(this.m_registryFilename))
/*     */     {
/*  62 */       this.m_registryFilename = DEFAULT_FILENAME;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void readRegistry() throws SOAPException {
/*     */     try {
/*  77 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */ 
/*     */       
/*  80 */       FileInputStream fileInputStream = new FileInputStream(file);
/*  81 */       ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
/*  82 */       this.m_registry = (Hashtable)objectInputStream.readObject();
/*  83 */       objectInputStream.close();
/*     */     }
/*  85 */     catch (Exception exception) {
/*     */       
/*  87 */       this.m_registry = new Hashtable();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void writeRegistry() throws SOAPException {
/*     */     try {
/* 100 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */ 
/*     */       
/* 103 */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/* 104 */       ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
/*     */       
/* 106 */       objectOutputStream.writeObject(this.m_registry);
/* 107 */       objectOutputStream.close();
/*     */     }
/* 109 */     catch (Exception exception) {
/*     */       
/* 111 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\BinaryProviderConfigManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */