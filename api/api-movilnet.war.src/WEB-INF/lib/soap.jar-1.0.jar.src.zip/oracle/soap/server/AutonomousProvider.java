package oracle.soap.server;

import org.apache.soap.SOAPException;

public interface AutonomousProvider extends Provider {
  boolean isMine(String paramString) throws SOAPException;
  
  String[] list() throws SOAPException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\AutonomousProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */