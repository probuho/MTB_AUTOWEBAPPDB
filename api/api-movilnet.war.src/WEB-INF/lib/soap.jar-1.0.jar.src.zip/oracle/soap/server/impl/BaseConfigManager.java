/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.servlet.ServletContext;
/*     */ import oracle.soap.server.ConfigManager;
/*     */ import oracle.soap.server.DeploymentDescriptor;
/*     */ import org.apache.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseConfigManager
/*     */   implements ConfigManager
/*     */ {
/*  35 */   protected Hashtable m_registry = new Hashtable();
/*  36 */   protected String[] m_namesCache = null;
/*  37 */   protected ServletContext m_context = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContext(ServletContext paramServletContext) {
/*  44 */     this.m_context = paramServletContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws SOAPException {
/*  62 */     readRegistry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeploymentDescriptor undeploy(String paramString) throws SOAPException {
/*  84 */     DeploymentDescriptor deploymentDescriptor = (DeploymentDescriptor)this.m_registry.remove(paramString);
/*     */ 
/*     */     
/*  87 */     if (deploymentDescriptor != null) {
/*     */       
/*  89 */       writeRegistry();
/*  90 */       this.m_namesCache = null;
/*     */     } 
/*  92 */     return deploymentDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deploy(DeploymentDescriptor paramDeploymentDescriptor) throws SOAPException {
/* 110 */     String str = paramDeploymentDescriptor.getId();
/* 111 */     this.m_registry.put(str, paramDeploymentDescriptor);
/* 112 */     writeRegistry();
/* 113 */     this.m_namesCache = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeploymentDescriptor query(String paramString) throws SOAPException {
/* 135 */     return (DeploymentDescriptor)this.m_registry.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list(int paramInt) throws SOAPException {
/* 158 */     int i = this.m_registry.size();
/* 159 */     int j = i + paramInt;
/*     */     
/* 161 */     if (this.m_namesCache == null || this.m_namesCache.length != j) {
/*     */       
/* 163 */       Enumeration enumeration = this.m_registry.keys();
/* 164 */       this.m_namesCache = new String[j];
/* 165 */       for (int k = paramInt; k < j; k++) {
/* 166 */         this.m_namesCache[k] = enumeration.nextElement();
/*     */       }
/*     */     } 
/* 169 */     return this.m_namesCache;
/*     */   }
/*     */   
/*     */   public abstract void readRegistry() throws SOAPException;
/*     */   
/*     */   public abstract void writeRegistry() throws SOAPException;
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\BaseConfigManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */