package oracle.soap.server.internal;

public final class OracleServerConstants {
  public static final String SERVICE_MANAGER_SERVICE_NAME = "urn:soap-service-manager";
  
  public static final String PROVIDER_MANAGER_SERVICE_NAME = "urn:soap-provider-manager";
  
  public static final String JAVA_PROVIDER_ID = "java-provider";
  
  public static final String DMS_NOUN_SEPARATOR = "|";
  
  public static final String DMS_PHASE_EVENT_NAME = "activePhase";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\internal\OracleServerConstants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */