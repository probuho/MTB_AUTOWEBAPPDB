/*      */ package oracle.soap.server;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.io.Writer;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.StringTokenizer;
/*      */ import oracle.soap.server.util.ServerUtils;
/*      */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*      */ import org.apache.soap.server.SOAPFaultRouter;
/*      */ import org.apache.soap.server.TypeMapping;
/*      */ import org.apache.soap.util.xml.DOMUtils;
/*      */ import org.apache.soap.util.xml.Deserializer;
/*      */ import org.apache.soap.util.xml.QName;
/*      */ import org.apache.soap.util.xml.Serializer;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ServiceDeploymentDescriptor
/*      */   extends DeploymentDescriptor
/*      */   implements Serializable
/*      */ {
/*      */   public static final int SERVICE_TYPE_RPC = 0;
/*      */   public static final int SERVICE_TYPE_MESSAGE = 1;
/*      */   private static final int SERVICE_TYPE_INVALID = 2;
/*      */   public static final byte PROVIDER_JAVA = 0;
/*      */   public static final byte PROVIDER_SCRIPT_FILE = 1;
/*      */   public static final byte PROVIDER_SCRIPT_STRING = 2;
/*      */   public static final byte PROVIDER_USER_DEFINED = 3;
/*      */   public static final int SCOPE_REQUEST = 0;
/*      */   public static final int SCOPE_SESSION = 1;
/*      */   public static final int SCOPE_APPLICATION = 2;
/*      */   private static final int SCOPE_INVALID = 3;
/*   69 */   private static String[] m_serviceTypeNames = new String[] { "rpc", "message" };
/*      */   
/*   71 */   private static String[] m_scopeNames = new String[] { "Request", "Session", "Application" };
/*      */ 
/*      */   
/*   74 */   protected int m_serviceType = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean m_checkMustUnderstands = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean m_isApacheDescriptor = false;
/*      */ 
/*      */ 
/*      */   
/*      */   protected String m_providerId;
/*      */ 
/*      */ 
/*      */   
/*   92 */   protected byte m_providerType = -1;
/*      */   protected String m_providerClass;
/*   94 */   protected Hashtable m_providerOptions = new Hashtable();
/*      */ 
/*      */   
/*      */   protected int m_scope;
/*      */ 
/*      */   
/*      */   protected String[] m_methods;
/*      */   
/*      */   protected String m_serviceClass;
/*      */   
/*      */   protected boolean m_isStatic;
/*      */   
/*  106 */   private String m_defaultSMRClass = null;
/*      */   
/*      */   protected TypeMapping[] m_typeMappings;
/*  109 */   private transient SOAPMappingRegistry m_cachedSMR = null;
/*  110 */   private transient Hashtable m_cachedSqlClassMap = null;
/*      */ 
/*      */   
/*  113 */   protected Hashtable m_sqlMap = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] m_faultListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private transient SOAPFaultRouter m_faultRouter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getIsApacheDescriptor() {
/*  140 */     return this.m_isApacheDescriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIsApacheDescriptor(boolean paramBoolean) {
/*  155 */     this.m_isApacheDescriptor = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProviderId(String paramString) {
/*  169 */     this.m_providerId = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProviderId() {
/*  183 */     return this.m_providerId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMethods(String[] paramArrayOfString) {
/*  197 */     this.m_methods = paramArrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getMethods() {
/*  211 */     return this.m_methods;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScope(int paramInt) {
/*  225 */     this.m_scope = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getScope() {
/*  239 */     return this.m_scope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServiceType(int paramInt) {
/*  254 */     this.m_serviceType = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getServiceType() {
/*  268 */     return this.m_serviceType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProviderClass(String paramString) {
/*  283 */     this.m_providerClass = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProviderClass() {
/*  298 */     return this.m_providerClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProviderType(byte paramByte) {
/*  314 */     this.m_providerType = paramByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getProviderType() {
/*  328 */     return this.m_providerType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProviderOptions(Hashtable paramHashtable) {
/*  343 */     this.m_providerOptions = paramHashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Hashtable getProviderOptions() {
/*  358 */     return this.m_providerOptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFaultListener(String[] paramArrayOfString) {
/*  372 */     this.m_faultListener = paramArrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getFaultListener() {
/*  386 */     return this.m_faultListener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SOAPFaultRouter buildFaultRouter(ClassLoader paramClassLoader) {
/*  400 */     if (this.m_faultRouter == null) {
/*  401 */       this.m_faultRouter = ServerUtils.buildFaultRouter(this.m_faultListener, paramClassLoader);
/*      */     }
/*  403 */     return this.m_faultRouter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypeMappings(TypeMapping[] paramArrayOfTypeMapping) {
/*  418 */     this.m_typeMappings = paramArrayOfTypeMapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeMapping[] getTypeMappings() {
/*  433 */     return this.m_typeMappings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlMap(Hashtable paramHashtable) {
/*  447 */     this.m_sqlMap = paramHashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Hashtable getSqlMap() {
/*  461 */     return this.m_sqlMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCachedSMR(SOAPMappingRegistry paramSOAPMappingRegistry) {
/*  475 */     this.m_cachedSMR = paramSOAPMappingRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SOAPMappingRegistry getCachedSMR() {
/*  489 */     return this.m_cachedSMR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCachedSqlClassMap(Hashtable paramHashtable) {
/*  503 */     this.m_cachedSqlClassMap = paramHashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Hashtable getCachedSqlClassMap() {
/*  517 */     return this.m_cachedSqlClassMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultSMRClass(String paramString) {
/*  531 */     this.m_defaultSMRClass = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDefaultSMRClass() {
/*  545 */     return this.m_defaultSMRClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getCheckMustUnderstands() {
/*  559 */     return this.m_checkMustUnderstands;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheckMustUnderstands(boolean paramBoolean) {
/*  573 */     this.m_checkMustUnderstands = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServiceClass(String paramString) {
/*  588 */     this.m_serviceClass = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServiceClass() {
/*  603 */     return this.m_serviceClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIsStatic(boolean paramBoolean) {
/*  619 */     this.m_isStatic = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getIsStatic() {
/*  635 */     return this.m_isStatic;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMethodValid(String paramString) {
/*  650 */     boolean bool = false;
/*      */ 
/*      */     
/*  653 */     if (this.m_methods == null) {
/*  654 */       return false;
/*      */     }
/*  656 */     for (byte b = 0; b < this.m_methods.length; b++) {
/*      */       
/*  658 */       if (paramString.equals(this.m_methods[b])) {
/*      */         
/*  660 */         bool = true;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  665 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ServiceDeploymentDescriptor fromXML(Element paramElement) {
/*  689 */     NodeList nodeList = null;
/*  690 */     Element element1 = null;
/*  691 */     boolean bool1 = false;
/*      */     
/*  693 */     ServiceDeploymentDescriptor serviceDeploymentDescriptor = new ServiceDeploymentDescriptor();
/*      */     
/*  695 */     if (paramElement == null)
/*      */     {
/*  697 */       throw new IllegalArgumentException("root is null");
/*      */     }
/*      */     
/*  700 */     String str1 = paramElement.getNamespaceURI();
/*      */     
/*  702 */     if (str1.equals("http://xmlns.oracle.com/soap/2001/04/deploy/service")) {
/*      */ 
/*      */       
/*  705 */       serviceDeploymentDescriptor.setIsApacheDescriptor(false);
/*      */     }
/*  707 */     else if (str1.equals("http://xml.apache.org/xml-soap/deployment")) {
/*      */       
/*  709 */       serviceDeploymentDescriptor.setIsApacheDescriptor(true);
/*      */     }
/*      */     else {
/*      */       
/*  713 */       throw new IllegalArgumentException("Invalid namespace URI, " + str1 + ", it must be one of " + "http://xmlns.oracle.com/soap/2001/04/deploy/service" + " or " + "http://xml.apache.org/xml-soap/deployment");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  721 */     if (!paramElement.getLocalName().equals("service"))
/*      */     {
/*  723 */       throw new IllegalArgumentException("Document root element is not " + str1 + ":service");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  729 */     String str2 = DOMUtils.getAttribute(paramElement, "id");
/*  730 */     if (str2 == null || str2.equals(""))
/*      */     {
/*  732 */       throw new IllegalArgumentException("missing 'id' attribute in 'service' element");
/*      */     }
/*      */     
/*  735 */     serviceDeploymentDescriptor.setId(str2);
/*      */ 
/*      */ 
/*      */     
/*  739 */     String str3 = DOMUtils.getAttribute(paramElement, "checkMustUnderstands");
/*      */ 
/*      */     
/*  742 */     if (str3 != null) {
/*  743 */       serviceDeploymentDescriptor.setCheckMustUnderstands((new Boolean(str3)).booleanValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  750 */     String str4 = DOMUtils.getAttribute(paramElement, "type");
/*  751 */     if (str4 != null) {
/*      */       
/*  753 */       bool1 = false;
/*  754 */       for (byte b = 0; b < 2; b++) {
/*      */         
/*  756 */         if (str4.equals(m_serviceTypeNames[b])) {
/*      */           
/*  758 */           serviceDeploymentDescriptor.setServiceType(b);
/*  759 */           bool1 = true;
/*      */           break;
/*      */         } 
/*      */       } 
/*  763 */       if (!bool1)
/*      */       {
/*  765 */         throw new IllegalArgumentException("unknown value for 'type' attribute in 'service' element: " + str4 + "'");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  773 */     nodeList = paramElement.getElementsByTagNameNS(str1, "provider");
/*      */     
/*  775 */     if (nodeList == null || nodeList.getLength() != 1)
/*      */     {
/*  777 */       throw new IllegalArgumentException("exactly one 'provider' element is required");
/*      */     }
/*      */ 
/*      */     
/*  781 */     Element element2 = (Element)nodeList.item(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  788 */     String str5 = DOMUtils.getAttribute(element2, "id");
/*  789 */     String str6 = DOMUtils.getAttribute(element2, "type");
/*      */     
/*  791 */     boolean bool2 = false;
/*      */     
/*  793 */     if (serviceDeploymentDescriptor.getIsApacheDescriptor()) {
/*      */       
/*  795 */       if (str6 == null || str6.length() == 0)
/*      */       {
/*  797 */         throw new IllegalArgumentException("Missing 'type' attribute in 'provider' element");
/*      */       }
/*      */       
/*  800 */       if (str5 != null)
/*      */       {
/*  802 */         throw new IllegalArgumentException("Unexpected 'id' attribute in 'provider' element");
/*      */       }
/*      */ 
/*      */       
/*  806 */       if (str6.equals("java"))
/*      */       {
/*  808 */         serviceDeploymentDescriptor.setProviderType((byte)0);
/*  809 */         bool2 = true;
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */         
/*  815 */         serviceDeploymentDescriptor.setProviderType((byte)3);
/*      */ 
/*      */ 
/*      */         
/*  819 */         serviceDeploymentDescriptor.setProviderClass(str6);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  826 */       if (str5 == null || str5.length() == 0)
/*      */       {
/*  828 */         throw new IllegalArgumentException("Missing 'id' attribute in 'provider' element");
/*      */       }
/*      */       
/*  831 */       if (str6 != null)
/*      */       {
/*  833 */         throw new IllegalArgumentException("Unexpected 'type' attribute in 'provider' element");
/*      */       }
/*      */ 
/*      */       
/*  837 */       serviceDeploymentDescriptor.setProviderId(str5);
/*      */       
/*  839 */       if (str5.equals("java-provider")) {
/*  840 */         bool2 = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  849 */     nodeList = element2.getElementsByTagNameNS(str1, "option");
/*  850 */     if (nodeList != null)
/*      */     {
/*      */ 
/*      */       
/*  854 */       for (byte b = 0; b < nodeList.getLength(); b++) {
/*      */         
/*  856 */         element1 = (Element)nodeList.item(b);
/*  857 */         String str9 = DOMUtils.getAttribute(element1, "key");
/*  858 */         String str10 = DOMUtils.getAttribute(element1, "value");
/*      */         
/*  860 */         if (str9 == null || str9.equals(""))
/*      */         {
/*  862 */           throw new IllegalArgumentException("Missing 'key' attribute on 'option' element in deployment descriptor");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  867 */         if (str10 == null)
/*      */         {
/*  869 */           throw new IllegalArgumentException("Missing 'value' attribute on 'option' element in provider descriptor (key=\"" + str9 + "\")");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  874 */         serviceDeploymentDescriptor.m_providerOptions.put(str9, str10);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  884 */     nodeList = element2.getElementsByTagNameNS(str1, "java");
/*      */     
/*  886 */     boolean bool3 = (nodeList != null && nodeList.getLength() == 1) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  891 */     if (bool3) {
/*      */       
/*  893 */       element1 = (Element)nodeList.item(0);
/*  894 */       String str9 = DOMUtils.getAttribute(element1, "class");
/*  895 */       if (str9 == null) {
/*  896 */         throw new IllegalArgumentException("'java' element requires 'class' attribute");
/*      */       }
/*      */       
/*  899 */       serviceDeploymentDescriptor.setServiceClass(str9);
/*  900 */       String str10 = DOMUtils.getAttribute(element1, "static");
/*  901 */       if (str10 != null)
/*      */       {
/*  903 */         serviceDeploymentDescriptor.setIsStatic((new Boolean(str10)).booleanValue());
/*      */       }
/*      */     }
/*  906 */     else if (bool2 || (nodeList != null && nodeList.getLength() > 1)) {
/*      */       
/*  908 */       throw new IllegalArgumentException("must be exactly one 'java' element under 'provider' element");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  915 */     String str7 = DOMUtils.getAttribute(element2, "scope");
/*  916 */     if (ServerUtils.isNull(str7))
/*      */     {
/*  918 */       throw new IllegalArgumentException("missing or invalid 'scope' attribute in 'provider' element");
/*      */     }
/*      */ 
/*      */     
/*  922 */     bool1 = false;
/*  923 */     for (byte b1 = 0; b1 < 3; b1++) {
/*      */       
/*  925 */       if (str7.equals(m_scopeNames[b1])) {
/*      */         
/*  927 */         serviceDeploymentDescriptor.setScope(b1);
/*  928 */         bool1 = true;
/*      */       } 
/*      */     } 
/*  931 */     if (!bool1)
/*      */     {
/*  933 */       throw new IllegalArgumentException("unknown value for 'scope' attribute in 'provider' element: " + str7 + "'");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  939 */     String str8 = null;
/*  940 */     StringTokenizer stringTokenizer = null;
/*  941 */     int i = 0;
/*  942 */     String[] arrayOfString1 = null;
/*      */     
/*  944 */     str8 = DOMUtils.getAttribute(element2, "methods");
/*  945 */     if (ServerUtils.isNull(str8))
/*      */     {
/*  947 */       throw new IllegalArgumentException("invalid or missing value for 'methods' in 'provider' element");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  952 */     stringTokenizer = new StringTokenizer(str8);
/*  953 */     i = stringTokenizer.countTokens();
/*  954 */     if (i == 0)
/*      */     {
/*  956 */       throw new IllegalArgumentException("at least one method is required");
/*      */     }
/*      */     
/*  959 */     arrayOfString1 = new String[i]; byte b2;
/*  960 */     for (b2 = 0; b2 < i; b2++)
/*      */     {
/*  962 */       arrayOfString1[b2] = stringTokenizer.nextToken();
/*      */     }
/*  964 */     serviceDeploymentDescriptor.setMethods(arrayOfString1);
/*      */ 
/*      */ 
/*      */     
/*  968 */     nodeList = paramElement.getElementsByTagNameNS(str1, "faultListener");
/*      */     
/*  970 */     b2 = (nodeList == null) ? 0 : nodeList.getLength();
/*      */     
/*  972 */     String[] arrayOfString2 = new String[b2];
/*      */     
/*  974 */     for (byte b3 = 0; nodeList != null && b3 < b2; b3++) {
/*      */       
/*  976 */       Element element = (Element)nodeList.item(b3);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  981 */       if (serviceDeploymentDescriptor.getIsApacheDescriptor()) {
/*  982 */         arrayOfString2[b3] = DOMUtils.getChildCharacterData(element);
/*      */       } else {
/*  984 */         arrayOfString2[b3] = DOMUtils.getAttribute(element, "class");
/*      */       } 
/*  986 */       if (arrayOfString2[b3] == null)
/*      */       {
/*  988 */         throw new IllegalArgumentException("'class' attribute is required in faultListener element");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  993 */     serviceDeploymentDescriptor.setFaultListener(arrayOfString2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  998 */     nodeList = paramElement.getElementsByTagNameNS(str1, "mappings");
/*      */     
/* 1000 */     if (nodeList != null && nodeList.getLength() > 1)
/*      */     {
/* 1002 */       throw new IllegalArgumentException("at most one 'mappings' element is allowed in service descriptor");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1007 */     if (nodeList != null && nodeList.getLength() == 1) {
/*      */       
/* 1009 */       element1 = (Element)nodeList.item(0);
/*      */       
/* 1011 */       String str = DOMUtils.getAttribute(element1, "defaultRegistryClass");
/* 1012 */       if (str != null)
/*      */       {
/* 1014 */         serviceDeploymentDescriptor.setDefaultSMRClass(str);
/*      */       }
/*      */       
/* 1017 */       nodeList = element1.getElementsByTagNameNS(str1, "map");
/*      */       
/* 1019 */       if (nodeList != null) {
/*      */         
/* 1021 */         int j = nodeList.getLength();
/* 1022 */         Hashtable hashtable = null;
/* 1023 */         if (j > 0) {
/*      */           
/* 1025 */           TypeMapping[] arrayOfTypeMapping = new TypeMapping[j];
/* 1026 */           for (byte b = 0; b < j; b++) {
/*      */             
/* 1028 */             element1 = (Element)nodeList.item(b);
/* 1029 */             QName qName = DOMUtils.getQualifiedAttributeValue(element1, "qname");
/*      */             
/* 1031 */             String str9 = DOMUtils.getAttribute(element1, "javaType");
/* 1032 */             String str10 = DOMUtils.getAttribute(element1, "sqlType");
/* 1033 */             if (ServerUtils.isNull(str10))
/* 1034 */               str10 = null; 
/* 1035 */             arrayOfTypeMapping[b] = new TypeMapping(DOMUtils.getAttribute(element1, "encodingStyle"), qName, str9, DOMUtils.getAttribute(element1, "java2XMLClassName"), DOMUtils.getAttribute(element1, "xml2JavaClassName"), str10);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1044 */             if (str10 != null) {
/*      */               
/* 1046 */               if (hashtable == null)
/* 1047 */                 hashtable = new Hashtable(); 
/* 1048 */               hashtable.put(str10, str9);
/*      */             } 
/*      */           } 
/*      */           
/* 1052 */           serviceDeploymentDescriptor.setTypeMappings(arrayOfTypeMapping);
/*      */           
/* 1054 */           if (hashtable != null) {
/* 1055 */             serviceDeploymentDescriptor.setSqlMap(hashtable);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1060 */     return serviceDeploymentDescriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void toXML(Writer paramWriter) {
/*      */     String str;
/* 1074 */     PrintWriter printWriter = new PrintWriter(paramWriter);
/*      */     
/* 1076 */     boolean bool = false;
/*      */     
/* 1078 */     if (this.m_isApacheDescriptor) {
/* 1079 */       str = "http://xml.apache.org/xml-soap/deployment";
/*      */     } else {
/* 1081 */       str = "http://xmlns.oracle.com/soap/2001/04/deploy/service";
/*      */     } 
/* 1083 */     printWriter.println("<isd:service xmlns:isd=\"" + str + "\"");
/* 1084 */     printWriter.println("    id=\"" + this.m_id + "\"");
/* 1085 */     printWriter.println("    type=\"" + m_serviceTypeNames[this.m_serviceType] + "\"");
/* 1086 */     printWriter.println("    checkMustUnderstands=\"" + this.m_checkMustUnderstands + "\" >");
/*      */ 
/*      */     
/* 1089 */     printWriter.println("");
/* 1090 */     printWriter.println("  <isd:provider");
/* 1091 */     byte b = this.m_providerType;
/* 1092 */     if (this.m_isApacheDescriptor) {
/*      */       String str1;
/*      */       
/* 1095 */       if (b == 0) {
/*      */         
/* 1097 */         str1 = "java";
/* 1098 */         bool = true;
/*      */       }
/* 1100 */       else if (b == 3) {
/* 1101 */         str1 = this.m_providerClass;
/*      */       } else {
/* 1103 */         str1 = "unknown";
/*      */       } 
/* 1105 */       printWriter.println("    type=\"" + str1 + "\"");
/*      */     }
/*      */     else {
/*      */       
/* 1109 */       printWriter.println("    id=\"" + this.m_providerId + "\"");
/* 1110 */       if (this.m_providerId.equals("java-provider")) {
/* 1111 */         bool = true;
/*      */       }
/*      */     } 
/* 1114 */     if (this.m_methods != null) {
/*      */       
/* 1116 */       printWriter.print("    methods=\"");
/* 1117 */       for (byte b1 = 0; b1 < this.m_methods.length; b1++) {
/*      */         
/* 1119 */         printWriter.print(this.m_methods[b1]);
/* 1120 */         if (b1 < this.m_methods.length - 1)
/* 1121 */           printWriter.print(" "); 
/*      */       } 
/* 1123 */       printWriter.println("\"");
/*      */     } 
/*      */     
/* 1126 */     printWriter.println("    scope=\"" + m_scopeNames[this.m_scope] + "\" >");
/*      */     
/* 1128 */     printWriter.println("");
/*      */ 
/*      */     
/* 1131 */     if (this.m_serviceClass != null)
/*      */     {
/* 1133 */       printWriter.println("    <isd:java class=\"" + this.m_serviceClass + "\" static=\"" + this.m_isStatic + "\"/>");
/*      */     }
/*      */ 
/*      */     
/* 1137 */     if (this.m_providerOptions.size() > 0) {
/*      */       
/* 1139 */       Enumeration enumeration = this.m_providerOptions.keys();
/* 1140 */       while (enumeration.hasMoreElements()) {
/*      */         
/* 1142 */         String str1 = enumeration.nextElement();
/* 1143 */         String str2 = (String)this.m_providerOptions.get(str1);
/* 1144 */         printWriter.println("    <isd:option key=\"" + str1 + "\" value=\"" + str2 + "\" />");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1150 */     printWriter.println("  </isd:provider>");
/*      */     
/* 1152 */     if (this.m_faultListener != null) {
/*      */       
/* 1154 */       printWriter.println("");
/*      */       
/* 1156 */       for (byte b1 = 0; b1 < this.m_faultListener.length; b1++) {
/*      */         
/* 1158 */         if (this.m_isApacheDescriptor) {
/*      */           
/* 1160 */           printWriter.println("  <isd:faultListener>" + this.m_faultListener[b1] + "</isd:faultListener>");
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1165 */           printWriter.println("  <isd:faultListener class=\"" + this.m_faultListener[b1] + "\"/>");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1172 */     if (this.m_typeMappings != null) {
/*      */       
/* 1174 */       printWriter.println("");
/* 1175 */       printWriter.print("  <isd:mappings");
/* 1176 */       if (this.m_defaultSMRClass != null) {
/*      */         
/* 1178 */         printWriter.println(" defaultRegistryClass=\"" + this.m_defaultSMRClass + "\">");
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1183 */         printWriter.println(">");
/*      */       } 
/*      */       
/* 1186 */       for (byte b1 = 0; b1 < this.m_typeMappings.length; b1++) {
/*      */         
/* 1188 */         TypeMapping typeMapping = this.m_typeMappings[b1];
/*      */         
/* 1190 */         printWriter.print("    <isd:map");
/*      */         
/* 1192 */         if (typeMapping.encodingStyle != null) {
/* 1193 */           printWriter.print(" encodingStyle=\"" + typeMapping.encodingStyle + "\"");
/*      */         }
/* 1195 */         printWriter.println();
/*      */         
/* 1197 */         if (typeMapping.elementType != null) {
/*      */           
/* 1199 */           printWriter.println("      xmlns:x=\"" + typeMapping.elementType.getNamespaceURI() + "\"");
/*      */           
/* 1201 */           printWriter.println("      qname=\"x:" + typeMapping.elementType.getLocalPart() + "\"");
/*      */         } 
/*      */ 
/*      */         
/* 1205 */         if (typeMapping.javaType != null)
/*      */         {
/* 1207 */           printWriter.print("      javaType=\"" + typeMapping.javaType + "\"");
/*      */         }
/*      */         
/* 1210 */         if (typeMapping.sqlType != null) {
/*      */           
/* 1212 */           printWriter.println("");
/* 1213 */           printWriter.print("      sqlType=\"" + typeMapping.sqlType + "\"");
/*      */         } 
/*      */         
/* 1216 */         if (typeMapping.xml2JavaClassName != null) {
/*      */           
/* 1218 */           printWriter.println("");
/* 1219 */           printWriter.print("      xml2JavaClassName=\"" + typeMapping.xml2JavaClassName + "\"");
/*      */         } 
/*      */         
/* 1222 */         if (typeMapping.java2XMLClassName != null) {
/*      */           
/* 1224 */           printWriter.println("");
/* 1225 */           printWriter.print("      java2XMLClassName=\"" + typeMapping.java2XMLClassName + "\"");
/*      */         } 
/*      */         
/* 1228 */         printWriter.println(" />");
/*      */       } 
/* 1230 */       printWriter.println("  </isd:mappings>");
/*      */     } 
/*      */     
/* 1233 */     printWriter.println("</isd:service>");
/* 1234 */     printWriter.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1245 */     StringBuffer stringBuffer1 = new StringBuffer();
/*      */ 
/*      */     
/* 1248 */     String str = m_serviceTypeNames[this.m_serviceType];
/*      */     
/* 1250 */     stringBuffer1.append("Service Id = " + this.m_id + "\n");
/* 1251 */     stringBuffer1.append("ServiceType = " + str + "\n");
/*      */     
/* 1253 */     stringBuffer1.append("Provider Id = " + this.m_providerId + "\n");
/* 1254 */     stringBuffer1.append("Provider Type = " + this.m_providerType + "\n");
/* 1255 */     stringBuffer1.append("Scope = " + m_scopeNames[this.m_scope] + "\n");
/*      */     
/* 1257 */     StringBuffer stringBuffer2 = new StringBuffer("["); byte b;
/* 1258 */     for (b = 0; b < this.m_methods.length; b++) {
/*      */       
/* 1260 */       stringBuffer2.append(this.m_methods[b]);
/* 1261 */       if (b < this.m_methods.length - 1)
/* 1262 */         stringBuffer2.append(","); 
/*      */     } 
/* 1264 */     stringBuffer2.append("]");
/* 1265 */     stringBuffer1.append("Methods = " + stringBuffer2 + "\n");
/*      */     
/* 1267 */     stringBuffer1.append("Options:\n");
/* 1268 */     Enumeration enumeration = this.m_providerOptions.keys();
/* 1269 */     while (enumeration.hasMoreElements()) {
/*      */       
/* 1271 */       b = enumeration.nextElement();
/* 1272 */       Object object = this.m_providerOptions.get(b);
/*      */       
/* 1274 */       stringBuffer1.append("    name = '" + b + "', value = '" + object + "'\n");
/*      */     } 
/*      */     
/* 1277 */     stringBuffer1.append("Mappings:\n");
/* 1278 */     if (this.m_typeMappings != null)
/*      */     {
/* 1280 */       for (b = 0; b < this.m_typeMappings.length; b++) {
/*      */         
/* 1282 */         stringBuffer1.append(this.m_typeMappings[b].toString());
/* 1283 */         stringBuffer1.append("\n");
/*      */       } 
/*      */     }
/*      */     
/* 1287 */     if (this.m_sqlMap != null) {
/*      */       
/* 1289 */       stringBuffer1.append("SQL Map:\n");
/* 1290 */       enumeration = this.m_sqlMap.keys();
/* 1291 */       while (enumeration.hasMoreElements()) {
/*      */         
/* 1293 */         b = enumeration.nextElement();
/* 1294 */         Object object = this.m_sqlMap.get(b);
/*      */         
/* 1296 */         stringBuffer1.append("    sqlType = '" + b + "', javaType = '" + object + "'\n");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1301 */     stringBuffer1.append("FaultListener:\n");
/* 1302 */     if (this.m_faultListener != null)
/*      */     {
/* 1304 */       for (b = 0; b < this.m_faultListener.length; b++) {
/*      */         
/* 1306 */         stringBuffer1.append("    ");
/* 1307 */         stringBuffer1.append(this.m_faultListener[b]);
/* 1308 */         stringBuffer1.append("\n");
/*      */       } 
/*      */     }
/* 1311 */     return stringBuffer1.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SOAPMappingRegistry buildSOAPMappingRegistry(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor) {
/* 1327 */     return buildSOAPMappingRegistry(paramServiceDeploymentDescriptor, Thread.currentThread().getContextClassLoader());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SOAPMappingRegistry buildSOAPMappingRegistry(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor, ClassLoader paramClassLoader) {
/* 1343 */     TypeMapping[] arrayOfTypeMapping = paramServiceDeploymentDescriptor.getTypeMappings();
/* 1344 */     SOAPMappingRegistry sOAPMappingRegistry = paramServiceDeploymentDescriptor.getCachedSMR();
/*      */     
/* 1346 */     if (sOAPMappingRegistry != null)
/*      */     {
/* 1348 */       return sOAPMappingRegistry;
/*      */     }
/* 1350 */     if (paramServiceDeploymentDescriptor.getDefaultSMRClass() != null) {
/*      */       
/*      */       try {
/*      */         
/* 1354 */         if (paramClassLoader == null) {
/* 1355 */           sOAPMappingRegistry = (SOAPMappingRegistry)Class.forName(paramServiceDeploymentDescriptor.getDefaultSMRClass()).newInstance();
/*      */         } else {
/*      */           
/* 1358 */           sOAPMappingRegistry = (SOAPMappingRegistry)Class.forName(paramServiceDeploymentDescriptor.getDefaultSMRClass(), true, paramClassLoader).newInstance();
/*      */         }
/*      */       
/* 1361 */       } catch (Exception exception) {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1367 */     if (sOAPMappingRegistry == null) {
/*      */       
/* 1369 */       SOAPMappingRegistry sOAPMappingRegistry1 = SOAPMappingRegistry.getBaseRegistry("http://www.w3.org/2001/XMLSchema");
/*      */       
/* 1371 */       if (arrayOfTypeMapping == null) {
/*      */         
/* 1373 */         paramServiceDeploymentDescriptor.setCachedSMR(sOAPMappingRegistry1);
/* 1374 */         return sOAPMappingRegistry1;
/*      */       } 
/*      */ 
/*      */       
/* 1378 */       sOAPMappingRegistry = new SOAPMappingRegistry(sOAPMappingRegistry1);
/*      */     } 
/*      */ 
/*      */     
/* 1382 */     if (arrayOfTypeMapping != null)
/*      */     {
/* 1384 */       for (byte b = 0; b < arrayOfTypeMapping.length; b++) {
/*      */         
/* 1386 */         TypeMapping typeMapping = arrayOfTypeMapping[b];
/* 1387 */         byte b1 = 0;
/*      */         
/*      */         try {
/* 1390 */           b1 = 0;
/* 1391 */           Class clazz = null;
/* 1392 */           if (typeMapping.javaType != null)
/* 1393 */             if (paramClassLoader == null) {
/* 1394 */               clazz = Class.forName(typeMapping.javaType);
/*      */             } else {
/* 1396 */               clazz = Class.forName(typeMapping.javaType, true, paramClassLoader);
/*      */             }  
/* 1398 */           b1 = 1;
/* 1399 */           Serializer serializer = null;
/* 1400 */           if (typeMapping.java2XMLClassName != null) {
/*      */             Class clazz1;
/* 1402 */             if (paramClassLoader == null) {
/* 1403 */               clazz1 = Class.forName(typeMapping.java2XMLClassName);
/*      */             } else {
/* 1405 */               clazz1 = Class.forName(typeMapping.java2XMLClassName, true, paramClassLoader);
/* 1406 */             }  serializer = (Serializer)clazz1.newInstance();
/*      */           } 
/* 1408 */           b1 = 2;
/* 1409 */           Deserializer deserializer = null;
/* 1410 */           if (typeMapping.xml2JavaClassName != null) {
/*      */             Class clazz1;
/* 1412 */             if (paramClassLoader == null) {
/* 1413 */               clazz1 = Class.forName(typeMapping.xml2JavaClassName);
/*      */             } else {
/* 1415 */               clazz1 = Class.forName(typeMapping.xml2JavaClassName, true, paramClassLoader);
/* 1416 */             }  deserializer = (Deserializer)clazz1.newInstance();
/*      */           } 
/* 1418 */           sOAPMappingRegistry.mapTypes(typeMapping.encodingStyle, typeMapping.elementType, clazz, serializer, deserializer);
/* 1419 */         } catch (Exception exception) {
/*      */           
/* 1421 */           String str = "deployment error in SOAP service '" + paramServiceDeploymentDescriptor.getId() + "': ";
/*      */           
/* 1423 */           if (b1 == 0) {
/* 1424 */             str = str + "class name '" + typeMapping.javaType + "' could not be resolved: ";
/* 1425 */           } else if (b1 == 1) {
/* 1426 */             str = str + "class name '" + typeMapping.java2XMLClassName + "' could not be " + "resolved as a serializer: ";
/*      */           } else {
/*      */             
/* 1429 */             str = str + "class name '" + typeMapping.xml2JavaClassName + "' could not be " + "resolved as a deserializer: ";
/*      */           } 
/*      */           
/* 1432 */           throw new IllegalArgumentException(str + exception.getMessage());
/*      */         } 
/*      */       } 
/*      */     }
/* 1436 */     paramServiceDeploymentDescriptor.setCachedSMR(sOAPMappingRegistry);
/* 1437 */     return sOAPMappingRegistry;
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\ServiceDeploymentDescriptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */