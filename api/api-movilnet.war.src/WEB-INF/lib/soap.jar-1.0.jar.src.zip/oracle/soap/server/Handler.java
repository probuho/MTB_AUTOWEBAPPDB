package oracle.soap.server;

import java.util.Properties;
import org.apache.soap.SOAPException;

public interface Handler {
  public static final int REQUEST_TYPE = 1;
  
  public static final int RESPONSE_TYPE = 2;
  
  public static final int ERROR_TYPE = 3;
  
  void init(SOAPServerContext paramSOAPServerContext) throws SOAPException;
  
  void setOptions(Properties paramProperties);
  
  Properties getOptions();
  
  void setName(String paramString);
  
  String getName();
  
  void destroy() throws SOAPException;
  
  void invoke(int paramInt, RequestContext paramRequestContext) throws SOAPException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\Handler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */