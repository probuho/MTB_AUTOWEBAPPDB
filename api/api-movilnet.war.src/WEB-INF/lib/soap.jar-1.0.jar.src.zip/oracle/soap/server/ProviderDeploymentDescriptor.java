/*     */ package oracle.soap.server;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.Writer;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProviderDeploymentDescriptor
/*     */   extends DeploymentDescriptor
/*     */   implements Serializable
/*     */ {
/*     */   private String m_classname;
/*  49 */   private Hashtable m_options = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassname(String paramString) {
/*  63 */     this.m_classname = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassname() {
/*  77 */     return this.m_classname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptions(Hashtable paramHashtable) {
/*  92 */     this.m_options = paramHashtable;
/*     */     
/*  94 */     if (this.m_options == null) {
/*  95 */       this.m_options = new Hashtable();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getOptions() {
/* 110 */     return this.m_options;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProviderDeploymentDescriptor fromXML(Element paramElement) {
/* 126 */     String str1 = null;
/* 127 */     String str2 = null;
/*     */     
/* 129 */     if (paramElement == null)
/*     */     {
/* 131 */       throw new IllegalArgumentException("root is null");
/*     */     }
/*     */ 
/*     */     
/* 135 */     if (!paramElement.getNamespaceURI().equals("http://xmlns.oracle.com/soap/2001/04/deploy/provider") || !paramElement.getLocalName().equals("provider"))
/*     */     {
/*     */ 
/*     */       
/* 139 */       throw new IllegalArgumentException("document root element is not http://xmlns.oracle.com/soap/2001/04/deploy/provider:provider");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     ProviderDeploymentDescriptor providerDeploymentDescriptor = new ProviderDeploymentDescriptor();
/*     */     
/* 147 */     str1 = DOMUtils.getAttribute(paramElement, "id");
/* 148 */     if (str1 == null)
/*     */     {
/* 150 */       throw new IllegalArgumentException("required 'id' attribute missing in provider descriptor");
/*     */     }
/*     */     
/* 153 */     providerDeploymentDescriptor.setId(str1);
/*     */     
/* 155 */     str2 = DOMUtils.getAttribute(paramElement, "class");
/* 156 */     if (str2 == null)
/*     */     {
/* 158 */       throw new IllegalArgumentException("required 'class' attribute missing in provider descriptor");
/*     */     }
/*     */     
/* 161 */     providerDeploymentDescriptor.setClassname(str2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */     
/* 170 */     NodeList nodeList = paramElement.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/deploy/provider", "option");
/*     */     
/* 172 */     if (nodeList != null)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 177 */       for (byte b = 0; b < nodeList.getLength(); b++) {
/*     */         
/* 179 */         Element element = (Element)nodeList.item(b);
/* 180 */         String str3 = DOMUtils.getAttribute(element, "key");
/* 181 */         String str4 = DOMUtils.getAttribute(element, "value");
/*     */         
/* 183 */         if (str3 == null || str3.equals(""))
/*     */         {
/* 185 */           throw new IllegalArgumentException("Missing 'key' attribute on 'option' element in provider descriptor");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 190 */         if (str4 == null)
/*     */         {
/* 192 */           throw new IllegalArgumentException("Missing 'value' attribute on 'option' element in provider descriptor (key=\"" + str3 + "\")");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 197 */         hashtable.put(str3, str4);
/*     */       } 
/*     */     }
/* 200 */     providerDeploymentDescriptor.setOptions(hashtable);
/*     */     
/* 202 */     return providerDeploymentDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toXML(Writer paramWriter) {
/* 216 */     PrintWriter printWriter = new PrintWriter(paramWriter);
/*     */     
/* 218 */     printWriter.println("<isd:provider xmlns:isd=\"http://xmlns.oracle.com/soap/2001/04/deploy/provider\"");
/*     */     
/* 220 */     printWriter.println("    id=\"" + this.m_id + "\"");
/* 221 */     printWriter.println("    class=\"" + this.m_classname + "\">");
/*     */     
/* 223 */     printWriter.println("");
/*     */     
/* 225 */     if (this.m_options.size() > 0)
/*     */     {
/* 227 */       for (Enumeration enumeration = this.m_options.keys(); enumeration.hasMoreElements(); ) {
/*     */         
/* 229 */         String str1 = enumeration.nextElement();
/* 230 */         String str2 = (String)this.m_options.get(str1);
/* 231 */         printWriter.println("    <isd:option key=\"" + str1 + "\" value=\"" + str2 + "\" />");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 237 */     printWriter.println("</isd:provider>");
/* 238 */     printWriter.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 245 */     StringBuffer stringBuffer = new StringBuffer();
/* 246 */     Enumeration enumeration = null;
/*     */     
/* 248 */     stringBuffer.append("Provider Id        = " + this.m_id + "\n");
/* 249 */     stringBuffer.append("Provider Classname = " + this.m_classname + "\n");
/*     */     
/* 251 */     stringBuffer.append("Options:\n");
/* 252 */     enumeration = this.m_options.keys();
/* 253 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 255 */       String str = (String)enumeration.nextElement();
/* 256 */       Object object = this.m_options.get(str);
/*     */       
/* 258 */       stringBuffer.append("    name = '" + str + "', value = '" + object + "'\n");
/*     */     } 
/*     */     
/* 261 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\ProviderDeploymentDescriptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */