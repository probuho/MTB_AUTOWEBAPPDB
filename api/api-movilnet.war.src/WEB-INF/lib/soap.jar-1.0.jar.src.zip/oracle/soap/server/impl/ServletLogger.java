/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import oracle.soap.server.ContainerContext;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletLogger
/*     */   extends Logger
/*     */ {
/*  42 */   private HttpServlet m_servlet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Properties paramProperties, ContainerContext paramContainerContext) throws SOAPException {
/*  63 */     String str1 = paramProperties.getProperty("severity");
/*  64 */     if (str1 != null) {
/*     */       
/*  66 */       int i = getSeverityValue(str1);
/*  67 */       if (i != 3) {
/*  68 */         this.m_severity = i;
/*     */       }
/*     */     } 
/*  71 */     if (paramContainerContext == null)
/*     */     {
/*  73 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "unable to initialize ServletLogger with null context");
/*     */     }
/*     */ 
/*     */     
/*  77 */     String str2 = paramContainerContext.getContainerType();
/*  78 */     if (str2 == null)
/*     */     {
/*  80 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "unable to initialize ServletLogger in unknown container type");
/*     */     }
/*     */ 
/*     */     
/*  84 */     if (!str2.equals("servlet"))
/*     */     {
/*  86 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "unable to initialize ServletLogger in '" + str2 + "' container");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  91 */     this.m_servlet = paramContainerContext.getHttpServlet();
/*     */     
/*  93 */     if (this.m_servlet == null)
/*     */     {
/*  95 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "unable to initialize ServletLogger: HTTP servlet is not set in context");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String paramString, int paramInt) {
/* 116 */     if (isLoggable(paramInt))
/*     */     {
/* 118 */       this.m_servlet.log(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String paramString, Throwable paramThrowable, int paramInt) {
/* 139 */     if (isLoggable(paramInt))
/*     */     {
/* 141 */       this.m_servlet.log(paramString + ": " + paramThrowable.getMessage() + "\n" + ServerUtils.getStackTrace(paramThrowable));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(Throwable paramThrowable, int paramInt) {
/* 161 */     if (isLoggable(paramInt))
/*     */     {
/* 163 */       this.m_servlet.log(paramThrowable.getMessage() + "\n" + ServerUtils.getStackTrace(paramThrowable));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\ServletLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */