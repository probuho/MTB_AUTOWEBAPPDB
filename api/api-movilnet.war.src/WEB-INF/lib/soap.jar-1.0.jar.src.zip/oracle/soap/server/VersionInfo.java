/*    */ package oracle.soap.server;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VersionInfo
/*    */ {
/*    */   public static final String SOAP_VERSION = "9.0.0.2";
/*    */   
/*    */   public static String getVersion() {
/* 15 */     return "9.0.0.2";
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\VersionInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */