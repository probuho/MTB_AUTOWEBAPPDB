/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.server.http.ServerHTTPUtils;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLProviderConfigManager
/*     */   extends BaseConfigManager
/*     */ {
/*     */   public static final String OPTION_FILENAME = "filename";
/*  52 */   public static final String DEFAULT_FILENAME = "WEB-INF" + File.separator + "providers.xml";
/*     */ 
/*     */   
/*  55 */   private String m_registryFilename = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptions(Properties paramProperties) throws SOAPException {
/*  71 */     this.m_registryFilename = paramProperties.getProperty("filename");
/*     */     
/*  73 */     if (ServerUtils.isNull(this.m_registryFilename))
/*     */     {
/*  75 */       this.m_registryFilename = DEFAULT_FILENAME;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void readRegistry() throws SOAPException {
/*  88 */     this.m_registry = new Hashtable();
/*     */ 
/*     */     
/*     */     try {
/*  92 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */       
/*  94 */       InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file), "UTF8");
/*     */       
/*  96 */       Document document = null;
/*  97 */       Element element = null;
/*  98 */       DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*     */       
/* 100 */       document = documentBuilder.parse(new InputSource(inputStreamReader));
/* 101 */       element = document.getDocumentElement();
/* 102 */       inputStreamReader.close();
/*     */       
/* 104 */       NodeList nodeList = element.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/deploy/provider", "provider");
/*     */ 
/*     */       
/* 107 */       int i = nodeList.getLength();
/* 108 */       for (byte b = 0; b < i; b++)
/*     */       {
/* 110 */         Element element1 = (Element)nodeList.item(b);
/* 111 */         ProviderDeploymentDescriptor providerDeploymentDescriptor = ProviderDeploymentDescriptor.fromXML(element1);
/*     */         
/* 113 */         String str = providerDeploymentDescriptor.getId();
/* 114 */         this.m_registry.put(str, providerDeploymentDescriptor);
/*     */       }
/*     */     
/* 117 */     } catch (FileNotFoundException fileNotFoundException) {
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 122 */     catch (Exception exception) {
/*     */       
/* 124 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error reading providers registry: " + exception.toString(), exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void writeRegistry() throws SOAPException {
/*     */     try {
/* 135 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */       
/* 137 */       PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF8"));
/*     */       
/* 139 */       Enumeration enumeration = this.m_registry.elements();
/*     */       
/* 141 */       printWriter.println("<deployedProviders>");
/* 142 */       printWriter.println();
/* 143 */       while (enumeration.hasMoreElements()) {
/*     */         
/* 145 */         ProviderDeploymentDescriptor providerDeploymentDescriptor = enumeration.nextElement();
/*     */         
/* 147 */         providerDeploymentDescriptor.toXML(printWriter);
/* 148 */         printWriter.println();
/*     */       } 
/* 150 */       printWriter.println("</deployedProviders>");
/*     */       
/* 152 */       printWriter.close();
/*     */     }
/* 154 */     catch (Exception exception) {
/*     */       
/* 156 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error writing providers registry: " + exception.toString(), exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\XMLProviderConfigManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */