package oracle.soap.server;

import org.apache.soap.SOAPException;

public interface Provider {
  void init(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor, SOAPServerContext paramSOAPServerContext) throws SOAPException;
  
  void destroy() throws SOAPException;
  
  String getId();
  
  void invoke(RequestContext paramRequestContext) throws SOAPException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\Provider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */