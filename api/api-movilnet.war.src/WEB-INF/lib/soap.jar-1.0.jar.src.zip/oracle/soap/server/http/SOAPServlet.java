/*      */ package oracle.soap.server.http;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import oracle.dms.instrument.Noun;
/*      */ import oracle.dms.instrument.PhaseEvent;
/*      */ import oracle.soap.server.ContainerContext;
/*      */ import oracle.soap.server.Handler;
/*      */ import oracle.soap.server.Logger;
/*      */ import oracle.soap.server.OracleSOAPContext;
/*      */ import oracle.soap.server.Provider;
/*      */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*      */ import oracle.soap.server.ProviderManager;
/*      */ import oracle.soap.server.RequestContext;
/*      */ import oracle.soap.server.SOAPServerContext;
/*      */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*      */ import oracle.soap.server.ServiceManager;
/*      */ import oracle.soap.server.util.ServerUtils;
/*      */ import oracle.soap.util.xml.XmlUtils;
/*      */ import org.apache.soap.Constants;
/*      */ import org.apache.soap.Envelope;
/*      */ import org.apache.soap.Fault;
/*      */ import org.apache.soap.Header;
/*      */ import org.apache.soap.SOAPException;
/*      */ import org.apache.soap.Utils;
/*      */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*      */ import org.apache.soap.rpc.Response;
/*      */ import org.apache.soap.rpc.SOAPContext;
/*      */ import org.apache.soap.server.SOAPFaultRouter;
/*      */ import org.apache.soap.server.http.ServerHTTPUtils;
/*      */ import org.apache.soap.transport.EnvelopeEditor;
/*      */ import org.apache.soap.transport.EnvelopeEditorFactory;
/*      */ import org.apache.soap.transport.TransportMessage;
/*      */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*      */ import org.apache.soap.util.xml.XMLParserUtils;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SOAPServlet
/*      */   extends HttpServlet
/*      */ {
/*   67 */   public static final String DEFAULT_CONFIG_FILENAME = "WEB-INF" + File.separator + "soap.xml";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   private Hashtable m_providerMap = null;
/*      */   
/*      */   private ProviderManager m_providerManager;
/*      */   
/*      */   private ServiceManager m_serviceManager;
/*      */   
/*      */   private ContainerContext m_containerContext;
/*      */   
/*      */   private SOAPServerContext m_soapServerContext;
/*      */   private Logger m_log;
/*      */   private boolean m_pathAuth;
/*  113 */   private Hashtable m_globalHandlers = null;
/*      */ 
/*      */   
/*  116 */   private Hashtable m_activeGlobalHandlers = null;
/*  117 */   private Handler[] m_globalRequestChain = null;
/*  118 */   private Handler[] m_globalResponseChain = null;
/*  119 */   private Handler[] m_globalErrorChain = null;
/*      */ 
/*      */   
/*      */   private Hashtable m_globalContext;
/*      */ 
/*      */   
/*  125 */   private SOAPFaultRouter m_faultRouter = null;
/*      */ 
/*      */   
/*      */   private PhaseEvent m_serverPhaseEvent;
/*      */   
/*  130 */   private EnvelopeEditor m_editor = null;
/*  131 */   private String m_configFilename = null;
/*  132 */   private ServletContext m_servletContext = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() throws ServletException {
/*  144 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*      */ 
/*      */ 
/*      */     
/*  148 */     ServletConfig servletConfig = getServletConfig();
/*  149 */     this.m_servletContext = servletConfig.getServletContext();
/*  150 */     String str1 = servletConfig.getInitParameter("EnvelopeEditorFactory");
/*      */ 
/*      */ 
/*      */     
/*  154 */     if (str1 != null) {
/*      */       try {
/*      */         EnvelopeEditorFactory envelopeEditorFactory;
/*  157 */         StringBuffer stringBuffer = new StringBuffer();
/*      */         
/*  159 */         Object object = ServerUtils.createObject(str1, classLoader, stringBuffer);
/*      */         
/*  161 */         if (object == null)
/*      */         {
/*  163 */           throw new ServletException("Cannot load envelope editor factory defined (" + str1 + ") " + stringBuffer.toString());
/*      */         }
/*      */ 
/*      */         
/*  167 */         if (object instanceof EnvelopeEditorFactory) {
/*      */           
/*  169 */           envelopeEditorFactory = (EnvelopeEditorFactory)object;
/*      */         }
/*      */         else {
/*      */           
/*  173 */           throw new ServletException("Envelope editory factory defined (" + str1 + ") is of incorrect type");
/*      */         } 
/*      */         
/*  176 */         if (envelopeEditorFactory != null) {
/*      */           
/*  178 */           Properties properties = new Properties();
/*  179 */           Enumeration enumeration = servletConfig.getInitParameterNames();
/*      */           
/*  181 */           while (enumeration.hasMoreElements()) {
/*      */             
/*  183 */             String str3 = enumeration.nextElement();
/*      */             
/*  185 */             if (!"EnvelopeEditorFactory".equals(str3) && !"XMLParser".equals(str3))
/*      */             {
/*      */               
/*  188 */               properties.put(str3, servletConfig.getInitParameter(str3));
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/*  193 */           String str = this.m_servletContext.getRealPath("");
/*      */           
/*  195 */           if (str != null)
/*      */           {
/*  197 */             properties.put("SOAPServerContextPath", str);
/*      */           }
/*      */ 
/*      */           
/*  201 */           this.m_editor = envelopeEditorFactory.create(properties);
/*      */         } 
/*  203 */       } catch (SOAPException sOAPException) {
/*  204 */         throw new ServletException("Can't create envelope editor" + sOAPException.getMessage());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  209 */     String str2 = servletConfig.getInitParameter("ConfigFile");
/*      */ 
/*      */ 
/*      */     
/*  213 */     if (str2 == null || str2.trim().equals("")) {
/*      */       
/*  215 */       this.m_configFilename = DEFAULT_CONFIG_FILENAME;
/*      */     }
/*      */     else {
/*      */       
/*  219 */       this.m_configFilename = str2;
/*      */     } 
/*      */     
/*  222 */     str2 = servletConfig.getInitParameter("XMLParser");
/*      */ 
/*      */     
/*  225 */     if (str2 == null)
/*      */     {
/*  227 */       str2 = "oracle.xml.jaxp.JXDocumentBuilderFactory";
/*      */     }
/*      */     
/*  230 */     XMLParserUtils.refreshDocumentBuilderFactory(str2, true, false);
/*      */ 
/*      */ 
/*      */     
/*  234 */     ServerHTTPUtils.setServletClassLoaderIntoContext(this.m_servletContext, classLoader);
/*      */ 
/*      */     
/*  237 */     Noun noun = Noun.create("|Soap", "SoapServer");
/*      */     
/*  239 */     this.m_serverPhaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Server");
/*      */ 
/*      */     
/*  242 */     this.m_serverPhaseEvent.deriveMetric(511);
/*      */     
/*  244 */     this.m_globalContext = new Hashtable();
/*      */ 
/*      */     
/*  247 */     this.m_containerContext = new ContainerContext();
/*  248 */     this.m_containerContext.setContainerType("servlet");
/*  249 */     this.m_containerContext.setHttpServlet(this);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  254 */       parseConfigFile();
/*      */ 
/*      */       
/*  257 */       this.m_providerMap = new Hashtable();
/*      */     }
/*  259 */     catch (SOAPException sOAPException) {
/*      */ 
/*      */       
/*  262 */       throw new ServletException(sOAPException.getMessage());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  270 */       String[] arrayOfString = this.m_providerManager.list();
/*      */       
/*  272 */       if (this.m_log.isLoggable(2))
/*      */       {
/*  274 */         this.m_log.log("Creating providers", 2);
/*      */       }
/*      */       
/*  277 */       for (byte b = 0; b < arrayOfString.length; b++)
/*      */       {
/*      */         try
/*      */         {
/*  281 */           setupProvider(arrayOfString[b]);
/*      */         }
/*  283 */         catch (Exception exception)
/*      */         {
/*  285 */           if (this.m_log.isLoggable(0)) {
/*  286 */             this.m_log.log("Unable to init provider '" + arrayOfString[b] + "': " + exception.getMessage(), 0);
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  299 */     catch (SOAPException sOAPException) {
/*      */       
/*  301 */       if (this.m_log.isLoggable(2))
/*      */       {
/*  303 */         this.m_log.log("Failed to access deployed providers." + sOAPException.getMessage(), (Throwable)sOAPException, 2);
/*      */       }
/*      */ 
/*      */       
/*  307 */       throw new ServletException(sOAPException.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseConfigFile() throws SOAPException {
/*  324 */     if (!(new File(this.m_configFilename)).isAbsolute())
/*      */     {
/*  326 */       this.m_configFilename = this.m_servletContext.getRealPath(File.separator + this.m_configFilename);
/*      */     }
/*      */     
/*  329 */     Document document = XmlUtils.parseXml(this.m_configFilename);
/*  330 */     Element element = document.getDocumentElement();
/*  331 */     ServerUtils.checkSoapConfigRootElement(element);
/*  332 */     this.m_pathAuth = ServerUtils.getPathAuth(element);
/*      */ 
/*      */ 
/*      */     
/*  336 */     String[] arrayOfString = ServerUtils.getFaultListeners(element);
/*  337 */     this.m_faultRouter = ServerUtils.buildFaultRouter(arrayOfString, ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext));
/*      */ 
/*      */ 
/*      */     
/*  341 */     this.m_providerManager = ServerUtils.createProviderManager(element, ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext), this.m_servletContext);
/*      */ 
/*      */     
/*  344 */     this.m_serviceManager = ServerUtils.createServiceManager(element, this.m_providerManager, ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext), this.m_servletContext);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  349 */     this.m_providerManager.setServiceManager(this.m_serviceManager);
/*      */     
/*  351 */     this.m_log = ServerUtils.createLogger(element, this.m_containerContext, ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext));
/*      */ 
/*      */ 
/*      */     
/*  355 */     this.m_globalContext.put("urn:soap-service-manager", this.m_serviceManager);
/*      */     
/*  357 */     this.m_globalContext.put("urn:soap-provider-manager", this.m_providerManager);
/*      */ 
/*      */ 
/*      */     
/*  361 */     this.m_soapServerContext = new SOAPServerContext();
/*  362 */     this.m_soapServerContext.setGlobalContext(this.m_globalContext);
/*  363 */     this.m_soapServerContext.setLogger(this.m_log);
/*      */ 
/*      */     
/*  366 */     createHandlers(element);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createHandlers(Element paramElement) throws SOAPException {
/*  377 */     this.m_globalHandlers = ServerUtils.createHandlers(paramElement, ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext));
/*      */     
/*  379 */     String[] arrayOfString1 = ServerUtils.getRequestHandlers(paramElement);
/*  380 */     String[] arrayOfString2 = ServerUtils.getResponseHandlers(paramElement);
/*  381 */     String[] arrayOfString3 = ServerUtils.getErrorHandlers(paramElement);
/*      */     
/*  383 */     this.m_globalRequestChain = new Handler[arrayOfString1.length];
/*  384 */     this.m_globalResponseChain = new Handler[arrayOfString2.length];
/*  385 */     this.m_globalErrorChain = new Handler[arrayOfString3.length];
/*  386 */     this.m_activeGlobalHandlers = new Hashtable();
/*      */     byte b;
/*  388 */     for (b = 0; b < arrayOfString1.length; b++) {
/*      */       
/*  390 */       Handler handler = (Handler)this.m_globalHandlers.get(arrayOfString1[b]);
/*      */       
/*  392 */       if (handler == null)
/*      */       {
/*  394 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "request handler '" + arrayOfString1[b] + "' is not defined");
/*      */       }
/*      */ 
/*      */       
/*  398 */       if (this.m_activeGlobalHandlers.get(arrayOfString1[b]) == null) {
/*      */ 
/*      */         
/*  401 */         if (this.m_log.isLoggable(1))
/*      */         {
/*  403 */           this.m_log.log("activating handler '" + arrayOfString1[b] + "'", 1);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  408 */         handler.init(this.m_soapServerContext);
/*  409 */         this.m_activeGlobalHandlers.put(arrayOfString1[b], handler);
/*      */         
/*  411 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  413 */           this.m_log.log("handler '" + arrayOfString1[b] + "' activated", 2);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  418 */       this.m_globalRequestChain[b] = handler;
/*      */     } 
/*      */ 
/*      */     
/*  422 */     for (b = 0; b < arrayOfString2.length; b++) {
/*      */       
/*  424 */       Handler handler = null;
/*  425 */       if ((handler = (Handler)this.m_globalHandlers.get(arrayOfString2[b])) == null)
/*      */       {
/*  427 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "response handler '" + arrayOfString2[b] + "' is not defined");
/*      */       }
/*      */ 
/*      */       
/*  431 */       if (this.m_activeGlobalHandlers.get(arrayOfString2[b]) == null) {
/*      */ 
/*      */         
/*  434 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  436 */           this.m_log.log("activating handler '" + arrayOfString2[b] + "'", 2);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  441 */         handler.init(this.m_soapServerContext);
/*  442 */         this.m_activeGlobalHandlers.put(arrayOfString2[b], handler);
/*      */         
/*  444 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  446 */           this.m_log.log("handler '" + arrayOfString2[b] + "' activated", 2);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  451 */       this.m_globalResponseChain[b] = handler;
/*      */     } 
/*      */ 
/*      */     
/*  455 */     for (b = 0; b < arrayOfString3.length; b++) {
/*      */       
/*  457 */       Handler handler = (Handler)this.m_globalHandlers.get(arrayOfString3[b]);
/*      */       
/*  459 */       if (handler == null)
/*      */       {
/*  461 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "error handler '" + arrayOfString3[b] + "' is not defined");
/*      */       }
/*      */ 
/*      */       
/*  465 */       if (this.m_activeGlobalHandlers.get(arrayOfString3[b]) == null) {
/*      */         
/*  467 */         if (this.m_log.isLoggable(1))
/*      */         {
/*  469 */           this.m_log.log("activating handler '" + arrayOfString3[b] + "'", 1);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  474 */         handler.init(this.m_soapServerContext);
/*  475 */         this.m_activeGlobalHandlers.put(arrayOfString3[b], handler);
/*      */         
/*  477 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  479 */           this.m_log.log("handler '" + arrayOfString3[b] + "' activated", 2);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  484 */       this.m_globalErrorChain[b] = handler;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setupProvider(String paramString) throws SOAPException {
/*  499 */     ProviderDeploymentDescriptor providerDeploymentDescriptor = this.m_providerManager.query(paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  504 */     Provider provider = ServerUtils.createProvider(providerDeploymentDescriptor.getClassname(), ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext));
/*      */     
/*  506 */     provider.init(providerDeploymentDescriptor, this.m_soapServerContext);
/*  507 */     this.m_providerMap.put(provider.getId(), provider);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void destroy() {
/*  516 */     Enumeration enumeration = this.m_providerMap.elements();
/*      */ 
/*      */     
/*  519 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  521 */       Provider provider = enumeration.nextElement();
/*  522 */       String str = provider.getId();
/*      */       
/*      */       try {
/*  525 */         if (this.m_log.isLoggable(999))
/*  526 */           this.m_log.log("destroying provider '" + str + "'", 999); 
/*  527 */         provider.destroy();
/*  528 */         if (this.m_log.isLoggable(999)) {
/*  529 */           this.m_log.log("provider '" + str + "' destroyed", 999);
/*      */         }
/*  531 */       } catch (Throwable throwable) {
/*      */         
/*  533 */         if (this.m_log.isLoggable(0)) {
/*  534 */           this.m_log.log("error destroying provider '" + str + "'", 0);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  543 */     enumeration = this.m_activeGlobalHandlers.keys();
/*      */     
/*  545 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  547 */       String str = (String)enumeration.nextElement();
/*  548 */       Handler handler = (Handler)this.m_activeGlobalHandlers.get(str);
/*      */       
/*      */       try {
/*  551 */         if (this.m_log.isLoggable(1))
/*      */         {
/*  553 */           this.m_log.log("destroying handler '" + str + "'", 1);
/*      */         }
/*      */ 
/*      */         
/*  557 */         handler.destroy();
/*  558 */         this.m_activeGlobalHandlers.remove(str);
/*      */       }
/*  560 */       catch (Throwable throwable) {
/*      */         
/*  562 */         if (this.m_log.isLoggable(0))
/*      */         {
/*  564 */           this.m_log.log("error destroying handler '" + str + "'", 0);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/*  580 */     PrintWriter printWriter = paramHttpServletResponse.getWriter();
/*      */     
/*  582 */     paramHttpServletResponse.setContentType("text/html");
/*  583 */     printWriter.println("<html><head><title>SOAP Server</title></head>");
/*  584 */     printWriter.println("<body><h1>SOAP Server</h1>");
/*  585 */     printWriter.println("<p>Sorry, I don't speak via HTTP GET- you have to use");
/*  586 */     printWriter.println("HTTP POST to talk to me.</p></body></html>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/*  597 */     ServletConfig servletConfig = getServletConfig();
/*  598 */     ServletContext servletContext = servletConfig.getServletContext();
/*  599 */     Provider provider = null;
/*  600 */     Response response = null;
/*  601 */     RequestContext requestContext = new RequestContext();
/*  602 */     String str1 = null;
/*  603 */     String str2 = null;
/*  604 */     char c = 'È';
/*  605 */     ServiceDeploymentDescriptor serviceDeploymentDescriptor = null;
/*      */     
/*  607 */     OracleSOAPContext oracleSOAPContext1 = new OracleSOAPContext();
/*  608 */     OracleSOAPContext oracleSOAPContext2 = new OracleSOAPContext();
/*  609 */     Envelope envelope = null;
/*      */     
/*  611 */     boolean bool = true;
/*      */ 
/*      */     
/*  614 */     String str3 = paramHttpServletRequest.getPathInfo();
/*      */ 
/*      */     
/*  617 */     long l = 0L;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  622 */       l = this.m_serverPhaseEvent.start();
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  627 */         setReqCtxAttrs(oracleSOAPContext1, paramHttpServletRequest, paramHttpServletResponse);
/*      */ 
/*      */         
/*  630 */         DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  635 */         envelope = ServerHTTPUtils.readEnvelopeFromRequest(documentBuilder, paramHttpServletRequest.getContentType(), paramHttpServletRequest.getContentLength(), (InputStream)paramHttpServletRequest.getInputStream(), this.m_editor, paramHttpServletResponse, (SOAPContext)oracleSOAPContext1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  643 */         if (envelope == null) {
/*      */           return;
/*      */         }
/*  646 */         str1 = XmlUtils.extractServiceId(envelope);
/*      */ 
/*      */ 
/*      */         
/*  650 */         if (str1.equals("urn:soap-service-manager")) {
/*      */ 
/*      */           
/*  653 */           ensureCorrectURI(this.m_serviceManager.getRequiredRequestURI(), paramHttpServletRequest.getRequestURI());
/*      */         
/*      */         }
/*  656 */         else if (str1.equals("urn:soap-provider-manager")) {
/*      */ 
/*      */           
/*  659 */           ensureCorrectURI(this.m_providerManager.getRequiredRequestURI(), paramHttpServletRequest.getRequestURI());
/*      */         
/*      */         }
/*  662 */         else if (this.m_pathAuth) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  668 */           boolean bool1 = false;
/*      */ 
/*      */           
/*  671 */           if (str3 != null && str3.startsWith("/")) {
/*      */             
/*  673 */             String str = str3.substring(1);
/*  674 */             if (!str.equals(str1)) {
/*  675 */               bool1 = true;
/*      */             }
/*      */           } else {
/*      */             
/*  679 */             bool1 = true;
/*      */           } 
/*      */           
/*  682 */           if (bool1) {
/*      */             
/*  684 */             String str = paramHttpServletRequest.getServletPath();
/*      */             
/*  686 */             throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Service URL incorrect.");
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  692 */         str2 = XmlUtils.extractMethodName(envelope);
/*      */         
/*  694 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  696 */           this.m_log.log("processing request for method '" + str2 + "' in service '" + str1 + "'", 2);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  701 */         serviceDeploymentDescriptor = this.m_serviceManager.query(str1);
/*      */         
/*  703 */         bool = (serviceDeploymentDescriptor.getServiceType() == 0) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  708 */         requestContext.setRequestEnvelope(envelope);
/*  709 */         requestContext.setServiceId(str1);
/*  710 */         requestContext.setMethodName(str2);
/*  711 */         requestContext.setRequestSOAPContext(oracleSOAPContext1);
/*  712 */         requestContext.setResponseSOAPContext(oracleSOAPContext2);
/*      */ 
/*      */         
/*  715 */         oracleSOAPContext1.setServiceDeploymentDescriptor(serviceDeploymentDescriptor);
/*  716 */         oracleSOAPContext2.setServiceDeploymentDescriptor(serviceDeploymentDescriptor);
/*      */ 
/*      */ 
/*      */         
/*  720 */         if (this.m_globalRequestChain.length > 0)
/*      */         {
/*  722 */           invokeGlobalChain(this.m_globalRequestChain, 1, requestContext, false);
/*      */         }
/*      */ 
/*      */         
/*  726 */         if (serviceDeploymentDescriptor.getCheckMustUnderstands()) {
/*      */           
/*  728 */           Envelope envelope1 = requestContext.getRequestEnvelope();
/*  729 */           Header header = envelope1.getHeader();
/*  730 */           if (header != null) {
/*  731 */             Utils.checkMustUnderstands(header);
/*      */           }
/*      */         } 
/*      */         
/*  735 */         provider = getProvider(serviceDeploymentDescriptor, str1);
/*      */         
/*  737 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  739 */           this.m_log.log("provider for service '" + str1 + "' is '" + provider.getId() + "'", 2);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  745 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  747 */           this.m_log.log("invoking method '" + str2 + "' in service '" + str1 + "' via provider '" + provider.getId() + "'", 2);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  752 */         provider.invoke(requestContext);
/*      */         
/*  754 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  756 */           this.m_log.log("completed request for method '" + str2 + "' in service '" + str1 + "' via provider '" + provider.getId() + "'", 2);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  762 */         if (str1.equals("urn:soap-provider-manager"))
/*      */         {
/*      */           
/*  765 */           updateProviderMap(str2);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  770 */         if (this.m_globalResponseChain.length > 0)
/*      */         {
/*  772 */           invokeGlobalChain(this.m_globalResponseChain, 2, requestContext, false);
/*      */         
/*      */         }
/*      */       }
/*  776 */       catch (Throwable throwable) {
/*      */         
/*  778 */         if (this.m_log.isLoggable(2))
/*      */         {
/*  780 */           this.m_log.log("Error: " + throwable.getMessage() + "\n" + ServerUtils.getStackTrace(throwable), 2);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  789 */         SOAPException sOAPException = null;
/*  790 */         if (throwable instanceof SOAPException) {
/*  791 */           sOAPException = (SOAPException)throwable;
/*      */         } else {
/*  793 */           sOAPException = new SOAPException(Constants.FAULT_CODE_SERVER + ". Exception: ", "", throwable);
/*      */         } 
/*      */         
/*  796 */         Fault fault = new Fault(sOAPException);
/*  797 */         fault.setFaultActorURI(paramHttpServletRequest.getRequestURI());
/*      */ 
/*      */         
/*  800 */         SOAPFaultRouter sOAPFaultRouter = null;
/*  801 */         if (serviceDeploymentDescriptor != null)
/*      */         {
/*  803 */           sOAPFaultRouter = serviceDeploymentDescriptor.buildFaultRouter(ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext));
/*      */         }
/*      */ 
/*      */         
/*  807 */         if (sOAPFaultRouter == null)
/*  808 */           sOAPFaultRouter = this.m_faultRouter; 
/*  809 */         if (sOAPFaultRouter != null) {
/*  810 */           sOAPFaultRouter.notifyListeners(fault, sOAPException);
/*      */         }
/*      */         
/*  813 */         if (fault.getFaultCode().startsWith(Constants.FAULT_CODE_CLIENT)) {
/*      */           
/*  815 */           c = 'Ɛ';
/*      */         }
/*      */         else {
/*      */           
/*  819 */           c = 'Ǵ';
/*      */         } 
/*      */         
/*  822 */         String str = null;
/*  823 */         if (requestContext != null)
/*  824 */           str = requestContext.getRequestEncodingStyle(); 
/*  825 */         if (str == null) {
/*  826 */           str = "http://schemas.xmlsoap.org/soap/encoding/";
/*      */         }
/*  828 */         oracleSOAPContext2 = new OracleSOAPContext();
/*  829 */         if (serviceDeploymentDescriptor != null)
/*  830 */           oracleSOAPContext2.setServiceDeploymentDescriptor(serviceDeploymentDescriptor); 
/*  831 */         response = new Response(null, null, fault, null, null, str, (SOAPContext)oracleSOAPContext2);
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  836 */           Envelope envelope1 = response.buildEnvelope();
/*  837 */           requestContext.setResponseEnvelope(envelope1);
/*  838 */           requestContext.setResponseSOAPContext(oracleSOAPContext2);
/*  839 */           requestContext.setResponseMap(new SOAPMappingRegistry());
/*  840 */           bool = true;
/*      */         }
/*  842 */         catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  851 */         if (this.m_globalErrorChain.length > 0)
/*      */         {
/*  853 */           invokeGlobalChain(this.m_globalErrorChain, 3, requestContext, true);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  861 */       oracleSOAPContext2 = requestContext.getResponseSOAPContext();
/*      */       
/*  863 */       if (bool) {
/*      */         
/*  865 */         StringWriter stringWriter = new StringWriter();
/*  866 */         Envelope envelope1 = requestContext.getResponseEnvelope();
/*  867 */         envelope1.marshall(stringWriter, (XMLJavaMappingRegistry)requestContext.getResponseMap(), (SOAPContext)oracleSOAPContext2);
/*  868 */         oracleSOAPContext2.setRootPart(stringWriter.toString(), "text/xml;charset=utf-8");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  874 */       TransportMessage transportMessage = new TransportMessage(null, (SOAPContext)oracleSOAPContext2, null);
/*      */ 
/*      */       
/*  877 */       transportMessage.editOutgoing(this.m_editor);
/*      */       
/*  879 */       transportMessage.save();
/*      */ 
/*      */       
/*  882 */       paramHttpServletResponse.setStatus(c);
/*  883 */       if (transportMessage.getContentType() == null) {
/*      */         
/*  885 */         paramHttpServletResponse.setContentType("text/xml;charset=utf-8");
/*      */       }
/*      */       else {
/*      */         
/*  889 */         paramHttpServletResponse.setContentType(transportMessage.getContentType());
/*      */       } 
/*  891 */       Enumeration enumeration = transportMessage.getHeaderNames();
/*  892 */       while (enumeration.hasMoreElements()) {
/*      */         
/*  894 */         String str = enumeration.nextElement();
/*  895 */         paramHttpServletResponse.setHeader(str, transportMessage.getHeader(str));
/*      */       } 
/*      */       
/*  898 */       paramHttpServletResponse.setContentLength(transportMessage.getContentLength());
/*  899 */       transportMessage.writeTo((OutputStream)paramHttpServletResponse.getOutputStream());
/*      */     }
/*  901 */     catch (Exception exception) {
/*  902 */       throw new ServletException("Error building response envelope: " + exception, exception);
/*      */     }
/*      */     finally {
/*      */       
/*  906 */       this.m_serverPhaseEvent.stop(l);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setReqCtxAttrs(OracleSOAPContext paramOracleSOAPContext, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) {
/*  922 */     paramOracleSOAPContext.setClassLoader(ServerHTTPUtils.getServletClassLoaderFromContext(getServletContext()));
/*      */     
/*  924 */     paramOracleSOAPContext.setProperty(Constants.BAG_HTTPSERVLET, this);
/*  925 */     paramOracleSOAPContext.setProperty(Constants.BAG_HTTPSESSION, paramHttpServletRequest.getSession());
/*      */     
/*  927 */     paramOracleSOAPContext.setProperty(Constants.BAG_HTTPSERVLETREQUEST, paramHttpServletRequest);
/*  928 */     paramOracleSOAPContext.setProperty(Constants.BAG_HTTPSERVLETRESPONSE, paramHttpServletResponse);
/*      */ 
/*      */     
/*  931 */     paramOracleSOAPContext.setRequestURI(paramHttpServletRequest.getRequestURI());
/*  932 */     String str = paramHttpServletRequest.getRemoteAddr();
/*  933 */     if (str != null)
/*      */     {
/*  935 */       paramOracleSOAPContext.setRemoteAddress(str);
/*      */     }
/*  937 */     str = paramHttpServletRequest.getRemoteHost();
/*  938 */     if (str != null)
/*      */     {
/*  940 */       paramOracleSOAPContext.setRemoteHost(str);
/*      */     }
/*  942 */     str = paramHttpServletRequest.getRemoteUser();
/*  943 */     if (str != null)
/*      */     {
/*  945 */       paramOracleSOAPContext.setUsername(str);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  953 */     if (paramHttpServletRequest.getAttribute("org.apache.jserv.HTTPS") != null) {
/*      */       
/*  955 */       paramOracleSOAPContext.setSecureChannel(true);
/*      */     }
/*  957 */     else if (paramHttpServletRequest.getAttribute("org.apache.jserv.SSL_PROTOCOL") != null) {
/*      */       
/*  959 */       paramOracleSOAPContext.setSecureChannel(true);
/*      */     }
/*  961 */     else if (paramHttpServletRequest.getAttribute("javax.net.ssl.cipher_suite") != null) {
/*      */       
/*  963 */       paramOracleSOAPContext.setSecureChannel(true);
/*      */     }
/*      */     else {
/*      */       
/*  967 */       paramOracleSOAPContext.setSecureChannel(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Object object;
/*      */ 
/*      */ 
/*      */     
/*  977 */     if ((object = paramHttpServletRequest.getAttribute("org.apache.jserv.SSL_CLIENT_CERT")) != null) {
/*      */       
/*  979 */       paramOracleSOAPContext.setCertificate(object);
/*      */     }
/*  981 */     else if ((object = paramHttpServletRequest.getAttribute("javax.net.ssl.peer_certificates")) != null) {
/*      */ 
/*      */       
/*  984 */       paramOracleSOAPContext.setCertificate(object);
/*      */     }
/*  986 */     else if ((object = paramHttpServletRequest.getAttribute("javax.servlet.request.X509Certificate")) != null) {
/*      */ 
/*      */       
/*  989 */       paramOracleSOAPContext.setCertificate(object);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeGlobalChain(Handler[] paramArrayOfHandler, int paramInt, RequestContext paramRequestContext, boolean paramBoolean) throws SOAPException {
/* 1010 */     for (byte b = 0; b < paramArrayOfHandler.length; b++) {
/*      */       
/*      */       try {
/* 1013 */         paramArrayOfHandler[b].invoke(paramInt, paramRequestContext);
/* 1014 */       } catch (SOAPException sOAPException) {
/* 1015 */         if (this.m_log.isLoggable(0))
/*      */         {
/* 1017 */           this.m_log.log("error invoking request handler '" + paramArrayOfHandler[b].getName() + "'" + "\n" + sOAPException.getMessage(), (Throwable)sOAPException, 0);
/*      */         }
/*      */ 
/*      */         
/* 1021 */         if (!paramBoolean) {
/* 1022 */           throw sOAPException;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Provider getProvider(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor, String paramString) throws SOAPException {
/* 1035 */     Provider provider = null;
/*      */     
/* 1037 */     if (paramServiceDeploymentDescriptor == null) {
/*      */       
/* 1039 */       if (this.m_log.isLoggable(2))
/*      */       {
/* 1041 */         this.m_log.log("service '" + paramString + "' is unknown", 2);
/*      */       }
/*      */       
/* 1044 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "service '" + paramString + "' is unknown");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1049 */     if (this.m_log.isLoggable(2))
/*      */     {
/* 1051 */       this.m_log.log("found deployment descriptor for service '" + paramString + "'", 2);
/*      */     }
/*      */ 
/*      */     
/* 1055 */     if (!paramServiceDeploymentDescriptor.getIsApacheDescriptor()) {
/* 1056 */       provider = (Provider)this.m_providerMap.get(paramServiceDeploymentDescriptor.getProviderId());
/*      */     
/*      */     }
/* 1059 */     else if (paramServiceDeploymentDescriptor.getProviderType() == 0) {
/*      */       
/* 1061 */       provider = (Provider)this.m_providerMap.get("java-provider");
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1070 */       ProviderDeploymentDescriptor providerDeploymentDescriptor = new ProviderDeploymentDescriptor();
/*      */       
/* 1072 */       providerDeploymentDescriptor.setId(paramServiceDeploymentDescriptor.getId() + " " + paramServiceDeploymentDescriptor.getProviderClass());
/* 1073 */       providerDeploymentDescriptor.setClassname(paramServiceDeploymentDescriptor.getProviderClass());
/* 1074 */       providerDeploymentDescriptor.setOptions(paramServiceDeploymentDescriptor.getProviderOptions());
/*      */       
/* 1076 */       provider = ServerUtils.createProvider(providerDeploymentDescriptor.getClassname(), ServerHTTPUtils.getServletClassLoaderFromContext(this.m_servletContext));
/*      */ 
/*      */       
/* 1079 */       provider.init(providerDeploymentDescriptor, this.m_soapServerContext);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1085 */     if (provider == null) {
/*      */       
/* 1087 */       if (this.m_log.isLoggable(2))
/*      */       {
/* 1089 */         this.m_log.log("unknown provider '" + paramServiceDeploymentDescriptor.getProviderId() + "' for service '" + paramString + "'", 2);
/*      */       }
/*      */ 
/*      */       
/* 1093 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "unknown provider '" + paramServiceDeploymentDescriptor.getProviderId() + "' for service '" + paramString + "'");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1098 */     return provider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ensureCorrectURI(String paramString1, String paramString2) throws SOAPException {
/* 1110 */     if (paramString1 != null)
/*      */     {
/* 1112 */       if (!paramString1.equals(paramString2)) {
/*      */         
/* 1114 */         if (this.m_log.isLoggable(2))
/*      */         {
/* 1116 */           this.m_log.log("Service/Provider manager requires URI '" + paramString1 + "' not URI '" + paramString2 + "'", 2);
/*      */         }
/*      */ 
/*      */         
/* 1120 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "invalid request URI '" + paramString2 + "' for service/provider " + "manager request");
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateProviderMap(String paramString) throws SOAPException {
/* 1136 */     if (paramString.equals("undeploy")) {
/*      */       
/* 1138 */       Vector vector = new Vector();
/*      */       
/* 1140 */       if (this.m_log.isLoggable(999)) {
/* 1141 */         this.m_log.log("Cleaning up after provider undeploy", 999);
/*      */       }
/* 1143 */       synchronized (this) {
/*      */         
/* 1145 */         Enumeration enumeration = this.m_providerMap.keys();
/* 1146 */         while (enumeration.hasMoreElements()) {
/*      */           
/* 1148 */           String str = enumeration.nextElement();
/*      */           try {
/* 1150 */             this.m_providerManager.query(str);
/* 1151 */           } catch (SOAPException sOAPException) {
/*      */             
/* 1153 */             vector.addElement((Provider)this.m_providerMap.remove(str));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1159 */       if (this.m_log.isLoggable(999)) {
/* 1160 */         this.m_log.log("There are " + vector.size() + " providers to destroy.", 999);
/*      */       }
/*      */ 
/*      */       
/* 1164 */       for (byte b = 0; b < vector.size(); b++)
/*      */       {
/* 1166 */         Provider provider = vector.elementAt(b);
/* 1167 */         if (this.m_log.isLoggable(999))
/* 1168 */           this.m_log.log("Destroying provider '" + provider.getId() + "'", 999); 
/* 1169 */         provider.destroy();
/*      */       }
/*      */     
/* 1172 */     } else if (paramString.equals("deploy")) {
/*      */       
/* 1174 */       if (this.m_log.isLoggable(999)) {
/* 1175 */         this.m_log.log("Init new provider after provider deploy", 999);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1180 */       synchronized (this)
/*      */       {
/* 1182 */         String[] arrayOfString = this.m_providerManager.list();
/*      */         
/* 1184 */         for (byte b = 0; b < arrayOfString.length; b++)
/*      */         {
/* 1186 */           if (this.m_providerMap.get(arrayOfString[b]) == null) {
/*      */             
/*      */             try {
/* 1189 */               if (this.m_log.isLoggable(2)) {
/* 1190 */                 this.m_log.log("Setting up new provider '" + arrayOfString[b] + "'", 2);
/*      */               }
/* 1192 */               setupProvider(arrayOfString[b]);
/* 1193 */             } catch (Exception exception) {
/* 1194 */               this.m_providerManager.undeploy(arrayOfString[b]);
/* 1195 */               throw new SOAPException(Constants.FAULT_CODE_SERVER, "Unable to init provider '" + arrayOfString[b] + "': " + exception.getMessage());
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1206 */     else if (this.m_log.isLoggable(999)) {
/* 1207 */       this.m_log.log("provider manager method was " + paramString, 999);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\http\SOAPServlet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */