/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import oracle.soap.server.ConfigManager;
/*     */ import oracle.soap.server.DeploymentDescriptor;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.ProviderManager;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.server.ServiceManager;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProviderManagerImpl
/*     */   implements ProviderManager
/*     */ {
/*     */   public static final String DEFAULT_CONFIG_MANAGER = "oracle.soap.server.impl.XMLProviderConfigManager";
/*     */   public static final String OPTION_REQUIRED_REQUEST_URI = "requiredRequestURI";
/*     */   private ProviderDeploymentDescriptor m_javapd;
/*  46 */   private String m_requiredRequestURI = null;
/*  47 */   private ServiceManager m_serviceManager = null;
/*  48 */   private ServletContext m_context = null;
/*  49 */   private ConfigManager m_configManager = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultConfigManagerClassname() {
/*  62 */     return "oracle.soap.server.impl.XMLProviderConfigManager";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Properties paramProperties, ServletContext paramServletContext, ConfigManager paramConfigManager) throws SOAPException {
/*  87 */     this.m_context = paramServletContext;
/*  88 */     this.m_configManager = paramConfigManager;
/*  89 */     this.m_requiredRequestURI = paramProperties.getProperty("requiredRequestURI");
/*     */     
/*  91 */     if (this.m_requiredRequestURI != null && this.m_requiredRequestURI.equals("")) {
/*  92 */       this.m_requiredRequestURI = null;
/*     */     }
/*     */ 
/*     */     
/*  96 */     this.m_javapd = new ProviderDeploymentDescriptor();
/*  97 */     this.m_javapd.setId("java-provider");
/*  98 */     this.m_javapd.setClassname("oracle.soap.providers.JavaProvider");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws SOAPException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceManager(ServiceManager paramServiceManager) {
/* 131 */     this.m_serviceManager = paramServiceManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequiredRequestURI() {
/* 148 */     return this.m_requiredRequestURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProviderDeploymentDescriptor undeploy(String paramString) throws SOAPException {
/* 170 */     if (paramString.equals("java-provider"))
/*     */     {
/* 172 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + paramString + "' may not be undeployed");
/*     */     }
/*     */ 
/*     */     
/* 176 */     if (this.m_serviceManager != null) {
/*     */       
/* 178 */       String[] arrayOfString = this.m_serviceManager.list();
/* 179 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*     */         
/* 181 */         ServiceDeploymentDescriptor serviceDeploymentDescriptor = this.m_serviceManager.query(arrayOfString[b]);
/* 182 */         String str = serviceDeploymentDescriptor.getProviderId();
/* 183 */         if (str != null && str.equals(paramString))
/*     */         {
/* 185 */           throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + paramString + "' may not be undeployed " + "because it still has deployed services");
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 192 */     ProviderDeploymentDescriptor providerDeploymentDescriptor = (ProviderDeploymentDescriptor)this.m_configManager.undeploy(paramString);
/*     */ 
/*     */     
/* 195 */     if (providerDeploymentDescriptor == null)
/*     */     {
/* 197 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + paramString + "' is unknown");
/*     */     }
/*     */ 
/*     */     
/* 201 */     return providerDeploymentDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deploy(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor) throws SOAPException {
/* 219 */     String str = paramProviderDeploymentDescriptor.getId();
/*     */     
/* 221 */     if (str.equals("java-provider"))
/*     */     {
/* 223 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + str + "' has already been deployed " + "automatically");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 230 */       if (this.m_configManager.query(str) != null)
/*     */       {
/* 232 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + str + "' is already deployed");
/*     */       }
/*     */       
/* 235 */       this.m_configManager.deploy((DeploymentDescriptor)paramProviderDeploymentDescriptor);
/*     */     }
/* 237 */     catch (Exception exception) {
/*     */       
/* 239 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProviderDeploymentDescriptor query(String paramString) throws SOAPException {
/* 262 */     if (ServerUtils.isNull(paramString))
/*     */     {
/* 264 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + paramString + "' invalid");
/*     */     }
/*     */ 
/*     */     
/* 268 */     if (paramString.equals("java-provider")) {
/*     */       
/* 270 */       if (this.m_javapd == null)
/*     */       {
/* 272 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + paramString + "' unknown");
/*     */       }
/*     */       
/* 275 */       return this.m_javapd;
/*     */     } 
/*     */     
/* 278 */     ProviderDeploymentDescriptor providerDeploymentDescriptor = (ProviderDeploymentDescriptor)this.m_configManager.query(paramString);
/*     */     
/* 280 */     if (providerDeploymentDescriptor == null)
/*     */     {
/* 282 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "provider '" + paramString + "' unknown");
/*     */     }
/*     */ 
/*     */     
/* 286 */     return providerDeploymentDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list() throws SOAPException {
/* 303 */     String[] arrayOfString = this.m_configManager.list(1);
/*     */     
/* 305 */     arrayOfString[0] = "java-provider";
/*     */     
/* 307 */     return arrayOfString;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\ProviderManagerImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */