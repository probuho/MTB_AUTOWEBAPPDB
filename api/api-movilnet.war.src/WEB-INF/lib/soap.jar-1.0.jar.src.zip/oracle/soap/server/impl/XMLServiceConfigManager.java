/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.server.http.ServerHTTPUtils;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLServiceConfigManager
/*     */   extends BaseConfigManager
/*     */ {
/*     */   public static final String OPTION_FILENAME = "filename";
/*  49 */   public static final String DEFAULT_FILENAME = "WEB-INF" + File.separator + "services.xml";
/*     */ 
/*     */   
/*  52 */   private String m_registryFilename = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptions(Properties paramProperties) throws SOAPException {
/*  74 */     this.m_registryFilename = paramProperties.getProperty("filename");
/*     */     
/*  76 */     if (ServerUtils.isNull(this.m_registryFilename))
/*     */     {
/*  78 */       this.m_registryFilename = DEFAULT_FILENAME;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void readRegistry() throws SOAPException {
/*  91 */     this.m_registry = new Hashtable();
/*     */ 
/*     */     
/*     */     try {
/*  95 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */       
/*  97 */       InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file), "UTF8");
/*     */       
/*  99 */       Document document = null;
/* 100 */       Element element = null;
/* 101 */       DocumentBuilder documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*     */       
/* 103 */       document = documentBuilder.parse(new InputSource(inputStreamReader));
/* 104 */       element = document.getDocumentElement();
/* 105 */       inputStreamReader.close();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 110 */       NodeList nodeList = element.getElementsByTagNameNS("http://xmlns.oracle.com/soap/2001/04/deploy/service", "service");
/*     */       
/* 112 */       processServiceElements(nodeList);
/*     */ 
/*     */       
/* 115 */       nodeList = element.getElementsByTagNameNS("http://xml.apache.org/xml-soap/deployment", "service");
/*     */       
/* 117 */       processServiceElements(nodeList);
/*     */     }
/* 119 */     catch (FileNotFoundException fileNotFoundException) {
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 124 */     catch (Exception exception) {
/*     */       
/* 126 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error reading services registry: " + exception.toString(), exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processServiceElements(NodeList paramNodeList) {
/* 133 */     int i = paramNodeList.getLength();
/* 134 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 136 */       Element element = (Element)paramNodeList.item(b);
/* 137 */       ServiceDeploymentDescriptor serviceDeploymentDescriptor = ServiceDeploymentDescriptor.fromXML(element);
/*     */       
/* 139 */       String str = serviceDeploymentDescriptor.getId();
/* 140 */       this.m_registry.put(str, serviceDeploymentDescriptor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void writeRegistry() throws SOAPException {
/*     */     try {
/* 150 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */       
/* 152 */       PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF8"));
/*     */       
/* 154 */       Enumeration enumeration = this.m_registry.elements();
/*     */       
/* 156 */       printWriter.println("<deployedServices>");
/* 157 */       printWriter.println();
/* 158 */       while (enumeration.hasMoreElements()) {
/*     */         
/* 160 */         ServiceDeploymentDescriptor serviceDeploymentDescriptor = enumeration.nextElement();
/*     */         
/* 162 */         serviceDeploymentDescriptor.toXML(printWriter);
/* 163 */         printWriter.println();
/*     */       } 
/* 165 */       printWriter.println("</deployedServices>");
/*     */       
/* 167 */       printWriter.close();
/*     */     }
/* 169 */     catch (Exception exception) {
/*     */       
/* 171 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error writing services registry: " + exception.toString(), exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\XMLServiceConfigManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */