/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.server.http.ServerHTTPUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryServiceConfigManager
/*     */   extends BaseConfigManager
/*     */ {
/*     */   public static final String OPTION_FILENAME = "filename";
/*  35 */   public static final String DEFAULT_FILENAME = "WEB-INF" + File.separator + "services.dd";
/*     */ 
/*     */   
/*  38 */   private String m_registryFilename = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptions(Properties paramProperties) throws SOAPException {
/*  54 */     this.m_registryFilename = paramProperties.getProperty("filename");
/*     */     
/*  56 */     if (ServerUtils.isNull(this.m_registryFilename))
/*     */     {
/*  58 */       this.m_registryFilename = DEFAULT_FILENAME;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void readRegistry() throws SOAPException {
/*     */     try {
/*  73 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */ 
/*     */       
/*  76 */       FileInputStream fileInputStream = new FileInputStream(file);
/*  77 */       ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
/*  78 */       this.m_registry = (Hashtable)objectInputStream.readObject();
/*  79 */       objectInputStream.close();
/*     */     }
/*  81 */     catch (Exception exception) {
/*     */       
/*  83 */       this.m_registry = new Hashtable();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void writeRegistry() throws SOAPException {
/*     */     try {
/*  96 */       File file = ServerHTTPUtils.getFileFromNameAndContext(this.m_registryFilename, this.m_context);
/*     */ 
/*     */       
/*  99 */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/* 100 */       ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
/*     */       
/* 102 */       objectOutputStream.writeObject(this.m_registry);
/* 103 */       objectOutputStream.close();
/*     */     }
/* 105 */     catch (Exception exception) {
/*     */       
/* 107 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\BinaryServiceConfigManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */