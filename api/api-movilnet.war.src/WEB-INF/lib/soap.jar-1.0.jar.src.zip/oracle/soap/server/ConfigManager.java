package oracle.soap.server;

import java.util.Properties;
import javax.servlet.ServletContext;
import org.apache.soap.SOAPException;

public interface ConfigManager {
  void setOptions(Properties paramProperties) throws SOAPException;
  
  void setContext(ServletContext paramServletContext);
  
  void init() throws SOAPException;
  
  DeploymentDescriptor undeploy(String paramString) throws SOAPException;
  
  void deploy(DeploymentDescriptor paramDeploymentDescriptor) throws SOAPException;
  
  DeploymentDescriptor query(String paramString) throws SOAPException;
  
  String[] list(int paramInt) throws SOAPException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\ConfigManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */