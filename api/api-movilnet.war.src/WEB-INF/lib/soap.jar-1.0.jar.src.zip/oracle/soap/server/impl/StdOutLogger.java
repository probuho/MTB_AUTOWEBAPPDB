/*     */ package oracle.soap.server.impl;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import oracle.soap.server.ContainerContext;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdOutLogger
/*     */   extends Logger
/*     */ {
/*  46 */   private static DateFormat s_dateTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
/*     */ 
/*     */   
/*  49 */   private PrintWriter m_pw = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Properties paramProperties, ContainerContext paramContainerContext) throws SOAPException {
/*  70 */     String str = paramProperties.getProperty("severity");
/*  71 */     if (str != null) {
/*     */       
/*  73 */       int i = getSeverityValue(str);
/*  74 */       if (i != 3) {
/*  75 */         this.m_severity = i;
/*     */       }
/*     */     } 
/*  78 */     this.m_pw = new PrintWriter(System.out, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String paramString, int paramInt) {
/*  96 */     if (isLoggable(paramInt))
/*     */     {
/*  98 */       this.m_pw.println(getHeader() + paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String paramString, Throwable paramThrowable, int paramInt) {
/* 119 */     if (isLoggable(paramInt))
/*     */     {
/* 121 */       this.m_pw.println(getHeader() + paramString + ": " + paramThrowable.getMessage() + "\n" + ServerUtils.getStackTrace(paramThrowable));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(Throwable paramThrowable, int paramInt) {
/* 142 */     if (isLoggable(paramInt))
/*     */     {
/* 144 */       this.m_pw.println(getHeader() + paramThrowable.getMessage() + "\n" + ServerUtils.getStackTrace(paramThrowable));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getHeader() {
/* 153 */     return s_dateTimeFormatter.format(new Date()) + " - ";
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\server\impl\StdOutLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */