/*    */ package oracle.soap.handlers.audit;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OneFilter
/*    */   implements Filter
/*    */ {
/*    */   public boolean apply(Hashtable paramHashtable) {
/* 15 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\handlers\audit\OneFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */