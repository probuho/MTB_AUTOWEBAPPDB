/*    */ package oracle.soap.handlers.audit;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZeroFilter
/*    */   implements Filter
/*    */ {
/*    */   public boolean apply(Hashtable paramHashtable) {
/* 15 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\handlers\audit\ZeroFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */