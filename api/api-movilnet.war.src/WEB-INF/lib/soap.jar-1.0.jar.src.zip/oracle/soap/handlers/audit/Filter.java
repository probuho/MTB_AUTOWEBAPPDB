package oracle.soap.handlers.audit;

import java.util.Hashtable;

public interface Filter {
  public static final String IP = "ip";
  
  public static final String HOST = "host";
  
  public static final String URN = "urn";
  
  public static final String USERNAME = "username";
  
  public static final int TYPE_IP = 1;
  
  public static final int TYPE_HOST = 2;
  
  public static final int TYPE_URN = 3;
  
  public static final int TYPE_USERNAME = 4;
  
  public static final char AND = '&';
  
  public static final char OR = '|';
  
  public static final char NOT = '!';
  
  public static final char OPEN_PARANTHESIS = '(';
  
  public static final char CLOSE_PARANTHESIS = ')';
  
  public static final char WILD_CARD = '*';
  
  public static final char EQUALS = '=';
  
  boolean apply(Hashtable paramHashtable);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\handlers\audit\Filter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */