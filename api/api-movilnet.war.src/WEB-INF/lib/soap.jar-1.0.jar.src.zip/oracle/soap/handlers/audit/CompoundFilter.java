/*     */ package oracle.soap.handlers.audit;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompoundFilter
/*     */   implements Filter
/*     */ {
/*     */   private char m_operand;
/*     */   private Filter m_first;
/*     */   private Filter m_second;
/*     */   
/*     */   public CompoundFilter(char paramChar, Filter paramFilter1, Filter paramFilter2) throws IllegalArgumentException {
/*  29 */     String str = "Invalid filter string in the audit logger";
/*  30 */     if (paramChar != '&' && paramChar != '|' && paramChar != '!')
/*  31 */       throw new IllegalArgumentException(str); 
/*  32 */     if (paramFilter1 == null)
/*  33 */       throw new IllegalArgumentException(str); 
/*  34 */     if (paramFilter2 == null && paramChar != '!')
/*  35 */       throw new IllegalArgumentException(str); 
/*  36 */     this.m_operand = paramChar;
/*  37 */     this.m_first = paramFilter1;
/*  38 */     this.m_second = paramFilter2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean apply(Hashtable paramHashtable) {
/*  44 */     switch (this.m_operand)
/*     */     
/*     */     { case '&':
/*  47 */         bool = (this.m_first.apply(paramHashtable) && this.m_second.apply(paramHashtable)) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  58 */         return bool;case '|': bool = (this.m_first.apply(paramHashtable) || this.m_second.apply(paramHashtable)) ? true : false; return bool;case '!': bool = !this.m_first.apply(paramHashtable) ? true : false; return bool; }  boolean bool = false; return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Filter parse(String paramString) throws IllegalArgumentException {
/*     */     CompoundFilter compoundFilter;
/*     */     int i;
/*  67 */     IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid filter string: \"" + paramString + "\"");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     if (paramString == null || paramString.length() == 0 || paramString.trim().length() == 0)
/*     */     {
/*  75 */       return new OneFilter();
/*     */     }
/*  77 */     if (paramString.length() < 5) {
/*  78 */       throw illegalArgumentException;
/*     */     }
/*  80 */     char[] arrayOfChar = paramString.toCharArray();
/*  81 */     if (arrayOfChar[0] != '(' || arrayOfChar[arrayOfChar.length - 1] != ')')
/*     */     {
/*  83 */       throw illegalArgumentException;
/*     */     }
/*  85 */     switch (arrayOfChar[1]) {
/*     */       
/*     */       case '&':
/*     */       case '|':
/*  89 */         i = findClosingParanthesis(arrayOfChar, 2);
/*  90 */         if (i <= 0 || i > arrayOfChar.length - 2) {
/*  91 */           throw illegalArgumentException;
/*     */         }
/*  93 */         compoundFilter = new CompoundFilter(arrayOfChar[1], parse(new String(arrayOfChar, 2, i - 2 + 1)), parse(new String(arrayOfChar, i + 1, arrayOfChar.length - i - 2)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         return compoundFilter;case '!': i = findClosingParanthesis(arrayOfChar, 2); if (i <= 0 || i != arrayOfChar.length - 2) throw illegalArgumentException;  compoundFilter = new CompoundFilter(arrayOfChar[1], parse(new String(arrayOfChar, 2, i - 2 + 1)), null); return compoundFilter;
/*     */     } 
/*     */     return new AtomicFilter(new String(arrayOfChar, 1, arrayOfChar.length - 2));
/*     */   }
/*     */ 
/*     */   
/*     */   private static int findClosingParanthesis(char[] paramArrayOfchar, int paramInt) throws IllegalArgumentException {
/* 117 */     byte b = 0;
/* 118 */     if (paramInt < 0 || paramInt >= paramArrayOfchar.length || paramArrayOfchar[paramInt] != '(')
/*     */     {
/* 120 */       throw new IllegalArgumentException("Invalid filter.");
/*     */     }
/* 122 */     for (int i = paramInt + 1; i < paramArrayOfchar.length; i++) {
/*     */       
/* 124 */       switch (paramArrayOfchar[i]) {
/*     */         
/*     */         case '(':
/* 127 */           b++;
/*     */           break;
/*     */         case ')':
/* 130 */           if (b == 0) {
/* 131 */             return i;
/*     */           }
/* 133 */           b--;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 139 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\handlers\audit\CompoundFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */