/*     */ package oracle.soap.handlers.audit;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AtomicFilter
/*     */   implements Filter
/*     */ {
/*     */   private int m_type;
/*     */   private String m_lhs;
/*     */   private String m_rhs;
/*     */   private String[] m_ip;
/*     */   private String[] m_host;
/*     */   
/*     */   public AtomicFilter(String paramString) throws IllegalArgumentException {
/*  29 */     byte b = -1;
/*  30 */     char[] arrayOfChar = paramString.toCharArray();
/*  31 */     IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid filter.");
/*     */ 
/*     */ 
/*     */     
/*  35 */     for (byte b1 = 0; b1 < arrayOfChar.length; b1++) {
/*     */       
/*  37 */       if (arrayOfChar[b1] == '(' || arrayOfChar[b1] == ')' || arrayOfChar[b1] == '|' || arrayOfChar[b1] == '&' || Character.isWhitespace(arrayOfChar[b1]))
/*     */       {
/*     */         
/*  40 */         throw illegalArgumentException; } 
/*  41 */       if (arrayOfChar[b1] == '=')
/*     */       {
/*  43 */         if (b == -1) {
/*  44 */           b = b1;
/*     */         } else {
/*  46 */           throw illegalArgumentException;
/*     */         } 
/*     */       }
/*     */     } 
/*  50 */     if (b <= 0 || b == paramString.length() - 1)
/*  51 */       throw illegalArgumentException; 
/*  52 */     init(paramString.substring(0, b), paramString.substring(b + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(String paramString1, String paramString2) throws IllegalArgumentException {
/*  59 */     this.m_lhs = paramString1;
/*  60 */     this.m_rhs = paramString2;
/*  61 */     if (paramString2.equals("*")) {
/*  62 */       throw new IllegalArgumentException("The attribute \"" + paramString1 + "\" cannot be used for filtering events.");
/*     */     }
/*  64 */     if (paramString1.equals("ip")) {
/*     */       
/*  66 */       this.m_lhs = paramString1;
/*  67 */       this.m_type = 1;
/*  68 */       StringTokenizer stringTokenizer = new StringTokenizer(paramString2, ".");
/*  69 */       this.m_ip = new String[stringTokenizer.countTokens()];
/*  70 */       for (byte b = 0; stringTokenizer.hasMoreTokens(); b++)
/*  71 */         this.m_ip[b] = stringTokenizer.nextToken(); 
/*  72 */       checkIPFilter();
/*     */     }
/*  74 */     else if (paramString1.equals("host")) {
/*  75 */       this.m_lhs = paramString1;
/*  76 */       this.m_type = 2;
/*  77 */       StringTokenizer stringTokenizer = new StringTokenizer(paramString2, ".");
/*  78 */       this.m_host = new String[stringTokenizer.countTokens()];
/*  79 */       for (byte b = 0; stringTokenizer.hasMoreTokens(); b++)
/*  80 */         this.m_host[b] = stringTokenizer.nextToken(); 
/*  81 */       checkHostFilter();
/*     */     }
/*  83 */     else if (paramString1.equals("urn")) {
/*  84 */       this.m_lhs = paramString1;
/*  85 */       this.m_type = 3;
/*     */     }
/*  87 */     else if (paramString1.equals("username")) {
/*  88 */       this.m_lhs = paramString1;
/*  89 */       this.m_type = 4;
/*     */     } else {
/*     */       
/*  92 */       throw new IllegalArgumentException("The attribute \"" + paramString1 + "\" cannot be used for filtering events.");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean apply(Hashtable paramHashtable) {
/*  98 */     Object object = paramHashtable.get(this.m_lhs);
/*     */ 
/*     */     
/* 101 */     if (object == null || !(object instanceof String)) {
/* 102 */       return false;
/*     */     }
/* 104 */     switch (this.m_type)
/*     */     
/*     */     { case 1:
/* 107 */         bool = compareIP((String)object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 121 */         return bool;case 2: bool = compareHost((String)object); return bool;case 3: bool = this.m_rhs.equalsIgnoreCase((String)object); return bool;case 4: bool = this.m_rhs.equalsIgnoreCase((String)object); return bool; }  boolean bool = false; return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean compareHost(String paramString) {
/* 126 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ".");
/* 127 */     String[] arrayOfString = new String[stringTokenizer.countTokens()]; int i;
/* 128 */     for (i = 0; i < arrayOfString.length; i++) {
/* 129 */       arrayOfString[i] = stringTokenizer.nextToken();
/*     */     }
/* 131 */     i = this.m_host.length;
/* 132 */     int j = arrayOfString.length;
/* 133 */     while (--i >= 0 && --j >= 0) {
/*     */       
/* 135 */       if (this.m_host[i].charAt(0) == '*')
/* 136 */         return true; 
/* 137 */       if (!this.m_host[i].equalsIgnoreCase(arrayOfString[j])) {
/* 138 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean compareIP(String paramString) {
/* 152 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ".");
/* 153 */     for (byte b = 0; b < this.m_ip.length && stringTokenizer.hasMoreTokens(); b++) {
/*     */       
/* 155 */       if (this.m_ip[b].charAt(0) == '*')
/* 156 */         return true; 
/* 157 */       if (!this.m_ip[b].equals(stringTokenizer.nextToken()))
/* 158 */         return false; 
/*     */     } 
/* 160 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkIPFilter() throws IllegalArgumentException {
/* 166 */     String str = "Illegal Filter.";
/* 167 */     boolean bool = false;
/* 168 */     for (byte b = 0; b < this.m_ip.length; b++) {
/*     */       
/* 170 */       if (bool)
/* 171 */         throw new IllegalArgumentException(str); 
/* 172 */       if (this.m_ip[b].length() == 0)
/* 173 */         throw new IllegalArgumentException(str); 
/* 174 */       if (this.m_ip[b].equals("*")) {
/*     */         
/* 176 */         if (bool) {
/* 177 */           throw new IllegalArgumentException(str);
/*     */         }
/* 179 */         bool = true;
/*     */       } else {
/*     */         
/*     */         try {
/* 183 */           int i = Integer.parseInt(this.m_ip[b]);
/* 184 */           if (i < 0 || i > 255)
/* 185 */             throw new IllegalArgumentException(str); 
/* 186 */         } catch (NumberFormatException numberFormatException) {
/* 187 */           throw new IllegalArgumentException(str);
/*     */         } 
/*     */       } 
/* 190 */     }  if (!bool && this.m_ip.length != 4) {
/* 191 */       throw new IllegalArgumentException(str);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkHostFilter() throws IllegalArgumentException {
/* 197 */     String str = "Illegal Filter.";
/* 198 */     boolean bool = false;
/* 199 */     if (this.m_host.length == 0) {
/* 200 */       throw new IllegalArgumentException(str);
/*     */     }
/* 202 */     for (int i = this.m_host.length - 1; i >= 0; i--) {
/*     */       
/* 204 */       if (bool)
/* 205 */         throw new IllegalArgumentException(str); 
/* 206 */       if (this.m_host[i].length() == 0)
/* 207 */         throw new IllegalArgumentException(str); 
/* 208 */       if (this.m_host[i].equals("*")) {
/*     */         
/* 210 */         if (bool) {
/* 211 */           throw new IllegalArgumentException(str);
/*     */         }
/* 213 */         bool = true;
/*     */       } 
/* 215 */       if (!bool)
/*     */       {
/* 217 */         for (byte b = 0; b < this.m_host[i].length(); b++) {
/* 218 */           if (this.m_host[i].charAt(b) == '*')
/* 219 */             throw new IllegalArgumentException(str); 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\handlers\audit\AtomicFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */