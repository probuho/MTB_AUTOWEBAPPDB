/*     */ package oracle.soap.handlers.audit;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import oracle.soap.server.Handler;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.OracleSOAPContext;
/*     */ import oracle.soap.server.RequestContext;
/*     */ import oracle.soap.server.SOAPServerContext;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.xml.XMLJavaMappingRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuditLogger
/*     */   implements Handler
/*     */ {
/*     */   public static final String HANDLER_NAME = "Audit-Logger";
/*     */   public static final String AUDIT_LOG_DIRECTORY = "auditLogDirectory";
/*     */   public static final String AUDIT_EVENT_FILTER = "filter";
/*     */   public static final String AUDIT_INCLUDE_REQUEST = "includeRequest";
/*     */   public static final String AUDIT_INCLUDE_RESPONSE = "includeResponse";
/*     */   private BufferedWriter m_bw;
/*     */   private Filter m_filter;
/*     */   private Properties m_options;
/*     */   private SOAPServerContext m_ssctx;
/*     */   private Logger m_logger;
/*     */   private String m_name;
/*     */   private boolean m_includeReq;
/*     */   private boolean m_includeRes;
/*     */   private SOAPMappingRegistry m_smr;
/*     */   
/*     */   public void init(SOAPServerContext paramSOAPServerContext) throws SOAPException {
/*  54 */     this.m_ssctx = paramSOAPServerContext;
/*  55 */     this.m_logger = paramSOAPServerContext.getLogger();
/*     */ 
/*     */     
/*  58 */     this.m_smr = new SOAPMappingRegistry();
/*     */ 
/*     */     
/*  61 */     Object object = this.m_options.get("includeRequest");
/*  62 */     if (object != null) {
/*     */       
/*  64 */       if (!(object instanceof String)) {
/*  65 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "The attribute \"includeRequest\" of the audit logger module is not set correctly.");
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  70 */       object = "false";
/*  71 */     }  if (((String)object).equalsIgnoreCase("true")) {
/*  72 */       this.m_includeReq = true;
/*  73 */     } else if (((String)object).equalsIgnoreCase("false")) {
/*  74 */       this.m_includeReq = false;
/*     */     } else {
/*  76 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "The attribute \"includeRequest\" of the audit logger module is not set correctly.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  81 */     object = this.m_options.get("includeResponse");
/*  82 */     if (object != null) {
/*     */       
/*  84 */       if (!(object instanceof String)) {
/*  85 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "The attribute \"includeResponse\" of the audit logger module is not set correctly.");
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  90 */       object = "false";
/*  91 */     }  if (((String)object).equalsIgnoreCase("true")) {
/*  92 */       this.m_includeRes = true;
/*  93 */     } else if (((String)object).equalsIgnoreCase("false")) {
/*  94 */       this.m_includeRes = false;
/*     */     } else {
/*  96 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "The attribute \"includeResponse\" of the audit logger module is not set correctly.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     object = this.m_options.get("filter");
/* 102 */     if (object != null && !(object instanceof String)) {
/* 103 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "The attribute \"filter\" of the audit logger module is not set correctly.");
/*     */     }
/*     */ 
/*     */     
/* 107 */     String str2 = (String)object;
/*     */     
/*     */     try {
/* 110 */       this.m_filter = CompoundFilter.parse(str2);
/* 111 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 112 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Filter for audit logger module is not valid.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 117 */     object = this.m_options.get("auditLogDirectory");
/* 118 */     if (object == null || !(object instanceof String)) {
/* 119 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "The attribute \"auditLogDirectory\" of the audit logger module is not set correctly.");
/*     */     }
/*     */ 
/*     */     
/* 123 */     String str1 = (String)object;
/*     */ 
/*     */     
/* 126 */     File file = new File(str1);
/* 127 */     if (!file.exists() || !file.isDirectory() || !file.canWrite()) {
/* 128 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "The attribute \"auditLogDirectory\" of the audit logger module is set to a invalid/unwritable directory");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 133 */     byte b = 1;
/*     */     
/*     */     do {
/* 136 */       if (b > 20) {
/* 137 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Audit-Logger: could not open file. Number of attempts: " + b + ". The clock on this machine may not have been set " + "corretly");
/*     */       }
/*     */ 
/*     */       
/* 141 */       file = new File(str1, "OracleSoapAuditLog." + System.currentTimeMillis());
/*     */     }
/* 143 */     while (file.exists());
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 148 */       this.m_bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF8"));
/*     */ 
/*     */       
/* 151 */       this.m_bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/* 152 */       this.m_bw.newLine();
/* 153 */       this.m_bw.write("<!-- Module: Audit-Logger -->");
/* 154 */       this.m_bw.newLine();
/* 155 */       this.m_bw.write("<!-- Filter = " + str2 + " -->");
/* 156 */       this.m_bw.newLine();
/* 157 */       this.m_bw.write("<!-- If the servlet container/runner fails, it is possible that this file is not a valid XML document because of a missing end tag. If this is the case, edit the file and add the end tag \"</SoapAuditTrail>\" at the end of the file to make this a valid XML document -->");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 162 */       this.m_bw.newLine();
/* 163 */       this.m_bw.write("<SoapAuditTrail xmlns=\"http://xmlns.oracle.com/soap/2001/04/security/auditing/\"");
/*     */ 
/*     */       
/* 166 */       this.m_bw.newLine();
/* 167 */       this.m_bw.write("                xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">");
/*     */       
/* 169 */       this.m_bw.newLine();
/* 170 */       this.m_bw.flush();
/* 171 */     } catch (IOException iOException) {
/* 172 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "IOException while opening the audit log file.", iOException);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (this.m_logger.isLoggable(1))
/*     */     {
/* 180 */       this.m_logger.log("Audit-Logger started. Output - file:" + file.toString(), 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptions(Properties paramProperties) {
/* 187 */     this.m_options = paramProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getOptions() {
/* 192 */     return this.m_options;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void destroy() throws SOAPException {
/* 198 */     if (this.m_bw != null) {
/*     */       try {
/* 200 */         this.m_bw.write("</SoapAuditTrail>");
/* 201 */         this.m_bw.newLine();
/* 202 */         this.m_bw.flush();
/* 203 */         this.m_bw.close();
/* 204 */       } catch (IOException iOException) {
/* 205 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "IOException while closing the audit log file.", iOException);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 213 */     paramString = this.m_name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 218 */     return this.m_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void invoke(int paramInt, RequestContext paramRequestContext) throws SOAPException {
/* 226 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     Envelope envelope1 = paramRequestContext.getRequestEnvelope();
/* 232 */     Envelope envelope2 = paramRequestContext.getResponseEnvelope();
/* 233 */     OracleSOAPContext oracleSOAPContext = paramRequestContext.getRequestSOAPContext();
/*     */     
/* 235 */     String str1 = oracleSOAPContext.getRemoteAddress();
/* 236 */     if (str1 != null) {
/* 237 */       hashtable.put("ip", str1);
/*     */     }
/* 239 */     String str2 = oracleSOAPContext.getRemoteHost();
/* 240 */     if (str2 != null) {
/* 241 */       hashtable.put("host", str2);
/*     */     }
/* 243 */     String str3 = oracleSOAPContext.getUsername();
/* 244 */     if (str3 != null) {
/* 245 */       hashtable.put("username", str3);
/*     */     }
/* 247 */     String str4 = paramRequestContext.getServiceId();
/* 248 */     if (str4 != null) {
/* 249 */       hashtable.put("urn", str4);
/*     */     }
/* 251 */     String str5 = paramRequestContext.getMethodName();
/*     */     
/* 253 */     if (this.m_filter.apply(hashtable))
/*     */       try {
/*     */         String str;
/*     */         
/* 257 */         switch (paramInt) {
/*     */           
/*     */           case 1:
/* 260 */             str = "request";
/*     */             break;
/*     */           case 2:
/* 263 */             str = "response";
/*     */             break;
/*     */           case 3:
/* 266 */             str = "error";
/*     */             break;
/*     */           default:
/* 269 */             throw new SOAPException(Constants.FAULT_CODE_SERVER, "Incorrect chainType provided for audit logger.");
/*     */         } 
/*     */         
/* 272 */         this.m_bw.write("  <SoapAuditRecord chainType=\"" + str + "\">");
/* 273 */         this.m_bw.newLine();
/* 274 */         this.m_bw.write("    <TimeStamp>");
/* 275 */         this.m_bw.write((new Date(System.currentTimeMillis())).toString());
/* 276 */         this.m_bw.write("</TimeStamp>");
/* 277 */         this.m_bw.newLine();
/* 278 */         if (str4 != null) {
/*     */           
/* 280 */           this.m_bw.write("    <ServiceURI>");
/* 281 */           this.m_bw.write(str4);
/* 282 */           this.m_bw.write("</ServiceURI>");
/* 283 */           this.m_bw.newLine();
/*     */         } 
/* 285 */         if (str5 != null) {
/*     */           
/* 287 */           this.m_bw.write("    <Method>");
/* 288 */           this.m_bw.write(str5);
/* 289 */           this.m_bw.write("</Method>");
/* 290 */           this.m_bw.newLine();
/*     */         } 
/* 292 */         if (str1 != null) {
/*     */           
/* 294 */           this.m_bw.write("    <IpAddress>");
/* 295 */           this.m_bw.write(str1);
/* 296 */           this.m_bw.write("</IpAddress>");
/* 297 */           this.m_bw.newLine();
/*     */         } 
/* 299 */         if (str2 != null) {
/*     */           
/* 301 */           this.m_bw.write("    <Hostname>");
/* 302 */           this.m_bw.write(str2);
/* 303 */           this.m_bw.write("</Hostname>");
/* 304 */           this.m_bw.newLine();
/*     */         } 
/* 306 */         if (str3 != null) {
/*     */           
/* 308 */           this.m_bw.write("    <User type=\"username\">");
/* 309 */           this.m_bw.write(str3);
/* 310 */           this.m_bw.write("</User>");
/* 311 */           this.m_bw.newLine();
/*     */         } 
/* 313 */         if (this.m_includeReq && envelope1 != null) {
/*     */           
/* 315 */           this.m_bw.write("    <Request>"); SOAPMappingRegistry sOAPMappingRegistry;
/* 316 */           if ((sOAPMappingRegistry = paramRequestContext.getResponseMap()) == null)
/* 317 */             sOAPMappingRegistry = this.m_smr; 
/* 318 */           envelope1.marshall(this.m_bw, (XMLJavaMappingRegistry)sOAPMappingRegistry, new SOAPContext(), false);
/* 319 */           this.m_bw.write("</Request>");
/* 320 */           this.m_bw.newLine();
/*     */         } 
/*     */         
/* 323 */         if (this.m_includeRes && envelope2 != null && paramInt == 2) {
/*     */ 
/*     */           
/* 326 */           this.m_bw.write("    <Response>"); SOAPMappingRegistry sOAPMappingRegistry;
/* 327 */           if ((sOAPMappingRegistry = paramRequestContext.getResponseMap()) == null)
/* 328 */             sOAPMappingRegistry = this.m_smr; 
/* 329 */           envelope2.marshall(this.m_bw, (XMLJavaMappingRegistry)sOAPMappingRegistry, new SOAPContext(), false);
/* 330 */           this.m_bw.write("</Response>");
/* 331 */           this.m_bw.newLine();
/*     */         } 
/* 333 */         this.m_bw.write("  </SoapAuditRecord>");
/* 334 */         this.m_bw.newLine();
/* 335 */         this.m_bw.flush();
/* 336 */       } catch (IOException iOException) {
/* 337 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "IOException while writing the audit log file.", iOException);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\handlers\audit\AuditLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */