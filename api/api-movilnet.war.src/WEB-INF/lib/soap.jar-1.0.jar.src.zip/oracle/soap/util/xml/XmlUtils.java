/*     */ package oracle.soap.util.xml;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Body;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.util.xml.XMLParserUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlUtils
/*     */ {
/*     */   public static String extractServiceId(Envelope paramEnvelope) throws SOAPException {
/*  53 */     Body body = paramEnvelope.getBody();
/*     */     
/*  55 */     if (body == null)
/*     */     {
/*  57 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Body is missing");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  62 */     Element element = body.getBodyEntries().elementAt(0);
/*  63 */     if (element == null)
/*     */     {
/*  65 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Body is empty");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  70 */     String str = element.getNamespaceURI();
/*     */     
/*  72 */     if (str == null)
/*     */     {
/*  74 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Service URI is missing");
/*     */     }
/*     */ 
/*     */     
/*  78 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractMethodName(Envelope paramEnvelope) throws SOAPException {
/*  94 */     Body body = paramEnvelope.getBody();
/*     */     
/*  96 */     if (body == null)
/*     */     {
/*  98 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Body is missing");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     Element element = body.getBodyEntries().elementAt(0);
/* 105 */     if (element == null)
/*     */     {
/* 107 */       throw new SOAPException(Constants.FAULT_CODE_CLIENT, "Body is empty");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     return element.getLocalName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dumpDOM(Document paramDocument, StringBuffer paramStringBuffer) {
/* 121 */     NodeList nodeList = paramDocument.getElementsByTagName("*");
/*     */     
/* 123 */     int i = nodeList.getLength();
/*     */     
/* 125 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 127 */       Element element = (Element)nodeList.item(b);
/* 128 */       paramStringBuffer.append("Element " + element.getNamespaceURI() + ":" + element.getLocalName() + "\n");
/*     */       
/* 130 */       NamedNodeMap namedNodeMap = element.getAttributes();
/* 131 */       int j = namedNodeMap.getLength();
/* 132 */       for (byte b1 = 0; b1 < j; b1++) {
/*     */         
/* 134 */         String str1 = namedNodeMap.item(b1).getNamespaceURI();
/* 135 */         String str2 = namedNodeMap.item(b1).getLocalName();
/* 136 */         String str3 = ((Attr)namedNodeMap.item(b1)).getValue();
/*     */         
/* 138 */         paramStringBuffer.append("   Attr  " + str1 + ":" + str2 + " = '" + str3 + "'" + "\n");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseXml(String paramString) throws SOAPException {
/* 161 */     Document document = null;
/* 162 */     DocumentBuilder documentBuilder = null;
/*     */ 
/*     */     
/*     */     try {
/* 166 */       documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*     */     }
/* 168 */     catch (Exception exception) {
/*     */       
/* 170 */       System.err.println("Problem creating JAXP document builder");
/* 171 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 174 */     if (documentBuilder == null) {
/* 175 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error parsing. No JAXP document builder");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 181 */       File file = new File(paramString);
/* 182 */       document = documentBuilder.parse("file:" + file.getCanonicalPath());
/*     */       
/* 184 */       if (document == null)
/*     */       {
/* 186 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error parsing '" + paramString + "'");
/*     */       
/*     */       }
/*     */     }
/* 190 */     catch (Exception exception) {
/*     */       
/* 192 */       System.err.println("parsing " + paramString);
/* 193 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 196 */     return document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseXml(Reader paramReader) throws SOAPException {
/* 214 */     Document document = null;
/* 215 */     DocumentBuilder documentBuilder = null;
/*     */ 
/*     */     
/*     */     try {
/* 219 */       documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*     */     }
/* 221 */     catch (Exception exception) {
/*     */       
/* 223 */       System.err.println("Problem creating JAXP document builder");
/* 224 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 227 */     if (documentBuilder == null) {
/* 228 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error parsing. No JAXP document builder");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 233 */       document = documentBuilder.parse(new InputSource(paramReader));
/* 234 */       if (document == null)
/*     */       {
/* 236 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error parsing a reader");
/*     */       
/*     */       }
/*     */     }
/* 240 */     catch (Exception exception) {
/*     */       
/* 242 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 245 */     return document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseXml(InputStream paramInputStream) throws SOAPException {
/* 260 */     Document document = null;
/* 261 */     DocumentBuilder documentBuilder = null;
/*     */ 
/*     */     
/*     */     try {
/* 265 */       documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*     */     }
/* 267 */     catch (Exception exception) {
/*     */       
/* 269 */       System.err.println("Problem creating JAXP document builder");
/* 270 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 273 */     if (documentBuilder == null) {
/* 274 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error parsing. No JAXP document builder");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 279 */       document = documentBuilder.parse(paramInputStream);
/* 280 */       if (document == null)
/*     */       {
/* 282 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error parsing the contents of an InputStream");
/*     */       
/*     */       }
/*     */     }
/* 286 */     catch (Exception exception) {
/*     */       
/* 288 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 291 */     return document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document createDocument() throws SOAPException {
/* 305 */     Document document = null;
/* 306 */     DocumentBuilder documentBuilder = null;
/*     */ 
/*     */     
/*     */     try {
/* 310 */       documentBuilder = XMLParserUtils.getXMLDocBuilder();
/*     */     }
/* 312 */     catch (Exception exception) {
/*     */       
/* 314 */       System.err.println("Problem creating JAXP document builder");
/* 315 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 318 */     if (documentBuilder == null) {
/* 319 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error creating document. No JAXP document builder");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 324 */       document = documentBuilder.newDocument();
/* 325 */       if (document == null)
/*     */       {
/* 327 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error creating document");
/*     */       
/*     */       }
/*     */     }
/* 331 */     catch (Exception exception) {
/*     */       
/* 333 */       ServerUtils.rethrow(Constants.FAULT_CODE_SERVER, exception);
/*     */     } 
/*     */     
/* 336 */     return document;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soa\\util\xml\XmlUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */