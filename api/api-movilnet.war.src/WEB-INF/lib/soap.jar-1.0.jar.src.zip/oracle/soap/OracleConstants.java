package oracle.soap;

public class OracleConstants {
  public static final String NS_URI_ORACLE_SOAP_CONFIG = "http://xmlns.oracle.com/soap/2001/04/config";
  
  public static final String NS_URI_ORACLE_SOAP_DEPLOY_PROVIDER = "http://xmlns.oracle.com/soap/2001/04/deploy/provider";
  
  public static final String NS_URI_ORACLE_SOAP_DEPLOY_SERVICE = "http://xmlns.oracle.com/soap/2001/04/deploy/service";
  
  public static final String NS_URI_ORACLE_SOAP_SECURITY_AUDITING = "http://xmlns.oracle.com/soap/2001/04/security/auditing/";
  
  public static final String NS_URI_ORACLE_SOAP = "http://xmlns.oracle.com/soap/";
  
  public static final String NS_URN_ORACLE_SOAP = "urn:ns-oracle-com:soap";
  
  public static final String NS_URI_ORACLE_LITERAL_XML = "http://xmlns.oracle.com/soap/encoding/literalxml";
  
  public static final String NS_URI_ORACLE_XML_SOAP = "http://xmlns.oracle.com/xml-soap";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\OracleConstants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */