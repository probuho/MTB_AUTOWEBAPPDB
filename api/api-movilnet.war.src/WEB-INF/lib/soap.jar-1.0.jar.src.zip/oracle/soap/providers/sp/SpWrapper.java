/*     */ package oracle.soap.providers.sp;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpWrapper
/*     */ {
/*     */   private static final int N_ARGS = 4;
/*     */   private static final String CTX = "sqlj.runtime.ref.DefaultContext";
/*     */   private static final String SP_PROVIDER = "oracle.soap.providers.sp.SpProvider";
/*     */   private static final String WAIT_QUEUE = "oracle.soap.providers.sp.WaitQueue";
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*     */     try {
/*  65 */       if (paramArrayOfString.length != 4) {
/*     */         
/*  67 */         doUsage();
/*  68 */         System.exit(1);
/*     */       } 
/*     */       
/*  71 */       byte b = 0;
/*  72 */       String str1 = paramArrayOfString[b++];
/*  73 */       String str2 = paramArrayOfString[b++];
/*  74 */       String str3 = paramArrayOfString[b++];
/*  75 */       String str4 = paramArrayOfString[b++];
/*     */       
/*  77 */       String str5 = genClassP(str1, str2);
/*  78 */       String str6 = genClassP(str1, "sp_" + str2);
/*  79 */       String str7 = genJavaF(str1, str2);
/*     */       
/*  81 */       Class clazz = Class.forName(str6);
/*     */       
/*  83 */       StringWriter stringWriter = new StringWriter();
/*  84 */       PrintWriter printWriter1 = new PrintWriter(stringWriter);
/*     */       
/*  86 */       genWrapper(printWriter1, clazz, str1, str2, str3, str4);
/*  87 */       printWriter1.flush();
/*     */       
/*  89 */       PrintWriter printWriter2 = new PrintWriter(new FileOutputStream(str7));
/*     */       
/*  91 */       printWriter2.println(stringWriter.toString());
/*  92 */       printWriter2.flush();
/*     */       
/*  94 */       printWriter2.close();
/*  95 */       printWriter1.close();
/*  96 */       stringWriter.close();
/*     */     }
/*  98 */     catch (Exception exception) {
/*     */       
/* 100 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void genWrapper(PrintWriter paramPrintWriter, Class paramClass, String paramString1, String paramString2, String paramString3, String paramString4) throws Exception {
/* 110 */     String str1 = paramClass.getName();
/*     */ 
/*     */     
/* 113 */     paramPrintWriter.println("/* Oracle PL/SQL to SOAP wrapper */");
/* 114 */     paramPrintWriter.println("");
/*     */     
/* 116 */     if (paramString1 != null && !paramString1.equals("")) {
/*     */       
/* 118 */       paramPrintWriter.println("package " + paramString1 + ";");
/* 119 */       paramPrintWriter.println("");
/*     */       
/* 121 */       paramPrintWriter.println("import oracle.soap.providers.sp.SpProvider;");
/* 122 */       paramPrintWriter.println("import oracle.soap.providers.sp.WaitQueue;");
/* 123 */       paramPrintWriter.println("");
/*     */     } 
/*     */     
/* 126 */     paramPrintWriter.println("public class " + paramString2);
/* 127 */     paramPrintWriter.println("{");
/* 128 */     paramPrintWriter.println("    private static final String PROVIDER_NAME = \"" + paramString3 + "\";");
/* 129 */     paramPrintWriter.println("    private static final String SERVICE_NAME  = \"" + paramString4 + "\";");
/* 130 */     paramPrintWriter.println("");
/*     */     
/* 132 */     paramPrintWriter.println("    private static boolean   s_done = false;");
/* 133 */     paramPrintWriter.println("    private static oracle.soap.providers.sp.WaitQueue s_sps  = null;");
/* 134 */     paramPrintWriter.println("");
/*     */     
/* 136 */     String str2 = genExceptionSig(paramClass.getConstructor(null).getExceptionTypes());
/*     */     
/* 138 */     paramPrintWriter.println("    public " + paramString2 + "()" + str2);
/* 139 */     paramPrintWriter.println("    {");
/* 140 */     paramPrintWriter.println("        doInit();");
/* 141 */     paramPrintWriter.println("    }");
/* 142 */     paramPrintWriter.println("");
/*     */ 
/*     */     
/* 145 */     paramPrintWriter.println("    private static synchronized void doInit()" + str2);
/* 146 */     paramPrintWriter.println("    {");
/* 147 */     paramPrintWriter.println("        if (! s_done)");
/* 148 */     paramPrintWriter.println("        {");
/* 149 */     paramPrintWriter.println("            sqlj.runtime.ref.DefaultContext[] ctxs = oracle.soap.providers.sp.SpProvider.registerService(PROVIDER_NAME, SERVICE_NAME);");
/*     */ 
/*     */     
/* 152 */     paramPrintWriter.println("            " + str1 + "[] sps = new " + str1 + "[ctxs.length];");
/*     */     
/* 154 */     paramPrintWriter.println("            for (int i = 0; i < ctxs.length; ++i)");
/* 155 */     paramPrintWriter.println("            {");
/* 156 */     paramPrintWriter.println("                sps[i]  = new " + str1 + "(ctxs[i]);");
/*     */     
/* 158 */     paramPrintWriter.println("                ctxs[i].getConnection().setAutoCommit(true);");
/* 159 */     paramPrintWriter.println("            }");
/* 160 */     paramPrintWriter.println("            s_sps = new oracle.soap.providers.sp.WaitQueue(sps);");
/* 161 */     paramPrintWriter.println("");
/*     */     
/* 163 */     paramPrintWriter.println("            s_done = true;");
/* 164 */     paramPrintWriter.println("        }");
/* 165 */     paramPrintWriter.println("    }");
/* 166 */     paramPrintWriter.println("");
/*     */ 
/*     */     
/* 169 */     Method[] arrayOfMethod = paramClass.getDeclaredMethods();
/* 170 */     for (byte b = 0; arrayOfMethod != null && b < arrayOfMethod.length; b++) {
/*     */       
/* 172 */       Method method = arrayOfMethod[b];
/*     */       
/* 174 */       int i = method.getModifiers();
/* 175 */       if (Modifier.isPublic(i)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 180 */         i |= 0x20;
/*     */         
/* 182 */         Class clazz = method.getReturnType();
/* 183 */         String str3 = xlate(clazz);
/*     */         
/* 185 */         boolean bool = (clazz == null || clazz == void.class) ? true : false;
/*     */         
/* 187 */         paramPrintWriter.println("    " + Modifier.toString(i) + " " + str3 + " " + method.getName() + "(" + genFormals(method.getParameterTypes()) + ")" + genExceptionSig(method.getExceptionTypes()));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 192 */         paramPrintWriter.println("    {");
/* 193 */         paramPrintWriter.println("        " + str1 + " sp = (" + str1 + ") s_sps.get();");
/* 194 */         paramPrintWriter.println("        try");
/* 195 */         paramPrintWriter.println("        {");
/*     */         
/* 197 */         String str4 = "sp." + method.getName() + "(" + genActuals(method.getParameterTypes()) + ")";
/*     */ 
/*     */         
/* 200 */         paramPrintWriter.println("    " + (bool ? "" : "return ") + str4 + ";");
/*     */         
/* 202 */         paramPrintWriter.println("        }");
/* 203 */         paramPrintWriter.println("        finally");
/* 204 */         paramPrintWriter.println("        {");
/* 205 */         paramPrintWriter.println("            s_sps.release(sp);");
/* 206 */         paramPrintWriter.println("        }");
/* 207 */         paramPrintWriter.println("    }");
/* 208 */         paramPrintWriter.println("");
/*     */       } 
/*     */     } 
/* 211 */     paramPrintWriter.println("}");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String genClassP(String paramString1, String paramString2) {
/* 217 */     String str = "";
/* 218 */     if (paramString1 != null && !paramString1.equals(""))
/*     */     {
/* 220 */       str = paramString1 + ".";
/*     */     }
/*     */     
/* 223 */     str = str + paramString2;
/* 224 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String genJavaF(String paramString1, String paramString2) {
/* 229 */     String str = "";
/* 230 */     if (paramString1 != null && !paramString1.equals(""))
/*     */     {
/* 232 */       str = paramString1.replace('.', File.separatorChar) + File.separator;
/*     */     }
/*     */ 
/*     */     
/* 236 */     str = str + paramString2 + ".java";
/* 237 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String genExceptionSig(Class[] paramArrayOfClass) throws Exception {
/* 244 */     if (paramArrayOfClass == null || paramArrayOfClass.length == 0)
/*     */     {
/* 246 */       return "";
/*     */     }
/*     */     
/* 249 */     String str = " ";
/* 250 */     for (byte b = 0; b < paramArrayOfClass.length; b++) {
/*     */       
/* 252 */       if (b == 0) { str = str + "throws " + xlate(paramArrayOfClass[b]); }
/* 253 */       else { str = str + " , " + xlate(paramArrayOfClass[b]); }
/*     */     
/*     */     } 
/* 256 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String genFormals(Class[] paramArrayOfClass) throws Exception {
/* 261 */     if (paramArrayOfClass == null) {
/* 262 */       return "";
/*     */     }
/*     */     
/* 265 */     String str = "";
/* 266 */     for (byte b = 0; b < paramArrayOfClass.length; b++) {
/* 267 */       str = str + xlate(paramArrayOfClass[b]) + " __p" + b;
/* 268 */       str = str + ((b == paramArrayOfClass.length - 1) ? "" : ", ");
/*     */     } 
/*     */     
/* 271 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String genActuals(Class[] paramArrayOfClass) throws Exception {
/* 276 */     if (paramArrayOfClass == null) {
/* 277 */       return "";
/*     */     }
/*     */     
/* 280 */     String str = "";
/* 281 */     for (byte b = 0; b < paramArrayOfClass.length; b++) {
/* 282 */       str = str + "__p" + b;
/* 283 */       str = str + ((b == paramArrayOfClass.length - 1) ? "" : ", ");
/*     */     } 
/*     */     
/* 286 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String xlate(Class paramClass) throws Exception {
/* 292 */     return paramClass.isArray() ? (xlate(paramClass.getComponentType()) + "[]") : paramClass.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void doUsage() {
/* 300 */     System.err.println("Usage: SpWrapper <javaPackage> <className> <provider> <service>");
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\sp\SpWrapper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */