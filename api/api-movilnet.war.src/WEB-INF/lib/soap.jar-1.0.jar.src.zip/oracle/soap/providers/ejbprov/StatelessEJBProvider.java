/*     */ package oracle.soap.providers.ejbprov;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.ejb.EJBHome;
/*     */ import javax.ejb.EJBObject;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import oracle.dms.instrument.Noun;
/*     */ import oracle.dms.instrument.PhaseEvent;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.OracleSOAPContext;
/*     */ import oracle.soap.server.Provider;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.RequestContext;
/*     */ import oracle.soap.server.SOAPServerContext;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.RPCConstants;
/*     */ import org.apache.soap.rpc.Response;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.MethodUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatelessEJBProvider
/*     */   implements Provider
/*     */ {
/*     */   private ProviderDeploymentDescriptor m_pd;
/*     */   private Logger m_log;
/*     */   private String m_contextFactory;
/*     */   private String m_contextProviderURL;
/*     */   private String m_securityPrincipal;
/*     */   private String m_securityCredential;
/*     */   private PhaseEvent m_providerPhaseEvent;
/*     */   private String m_providerNounName;
/*     */   private static final String SECURITY_PRINCIPAL = "SecurityPrincipal";
/*     */   private static final String SECURITY_CREDENTIAL = "SecurityCredential";
/*     */   private static final String JNDI_LOCATION = "JNDILocation";
/*     */   private static final String CONTEXT_FACTORY_CLASS = "FullContextFactoryName";
/*     */   private static final String CONTEXT_PROVIDER_URL = "ContextProviderURL";
/*     */   private static final String DEPLOYMENT_NAME = "DeploymentName";
/*     */   
/*     */   public void init(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor, SOAPServerContext paramSOAPServerContext) throws SOAPException {
/* 130 */     this.m_pd = paramProviderDeploymentDescriptor;
/* 131 */     this.m_log = paramSOAPServerContext.getLogger();
/*     */     
/* 133 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 135 */       this.m_log.log("initializing provider '" + getId() + "'", 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 140 */     this.m_providerNounName = "|Soap|" + getId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     Noun noun = Noun.create(this.m_providerNounName, "SoapStatelessEJBProvider");
/* 147 */     this.m_providerPhaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Stateless EJB Provider");
/*     */ 
/*     */     
/* 150 */     this.m_providerPhaseEvent.deriveMetric(511);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     Hashtable hashtable = paramProviderDeploymentDescriptor.getOptions();
/* 156 */     this.m_securityPrincipal = (String)hashtable.get("SecurityPrincipal");
/* 157 */     this.m_securityCredential = (String)hashtable.get("SecurityCredential");
/* 158 */     this.m_contextFactory = (String)hashtable.get("FullContextFactoryName");
/* 159 */     this.m_contextProviderURL = (String)hashtable.get("ContextProviderURL");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws SOAPException {
/* 181 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 183 */       this.m_log.log("destroying provider '" + getId() + "'", 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 199 */     return this.m_pd.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(RequestContext paramRequestContext) throws SOAPException {
/* 220 */     EJBObject eJBObject = null;
/*     */     
/* 222 */     long l = 0L;
/*     */ 
/*     */     
/*     */     try {
/* 226 */       l = this.m_providerPhaseEvent.start();
/*     */       
/* 228 */       OracleSOAPContext oracleSOAPContext1 = paramRequestContext.getRequestSOAPContext();
/* 229 */       OracleSOAPContext oracleSOAPContext2 = paramRequestContext.getResponseSOAPContext();
/*     */       
/* 231 */       String str1 = paramRequestContext.getServiceId();
/*     */       
/* 233 */       ServiceDeploymentDescriptor serviceDeploymentDescriptor = oracleSOAPContext1.getServiceDeploymentDescriptor();
/*     */       
/* 235 */       SOAPMappingRegistry sOAPMappingRegistry = ServiceDeploymentDescriptor.buildSOAPMappingRegistry(serviceDeploymentDescriptor);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 240 */       if (serviceDeploymentDescriptor.getServiceType() == 1)
/*     */       {
/*     */         
/* 243 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Message-type services are not supported (service '" + str1 + "')");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 248 */       String str2 = paramRequestContext.getMethodName();
/*     */ 
/*     */ 
/*     */       
/* 252 */       if (!serviceDeploymentDescriptor.isMethodValid(str2)) {
/*     */         
/* 254 */         if (this.m_log.isLoggable(2))
/*     */         {
/* 256 */           this.m_log.log("method name '" + str2 + "' is unknown " + "for service '" + str1 + "'", 2);
/*     */         }
/*     */ 
/*     */         
/* 260 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "invalid method '" + str2 + "' in service '" + str1 + "'");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 269 */       Hashtable hashtable = serviceDeploymentDescriptor.getProviderOptions();
/*     */ 
/*     */ 
/*     */       
/* 273 */       String str3 = (String)hashtable.get("DeploymentName");
/*     */       
/* 275 */       if (str3 == null)
/*     */       {
/* 277 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Deployment Name not specified in Service Deployment Descriptor");
/*     */       }
/*     */       
/* 280 */       String str4 = (String)hashtable.get("JNDILocation");
/* 281 */       if (str4 == null)
/*     */       {
/* 283 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "JNDI Location not specified in Service Deployment Descriptor");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 288 */       Context context = getContext(str3);
/* 289 */       Call call = Call.extractFromEnvelope(paramRequestContext.getRequestEnvelope(), sOAPMappingRegistry, (SOAPContext)oracleSOAPContext1);
/* 290 */       paramRequestContext.setRequestEncodingStyle(call.getEncodingStyleURI());
/*     */       
/* 292 */       String str5 = call.getTargetObjectURI();
/*     */ 
/*     */       
/*     */       try {
/*     */         EJBHome eJBHome;
/*     */         
/* 298 */         Object object = context.lookup(str4);
/*     */ 
/*     */ 
/*     */         
/* 302 */         ClassLoader classLoader = paramRequestContext.getRequestSOAPContext().getClassLoader();
/*     */         
/* 304 */         if (classLoader == null) {
/* 305 */           eJBHome = (EJBHome)PortableRemoteObject.narrow(object, Class.forName("javax.ejb.EJBHome"));
/*     */         } else {
/*     */           
/* 308 */           eJBHome = (EJBHome)PortableRemoteObject.narrow(object, Class.forName("javax.ejb.EJBHome", true, classLoader));
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 315 */         Method method = eJBHome.getClass().getMethod("create", new Class[0]);
/* 316 */         eJBObject = (EJBObject)method.invoke(eJBHome, new Object[0]);
/*     */       
/*     */       }
/* 319 */       catch (Exception exception) {
/*     */ 
/*     */         
/* 322 */         System.out.println("Exception caught: " + exception.toString());
/* 323 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error in connecting to EJB", exception);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 328 */       Vector vector = call.getParams();
/* 329 */       String str6 = call.getEncodingStyleURI();
/* 330 */       Object[] arrayOfObject = null;
/* 331 */       Class[] arrayOfClass = null;
/* 332 */       if (vector != null) {
/*     */         
/* 334 */         int i = vector.size();
/* 335 */         arrayOfObject = new Object[i];
/* 336 */         arrayOfClass = new Class[i];
/* 337 */         for (byte b = 0; b < i; b++) {
/*     */           
/* 339 */           Parameter parameter = vector.elementAt(b);
/* 340 */           arrayOfObject[b] = parameter.getValue();
/* 341 */           arrayOfClass[b] = parameter.getType();
/* 342 */           if (str6 == null)
/*     */           {
/* 344 */             str6 = parameter.getEncodingStyleURI();
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 349 */       if (str6 == null)
/*     */       {
/*     */         
/* 352 */         str6 = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */       }
/*     */       
/* 355 */       paramRequestContext.setRequestEncodingStyle(str6);
/*     */ 
/*     */ 
/*     */       
/* 359 */       if (this.m_log.isLoggable(2))
/*     */       {
/* 361 */         this.m_log.log("provider '" + getId() + "' invoking method '" + str2 + "' for service '" + str1 + "'", 2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 366 */       Bean bean = null;
/*     */       
/*     */       try {
/* 369 */         Method method = MethodUtils.getMethod(eJBObject, call.getMethodName(), arrayOfClass);
/*     */         
/* 371 */         PhaseEvent phaseEvent = null;
/* 372 */         long l1 = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 378 */           Noun noun = Noun.create(this.m_providerNounName + "|" + str1, "SoapService");
/*     */ 
/*     */ 
/*     */           
/* 382 */           phaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Service");
/*     */ 
/*     */           
/* 385 */           phaseEvent.deriveMetric(511);
/*     */           
/* 387 */           l1 = phaseEvent.start();
/*     */ 
/*     */           
/* 390 */           bean = new Bean(method.getReturnType(), method.invoke(eJBObject, arrayOfObject));
/*     */         
/*     */         }
/*     */         finally {
/*     */ 
/*     */           
/* 396 */           phaseEvent.stop(l1);
/*     */         }
/*     */       
/* 399 */       } catch (InvocationTargetException invocationTargetException) {
/*     */         
/* 401 */         Throwable throwable = invocationTargetException.getTargetException();
/* 402 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */       
/*     */       }
/* 405 */       catch (Throwable throwable) {
/*     */         
/* 407 */         if (this.m_log.isLoggable(999))
/*     */         {
/* 409 */           this.m_log.log("Error in method '" + call.getMethodName() + "': " + throwable.getMessage() + "\n" + ServerUtils.getStackTrace(throwable), 999);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 414 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */       } 
/*     */ 
/*     */       
/* 418 */       if (this.m_log.isLoggable(2))
/*     */       {
/* 420 */         this.m_log.log("provider '" + getId() + "' completed method '" + str2 + "' for service '" + str1 + "'", 2);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 429 */         if (serviceDeploymentDescriptor.getServiceType() == 0)
/*     */         {
/*     */ 
/*     */           
/* 433 */           Parameter parameter = null;
/* 434 */           if (bean.type != void.class)
/*     */           {
/* 436 */             parameter = new Parameter(RPCConstants.ELEM_RETURN, bean.type, bean.value, null);
/*     */           }
/*     */           
/* 439 */           Response response = new Response(call.getTargetObjectURI(), call.getMethodName(), parameter, null, null, str6, (SOAPContext)oracleSOAPContext2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 448 */             Envelope envelope = response.buildEnvelope();
/* 449 */             paramRequestContext.setResponseEnvelope(envelope);
/* 450 */             paramRequestContext.setResponseMap(sOAPMappingRegistry);
/*     */           }
/* 452 */           catch (Exception exception) {
/*     */             
/* 454 */             throw new SOAPException(Constants.FAULT_CODE_SERVER, "error building response envelope: " + exception.getMessage(), exception);
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 466 */       catch (Exception exception) {
/*     */         
/* 468 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "error creating response: " + exception.getMessage(), exception);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 476 */       this.m_providerPhaseEvent.stop(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Context getContext(String paramString) throws SOAPException {
/* 487 */     InitialContext initialContext = null;
/*     */ 
/*     */     
/* 490 */     Properties properties = new Properties();
/*     */ 
/*     */     
/* 493 */     String str = this.m_contextProviderURL + "/" + paramString;
/*     */ 
/*     */ 
/*     */     
/* 497 */     properties.put("java.naming.provider.url", str);
/*     */     
/* 499 */     properties.put("java.naming.factory.initial", this.m_contextFactory);
/*     */ 
/*     */     
/* 502 */     properties.put("java.naming.security.principal", this.m_securityPrincipal);
/*     */ 
/*     */     
/* 505 */     properties.put("java.naming.security.credentials", this.m_securityCredential);
/*     */ 
/*     */     
/*     */     try {
/* 509 */       initialContext = new InitialContext(properties);
/*     */     }
/* 511 */     catch (NamingException namingException) {
/*     */       
/* 513 */       System.out.println("Naming Exception caught during InitialContext creation @ " + this.m_contextProviderURL);
/* 514 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Unable to initialize context");
/*     */     } 
/*     */     
/* 517 */     return initialContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\ejbprov\StatelessEJBProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */