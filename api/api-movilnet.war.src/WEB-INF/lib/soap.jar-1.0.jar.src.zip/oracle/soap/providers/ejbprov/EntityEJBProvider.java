/*     */ package oracle.soap.providers.ejbprov;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.ejb.EJBHome;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import oracle.dms.instrument.Noun;
/*     */ import oracle.dms.instrument.PhaseEvent;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.OracleSOAPContext;
/*     */ import oracle.soap.server.Provider;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.RequestContext;
/*     */ import oracle.soap.server.SOAPServerContext;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.RPCConstants;
/*     */ import org.apache.soap.rpc.Response;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.MethodUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityEJBProvider
/*     */   implements Provider
/*     */ {
/*     */   private ProviderDeploymentDescriptor m_pd;
/*     */   private Logger m_log;
/*     */   private String m_contextFactory;
/*     */   private String m_contextProviderURL;
/*     */   private String m_securityPrincipal;
/*     */   private String m_securityCredential;
/*     */   private PhaseEvent m_providerPhaseEvent;
/*     */   private String m_providerNounName;
/*     */   private static final String SECURITY_PRINCIPAL = "SecurityPrincipal";
/*     */   private static final String SECURITY_CREDENTIAL = "SecurityCredential";
/*     */   private static final String JNDI_LOCATION = "JNDILocation";
/*     */   private static final String CONTEXT_FACTORY_CLASS = "FullContextFactoryName";
/*     */   private static final String CONTEXT_PROVIDER_URL = "ContextProviderURL";
/*     */   private static final String DEPLOYMENT_NAME = "DeploymentName";
/*     */   private static final String EJBKEY = "EntityEJBKey";
/*     */   
/*     */   public void init(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor, SOAPServerContext paramSOAPServerContext) throws SOAPException {
/* 132 */     this.m_pd = paramProviderDeploymentDescriptor;
/* 133 */     this.m_log = paramSOAPServerContext.getLogger();
/*     */     
/* 135 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 137 */       this.m_log.log("initializing provider '" + getId() + "'", 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.m_providerNounName = "|Soap|" + getId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     Noun noun = Noun.create(this.m_providerNounName, "SoapEntityEJBProvider");
/* 149 */     this.m_providerPhaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Entity EJB Provider");
/*     */ 
/*     */     
/* 152 */     this.m_providerPhaseEvent.deriveMetric(511);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     Hashtable hashtable = paramProviderDeploymentDescriptor.getOptions();
/* 158 */     this.m_securityPrincipal = (String)hashtable.get("SecurityPrincipal");
/* 159 */     this.m_securityCredential = (String)hashtable.get("SecurityCredential");
/* 160 */     this.m_contextFactory = (String)hashtable.get("FullContextFactoryName");
/* 161 */     this.m_contextProviderURL = (String)hashtable.get("ContextProviderURL");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws SOAPException {
/* 183 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 185 */       this.m_log.log("destroying provider '" + getId() + "'", 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 201 */     return this.m_pd.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(RequestContext paramRequestContext) throws SOAPException {
/* 221 */     long l = 0L;
/* 222 */     boolean bool1 = true;
/* 223 */     EJBHome eJBHome = null;
/* 224 */     Object object = null;
/* 225 */     String str = null;
/* 226 */     boolean bool2 = false;
/* 227 */     Call call = null;
/*     */     
/*     */     try {
/*     */       Object object1;
/*     */       
/* 232 */       l = this.m_providerPhaseEvent.start();
/*     */       
/* 234 */       OracleSOAPContext oracleSOAPContext1 = paramRequestContext.getRequestSOAPContext();
/* 235 */       OracleSOAPContext oracleSOAPContext2 = paramRequestContext.getResponseSOAPContext();
/*     */ 
/*     */ 
/*     */       
/* 239 */       ServiceDeploymentDescriptor serviceDeploymentDescriptor = oracleSOAPContext1.getServiceDeploymentDescriptor();
/* 240 */       SOAPMappingRegistry sOAPMappingRegistry = ServiceDeploymentDescriptor.buildSOAPMappingRegistry(serviceDeploymentDescriptor);
/*     */ 
/*     */       
/* 243 */       call = Call.extractFromEnvelope(paramRequestContext.getRequestEnvelope(), sOAPMappingRegistry, (SOAPContext)oracleSOAPContext1);
/* 244 */       str = call.getFullTargetObjectURI();
/*     */ 
/*     */ 
/*     */       
/* 248 */       String str1 = paramRequestContext.getServiceId();
/*     */ 
/*     */       
/* 251 */       if (serviceDeploymentDescriptor.getServiceType() == 1)
/*     */       {
/*     */         
/* 254 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Message-type services are not supported (service '" + str1 + "')");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 259 */       String str2 = paramRequestContext.getMethodName();
/*     */       
/* 261 */       if (!serviceDeploymentDescriptor.isMethodValid(str2)) {
/*     */         
/* 263 */         if (this.m_log.isLoggable(2))
/*     */         {
/* 265 */           this.m_log.log("method name '" + str2 + "' is unknown " + "for service '" + str1 + "'", 2);
/*     */         }
/*     */ 
/*     */         
/* 269 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "invalid method '" + str2 + "' in service '" + str1 + "'");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 276 */       HttpSession httpSession = oracleSOAPContext1.getHttpSession();
/* 277 */       Object object2 = httpSession.getValue("EntityEJBKey");
/*     */ 
/*     */       
/* 280 */       if (str2.equals("create") || str2.startsWith("find")) {
/*     */         
/*     */         try
/*     */         {
/*     */ 
/*     */           
/* 286 */           EJBHome eJBHome1 = getEJBHome(serviceDeploymentDescriptor, paramRequestContext.getRequestSOAPContext().getClassLoader());
/*     */           
/* 288 */           eJBHome = eJBHome1;
/* 289 */           bool2 = true;
/*     */         }
/* 291 */         catch (Exception exception)
/*     */         {
/*     */           
/* 294 */           System.out.println("Exception caught: " + exception.toString());
/* 295 */           throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error in connecting to EJB", exception);
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 300 */       else if (object2 != null) {
/*     */         
/* 302 */         object1 = object2;
/* 303 */         bool1 = false;
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 310 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error in determining target EJB of Call");
/*     */       } 
/*     */ 
/*     */       
/* 314 */       Vector vector = call.getParams();
/* 315 */       String str3 = call.getEncodingStyleURI();
/* 316 */       Object[] arrayOfObject = null;
/* 317 */       Class[] arrayOfClass = null;
/* 318 */       if (vector != null) {
/*     */         
/* 320 */         int i = vector.size();
/* 321 */         arrayOfObject = new Object[i];
/* 322 */         arrayOfClass = new Class[i];
/* 323 */         for (byte b = 0; b < i; b++) {
/*     */           
/* 325 */           Parameter parameter = vector.elementAt(b);
/* 326 */           arrayOfObject[b] = parameter.getValue();
/* 327 */           arrayOfClass[b] = parameter.getType();
/* 328 */           if (str3 == null)
/*     */           {
/* 330 */             str3 = parameter.getEncodingStyleURI();
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 335 */       if (str3 == null)
/*     */       {
/*     */         
/* 338 */         str3 = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */       }
/*     */       
/* 341 */       paramRequestContext.setRequestEncodingStyle(str3);
/*     */ 
/*     */ 
/*     */       
/* 345 */       if (this.m_log.isLoggable(2))
/*     */       {
/* 347 */         this.m_log.log("provider '" + getId() + "' invoking method '" + str2 + "' for service '" + str1 + "'", 2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 352 */       Bean bean = null;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */         try {
/* 358 */           Method method1 = object1.getClass().getMethod(call.getMethodName(), arrayOfClass);
/*     */         }
/* 360 */         catch (Exception exception) {
/*     */           
/* 362 */           exception.printStackTrace();
/*     */         } 
/*     */ 
/*     */         
/* 366 */         Method method = MethodUtils.getMethod(object1, call.getMethodName(), arrayOfClass);
/*     */         
/* 368 */         PhaseEvent phaseEvent = null;
/* 369 */         long l1 = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 375 */           Noun noun = Noun.create(this.m_providerNounName + "|" + str1, "SoapService");
/*     */ 
/*     */ 
/*     */           
/* 379 */           phaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Service");
/*     */ 
/*     */           
/* 382 */           phaseEvent.deriveMetric(511);
/*     */           
/* 384 */           l1 = phaseEvent.start();
/*     */ 
/*     */ 
/*     */           
/* 388 */           bean = new Bean(method.getReturnType(), method.invoke(object1, arrayOfObject));
/*     */ 
/*     */         
/*     */         }
/*     */         finally {
/*     */ 
/*     */           
/* 395 */           phaseEvent.stop(l1);
/*     */         }
/*     */       
/* 398 */       } catch (InvocationTargetException invocationTargetException) {
/*     */         
/* 400 */         Throwable throwable = invocationTargetException.getTargetException();
/* 401 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */       
/*     */       }
/* 404 */       catch (Throwable throwable) {
/*     */         
/* 406 */         if (this.m_log.isLoggable(999))
/*     */         {
/* 408 */           this.m_log.log("Error in method '" + call.getMethodName() + "': " + throwable.getMessage() + "\n" + ServerUtils.getStackTrace(throwable), 999);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 413 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */       } 
/*     */ 
/*     */       
/* 417 */       if (this.m_log.isLoggable(2))
/*     */       {
/* 419 */         this.m_log.log("provider '" + getId() + "' completed method '" + str2 + "' for service '" + str1 + "'", 2);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 429 */         if (serviceDeploymentDescriptor.getServiceType() == 0)
/*     */         {
/*     */ 
/*     */           
/* 433 */           Parameter parameter = null;
/* 434 */           if (bean.type != void.class)
/*     */           {
/* 436 */             parameter = new Parameter(RPCConstants.ELEM_RETURN, bean.type, bean.value, null);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 441 */           if (bool2) {
/*     */ 
/*     */             
/*     */             try {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 449 */               object1 = parameter.getValue();
/* 450 */             } catch (ClassCastException classCastException) {
/*     */ 
/*     */ 
/*     */               
/* 454 */               throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error : Find method returns a Collection", classCastException);
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 459 */             parameter = null;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 469 */           String str4 = call.getTargetObjectURI();
/*     */           
/* 471 */           Response response = new Response(str4, call.getMethodName(), parameter, null, null, str3, (SOAPContext)oracleSOAPContext2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 479 */           if (bool1 || bool2) {
/* 480 */             httpSession.putValue("EntityEJBKey", object1);
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/* 485 */             Envelope envelope = response.buildEnvelope();
/* 486 */             paramRequestContext.setResponseEnvelope(envelope);
/* 487 */             paramRequestContext.setResponseMap(sOAPMappingRegistry);
/*     */           }
/* 489 */           catch (Exception exception) {
/*     */             
/* 491 */             throw new SOAPException(Constants.FAULT_CODE_SERVER, "error building response envelope: " + exception.getMessage(), exception);
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 503 */       catch (Exception exception) {
/*     */         
/* 505 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "error creating response: " + exception.getMessage(), exception);
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 515 */       this.m_providerPhaseEvent.stop(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EJBHome getEJBHome(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor, ClassLoader paramClassLoader) throws Exception {
/*     */     EJBHome eJBHome;
/* 526 */     Hashtable hashtable = paramServiceDeploymentDescriptor.getProviderOptions();
/*     */ 
/*     */ 
/*     */     
/* 530 */     String str1 = (String)hashtable.get("DeploymentName");
/*     */     
/* 532 */     if (str1 == null)
/*     */     {
/* 534 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Deployment Name not specified in Service Deployment Descriptor");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 539 */     String str2 = (String)hashtable.get("JNDILocation");
/* 540 */     if (str2 == null)
/*     */     {
/* 542 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "JNDI Location  not specified in Service Deployment Descriptor");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 548 */     Context context = getContext(str1);
/*     */ 
/*     */ 
/*     */     
/* 552 */     Object object = context.lookup(str2);
/*     */ 
/*     */     
/* 555 */     if (paramClassLoader == null) {
/* 556 */       eJBHome = (EJBHome)PortableRemoteObject.narrow(object, Class.forName("javax.ejb.EJBHome"));
/*     */     } else {
/* 558 */       eJBHome = (EJBHome)PortableRemoteObject.narrow(object, Class.forName("javax.ejb.EJBHome", true, paramClassLoader));
/*     */     } 
/*     */ 
/*     */     
/* 562 */     return eJBHome;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Context getContext(String paramString) throws SOAPException {
/* 572 */     InitialContext initialContext = null;
/*     */ 
/*     */     
/* 575 */     Properties properties = new Properties();
/*     */ 
/*     */     
/* 578 */     String str = this.m_contextProviderURL + "/" + paramString;
/*     */ 
/*     */     
/* 581 */     properties.put("java.naming.provider.url", str);
/* 582 */     properties.put("java.naming.factory.initial", this.m_contextFactory);
/* 583 */     properties.put("java.naming.security.principal", this.m_securityPrincipal);
/* 584 */     properties.put("java.naming.security.credentials", this.m_securityCredential);
/*     */     
/*     */     try {
/* 587 */       initialContext = new InitialContext(properties);
/*     */     }
/* 589 */     catch (NamingException namingException) {
/*     */       
/* 591 */       System.out.println("Naming Exception caught during InitialContext creation @ " + this.m_contextProviderURL);
/* 592 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Unable to initialize context");
/*     */     } 
/*     */     
/* 595 */     return initialContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\ejbprov\EntityEJBProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */