/*     */ package oracle.soap.providers.sp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WaitQueue
/*     */ {
/*     */   public WaitQueue(Object[] paramArrayOfObject) {
/*  44 */     for (byte b = 0; paramArrayOfObject != null && b < paramArrayOfObject.length; b++) {
/*     */       
/*  46 */       if (paramArrayOfObject[b] != null)
/*     */       {
/*  48 */         this.m_objs.put(paramArrayOfObject[b]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object get() {
/*  73 */     Object object = null;
/*     */     
/*  75 */     while (this.m_objs.size() < 1) {
/*     */ 
/*     */       
/*     */       try {
/*  79 */         wait();
/*     */       }
/*  81 */       catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     Object object1 = this.m_objs.getAny();
/*  88 */     this.m_objs.remove(object1);
/*     */     
/*  90 */     return object1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void release(Object paramObject) {
/* 112 */     if (paramObject != null)
/*     */     {
/* 114 */       this.m_objs.put(paramObject);
/*     */     }
/*     */     
/* 117 */     notify();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   private Hashset m_objs = new Hashset();
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\sp\WaitQueue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */