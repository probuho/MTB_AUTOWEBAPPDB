/*     */ package oracle.soap.providers.sp;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import oracle.dms.instrument.Noun;
/*     */ import oracle.dms.instrument.State;
/*     */ import oracle.jdbc.pool.OracleDataSource;
/*     */ import oracle.soap.providers.JavaProvider;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.SOAPServerContext;
/*     */ import oracle.sqlj.runtime.Oracle;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.SOAPException;
/*     */ import sqlj.runtime.ref.DefaultContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpProvider
/*     */   extends JavaProvider
/*     */ {
/*     */   public void init(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor, SOAPServerContext paramSOAPServerContext) throws SOAPException {
/* 107 */     super.init(paramProviderDeploymentDescriptor, paramSOAPServerContext);
/*     */ 
/*     */     
/* 110 */     Hashtable hashtable = paramProviderDeploymentDescriptor.getOptions();
/*     */     
/* 112 */     this.m_dbUser = (String)hashtable.get("user");
/* 113 */     this.m_dbPass = (String)hashtable.get("password");
/* 114 */     this.m_dbUrl = (String)hashtable.get("url");
/*     */     
/* 116 */     if (hashtable.containsKey("connections_per_service"))
/*     */     {
/* 118 */       this.m_nCtxs = Integer.parseInt((String)hashtable.get("connections_per_service"));
/*     */     }
/*     */     
/* 121 */     this.m_log = paramSOAPServerContext.getLogger();
/*     */ 
/*     */     
/* 124 */     checkString(this.m_dbUser, "user");
/* 125 */     checkString(this.m_dbPass, "password");
/* 126 */     checkString(this.m_dbUrl, "url");
/* 127 */     checkInt(this.m_nCtxs, "connections_per_service");
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 132 */       this.m_ds = new OracleDataSource();
/*     */       
/* 134 */       this.m_ds.setUser(this.m_dbUser);
/* 135 */       this.m_ds.setPassword(this.m_dbPass);
/* 136 */       this.m_ds.setURL(this.m_dbUrl);
/*     */       
/* 138 */       Oracle.connect(this.m_dbUrl, this.m_dbUser, this.m_dbPass);
/*     */ 
/*     */       
/* 141 */       Noun noun = Noun.create("|Soap|SpProvider|" + getId(), "SpProvider");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       this.m_connState = State.create(noun, "connections", "", "# jdbc connections to backend database", 0);
/*     */ 
/*     */ 
/*     */       
/* 153 */       this.m_connState.update(1);
/*     */     }
/* 155 */     catch (Exception exception) {
/*     */       
/* 157 */       this.m_log.log("unable to initialize JDBC/SQLJ connections", exception, 2);
/*     */       
/* 159 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "unable to initialize JDBC/SQLJ connections", exception);
/*     */     } 
/*     */ 
/*     */     
/* 163 */     s_sps.put(getId(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws SOAPException {
/* 186 */     s_sps.remove(getId());
/*     */ 
/*     */     
/*     */     try {
/* 190 */       Enumeration enumeration = this.m_ctxs.keys();
/* 191 */       while (enumeration.hasMoreElements()) {
/*     */         
/* 193 */         String str = enumeration.nextElement();
/* 194 */         cleanService((DefaultContext[])this.m_ctxs.get(str));
/*     */       } 
/* 196 */       this.m_ctxs.clear();
/*     */       
/* 198 */       Oracle.close();
/*     */ 
/*     */       
/* 201 */       this.m_connState.update(0);
/* 202 */       this.m_connState.destroy();
/*     */     }
/* 204 */     catch (Exception exception) {
/*     */       
/* 206 */       this.m_log.log("unable to terminate JDBC/SQLJ connections", exception, 2);
/*     */       
/* 208 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "unable to terminate JDBC/SQLJ connections", exception);
/*     */     } 
/*     */ 
/*     */     
/* 212 */     super.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized DefaultContext[] registerService(String paramString1, String paramString2) throws SQLException {
/* 251 */     if (!s_sps.containsKey(paramString1))
/*     */     {
/* 253 */       throw new RuntimeException("no such provider `" + paramString1 + "'");
/*     */     }
/*     */ 
/*     */     
/* 257 */     SpProvider spProvider = (SpProvider)s_sps.get(paramString1);
/* 258 */     if (spProvider.m_ctxs.containsKey(paramString2))
/*     */     {
/* 260 */       cleanService((DefaultContext[])spProvider.m_ctxs.get(paramString2));
/*     */     }
/*     */ 
/*     */     
/* 264 */     spProvider.m_connState.update(spProvider.numConnections());
/*     */ 
/*     */     
/* 267 */     DefaultContext[] arrayOfDefaultContext = new DefaultContext[spProvider.m_nCtxs];
/* 268 */     for (byte b = 0; b < arrayOfDefaultContext.length; b++) {
/*     */       
/* 270 */       arrayOfDefaultContext[b] = new DefaultContext(spProvider.m_ds.getConnection());
/* 271 */       arrayOfDefaultContext[b].getConnection().setAutoCommit(true);
/*     */     } 
/*     */     
/* 274 */     spProvider.m_ctxs.put(paramString2, arrayOfDefaultContext);
/*     */ 
/*     */     
/* 277 */     spProvider.m_connState.update(spProvider.numConnections());
/*     */     
/* 279 */     return arrayOfDefaultContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numConnections() {
/* 304 */     int i = 1;
/*     */     
/* 306 */     Enumeration enumeration = this.m_ctxs.elements();
/* 307 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 309 */       DefaultContext[] arrayOfDefaultContext = enumeration.nextElement();
/* 310 */       i += arrayOfDefaultContext.length;
/*     */     } 
/*     */     
/* 313 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void cleanService(DefaultContext[] paramArrayOfDefaultContext) {
/* 330 */     for (byte b = 0; b < paramArrayOfDefaultContext.length; b++) {
/*     */ 
/*     */       
/*     */       try {
/* 334 */         paramArrayOfDefaultContext[b].close();
/*     */       }
/* 336 */       catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkString(String paramString1, String paramString2) throws SOAPException {
/* 364 */     if (paramString1 == null || paramString1.equals("")) {
/*     */       
/* 366 */       this.m_log.log("invalid value for `" + paramString2 + "'", 2);
/*     */       
/* 368 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "invalid value for `" + paramString2 + "'");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkInt(int paramInt, String paramString) throws SOAPException {
/* 394 */     if (paramInt <= 0) {
/*     */       
/* 396 */       this.m_log.log("invalid integer `" + paramInt + "' for `" + paramString + "'", 2);
/*     */       
/* 398 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "invalid integer `" + paramInt + "' for `" + paramString + "'");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 413 */   private String m_dbUser = null;
/* 414 */   private String m_dbPass = null;
/* 415 */   private String m_dbUrl = null;
/* 416 */   private int m_nCtxs = 10;
/*     */   
/* 418 */   private Logger m_log = null;
/*     */   
/* 420 */   private State m_connState = null;
/* 421 */   private OracleDataSource m_ds = null;
/* 422 */   private Hashtable m_ctxs = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 432 */   private static Hashtable s_sps = new Hashtable();
/*     */   private static final String USER_OPT = "user";
/*     */   private static final String PASS_OPT = "password";
/*     */   private static final String URL_OPT = "url";
/*     */   private static final String CONN_OPT = "connections_per_service";
/*     */   private static final int DEFAULT_CONN = 10;
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\sp\SpProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */