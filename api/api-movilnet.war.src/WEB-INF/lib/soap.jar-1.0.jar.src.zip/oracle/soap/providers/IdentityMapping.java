/*     */ package oracle.soap.providers;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Hashtable;
/*     */ import oracle.soap.util.xml.XmlUtils;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.util.xml.DOMUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentityMapping
/*     */ {
/*     */   public static final String NS_URI = "http://ns.oracle.com/soap/security";
/*     */   private static final String E_IM = "IdentityMapping";
/*     */   private static final String E_ME = "MapEntry";
/*     */   private static final String A_DEFAULT_TO = "defaultTo";
/*     */   private static final String A_FROM = "from";
/*     */   private static final String A_TO = "to";
/*  45 */   private static final String s_nullMarker = new String();
/*     */   
/*  47 */   private String m_defaultTo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Hashtable m_mapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdentityMapping(String paramString) throws SOAPException {
/*  63 */     this(XmlUtils.parseXml(paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdentityMapping(URL paramURL) throws IOException, SOAPException {
/*  79 */     this(paramURL.openStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdentityMapping(InputStream paramInputStream) throws SOAPException {
/*  95 */     init(XmlUtils.parseXml(paramInputStream).getDocumentElement());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdentityMapping(Document paramDocument) {
/* 107 */     init(paramDocument.getDocumentElement());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdentityMapping(Element paramElement) {
/* 119 */     init(paramElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(Element paramElement) throws IllegalArgumentException {
/* 130 */     String str = paramElement.getNamespaceURI();
/* 131 */     if (str == null || !str.equals("http://ns.oracle.com/soap/security")) {
/* 132 */       throw new IllegalArgumentException("The element/document does not belong to the correct namespace. Expected NS of: http://ns.oracle.com/soap/security Instead got: " + str);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 137 */     str = paramElement.getLocalName();
/* 138 */     if (str == null || !str.equals("IdentityMapping")) {
/* 139 */       throw new IllegalArgumentException("The element/document does not have the correct top level tagname. Expected tagname: IdentityMapping Instead got: " + str);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 144 */     str = DOMUtils.getAttribute(paramElement, "defaultTo");
/* 145 */     this.m_defaultTo = str;
/*     */ 
/*     */     
/* 148 */     NodeList nodeList = paramElement.getElementsByTagNameNS("http://ns.oracle.com/soap/security", "MapEntry");
/* 149 */     if (nodeList != null) {
/*     */       
/* 151 */       int i = nodeList.getLength();
/* 152 */       this.m_mapping = new Hashtable(i);
/* 153 */       for (byte b = 0; b < i; b++) {
/*     */         
/* 155 */         Element element = (Element)nodeList.item(b);
/* 156 */         String str1 = DOMUtils.getAttribute(element, "from");
/* 157 */         if (str1 == null) {
/* 158 */           throw new IllegalArgumentException("Not a valid XML doc. Element: " + element.getLocalName() + " does not have the attribute: " + "from");
/*     */         }
/* 160 */         String str2 = DOMUtils.getAttribute(element, "to");
/* 161 */         if (str2 == null) {
/* 162 */           this.m_mapping.put(str1, s_nullMarker);
/*     */         } else {
/* 164 */           this.m_mapping.put(str1, str2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMappedIdentity(String paramString) {
/* 178 */     String str = null;
/* 179 */     if (this.m_mapping != null)
/* 180 */       str = (String)this.m_mapping.get(paramString); 
/* 181 */     if (str == null)
/* 182 */       str = this.m_defaultTo; 
/* 183 */     if (str == s_nullMarker)
/* 184 */       str = null; 
/* 185 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\IdentityMapping.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */