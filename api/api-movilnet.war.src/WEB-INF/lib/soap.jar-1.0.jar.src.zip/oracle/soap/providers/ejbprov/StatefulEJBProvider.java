/*     */ package oracle.soap.providers.ejbprov;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.ejb.EJBHome;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import oracle.dms.instrument.Noun;
/*     */ import oracle.dms.instrument.PhaseEvent;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.OracleSOAPContext;
/*     */ import oracle.soap.server.Provider;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.RequestContext;
/*     */ import oracle.soap.server.SOAPServerContext;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.RPCConstants;
/*     */ import org.apache.soap.rpc.Response;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.MethodUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatefulEJBProvider
/*     */   implements Provider
/*     */ {
/*     */   private ProviderDeploymentDescriptor m_pd;
/*     */   private Logger m_log;
/*     */   private String m_contextFactory;
/*     */   private String m_contextProviderURL;
/*     */   private String m_securityPrincipal;
/*     */   private String m_securityCredential;
/*     */   private PhaseEvent m_providerPhaseEvent;
/*     */   private String m_providerNounName;
/*     */   private static final String SECURITY_PRINCIPAL = "SecurityPrincipal";
/*     */   private static final String SECURITY_CREDENTIAL = "SecurityCredential";
/*     */   private static final String JNDI_LOCATION = "JNDILocation";
/*     */   private static final String CONTEXT_FACTORY_CLASS = "FullContextFactoryName";
/*     */   private static final String CONTEXT_PROVIDER_URL = "ContextProviderURL";
/*     */   private static final String DEPLOYMENT_NAME = "DeploymentName";
/*     */   private static final String EJBKEY = "StatefulEJBKey";
/*     */   
/*     */   public void init(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor, SOAPServerContext paramSOAPServerContext) throws SOAPException {
/* 126 */     this.m_pd = paramProviderDeploymentDescriptor;
/* 127 */     this.m_log = paramSOAPServerContext.getLogger();
/*     */     
/* 129 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 131 */       this.m_log.log("initializing provider '" + getId() + "'", 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 136 */     this.m_providerNounName = "|Soap|" + getId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     Noun noun = Noun.create(this.m_providerNounName, "SoapStatefulEJBProvider");
/* 143 */     this.m_providerPhaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Stateful EJB Provider");
/*     */ 
/*     */     
/* 146 */     this.m_providerPhaseEvent.deriveMetric(511);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     Hashtable hashtable = paramProviderDeploymentDescriptor.getOptions();
/* 152 */     this.m_securityPrincipal = (String)hashtable.get("SecurityPrincipal");
/* 153 */     this.m_securityCredential = (String)hashtable.get("SecurityCredential");
/* 154 */     this.m_contextFactory = (String)hashtable.get("FullContextFactoryName");
/* 155 */     this.m_contextProviderURL = (String)hashtable.get("ContextProviderURL");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws SOAPException {
/* 177 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 179 */       this.m_log.log("destroying provider '" + getId() + "'", 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 195 */     return this.m_pd.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(RequestContext paramRequestContext) throws SOAPException {
/* 215 */     long l = 0L;
/* 216 */     boolean bool1 = true;
/* 217 */     EJBHome eJBHome = null;
/* 218 */     Object object = null;
/* 219 */     String str = null;
/* 220 */     boolean bool2 = false;
/* 221 */     Call call = null;
/*     */     
/*     */     try {
/*     */       Object object1;
/*     */       
/* 226 */       l = this.m_providerPhaseEvent.start();
/*     */       
/* 228 */       OracleSOAPContext oracleSOAPContext1 = paramRequestContext.getRequestSOAPContext();
/* 229 */       OracleSOAPContext oracleSOAPContext2 = paramRequestContext.getResponseSOAPContext();
/*     */ 
/*     */ 
/*     */       
/* 233 */       ServiceDeploymentDescriptor serviceDeploymentDescriptor = oracleSOAPContext1.getServiceDeploymentDescriptor();
/*     */       
/* 235 */       SOAPMappingRegistry sOAPMappingRegistry = ServiceDeploymentDescriptor.buildSOAPMappingRegistry(serviceDeploymentDescriptor);
/*     */ 
/*     */       
/* 238 */       call = Call.extractFromEnvelope(paramRequestContext.getRequestEnvelope(), sOAPMappingRegistry, (SOAPContext)oracleSOAPContext1);
/* 239 */       str = call.getFullTargetObjectURI();
/*     */ 
/*     */ 
/*     */       
/* 243 */       String str1 = paramRequestContext.getServiceId();
/*     */ 
/*     */       
/* 246 */       if (serviceDeploymentDescriptor.getServiceType() == 1)
/*     */       {
/*     */         
/* 249 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "Message-type services are not supported (service '" + str1 + "')");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 254 */       String str2 = paramRequestContext.getMethodName();
/*     */       
/* 256 */       if (!serviceDeploymentDescriptor.isMethodValid(str2)) {
/*     */         
/* 258 */         if (this.m_log.isLoggable(2))
/*     */         {
/* 260 */           this.m_log.log("method name '" + str2 + "' is unknown " + "for service '" + str1 + "'", 2);
/*     */         }
/*     */ 
/*     */         
/* 264 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "invalid method '" + str2 + "' in service '" + str1 + "'");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 271 */       HttpSession httpSession = oracleSOAPContext1.getHttpSession();
/* 272 */       Object object2 = httpSession.getValue("StatefulEJBKey");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 277 */       if (str2.equals("create")) {
/*     */         
/*     */         try
/*     */         {
/*     */ 
/*     */           
/* 283 */           EJBHome eJBHome1 = getEJBHome(serviceDeploymentDescriptor, paramRequestContext.getRequestSOAPContext().getClassLoader());
/*     */           
/* 285 */           eJBHome = eJBHome1;
/* 286 */           bool2 = true;
/*     */         }
/* 288 */         catch (Exception exception)
/*     */         {
/*     */           
/* 291 */           System.out.println("Exception caught: " + exception.toString());
/* 292 */           throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error in connecting to EJB", exception);
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 297 */       else if (object2 != null) {
/*     */         
/* 299 */         object1 = object2;
/* 300 */         bool1 = false;
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 307 */           EJBHome eJBHome1 = getEJBHome(serviceDeploymentDescriptor, paramRequestContext.getRequestSOAPContext().getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 313 */           Method method = eJBHome1.getClass().getMethod("create", new Class[0]);
/* 314 */           object1 = method.invoke(eJBHome1, new Object[0]);
/*     */ 
/*     */         
/*     */         }
/* 318 */         catch (Exception exception) {
/*     */ 
/*     */           
/* 321 */           System.out.println("Exception caught: " + exception.toString());
/* 322 */           throw new SOAPException(Constants.FAULT_CODE_SERVER, "Error in connecting to EJB", exception);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 329 */       Vector vector = call.getParams();
/* 330 */       String str3 = call.getEncodingStyleURI();
/* 331 */       Object[] arrayOfObject = null;
/* 332 */       Class[] arrayOfClass = null;
/* 333 */       if (vector != null) {
/*     */         
/* 335 */         int i = vector.size();
/* 336 */         arrayOfObject = new Object[i];
/* 337 */         arrayOfClass = new Class[i];
/* 338 */         for (byte b = 0; b < i; b++) {
/*     */           
/* 340 */           Parameter parameter = vector.elementAt(b);
/* 341 */           arrayOfObject[b] = parameter.getValue();
/* 342 */           arrayOfClass[b] = parameter.getType();
/* 343 */           if (str3 == null)
/*     */           {
/* 345 */             str3 = parameter.getEncodingStyleURI();
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 350 */       if (str3 == null)
/*     */       {
/*     */         
/* 353 */         str3 = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */       }
/*     */       
/* 356 */       paramRequestContext.setRequestEncodingStyle(str3);
/*     */ 
/*     */ 
/*     */       
/* 360 */       if (this.m_log.isLoggable(2))
/*     */       {
/* 362 */         this.m_log.log("provider '" + getId() + "' invoking method '" + str2 + "' for service '" + str1 + "'", 2);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 371 */       Bean bean = null;
/*     */ 
/*     */       
/*     */       try {
/* 375 */         Method method = MethodUtils.getMethod(object1, call.getMethodName(), arrayOfClass);
/*     */ 
/*     */         
/* 378 */         PhaseEvent phaseEvent = null;
/* 379 */         long l1 = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 385 */           Noun noun = Noun.create(this.m_providerNounName + "|" + str1, "SoapService");
/*     */ 
/*     */ 
/*     */           
/* 389 */           phaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Service");
/*     */ 
/*     */           
/* 392 */           phaseEvent.deriveMetric(511);
/*     */           
/* 394 */           l1 = phaseEvent.start();
/*     */ 
/*     */ 
/*     */           
/* 398 */           bean = new Bean(method.getReturnType(), method.invoke(object1, arrayOfObject));
/*     */ 
/*     */         
/*     */         }
/*     */         finally {
/*     */ 
/*     */           
/* 405 */           phaseEvent.stop(l1);
/*     */         }
/*     */       
/* 408 */       } catch (InvocationTargetException invocationTargetException) {
/*     */         
/* 410 */         Throwable throwable = invocationTargetException.getTargetException();
/* 411 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */       
/*     */       }
/* 414 */       catch (Throwable throwable) {
/*     */         
/* 416 */         if (this.m_log.isLoggable(999))
/*     */         {
/* 418 */           this.m_log.log("Error in method '" + call.getMethodName() + "': " + throwable.getMessage() + "\n" + ServerUtils.getStackTrace(throwable), 999);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 423 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */       } 
/*     */ 
/*     */       
/* 427 */       if (this.m_log.isLoggable(2))
/*     */       {
/* 429 */         this.m_log.log("provider '" + getId() + "' completed method '" + str2 + "' for service '" + str1 + "'", 2);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 439 */         if (serviceDeploymentDescriptor.getServiceType() == 0)
/*     */         {
/*     */ 
/*     */           
/* 443 */           Parameter parameter = null;
/* 444 */           if (bean.type != void.class)
/*     */           {
/* 446 */             parameter = new Parameter(RPCConstants.ELEM_RETURN, bean.type, bean.value, null);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 451 */           if (bool2) {
/*     */ 
/*     */             
/*     */             try {
/*     */ 
/*     */ 
/*     */               
/* 458 */               object1 = parameter.getValue();
/* 459 */             } catch (ClassCastException classCastException) {
/*     */               
/* 461 */               Enumeration enumeration = (Enumeration)parameter.getValue();
/* 462 */               object1 = enumeration.nextElement();
/*     */             } 
/*     */ 
/*     */             
/* 466 */             parameter = null;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 476 */           String str4 = call.getTargetObjectURI();
/*     */           
/* 478 */           Response response = new Response(str4, call.getMethodName(), parameter, null, null, str3, (SOAPContext)oracleSOAPContext2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 486 */           if (bool1 || bool2) {
/* 487 */             httpSession.putValue("StatefulEJBKey", object1);
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/* 492 */             Envelope envelope = response.buildEnvelope();
/* 493 */             paramRequestContext.setResponseEnvelope(envelope);
/* 494 */             paramRequestContext.setResponseMap(sOAPMappingRegistry);
/*     */           }
/* 496 */           catch (Exception exception) {
/*     */             
/* 498 */             throw new SOAPException(Constants.FAULT_CODE_SERVER, "error building response envelope: " + exception.getMessage(), exception);
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 510 */       catch (Exception exception) {
/*     */         
/* 512 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "error creating response: " + exception.getMessage(), exception);
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 522 */       this.m_providerPhaseEvent.stop(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EJBHome getEJBHome(ServiceDeploymentDescriptor paramServiceDeploymentDescriptor, ClassLoader paramClassLoader) throws Exception {
/*     */     EJBHome eJBHome;
/* 534 */     Hashtable hashtable = paramServiceDeploymentDescriptor.getProviderOptions();
/*     */ 
/*     */ 
/*     */     
/* 538 */     String str1 = (String)hashtable.get("DeploymentName");
/*     */     
/* 540 */     if (str1 == null)
/*     */     {
/* 542 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Deployment Name not specified in Service Deployment Descriptor");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 547 */     String str2 = (String)hashtable.get("JNDILocation");
/* 548 */     if (str2 == null)
/*     */     {
/* 550 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "JNDI Location  not specified in Service Deployment Descriptor");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 556 */     Context context = getContext(str1);
/*     */ 
/*     */ 
/*     */     
/* 560 */     Object object = context.lookup(str2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 565 */     if (paramClassLoader == null) {
/* 566 */       eJBHome = (EJBHome)PortableRemoteObject.narrow(object, Class.forName("javax.ejb.EJBHome"));
/*     */     } else {
/* 568 */       eJBHome = (EJBHome)PortableRemoteObject.narrow(object, Class.forName("javax.ejb.EJBHome", true, paramClassLoader));
/*     */     } 
/*     */     
/* 571 */     return eJBHome;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Context getContext(String paramString) throws SOAPException {
/* 581 */     InitialContext initialContext = null;
/*     */ 
/*     */     
/* 584 */     Properties properties = new Properties();
/*     */ 
/*     */     
/* 587 */     String str = this.m_contextProviderURL + "/" + paramString;
/*     */ 
/*     */     
/* 590 */     properties.put("java.naming.provider.url", str);
/* 591 */     properties.put("java.naming.factory.initial", this.m_contextFactory);
/* 592 */     properties.put("java.naming.security.principal", this.m_securityPrincipal);
/* 593 */     properties.put("java.naming.security.credentials", this.m_securityCredential);
/*     */     
/*     */     try {
/* 596 */       initialContext = new InitialContext(properties);
/*     */     }
/* 598 */     catch (NamingException namingException) {
/*     */       
/* 600 */       System.out.println("Naming Exception caught during InitialContext creation @ " + this.m_contextProviderURL);
/* 601 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Unable to initialize context");
/*     */     } 
/*     */     
/* 604 */     return initialContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\ejbprov\StatefulEJBProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */