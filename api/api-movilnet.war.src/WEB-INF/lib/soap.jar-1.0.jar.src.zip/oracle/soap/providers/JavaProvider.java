/*     */ package oracle.soap.providers;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import oracle.dms.instrument.Noun;
/*     */ import oracle.dms.instrument.PhaseEvent;
/*     */ import oracle.soap.encoding.soapenc.EncUtils;
/*     */ import oracle.soap.server.Logger;
/*     */ import oracle.soap.server.OracleSOAPContext;
/*     */ import oracle.soap.server.Provider;
/*     */ import oracle.soap.server.ProviderDeploymentDescriptor;
/*     */ import oracle.soap.server.RequestContext;
/*     */ import oracle.soap.server.SOAPServerContext;
/*     */ import oracle.soap.server.ServiceDeploymentDescriptor;
/*     */ import oracle.soap.server.util.ServerUtils;
/*     */ import org.apache.soap.Constants;
/*     */ import org.apache.soap.Envelope;
/*     */ import org.apache.soap.SOAPException;
/*     */ import org.apache.soap.encoding.SOAPMappingRegistry;
/*     */ import org.apache.soap.rpc.Call;
/*     */ import org.apache.soap.rpc.Parameter;
/*     */ import org.apache.soap.rpc.RPCConstants;
/*     */ import org.apache.soap.rpc.Response;
/*     */ import org.apache.soap.rpc.SOAPContext;
/*     */ import org.apache.soap.util.Bean;
/*     */ import org.apache.soap.util.MethodUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaProvider
/*     */   implements Provider
/*     */ {
/*     */   private ProviderDeploymentDescriptor m_pd;
/*     */   private Logger m_log;
/*     */   private Hashtable m_globalContext;
/*     */   private PhaseEvent m_providerPhaseEvent;
/*     */   private String m_providerNounName;
/*     */   
/*     */   public void init(ProviderDeploymentDescriptor paramProviderDeploymentDescriptor, SOAPServerContext paramSOAPServerContext) throws SOAPException {
/* 103 */     this.m_pd = paramProviderDeploymentDescriptor;
/* 104 */     this.m_log = paramSOAPServerContext.getLogger();
/* 105 */     this.m_globalContext = paramSOAPServerContext.getGlobalContext();
/*     */     
/* 107 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 109 */       this.m_log.log("initializing provider '" + getId() + "'", 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 114 */     this.m_providerNounName = "|Soap|" + getId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     Noun noun = Noun.create(this.m_providerNounName, "SoapProvider");
/* 121 */     this.m_providerPhaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Provider");
/*     */ 
/*     */     
/* 124 */     this.m_providerPhaseEvent.deriveMetric(511);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws SOAPException {
/* 145 */     if (this.m_log.isLoggable(1))
/*     */     {
/* 147 */       this.m_log.log("destroying provider '" + getId() + "'", 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 163 */     return this.m_pd.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(RequestContext paramRequestContext) throws SOAPException {
/* 182 */     long l = 0L;
/*     */ 
/*     */     
/*     */     try {
/* 186 */       l = this.m_providerPhaseEvent.start();
/*     */ 
/*     */       
/* 189 */       Object object = getTargetObject(paramRequestContext);
/*     */ 
/*     */       
/* 192 */       invokeMethod(paramRequestContext, object);
/*     */     }
/*     */     finally {
/*     */       
/* 196 */       this.m_providerPhaseEvent.stop(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getTargetObject(RequestContext paramRequestContext) throws SOAPException {
/*     */     Class clazz;
/* 203 */     OracleSOAPContext oracleSOAPContext = paramRequestContext.getRequestSOAPContext();
/* 204 */     HttpSession httpSession = oracleSOAPContext.getHttpSession();
/* 205 */     ServiceDeploymentDescriptor serviceDeploymentDescriptor = oracleSOAPContext.getServiceDeploymentDescriptor();
/*     */     
/* 207 */     String str1 = paramRequestContext.getServiceId();
/* 208 */     String str2 = paramRequestContext.getMethodName();
/* 209 */     int i = serviceDeploymentDescriptor.getScope();
/* 210 */     String str3 = serviceDeploymentDescriptor.getServiceClass();
/* 211 */     boolean bool = serviceDeploymentDescriptor.getIsStatic();
/* 212 */     Object object = null;
/*     */ 
/*     */     
/* 215 */     if (!serviceDeploymentDescriptor.isMethodValid(str2)) {
/*     */       
/* 217 */       if (this.m_log.isLoggable(2))
/*     */       {
/* 219 */         this.m_log.log("method name '" + str2 + "' is unknown " + "for service '" + str1 + "'", 2);
/*     */       }
/*     */ 
/*     */       
/* 223 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "invalid method '" + str2 + "' in service '" + str1 + "'");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     HttpServlet httpServlet = null;
/* 231 */     if (i == 0) {
/*     */ 
/*     */       
/* 234 */       httpServlet = oracleSOAPContext.getHttpServlet();
/*     */     }
/* 236 */     else if (i == 1) {
/*     */       
/* 238 */       HttpSession httpSession1 = httpSession;
/*     */     }
/* 240 */     else if (i == 2) {
/*     */       
/*     */       try {
/* 243 */         clazz = oracleSOAPContext.loadClass(str3);
/* 244 */       } catch (ClassNotFoundException classNotFoundException) {
/* 245 */         String str = "Unable to resolve target object at application scope: " + classNotFoundException.getMessage();
/*     */ 
/*     */         
/* 248 */         throw new SOAPException(Constants.FAULT_CODE_SERVER_BAD_TARGET_OBJECT_URI, str, classNotFoundException);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 254 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, "Service uses invalid object scope");
/*     */     } 
/*     */ 
/*     */     
/* 258 */     synchronized (clazz) {
/*     */       
/* 260 */       if (i == 1) {
/*     */ 
/*     */         
/* 263 */         object = httpSession.getValue(str1);
/*     */       }
/* 265 */       else if (i == 2) {
/* 266 */         object = this.m_globalContext.get(str1);
/*     */       } else {
/* 268 */         object = null;
/*     */       } 
/* 270 */       if (object == null) {
/*     */ 
/*     */         
/*     */         try {
/* 274 */           Class clazz1 = oracleSOAPContext.loadClass(str3);
/* 275 */           if (bool) {
/* 276 */             object = clazz1;
/*     */           } else {
/* 278 */             object = clazz1.newInstance();
/*     */           } 
/* 280 */         } catch (Exception exception) {
/*     */           
/* 282 */           throw new SOAPException(Constants.FAULT_CODE_SERVER_BAD_TARGET_OBJECT_URI, "Unable to resolve target object(" + str3 + "): " + exception.getMessage(), exception);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 292 */         if (i == 1) {
/*     */ 
/*     */           
/* 295 */           httpSession.putValue(str1, object);
/*     */         }
/* 297 */         else if (i == 2) {
/*     */           
/* 299 */           this.m_globalContext.put(str1, object);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 304 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeMethod(RequestContext paramRequestContext, Object paramObject) throws SOAPException {
/* 311 */     OracleSOAPContext oracleSOAPContext1 = paramRequestContext.getRequestSOAPContext();
/* 312 */     OracleSOAPContext oracleSOAPContext2 = paramRequestContext.getResponseSOAPContext();
/* 313 */     String str1 = paramRequestContext.getMethodName();
/* 314 */     String str2 = paramRequestContext.getServiceId();
/* 315 */     ServiceDeploymentDescriptor serviceDeploymentDescriptor = oracleSOAPContext1.getServiceDeploymentDescriptor();
/*     */     
/* 317 */     int i = serviceDeploymentDescriptor.getServiceType();
/* 318 */     SOAPMappingRegistry sOAPMappingRegistry = ServiceDeploymentDescriptor.buildSOAPMappingRegistry(serviceDeploymentDescriptor, paramRequestContext.getRequestSOAPContext().getClassLoader());
/*     */ 
/*     */ 
/*     */     
/* 322 */     if (this.m_log.isLoggable(2))
/*     */     {
/* 324 */       this.m_log.log("provider '" + getId() + "' invoking method '" + str1 + "' for service '" + str2 + "'", 2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     Call call = null;
/* 332 */     String str3 = null;
/* 333 */     Object[] arrayOfObject = null;
/* 334 */     Class[] arrayOfClass = null;
/* 335 */     Method method = null;
/*     */     
/* 337 */     if (i == 0) {
/*     */       
/* 339 */       call = Call.extractFromEnvelope(paramRequestContext.getRequestEnvelope(), sOAPMappingRegistry, (SOAPContext)oracleSOAPContext1);
/*     */ 
/*     */ 
/*     */       
/* 343 */       Vector vector = call.getParams();
/* 344 */       str3 = call.getEncodingStyleURI();
/* 345 */       if (vector != null) {
/*     */         
/* 347 */         int j = vector.size();
/* 348 */         arrayOfObject = new Object[j];
/* 349 */         arrayOfClass = new Class[j];
/* 350 */         for (byte b = 0; b < j; b++) {
/*     */           
/* 352 */           Parameter parameter = vector.elementAt(b);
/* 353 */           arrayOfObject[b] = parameter.getValue();
/* 354 */           arrayOfClass[b] = parameter.getType();
/* 355 */           if (str3 == null)
/*     */           {
/* 357 */             str3 = parameter.getEncodingStyleURI();
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 362 */       if (str3 == null)
/*     */       {
/*     */         
/* 365 */         str3 = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */       }
/*     */       
/* 368 */       paramRequestContext.setRequestEncodingStyle(str3);
/*     */ 
/*     */       
/*     */       try {
/* 372 */         method = MethodUtils.getMethod(paramObject, call.getMethodName(), arrayOfClass);
/*     */       
/*     */       }
/* 375 */       catch (NoSuchMethodException noSuchMethodException) {
/*     */         
/*     */         try
/*     */         {
/*     */ 
/*     */           
/* 381 */           int j = 0;
/* 382 */           if (vector != null) j = vector.size(); 
/* 383 */           Class[] arrayOfClass1 = new Class[j + 1];
/* 384 */           Object[] arrayOfObject1 = new Object[j + 1]; byte b;
/* 385 */           for (b = 0; b < j; b++)
/* 386 */             arrayOfClass1[b + 1] = arrayOfClass[b]; 
/* 387 */           arrayOfClass = arrayOfClass1;
/* 388 */           arrayOfClass[0] = SOAPContext.class;
/* 389 */           method = MethodUtils.getMethod(paramObject, call.getMethodName(), arrayOfClass);
/*     */           
/* 391 */           for (b = 0; b < j; b++)
/* 392 */             arrayOfObject1[b + 1] = arrayOfObject[b]; 
/* 393 */           arrayOfObject1[0] = oracleSOAPContext1;
/* 394 */           arrayOfObject = arrayOfObject1;
/*     */         }
/* 396 */         catch (NoSuchMethodException noSuchMethodException1)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 401 */           if (this.m_log.isLoggable(999))
/*     */           {
/* 403 */             this.m_log.log("Error in method '" + call.getMethodName() + "': " + noSuchMethodException.getMessage() + "\n" + ServerUtils.getStackTrace(noSuchMethodException), 999);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 409 */           throw new SOAPException(Constants.FAULT_CODE_SERVER, noSuchMethodException.getMessage(), noSuchMethodException);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 416 */       arrayOfClass = new Class[] { Envelope.class, SOAPContext.class, SOAPContext.class };
/*     */       
/* 418 */       arrayOfObject = new Object[] { paramRequestContext.getRequestEnvelope(), oracleSOAPContext1, oracleSOAPContext2 };
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 423 */         method = MethodUtils.getMethod(paramObject, str1, arrayOfClass);
/*     */       }
/* 425 */       catch (NoSuchMethodException noSuchMethodException) {
/*     */ 
/*     */         
/* 428 */         if (this.m_log.isLoggable(999))
/*     */         {
/* 430 */           this.m_log.log("Error in method '" + str1 + "': " + noSuchMethodException.getMessage() + "\n" + ServerUtils.getStackTrace(noSuchMethodException), 999);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 436 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, noSuchMethodException.getMessage(), noSuchMethodException);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 441 */     Bean bean = null;
/*     */     
/*     */     try {
/* 444 */       PhaseEvent phaseEvent = null;
/* 445 */       long l = 0L;
/*     */ 
/*     */       
/*     */       try {
/*     */         Object object;
/*     */         
/* 451 */         Noun noun = Noun.create(this.m_providerNounName + "|" + str2, "SoapService");
/*     */ 
/*     */ 
/*     */         
/* 455 */         phaseEvent = PhaseEvent.create(noun, "activePhase", "SOAP Service");
/*     */ 
/*     */         
/* 458 */         phaseEvent.deriveMetric(511);
/*     */         
/* 460 */         l = phaseEvent.start();
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 465 */           object = method.invoke(paramObject, arrayOfObject);
/* 466 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */           
/* 469 */           boolean bool = false;
/*     */           
/* 471 */           arrayOfClass = method.getParameterTypes();
/* 472 */           for (byte b = 0; b < arrayOfClass.length; b++) {
/*     */             
/* 474 */             Object[] arrayOfObject1 = EncUtils.mapArrayInbuiltToWrapper(arrayOfClass[b], arrayOfObject[b]);
/*     */             
/* 476 */             if (arrayOfObject1 != null) {
/*     */               
/* 478 */               arrayOfObject[b] = arrayOfObject1;
/* 479 */               bool = true;
/*     */             } 
/*     */           } 
/* 482 */           if (bool) {
/*     */             
/* 484 */             object = method.invoke(paramObject, arrayOfObject);
/*     */           } else {
/*     */             
/* 487 */             throw illegalArgumentException;
/*     */           } 
/* 489 */         }  if (i == 0)
/*     */         {
/* 491 */           bean = new Bean(method.getReturnType(), object);
/*     */         
/*     */         }
/*     */       }
/*     */       finally {
/*     */         
/* 497 */         phaseEvent.stop(l);
/*     */       }
/*     */     
/* 500 */     } catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 502 */       Throwable throwable = invocationTargetException.getTargetException();
/* 503 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */     
/*     */     }
/* 506 */     catch (Throwable throwable) {
/*     */       
/* 508 */       if (this.m_log.isLoggable(999))
/*     */       {
/* 510 */         this.m_log.log("Error in method '" + str1 + "': " + throwable.getMessage() + "\n" + ServerUtils.getStackTrace(throwable), 999);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 515 */       throw new SOAPException(Constants.FAULT_CODE_SERVER, throwable.getMessage(), throwable);
/*     */     } 
/*     */ 
/*     */     
/* 519 */     if (this.m_log.isLoggable(2))
/*     */     {
/* 521 */       this.m_log.log("provider '" + getId() + "' completed method '" + str1 + "' for service '" + str2 + "'", 2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 530 */     if (i == 0)
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 535 */         Parameter parameter = null;
/* 536 */         if (bean.type != void.class)
/*     */         {
/* 538 */           parameter = new Parameter(RPCConstants.ELEM_RETURN, bean.type, bean.value, null);
/*     */         }
/*     */         
/* 541 */         Response response = new Response(call.getTargetObjectURI(), call.getMethodName(), parameter, null, null, str3, (SOAPContext)oracleSOAPContext2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 549 */           Envelope envelope = response.buildEnvelope();
/* 550 */           paramRequestContext.setResponseEnvelope(envelope);
/* 551 */           paramRequestContext.setResponseMap(sOAPMappingRegistry);
/*     */         }
/* 553 */         catch (Exception exception) {
/*     */           
/* 555 */           throw new SOAPException(Constants.FAULT_CODE_SERVER, "error building response envelope: " + exception.getMessage(), exception);
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 561 */       catch (Exception exception) {
/*     */         
/* 563 */         throw new SOAPException(Constants.FAULT_CODE_SERVER, "error creating response: " + exception.getMessage(), exception);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\JavaProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */