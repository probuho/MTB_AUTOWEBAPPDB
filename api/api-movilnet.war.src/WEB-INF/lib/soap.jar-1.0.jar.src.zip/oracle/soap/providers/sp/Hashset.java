/*     */ package oracle.soap.providers.sp;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Hashset
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private Hashtable m_tbl;
/*     */   private static final long serialVersionUID = -4469017106985139442L;
/*     */   
/*     */   public Hashset() {
/* 250 */     this.m_tbl = null; this.m_tbl = new Hashtable(); } public Hashset(Hashset paramHashset) { this.m_tbl = null;
/*     */     if (paramHashset == null) {
/*     */       this.m_tbl = new Hashtable();
/*     */     } else {
/*     */       this.m_tbl = (Hashtable)paramHashset.m_tbl.clone();
/*     */     }  }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     return new Hashset(this);
/*     */   }
/*     */   
/*     */   public int size() {
/*     */     return this.m_tbl.size();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*     */     return this.m_tbl.isEmpty();
/*     */   }
/*     */   
/*     */   public Enumeration elements() {
/*     */     return this.m_tbl.elements();
/*     */   }
/*     */   
/*     */   public boolean contains(Object paramObject) {
/*     */     return this.m_tbl.contains(paramObject);
/*     */   }
/*     */   
/*     */   public void put(Object paramObject) {
/*     */     this.m_tbl.put(paramObject, paramObject);
/*     */   }
/*     */   
/*     */   public void remove(Object paramObject) {
/*     */     this.m_tbl.remove(paramObject);
/*     */   }
/*     */   
/*     */   public void clear() {
/*     */     this.m_tbl.clear();
/*     */   }
/*     */   
/*     */   public Object getAny() {
/*     */     Object object = null;
/*     */     synchronized (this.m_tbl) {
/*     */       Enumeration enumeration = this.m_tbl.keys();
/*     */       if (enumeration.hasMoreElements())
/*     */         object = this.m_tbl.get(enumeration.nextElement()); 
/*     */     } 
/*     */     return object;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\soap\providers\sp\Hashset.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */