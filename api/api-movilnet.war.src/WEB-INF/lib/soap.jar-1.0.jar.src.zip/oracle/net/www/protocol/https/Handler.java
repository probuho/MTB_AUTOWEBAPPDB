/*    */ package oracle.net.www.protocol.https;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import oracle.net.www.protocol.http.Handler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends Handler
/*    */ {
/*    */   public Handler() {}
/*    */   
/*    */   public Handler(String paramString, int paramInt) {
/* 28 */     super(paramString, paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDefaultPort() {
/* 33 */     return 443;
/*    */   }
/*    */ 
/*    */   
/*    */   protected URLConnection openConnection(URL paramURL) throws IOException {
/* 38 */     return (URLConnection)new HttpsURLConnection(paramURL, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\protocol\https\Handler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */