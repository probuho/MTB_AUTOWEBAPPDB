/*     */ package oracle.net.www.protocol.http;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderParser
/*     */ {
/*     */   private String m_header;
/*     */   private String[][] m_keyValuePairs;
/*     */   
/*     */   public HeaderParser(String paramString) {
/*  41 */     this.m_header = paramString;
/*  42 */     parse();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue(String paramString) {
/*  47 */     if (paramString == null)
/*  48 */       return null; 
/*  49 */     for (byte b = 0; b < this.m_keyValuePairs.length; b++) {
/*  50 */       if (paramString.equalsIgnoreCase(this.m_keyValuePairs[b][0]))
/*  51 */         return this.m_keyValuePairs[b][1]; 
/*     */     } 
/*  53 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue(int paramInt) {
/*  58 */     if (paramInt < 0 || paramInt > this.m_keyValuePairs.length - 1) {
/*  59 */       return null;
/*     */     }
/*  61 */     return this.m_keyValuePairs[paramInt][1];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey(int paramInt) {
/*  66 */     if (paramInt < 0 || paramInt > this.m_keyValuePairs.length - 1) {
/*  67 */       return null;
/*     */     }
/*  69 */     return this.m_keyValuePairs[paramInt][0];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCount() {
/*  74 */     return this.m_keyValuePairs.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse() {
/*  82 */     String str1 = null, str2 = null;
/*  83 */     boolean bool1 = true, bool2 = false;
/*  84 */     boolean bool3 = false, bool4 = false, bool5 = false;
/*  85 */     int i = 0;
/*     */     
/*  87 */     if (this.m_header == null) {
/*     */       return;
/*     */     }
/*  90 */     this.m_header = this.m_header.trim();
/*  91 */     char[] arrayOfChar = this.m_header.toCharArray();
/*  92 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */     
/*     */     byte b;
/*     */     
/*  97 */     for (b = 0; b < arrayOfChar.length && !bool4; b++) {
/*     */       
/*  99 */       if (bool5 && arrayOfChar[b] != '"') {
/*     */         
/* 101 */         bool4 = true;
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 110 */       switch (arrayOfChar[b]) {
/*     */ 
/*     */         
/*     */         case ',':
/* 114 */           if (bool1) {
/*     */ 
/*     */             
/* 117 */             if (i == b) {
/* 118 */               i = b + 1;
/*     */               break;
/*     */             } 
/* 121 */             bool4 = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 126 */           if (bool2) {
/*     */             
/* 128 */             if (!bool3) {
/*     */               
/* 130 */               str2 = new String(arrayOfChar, i, b - i);
/* 131 */               str2 = str2.trim();
/* 132 */               bool2 = false;
/* 133 */               bool1 = true;
/* 134 */               i = b + 1;
/*     */             } 
/*     */             
/*     */             break;
/*     */           } 
/* 139 */           bool1 = true;
/* 140 */           i = b + 1;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case ' ':
/* 147 */           if (!bool3) {
/* 148 */             i++;
/*     */           }
/*     */           break;
/*     */         
/*     */         case '=':
/* 153 */           if (bool1) {
/*     */             
/* 155 */             bool1 = false;
/* 156 */             bool2 = true;
/* 157 */             str1 = new String(arrayOfChar, i, b - i);
/* 158 */             str1.trim();
/* 159 */             i = b + 1;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 164 */           if (!bool2)
/*     */           {
/* 166 */             bool4 = true;
/*     */           }
/*     */           break;
/*     */ 
/*     */         
/*     */         case '"':
/* 172 */           if (bool1) {
/*     */             break;
/*     */           }
/*     */           
/* 176 */           if (bool2) {
/*     */             
/* 178 */             if (bool3) {
/*     */               
/* 180 */               if (!bool5) {
/*     */                 
/* 182 */                 str2 = new String(arrayOfChar, i, b - i);
/* 183 */                 i = b + 1;
/* 184 */                 bool3 = false;
/* 185 */                 bool2 = false;
/*     */                 break;
/*     */               } 
/* 188 */               bool5 = false; break;
/*     */             } 
/* 190 */             if (i != b) {
/*     */               
/* 192 */               bool4 = true;
/*     */               
/*     */               break;
/*     */             } 
/* 196 */             bool3 = true;
/* 197 */             i = b + 1;
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 203 */           bool4 = true;
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case '\\':
/* 209 */           if (bool1) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 215 */           if (bool2) {
/*     */             
/* 217 */             if (bool3) {
/* 218 */               bool5 = true;
/*     */             }
/*     */             break;
/*     */           } 
/* 222 */           bool4 = true;
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 228 */           if (!bool1 && !bool2)
/*     */           {
/*     */             
/* 231 */             bool4 = true;
/*     */           }
/*     */           break;
/*     */       } 
/* 235 */       if (str1 != null && str2 != null) {
/*     */ 
/*     */         
/* 238 */         hashtable.put(str1.toLowerCase(), removeEscapeChar(str2, '\\'));
/* 239 */         str1 = str2 = null;
/*     */       } 
/*     */     } 
/* 242 */     if (!bool4)
/*     */     {
/* 244 */       if (str1 != null && bool2 && !bool3)
/*     */       {
/* 246 */         if (i < b) {
/*     */           
/* 248 */           str2 = new String(arrayOfChar, i, b - i);
/* 249 */           if (str2 != null)
/*     */           {
/*     */             
/* 252 */             hashtable.put(str1.toLowerCase(), removeEscapeChar(str2, '\\'));
/*     */           }
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 259 */     this.m_keyValuePairs = new String[hashtable.size()][2];
/* 260 */     Enumeration enumeration = hashtable.keys();
/* 261 */     b = 0;
/* 262 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 264 */       str1 = enumeration.nextElement();
/* 265 */       this.m_keyValuePairs[b][0] = str1;
/* 266 */       this.m_keyValuePairs[b][1] = (String)hashtable.get(str1);
/* 267 */       b++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String removeEscapeChar(String paramString, char paramChar) {
/* 276 */     if (paramString == null) {
/* 277 */       return null;
/*     */     }
/* 279 */     StringBuffer stringBuffer = new StringBuffer();
/* 280 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, (new Character(paramChar)).toString());
/* 281 */     while (stringTokenizer.hasMoreTokens()) {
/* 282 */       stringBuffer.append(stringTokenizer.nextToken());
/*     */     }
/* 284 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\protocol\http\HeaderParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */