/*    */ package oracle.net.www;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Base64Encoder
/*    */ {
/* 22 */   private static final char[] KEY = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final int SIZE_OF_LINE = 57;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String encode(byte[] paramArrayOfbyte) {
/* 38 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/* 39 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*    */     try {
/* 41 */       encode(byteArrayInputStream, byteArrayOutputStream);
/* 42 */     } catch (IOException iOException) {
/* 43 */       throw new RuntimeException("Internal error.\n" + iOException.toString());
/*    */     } 
/* 45 */     return byteArrayOutputStream.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(byte[] paramArrayOfbyte, OutputStream paramOutputStream) throws IOException {
/* 50 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/* 51 */     encode(byteArrayInputStream, paramOutputStream);
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
/* 56 */     int[] arrayOfInt = new int[3];
/* 57 */     byte b1 = 0, b2 = 0;
/* 58 */     for (arrayOfInt[b1] = paramInputStream.read(); paramInputStream.read() != -1; ) {
/*    */       
/* 60 */       b2++;
/* 61 */       b1++;
/* 62 */       if (b1 == 3) {
/*    */         
/* 64 */         paramOutputStream.write(KEY[(arrayOfInt[0] & 0xFC) >>> 2]);
/* 65 */         paramOutputStream.write(KEY[(arrayOfInt[0] & 0x3) << 4 | (arrayOfInt[1] & 0xF0) >>> 4]);
/* 66 */         paramOutputStream.write(KEY[(arrayOfInt[1] & 0xF) << 2 | (arrayOfInt[2] & 0xC0) >>> 6]);
/* 67 */         paramOutputStream.write(KEY[arrayOfInt[2] & 0x3F]);
/* 68 */         b1 = 0;
/* 69 */         if (b2 == 57) {
/*    */           
/* 71 */           paramOutputStream.write(10);
/* 72 */           b2 = 0;
/*    */         } 
/* 74 */         paramOutputStream.flush();
/*    */       } 
/*    */     } 
/*    */     
/* 78 */     if (b1 == 1) {
/*    */       
/* 80 */       paramOutputStream.write(KEY[(arrayOfInt[0] & 0xFC) >>> 2]);
/* 81 */       paramOutputStream.write(KEY[(arrayOfInt[0] & 0x3) << 4]);
/* 82 */       paramOutputStream.write(61);
/* 83 */       paramOutputStream.write(61);
/*    */     }
/* 85 */     else if (b1 == 2) {
/*    */       
/* 87 */       paramOutputStream.write(KEY[(arrayOfInt[0] & 0xFC) >>> 2]);
/* 88 */       paramOutputStream.write(KEY[(arrayOfInt[0] & 0x3) << 4 | (arrayOfInt[1] & 0xF0) >>> 4]);
/* 89 */       paramOutputStream.write(KEY[(arrayOfInt[1] & 0xF) << 2]);
/* 90 */       paramOutputStream.write(61);
/*    */     } 
/* 92 */     paramOutputStream.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\Base64Encoder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */