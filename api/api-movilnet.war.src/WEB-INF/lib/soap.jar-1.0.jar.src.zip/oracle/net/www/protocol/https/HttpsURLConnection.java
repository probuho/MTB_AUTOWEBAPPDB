/*     */ package oracle.net.www.protocol.https;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import oracle.net.www.protocol.http.HttpURLConnection;
/*     */ import oracle.security.ssl.OracleSSLCredential;
/*     */ import oracle.security.ssl.OracleSSLSocketFactory;
/*     */ import oracle.security.ssl.OracleSSLSocketFactoryImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpsURLConnection
/*     */   extends HttpURLConnection
/*     */ {
/*     */   public static final String WALLET_LOCATION = "oracle.wallet.location";
/*     */   public static final String WALLET_PASSWORD = "oracle.wallet.password";
/*     */   public static final String CIPHERS = "oracle.ssl.ciphers";
/*     */   private OracleSSLSocketFactory m_sslSocketFactory;
/*     */   private String m_wltLoc;
/*     */   private String m_wltPassword;
/*     */   private String[] m_ciphers;
/*     */   
/*     */   public HttpsURLConnection(URL paramURL) throws IOException {
/*  57 */     this(paramURL, new Handler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpsURLConnection(URL paramURL, Handler paramHandler) throws IOException {
/*  66 */     super(paramURL, paramHandler);
/*  67 */     this.m_sslSocketFactory = (OracleSSLSocketFactory)new OracleSSLSocketFactoryImpl();
/*  68 */     this.m_wltLoc = System.getProperty("oracle.wallet.location");
/*  69 */     this.m_wltPassword = System.getProperty("oracle.wallet.password");
/*  70 */     this.m_ciphers = parseCiphers(System.getProperty("oracle.ssl.ciphers"));
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized String[] getCipherSuites() {
/*  75 */     return this.m_ciphers;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setCipherSuites(String paramString) {
/*  80 */     setCipherSuites(parseCiphers(paramString));
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setCipherSuites(String[] paramArrayOfString) {
/*  85 */     this.m_ciphers = paramArrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] parseCiphers(String paramString) {
/*  92 */     if (paramString == null || paramString.equals("")) {
/*  93 */       return null;
/*     */     }
/*  95 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ":");
/*  96 */     String[] arrayOfString = new String[stringTokenizer.countTokens()];
/*  97 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  98 */       arrayOfString[b] = stringTokenizer.nextToken();
/*     */     }
/* 100 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void validateCipherSuites() throws IllegalArgumentException, ProtocolException {
/* 109 */     if (this.connected) {
/* 110 */       throw new ProtocolException("Cannot set cipher suites: already connected");
/*     */     }
/*     */     
/* 113 */     String[] arrayOfString = this.m_sslSocketFactory.getSupportedCipherSuites();
/* 114 */     for (byte b = 0; b < this.m_ciphers.length; b++) {
/*     */       byte b1;
/* 116 */       for (b1 = 0; b1 < arrayOfString.length; b1++) {
/*     */         
/* 118 */         if (this.m_ciphers[b].equals(arrayOfString[b1]))
/*     */           break; 
/*     */       } 
/* 121 */       if (b1 >= arrayOfString.length) {
/* 122 */         throw new IllegalArgumentException("Cipher suite: \"" + this.m_ciphers[b] + "\" is not supported");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setWallet(String paramString1, String paramString2) throws IOException {
/* 134 */     if (this.connected) {
/* 135 */       throw new ProtocolException("Cannot set wallet: already connected");
/*     */     }
/* 137 */     this.m_wltLoc = paramString1;
/* 138 */     this.m_wltPassword = paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void setCredentials() throws IOException {
/* 148 */     OracleSSLCredential oracleSSLCredential = new OracleSSLCredential();
/* 149 */     if (this.m_wltLoc != null) {
/*     */       
/* 151 */       ckWltLoc(this.m_wltLoc);
/* 152 */       if (!setTrustPoints(oracleSSLCredential, this.m_wltLoc) && this.m_wltPassword != null)
/*     */       {
/* 154 */         oracleSSLCredential.setWallet(this.m_wltLoc, this.m_wltPassword);
/*     */       }
/*     */     } 
/*     */     
/* 158 */     this.m_sslSocketFactory.setSSLCredentials(oracleSSLCredential);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SSLSession getSSLSession() throws ProtocolException {
/* 165 */     if (!this.connected)
/* 166 */       throw new ProtocolException("Cannot get session : not connected"); 
/* 167 */     if (this.m_socket != null)
/*     */     {
/* 169 */       return ((SSLSocket)this.m_socket).getSession();
/*     */     }
/*     */     
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void connect() throws IOException {
/* 179 */     String str2 = null;
/* 180 */     int j = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     if (this.connected) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 191 */     String str1 = getURL().getHost();
/* 192 */     if (str1 == null)
/* 193 */       str1 = "localhost"; 
/* 194 */     int i = getURL().getPort();
/* 195 */     if (i <= 0) {
/* 196 */       i = this.m_handler.getDefaultPort();
/*     */     }
/* 198 */     str2 = this.m_handler.getProxyHost();
/* 199 */     j = this.m_handler.getProxyPort();
/* 200 */     if (usingProxy()) {
/*     */ 
/*     */       
/* 203 */       if (j <= 0)
/* 204 */         j = 80; 
/* 205 */       Socket socket = new Socket(str2, j);
/* 206 */       socket.setSoTimeout(getTimeout());
/*     */       try {
/* 208 */         makeProxyConnection(socket, str1, i, false);
/* 209 */         if (this.responseCode == 407) {
/*     */ 
/*     */           
/* 212 */           socket.close();
/* 213 */           socket = new Socket(str2, j);
/* 214 */           socket.setSoTimeout(getTimeout());
/* 215 */           makeProxyConnection(socket, str1, i, true);
/*     */         } 
/*     */         
/* 218 */         if (this.responseCode < 200 || this.responseCode > 299) {
/* 219 */           throw new IOException("Connection to Proxy failed. Response:\n" + getHeaderField(0));
/*     */         }
/*     */         
/* 222 */         this.m_socket = this.m_sslSocketFactory.createSocket(socket);
/* 223 */       } catch (IOException iOException) {
/* 224 */         if (socket != null) {
/*     */           try {
/* 226 */             socket.close();
/* 227 */           } catch (IOException iOException1) {}
/*     */         }
/*     */         
/* 230 */         throw iOException;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 236 */       this.m_socket = this.m_sslSocketFactory.createSocket(str1, i);
/* 237 */       this.m_socket.setSoTimeout(getTimeout());
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 242 */       setupSSL((SSLSocket)this.m_socket);
/* 243 */     } catch (IOException iOException) {
/* 244 */       if (this.m_socket != null) {
/*     */         
/*     */         try {
/* 247 */           this.m_socket.close();
/* 248 */         } catch (Exception exception) {}
/*     */ 
/*     */         
/* 251 */         this.m_socket = null;
/* 252 */         this.m_inputStream = null;
/* 253 */         this.m_outputStream = null;
/*     */       } 
/* 255 */       throw iOException;
/*     */     } 
/*     */     
/* 258 */     this.connected = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void makeProxyConnection(Socket paramSocket, String paramString, int paramInt, boolean paramBoolean) throws IOException {
/* 271 */     StringBuffer stringBuffer = new StringBuffer();
/* 272 */     stringBuffer.append("CONNECT ").append(paramString).append(":").append(paramInt);
/* 273 */     stringBuffer.append(" HTTP/1.0\r\nUser-Agent: Oracle-SOAP-Client\r\n");
/* 274 */     if (paramBoolean) {
/*     */       
/* 276 */       String str = getCredHeader("Proxy-Authenticate", true);
/* 277 */       if (str == null) {
/* 278 */         throw new IOException("Username and/or password for proxy authentication not set. Cannot authenticate");
/*     */       }
/*     */       
/* 281 */       this.m_proxyAuthAttempted = true;
/* 282 */       stringBuffer.append(str);
/*     */     } else {
/*     */       
/* 285 */       setRequestBasicAuthHeader(stringBuffer, true);
/*     */     } 
/* 287 */     if (paramSocket == null) {
/* 288 */       throw new IOException("Problem creating connection to the proxy");
/*     */     }
/* 290 */     InputStream inputStream = paramSocket.getInputStream();
/* 291 */     OutputStream outputStream = paramSocket.getOutputStream();
/*     */     
/* 293 */     if (inputStream == null) {
/* 294 */       throw new IOException("Problem creating connection to the proxy.  Could not get the input stream.");
/*     */     }
/* 296 */     if (outputStream == null) {
/* 297 */       throw new IOException("Problem creating connection to the proxy.  Could not get the output stream.");
/*     */     }
/*     */     
/*     */     try {
/* 301 */       outputStream.write((stringBuffer + "\r\n").getBytes(), 0, stringBuffer.length() + 2);
/* 302 */       outputStream.flush();
/*     */       
/* 304 */       parseHeaders(inputStream);
/* 305 */       if (this.responseCode == -1) {
/* 306 */         throw new IOException("Unrecognized response from proxy server. Response:\n" + getHeaderField(0));
/*     */       }
/*     */ 
/*     */       
/* 310 */       int i = getHeaderFieldInt("Content-Length", 0);
/* 311 */       if (i > 0)
/*     */       {
/* 313 */         byte[] arrayOfByte = new byte[i];
/* 314 */         inputStream.read(arrayOfByte);
/*     */       }
/*     */     
/*     */     }
/* 318 */     catch (IOException iOException) {
/*     */       try {
/* 320 */         inputStream.close();
/* 321 */       } catch (IOException iOException1) {}
/*     */ 
/*     */       
/*     */       try {
/* 325 */         outputStream.close();
/* 326 */       } catch (IOException iOException1) {}
/*     */ 
/*     */       
/* 329 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupSSL(SSLSocket paramSSLSocket) throws IOException {
/* 336 */     setCredentials();
/*     */     
/* 338 */     paramSSLSocket.setUseClientMode(true);
/*     */     
/* 340 */     if (this.m_ciphers == null) {
/* 341 */       paramSSLSocket.setEnabledCipherSuites(((OracleSSLSocketFactoryImpl)this.m_sslSocketFactory).getSupportedCipherSuites());
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 346 */       validateCipherSuites();
/* 347 */       paramSSLSocket.setEnabledCipherSuites(this.m_ciphers);
/*     */     } 
/*     */     
/* 350 */     paramSSLSocket.startHandshake();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void ckWltLoc(String paramString) throws IOException {
/* 362 */     File file = new File(paramString);
/*     */     
/* 364 */     if (!file.exists()) {
/* 365 */       throw new IOException("The wallet \"" + paramString + "\" does not exist.");
/*     */     }
/* 367 */     if (!file.canRead()) {
/* 368 */       throw new IOException("The wallet \"" + paramString + "\" cannot be read.");
/*     */     }
/* 370 */     if (!file.isFile()) {
/* 371 */       throw new IOException("The wallet \"" + paramString + "\" is not a 'normal' file.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean setTrustPoints(OracleSSLCredential paramOracleSSLCredential, String paramString) throws IOException {
/* 382 */     String str = "wallet is corrupt.";
/* 383 */     BufferedReader bufferedReader = null;
/* 384 */     boolean bool = false;
/*     */     
/* 386 */     StringBuffer stringBuffer = null;
/*     */     try {
/* 388 */       bufferedReader = new BufferedReader(new FileReader(paramString)); String str1;
/* 389 */       while ((str1 = bufferedReader.readLine()) != null) {
/*     */         
/* 391 */         if (str1.startsWith("-----BEGIN CERTIFICATE-----")) {
/*     */           
/* 393 */           if (bool)
/* 394 */             throw new IOException(str); 
/* 395 */           bool = true;
/* 396 */           stringBuffer = new StringBuffer(); continue;
/*     */         } 
/* 398 */         if (str1.startsWith("-----END CERTIFICATE-----")) {
/*     */           
/* 400 */           if (!bool)
/* 401 */             throw new IOException(str); 
/* 402 */           bool = false;
/* 403 */           paramOracleSSLCredential.addTrustedCert(stringBuffer.toString()); continue;
/*     */         } 
/* 405 */         if (str1.startsWith("-----BEGIN ENCRYPTED PRIVATE KEY-----"))
/* 406 */           return false; 
/* 407 */         if (str1.startsWith("#") || str1.equals(""))
/*     */           continue; 
/* 409 */         if (bool) {
/*     */           
/* 411 */           stringBuffer.append(str1);
/* 412 */           stringBuffer.append("\n");
/*     */           continue;
/*     */         } 
/* 415 */         throw new IOException(str);
/*     */       } 
/* 417 */       if (bool)
/* 418 */         throw new IOException(str); 
/* 419 */       return true;
/*     */     } finally {
/* 421 */       if (bufferedReader != null) {
/* 422 */         bufferedReader.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getRequestURI(URL paramURL) {
/* 432 */     return paramURL.getFile();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\protocol\https\HttpsURLConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */