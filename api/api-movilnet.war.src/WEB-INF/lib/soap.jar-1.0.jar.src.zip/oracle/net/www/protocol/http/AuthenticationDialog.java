/*    */ package oracle.net.www.protocol.http;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Button;
/*    */ import java.awt.Dialog;
/*    */ import java.awt.FlowLayout;
/*    */ import java.awt.Frame;
/*    */ import java.awt.GridLayout;
/*    */ import java.awt.Label;
/*    */ import java.awt.Panel;
/*    */ import java.awt.TextField;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationDialog
/*    */   extends Dialog
/*    */   implements ActionListener
/*    */ {
/*    */   private TextField m_username;
/*    */   private TextField m_password;
/*    */   private boolean m_action;
/*    */   
/*    */   public AuthenticationDialog(String paramString1, String paramString2, String paramString3) {
/* 26 */     super(new Frame(), paramString1, true);
/* 27 */     this.m_username = new TextField(20);
/* 28 */     this.m_password = new TextField(20);
/* 29 */     this.m_password.setEchoChar('*');
/* 30 */     Panel panel1 = new Panel();
/* 31 */     Panel panel2 = new Panel();
/*    */     
/* 33 */     panel2.setLayout(new FlowLayout());
/* 34 */     Button button1 = new Button("OK");
/* 35 */     button1.addActionListener(this);
/* 36 */     Button button2 = new Button("Cancel");
/* 37 */     button2.addActionListener(this);
/* 38 */     panel2.add(button1);
/* 39 */     panel2.add(button2);
/*    */     
/* 41 */     panel1.setLayout(new GridLayout(2, 2));
/* 42 */     panel1.add(new Label(paramString2));
/* 43 */     panel1.add(this.m_username);
/* 44 */     panel1.add(new Label(paramString3));
/* 45 */     panel1.add(this.m_password);
/*    */     
/* 47 */     setLayout(new BorderLayout());
/* 48 */     add(panel1, "North");
/* 49 */     add(panel2, "South");
/*    */     
/* 51 */     setSize(350, 150);
/* 52 */     pack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void display() {
/* 57 */     setVisible(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 62 */     if (this.m_action) {
/* 63 */       return this.m_username.getText();
/*    */     }
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPassword() {
/* 70 */     if (this.m_action) {
/* 71 */       return this.m_password.getText();
/*    */     }
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 78 */     String str = paramActionEvent.getActionCommand();
/* 79 */     if (str.equals("OK")) {
/* 80 */       this.m_action = true;
/*    */     } else {
/* 82 */       this.m_action = false;
/* 83 */     }  setVisible(false);
/* 84 */     dispose();
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/* 89 */     String[] arrayOfString = new String[2];
/* 90 */     boolean[] arrayOfBoolean = new boolean[2];
/* 91 */     arrayOfString[0] = "Username: ";
/* 92 */     arrayOfString[1] = "Password: ";
/* 93 */     arrayOfBoolean[0] = false;
/* 94 */     arrayOfBoolean[1] = true;
/* 95 */     AuthenticationDialog authenticationDialog = new AuthenticationDialog("HTTP authentication", "username:", "password:");
/*    */     
/* 97 */     authenticationDialog.display();
/* 98 */     System.out.println(authenticationDialog.getUsername());
/* 99 */     System.out.println(authenticationDialog.getPassword());
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\protocol\http\AuthenticationDialog.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */