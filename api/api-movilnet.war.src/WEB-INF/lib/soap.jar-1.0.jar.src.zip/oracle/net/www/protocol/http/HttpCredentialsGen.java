/*     */ package oracle.net.www.protocol.http;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import oracle.net.www.Base64Encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpCredentialsGen
/*     */ {
/*     */   private String m_username;
/*     */   private String m_password;
/*  32 */   private Base64Encoder m_encoder = new Base64Encoder(); public HttpCredentialsGen() {
/*     */     try {
/*  34 */       this.m_md5 = MessageDigest.getInstance("MD5");
/*  35 */     } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/*     */       
/*  37 */       throw new Error("Problem getting an instance of MD5 algorithm.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private MessageDigest m_md5;
/*     */   
/*     */   public HttpCredentialsGen(String paramString1, String paramString2) throws IllegalArgumentException {
/*  44 */     this();
/*  45 */     this.m_username = paramString1;
/*  46 */     this.m_password = paramString2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/*  51 */     return this.m_username;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPassword() {
/*  56 */     return this.m_password;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUsername(String paramString) {
/*  61 */     this.m_username = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPassword(String paramString) {
/*  66 */     this.m_password = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBasicCredentials() {
/*  74 */     return getBasicCredentials(this.m_username, this.m_password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBasicCredentials(String paramString1, String paramString2) {
/*  82 */     if (paramString1 == null || paramString2 == null) {
/*  83 */       return null;
/*     */     }
/*     */     try {
/*  86 */       return this.m_encoder.encode((paramString1 + ":" + paramString2).getBytes("ISO-8859-1"));
/*  87 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  88 */       throw new RuntimeException("ISO-8859-1 encoding not supported");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDigestCredentials(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9) {
/* 100 */     return getDigestCredentials(this.m_username, this.m_password, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramString8, paramString9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDigestCredentials(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11) {
/* 112 */     String str1 = null, str2 = null, str3 = null;
/*     */     
/* 114 */     if (paramString1 == null || paramString2 == null || paramString3 == null || paramString6 == null || paramString4 == null || paramString5 == null)
/*     */     {
/* 116 */       return null;
/*     */     }
/* 118 */     if (paramString10 == null) {
/* 119 */       paramString10 = "MD5";
/*     */     }
/*     */     
/* 122 */     if (paramString10.equalsIgnoreCase("MD5")) {
/*     */       
/* 124 */       str1 = A1(paramString1, paramString2, paramString3);
/*     */     }
/* 126 */     else if (paramString10.equalsIgnoreCase("MD5-sess")) {
/*     */       
/* 128 */       if (paramString6 == null || paramString8 == null) {
/* 129 */         return null;
/*     */       }
/* 131 */       str1 = A1(paramString1, paramString2, paramString3, paramString6, paramString8);
/*     */     } else {
/*     */       
/* 134 */       return null;
/*     */     } 
/*     */     
/* 137 */     if (paramString9 == null) {
/*     */       
/* 139 */       str2 = A2(paramString5, paramString4);
/*     */ 
/*     */     
/*     */     }
/* 143 */     else if (paramString9.equalsIgnoreCase("auth")) {
/*     */       
/* 145 */       if (paramString7 == null || paramString8 == null)
/* 146 */         return null; 
/* 147 */       str2 = A2(paramString5, paramString4);
/*     */     }
/* 149 */     else if (paramString9.equalsIgnoreCase("auth-int")) {
/*     */       
/* 151 */       if (paramString7 == null || paramString8 == null || paramString11 == null)
/* 152 */         return null; 
/* 153 */       str2 = A2(paramString5, paramString4, paramString11);
/*     */     }
/*     */     else {
/*     */       
/* 157 */       str2 = A2(paramString5, paramString4);
/* 158 */       paramString9 = null;
/*     */     } 
/*     */ 
/*     */     
/* 162 */     if (paramString9 != null) {
/*     */       
/* 164 */       str3 = KD(H(str1), paramString6 + ":" + paramString7 + ":" + paramString8 + ":" + paramString9 + ":" + H(str2));
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 170 */       str3 = KD(H(str1), paramString6 + ":" + H(str2));
/*     */     } 
/* 172 */     return str3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String H(String paramString) {
/* 178 */     return toHexString(digest(paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String KD(String paramString1, String paramString2) {
/* 184 */     return H(paramString1 + ":" + paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized byte[] digest(String paramString) {
/* 191 */     this.m_md5.reset();
/*     */     try {
/* 193 */       this.m_md5.update(paramString.getBytes("ISO-8859-1"));
/* 194 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 195 */       throw new RuntimeException("ISO-8859-1 encoding not supported");
/*     */     } 
/* 197 */     return this.m_md5.digest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toHexString(byte[] paramArrayOfbyte) {
/* 207 */     StringBuffer stringBuffer = new StringBuffer();
/* 208 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/*     */ 
/*     */       
/* 211 */       char c = (char)(paramArrayOfbyte[b] >> 4 & 0xF);
/* 212 */       if (c <= '\t') {
/* 213 */         c = (char)(c + 48);
/*     */       } else {
/* 215 */         c = (char)(c - 10 + 97);
/* 216 */       }  stringBuffer.append(c);
/*     */ 
/*     */       
/* 219 */       c = (char)(paramArrayOfbyte[b] & 0xF);
/* 220 */       if (c <= '\t') {
/* 221 */         c = (char)(c + 48);
/*     */       } else {
/* 223 */         c = (char)(c - 10 + 97);
/* 224 */       }  stringBuffer.append(c);
/*     */     } 
/* 226 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String A1(String paramString1, String paramString2, String paramString3) {
/* 233 */     return paramString1 + ":" + paramString3 + ":" + paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String A1(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
/* 241 */     return H(A1(paramString1, paramString3, paramString2)) + ":" + paramString4 + ":" + paramString5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String A2(String paramString1, String paramString2) {
/* 248 */     return paramString1 + ":" + paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String A2(String paramString1, String paramString2, String paramString3) {
/* 255 */     return A2(paramString1, paramString2) + ":" + H(paramString3);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\protocol\http\HttpCredentialsGen.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */