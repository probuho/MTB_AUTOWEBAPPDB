/*      */ package oracle.net.www.protocol.http;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.HttpURLConnection;
/*      */ import java.net.ProtocolException;
/*      */ import java.net.Socket;
/*      */ import java.net.URL;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpURLConnection
/*      */   extends HttpURLConnection
/*      */ {
/*      */   public static final String USERNAME = "http.username";
/*      */   public static final String PASSWORD = "http.password";
/*      */   public static final String AUTH_TYPE = "http.authType";
/*      */   public static final String PROXY_USERNAME = "http.proxyUsername";
/*      */   public static final String PROXY_PASSWORD = "http.proxyPassword";
/*      */   public static final String PROXY_AUTH_TYPE = "http.proxyAuthType";
/*      */   private static HttpCredentialsGen s_defaultProxyCred;
/*      */   private static HttpCredentialsGen s_defaultHttpCred;
/*      */   private static String s_defaultHttpAuthType;
/*      */   private static String s_defaultProxyAuthType;
/*   51 */   private static int s_maxRedirects = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   56 */   private static Properties s_defaultRequestProperties = new Properties(); static {
/*   57 */     s_defaultRequestProperties.put("user-agent", "Oracle-Soap-Client/1.0 HTTP/1.0");
/*      */     
/*   59 */     s_defaultProxyCred = new HttpCredentialsGen();
/*   60 */     s_defaultHttpCred = new HttpCredentialsGen();
/*      */   }
/*      */ 
/*      */   
/*      */   protected Handler m_handler;
/*      */   
/*      */   protected Socket m_socket;
/*      */   
/*      */   protected InputStream m_inputStream;
/*      */   protected OutputStream m_outputStream;
/*      */   private String[] m_headerKeys;
/*      */   private String[] m_headerValues;
/*      */   private Properties m_requestProperties;
/*      */   private HttpCredentialsGen m_proxyCred;
/*      */   private HttpCredentialsGen m_httpCred;
/*      */   private String m_httpAuthType;
/*      */   private String m_proxyAuthType;
/*      */   protected boolean m_proxyAuthAttempted;
/*      */   protected boolean m_httpAuthAttempted;
/*      */   private ByteArrayOutputStream m_buffer;
/*      */   private int m_timeout;
/*      */   private URL m_url;
/*      */   
/*      */   public HttpURLConnection(URL paramURL) throws IOException {
/*   84 */     this(paramURL, new Handler());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpURLConnection(URL paramURL, Handler paramHandler) throws IOException {
/*   93 */     super(paramURL);
/*   94 */     this.m_handler = paramHandler;
/*   95 */     this.m_requestProperties = new Properties(s_defaultRequestProperties);
/*   96 */     this.m_proxyCred = new HttpCredentialsGen();
/*   97 */     this.m_httpCred = new HttpCredentialsGen();
/*   98 */     this.m_url = paramURL;
/*      */ 
/*      */     
/*  101 */     this.m_socket.setTcpNoDelay(true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeout(int paramInt) {
/*  107 */     if (paramInt >= 0) {
/*  108 */       this.m_timeout = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getTimeout() {
/*  113 */     return this.m_timeout;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setDefaultProxyAuthType(String paramString) {
/*  118 */     s_defaultProxyAuthType = paramString;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getDefaultProxyAuthType() {
/*  123 */     return s_defaultProxyAuthType;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setDefaultProxyUsername(String paramString) {
/*  128 */     s_defaultProxyCred.setUsername(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getDefaultProxyUsername() {
/*  133 */     return s_defaultProxyCred.getUsername();
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setDefaultProxyPassword(String paramString) {
/*  138 */     s_defaultProxyCred.setPassword(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getDefaultProxyPassword() {
/*  143 */     return s_defaultProxyCred.getPassword();
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setDefaultHttpAuthType(String paramString) {
/*  148 */     s_defaultHttpAuthType = paramString;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getDefaultHttpAuthType() {
/*  153 */     return s_defaultHttpAuthType;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setDefaultHttpUsername(String paramString) {
/*  158 */     s_defaultHttpCred.setUsername(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getDefaultHttpUsername() {
/*  163 */     return s_defaultHttpCred.getUsername();
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setDefaultHttpPassword(String paramString) {
/*  168 */     s_defaultHttpCred.setPassword(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getDefaultHttpPassword() {
/*  173 */     return s_defaultHttpCred.getPassword();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProxyAuthType(String paramString) {
/*  178 */     this.m_proxyAuthType = paramString;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getProxyAuthType() {
/*  183 */     return this.m_proxyAuthType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProxyUsername(String paramString) {
/*  188 */     this.m_proxyCred.setUsername(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getProxyUsername() {
/*  193 */     return this.m_proxyCred.getUsername();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProxyPassword(String paramString) {
/*  198 */     this.m_proxyCred.setPassword(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getProxyPassword() {
/*  203 */     return this.m_proxyCred.getPassword();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHttpAuthType(String paramString) {
/*  208 */     this.m_httpAuthType = paramString;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getHttpAuthType() {
/*  213 */     return this.m_httpAuthType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHttpUsername(String paramString) {
/*  218 */     this.m_httpCred.setUsername(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getHttpUsername() {
/*  223 */     return this.m_httpCred.getUsername();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHttpPassword(String paramString) {
/*  228 */     this.m_httpCred.setPassword(paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getHttpPassword() {
/*  233 */     return this.m_httpCred.getPassword();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean usingProxy() {
/*  238 */     if (this.m_handler.getProxyHost() == null) {
/*  239 */       return false;
/*      */     }
/*  241 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeaderFieldKey(int paramInt) {
/*  256 */     if (this.m_headerKeys == null || paramInt >= this.m_headerKeys.length) {
/*  257 */       return null;
/*      */     }
/*  259 */     return this.m_headerKeys[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeaderField(int paramInt) {
/*  274 */     if (this.m_headerValues == null || paramInt >= this.m_headerValues.length) {
/*  275 */       return null;
/*      */     }
/*  277 */     return this.m_headerValues[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeaderField(String paramString) {
/*  283 */     if (paramString == null) {
/*  284 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  295 */     if (this.m_headerKeys != null && this.m_headerValues != null)
/*  296 */       for (byte b = 0; b < this.m_headerKeys.length; b++) {
/*      */         
/*  298 */         if (this.m_headerKeys[b].equalsIgnoreCase(paramString))
/*  299 */           return this.m_headerValues[b]; 
/*      */       }  
/*  301 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getHeaderFieldInt(int paramInt1, int paramInt2) {
/*      */     try {
/*  307 */       return Integer.parseInt(getHeaderField(paramInt1));
/*  308 */     } catch (NumberFormatException numberFormatException) {
/*      */       
/*  310 */       return paramInt2;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getHeaderFieldInt(String paramString, int paramInt) {
/*      */     try {
/*  316 */       return Integer.parseInt(getHeaderField(paramString));
/*  317 */     } catch (NumberFormatException numberFormatException) {
/*      */       
/*  319 */       return paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestProperty(String paramString1, String paramString2) {
/*  345 */     if (paramString1 == null || paramString2 == null) {
/*      */       return;
/*      */     }
/*  348 */     this.m_requestProperties.put(paramString1.toLowerCase().trim(), paramString2);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getRequestProperty(String paramString) {
/*  353 */     if (paramString == null) {
/*  354 */       return null;
/*      */     }
/*  356 */     return this.m_requestProperties.getProperty(paramString.toLowerCase().trim());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void connect() throws IOException {
/*  362 */     String str2 = null;
/*  363 */     int j = -1;
/*      */ 
/*      */     
/*  366 */     if (this.connected) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  372 */     String str1 = getURL().getHost();
/*  373 */     if (str1 == null)
/*  374 */       str1 = "localhost"; 
/*  375 */     int i = getURL().getPort();
/*  376 */     if (i <= 0) {
/*  377 */       i = this.m_handler.getDefaultPort();
/*      */     }
/*  379 */     str2 = this.m_handler.getProxyHost();
/*  380 */     j = this.m_handler.getProxyPort();
/*  381 */     if (usingProxy()) {
/*      */ 
/*      */       
/*  384 */       if (j <= 0)
/*  385 */         j = 80; 
/*  386 */       this.m_socket = new Socket(str2, j);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  391 */       this.m_socket = new Socket(str1, i);
/*      */     } 
/*      */     
/*  394 */     this.m_socket.setSoTimeout(getTimeout());
/*  395 */     this.connected = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized InputStream getInputStream() throws IOException {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #4
/*      */     //   3: aload_0
/*      */     //   4: invokevirtual getDoInput : ()Z
/*      */     //   7: ifne -> 20
/*      */     //   10: new java/net/ProtocolException
/*      */     //   13: dup
/*      */     //   14: ldc 'Cannot get input if doInput is false'
/*      */     //   16: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   19: athrow
/*      */     //   20: aload_0
/*      */     //   21: getfield m_inputStream : Ljava/io/InputStream;
/*      */     //   24: ifnull -> 32
/*      */     //   27: aload_0
/*      */     //   28: getfield m_inputStream : Ljava/io/InputStream;
/*      */     //   31: areturn
/*      */     //   32: aload_0
/*      */     //   33: invokevirtual connect : ()V
/*      */     //   36: new java/lang/StringBuffer
/*      */     //   39: dup
/*      */     //   40: invokespecial <init> : ()V
/*      */     //   43: astore_2
/*      */     //   44: aload_0
/*      */     //   45: aload_2
/*      */     //   46: iconst_0
/*      */     //   47: invokevirtual setRequestBasicAuthHeader : (Ljava/lang/StringBuffer;Z)V
/*      */     //   50: ldc 'http'
/*      */     //   52: aload_0
/*      */     //   53: invokevirtual getURL : ()Ljava/net/URL;
/*      */     //   56: invokevirtual getProtocol : ()Ljava/lang/String;
/*      */     //   59: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*      */     //   62: ifeq -> 71
/*      */     //   65: aload_0
/*      */     //   66: aload_2
/*      */     //   67: iconst_1
/*      */     //   68: invokevirtual setRequestBasicAuthHeader : (Ljava/lang/StringBuffer;Z)V
/*      */     //   71: aload_0
/*      */     //   72: getfield m_requestProperties : Ljava/util/Properties;
/*      */     //   75: invokevirtual propertyNames : ()Ljava/util/Enumeration;
/*      */     //   78: astore_1
/*      */     //   79: aload_1
/*      */     //   80: invokeinterface hasMoreElements : ()Z
/*      */     //   85: ifeq -> 125
/*      */     //   88: aload_1
/*      */     //   89: invokeinterface nextElement : ()Ljava/lang/Object;
/*      */     //   94: checkcast java/lang/String
/*      */     //   97: astore_3
/*      */     //   98: aload_2
/*      */     //   99: aload_3
/*      */     //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   103: ldc ': '
/*      */     //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   108: aload_0
/*      */     //   109: aload_3
/*      */     //   110: invokevirtual getRequestProperty : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   116: ldc '\\r\\n'
/*      */     //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   121: pop
/*      */     //   122: goto -> 79
/*      */     //   125: aload_0
/*      */     //   126: getfield m_buffer : Ljava/io/ByteArrayOutputStream;
/*      */     //   129: ifnull -> 189
/*      */     //   132: aload_0
/*      */     //   133: getfield m_buffer : Ljava/io/ByteArrayOutputStream;
/*      */     //   136: invokevirtual size : ()I
/*      */     //   139: ifeq -> 173
/*      */     //   142: aload_0
/*      */     //   143: ldc 'content-length'
/*      */     //   145: invokevirtual getRequestProperty : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   148: ifnonnull -> 173
/*      */     //   151: aload_2
/*      */     //   152: ldc 'Content-Length: '
/*      */     //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   157: aload_0
/*      */     //   158: getfield m_buffer : Ljava/io/ByteArrayOutputStream;
/*      */     //   161: invokevirtual size : ()I
/*      */     //   164: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   167: ldc '\\r\\n'
/*      */     //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   172: pop
/*      */     //   173: aload_0
/*      */     //   174: ldc 'content-type'
/*      */     //   176: invokevirtual getRequestProperty : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   179: ifnonnull -> 189
/*      */     //   182: aload_2
/*      */     //   183: ldc 'Content-Type: application/x-www-form-urlencoded\\r\\n'
/*      */     //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   188: pop
/*      */     //   189: iload #4
/*      */     //   191: getstatic oracle/net/www/protocol/http/HttpURLConnection.s_maxRedirects : I
/*      */     //   194: if_icmpge -> 268
/*      */     //   197: aload_0
/*      */     //   198: aload_2
/*      */     //   199: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   202: invokespecial writeRequest : (Ljava/lang/String;)V
/*      */     //   205: aload_0
/*      */     //   206: aload_0
/*      */     //   207: getfield m_inputStream : Ljava/io/InputStream;
/*      */     //   210: aload_0
/*      */     //   211: getfield m_outputStream : Ljava/io/OutputStream;
/*      */     //   214: aload_2
/*      */     //   215: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   218: invokevirtual processResponse : (Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V
/*      */     //   221: iinc #4, 1
/*      */     //   224: invokestatic getFollowRedirects : ()Z
/*      */     //   227: ifeq -> 268
/*      */     //   230: aload_0
/*      */     //   231: getfield responseCode : I
/*      */     //   234: sipush #299
/*      */     //   237: if_icmple -> 268
/*      */     //   240: aload_0
/*      */     //   241: getfield responseCode : I
/*      */     //   244: sipush #400
/*      */     //   247: if_icmpge -> 268
/*      */     //   250: iload #4
/*      */     //   252: getstatic oracle/net/www/protocol/http/HttpURLConnection.s_maxRedirects : I
/*      */     //   255: if_icmpeq -> 189
/*      */     //   258: aload_0
/*      */     //   259: invokevirtual process3XX : ()Z
/*      */     //   262: ifne -> 189
/*      */     //   265: goto -> 268
/*      */     //   268: goto -> 280
/*      */     //   271: astore #5
/*      */     //   273: aload_0
/*      */     //   274: invokevirtual disconnect : ()V
/*      */     //   277: aload #5
/*      */     //   279: athrow
/*      */     //   280: aload_0
/*      */     //   281: getfield m_inputStream : Ljava/io/InputStream;
/*      */     //   284: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #404	-> 0
/*      */     //   #406	-> 3
/*      */     //   #407	-> 10
/*      */     //   #409	-> 20
/*      */     //   #412	-> 27
/*      */     //   #420	-> 32
/*      */     //   #424	-> 36
/*      */     //   #427	-> 44
/*      */     //   #430	-> 50
/*      */     //   #431	-> 65
/*      */     //   #434	-> 71
/*      */     //   #435	-> 79
/*      */     //   #437	-> 88
/*      */     //   #438	-> 98
/*      */     //   #442	-> 125
/*      */     //   #444	-> 132
/*      */     //   #446	-> 151
/*      */     //   #448	-> 173
/*      */     //   #449	-> 182
/*      */     //   #453	-> 189
/*      */     //   #455	-> 197
/*      */     //   #456	-> 205
/*      */     //   #457	-> 221
/*      */     //   #458	-> 224
/*      */     //   #461	-> 250
/*      */     //   #462	-> 265
/*      */     //   #470	-> 268
/*      */     //   #467	-> 271
/*      */     //   #468	-> 273
/*      */     //   #469	-> 277
/*      */     //   #478	-> 280
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   189	268	271	java/io/IOException
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeRequest(String paramString) throws IOException {
/*  485 */     this.m_inputStream = new BufferedInputStream(this.m_socket.getInputStream());
/*  486 */     this.m_outputStream = this.m_socket.getOutputStream();
/*  487 */     if (this.m_inputStream == null)
/*  488 */       throw new IOException("Could not get inputStream."); 
/*  489 */     if (this.m_outputStream == null) {
/*  490 */       throw new IOException("Could not get outputStream.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  496 */     String str = getRequestPrefix();
/*  497 */     this.m_outputStream.write(str.getBytes("ISO-8859-1"), 0, str.length());
/*  498 */     this.m_outputStream.write(paramString.toString().getBytes("ISO-8859-1"), 0, paramString.length());
/*  499 */     this.m_outputStream.write("\r\n".getBytes("ISO-8859-1"), 0, 2);
/*      */     
/*  501 */     if (this.m_buffer != null)
/*  502 */       this.m_buffer.writeTo(this.m_outputStream); 
/*  503 */     this.m_outputStream.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void disconnect() {
/*  509 */     if (!this.connected) {
/*      */       return;
/*      */     }
/*  512 */     if (this.m_inputStream != null) {
/*      */       
/*      */       try {
/*  515 */         this.m_inputStream.close();
/*  516 */       } catch (IOException iOException) {}
/*      */ 
/*      */       
/*  519 */       this.m_inputStream = null;
/*      */     } 
/*  521 */     if (this.m_outputStream != null) {
/*      */       
/*      */       try {
/*  524 */         this.m_outputStream.close();
/*  525 */       } catch (IOException iOException) {}
/*      */ 
/*      */       
/*  528 */       this.m_outputStream = null;
/*      */     } 
/*  530 */     if (this.m_socket != null) {
/*      */       
/*      */       try {
/*  533 */         this.m_socket.close();
/*  534 */       } catch (IOException iOException) {}
/*      */ 
/*      */       
/*  537 */       this.m_socket = null;
/*      */     } 
/*  539 */     this.m_headerKeys = this.m_headerValues = null;
/*      */     
/*  541 */     this.responseCode = -1;
/*  542 */     this.responseMessage = null;
/*  543 */     this.connected = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean process3XX() throws IOException {
/*  556 */     String str2 = getRequestMethod();
/*      */     
/*  558 */     String str1 = getHeaderField("location");
/*  559 */     if (str1 == null) {
/*  560 */       return false;
/*      */     }
/*  562 */     URL uRL = new URL(str1);
/*  563 */     if (!getURL().getProtocol().equalsIgnoreCase(uRL.getProtocol()))
/*  564 */       return false; 
/*  565 */     setURL(uRL);
/*      */     
/*  567 */     switch (this.responseCode) {
/*      */ 
/*      */       
/*      */       case 303:
/*  571 */         if ("POST".equalsIgnoreCase(getRequestMethod())) {
/*  572 */           str2 = "GET";
/*      */         }
/*      */         break;
/*      */       
/*      */       case 304:
/*  577 */         return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  584 */     if (!str2.equalsIgnoreCase("GET") && !str2.equalsIgnoreCase("HEAD"))
/*      */     {
/*  586 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  590 */     disconnect();
/*  591 */     setRequestMethod(str2);
/*  592 */     connect();
/*  593 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processResponse(InputStream paramInputStream, OutputStream paramOutputStream, String paramString) throws IOException {
/*  608 */     parseHeaders(paramInputStream);
/*  609 */     if (this.responseCode == -1) {
/*  610 */       throw new IOException("Unrecognized response from proxy or HTTP server. Response:\n" + getHeaderField(0));
/*      */     }
/*      */ 
/*      */     
/*  614 */     if (this.responseCode == 407 || this.responseCode == 401) {
/*      */       
/*  616 */       boolean bool = (this.responseCode == 407) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  626 */       if (bool && this.m_proxyAuthAttempted)
/*  627 */         throw new IOException("Not authenticated to the proxy."); 
/*  628 */       if (!bool && this.m_httpAuthAttempted) {
/*  629 */         throw new IOException("Not authenticated to the server.");
/*      */       }
/*  631 */       String str3 = bool ? "Proxy-Authenticate" : "WWW-Authenticate";
/*  632 */       String str1 = getCredHeader(str3, bool);
/*      */       
/*  634 */       if (str1 == null) {
/*  635 */         throw new IOException("Username and/or password for " + (bool ? "proxy" : "http") + " authentication not set." + " Cannot authenticate");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  640 */       if (bool) {
/*  641 */         this.m_proxyAuthAttempted = true;
/*      */       } else {
/*  643 */         this.m_httpAuthAttempted = true;
/*      */       } 
/*      */       
/*  646 */       String str2 = getHeaderField("connection");
/*  647 */       if (bool || (str2 != null && str2.trim().equalsIgnoreCase("close"))) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  652 */         disconnect();
/*  653 */         connect();
/*  654 */         paramInputStream = this.m_inputStream = new BufferedInputStream(this.m_socket.getInputStream());
/*  655 */         paramOutputStream = this.m_outputStream = this.m_socket.getOutputStream();
/*  656 */         if (paramInputStream == null)
/*  657 */           throw new IOException("Could not get inputStream."); 
/*  658 */         if (paramOutputStream == null) {
/*  659 */           throw new IOException("Could not get outputStream.");
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  666 */         int i = getContentLength();
/*      */         
/*  668 */         while (i > 0 && paramInputStream.read() != -1)
/*  669 */           i--; 
/*      */       } 
/*  671 */       paramString = paramString + str1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  677 */       String str4 = getRequestPrefix();
/*  678 */       paramOutputStream.write(str4.getBytes("ISO-8859-1"), 0, str4.length());
/*  679 */       paramOutputStream.write((paramString + "\r\n").getBytes("ISO-8859-1"), 0, paramString.length() + 2);
/*      */       
/*  681 */       if (this.m_buffer != null)
/*  682 */         this.m_buffer.writeTo(paramOutputStream); 
/*  683 */       paramOutputStream.flush();
/*  684 */       processResponse(paramInputStream, paramOutputStream, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseHeaders(InputStream paramInputStream) throws IOException {
/*  706 */     String str2 = "Unknown protocol. Expected HTTP response. Response:\n";
/*      */     
/*  708 */     Vector vector1 = new Vector(10, 5);
/*  709 */     Vector vector2 = new Vector(10, 5);
/*  710 */     StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */     
/*  713 */     this.responseCode = -1;
/*  714 */     this.responseMessage = null;
/*  715 */     this.m_headerKeys = null;
/*  716 */     this.m_headerValues = null;
/*      */ 
/*      */ 
/*      */     
/*  720 */     String str1 = readLine(paramInputStream);
/*      */     
/*  722 */     if (str1 == null || !str1.regionMatches(true, 0, "HTTP/", 0, 5))
/*  723 */       throw new ProtocolException(str2 + str1); 
/*  724 */     vector1.addElement("null");
/*  725 */     vector2.addElement(str1);
/*      */ 
/*      */     
/*  728 */     int i = str1.indexOf(' ');
/*  729 */     for (; str1.charAt(i) == ' '; i++);
/*      */     try {
/*  731 */       this.responseCode = Integer.parseInt(str1.substring(i, i + 3));
/*  732 */     } catch (Exception exception) {
/*  733 */       this.responseCode = -1;
/*      */     } 
/*      */ 
/*      */     
/*  737 */     while ((str1 = readLine(paramInputStream)) != null) {
/*      */ 
/*      */       
/*  740 */       if (str1.equals(""))
/*      */         break; 
/*  742 */       i = str1.indexOf(":");
/*  743 */       if (i < 0)
/*  744 */         throw new ProtocolException(str2 + str1); 
/*  745 */       vector1.addElement(str1.substring(0, i).trim().toLowerCase());
/*  746 */       if (i >= str1.length() - 1) {
/*  747 */         vector2.addElement(""); continue;
/*      */       } 
/*  749 */       vector2.addElement(str1.substring(i + 1).trim());
/*      */     } 
/*  751 */     this.m_headerKeys = new String[vector1.size()];
/*  752 */     this.m_headerValues = new String[vector2.size()];
/*  753 */     vector1.copyInto((Object[])this.m_headerKeys);
/*  754 */     vector2.copyInto((Object[])this.m_headerValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized OutputStream getOutputStream() throws IOException {
/*  761 */     if (!getDoOutput()) {
/*  762 */       throw new ProtocolException("doOutput is set to false.");
/*      */     }
/*  764 */     if (this.m_inputStream != null) {
/*  765 */       throw new ProtocolException("Cannot write output after input is read.");
/*      */     }
/*      */     
/*  768 */     if (getRequestMethod().equals("GET")) {
/*  769 */       setRequestMethod("POST");
/*      */     }
/*  771 */     if (!getRequestMethod().equals("POST") && !getRequestMethod().equals("PUT")) {
/*  772 */       throw new ProtocolException("Method: " + getRequestMethod() + " does not support output");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  779 */     if (this.m_buffer == null) {
/*  780 */       this.m_buffer = new ByteArrayOutputStream();
/*      */     }
/*      */     
/*  783 */     return this.m_buffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] getCredentials(boolean paramBoolean1, boolean paramBoolean2) {
/*  793 */     String[] arrayOfString = new String[2];
/*      */     
/*  795 */     arrayOfString[0] = paramBoolean1 ? this.m_proxyCred.getUsername() : this.m_httpCred.getUsername();
/*      */     
/*  797 */     arrayOfString[1] = paramBoolean1 ? this.m_proxyCred.getPassword() : this.m_httpCred.getPassword();
/*      */     
/*  799 */     if (arrayOfString[0] == null) {
/*      */       
/*  801 */       arrayOfString[0] = paramBoolean1 ? s_defaultProxyCred.getUsername() : s_defaultHttpCred.getUsername();
/*      */       
/*  803 */       if (arrayOfString[0] == null) {
/*  804 */         arrayOfString[0] = paramBoolean1 ? System.getProperty("http.proxyUsername") : System.getProperty("http.username");
/*      */       }
/*      */     } 
/*  807 */     if (arrayOfString[1] == null) {
/*      */       
/*  809 */       arrayOfString[1] = paramBoolean1 ? s_defaultProxyCred.getPassword() : s_defaultHttpCred.getPassword();
/*      */       
/*  811 */       if (arrayOfString[1] == null) {
/*  812 */         arrayOfString[1] = paramBoolean1 ? System.getProperty("http.proxyPassword") : System.getProperty("http.password");
/*      */       }
/*      */     } 
/*  815 */     if ((arrayOfString[0] == null || arrayOfString[1] == null) && paramBoolean2) {
/*      */       
/*  817 */       AuthenticationDialog authenticationDialog = paramBoolean1 ? new AuthenticationDialog("Proxy authentication", "username", "password") : new AuthenticationDialog("Http authentication", "username", "password");
/*      */ 
/*      */ 
/*      */       
/*  821 */       authenticationDialog.display();
/*  822 */       arrayOfString[0] = authenticationDialog.getUsername();
/*  823 */       arrayOfString[1] = authenticationDialog.getPassword();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  829 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getBasicAuthHeader(boolean paramBoolean1, boolean paramBoolean2) {
/*  837 */     String[] arrayOfString = getCredentials(paramBoolean1, paramBoolean2);
/*  838 */     if (paramBoolean1) {
/*      */       
/*  840 */       setProxyAuthType("basic");
/*  841 */       setProxyUsername(arrayOfString[0]);
/*  842 */       setProxyPassword(arrayOfString[1]);
/*      */     }
/*      */     else {
/*      */       
/*  846 */       setHttpAuthType("basic");
/*  847 */       setHttpUsername(arrayOfString[0]);
/*  848 */       setHttpPassword(arrayOfString[1]);
/*      */     } 
/*  850 */     String str = this.m_proxyCred.getBasicCredentials(arrayOfString[0], arrayOfString[1]);
/*  851 */     if (str != null) {
/*  852 */       str = (paramBoolean1 ? "Proxy-Authorization: " : "Authorization: ") + "Basic " + str + "\r\n";
/*      */     }
/*      */     
/*  855 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getDigestAuthHeader(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/*  867 */     String[] arrayOfString = getCredentials(paramBoolean1, paramBoolean2);
/*  868 */     if (paramBoolean1) {
/*      */       
/*  870 */       setProxyAuthType("digest");
/*  871 */       setProxyUsername(arrayOfString[0]);
/*  872 */       setProxyPassword(arrayOfString[1]);
/*      */     }
/*      */     else {
/*      */       
/*  876 */       setHttpAuthType("digest");
/*  877 */       setHttpUsername(arrayOfString[0]);
/*  878 */       setHttpPassword(arrayOfString[1]);
/*      */     } 
/*      */     
/*  881 */     paramString = paramString.trim();
/*  882 */     HeaderParser headerParser = new HeaderParser(paramString);
/*      */     
/*  884 */     String str1 = headerParser.getValue("realm");
/*  885 */     String str3 = headerParser.getValue("nonce");
/*  886 */     String str4 = headerParser.getValue("ncount");
/*  887 */     String str5 = headerParser.getValue("qop");
/*  888 */     String str6 = headerParser.getValue("altorithm");
/*  889 */     String str2 = getURL().getFile();
/*  890 */     if (getURL() == null) {
/*  891 */       str2 = "/";
/*      */     }
/*      */     
/*  894 */     if (str5 != null) {
/*  895 */       str5 = (new StringTokenizer(str5, ",")).nextToken();
/*      */     }
/*  897 */     String str7 = this.m_proxyCred.getDigestCredentials(arrayOfString[0], arrayOfString[1], str1, str2, getRequestMethod(), str3, str4, null, str5, str6, null);
/*      */     
/*  899 */     if (str7 != null) {
/*  900 */       str7 = (paramBoolean1 ? "Proxy-Authorization: " : "Authorization: ") + "Digest " + str7 + "\r\n";
/*      */     }
/*      */     
/*  903 */     return str7;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String readLine(InputStream paramInputStream) throws IOException {
/*  911 */     int j = -1;
/*  912 */     StringBuffer stringBuffer = new StringBuffer();
/*  913 */     boolean bool = true;
/*      */     int i;
/*  915 */     while ((i = paramInputStream.read()) != -1) {
/*      */       
/*  917 */       if (i == 10 && j == 13) {
/*      */ 
/*      */ 
/*      */         
/*  921 */         stringBuffer.setLength(stringBuffer.length() - 1);
/*      */         break;
/*      */       } 
/*  924 */       stringBuffer.append((char)i);
/*  925 */       if (bool) bool = false; 
/*  926 */       j = i;
/*      */     } 
/*  928 */     if (bool) {
/*  929 */       return null;
/*      */     }
/*  931 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getCredHeader(String paramString, boolean paramBoolean) throws IOException {
/*  939 */     String str2 = getHeaderField(paramString);
/*      */ 
/*      */     
/*  942 */     if (str2 == null) {
/*  943 */       throw new IOException("\"" + paramString + "\" header not present.");
/*      */     }
/*  945 */     int i = str2.indexOf(' ');
/*  946 */     if (i < -1 || i == str2.length() - 1) {
/*  947 */       throw new IOException("\"" + paramString + "\" header is incorrect");
/*      */     }
/*  949 */     String str1 = str2.substring(0, i).trim();
/*  950 */     if (str1.equalsIgnoreCase("Basic")) {
/*      */ 
/*      */       
/*  953 */       str1 = getBasicAuthHeader(paramBoolean, true);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  964 */       throw new IOException("\"" + paramString + "\" header is incorrect");
/*      */     } 
/*  966 */     return str1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getRequestURI(URL paramURL) {
/*  975 */     return usingProxy() ? paramURL.toString() : paramURL.getFile();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Hashtable getResponseHeaders() {
/*  981 */     if (this.m_headerKeys == null || this.m_headerValues == null)
/*  982 */       return null; 
/*  983 */     Hashtable hashtable = new Hashtable();
/*  984 */     for (byte b = 0; b < this.m_headerKeys.length; b++)
/*  985 */       hashtable.put(this.m_headerKeys[b], this.m_headerValues[b]); 
/*  986 */     return hashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestPrefix() {
/*  992 */     StringBuffer stringBuffer = new StringBuffer();
/*  993 */     stringBuffer.append(getRequestMethod()).append(" ");
/*  994 */     stringBuffer.append(getRequestURI(getURL()));
/*  995 */     stringBuffer.append(" HTTP/1.0\r\n");
/*  996 */     stringBuffer.append("Host: " + getURL().getHost() + "\r\n");
/*  997 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestBasicAuthHeader(StringBuffer paramStringBuffer, boolean paramBoolean) {
/* 1004 */     String str1 = null, str2 = null;
/*      */     
/* 1006 */     if ((str1 = (String)(paramBoolean ? getProxyAuthType() : getHttpAuthType())) != null) {
/*      */ 
/*      */       
/* 1009 */       if (str1.equalsIgnoreCase("basic")) {
/* 1010 */         str2 = getBasicAuthHeader(paramBoolean, false);
/*      */       }
/* 1012 */     } else if ((str1 = (String)(paramBoolean ? getDefaultProxyAuthType() : getDefaultHttpAuthType())) != null) {
/*      */ 
/*      */       
/* 1015 */       if (str1.equalsIgnoreCase("basic")) {
/* 1016 */         str2 = getBasicAuthHeader(paramBoolean, false);
/*      */       }
/* 1018 */     } else if ((str1 = (String)(paramBoolean ? System.getProperty("http.proxyAuthType") : System.getProperty("http.authType"))) != null) {
/*      */ 
/*      */       
/* 1021 */       if (str1.equalsIgnoreCase("basic")) {
/* 1022 */         str2 = getBasicAuthHeader(paramBoolean, false);
/*      */       }
/*      */     } 
/* 1025 */     if (str2 != null) {
/*      */       
/* 1027 */       paramStringBuffer.append(str2);
/*      */       
/* 1029 */       if (paramBoolean) {
/* 1030 */         this.m_proxyAuthAttempted = true;
/*      */       } else {
/* 1032 */         this.m_httpAuthAttempted = true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL() {
/* 1040 */     return this.m_url;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setURL(URL paramURL) {
/* 1045 */     this.m_url = paramURL;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() throws Throwable {
/*      */     try {
/* 1052 */       disconnect();
/*      */     } finally {
/* 1054 */       super.finalize();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\protocol\http\HttpURLConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */