/*     */ package oracle.net.www;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64Decoder
/*     */ {
/*  22 */   private static final char[] KEY = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   private static final byte[] REVERSE_MAPPING = new byte[256]; static { byte b;
/*  34 */     for (b = 0; b < 'Ā'; b++)
/*  35 */       REVERSE_MAPPING[b] = -1; 
/*  36 */     for (b = 0; b < KEY.length; b++) {
/*  37 */       REVERSE_MAPPING[KEY[b]] = (byte)b;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(String paramString) throws IOException {
/*  46 */     if (paramString == null) {
/*  47 */       return null;
/*     */     }
/*  49 */     return decode(paramString.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(byte[] paramArrayOfbyte) throws IOException {
/*  56 */     if (paramArrayOfbyte == null) {
/*  57 */       return null;
/*     */     }
/*  59 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/*  60 */     return decode(byteArrayInputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decode(InputStream paramInputStream) throws IOException {
/*  67 */     if (paramInputStream == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  71 */     decode(paramInputStream, byteArrayOutputStream);
/*  72 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void decode(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
/*  77 */     byte[] arrayOfByte = new byte[4];
/*  78 */     byte b = 0;
/*     */     
/*  80 */     if (paramInputStream == null || paramOutputStream == null) {
/*     */       return;
/*     */     }
/*  83 */     for (arrayOfByte[b] = (byte)paramInputStream.read(); (byte)paramInputStream.read() != -1; ) {
/*     */       
/*  85 */       if (arrayOfByte[b] == 61) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/*  90 */       arrayOfByte[b] = REVERSE_MAPPING[arrayOfByte[b]];
/*  91 */       if (arrayOfByte[b] == -1) {
/*     */         continue;
/*     */       }
/*  94 */       b++;
/*  95 */       if (b == 4) {
/*     */         
/*  97 */         writeFirstByte(paramOutputStream, arrayOfByte);
/*  98 */         writeSecondByte(paramOutputStream, arrayOfByte);
/*  99 */         writeThirdByte(paramOutputStream, arrayOfByte);
/* 100 */         b = 0;
/* 101 */         paramOutputStream.flush();
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     if (b == 1)
/*     */     {
/* 107 */       throw new IOException("Input does not contain a valid Base 64 encoded data");
/*     */     }
/*     */     
/* 110 */     if (b == 2) {
/*     */       
/* 112 */       writeFirstByte(paramOutputStream, arrayOfByte);
/*     */     }
/* 114 */     else if (b == 3) {
/*     */       
/* 116 */       writeFirstByte(paramOutputStream, arrayOfByte);
/* 117 */       writeSecondByte(paramOutputStream, arrayOfByte);
/*     */     } 
/* 119 */     paramOutputStream.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeFirstByte(OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws IOException {
/* 124 */     paramOutputStream.write((byte)(paramArrayOfbyte[0] << 2 & 0xFC | paramArrayOfbyte[1] >>> 4 & 0x3));
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeSecondByte(OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws IOException {
/* 129 */     paramOutputStream.write((byte)(paramArrayOfbyte[1] << 4 & 0xF0 | paramArrayOfbyte[2] >>> 2 & 0xF));
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeThirdByte(OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws IOException {
/* 134 */     paramOutputStream.write((byte)(paramArrayOfbyte[2] << 6 & 0xC0 | paramArrayOfbyte[3] & 0x3F));
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\Base64Decoder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */