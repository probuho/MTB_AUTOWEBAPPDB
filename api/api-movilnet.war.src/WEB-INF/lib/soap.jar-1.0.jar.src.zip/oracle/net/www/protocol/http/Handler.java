/*    */ package oracle.net.www.protocol.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends URLStreamHandler
/*    */ {
/*    */   public static final String PROXY_HOST = "http.proxyHost";
/*    */   public static final String PROXY_PORT = "http.proxyPort";
/*    */   private String m_proxyHost;
/*    */   private int m_proxyPort;
/*    */   
/*    */   public Handler() {
/* 30 */     this.m_proxyPort = -1;
/* 31 */     this.m_proxyHost = System.getProperty("http.proxyPort");
/* 32 */     if (this.m_proxyHost != null)
/*    */     {
/*    */       
/* 35 */       this.m_proxyPort = Integer.parseInt(this.m_proxyHost);
/*    */     }
/* 37 */     this.m_proxyHost = System.getProperty("http.proxyHost");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Handler(String paramString, int paramInt) {
/* 43 */     this.m_proxyHost = paramString;
/* 44 */     this.m_proxyPort = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDefaultPort() {
/* 49 */     return 80;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProxyHost() {
/* 54 */     return this.m_proxyHost;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getProxyPort() {
/* 59 */     return this.m_proxyPort;
/*    */   }
/*    */ 
/*    */   
/*    */   protected URLConnection openConnection(URL paramURL) throws IOException {
/* 64 */     return new HttpURLConnection(paramURL, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\soap.jar-1.0.jar!\oracle\net\www\protocol\http\Handler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */