/**
 * Contains parts of the <b>internal</b> implementation of this library.
 *
 * <p><b>Do not use any of the classes in this package.</b> They might be removed
 * or changed at any point without prior warning.
 */
package com.auth0.jwt.impl;
