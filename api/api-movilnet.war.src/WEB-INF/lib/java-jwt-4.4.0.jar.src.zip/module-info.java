module com.auth0.jwt {
    requires com.fasterxml.jackson.databind;

    exports com.auth0.jwt;
    exports com.auth0.jwt.algorithms;
    exports com.auth0.jwt.exceptions;
    exports com.auth0.jwt.interfaces;
}
