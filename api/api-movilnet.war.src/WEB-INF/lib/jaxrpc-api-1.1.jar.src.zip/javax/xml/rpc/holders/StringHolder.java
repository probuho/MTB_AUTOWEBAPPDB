/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringHolder
/*    */   implements Holder
/*    */ {
/*    */   public String value;
/*    */   
/*    */   public StringHolder() {}
/*    */   
/*    */   public StringHolder(String myString) {
/* 16 */     this.value = myString;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\StringHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */