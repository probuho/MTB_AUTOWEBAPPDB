package javax.xml.rpc.handler;

import java.util.List;
import java.util.Map;

public interface HandlerChain extends List {
  boolean handleRequest(MessageContext paramMessageContext);
  
  boolean handleResponse(MessageContext paramMessageContext);
  
  boolean handleFault(MessageContext paramMessageContext);
  
  void init(Map paramMap);
  
  void destroy();
  
  void setRoles(String[] paramArrayOfString);
  
  String[] getRoles();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\handler\HandlerChain.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */