package javax.xml.rpc.encoding;

import java.io.Serializable;
import java.util.Iterator;

public interface DeserializerFactory extends Serializable {
  Deserializer getDeserializerAs(String paramString);
  
  Iterator getSupportedMechanismTypes();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\encoding\DeserializerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */