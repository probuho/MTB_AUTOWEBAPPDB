package javax.xml.rpc.server;

import java.security.Principal;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.xml.rpc.handler.MessageContext;

public interface ServletEndpointContext {
  MessageContext getMessageContext();
  
  Principal getUserPrincipal();
  
  HttpSession getHttpSession();
  
  ServletContext getServletContext();
  
  boolean isUserInRole(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\server\ServletEndpointContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */