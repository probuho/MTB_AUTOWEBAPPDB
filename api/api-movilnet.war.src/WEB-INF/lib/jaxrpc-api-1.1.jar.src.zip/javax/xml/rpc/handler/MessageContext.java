package javax.xml.rpc.handler;

import java.util.Iterator;

public interface MessageContext {
  void setProperty(String paramString, Object paramObject);
  
  Object getProperty(String paramString);
  
  void removeProperty(String paramString);
  
  boolean containsProperty(String paramString);
  
  Iterator getPropertyNames();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\handler\MessageContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */