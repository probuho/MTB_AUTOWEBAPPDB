/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntegerWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Integer value;
/*    */   
/*    */   public IntegerWrapperHolder() {}
/*    */   
/*    */   public IntegerWrapperHolder(Integer myint) {
/* 16 */     this.value = myint;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\IntegerWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */