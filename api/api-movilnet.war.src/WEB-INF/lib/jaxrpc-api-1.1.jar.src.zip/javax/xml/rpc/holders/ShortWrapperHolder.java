/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ShortWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Short value;
/*    */   
/*    */   public ShortWrapperHolder() {}
/*    */   
/*    */   public ShortWrapperHolder(Short myshort) {
/* 16 */     this.value = myshort;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\ShortWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */