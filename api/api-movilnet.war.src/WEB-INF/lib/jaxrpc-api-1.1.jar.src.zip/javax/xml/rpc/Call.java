package javax.xml.rpc;

import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;

public interface Call {
  public static final String USERNAME_PROPERTY = "javax.xml.rpc.security.auth.username";
  
  public static final String PASSWORD_PROPERTY = "javax.xml.rpc.security.auth.password";
  
  public static final String OPERATION_STYLE_PROPERTY = "javax.xml.rpc.soap.operation.style";
  
  public static final String SOAPACTION_USE_PROPERTY = "javax.xml.rpc.soap.http.soapaction.use";
  
  public static final String SOAPACTION_URI_PROPERTY = "javax.xml.rpc.soap.http.soapaction.uri";
  
  public static final String ENCODINGSTYLE_URI_PROPERTY = "javax.xml.rpc.encodingstyle.namespace.uri";
  
  public static final String SESSION_MAINTAIN_PROPERTY = "javax.xml.rpc.session.maintain";
  
  boolean isParameterAndReturnSpecRequired(QName paramQName);
  
  void addParameter(String paramString, QName paramQName, ParameterMode paramParameterMode);
  
  void addParameter(String paramString, QName paramQName, Class paramClass, ParameterMode paramParameterMode);
  
  QName getParameterTypeByName(String paramString);
  
  void setReturnType(QName paramQName);
  
  void setReturnType(QName paramQName, Class paramClass);
  
  QName getReturnType();
  
  void removeAllParameters();
  
  QName getOperationName();
  
  void setOperationName(QName paramQName);
  
  QName getPortTypeName();
  
  void setPortTypeName(QName paramQName);
  
  void setTargetEndpointAddress(String paramString);
  
  String getTargetEndpointAddress();
  
  void setProperty(String paramString, Object paramObject);
  
  Object getProperty(String paramString);
  
  void removeProperty(String paramString);
  
  Iterator getPropertyNames();
  
  Object invoke(Object[] paramArrayOfObject) throws RemoteException;
  
  Object invoke(QName paramQName, Object[] paramArrayOfObject) throws RemoteException;
  
  void invokeOneWay(Object[] paramArrayOfObject);
  
  Map getOutputParams();
  
  List getOutputValues();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\Call.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */