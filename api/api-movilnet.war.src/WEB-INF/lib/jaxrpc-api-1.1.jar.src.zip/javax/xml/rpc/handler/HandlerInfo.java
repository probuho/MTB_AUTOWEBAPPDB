/*     */ package javax.xml.rpc.handler;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerInfo
/*     */   implements Serializable
/*     */ {
/*     */   private Class handlerClass;
/*     */   private Map config;
/*     */   private Vector headers;
/*     */   
/*     */   public HandlerInfo() {
/*  33 */     this.handlerClass = null;
/*  34 */     this.config = new HashMap();
/*  35 */     this.headers = new Vector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandlerInfo(Class handlerClass, Map config, QName[] headers) {
/*  48 */     this.handlerClass = handlerClass;
/*  49 */     this.config = config;
/*  50 */     this.headers = new Vector();
/*  51 */     if (headers != null) {
/*  52 */       for (int i = 0; i < headers.length; i++) {
/*  53 */         this.headers.add(i, headers[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHandlerClass(Class handlerClass) {
/*  63 */     this.handlerClass = handlerClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getHandlerClass() {
/*  71 */     return this.handlerClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHandlerConfig(Map config) {
/*  79 */     this.config = config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getHandlerConfig() {
/*  88 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaders(QName[] headers) {
/*  99 */     this.headers.clear();
/* 100 */     if (headers != null) {
/* 101 */       for (int i = 0; i < headers.length; i++) {
/* 102 */         this.headers.add(i, headers[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName[] getHeaders() {
/* 114 */     if (this.headers.size() == 0) {
/* 115 */       return null;
/*     */     }
/* 117 */     QName[] qns = new QName[this.headers.size()];
/* 118 */     this.headers.copyInto((Object[])qns);
/* 119 */     return qns;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\handler\HandlerInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */