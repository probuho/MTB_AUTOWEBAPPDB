/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BigIntegerHolder
/*    */   implements Holder
/*    */ {
/*    */   public BigInteger value;
/*    */   
/*    */   public BigIntegerHolder() {}
/*    */   
/*    */   public BigIntegerHolder(BigInteger myBigInteger) {
/* 16 */     this.value = myBigInteger;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\BigIntegerHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */