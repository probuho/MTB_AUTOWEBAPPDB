/*     */ package javax.xml.rpc.encoding;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLType
/*     */ {
/*  26 */   public static final QName XSD_STRING = new QName("http://www.w3.org/2001/XMLSchema", "string");
/*     */ 
/*     */ 
/*     */   
/*  30 */   public static final QName XSD_FLOAT = new QName("http://www.w3.org/2001/XMLSchema", "float");
/*     */ 
/*     */ 
/*     */   
/*  34 */   public static final QName XSD_BOOLEAN = new QName("http://www.w3.org/2001/XMLSchema", "boolean");
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static final QName XSD_DOUBLE = new QName("http://www.w3.org/2001/XMLSchema", "double");
/*     */ 
/*     */ 
/*     */   
/*  42 */   public static final QName XSD_INTEGER = new QName("http://www.w3.org/2001/XMLSchema", "integer");
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final QName XSD_INT = new QName("http://www.w3.org/2001/XMLSchema", "int");
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static final QName XSD_LONG = new QName("http://www.w3.org/2001/XMLSchema", "long");
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final QName XSD_SHORT = new QName("http://www.w3.org/2001/XMLSchema", "short");
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final QName XSD_DECIMAL = new QName("http://www.w3.org/2001/XMLSchema", "decimal");
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final QName XSD_BASE64 = new QName("http://www.w3.org/2001/XMLSchema", "base64Binary");
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final QName XSD_HEXBINARY = new QName("http://www.w3.org/2001/XMLSchema", "hexBinary");
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final QName XSD_BYTE = new QName("http://www.w3.org/2001/XMLSchema", "byte");
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static final QName XSD_DATETIME = new QName("http://www.w3.org/2001/XMLSchema", "dateTime");
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final QName XSD_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "QName");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final QName SOAP_STRING = new QName("http://schemas.xmlsoap.org/soap/encoding/", "string");
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static final QName SOAP_BOOLEAN = new QName("http://schemas.xmlsoap.org/soap/encoding/", "boolean");
/*     */ 
/*     */ 
/*     */   
/*  91 */   public static final QName SOAP_DOUBLE = new QName("http://schemas.xmlsoap.org/soap/encoding/", "double");
/*     */ 
/*     */ 
/*     */   
/*  95 */   public static final QName SOAP_BASE64 = new QName("http://schemas.xmlsoap.org/soap/encoding/", "base64");
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final QName SOAP_FLOAT = new QName("http://schemas.xmlsoap.org/soap/encoding/", "float");
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static final QName SOAP_INT = new QName("http://schemas.xmlsoap.org/soap/encoding/", "int");
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final QName SOAP_LONG = new QName("http://schemas.xmlsoap.org/soap/encoding/", "long");
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static final QName SOAP_SHORT = new QName("http://schemas.xmlsoap.org/soap/encoding/", "short");
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final QName SOAP_BYTE = new QName("http://schemas.xmlsoap.org/soap/encoding/", "byte");
/*     */ 
/*     */ 
/*     */   
/* 119 */   public static final QName SOAP_ARRAY = new QName("http://schemas.xmlsoap.org/soap/encoding/", "Array");
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\encoding\XMLType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */