package javax.xml.rpc.handler;

import javax.xml.namespace.QName;

public interface Handler {
  boolean handleRequest(MessageContext paramMessageContext);
  
  boolean handleResponse(MessageContext paramMessageContext);
  
  boolean handleFault(MessageContext paramMessageContext);
  
  void init(HandlerInfo paramHandlerInfo);
  
  void destroy();
  
  QName[] getHeaders();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\handler\Handler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */