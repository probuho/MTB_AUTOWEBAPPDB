/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntHolder
/*    */   implements Holder
/*    */ {
/*    */   public int value;
/*    */   
/*    */   public IntHolder() {}
/*    */   
/*    */   public IntHolder(int myint) {
/* 16 */     this.value = myint;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\IntHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */