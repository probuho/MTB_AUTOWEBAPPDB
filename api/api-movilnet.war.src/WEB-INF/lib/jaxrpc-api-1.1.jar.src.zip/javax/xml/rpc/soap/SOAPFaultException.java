/*     */ package javax.xml.rpc.soap;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.soap.Detail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPFaultException
/*     */   extends RuntimeException
/*     */ {
/*     */   private QName faultcode;
/*     */   private String faultstring;
/*     */   private String faultactor;
/*     */   private Detail detail;
/*     */   
/*     */   public SOAPFaultException(QName faultcode, String faultstring, String faultactor, Detail faultdetail) {
/*  54 */     super(faultstring);
/*  55 */     this.faultcode = faultcode;
/*  56 */     this.faultstring = faultstring;
/*  57 */     this.faultactor = faultactor;
/*  58 */     this.detail = faultdetail;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getFaultCode() {
/*  69 */     return this.faultcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFaultString() {
/*  79 */     return this.faultstring;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFaultActor() {
/*  90 */     return this.faultactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Detail getDetail() {
/* 101 */     return this.detail;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\soap\SOAPFaultException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */