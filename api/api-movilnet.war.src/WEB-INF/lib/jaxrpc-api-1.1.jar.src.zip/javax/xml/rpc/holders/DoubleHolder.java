/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DoubleHolder
/*    */   implements Holder
/*    */ {
/*    */   public double value;
/*    */   
/*    */   public DoubleHolder() {}
/*    */   
/*    */   public DoubleHolder(double mydouble) {
/* 16 */     this.value = mydouble;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\DoubleHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */