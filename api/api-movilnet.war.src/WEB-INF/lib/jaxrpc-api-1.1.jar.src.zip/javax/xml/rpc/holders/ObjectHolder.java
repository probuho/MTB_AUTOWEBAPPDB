/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObjectHolder
/*    */   implements Holder
/*    */ {
/*    */   public Object value;
/*    */   
/*    */   public ObjectHolder() {}
/*    */   
/*    */   public ObjectHolder(Object value) {
/* 16 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\ObjectHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */