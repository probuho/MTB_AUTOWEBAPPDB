/*    */ package javax.xml.rpc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterMode
/*    */ {
/*    */   private final String mode;
/*    */   
/*    */   private ParameterMode(String mode) {
/* 22 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     return this.mode;
/*    */   }
/*    */ 
/*    */   
/* 33 */   public static final ParameterMode IN = new ParameterMode("IN");
/*    */ 
/*    */ 
/*    */   
/* 37 */   public static final ParameterMode OUT = new ParameterMode("OUT");
/*    */ 
/*    */ 
/*    */   
/* 41 */   public static final ParameterMode INOUT = new ParameterMode("INOUT");
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\ParameterMode.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */