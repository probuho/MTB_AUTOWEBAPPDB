package javax.xml.rpc.handler;

import java.io.Serializable;
import java.util.List;
import javax.xml.namespace.QName;

public interface HandlerRegistry extends Serializable {
  List getHandlerChain(QName paramQName);
  
  void setHandlerChain(QName paramQName, List paramList);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\handler\HandlerRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */