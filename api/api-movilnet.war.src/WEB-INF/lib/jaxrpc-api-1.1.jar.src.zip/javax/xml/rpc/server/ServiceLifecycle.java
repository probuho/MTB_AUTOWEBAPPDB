package javax.xml.rpc.server;

import javax.xml.rpc.ServiceException;

public interface ServiceLifecycle {
  void init(Object paramObject) throws ServiceException;
  
  void destroy();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\server\ServiceLifecycle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */