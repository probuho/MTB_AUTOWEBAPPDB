/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FloatHolder
/*    */   implements Holder
/*    */ {
/*    */   public float value;
/*    */   
/*    */   public FloatHolder() {}
/*    */   
/*    */   public FloatHolder(float myfloat) {
/* 16 */     this.value = myfloat;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\FloatHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */