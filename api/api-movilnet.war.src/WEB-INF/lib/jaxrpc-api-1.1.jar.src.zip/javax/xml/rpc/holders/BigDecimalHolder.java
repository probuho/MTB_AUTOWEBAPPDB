/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BigDecimalHolder
/*    */   implements Holder
/*    */ {
/*    */   public BigDecimal value;
/*    */   
/*    */   public BigDecimalHolder() {}
/*    */   
/*    */   public BigDecimalHolder(BigDecimal myBigDecimal) {
/* 16 */     this.value = myBigDecimal;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\holders\BigDecimalHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */