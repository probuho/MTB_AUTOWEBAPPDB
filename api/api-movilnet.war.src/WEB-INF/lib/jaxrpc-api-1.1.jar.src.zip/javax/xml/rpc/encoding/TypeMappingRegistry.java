package javax.xml.rpc.encoding;

import java.io.Serializable;

public interface TypeMappingRegistry extends Serializable {
  TypeMapping register(String paramString, TypeMapping paramTypeMapping);
  
  void registerDefault(TypeMapping paramTypeMapping);
  
  TypeMapping getDefaultTypeMapping();
  
  String[] getRegisteredEncodingStyleURIs();
  
  TypeMapping getTypeMapping(String paramString);
  
  TypeMapping createTypeMapping();
  
  TypeMapping unregisterTypeMapping(String paramString);
  
  boolean removeTypeMapping(TypeMapping paramTypeMapping);
  
  void clear();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\encoding\TypeMappingRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */