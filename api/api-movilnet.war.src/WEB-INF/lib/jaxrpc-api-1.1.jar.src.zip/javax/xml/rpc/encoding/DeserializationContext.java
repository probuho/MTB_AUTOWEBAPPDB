package javax.xml.rpc.encoding;

public interface DeserializationContext {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\encoding\DeserializationContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */