package javax.xml.rpc.handler.soap;

import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.SOAPMessage;

public interface SOAPMessageContext extends MessageContext {
  SOAPMessage getMessage();
  
  void setMessage(SOAPMessage paramSOAPMessage);
  
  String[] getRoles();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-api-1.1.jar!\javax\xml\rpc\handler\soap\SOAPMessageContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */