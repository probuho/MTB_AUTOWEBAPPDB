/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BonusPlanModify
/*    */   extends BonusPlanEntity
/*    */   implements Serializable
/*    */ {
/*    */   protected EBonusPlanAction bonusPlanAction;
/*    */   
/*    */   public EBonusPlanAction getBonusPlanAction() {
/* 17 */     return this.bonusPlanAction;
/*    */   }
/*    */   
/*    */   public void setBonusPlanAction(EBonusPlanAction bonusPlanAction) {
/* 21 */     this.bonusPlanAction = bonusPlanAction;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\BonusPlanModify.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */