/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientBasicDataTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String birthDate;
/*     */   protected String citizenship;
/*     */   protected String email;
/*     */   protected String firstLastName;
/*     */   protected String firstName;
/*     */   protected String gender;
/*     */   protected String jubiladoInd;
/*     */   protected String middleName;
/*     */   protected String pensionInd;
/*     */   protected String secondLastName;
/*     */   protected String ssn;
/*     */   protected String ssnType;
/*     */   protected String title;
/*     */   
/*     */   public String getBirthDate() {
/*  29 */     return this.birthDate;
/*     */   }
/*     */   
/*     */   public void setBirthDate(String birthDate) {
/*  33 */     this.birthDate = birthDate;
/*     */   }
/*     */   
/*     */   public String getCitizenship() {
/*  37 */     return this.citizenship;
/*     */   }
/*     */   
/*     */   public void setCitizenship(String citizenship) {
/*  41 */     this.citizenship = citizenship;
/*     */   }
/*     */   
/*     */   public String getEmail() {
/*  45 */     return this.email;
/*     */   }
/*     */   
/*     */   public void setEmail(String email) {
/*  49 */     this.email = email;
/*     */   }
/*     */   
/*     */   public String getFirstLastName() {
/*  53 */     return this.firstLastName;
/*     */   }
/*     */   
/*     */   public void setFirstLastName(String firstLastName) {
/*  57 */     this.firstLastName = firstLastName;
/*     */   }
/*     */   
/*     */   public String getFirstName() {
/*  61 */     return this.firstName;
/*     */   }
/*     */   
/*     */   public void setFirstName(String firstName) {
/*  65 */     this.firstName = firstName;
/*     */   }
/*     */   
/*     */   public String getGender() {
/*  69 */     return this.gender;
/*     */   }
/*     */   
/*     */   public void setGender(String gender) {
/*  73 */     this.gender = gender;
/*     */   }
/*     */   
/*     */   public String getJubiladoInd() {
/*  77 */     return this.jubiladoInd;
/*     */   }
/*     */   
/*     */   public void setJubiladoInd(String jubiladoInd) {
/*  81 */     this.jubiladoInd = jubiladoInd;
/*     */   }
/*     */   
/*     */   public String getMiddleName() {
/*  85 */     return this.middleName;
/*     */   }
/*     */   
/*     */   public void setMiddleName(String middleName) {
/*  89 */     this.middleName = middleName;
/*     */   }
/*     */   
/*     */   public String getPensionInd() {
/*  93 */     return this.pensionInd;
/*     */   }
/*     */   
/*     */   public void setPensionInd(String pensionInd) {
/*  97 */     this.pensionInd = pensionInd;
/*     */   }
/*     */   
/*     */   public String getSecondLastName() {
/* 101 */     return this.secondLastName;
/*     */   }
/*     */   
/*     */   public void setSecondLastName(String secondLastName) {
/* 105 */     this.secondLastName = secondLastName;
/*     */   }
/*     */   
/*     */   public String getSsn() {
/* 109 */     return this.ssn;
/*     */   }
/*     */   
/*     */   public void setSsn(String ssn) {
/* 113 */     this.ssn = ssn;
/*     */   }
/*     */   
/*     */   public String getSsnType() {
/* 117 */     return this.ssnType;
/*     */   }
/*     */   
/*     */   public void setSsnType(String ssnType) {
/* 121 */     this.ssnType = ssnType;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/* 125 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setTitle(String title) {
/* 129 */     this.title = title;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ClientBasicDataTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */