package ve.com.movilnet.gdis.cia.prepay.ws.base.subscriber.service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import ve.com.movilnet.gdis.cia.ws.to.requests.CreatePeriodicChargeRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.CreateSubscriberRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.DeletePeriodicChargeRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ElectronicSerialRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ModifySubscriberRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.RetrieveLinesbyCIGSMRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.StringRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.StringRequestTO2;
import ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.LineBasicDataResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.LineSpecificDataResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.LineSpecificDataResponseTO2;
import ve.com.movilnet.gdis.cia.ws.to.responses.PeriodicChargeResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.RetrieveLinesResponseGSMTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.StatusLinesSubscriberResponseTO;

public interface IWSBaseSubscriber extends Remote {
  PeriodicChargeResponseTO createPeriodicCharge(CreatePeriodicChargeRequestTO paramCreatePeriodicChargeRequestTO) throws RemoteException;
  
  BooleanResponseTO createSubscriber(CreateSubscriberRequestTO paramCreateSubscriberRequestTO) throws RemoteException;
  
  PeriodicChargeResponseTO deletePeriodicCharge(DeletePeriodicChargeRequestTO paramDeletePeriodicChargeRequestTO) throws RemoteException;
  
  BooleanResponseTO deleteSubscriber(StringRequestTO paramStringRequestTO) throws RemoteException;
  
  BooleanResponseTO modifySubscriber(ModifySubscriberRequestTO paramModifySubscriberRequestTO) throws RemoteException;
  
  LineBasicDataResponseTO retrieveLineBasicData(StringRequestTO paramStringRequestTO) throws RemoteException;
  
  LineSpecificDataResponseTO retrieveLineSpecificData(StringRequestTO paramStringRequestTO) throws RemoteException;
  
  LineSpecificDataResponseTO2 retrieveLineSpecificData2(StringRequestTO2 paramStringRequestTO2) throws RemoteException;
  
  RetrieveLinesResponseGSMTO retrieveLinesByCIGSM(RetrieveLinesbyCIGSMRequestTO paramRetrieveLinesbyCIGSMRequestTO) throws RemoteException;
  
  StatusLinesSubscriberResponseTO retrieveStatusLinesSubscriber(StringRequestTO paramStringRequestTO) throws RemoteException;
  
  StatusLinesSubscriberResponseTO retrieveStatusLinesSubscriberbyESN(ElectronicSerialRequestTO paramElectronicSerialRequestTO) throws RemoteException;
  
  StatusLinesSubscriberResponseTO retrieveStatusLinesSubscriberbySIM(StringRequestTO paramStringRequestTO) throws RemoteException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\subscriber\service\IWSBaseSubscriber.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */