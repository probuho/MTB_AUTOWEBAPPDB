/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccumulatorBase
/*    */   implements Serializable
/*    */ {
/*    */   protected String accumulatorName;
/*    */   protected String amount;
/*    */   
/*    */   public String getAccumulatorName() {
/* 18 */     return this.accumulatorName;
/*    */   }
/*    */   
/*    */   public void setAccumulatorName(String accumulatorName) {
/* 22 */     this.accumulatorName = accumulatorName;
/*    */   }
/*    */   
/*    */   public String getAmount() {
/* 26 */     return this.amount;
/*    */   }
/*    */   
/*    */   public void setAmount(String amount) {
/* 30 */     this.amount = amount;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\AccumulatorBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */