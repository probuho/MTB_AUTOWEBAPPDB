/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberHome
/*    */   implements Serializable
/*    */ {
/*    */   protected String home1;
/*    */   protected String home2;
/*    */   protected String home3;
/*    */   protected String home4;
/*    */   
/*    */   public String getHome1() {
/* 20 */     return this.home1;
/*    */   }
/*    */   
/*    */   public void setHome1(String home1) {
/* 24 */     this.home1 = home1;
/*    */   }
/*    */   
/*    */   public String getHome2() {
/* 28 */     return this.home2;
/*    */   }
/*    */   
/*    */   public void setHome2(String home2) {
/* 32 */     this.home2 = home2;
/*    */   }
/*    */   
/*    */   public String getHome3() {
/* 36 */     return this.home3;
/*    */   }
/*    */   
/*    */   public void setHome3(String home3) {
/* 40 */     this.home3 = home3;
/*    */   }
/*    */   
/*    */   public String getHome4() {
/* 44 */     return this.home4;
/*    */   }
/*    */   
/*    */   public void setHome4(String home4) {
/* 48 */     this.home4 = home4;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberHome.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */