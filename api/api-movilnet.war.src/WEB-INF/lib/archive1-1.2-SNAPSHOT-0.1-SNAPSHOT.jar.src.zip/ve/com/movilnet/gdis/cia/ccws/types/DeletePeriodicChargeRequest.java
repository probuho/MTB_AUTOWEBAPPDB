/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeletePeriodicChargeRequest
/*    */   implements Serializable
/*    */ {
/*    */   protected String chargeId;
/*    */   protected String identity;
/*    */   protected String subscriberId;
/*    */   
/*    */   public String getChargeId() {
/* 19 */     return this.chargeId;
/*    */   }
/*    */   
/*    */   public void setChargeId(String chargeId) {
/* 23 */     this.chargeId = chargeId;
/*    */   }
/*    */   
/*    */   public String getIdentity() {
/* 27 */     return this.identity;
/*    */   }
/*    */   
/*    */   public void setIdentity(String identity) {
/* 31 */     this.identity = identity;
/*    */   }
/*    */   
/*    */   public String getSubscriberId() {
/* 35 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(String subscriberId) {
/* 39 */     this.subscriberId = subscriberId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\DeletePeriodicChargeRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */