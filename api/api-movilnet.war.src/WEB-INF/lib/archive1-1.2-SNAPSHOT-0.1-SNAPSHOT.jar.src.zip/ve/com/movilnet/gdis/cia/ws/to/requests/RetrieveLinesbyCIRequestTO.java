/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RetrieveLinesbyCIRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String ssn;
/*    */   protected String ssnType;
/*    */   
/*    */   public String getSsn() {
/* 18 */     return this.ssn;
/*    */   }
/*    */   
/*    */   public void setSsn(String ssn) {
/* 22 */     this.ssn = ssn;
/*    */   }
/*    */   
/*    */   public String getSsnType() {
/* 26 */     return this.ssnType;
/*    */   }
/*    */   
/*    */   public void setSsnType(String ssnType) {
/* 30 */     this.ssnType = ssnType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\RetrieveLinesbyCIRequestTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */