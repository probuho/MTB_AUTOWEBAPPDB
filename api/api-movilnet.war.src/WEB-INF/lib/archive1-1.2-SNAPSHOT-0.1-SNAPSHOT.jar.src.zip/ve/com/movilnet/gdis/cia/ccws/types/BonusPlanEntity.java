/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BonusPlanEntity
/*    */   implements Serializable
/*    */ {
/*    */   protected String bonusPlanName;
/*    */   
/*    */   public String getBonusPlanName() {
/* 17 */     return this.bonusPlanName;
/*    */   }
/*    */   
/*    */   public void setBonusPlanName(String bonusPlanName) {
/* 21 */     this.bonusPlanName = bonusPlanName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\BonusPlanEntity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */