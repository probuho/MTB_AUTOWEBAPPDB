/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberCreate
/*    */   extends SubscriberBase
/*    */   implements Serializable
/*    */ {
/*    */   protected String SPName;
/*    */   protected BalanceEntityBase[] balances;
/*    */   protected SubscriberMainBase subscriber;
/*    */   
/*    */   public String getSPName() {
/* 19 */     return this.SPName;
/*    */   }
/*    */   
/*    */   public void setSPName(String SPName) {
/* 23 */     this.SPName = SPName;
/*    */   }
/*    */   
/*    */   public BalanceEntityBase[] getBalances() {
/* 27 */     return this.balances;
/*    */   }
/*    */   
/*    */   public void setBalances(BalanceEntityBase[] balances) {
/* 31 */     this.balances = balances;
/*    */   }
/*    */   
/*    */   public SubscriberMainBase getSubscriber() {
/* 35 */     return this.subscriber;
/*    */   }
/*    */   
/*    */   public void setSubscriber(SubscriberMainBase subscriber) {
/* 39 */     this.subscriber = subscriber;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberCreate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */