/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected ApplicationClientTO applicationClient;
/*    */   protected SecurityTO security;
/*    */   protected String serviceProvider;
/*    */   protected short technology;
/*    */   protected String transactionId;
/*    */   
/*    */   public ApplicationClientTO getApplicationClient() {
/* 21 */     return this.applicationClient;
/*    */   }
/*    */   
/*    */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/* 25 */     this.applicationClient = applicationClient;
/*    */   }
/*    */   
/*    */   public SecurityTO getSecurity() {
/* 29 */     return this.security;
/*    */   }
/*    */   
/*    */   public void setSecurity(SecurityTO security) {
/* 33 */     this.security = security;
/*    */   }
/*    */   
/*    */   public String getServiceProvider() {
/* 37 */     return this.serviceProvider;
/*    */   }
/*    */   
/*    */   public void setServiceProvider(String serviceProvider) {
/* 41 */     this.serviceProvider = serviceProvider;
/*    */   }
/*    */   
/*    */   public short getTechnology() {
/* 45 */     return this.technology;
/*    */   }
/*    */   
/*    */   public void setTechnology(short technology) {
/* 49 */     this.technology = technology;
/*    */   }
/*    */   
/*    */   public String getTransactionId() {
/* 53 */     return this.transactionId;
/*    */   }
/*    */   
/*    */   public void setTransactionId(String transactionId) {
/* 57 */     this.transactionId = transactionId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\RequestTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */