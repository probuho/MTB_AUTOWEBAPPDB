/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String ccwsPassword;
/*    */   protected String ccwsUser;
/*    */   
/*    */   public String getCcwsPassword() {
/* 18 */     return this.ccwsPassword;
/*    */   }
/*    */   
/*    */   public void setCcwsPassword(String ccwsPassword) {
/* 22 */     this.ccwsPassword = ccwsPassword;
/*    */   }
/*    */   
/*    */   public String getCcwsUser() {
/* 26 */     return this.ccwsUser;
/*    */   }
/*    */   
/*    */   public void setCcwsUser(String ccwsUser) {
/* 30 */     this.ccwsUser = ccwsUser;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\SecurityTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */