/*     */ package ve.com.movilnet.gdis.cia.ccws.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberEntityExt
/*     */   implements Serializable
/*     */ {
/*     */   protected Long IDENTITY_ID;
/*     */   protected String SUBSCRIBER_ID;
/*     */   protected String appliedDate1;
/*     */   protected String appliedDate2;
/*     */   protected String appliedDate3;
/*     */   protected String appliedDate4;
/*     */   protected String appliedDate5;
/*     */   protected Calendar appliedDateRawData1;
/*     */   protected Calendar appliedDateRawData2;
/*     */   protected Calendar appliedDateRawData3;
/*     */   protected Calendar appliedDateRawData4;
/*     */   protected Calendar appliedDateRawData5;
/*     */   protected String nextAppliedDate1;
/*     */   protected String nextAppliedDate2;
/*     */   protected String nextAppliedDate3;
/*     */   protected String nextAppliedDate4;
/*     */   protected String nextAppliedDate5;
/*     */   protected Calendar nextAppliedDateRawData1;
/*     */   protected Calendar nextAppliedDateRawData2;
/*     */   protected Calendar nextAppliedDateRawData3;
/*     */   protected Calendar nextAppliedDateRawData4;
/*     */   protected Calendar nextAppliedDateRawData5;
/*     */   protected String specialDayDate1;
/*     */   protected String specialDayDate2;
/*     */   protected String specialDayDate3;
/*     */   protected String specialDayDate4;
/*     */   protected String specialDayDate5;
/*     */   protected Calendar specialDayDateRawData1;
/*     */   protected Calendar specialDayDateRawData2;
/*     */   protected Calendar specialDayDateRawData3;
/*     */   protected Calendar specialDayDateRawData4;
/*     */   protected Calendar specialDayDateRawData5;
/*     */   protected Short specialdayChangeCounter;
/*     */   
/*     */   public Long getIDENTITY_ID() {
/*  49 */     return this.IDENTITY_ID;
/*     */   }
/*     */   
/*     */   public void setIDENTITY_ID(Long IDENTITY_ID) {
/*  53 */     this.IDENTITY_ID = IDENTITY_ID;
/*     */   }
/*     */   
/*     */   public String getSUBSCRIBER_ID() {
/*  57 */     return this.SUBSCRIBER_ID;
/*     */   }
/*     */   
/*     */   public void setSUBSCRIBER_ID(String SUBSCRIBER_ID) {
/*  61 */     this.SUBSCRIBER_ID = SUBSCRIBER_ID;
/*     */   }
/*     */   
/*     */   public String getAppliedDate1() {
/*  65 */     return this.appliedDate1;
/*     */   }
/*     */   
/*     */   public void setAppliedDate1(String appliedDate1) {
/*  69 */     this.appliedDate1 = appliedDate1;
/*     */   }
/*     */   
/*     */   public String getAppliedDate2() {
/*  73 */     return this.appliedDate2;
/*     */   }
/*     */   
/*     */   public void setAppliedDate2(String appliedDate2) {
/*  77 */     this.appliedDate2 = appliedDate2;
/*     */   }
/*     */   
/*     */   public String getAppliedDate3() {
/*  81 */     return this.appliedDate3;
/*     */   }
/*     */   
/*     */   public void setAppliedDate3(String appliedDate3) {
/*  85 */     this.appliedDate3 = appliedDate3;
/*     */   }
/*     */   
/*     */   public String getAppliedDate4() {
/*  89 */     return this.appliedDate4;
/*     */   }
/*     */   
/*     */   public void setAppliedDate4(String appliedDate4) {
/*  93 */     this.appliedDate4 = appliedDate4;
/*     */   }
/*     */   
/*     */   public String getAppliedDate5() {
/*  97 */     return this.appliedDate5;
/*     */   }
/*     */   
/*     */   public void setAppliedDate5(String appliedDate5) {
/* 101 */     this.appliedDate5 = appliedDate5;
/*     */   }
/*     */   
/*     */   public Calendar getAppliedDateRawData1() {
/* 105 */     return this.appliedDateRawData1;
/*     */   }
/*     */   
/*     */   public void setAppliedDateRawData1(Calendar appliedDateRawData1) {
/* 109 */     this.appliedDateRawData1 = appliedDateRawData1;
/*     */   }
/*     */   
/*     */   public Calendar getAppliedDateRawData2() {
/* 113 */     return this.appliedDateRawData2;
/*     */   }
/*     */   
/*     */   public void setAppliedDateRawData2(Calendar appliedDateRawData2) {
/* 117 */     this.appliedDateRawData2 = appliedDateRawData2;
/*     */   }
/*     */   
/*     */   public Calendar getAppliedDateRawData3() {
/* 121 */     return this.appliedDateRawData3;
/*     */   }
/*     */   
/*     */   public void setAppliedDateRawData3(Calendar appliedDateRawData3) {
/* 125 */     this.appliedDateRawData3 = appliedDateRawData3;
/*     */   }
/*     */   
/*     */   public Calendar getAppliedDateRawData4() {
/* 129 */     return this.appliedDateRawData4;
/*     */   }
/*     */   
/*     */   public void setAppliedDateRawData4(Calendar appliedDateRawData4) {
/* 133 */     this.appliedDateRawData4 = appliedDateRawData4;
/*     */   }
/*     */   
/*     */   public Calendar getAppliedDateRawData5() {
/* 137 */     return this.appliedDateRawData5;
/*     */   }
/*     */   
/*     */   public void setAppliedDateRawData5(Calendar appliedDateRawData5) {
/* 141 */     this.appliedDateRawData5 = appliedDateRawData5;
/*     */   }
/*     */   
/*     */   public String getNextAppliedDate1() {
/* 145 */     return this.nextAppliedDate1;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDate1(String nextAppliedDate1) {
/* 149 */     this.nextAppliedDate1 = nextAppliedDate1;
/*     */   }
/*     */   
/*     */   public String getNextAppliedDate2() {
/* 153 */     return this.nextAppliedDate2;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDate2(String nextAppliedDate2) {
/* 157 */     this.nextAppliedDate2 = nextAppliedDate2;
/*     */   }
/*     */   
/*     */   public String getNextAppliedDate3() {
/* 161 */     return this.nextAppliedDate3;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDate3(String nextAppliedDate3) {
/* 165 */     this.nextAppliedDate3 = nextAppliedDate3;
/*     */   }
/*     */   
/*     */   public String getNextAppliedDate4() {
/* 169 */     return this.nextAppliedDate4;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDate4(String nextAppliedDate4) {
/* 173 */     this.nextAppliedDate4 = nextAppliedDate4;
/*     */   }
/*     */   
/*     */   public String getNextAppliedDate5() {
/* 177 */     return this.nextAppliedDate5;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDate5(String nextAppliedDate5) {
/* 181 */     this.nextAppliedDate5 = nextAppliedDate5;
/*     */   }
/*     */   
/*     */   public Calendar getNextAppliedDateRawData1() {
/* 185 */     return this.nextAppliedDateRawData1;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDateRawData1(Calendar nextAppliedDateRawData1) {
/* 189 */     this.nextAppliedDateRawData1 = nextAppliedDateRawData1;
/*     */   }
/*     */   
/*     */   public Calendar getNextAppliedDateRawData2() {
/* 193 */     return this.nextAppliedDateRawData2;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDateRawData2(Calendar nextAppliedDateRawData2) {
/* 197 */     this.nextAppliedDateRawData2 = nextAppliedDateRawData2;
/*     */   }
/*     */   
/*     */   public Calendar getNextAppliedDateRawData3() {
/* 201 */     return this.nextAppliedDateRawData3;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDateRawData3(Calendar nextAppliedDateRawData3) {
/* 205 */     this.nextAppliedDateRawData3 = nextAppliedDateRawData3;
/*     */   }
/*     */   
/*     */   public Calendar getNextAppliedDateRawData4() {
/* 209 */     return this.nextAppliedDateRawData4;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDateRawData4(Calendar nextAppliedDateRawData4) {
/* 213 */     this.nextAppliedDateRawData4 = nextAppliedDateRawData4;
/*     */   }
/*     */   
/*     */   public Calendar getNextAppliedDateRawData5() {
/* 217 */     return this.nextAppliedDateRawData5;
/*     */   }
/*     */   
/*     */   public void setNextAppliedDateRawData5(Calendar nextAppliedDateRawData5) {
/* 221 */     this.nextAppliedDateRawData5 = nextAppliedDateRawData5;
/*     */   }
/*     */   
/*     */   public String getSpecialDayDate1() {
/* 225 */     return this.specialDayDate1;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDate1(String specialDayDate1) {
/* 229 */     this.specialDayDate1 = specialDayDate1;
/*     */   }
/*     */   
/*     */   public String getSpecialDayDate2() {
/* 233 */     return this.specialDayDate2;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDate2(String specialDayDate2) {
/* 237 */     this.specialDayDate2 = specialDayDate2;
/*     */   }
/*     */   
/*     */   public String getSpecialDayDate3() {
/* 241 */     return this.specialDayDate3;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDate3(String specialDayDate3) {
/* 245 */     this.specialDayDate3 = specialDayDate3;
/*     */   }
/*     */   
/*     */   public String getSpecialDayDate4() {
/* 249 */     return this.specialDayDate4;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDate4(String specialDayDate4) {
/* 253 */     this.specialDayDate4 = specialDayDate4;
/*     */   }
/*     */   
/*     */   public String getSpecialDayDate5() {
/* 257 */     return this.specialDayDate5;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDate5(String specialDayDate5) {
/* 261 */     this.specialDayDate5 = specialDayDate5;
/*     */   }
/*     */   
/*     */   public Calendar getSpecialDayDateRawData1() {
/* 265 */     return this.specialDayDateRawData1;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDateRawData1(Calendar specialDayDateRawData1) {
/* 269 */     this.specialDayDateRawData1 = specialDayDateRawData1;
/*     */   }
/*     */   
/*     */   public Calendar getSpecialDayDateRawData2() {
/* 273 */     return this.specialDayDateRawData2;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDateRawData2(Calendar specialDayDateRawData2) {
/* 277 */     this.specialDayDateRawData2 = specialDayDateRawData2;
/*     */   }
/*     */   
/*     */   public Calendar getSpecialDayDateRawData3() {
/* 281 */     return this.specialDayDateRawData3;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDateRawData3(Calendar specialDayDateRawData3) {
/* 285 */     this.specialDayDateRawData3 = specialDayDateRawData3;
/*     */   }
/*     */   
/*     */   public Calendar getSpecialDayDateRawData4() {
/* 289 */     return this.specialDayDateRawData4;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDateRawData4(Calendar specialDayDateRawData4) {
/* 293 */     this.specialDayDateRawData4 = specialDayDateRawData4;
/*     */   }
/*     */   
/*     */   public Calendar getSpecialDayDateRawData5() {
/* 297 */     return this.specialDayDateRawData5;
/*     */   }
/*     */   
/*     */   public void setSpecialDayDateRawData5(Calendar specialDayDateRawData5) {
/* 301 */     this.specialDayDateRawData5 = specialDayDateRawData5;
/*     */   }
/*     */   
/*     */   public Short getSpecialdayChangeCounter() {
/* 305 */     return this.specialdayChangeCounter;
/*     */   }
/*     */   
/*     */   public void setSpecialdayChangeCounter(Short specialdayChangeCounter) {
/* 309 */     this.specialdayChangeCounter = specialdayChangeCounter;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberEntityExt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */