/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccumulatorEntity
/*    */   extends AccumulatorBase
/*    */   implements Serializable
/*    */ {
/*    */   protected String currencyCode;
/*    */   protected Calendar nextResetAccumulatorTS;
/*    */   protected int period;
/*    */   protected int zeroDay;
/*    */   
/*    */   public String getCurrencyCode() {
/* 20 */     return this.currencyCode;
/*    */   }
/*    */   
/*    */   public void setCurrencyCode(String currencyCode) {
/* 24 */     this.currencyCode = currencyCode;
/*    */   }
/*    */   
/*    */   public Calendar getNextResetAccumulatorTS() {
/* 28 */     return this.nextResetAccumulatorTS;
/*    */   }
/*    */   
/*    */   public void setNextResetAccumulatorTS(Calendar nextResetAccumulatorTS) {
/* 32 */     this.nextResetAccumulatorTS = nextResetAccumulatorTS;
/*    */   }
/*    */   
/*    */   public int getPeriod() {
/* 36 */     return this.period;
/*    */   }
/*    */   
/*    */   public void setPeriod(int period) {
/* 40 */     this.period = period;
/*    */   }
/*    */   
/*    */   public int getZeroDay() {
/* 44 */     return this.zeroDay;
/*    */   }
/*    */   
/*    */   public void setZeroDay(int zeroDay) {
/* 48 */     this.zeroDay = zeroDay;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\AccumulatorEntity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */