/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.ResultGSMTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RetrieveLinesResponseGSMTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected int ocurrenciaTotal;
/*    */   protected ResultGSMTO[] resultado;
/*    */   
/*    */   public int getOcurrenciaTotal() {
/* 18 */     return this.ocurrenciaTotal;
/*    */   }
/*    */   
/*    */   public void setOcurrenciaTotal(int ocurrenciaTotal) {
/* 22 */     this.ocurrenciaTotal = ocurrenciaTotal;
/*    */   }
/*    */   
/*    */   public ResultGSMTO[] getResultado() {
/* 26 */     return this.resultado;
/*    */   }
/*    */   
/*    */   public void setResultado(ResultGSMTO[] resultado) {
/* 30 */     this.resultado = resultado;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\RetrieveLinesResponseGSMTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */