/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberPPS
/*    */   extends SubscriberMainBase
/*    */   implements Serializable
/*    */ {
/*    */   protected String FFChangeCount;
/*    */   protected String SPName;
/*    */   protected AccumulatorModify[] accumulators;
/*    */   protected String balanceChangeChargeCode;
/*    */   protected String balanceChangeComment;
/*    */   protected BalanceEntityBase[] balances;
/*    */   protected BonusPlanModify[] bonusPlan;
/*    */   protected String currencyCode;
/*    */   protected String freeFFChgAllowance;
/*    */   
/*    */   public String getFFChangeCount() {
/* 25 */     return this.FFChangeCount;
/*    */   }
/*    */   
/*    */   public void setFFChangeCount(String FFChangeCount) {
/* 29 */     this.FFChangeCount = FFChangeCount;
/*    */   }
/*    */   
/*    */   public String getSPName() {
/* 33 */     return this.SPName;
/*    */   }
/*    */   
/*    */   public void setSPName(String SPName) {
/* 37 */     this.SPName = SPName;
/*    */   }
/*    */   
/*    */   public AccumulatorModify[] getAccumulators() {
/* 41 */     return this.accumulators;
/*    */   }
/*    */   
/*    */   public void setAccumulators(AccumulatorModify[] accumulators) {
/* 45 */     this.accumulators = accumulators;
/*    */   }
/*    */   
/*    */   public String getBalanceChangeChargeCode() {
/* 49 */     return this.balanceChangeChargeCode;
/*    */   }
/*    */   
/*    */   public void setBalanceChangeChargeCode(String balanceChangeChargeCode) {
/* 53 */     this.balanceChangeChargeCode = balanceChangeChargeCode;
/*    */   }
/*    */   
/*    */   public String getBalanceChangeComment() {
/* 57 */     return this.balanceChangeComment;
/*    */   }
/*    */   
/*    */   public void setBalanceChangeComment(String balanceChangeComment) {
/* 61 */     this.balanceChangeComment = balanceChangeComment;
/*    */   }
/*    */   
/*    */   public BalanceEntityBase[] getBalances() {
/* 65 */     return this.balances;
/*    */   }
/*    */   
/*    */   public void setBalances(BalanceEntityBase[] balances) {
/* 69 */     this.balances = balances;
/*    */   }
/*    */   
/*    */   public BonusPlanModify[] getBonusPlan() {
/* 73 */     return this.bonusPlan;
/*    */   }
/*    */   
/*    */   public void setBonusPlan(BonusPlanModify[] bonusPlan) {
/* 77 */     this.bonusPlan = bonusPlan;
/*    */   }
/*    */   
/*    */   public String getCurrencyCode() {
/* 81 */     return this.currencyCode;
/*    */   }
/*    */   
/*    */   public void setCurrencyCode(String currencyCode) {
/* 85 */     this.currencyCode = currencyCode;
/*    */   }
/*    */   
/*    */   public String getFreeFFChgAllowance() {
/* 89 */     return this.freeFFChgAllowance;
/*    */   }
/*    */   
/*    */   public void setFreeFFChgAllowance(String freeFFChgAllowance) {
/* 93 */     this.freeFFChgAllowance = freeFFChgAllowance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberPPS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */