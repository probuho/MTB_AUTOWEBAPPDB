/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientProfileTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String accountType;
/*     */   protected String accountTypeDesc;
/*     */   protected ClientBasicDataTO basicData;
/*     */   protected ClientCantvInfoTO clientCantvInfo;
/*     */   protected ClientLaborDataTO clientLaborData;
/*     */   protected ClientLocationTO clientLocation;
/*     */   protected ClientCorporateACTInfoTO corporateACTInfo;
/*     */   protected String dealerCode;
/*     */   protected ClientExtraInfoTO extraInfo;
/*     */   protected String phoneType;
/*     */   protected float phoneTypeId;
/*     */   protected String socialInd;
/*     */   protected String updbyDate;
/*     */   protected String updbyTransactionType;
/*     */   protected String updbyUserId;
/*     */   
/*     */   public String getAccountType() {
/*  31 */     return this.accountType;
/*     */   }
/*     */   
/*     */   public void setAccountType(String accountType) {
/*  35 */     this.accountType = accountType;
/*     */   }
/*     */   
/*     */   public String getAccountTypeDesc() {
/*  39 */     return this.accountTypeDesc;
/*     */   }
/*     */   
/*     */   public void setAccountTypeDesc(String accountTypeDesc) {
/*  43 */     this.accountTypeDesc = accountTypeDesc;
/*     */   }
/*     */   
/*     */   public ClientBasicDataTO getBasicData() {
/*  47 */     return this.basicData;
/*     */   }
/*     */   
/*     */   public void setBasicData(ClientBasicDataTO basicData) {
/*  51 */     this.basicData = basicData;
/*     */   }
/*     */   
/*     */   public ClientCantvInfoTO getClientCantvInfo() {
/*  55 */     return this.clientCantvInfo;
/*     */   }
/*     */   
/*     */   public void setClientCantvInfo(ClientCantvInfoTO clientCantvInfo) {
/*  59 */     this.clientCantvInfo = clientCantvInfo;
/*     */   }
/*     */   
/*     */   public ClientLaborDataTO getClientLaborData() {
/*  63 */     return this.clientLaborData;
/*     */   }
/*     */   
/*     */   public void setClientLaborData(ClientLaborDataTO clientLaborData) {
/*  67 */     this.clientLaborData = clientLaborData;
/*     */   }
/*     */   
/*     */   public ClientLocationTO getClientLocation() {
/*  71 */     return this.clientLocation;
/*     */   }
/*     */   
/*     */   public void setClientLocation(ClientLocationTO clientLocation) {
/*  75 */     this.clientLocation = clientLocation;
/*     */   }
/*     */   
/*     */   public ClientCorporateACTInfoTO getCorporateACTInfo() {
/*  79 */     return this.corporateACTInfo;
/*     */   }
/*     */   
/*     */   public void setCorporateACTInfo(ClientCorporateACTInfoTO corporateACTInfo) {
/*  83 */     this.corporateACTInfo = corporateACTInfo;
/*     */   }
/*     */   
/*     */   public String getDealerCode() {
/*  87 */     return this.dealerCode;
/*     */   }
/*     */   
/*     */   public void setDealerCode(String dealerCode) {
/*  91 */     this.dealerCode = dealerCode;
/*     */   }
/*     */   
/*     */   public ClientExtraInfoTO getExtraInfo() {
/*  95 */     return this.extraInfo;
/*     */   }
/*     */   
/*     */   public void setExtraInfo(ClientExtraInfoTO extraInfo) {
/*  99 */     this.extraInfo = extraInfo;
/*     */   }
/*     */   
/*     */   public String getPhoneType() {
/* 103 */     return this.phoneType;
/*     */   }
/*     */   
/*     */   public void setPhoneType(String phoneType) {
/* 107 */     this.phoneType = phoneType;
/*     */   }
/*     */   
/*     */   public float getPhoneTypeId() {
/* 111 */     return this.phoneTypeId;
/*     */   }
/*     */   
/*     */   public void setPhoneTypeId(float phoneTypeId) {
/* 115 */     this.phoneTypeId = phoneTypeId;
/*     */   }
/*     */   
/*     */   public String getSocialInd() {
/* 119 */     return this.socialInd;
/*     */   }
/*     */   
/*     */   public void setSocialInd(String socialInd) {
/* 123 */     this.socialInd = socialInd;
/*     */   }
/*     */   
/*     */   public String getUpdbyDate() {
/* 127 */     return this.updbyDate;
/*     */   }
/*     */   
/*     */   public void setUpdbyDate(String updbyDate) {
/* 131 */     this.updbyDate = updbyDate;
/*     */   }
/*     */   
/*     */   public String getUpdbyTransactionType() {
/* 135 */     return this.updbyTransactionType;
/*     */   }
/*     */   
/*     */   public void setUpdbyTransactionType(String updbyTransactionType) {
/* 139 */     this.updbyTransactionType = updbyTransactionType;
/*     */   }
/*     */   
/*     */   public String getUpdbyUserId() {
/* 143 */     return this.updbyUserId;
/*     */   }
/*     */   
/*     */   public void setUpdbyUserId(String updbyUserId) {
/* 147 */     this.updbyUserId = updbyUserId;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ClientProfileTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */