/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RetrieveLinesbyCIGSMRequestTO
/*    */   extends RetrieveLinesbyCIRequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String userId;
/*    */   
/*    */   public String getUserId() {
/* 17 */     return this.userId;
/*    */   }
/*    */   
/*    */   public void setUserId(String userId) {
/* 21 */     this.userId = userId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\RetrieveLinesbyCIGSMRequestTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */