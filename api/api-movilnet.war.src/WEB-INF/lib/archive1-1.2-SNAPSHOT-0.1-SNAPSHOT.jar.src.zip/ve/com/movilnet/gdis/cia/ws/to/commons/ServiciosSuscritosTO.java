/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiciosSuscritosTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String comercialName;
/*     */   protected String genField1;
/*     */   protected String genField2;
/*     */   protected String serviceCode;
/*     */   protected String serviceGroupId;
/*     */   protected String servicePeriodicCharge;
/*     */   protected String serviceSubType;
/*     */   protected String serviceType;
/*     */   protected Calendar subscriptionStartDate;
/*     */   protected String subscriptionStatus;
/*     */   protected Calendar subscriptonExpirationDate;
/*     */   protected String switchInd;
/*     */   
/*     */   public String getComercialName() {
/*  28 */     return this.comercialName;
/*     */   }
/*     */   
/*     */   public void setComercialName(String comercialName) {
/*  32 */     this.comercialName = comercialName;
/*     */   }
/*     */   
/*     */   public String getGenField1() {
/*  36 */     return this.genField1;
/*     */   }
/*     */   
/*     */   public void setGenField1(String genField1) {
/*  40 */     this.genField1 = genField1;
/*     */   }
/*     */   
/*     */   public String getGenField2() {
/*  44 */     return this.genField2;
/*     */   }
/*     */   
/*     */   public void setGenField2(String genField2) {
/*  48 */     this.genField2 = genField2;
/*     */   }
/*     */   
/*     */   public String getServiceCode() {
/*  52 */     return this.serviceCode;
/*     */   }
/*     */   
/*     */   public void setServiceCode(String serviceCode) {
/*  56 */     this.serviceCode = serviceCode;
/*     */   }
/*     */   
/*     */   public String getServiceGroupId() {
/*  60 */     return this.serviceGroupId;
/*     */   }
/*     */   
/*     */   public void setServiceGroupId(String serviceGroupId) {
/*  64 */     this.serviceGroupId = serviceGroupId;
/*     */   }
/*     */   
/*     */   public String getServicePeriodicCharge() {
/*  68 */     return this.servicePeriodicCharge;
/*     */   }
/*     */   
/*     */   public void setServicePeriodicCharge(String servicePeriodicCharge) {
/*  72 */     this.servicePeriodicCharge = servicePeriodicCharge;
/*     */   }
/*     */   
/*     */   public String getServiceSubType() {
/*  76 */     return this.serviceSubType;
/*     */   }
/*     */   
/*     */   public void setServiceSubType(String serviceSubType) {
/*  80 */     this.serviceSubType = serviceSubType;
/*     */   }
/*     */   
/*     */   public String getServiceType() {
/*  84 */     return this.serviceType;
/*     */   }
/*     */   
/*     */   public void setServiceType(String serviceType) {
/*  88 */     this.serviceType = serviceType;
/*     */   }
/*     */   
/*     */   public Calendar getSubscriptionStartDate() {
/*  92 */     return this.subscriptionStartDate;
/*     */   }
/*     */   
/*     */   public void setSubscriptionStartDate(Calendar subscriptionStartDate) {
/*  96 */     this.subscriptionStartDate = subscriptionStartDate;
/*     */   }
/*     */   
/*     */   public String getSubscriptionStatus() {
/* 100 */     return this.subscriptionStatus;
/*     */   }
/*     */   
/*     */   public void setSubscriptionStatus(String subscriptionStatus) {
/* 104 */     this.subscriptionStatus = subscriptionStatus;
/*     */   }
/*     */   
/*     */   public Calendar getSubscriptonExpirationDate() {
/* 108 */     return this.subscriptonExpirationDate;
/*     */   }
/*     */   
/*     */   public void setSubscriptonExpirationDate(Calendar subscriptonExpirationDate) {
/* 112 */     this.subscriptonExpirationDate = subscriptonExpirationDate;
/*     */   }
/*     */   
/*     */   public String getSwitchInd() {
/* 116 */     return this.switchInd;
/*     */   }
/*     */   
/*     */   public void setSwitchInd(String switchInd) {
/* 120 */     this.switchInd = switchInd;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ServiciosSuscritosTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */