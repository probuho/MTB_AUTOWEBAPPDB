/*     */ package ve.com.movilnet.gdis.cia.ccws.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberPB
/*     */   implements Serializable
/*     */ {
/*     */   protected String destNumber1;
/*     */   protected String destNumber10;
/*     */   protected String destNumber2;
/*     */   protected String destNumber3;
/*     */   protected String destNumber4;
/*     */   protected String destNumber5;
/*     */   protected String destNumber6;
/*     */   protected String destNumber7;
/*     */   protected String destNumber8;
/*     */   protected String destNumber9;
/*     */   
/*     */   public String getDestNumber1() {
/*  26 */     return this.destNumber1;
/*     */   }
/*     */   
/*     */   public void setDestNumber1(String destNumber1) {
/*  30 */     this.destNumber1 = destNumber1;
/*     */   }
/*     */   
/*     */   public String getDestNumber10() {
/*  34 */     return this.destNumber10;
/*     */   }
/*     */   
/*     */   public void setDestNumber10(String destNumber10) {
/*  38 */     this.destNumber10 = destNumber10;
/*     */   }
/*     */   
/*     */   public String getDestNumber2() {
/*  42 */     return this.destNumber2;
/*     */   }
/*     */   
/*     */   public void setDestNumber2(String destNumber2) {
/*  46 */     this.destNumber2 = destNumber2;
/*     */   }
/*     */   
/*     */   public String getDestNumber3() {
/*  50 */     return this.destNumber3;
/*     */   }
/*     */   
/*     */   public void setDestNumber3(String destNumber3) {
/*  54 */     this.destNumber3 = destNumber3;
/*     */   }
/*     */   
/*     */   public String getDestNumber4() {
/*  58 */     return this.destNumber4;
/*     */   }
/*     */   
/*     */   public void setDestNumber4(String destNumber4) {
/*  62 */     this.destNumber4 = destNumber4;
/*     */   }
/*     */   
/*     */   public String getDestNumber5() {
/*  66 */     return this.destNumber5;
/*     */   }
/*     */   
/*     */   public void setDestNumber5(String destNumber5) {
/*  70 */     this.destNumber5 = destNumber5;
/*     */   }
/*     */   
/*     */   public String getDestNumber6() {
/*  74 */     return this.destNumber6;
/*     */   }
/*     */   
/*     */   public void setDestNumber6(String destNumber6) {
/*  78 */     this.destNumber6 = destNumber6;
/*     */   }
/*     */   
/*     */   public String getDestNumber7() {
/*  82 */     return this.destNumber7;
/*     */   }
/*     */   
/*     */   public void setDestNumber7(String destNumber7) {
/*  86 */     this.destNumber7 = destNumber7;
/*     */   }
/*     */   
/*     */   public String getDestNumber8() {
/*  90 */     return this.destNumber8;
/*     */   }
/*     */   
/*     */   public void setDestNumber8(String destNumber8) {
/*  94 */     this.destNumber8 = destNumber8;
/*     */   }
/*     */   
/*     */   public String getDestNumber9() {
/*  98 */     return this.destNumber9;
/*     */   }
/*     */   
/*     */   public void setDestNumber9(String destNumber9) {
/* 102 */     this.destNumber9 = destNumber9;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberPB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */