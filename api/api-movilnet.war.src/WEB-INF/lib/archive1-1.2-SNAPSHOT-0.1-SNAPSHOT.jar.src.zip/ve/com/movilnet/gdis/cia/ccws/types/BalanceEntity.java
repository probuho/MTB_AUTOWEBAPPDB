/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BalanceEntity
/*    */   extends BalanceEntityBase
/*    */   implements Serializable
/*    */ {
/*    */   protected double availableBalance;
/*    */   protected double availableSpendingLimit;
/*    */   protected FundsType fundsType;
/*    */   protected double maximumSpendingLimit;
/*    */   protected int precisionPoint;
/*    */   
/*    */   public double getAvailableBalance() {
/* 21 */     return this.availableBalance;
/*    */   }
/*    */   
/*    */   public void setAvailableBalance(double availableBalance) {
/* 25 */     this.availableBalance = availableBalance;
/*    */   }
/*    */   
/*    */   public double getAvailableSpendingLimit() {
/* 29 */     return this.availableSpendingLimit;
/*    */   }
/*    */   
/*    */   public void setAvailableSpendingLimit(double availableSpendingLimit) {
/* 33 */     this.availableSpendingLimit = availableSpendingLimit;
/*    */   }
/*    */   
/*    */   public FundsType getFundsType() {
/* 37 */     return this.fundsType;
/*    */   }
/*    */   
/*    */   public void setFundsType(FundsType fundsType) {
/* 41 */     this.fundsType = fundsType;
/*    */   }
/*    */   
/*    */   public double getMaximumSpendingLimit() {
/* 45 */     return this.maximumSpendingLimit;
/*    */   }
/*    */   
/*    */   public void setMaximumSpendingLimit(double maximumSpendingLimit) {
/* 49 */     this.maximumSpendingLimit = maximumSpendingLimit;
/*    */   }
/*    */   
/*    */   public int getPrecisionPoint() {
/* 53 */     return this.precisionPoint;
/*    */   }
/*    */   
/*    */   public void setPrecisionPoint(int precisionPoint) {
/* 57 */     this.precisionPoint = precisionPoint;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\BalanceEntity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */