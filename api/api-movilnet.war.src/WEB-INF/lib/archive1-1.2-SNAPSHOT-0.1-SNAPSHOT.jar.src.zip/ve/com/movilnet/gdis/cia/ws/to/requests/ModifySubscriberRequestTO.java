/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.SubscriberModify;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.ClientProfileTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModifySubscriberRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected ClientProfileTO clientInfo;
/*    */   protected SubscriberModify subscriberModify;
/*    */   protected String transactionType;
/*    */   protected String nodo;
/*    */   
/*    */   public ClientProfileTO getClientInfo() {
/* 20 */     return this.clientInfo;
/*    */   }
/*    */   
/*    */   public void setClientInfo(ClientProfileTO clientInfo) {
/* 24 */     this.clientInfo = clientInfo;
/*    */   }
/*    */   
/*    */   public SubscriberModify getSubscriberModify() {
/* 28 */     return this.subscriberModify;
/*    */   }
/*    */   
/*    */   public void setSubscriberModify(SubscriberModify subscriberModify) {
/* 32 */     this.subscriberModify = subscriberModify;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 36 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 40 */     this.transactionType = transactionType;
/*    */   }
/*    */   
/*    */   public String getNodo() {
/* 44 */     return this.nodo;
/*    */   }
/*    */   
/*    */   public void setNodo(String nodo) {
/* 48 */     this.nodo = nodo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ModifySubscriberRequestTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */