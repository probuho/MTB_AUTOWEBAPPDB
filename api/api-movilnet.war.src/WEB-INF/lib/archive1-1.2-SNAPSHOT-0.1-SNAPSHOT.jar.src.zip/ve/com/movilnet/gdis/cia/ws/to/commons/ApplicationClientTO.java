/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationClientTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String application;
/*    */   protected String code;
/*    */   
/*    */   public String getApplication() {
/* 18 */     return this.application;
/*    */   }
/*    */   
/*    */   public void setApplication(String application) {
/* 22 */     this.application = application;
/*    */   }
/*    */   
/*    */   public String getCode() {
/* 26 */     return this.code;
/*    */   }
/*    */   
/*    */   public void setCode(String code) {
/* 30 */     this.code = code;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ApplicationClientTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */