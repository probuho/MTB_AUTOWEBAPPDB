/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscribedOffer
/*    */   extends OfferBase
/*    */   implements Serializable
/*    */ {
/*    */   protected Offer_State state;
/*    */   
/*    */   public Offer_State getState() {
/* 17 */     return this.state;
/*    */   }
/*    */   
/*    */   public void setState(Offer_State state) {
/* 21 */     this.state = state;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscribedOffer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */