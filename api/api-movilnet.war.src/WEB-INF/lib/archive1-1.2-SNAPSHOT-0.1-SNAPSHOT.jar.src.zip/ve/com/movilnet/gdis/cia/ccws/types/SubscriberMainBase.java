/*     */ package ve.com.movilnet.gdis.cia.ccws.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberMainBase
/*     */   implements Serializable
/*     */ {
/*     */   protected String CFBNumber;
/*     */   protected String CFISNumber;
/*     */   protected String CFNANumber;
/*     */   protected String CFUNumber;
/*     */   protected String COSName;
/*     */   protected String ESN;
/*     */   protected String HLR_ID;
/*     */   protected String IMSI;
/*     */   protected String PIN;
/*     */   protected boolean PINChangeNeeded;
/*     */   protected String accountNumber;
/*     */   protected String availableCyclicLimit;
/*     */   protected String billCycleDay;
/*     */   protected String creditLimit;
/*     */   protected String currentState;
/*     */   protected String cyclicLimit;
/*     */   protected SubscriberEntityExt extensionData;
/*     */   protected SOAPElement extensionDataRaw;
/*     */   protected String inFocusIdentity;
/*     */   protected String languageName;
/*     */   protected String limitType;
/*     */   protected String marketSegment;
/*     */   protected String notificationLanguage;
/*     */   protected String notificationLevel;
/*     */   protected String numberFreeAnCallsString;
/*     */   protected String otherSysID;
/*     */   protected String roamingCreditLimitAsString;
/*     */   protected String timeZone;
/*     */   
/*     */   public String getCFBNumber() {
/*  44 */     return this.CFBNumber;
/*     */   }
/*     */   
/*     */   public void setCFBNumber(String CFBNumber) {
/*  48 */     this.CFBNumber = CFBNumber;
/*     */   }
/*     */   
/*     */   public String getCFISNumber() {
/*  52 */     return this.CFISNumber;
/*     */   }
/*     */   
/*     */   public void setCFISNumber(String CFISNumber) {
/*  56 */     this.CFISNumber = CFISNumber;
/*     */   }
/*     */   
/*     */   public String getCFNANumber() {
/*  60 */     return this.CFNANumber;
/*     */   }
/*     */   
/*     */   public void setCFNANumber(String CFNANumber) {
/*  64 */     this.CFNANumber = CFNANumber;
/*     */   }
/*     */   
/*     */   public String getCFUNumber() {
/*  68 */     return this.CFUNumber;
/*     */   }
/*     */   
/*     */   public void setCFUNumber(String CFUNumber) {
/*  72 */     this.CFUNumber = CFUNumber;
/*     */   }
/*     */   
/*     */   public String getCOSName() {
/*  76 */     return this.COSName;
/*     */   }
/*     */   
/*     */   public void setCOSName(String COSName) {
/*  80 */     this.COSName = COSName;
/*     */   }
/*     */   
/*     */   public String getESN() {
/*  84 */     return this.ESN;
/*     */   }
/*     */   
/*     */   public void setESN(String ESN) {
/*  88 */     this.ESN = ESN;
/*     */   }
/*     */   
/*     */   public String getHLR_ID() {
/*  92 */     return this.HLR_ID;
/*     */   }
/*     */   
/*     */   public void setHLR_ID(String HLR_ID) {
/*  96 */     this.HLR_ID = HLR_ID;
/*     */   }
/*     */   
/*     */   public String getIMSI() {
/* 100 */     return this.IMSI;
/*     */   }
/*     */   
/*     */   public void setIMSI(String IMSI) {
/* 104 */     this.IMSI = IMSI;
/*     */   }
/*     */   
/*     */   public String getPIN() {
/* 108 */     return this.PIN;
/*     */   }
/*     */   
/*     */   public void setPIN(String PIN) {
/* 112 */     this.PIN = PIN;
/*     */   }
/*     */   
/*     */   public boolean isPINChangeNeeded() {
/* 116 */     return this.PINChangeNeeded;
/*     */   }
/*     */   
/*     */   public void setPINChangeNeeded(boolean PINChangeNeeded) {
/* 120 */     this.PINChangeNeeded = PINChangeNeeded;
/*     */   }
/*     */   
/*     */   public String getAccountNumber() {
/* 124 */     return this.accountNumber;
/*     */   }
/*     */   
/*     */   public void setAccountNumber(String accountNumber) {
/* 128 */     this.accountNumber = accountNumber;
/*     */   }
/*     */   
/*     */   public String getAvailableCyclicLimit() {
/* 132 */     return this.availableCyclicLimit;
/*     */   }
/*     */   
/*     */   public void setAvailableCyclicLimit(String availableCyclicLimit) {
/* 136 */     this.availableCyclicLimit = availableCyclicLimit;
/*     */   }
/*     */   
/*     */   public String getBillCycleDay() {
/* 140 */     return this.billCycleDay;
/*     */   }
/*     */   
/*     */   public void setBillCycleDay(String billCycleDay) {
/* 144 */     this.billCycleDay = billCycleDay;
/*     */   }
/*     */   
/*     */   public String getCreditLimit() {
/* 148 */     return this.creditLimit;
/*     */   }
/*     */   
/*     */   public void setCreditLimit(String creditLimit) {
/* 152 */     this.creditLimit = creditLimit;
/*     */   }
/*     */   
/*     */   public String getCurrentState() {
/* 156 */     return this.currentState;
/*     */   }
/*     */   
/*     */   public void setCurrentState(String currentState) {
/* 160 */     this.currentState = currentState;
/*     */   }
/*     */   
/*     */   public String getCyclicLimit() {
/* 164 */     return this.cyclicLimit;
/*     */   }
/*     */   
/*     */   public void setCyclicLimit(String cyclicLimit) {
/* 168 */     this.cyclicLimit = cyclicLimit;
/*     */   }
/*     */   
/*     */   public SubscriberEntityExt getExtensionData() {
/* 172 */     return this.extensionData;
/*     */   }
/*     */   
/*     */   public void setExtensionData(SubscriberEntityExt extensionData) {
/* 176 */     this.extensionData = extensionData;
/*     */   }
/*     */   
/*     */   public SOAPElement getExtensionDataRaw() {
/* 180 */     return this.extensionDataRaw;
/*     */   }
/*     */   
/*     */   public void setExtensionDataRaw(SOAPElement extensionDataRaw) {
/* 184 */     this.extensionDataRaw = extensionDataRaw;
/*     */   }
/*     */   
/*     */   public String getInFocusIdentity() {
/* 188 */     return this.inFocusIdentity;
/*     */   }
/*     */   
/*     */   public void setInFocusIdentity(String inFocusIdentity) {
/* 192 */     this.inFocusIdentity = inFocusIdentity;
/*     */   }
/*     */   
/*     */   public String getLanguageName() {
/* 196 */     return this.languageName;
/*     */   }
/*     */   
/*     */   public void setLanguageName(String languageName) {
/* 200 */     this.languageName = languageName;
/*     */   }
/*     */   
/*     */   public String getLimitType() {
/* 204 */     return this.limitType;
/*     */   }
/*     */   
/*     */   public void setLimitType(String limitType) {
/* 208 */     this.limitType = limitType;
/*     */   }
/*     */   
/*     */   public String getMarketSegment() {
/* 212 */     return this.marketSegment;
/*     */   }
/*     */   
/*     */   public void setMarketSegment(String marketSegment) {
/* 216 */     this.marketSegment = marketSegment;
/*     */   }
/*     */   
/*     */   public String getNotificationLanguage() {
/* 220 */     return this.notificationLanguage;
/*     */   }
/*     */   
/*     */   public void setNotificationLanguage(String notificationLanguage) {
/* 224 */     this.notificationLanguage = notificationLanguage;
/*     */   }
/*     */   
/*     */   public String getNotificationLevel() {
/* 228 */     return this.notificationLevel;
/*     */   }
/*     */   
/*     */   public void setNotificationLevel(String notificationLevel) {
/* 232 */     this.notificationLevel = notificationLevel;
/*     */   }
/*     */   
/*     */   public String getNumberFreeAnCallsString() {
/* 236 */     return this.numberFreeAnCallsString;
/*     */   }
/*     */   
/*     */   public void setNumberFreeAnCallsString(String numberFreeAnCallsString) {
/* 240 */     this.numberFreeAnCallsString = numberFreeAnCallsString;
/*     */   }
/*     */   
/*     */   public String getOtherSysID() {
/* 244 */     return this.otherSysID;
/*     */   }
/*     */   
/*     */   public void setOtherSysID(String otherSysID) {
/* 248 */     this.otherSysID = otherSysID;
/*     */   }
/*     */   
/*     */   public String getRoamingCreditLimitAsString() {
/* 252 */     return this.roamingCreditLimitAsString;
/*     */   }
/*     */   
/*     */   public void setRoamingCreditLimitAsString(String roamingCreditLimitAsString) {
/* 256 */     this.roamingCreditLimitAsString = roamingCreditLimitAsString;
/*     */   }
/*     */   
/*     */   public String getTimeZone() {
/* 260 */     return this.timeZone;
/*     */   }
/*     */   
/*     */   public void setTimeZone(String timeZone) {
/* 264 */     this.timeZone = timeZone;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberMainBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */