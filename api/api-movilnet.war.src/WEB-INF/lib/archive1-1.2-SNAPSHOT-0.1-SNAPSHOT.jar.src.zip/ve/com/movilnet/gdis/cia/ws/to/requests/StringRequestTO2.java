/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringRequestTO2
/*    */   extends StringRequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String generico1;
/*    */   protected String generico2;
/*    */   protected String generico3;
/*    */   
/*    */   public String getGenerico1() {
/* 19 */     return this.generico1;
/*    */   }
/*    */   
/*    */   public void setGenerico1(String generico1) {
/* 23 */     this.generico1 = generico1;
/*    */   }
/*    */   
/*    */   public String getGenerico2() {
/* 27 */     return this.generico2;
/*    */   }
/*    */   
/*    */   public void setGenerico2(String generico2) {
/* 31 */     this.generico2 = generico2;
/*    */   }
/*    */   
/*    */   public String getGenerico3() {
/* 35 */     return this.generico3;
/*    */   }
/*    */   
/*    */   public void setGenerico3(String generico3) {
/* 39 */     this.generico3 = generico3;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\StringRequestTO2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */