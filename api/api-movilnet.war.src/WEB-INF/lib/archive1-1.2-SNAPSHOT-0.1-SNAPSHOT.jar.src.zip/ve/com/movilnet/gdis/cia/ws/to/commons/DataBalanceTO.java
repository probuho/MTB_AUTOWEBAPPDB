/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.math.BigDecimal;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.BalanceEntityBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataBalanceTO
/*    */   extends BalanceListTO
/*    */   implements Serializable
/*    */ {
/*    */   protected BalanceEntityBase balanceEntityBase;
/*    */   protected BigDecimal montoBalance;
/*    */   
/*    */   public BalanceEntityBase getBalanceEntityBase() {
/* 18 */     return this.balanceEntityBase;
/*    */   }
/*    */   
/*    */   public void setBalanceEntityBase(BalanceEntityBase balanceEntityBase) {
/* 22 */     this.balanceEntityBase = balanceEntityBase;
/*    */   }
/*    */   
/*    */   public BigDecimal getMontoBalance() {
/* 26 */     return this.montoBalance;
/*    */   }
/*    */   
/*    */   public void setMontoBalance(BigDecimal montoBalance) {
/* 30 */     this.montoBalance = montoBalance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\DataBalanceTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */