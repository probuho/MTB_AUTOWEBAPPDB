/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PeriodicChargeResponse
/*    */   implements Serializable
/*    */ {
/*    */   protected int status;
/*    */   
/*    */   public int getStatus() {
/* 17 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(int status) {
/* 21 */     this.status = status;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\PeriodicChargeResponse.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */