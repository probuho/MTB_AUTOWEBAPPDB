/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientLocationTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String aptoNo;
/*     */   protected String aptoType;
/*     */   protected String avenueStreetName;
/*     */   protected String buildingName;
/*     */   protected String buildingType;
/*     */   protected String cityCode;
/*     */   protected String ctvSectorCode;
/*     */   protected String extraInfo;
/*     */   protected String floorNo;
/*     */   protected String floorType;
/*     */   protected String homePhoneNo;
/*     */   protected String municpCode;
/*     */   protected String parrqCode;
/*     */   protected String sectorCode;
/*     */   protected String stateCode;
/*     */   protected String streetType;
/*     */   protected String urbCode;
/*     */   protected String zipCode;
/*     */   
/*     */   public String getAptoNo() {
/*  34 */     return this.aptoNo;
/*     */   }
/*     */   
/*     */   public void setAptoNo(String aptoNo) {
/*  38 */     this.aptoNo = aptoNo;
/*     */   }
/*     */   
/*     */   public String getAptoType() {
/*  42 */     return this.aptoType;
/*     */   }
/*     */   
/*     */   public void setAptoType(String aptoType) {
/*  46 */     this.aptoType = aptoType;
/*     */   }
/*     */   
/*     */   public String getAvenueStreetName() {
/*  50 */     return this.avenueStreetName;
/*     */   }
/*     */   
/*     */   public void setAvenueStreetName(String avenueStreetName) {
/*  54 */     this.avenueStreetName = avenueStreetName;
/*     */   }
/*     */   
/*     */   public String getBuildingName() {
/*  58 */     return this.buildingName;
/*     */   }
/*     */   
/*     */   public void setBuildingName(String buildingName) {
/*  62 */     this.buildingName = buildingName;
/*     */   }
/*     */   
/*     */   public String getBuildingType() {
/*  66 */     return this.buildingType;
/*     */   }
/*     */   
/*     */   public void setBuildingType(String buildingType) {
/*  70 */     this.buildingType = buildingType;
/*     */   }
/*     */   
/*     */   public String getCityCode() {
/*  74 */     return this.cityCode;
/*     */   }
/*     */   
/*     */   public void setCityCode(String cityCode) {
/*  78 */     this.cityCode = cityCode;
/*     */   }
/*     */   
/*     */   public String getCtvSectorCode() {
/*  82 */     return this.ctvSectorCode;
/*     */   }
/*     */   
/*     */   public void setCtvSectorCode(String ctvSectorCode) {
/*  86 */     this.ctvSectorCode = ctvSectorCode;
/*     */   }
/*     */   
/*     */   public String getExtraInfo() {
/*  90 */     return this.extraInfo;
/*     */   }
/*     */   
/*     */   public void setExtraInfo(String extraInfo) {
/*  94 */     this.extraInfo = extraInfo;
/*     */   }
/*     */   
/*     */   public String getFloorNo() {
/*  98 */     return this.floorNo;
/*     */   }
/*     */   
/*     */   public void setFloorNo(String floorNo) {
/* 102 */     this.floorNo = floorNo;
/*     */   }
/*     */   
/*     */   public String getFloorType() {
/* 106 */     return this.floorType;
/*     */   }
/*     */   
/*     */   public void setFloorType(String floorType) {
/* 110 */     this.floorType = floorType;
/*     */   }
/*     */   
/*     */   public String getHomePhoneNo() {
/* 114 */     return this.homePhoneNo;
/*     */   }
/*     */   
/*     */   public void setHomePhoneNo(String homePhoneNo) {
/* 118 */     this.homePhoneNo = homePhoneNo;
/*     */   }
/*     */   
/*     */   public String getMunicpCode() {
/* 122 */     return this.municpCode;
/*     */   }
/*     */   
/*     */   public void setMunicpCode(String municpCode) {
/* 126 */     this.municpCode = municpCode;
/*     */   }
/*     */   
/*     */   public String getParrqCode() {
/* 130 */     return this.parrqCode;
/*     */   }
/*     */   
/*     */   public void setParrqCode(String parrqCode) {
/* 134 */     this.parrqCode = parrqCode;
/*     */   }
/*     */   
/*     */   public String getSectorCode() {
/* 138 */     return this.sectorCode;
/*     */   }
/*     */   
/*     */   public void setSectorCode(String sectorCode) {
/* 142 */     this.sectorCode = sectorCode;
/*     */   }
/*     */   
/*     */   public String getStateCode() {
/* 146 */     return this.stateCode;
/*     */   }
/*     */   
/*     */   public void setStateCode(String stateCode) {
/* 150 */     this.stateCode = stateCode;
/*     */   }
/*     */   
/*     */   public String getStreetType() {
/* 154 */     return this.streetType;
/*     */   }
/*     */   
/*     */   public void setStreetType(String streetType) {
/* 158 */     this.streetType = streetType;
/*     */   }
/*     */   
/*     */   public String getUrbCode() {
/* 162 */     return this.urbCode;
/*     */   }
/*     */   
/*     */   public void setUrbCode(String urbCode) {
/* 166 */     this.urbCode = urbCode;
/*     */   }
/*     */   
/*     */   public String getZipCode() {
/* 170 */     return this.zipCode;
/*     */   }
/*     */   
/*     */   public void setZipCode(String zipCode) {
/* 174 */     this.zipCode = zipCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ClientLocationTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */