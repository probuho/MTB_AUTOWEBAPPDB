/*     */ package ve.com.movilnet.gdis.cia.ccws.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberEntity
/*     */   extends SubscriberMainBase
/*     */   implements Serializable
/*     */ {
/*     */   protected String FFChangeCount;
/*     */   protected String SPName;
/*     */   protected SubscriberAccountType accountType;
/*     */   protected AccumulatorEntity[] accumulator;
/*     */   protected BalanceEntity[] balances;
/*     */   protected BonusPlanEntity[] bonusPlan;
/*     */   protected Calendar creationDate;
/*     */   protected String currencyCode;
/*     */   protected Calendar dateEnterActive;
/*     */   protected String freeFFChgAllowance;
/*     */   protected String groupName;
/*     */   protected double lastCallCharge;
/*     */   protected Calendar lastTransDate;
/*     */   protected SubscribedOffer[] offer;
/*     */   protected String preferredNumber;
/*     */   protected Calendar preferredNumberDate;
/*     */   protected Calendar prevTransDate;
/*     */   protected String previousPreferredNumber;
/*     */   protected String previousState;
/*     */   protected double promisedPaymentAmount;
/*     */   protected int promisedPaymentBalanceID;
/*     */   protected Calendar promisedPaymentDueDate;
/*     */   
/*     */   public String getFFChangeCount() {
/*  38 */     return this.FFChangeCount;
/*     */   }
/*     */   
/*     */   public void setFFChangeCount(String FFChangeCount) {
/*  42 */     this.FFChangeCount = FFChangeCount;
/*     */   }
/*     */   
/*     */   public String getSPName() {
/*  46 */     return this.SPName;
/*     */   }
/*     */   
/*     */   public void setSPName(String SPName) {
/*  50 */     this.SPName = SPName;
/*     */   }
/*     */   
/*     */   public SubscriberAccountType getAccountType() {
/*  54 */     return this.accountType;
/*     */   }
/*     */   
/*     */   public void setAccountType(SubscriberAccountType accountType) {
/*  58 */     this.accountType = accountType;
/*     */   }
/*     */   
/*     */   public AccumulatorEntity[] getAccumulator() {
/*  62 */     return this.accumulator;
/*     */   }
/*     */   
/*     */   public void setAccumulator(AccumulatorEntity[] accumulator) {
/*  66 */     this.accumulator = accumulator;
/*     */   }
/*     */   
/*     */   public BalanceEntity[] getBalances() {
/*  70 */     return this.balances;
/*     */   }
/*     */   
/*     */   public void setBalances(BalanceEntity[] balances) {
/*  74 */     this.balances = balances;
/*     */   }
/*     */   
/*     */   public BonusPlanEntity[] getBonusPlan() {
/*  78 */     return this.bonusPlan;
/*     */   }
/*     */   
/*     */   public void setBonusPlan(BonusPlanEntity[] bonusPlan) {
/*  82 */     this.bonusPlan = bonusPlan;
/*     */   }
/*     */   
/*     */   public Calendar getCreationDate() {
/*  86 */     return this.creationDate;
/*     */   }
/*     */   
/*     */   public void setCreationDate(Calendar creationDate) {
/*  90 */     this.creationDate = creationDate;
/*     */   }
/*     */   
/*     */   public String getCurrencyCode() {
/*  94 */     return this.currencyCode;
/*     */   }
/*     */   
/*     */   public void setCurrencyCode(String currencyCode) {
/*  98 */     this.currencyCode = currencyCode;
/*     */   }
/*     */   
/*     */   public Calendar getDateEnterActive() {
/* 102 */     return this.dateEnterActive;
/*     */   }
/*     */   
/*     */   public void setDateEnterActive(Calendar dateEnterActive) {
/* 106 */     this.dateEnterActive = dateEnterActive;
/*     */   }
/*     */   
/*     */   public String getFreeFFChgAllowance() {
/* 110 */     return this.freeFFChgAllowance;
/*     */   }
/*     */   
/*     */   public void setFreeFFChgAllowance(String freeFFChgAllowance) {
/* 114 */     this.freeFFChgAllowance = freeFFChgAllowance;
/*     */   }
/*     */   
/*     */   public String getGroupName() {
/* 118 */     return this.groupName;
/*     */   }
/*     */   
/*     */   public void setGroupName(String groupName) {
/* 122 */     this.groupName = groupName;
/*     */   }
/*     */   
/*     */   public double getLastCallCharge() {
/* 126 */     return this.lastCallCharge;
/*     */   }
/*     */   
/*     */   public void setLastCallCharge(double lastCallCharge) {
/* 130 */     this.lastCallCharge = lastCallCharge;
/*     */   }
/*     */   
/*     */   public Calendar getLastTransDate() {
/* 134 */     return this.lastTransDate;
/*     */   }
/*     */   
/*     */   public void setLastTransDate(Calendar lastTransDate) {
/* 138 */     this.lastTransDate = lastTransDate;
/*     */   }
/*     */   
/*     */   public SubscribedOffer[] getOffer() {
/* 142 */     return this.offer;
/*     */   }
/*     */   
/*     */   public void setOffer(SubscribedOffer[] offer) {
/* 146 */     this.offer = offer;
/*     */   }
/*     */   
/*     */   public String getPreferredNumber() {
/* 150 */     return this.preferredNumber;
/*     */   }
/*     */   
/*     */   public void setPreferredNumber(String preferredNumber) {
/* 154 */     this.preferredNumber = preferredNumber;
/*     */   }
/*     */   
/*     */   public Calendar getPreferredNumberDate() {
/* 158 */     return this.preferredNumberDate;
/*     */   }
/*     */   
/*     */   public void setPreferredNumberDate(Calendar preferredNumberDate) {
/* 162 */     this.preferredNumberDate = preferredNumberDate;
/*     */   }
/*     */   
/*     */   public Calendar getPrevTransDate() {
/* 166 */     return this.prevTransDate;
/*     */   }
/*     */   
/*     */   public void setPrevTransDate(Calendar prevTransDate) {
/* 170 */     this.prevTransDate = prevTransDate;
/*     */   }
/*     */   
/*     */   public String getPreviousPreferredNumber() {
/* 174 */     return this.previousPreferredNumber;
/*     */   }
/*     */   
/*     */   public void setPreviousPreferredNumber(String previousPreferredNumber) {
/* 178 */     this.previousPreferredNumber = previousPreferredNumber;
/*     */   }
/*     */   
/*     */   public String getPreviousState() {
/* 182 */     return this.previousState;
/*     */   }
/*     */   
/*     */   public void setPreviousState(String previousState) {
/* 186 */     this.previousState = previousState;
/*     */   }
/*     */   
/*     */   public double getPromisedPaymentAmount() {
/* 190 */     return this.promisedPaymentAmount;
/*     */   }
/*     */   
/*     */   public void setPromisedPaymentAmount(double promisedPaymentAmount) {
/* 194 */     this.promisedPaymentAmount = promisedPaymentAmount;
/*     */   }
/*     */   
/*     */   public int getPromisedPaymentBalanceID() {
/* 198 */     return this.promisedPaymentBalanceID;
/*     */   }
/*     */   
/*     */   public void setPromisedPaymentBalanceID(int promisedPaymentBalanceID) {
/* 202 */     this.promisedPaymentBalanceID = promisedPaymentBalanceID;
/*     */   }
/*     */   
/*     */   public Calendar getPromisedPaymentDueDate() {
/* 206 */     return this.promisedPaymentDueDate;
/*     */   }
/*     */   
/*     */   public void setPromisedPaymentDueDate(Calendar promisedPaymentDueDate) {
/* 210 */     this.promisedPaymentDueDate = promisedPaymentDueDate;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberEntity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */