/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected long executionTime;
/*    */   protected String origin;
/*    */   protected String responseCode;
/*    */   protected String responseDescription;
/*    */   protected String responseMessage;
/*    */   protected String responseSubCode;
/*    */   protected String transactionId;
/*    */   
/*    */   public long getExecutionTime() {
/* 23 */     return this.executionTime;
/*    */   }
/*    */   
/*    */   public void setExecutionTime(long executionTime) {
/* 27 */     this.executionTime = executionTime;
/*    */   }
/*    */   
/*    */   public String getOrigin() {
/* 31 */     return this.origin;
/*    */   }
/*    */   
/*    */   public void setOrigin(String origin) {
/* 35 */     this.origin = origin;
/*    */   }
/*    */   
/*    */   public String getResponseCode() {
/* 39 */     return this.responseCode;
/*    */   }
/*    */   
/*    */   public void setResponseCode(String responseCode) {
/* 43 */     this.responseCode = responseCode;
/*    */   }
/*    */   
/*    */   public String getResponseDescription() {
/* 47 */     return this.responseDescription;
/*    */   }
/*    */   
/*    */   public void setResponseDescription(String responseDescription) {
/* 51 */     this.responseDescription = responseDescription;
/*    */   }
/*    */   
/*    */   public String getResponseMessage() {
/* 55 */     return this.responseMessage;
/*    */   }
/*    */   
/*    */   public void setResponseMessage(String responseMessage) {
/* 59 */     this.responseMessage = responseMessage;
/*    */   }
/*    */   
/*    */   public String getResponseSubCode() {
/* 63 */     return this.responseSubCode;
/*    */   }
/*    */   
/*    */   public void setResponseSubCode(String responseSubCode) {
/* 67 */     this.responseSubCode = responseSubCode;
/*    */   }
/*    */   
/*    */   public String getTransactionId() {
/* 71 */     return this.transactionId;
/*    */   }
/*    */   
/*    */   public void setTransactionId(String transactionId) {
/* 75 */     this.transactionId = transactionId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\ResponseTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */