/*     */ package ve.com.movilnet.gdis.cia.ccws.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberPeriodicCharge
/*     */   implements Serializable
/*     */ {
/*     */   protected long applyDay;
/*     */   protected Calendar endDate;
/*     */   protected boolean firstChargeApplied;
/*     */   protected Calendar lastChargeDate;
/*     */   protected boolean pendingRC;
/*     */   protected String period;
/*     */   protected String periodicChargeID;
/*     */   protected String postActiveChargeApplied;
/*     */   protected int remainingApplications;
/*     */   protected Calendar startDate;
/*     */   
/*     */   public long getApplyDay() {
/*  26 */     return this.applyDay;
/*     */   }
/*     */   
/*     */   public void setApplyDay(long applyDay) {
/*  30 */     this.applyDay = applyDay;
/*     */   }
/*     */   
/*     */   public Calendar getEndDate() {
/*  34 */     return this.endDate;
/*     */   }
/*     */   
/*     */   public void setEndDate(Calendar endDate) {
/*  38 */     this.endDate = endDate;
/*     */   }
/*     */   
/*     */   public boolean isFirstChargeApplied() {
/*  42 */     return this.firstChargeApplied;
/*     */   }
/*     */   
/*     */   public void setFirstChargeApplied(boolean firstChargeApplied) {
/*  46 */     this.firstChargeApplied = firstChargeApplied;
/*     */   }
/*     */   
/*     */   public Calendar getLastChargeDate() {
/*  50 */     return this.lastChargeDate;
/*     */   }
/*     */   
/*     */   public void setLastChargeDate(Calendar lastChargeDate) {
/*  54 */     this.lastChargeDate = lastChargeDate;
/*     */   }
/*     */   
/*     */   public boolean isPendingRC() {
/*  58 */     return this.pendingRC;
/*     */   }
/*     */   
/*     */   public void setPendingRC(boolean pendingRC) {
/*  62 */     this.pendingRC = pendingRC;
/*     */   }
/*     */   
/*     */   public String getPeriod() {
/*  66 */     return this.period;
/*     */   }
/*     */   
/*     */   public void setPeriod(String period) {
/*  70 */     this.period = period;
/*     */   }
/*     */   
/*     */   public String getPeriodicChargeID() {
/*  74 */     return this.periodicChargeID;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeID(String periodicChargeID) {
/*  78 */     this.periodicChargeID = periodicChargeID;
/*     */   }
/*     */   
/*     */   public String getPostActiveChargeApplied() {
/*  82 */     return this.postActiveChargeApplied;
/*     */   }
/*     */   
/*     */   public void setPostActiveChargeApplied(String postActiveChargeApplied) {
/*  86 */     this.postActiveChargeApplied = postActiveChargeApplied;
/*     */   }
/*     */   
/*     */   public int getRemainingApplications() {
/*  90 */     return this.remainingApplications;
/*     */   }
/*     */   
/*     */   public void setRemainingApplications(int remainingApplications) {
/*  94 */     this.remainingApplications = remainingApplications;
/*     */   }
/*     */   
/*     */   public Calendar getStartDate() {
/*  98 */     return this.startDate;
/*     */   }
/*     */   
/*     */   public void setStartDate(Calendar startDate) {
/* 102 */     this.startDate = startDate;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberPeriodicCharge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */