/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberBase
/*    */   extends SubscriberBasic
/*    */   implements Serializable
/*    */ {
/*    */   protected SubscriberHome subscriberHome;
/*    */   protected SubscriberInfo subscriberInfo;
/*    */   protected SubscriberPB subscriberPhoneBook;
/*    */   
/*    */   public SubscriberHome getSubscriberHome() {
/* 19 */     return this.subscriberHome;
/*    */   }
/*    */   
/*    */   public void setSubscriberHome(SubscriberHome subscriberHome) {
/* 23 */     this.subscriberHome = subscriberHome;
/*    */   }
/*    */   
/*    */   public SubscriberInfo getSubscriberInfo() {
/* 27 */     return this.subscriberInfo;
/*    */   }
/*    */   
/*    */   public void setSubscriberInfo(SubscriberInfo subscriberInfo) {
/* 31 */     this.subscriberInfo = subscriberInfo;
/*    */   }
/*    */   
/*    */   public SubscriberPB getSubscriberPhoneBook() {
/* 35 */     return this.subscriberPhoneBook;
/*    */   }
/*    */   
/*    */   public void setSubscriberPhoneBook(SubscriberPB subscriberPhoneBook) {
/* 39 */     this.subscriberPhoneBook = subscriberPhoneBook;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */