/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccumulatorModify
/*    */   extends AccumulatorBase
/*    */   implements Serializable
/*    */ {
/*    */   protected boolean resetAccumulator;
/*    */   protected String zeroDay;
/*    */   
/*    */   public boolean isResetAccumulator() {
/* 18 */     return this.resetAccumulator;
/*    */   }
/*    */   
/*    */   public void setResetAccumulator(boolean resetAccumulator) {
/* 22 */     this.resetAccumulator = resetAccumulator;
/*    */   }
/*    */   
/*    */   public String getZeroDay() {
/* 26 */     return this.zeroDay;
/*    */   }
/*    */   
/*    */   public void setZeroDay(String zeroDay) {
/* 30 */     this.zeroDay = zeroDay;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\AccumulatorModify.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */