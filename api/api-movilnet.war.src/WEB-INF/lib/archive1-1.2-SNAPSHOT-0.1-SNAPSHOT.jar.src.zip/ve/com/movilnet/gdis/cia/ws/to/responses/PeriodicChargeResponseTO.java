/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.PeriodicChargeResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PeriodicChargeResponseTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected PeriodicChargeResponse periodicChargeResponse;
/*    */   
/*    */   public PeriodicChargeResponse getPeriodicChargeResponse() {
/* 17 */     return this.periodicChargeResponse;
/*    */   }
/*    */   
/*    */   public void setPeriodicChargeResponse(PeriodicChargeResponse periodicChargeResponse) {
/* 21 */     this.periodicChargeResponse = periodicChargeResponse;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\PeriodicChargeResponseTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */