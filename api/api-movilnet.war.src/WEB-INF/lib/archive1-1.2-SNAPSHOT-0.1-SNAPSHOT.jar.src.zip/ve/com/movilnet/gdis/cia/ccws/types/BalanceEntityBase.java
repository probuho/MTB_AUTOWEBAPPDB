/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BalanceEntityBase
/*    */   implements Serializable
/*    */ {
/*    */   protected Calendar accountExpiration;
/*    */   protected double balance;
/*    */   protected String balanceName;
/*    */   protected double nextMaximumSpendingLimit;
/*    */   protected double totalSpendingLimit;
/*    */   
/*    */   public Calendar getAccountExpiration() {
/* 21 */     return this.accountExpiration;
/*    */   }
/*    */   
/*    */   public void setAccountExpiration(Calendar accountExpiration) {
/* 25 */     this.accountExpiration = accountExpiration;
/*    */   }
/*    */   
/*    */   public double getBalance() {
/* 29 */     return this.balance;
/*    */   }
/*    */   
/*    */   public void setBalance(double balance) {
/* 33 */     this.balance = balance;
/*    */   }
/*    */   
/*    */   public String getBalanceName() {
/* 37 */     return this.balanceName;
/*    */   }
/*    */   
/*    */   public void setBalanceName(String balanceName) {
/* 41 */     this.balanceName = balanceName;
/*    */   }
/*    */   
/*    */   public double getNextMaximumSpendingLimit() {
/* 45 */     return this.nextMaximumSpendingLimit;
/*    */   }
/*    */   
/*    */   public void setNextMaximumSpendingLimit(double nextMaximumSpendingLimit) {
/* 49 */     this.nextMaximumSpendingLimit = nextMaximumSpendingLimit;
/*    */   }
/*    */   
/*    */   public double getTotalSpendingLimit() {
/* 53 */     return this.totalSpendingLimit;
/*    */   }
/*    */   
/*    */   public void setTotalSpendingLimit(double totalSpendingLimit) {
/* 57 */     this.totalSpendingLimit = totalSpendingLimit;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\BalanceEntityBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */