/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultGSMTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String cosName;
/*    */   protected String fechaActivacion;
/*    */   protected String generico1;
/*    */   protected String nombreSubscriptor;
/*    */   protected String statusLinea;
/*    */   protected long subscriberId;
/*    */   
/*    */   public String getCosName() {
/* 22 */     return this.cosName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 26 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public String getFechaActivacion() {
/* 30 */     return this.fechaActivacion;
/*    */   }
/*    */   
/*    */   public void setFechaActivacion(String fechaActivacion) {
/* 34 */     this.fechaActivacion = fechaActivacion;
/*    */   }
/*    */   
/*    */   public String getGenerico1() {
/* 38 */     return this.generico1;
/*    */   }
/*    */   
/*    */   public void setGenerico1(String generico1) {
/* 42 */     this.generico1 = generico1;
/*    */   }
/*    */   
/*    */   public String getNombreSubscriptor() {
/* 46 */     return this.nombreSubscriptor;
/*    */   }
/*    */   
/*    */   public void setNombreSubscriptor(String nombreSubscriptor) {
/* 50 */     this.nombreSubscriptor = nombreSubscriptor;
/*    */   }
/*    */   
/*    */   public String getStatusLinea() {
/* 54 */     return this.statusLinea;
/*    */   }
/*    */   
/*    */   public void setStatusLinea(String statusLinea) {
/* 58 */     this.statusLinea = statusLinea;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 62 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 66 */     this.subscriberId = subscriberId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ResultGSMTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */