/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberBasic
/*    */   implements Serializable
/*    */ {
/*    */   protected String identity;
/*    */   protected String subscriberID;
/*    */   
/*    */   public String getIdentity() {
/* 18 */     return this.identity;
/*    */   }
/*    */   
/*    */   public void setIdentity(String identity) {
/* 22 */     this.identity = identity;
/*    */   }
/*    */   
/*    */   public String getSubscriberID() {
/* 26 */     return this.subscriberID;
/*    */   }
/*    */   
/*    */   public void setSubscriberID(String subscriberID) {
/* 30 */     this.subscriberID = subscriberID;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberBasic.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */