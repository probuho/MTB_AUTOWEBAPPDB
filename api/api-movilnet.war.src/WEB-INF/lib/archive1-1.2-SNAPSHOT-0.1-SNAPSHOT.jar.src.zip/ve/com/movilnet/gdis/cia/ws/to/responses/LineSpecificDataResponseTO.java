/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.SubscriberEntity;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.SubscriberHome;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.SubscriberInfo;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.SubscriberPB;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.SubscriberPeriodicCharge;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.ClientProfileTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.DataBalanceTO;
/*    */ 
/*    */ public class LineSpecificDataResponseTO
/*    */   extends ResponseTO implements Serializable {
/*    */   protected ClientProfileTO clientInfo;
/*    */   protected DataBalanceTO[] dataBalanceTO;
/*    */   protected String nextApplyDate;
/*    */   protected String segmento;
/*    */   protected SubscriberEntity subscriberEntity;
/*    */   protected SubscriberHome subscriberHome;
/*    */   protected SubscriberInfo subscriberInfo;
/*    */   protected SubscriberPB subscriberPB;
/*    */   protected SubscriberPeriodicCharge[] subscriberPeriodicCharge;
/*    */   
/*    */   public ClientProfileTO getClientInfo() {
/* 25 */     return this.clientInfo;
/*    */   }
/*    */   
/*    */   public void setClientInfo(ClientProfileTO clientInfo) {
/* 29 */     this.clientInfo = clientInfo;
/*    */   }
/*    */   
/*    */   public DataBalanceTO[] getDataBalanceTO() {
/* 33 */     return this.dataBalanceTO;
/*    */   }
/*    */   
/*    */   public void setDataBalanceTO(DataBalanceTO[] dataBalanceTO) {
/* 37 */     this.dataBalanceTO = dataBalanceTO;
/*    */   }
/*    */   
/*    */   public String getNextApplyDate() {
/* 41 */     return this.nextApplyDate;
/*    */   }
/*    */   
/*    */   public void setNextApplyDate(String nextApplyDate) {
/* 45 */     this.nextApplyDate = nextApplyDate;
/*    */   }
/*    */   
/*    */   public String getSegmento() {
/* 49 */     return this.segmento;
/*    */   }
/*    */   
/*    */   public void setSegmento(String segmento) {
/* 53 */     this.segmento = segmento;
/*    */   }
/*    */   
/*    */   public SubscriberEntity getSubscriberEntity() {
/* 57 */     return this.subscriberEntity;
/*    */   }
/*    */   
/*    */   public void setSubscriberEntity(SubscriberEntity subscriberEntity) {
/* 61 */     this.subscriberEntity = subscriberEntity;
/*    */   }
/*    */   
/*    */   public SubscriberHome getSubscriberHome() {
/* 65 */     return this.subscriberHome;
/*    */   }
/*    */   
/*    */   public void setSubscriberHome(SubscriberHome subscriberHome) {
/* 69 */     this.subscriberHome = subscriberHome;
/*    */   }
/*    */   
/*    */   public SubscriberInfo getSubscriberInfo() {
/* 73 */     return this.subscriberInfo;
/*    */   }
/*    */   
/*    */   public void setSubscriberInfo(SubscriberInfo subscriberInfo) {
/* 77 */     this.subscriberInfo = subscriberInfo;
/*    */   }
/*    */   
/*    */   public SubscriberPB getSubscriberPB() {
/* 81 */     return this.subscriberPB;
/*    */   }
/*    */   
/*    */   public void setSubscriberPB(SubscriberPB subscriberPB) {
/* 85 */     this.subscriberPB = subscriberPB;
/*    */   }
/*    */   
/*    */   public SubscriberPeriodicCharge[] getSubscriberPeriodicCharge() {
/* 89 */     return this.subscriberPeriodicCharge;
/*    */   }
/*    */   
/*    */   public void setSubscriberPeriodicCharge(SubscriberPeriodicCharge[] subscriberPeriodicCharge) {
/* 93 */     this.subscriberPeriodicCharge = subscriberPeriodicCharge;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\LineSpecificDataResponseTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */