/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.ResultTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusLinesSubscriberResponseTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected ResultTO[] numberLinesActive;
/*    */   protected ResultTO[] numberLinesAwaitActivation;
/*    */   protected ResultTO[] numberLinesAwaitFirstRecharge;
/*    */   protected ResultTO[] numberLinesDisabled;
/*    */   protected ResultTO[] numberLinesFraudLockout;
/*    */   protected ResultTO[] numberLinesIdle;
/*    */   protected ResultTO[] numberLinesNotUsedS4;
/*    */   protected ResultTO[] numberLinesRetired;
/*    */   protected ResultTO[] numberLinesSuspended;
/*    */   
/*    */   public ResultTO[] getNumberLinesActive() {
/* 25 */     return this.numberLinesActive;
/*    */   }
/*    */   
/*    */   public void setNumberLinesActive(ResultTO[] numberLinesActive) {
/* 29 */     this.numberLinesActive = numberLinesActive;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesAwaitActivation() {
/* 33 */     return this.numberLinesAwaitActivation;
/*    */   }
/*    */   
/*    */   public void setNumberLinesAwaitActivation(ResultTO[] numberLinesAwaitActivation) {
/* 37 */     this.numberLinesAwaitActivation = numberLinesAwaitActivation;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesAwaitFirstRecharge() {
/* 41 */     return this.numberLinesAwaitFirstRecharge;
/*    */   }
/*    */   
/*    */   public void setNumberLinesAwaitFirstRecharge(ResultTO[] numberLinesAwaitFirstRecharge) {
/* 45 */     this.numberLinesAwaitFirstRecharge = numberLinesAwaitFirstRecharge;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesDisabled() {
/* 49 */     return this.numberLinesDisabled;
/*    */   }
/*    */   
/*    */   public void setNumberLinesDisabled(ResultTO[] numberLinesDisabled) {
/* 53 */     this.numberLinesDisabled = numberLinesDisabled;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesFraudLockout() {
/* 57 */     return this.numberLinesFraudLockout;
/*    */   }
/*    */   
/*    */   public void setNumberLinesFraudLockout(ResultTO[] numberLinesFraudLockout) {
/* 61 */     this.numberLinesFraudLockout = numberLinesFraudLockout;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesIdle() {
/* 65 */     return this.numberLinesIdle;
/*    */   }
/*    */   
/*    */   public void setNumberLinesIdle(ResultTO[] numberLinesIdle) {
/* 69 */     this.numberLinesIdle = numberLinesIdle;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesNotUsedS4() {
/* 73 */     return this.numberLinesNotUsedS4;
/*    */   }
/*    */   
/*    */   public void setNumberLinesNotUsedS4(ResultTO[] numberLinesNotUsedS4) {
/* 77 */     this.numberLinesNotUsedS4 = numberLinesNotUsedS4;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesRetired() {
/* 81 */     return this.numberLinesRetired;
/*    */   }
/*    */   
/*    */   public void setNumberLinesRetired(ResultTO[] numberLinesRetired) {
/* 85 */     this.numberLinesRetired = numberLinesRetired;
/*    */   }
/*    */   
/*    */   public ResultTO[] getNumberLinesSuspended() {
/* 89 */     return this.numberLinesSuspended;
/*    */   }
/*    */   
/*    */   public void setNumberLinesSuspended(ResultTO[] numberLinesSuspended) {
/* 93 */     this.numberLinesSuspended = numberLinesSuspended;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\StatusLinesSubscriberResponseTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */