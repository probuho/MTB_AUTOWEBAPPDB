/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberInfoExt
/*    */   implements Serializable
/*    */ {
/*    */   protected Long IDENTITY_ID;
/*    */   protected String SUBSCRIBER_ID;
/*    */   
/*    */   public Long getIDENTITY_ID() {
/* 18 */     return this.IDENTITY_ID;
/*    */   }
/*    */   
/*    */   public void setIDENTITY_ID(Long IDENTITY_ID) {
/* 22 */     this.IDENTITY_ID = IDENTITY_ID;
/*    */   }
/*    */   
/*    */   public String getSUBSCRIBER_ID() {
/* 26 */     return this.SUBSCRIBER_ID;
/*    */   }
/*    */   
/*    */   public void setSUBSCRIBER_ID(String SUBSCRIBER_ID) {
/* 30 */     this.SUBSCRIBER_ID = SUBSCRIBER_ID;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberInfoExt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */