/*     */ package ve.com.movilnet.gdis.cia.ccws.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberRetrieveLite
/*     */   implements Serializable
/*     */ {
/*     */   protected String COS;
/*     */   protected String SP;
/*     */   protected double balance;
/*     */   protected String balance_Name;
/*     */   protected Calendar date_Active;
/*     */   protected Calendar expire_Date;
/*     */   protected String preferredNumber;
/*     */   protected Calendar preferredNumberDate;
/*     */   protected String previousPreferredNumber;
/*     */   protected String state;
/*     */   protected String state_Prev;
/*     */   protected String subscriber_ID;
/*     */   
/*     */   public String getCOS() {
/*  28 */     return this.COS;
/*     */   }
/*     */   
/*     */   public void setCOS(String COS) {
/*  32 */     this.COS = COS;
/*     */   }
/*     */   
/*     */   public String getSP() {
/*  36 */     return this.SP;
/*     */   }
/*     */   
/*     */   public void setSP(String SP) {
/*  40 */     this.SP = SP;
/*     */   }
/*     */   
/*     */   public double getBalance() {
/*  44 */     return this.balance;
/*     */   }
/*     */   
/*     */   public void setBalance(double balance) {
/*  48 */     this.balance = balance;
/*     */   }
/*     */   
/*     */   public String getBalance_Name() {
/*  52 */     return this.balance_Name;
/*     */   }
/*     */   
/*     */   public void setBalance_Name(String balance_Name) {
/*  56 */     this.balance_Name = balance_Name;
/*     */   }
/*     */   
/*     */   public Calendar getDate_Active() {
/*  60 */     return this.date_Active;
/*     */   }
/*     */   
/*     */   public void setDate_Active(Calendar date_Active) {
/*  64 */     this.date_Active = date_Active;
/*     */   }
/*     */   
/*     */   public Calendar getExpire_Date() {
/*  68 */     return this.expire_Date;
/*     */   }
/*     */   
/*     */   public void setExpire_Date(Calendar expire_Date) {
/*  72 */     this.expire_Date = expire_Date;
/*     */   }
/*     */   
/*     */   public String getPreferredNumber() {
/*  76 */     return this.preferredNumber;
/*     */   }
/*     */   
/*     */   public void setPreferredNumber(String preferredNumber) {
/*  80 */     this.preferredNumber = preferredNumber;
/*     */   }
/*     */   
/*     */   public Calendar getPreferredNumberDate() {
/*  84 */     return this.preferredNumberDate;
/*     */   }
/*     */   
/*     */   public void setPreferredNumberDate(Calendar preferredNumberDate) {
/*  88 */     this.preferredNumberDate = preferredNumberDate;
/*     */   }
/*     */   
/*     */   public String getPreviousPreferredNumber() {
/*  92 */     return this.previousPreferredNumber;
/*     */   }
/*     */   
/*     */   public void setPreviousPreferredNumber(String previousPreferredNumber) {
/*  96 */     this.previousPreferredNumber = previousPreferredNumber;
/*     */   }
/*     */   
/*     */   public String getState() {
/* 100 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setState(String state) {
/* 104 */     this.state = state;
/*     */   }
/*     */   
/*     */   public String getState_Prev() {
/* 108 */     return this.state_Prev;
/*     */   }
/*     */   
/*     */   public void setState_Prev(String state_Prev) {
/* 112 */     this.state_Prev = state_Prev;
/*     */   }
/*     */   
/*     */   public String getSubscriber_ID() {
/* 116 */     return this.subscriber_ID;
/*     */   }
/*     */   
/*     */   public void setSubscriber_ID(String subscriber_ID) {
/* 120 */     this.subscriber_ID = subscriber_ID;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberRetrieveLite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */