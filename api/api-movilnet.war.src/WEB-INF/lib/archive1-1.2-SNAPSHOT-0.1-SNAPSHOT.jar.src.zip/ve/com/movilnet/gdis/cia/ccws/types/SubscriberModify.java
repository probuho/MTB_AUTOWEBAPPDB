/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberModify
/*    */   extends SubscriberBase
/*    */   implements Serializable
/*    */ {
/*    */   protected boolean deleteSubscriberPeriodicCharges;
/*    */   protected SubscriberPeriodicCharge[] periodicCharges;
/*    */   protected SubscriberPPS subscriber;
/*    */   
/*    */   public boolean isDeleteSubscriberPeriodicCharges() {
/* 19 */     return this.deleteSubscriberPeriodicCharges;
/*    */   }
/*    */   
/*    */   public void setDeleteSubscriberPeriodicCharges(boolean deleteSubscriberPeriodicCharges) {
/* 23 */     this.deleteSubscriberPeriodicCharges = deleteSubscriberPeriodicCharges;
/*    */   }
/*    */   
/*    */   public SubscriberPeriodicCharge[] getPeriodicCharges() {
/* 27 */     return this.periodicCharges;
/*    */   }
/*    */   
/*    */   public void setPeriodicCharges(SubscriberPeriodicCharge[] periodicCharges) {
/* 31 */     this.periodicCharges = periodicCharges;
/*    */   }
/*    */   
/*    */   public SubscriberPPS getSubscriber() {
/* 35 */     return this.subscriber;
/*    */   }
/*    */   
/*    */   public void setSubscriber(SubscriberPPS subscriber) {
/* 39 */     this.subscriber = subscriber;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberModify.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */