/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiciosSuscritosTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineSpecificDataResponseTO2
/*     */   extends LineSpecificDataResponseTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String campo1;
/*     */   protected String campo10;
/*     */   protected String campo2;
/*     */   protected String campo3;
/*     */   protected String campo4;
/*     */   protected String campo5;
/*     */   protected String campo6;
/*     */   protected String campo7;
/*     */   protected String campo8;
/*     */   protected String campo9;
/*     */   protected String razonSuspension;
/*     */   protected ServiciosSuscritosTO[] serviciosSuscritos;
/*     */   protected String tipoEquipo;
/*     */   protected String tipoPlan;
/*     */   protected String tipoSimCard;
/*     */   
/*     */   public String getCampo1() {
/*  31 */     return this.campo1;
/*     */   }
/*     */   
/*     */   public void setCampo1(String campo1) {
/*  35 */     this.campo1 = campo1;
/*     */   }
/*     */   
/*     */   public String getCampo10() {
/*  39 */     return this.campo10;
/*     */   }
/*     */   
/*     */   public void setCampo10(String campo10) {
/*  43 */     this.campo10 = campo10;
/*     */   }
/*     */   
/*     */   public String getCampo2() {
/*  47 */     return this.campo2;
/*     */   }
/*     */   
/*     */   public void setCampo2(String campo2) {
/*  51 */     this.campo2 = campo2;
/*     */   }
/*     */   
/*     */   public String getCampo3() {
/*  55 */     return this.campo3;
/*     */   }
/*     */   
/*     */   public void setCampo3(String campo3) {
/*  59 */     this.campo3 = campo3;
/*     */   }
/*     */   
/*     */   public String getCampo4() {
/*  63 */     return this.campo4;
/*     */   }
/*     */   
/*     */   public void setCampo4(String campo4) {
/*  67 */     this.campo4 = campo4;
/*     */   }
/*     */   
/*     */   public String getCampo5() {
/*  71 */     return this.campo5;
/*     */   }
/*     */   
/*     */   public void setCampo5(String campo5) {
/*  75 */     this.campo5 = campo5;
/*     */   }
/*     */   
/*     */   public String getCampo6() {
/*  79 */     return this.campo6;
/*     */   }
/*     */   
/*     */   public void setCampo6(String campo6) {
/*  83 */     this.campo6 = campo6;
/*     */   }
/*     */   
/*     */   public String getCampo7() {
/*  87 */     return this.campo7;
/*     */   }
/*     */   
/*     */   public void setCampo7(String campo7) {
/*  91 */     this.campo7 = campo7;
/*     */   }
/*     */   
/*     */   public String getCampo8() {
/*  95 */     return this.campo8;
/*     */   }
/*     */   
/*     */   public void setCampo8(String campo8) {
/*  99 */     this.campo8 = campo8;
/*     */   }
/*     */   
/*     */   public String getCampo9() {
/* 103 */     return this.campo9;
/*     */   }
/*     */   
/*     */   public void setCampo9(String campo9) {
/* 107 */     this.campo9 = campo9;
/*     */   }
/*     */   
/*     */   public String getRazonSuspension() {
/* 111 */     return this.razonSuspension;
/*     */   }
/*     */   
/*     */   public void setRazonSuspension(String razonSuspension) {
/* 115 */     this.razonSuspension = razonSuspension;
/*     */   }
/*     */   
/*     */   public ServiciosSuscritosTO[] getServiciosSuscritos() {
/* 119 */     return this.serviciosSuscritos;
/*     */   }
/*     */   
/*     */   public void setServiciosSuscritos(ServiciosSuscritosTO[] serviciosSuscritos) {
/* 123 */     this.serviciosSuscritos = serviciosSuscritos;
/*     */   }
/*     */   
/*     */   public String getTipoEquipo() {
/* 127 */     return this.tipoEquipo;
/*     */   }
/*     */   
/*     */   public void setTipoEquipo(String tipoEquipo) {
/* 131 */     this.tipoEquipo = tipoEquipo;
/*     */   }
/*     */   
/*     */   public String getTipoPlan() {
/* 135 */     return this.tipoPlan;
/*     */   }
/*     */   
/*     */   public void setTipoPlan(String tipoPlan) {
/* 139 */     this.tipoPlan = tipoPlan;
/*     */   }
/*     */   
/*     */   public String getTipoSimCard() {
/* 143 */     return this.tipoSimCard;
/*     */   }
/*     */   
/*     */   public void setTipoSimCard(String tipoSimCard) {
/* 147 */     this.tipoSimCard = tipoSimCard;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\LineSpecificDataResponseTO2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */