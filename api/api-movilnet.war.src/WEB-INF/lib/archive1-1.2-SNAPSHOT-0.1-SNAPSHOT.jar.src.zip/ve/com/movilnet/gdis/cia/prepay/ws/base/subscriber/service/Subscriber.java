/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.subscriber.service;
/*    */ 
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.CreatePeriodicChargeRequestTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.CreateSubscriberRequestTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.DeletePeriodicChargeRequestTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ElectronicSerialRequestTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ModifySubscriberRequestTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.RetrieveLinesbyCIGSMRequestTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.StringRequestTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.StringRequestTO2;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.LineBasicDataResponseTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.LineSpecificDataResponseTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.LineSpecificDataResponseTO2;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.PeriodicChargeResponseTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.RetrieveLinesResponseGSMTO;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.StatusLinesSubscriberResponseTO;
/*    */ 
/*    */ public class Subscriber {
/*    */   public PeriodicChargeResponseTO createPeriodicCharge(CreatePeriodicChargeRequestTO createPeriodicChargeRequest) {
/* 21 */     return null;
/*    */   }
/*    */   
/*    */   public BooleanResponseTO createSubscriber(CreateSubscriberRequestTO createSubscriberRequest) {
/* 25 */     return null;
/*    */   }
/*    */   
/*    */   public PeriodicChargeResponseTO deletePeriodicCharge(DeletePeriodicChargeRequestTO deletePeriodicChargeRequest) {
/* 29 */     return null;
/*    */   }
/*    */   
/*    */   public BooleanResponseTO deleteSubscriber(StringRequestTO stringRequest) {
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public BooleanResponseTO modifySubscriber(ModifySubscriberRequestTO modifySubscriberRequest) {
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   public LineBasicDataResponseTO retrieveLineBasicData(StringRequestTO stringRequest) {
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   public LineSpecificDataResponseTO retrieveLineSpecificData(StringRequestTO stringRequest) {
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   public LineSpecificDataResponseTO2 retrieveLineSpecificData2(StringRequestTO2 stringRequest) {
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public RetrieveLinesResponseGSMTO retrieveLinesByCIGSM(RetrieveLinesbyCIGSMRequestTO retrieveLinesbyCIRequestTO) {
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   public StatusLinesSubscriberResponseTO retrieveStatusLinesSubscriber(StringRequestTO stringRequest) {
/* 57 */     return null;
/*    */   }
/*    */   
/*    */   public StatusLinesSubscriberResponseTO retrieveStatusLinesSubscriberbyESN(ElectronicSerialRequestTO stringRequest) {
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   public StatusLinesSubscriberResponseTO retrieveStatusLinesSubscriberbySIM(StringRequestTO stringRequest) {
/* 65 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\subscriber\service\Subscriber.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */