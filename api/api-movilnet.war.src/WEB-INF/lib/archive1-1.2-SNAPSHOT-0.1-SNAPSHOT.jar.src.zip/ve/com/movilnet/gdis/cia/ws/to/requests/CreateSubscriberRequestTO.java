/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ccws.types.SubscriberCreate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateSubscriberRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected SubscriberCreate createSubscriber;
/*    */   protected String nodo;
/*    */   
/*    */   public SubscriberCreate getCreateSubscriber() {
/* 18 */     return this.createSubscriber;
/*    */   }
/*    */   
/*    */   public void setCreateSubscriber(SubscriberCreate createSubscriber) {
/* 22 */     this.createSubscriber = createSubscriber;
/*    */   }
/*    */   
/*    */   public String getNodo() {
/* 26 */     return this.nodo;
/*    */   }
/*    */   
/*    */   public void setNodo(String nodo) {
/* 30 */     this.nodo = nodo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\CreateSubscriberRequestTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */