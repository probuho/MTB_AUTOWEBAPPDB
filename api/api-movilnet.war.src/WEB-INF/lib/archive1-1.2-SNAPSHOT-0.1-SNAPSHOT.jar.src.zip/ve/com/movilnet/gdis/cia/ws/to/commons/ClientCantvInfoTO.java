/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientCantvInfoTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String classBusinessUnit;
/*    */   protected String flagNumberPrivate;
/*    */   protected String subClassBusinessUnit;
/*    */   
/*    */   public String getClassBusinessUnit() {
/* 19 */     return this.classBusinessUnit;
/*    */   }
/*    */   
/*    */   public void setClassBusinessUnit(String classBusinessUnit) {
/* 23 */     this.classBusinessUnit = classBusinessUnit;
/*    */   }
/*    */   
/*    */   public String getFlagNumberPrivate() {
/* 27 */     return this.flagNumberPrivate;
/*    */   }
/*    */   
/*    */   public void setFlagNumberPrivate(String flagNumberPrivate) {
/* 31 */     this.flagNumberPrivate = flagNumberPrivate;
/*    */   }
/*    */   
/*    */   public String getSubClassBusinessUnit() {
/* 35 */     return this.subClassBusinessUnit;
/*    */   }
/*    */   
/*    */   public void setSubClassBusinessUnit(String subClassBusinessUnit) {
/* 39 */     this.subClassBusinessUnit = subClassBusinessUnit;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ClientCantvInfoTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */