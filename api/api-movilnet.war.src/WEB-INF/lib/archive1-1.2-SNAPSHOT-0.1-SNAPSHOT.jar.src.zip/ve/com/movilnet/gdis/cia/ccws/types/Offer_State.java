/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Offer_State
/*    */   implements Serializable
/*    */ {
/*    */   protected String value;
/*    */   
/*    */   public String getValue() {
/* 17 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 21 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\Offer_State.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */