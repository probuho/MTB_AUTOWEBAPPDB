/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OfferBase
/*    */   implements Serializable
/*    */ {
/*    */   protected String name;
/*    */   protected Calendar serviceEnd;
/*    */   protected Calendar serviceStart;
/*    */   
/*    */   public String getName() {
/* 19 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 23 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Calendar getServiceEnd() {
/* 27 */     return this.serviceEnd;
/*    */   }
/*    */   
/*    */   public void setServiceEnd(Calendar serviceEnd) {
/* 31 */     this.serviceEnd = serviceEnd;
/*    */   }
/*    */   
/*    */   public Calendar getServiceStart() {
/* 35 */     return this.serviceStart;
/*    */   }
/*    */   
/*    */   public void setServiceStart(Calendar serviceStart) {
/* 39 */     this.serviceStart = serviceStart;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\OfferBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */