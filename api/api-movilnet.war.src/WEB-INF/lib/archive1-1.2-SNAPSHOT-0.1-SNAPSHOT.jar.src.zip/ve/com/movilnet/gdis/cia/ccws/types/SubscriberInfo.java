/*     */ package ve.com.movilnet.gdis.cia.ccws.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberInfo
/*     */   implements Serializable
/*     */ {
/*     */   protected String ZIP;
/*     */   protected String address1;
/*     */   protected String address2;
/*     */   protected String address3;
/*     */   protected String address4;
/*     */   protected SubscriberInfoExt extensionData;
/*     */   protected SOAPElement extensionDataRaw;
/*     */   protected String firstName;
/*     */   protected String lastName;
/*     */   protected String middleInitial;
/*     */   
/*     */   public String getZIP() {
/*  26 */     return this.ZIP;
/*     */   }
/*     */   
/*     */   public void setZIP(String ZIP) {
/*  30 */     this.ZIP = ZIP;
/*     */   }
/*     */   
/*     */   public String getAddress1() {
/*  34 */     return this.address1;
/*     */   }
/*     */   
/*     */   public void setAddress1(String address1) {
/*  38 */     this.address1 = address1;
/*     */   }
/*     */   
/*     */   public String getAddress2() {
/*  42 */     return this.address2;
/*     */   }
/*     */   
/*     */   public void setAddress2(String address2) {
/*  46 */     this.address2 = address2;
/*     */   }
/*     */   
/*     */   public String getAddress3() {
/*  50 */     return this.address3;
/*     */   }
/*     */   
/*     */   public void setAddress3(String address3) {
/*  54 */     this.address3 = address3;
/*     */   }
/*     */   
/*     */   public String getAddress4() {
/*  58 */     return this.address4;
/*     */   }
/*     */   
/*     */   public void setAddress4(String address4) {
/*  62 */     this.address4 = address4;
/*     */   }
/*     */   
/*     */   public SubscriberInfoExt getExtensionData() {
/*  66 */     return this.extensionData;
/*     */   }
/*     */   
/*     */   public void setExtensionData(SubscriberInfoExt extensionData) {
/*  70 */     this.extensionData = extensionData;
/*     */   }
/*     */   
/*     */   public SOAPElement getExtensionDataRaw() {
/*  74 */     return this.extensionDataRaw;
/*     */   }
/*     */   
/*     */   public void setExtensionDataRaw(SOAPElement extensionDataRaw) {
/*  78 */     this.extensionDataRaw = extensionDataRaw;
/*     */   }
/*     */   
/*     */   public String getFirstName() {
/*  82 */     return this.firstName;
/*     */   }
/*     */   
/*     */   public void setFirstName(String firstName) {
/*  86 */     this.firstName = firstName;
/*     */   }
/*     */   
/*     */   public String getLastName() {
/*  90 */     return this.lastName;
/*     */   }
/*     */   
/*     */   public void setLastName(String lastName) {
/*  94 */     this.lastName = lastName;
/*     */   }
/*     */   
/*     */   public String getMiddleInitial() {
/*  98 */     return this.middleInitial;
/*     */   }
/*     */   
/*     */   public void setMiddleInitial(String middleInitial) {
/* 102 */     this.middleInitial = middleInitial;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\SubscriberInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */