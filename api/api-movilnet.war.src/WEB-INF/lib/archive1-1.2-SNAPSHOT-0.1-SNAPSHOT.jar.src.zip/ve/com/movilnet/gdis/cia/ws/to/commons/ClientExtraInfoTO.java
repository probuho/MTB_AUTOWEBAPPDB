/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientExtraInfoTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String authorizeFirstName;
/*    */   protected String authorizeLastName;
/*    */   protected String contactFirstName;
/*    */   protected String contactLastName;
/*    */   protected String contactPhoneNumber;
/*    */   
/*    */   public String getAuthorizeFirstName() {
/* 21 */     return this.authorizeFirstName;
/*    */   }
/*    */   
/*    */   public void setAuthorizeFirstName(String authorizeFirstName) {
/* 25 */     this.authorizeFirstName = authorizeFirstName;
/*    */   }
/*    */   
/*    */   public String getAuthorizeLastName() {
/* 29 */     return this.authorizeLastName;
/*    */   }
/*    */   
/*    */   public void setAuthorizeLastName(String authorizeLastName) {
/* 33 */     this.authorizeLastName = authorizeLastName;
/*    */   }
/*    */   
/*    */   public String getContactFirstName() {
/* 37 */     return this.contactFirstName;
/*    */   }
/*    */   
/*    */   public void setContactFirstName(String contactFirstName) {
/* 41 */     this.contactFirstName = contactFirstName;
/*    */   }
/*    */   
/*    */   public String getContactLastName() {
/* 45 */     return this.contactLastName;
/*    */   }
/*    */   
/*    */   public void setContactLastName(String contactLastName) {
/* 49 */     this.contactLastName = contactLastName;
/*    */   }
/*    */   
/*    */   public String getContactPhoneNumber() {
/* 53 */     return this.contactPhoneNumber;
/*    */   }
/*    */   
/*    */   public void setContactPhoneNumber(String contactPhoneNumber) {
/* 57 */     this.contactPhoneNumber = contactPhoneNumber;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ClientExtraInfoTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */