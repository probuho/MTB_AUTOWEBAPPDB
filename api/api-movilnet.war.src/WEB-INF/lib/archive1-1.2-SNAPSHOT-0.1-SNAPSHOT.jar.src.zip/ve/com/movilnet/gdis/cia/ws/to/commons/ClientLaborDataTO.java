/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientLaborDataTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String company;
/*    */   protected String hireDate;
/*    */   protected String jobPosition;
/*    */   protected String profession;
/*    */   protected String workPhoneNumber;
/*    */   protected String workPhoneNumberExt;
/*    */   
/*    */   public String getCompany() {
/* 22 */     return this.company;
/*    */   }
/*    */   
/*    */   public void setCompany(String company) {
/* 26 */     this.company = company;
/*    */   }
/*    */   
/*    */   public String getHireDate() {
/* 30 */     return this.hireDate;
/*    */   }
/*    */   
/*    */   public void setHireDate(String hireDate) {
/* 34 */     this.hireDate = hireDate;
/*    */   }
/*    */   
/*    */   public String getJobPosition() {
/* 38 */     return this.jobPosition;
/*    */   }
/*    */   
/*    */   public void setJobPosition(String jobPosition) {
/* 42 */     this.jobPosition = jobPosition;
/*    */   }
/*    */   
/*    */   public String getProfession() {
/* 46 */     return this.profession;
/*    */   }
/*    */   
/*    */   public void setProfession(String profession) {
/* 50 */     this.profession = profession;
/*    */   }
/*    */   
/*    */   public String getWorkPhoneNumber() {
/* 54 */     return this.workPhoneNumber;
/*    */   }
/*    */   
/*    */   public void setWorkPhoneNumber(String workPhoneNumber) {
/* 58 */     this.workPhoneNumber = workPhoneNumber;
/*    */   }
/*    */   
/*    */   public String getWorkPhoneNumberExt() {
/* 62 */     return this.workPhoneNumberExt;
/*    */   }
/*    */   
/*    */   public void setWorkPhoneNumberExt(String workPhoneNumberExt) {
/* 66 */     this.workPhoneNumberExt = workPhoneNumberExt;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ClientLaborDataTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */