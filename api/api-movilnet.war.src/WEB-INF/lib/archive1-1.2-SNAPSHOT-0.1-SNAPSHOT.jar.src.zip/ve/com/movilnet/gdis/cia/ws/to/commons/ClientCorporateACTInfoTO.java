/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientCorporateACTInfoTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String accountNumber;
/*     */   protected String accountRIF;
/*     */   protected String accountSubType;
/*     */   protected String accountType;
/*     */   protected String ciRepresentante;
/*     */   protected String contractNumber;
/*     */   protected String lastNameRepres;
/*     */   protected String nameRepresentante;
/*     */   protected String orderNumber;
/*     */   protected String ssntypeRepresentante;
/*     */   protected String telfRepresentante;
/*     */   
/*     */   public String getAccountNumber() {
/*  27 */     return this.accountNumber;
/*     */   }
/*     */   
/*     */   public void setAccountNumber(String accountNumber) {
/*  31 */     this.accountNumber = accountNumber;
/*     */   }
/*     */   
/*     */   public String getAccountRIF() {
/*  35 */     return this.accountRIF;
/*     */   }
/*     */   
/*     */   public void setAccountRIF(String accountRIF) {
/*  39 */     this.accountRIF = accountRIF;
/*     */   }
/*     */   
/*     */   public String getAccountSubType() {
/*  43 */     return this.accountSubType;
/*     */   }
/*     */   
/*     */   public void setAccountSubType(String accountSubType) {
/*  47 */     this.accountSubType = accountSubType;
/*     */   }
/*     */   
/*     */   public String getAccountType() {
/*  51 */     return this.accountType;
/*     */   }
/*     */   
/*     */   public void setAccountType(String accountType) {
/*  55 */     this.accountType = accountType;
/*     */   }
/*     */   
/*     */   public String getCiRepresentante() {
/*  59 */     return this.ciRepresentante;
/*     */   }
/*     */   
/*     */   public void setCiRepresentante(String ciRepresentante) {
/*  63 */     this.ciRepresentante = ciRepresentante;
/*     */   }
/*     */   
/*     */   public String getContractNumber() {
/*  67 */     return this.contractNumber;
/*     */   }
/*     */   
/*     */   public void setContractNumber(String contractNumber) {
/*  71 */     this.contractNumber = contractNumber;
/*     */   }
/*     */   
/*     */   public String getLastNameRepres() {
/*  75 */     return this.lastNameRepres;
/*     */   }
/*     */   
/*     */   public void setLastNameRepres(String lastNameRepres) {
/*  79 */     this.lastNameRepres = lastNameRepres;
/*     */   }
/*     */   
/*     */   public String getNameRepresentante() {
/*  83 */     return this.nameRepresentante;
/*     */   }
/*     */   
/*     */   public void setNameRepresentante(String nameRepresentante) {
/*  87 */     this.nameRepresentante = nameRepresentante;
/*     */   }
/*     */   
/*     */   public String getOrderNumber() {
/*  91 */     return this.orderNumber;
/*     */   }
/*     */   
/*     */   public void setOrderNumber(String orderNumber) {
/*  95 */     this.orderNumber = orderNumber;
/*     */   }
/*     */   
/*     */   public String getSsntypeRepresentante() {
/*  99 */     return this.ssntypeRepresentante;
/*     */   }
/*     */   
/*     */   public void setSsntypeRepresentante(String ssntypeRepresentante) {
/* 103 */     this.ssntypeRepresentante = ssntypeRepresentante;
/*     */   }
/*     */   
/*     */   public String getTelfRepresentante() {
/* 107 */     return this.telfRepresentante;
/*     */   }
/*     */   
/*     */   public void setTelfRepresentante(String telfRepresentante) {
/* 111 */     this.telfRepresentante = telfRepresentante;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ClientCorporateACTInfoTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */