/*    */ package ve.com.movilnet.gdis.cia.ccws.types;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreatePeriodicChargeRequest
/*    */   implements Serializable
/*    */ {
/*    */   protected int applyDay;
/*    */   protected String chargeId;
/*    */   protected Calendar endDate;
/*    */   protected String identity;
/*    */   protected int numberOfApplications;
/*    */   protected Calendar startDate;
/*    */   protected String subscriberId;
/*    */   
/*    */   public int getApplyDay() {
/* 23 */     return this.applyDay;
/*    */   }
/*    */   
/*    */   public void setApplyDay(int applyDay) {
/* 27 */     this.applyDay = applyDay;
/*    */   }
/*    */   
/*    */   public String getChargeId() {
/* 31 */     return this.chargeId;
/*    */   }
/*    */   
/*    */   public void setChargeId(String chargeId) {
/* 35 */     this.chargeId = chargeId;
/*    */   }
/*    */   
/*    */   public Calendar getEndDate() {
/* 39 */     return this.endDate;
/*    */   }
/*    */   
/*    */   public void setEndDate(Calendar endDate) {
/* 43 */     this.endDate = endDate;
/*    */   }
/*    */   
/*    */   public String getIdentity() {
/* 47 */     return this.identity;
/*    */   }
/*    */   
/*    */   public void setIdentity(String identity) {
/* 51 */     this.identity = identity;
/*    */   }
/*    */   
/*    */   public int getNumberOfApplications() {
/* 55 */     return this.numberOfApplications;
/*    */   }
/*    */   
/*    */   public void setNumberOfApplications(int numberOfApplications) {
/* 59 */     this.numberOfApplications = numberOfApplications;
/*    */   }
/*    */   
/*    */   public Calendar getStartDate() {
/* 63 */     return this.startDate;
/*    */   }
/*    */   
/*    */   public void setStartDate(Calendar startDate) {
/* 67 */     this.startDate = startDate;
/*    */   }
/*    */   
/*    */   public String getSubscriberId() {
/* 71 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(String subscriberId) {
/* 75 */     this.subscriberId = subscriberId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ccws\types\CreatePeriodicChargeRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */