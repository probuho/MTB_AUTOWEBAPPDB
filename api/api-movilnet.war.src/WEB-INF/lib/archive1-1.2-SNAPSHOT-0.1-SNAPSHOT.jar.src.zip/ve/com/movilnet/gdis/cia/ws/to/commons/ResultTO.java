/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String fechaActivacion;
/*    */   protected String nombreSubscriptor;
/*    */   protected int statusLinea;
/*    */   protected long subscriberId;
/*    */   
/*    */   public String getFechaActivacion() {
/* 20 */     return this.fechaActivacion;
/*    */   }
/*    */   
/*    */   public void setFechaActivacion(String fechaActivacion) {
/* 24 */     this.fechaActivacion = fechaActivacion;
/*    */   }
/*    */   
/*    */   public String getNombreSubscriptor() {
/* 28 */     return this.nombreSubscriptor;
/*    */   }
/*    */   
/*    */   public void setNombreSubscriptor(String nombreSubscriptor) {
/* 32 */     this.nombreSubscriptor = nombreSubscriptor;
/*    */   }
/*    */   
/*    */   public int getStatusLinea() {
/* 36 */     return this.statusLinea;
/*    */   }
/*    */   
/*    */   public void setStatusLinea(int statusLinea) {
/* 40 */     this.statusLinea = statusLinea;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 44 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 48 */     this.subscriberId = subscriberId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\archive1-1.2-SNAPSHOT-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ResultTO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */