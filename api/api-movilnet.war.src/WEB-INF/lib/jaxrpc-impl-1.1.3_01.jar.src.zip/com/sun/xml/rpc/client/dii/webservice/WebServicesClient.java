/*    */ package com.sun.xml.rpc.client.dii.webservice;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServicesClient
/*    */ {
/* 36 */   private List webServices = new ArrayList();
/*    */ 
/*    */   
/*    */   public List getWebServices() {
/* 40 */     return this.webServices;
/*    */   }
/*    */   
/*    */   public void setWebServices(List webservices) {
/* 44 */     this.webServices = webservices;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\client\dii\webservice\WebServicesClient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */