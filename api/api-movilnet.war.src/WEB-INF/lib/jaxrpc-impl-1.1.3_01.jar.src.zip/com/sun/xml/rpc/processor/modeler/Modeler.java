package com.sun.xml.rpc.processor.modeler;

import com.sun.xml.rpc.processor.model.Model;

public interface Modeler {
  Model buildModel();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\modeler\Modeler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */