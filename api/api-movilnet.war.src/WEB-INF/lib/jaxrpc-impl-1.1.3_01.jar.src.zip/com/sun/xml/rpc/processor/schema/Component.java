package com.sun.xml.rpc.processor.schema;

public abstract class Component {
  public abstract void accept(ComponentVisitor paramComponentVisitor) throws Exception;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\schema\Component.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */