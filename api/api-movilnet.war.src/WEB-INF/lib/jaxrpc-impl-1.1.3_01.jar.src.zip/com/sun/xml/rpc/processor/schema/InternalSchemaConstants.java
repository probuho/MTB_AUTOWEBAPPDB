package com.sun.xml.rpc.processor.schema;

import com.sun.xml.rpc.wsdl.document.schema.SchemaConstants;

public interface InternalSchemaConstants extends SchemaConstants {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\schema\InternalSchemaConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */