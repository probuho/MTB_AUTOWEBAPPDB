package com.sun.xml.rpc.processor.generator.nodes;

interface QNameScopeTypes {
  public static final String COMPLEX_TYPE = "complexType";
  
  public static final String ELEMENT = "element";
  
  public static final String SIMPLE_TYPE = "simpleType";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\generator\nodes\QNameScopeTypes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */