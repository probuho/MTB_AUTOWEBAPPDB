/*    */ package com.sun.xml.rpc.processor.model.exporter;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Constants
/*    */ {
/*    */   public static final String NS_MODEL = "http://java.sun.com/xml/ns/jax-rpc/ri/model";
/* 38 */   public static final QName QNAME_MODEL = new QName("http://java.sun.com/xml/ns/jax-rpc/ri/model", "model");
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\model\exporter\Constants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */