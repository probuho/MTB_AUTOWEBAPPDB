package com.sun.xml.rpc.processor.modeler.j2ee.xml;

public class ejbRefNameType extends jndiNameType {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\modeler\j2ee\xml\ejbRefNameType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */