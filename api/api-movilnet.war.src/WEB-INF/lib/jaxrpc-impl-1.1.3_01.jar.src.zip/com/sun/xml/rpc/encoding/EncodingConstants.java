package com.sun.xml.rpc.encoding;

public class EncodingConstants {
  public static final String JAX_RPC_RI_MECHANISM = "http://java.sun.com/jax-rpc-ri/1.0/streaming/";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\EncodingConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */