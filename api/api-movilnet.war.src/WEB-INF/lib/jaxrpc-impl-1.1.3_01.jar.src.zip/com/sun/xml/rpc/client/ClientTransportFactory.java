package com.sun.xml.rpc.client;

import com.sun.xml.rpc.spi.runtime.ClientTransportFactory;

public interface ClientTransportFactory extends ClientTransportFactory {
  ClientTransport create();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\client\ClientTransportFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */