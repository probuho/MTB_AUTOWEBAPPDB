/*    */ package com.sun.xml.rpc.processor.schema;
/*    */ 
/*    */ import com.sun.xml.rpc.wsdl.framework.AbstractDocument;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalSchemaBuilder11
/*    */   extends InternalSchemaBuilderBase
/*    */ {
/*    */   public InternalSchemaBuilder11(AbstractDocument document, Properties options) {
/* 47 */     super(document, options);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\schema\InternalSchemaBuilder11.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */