package com.sun.xml.rpc.client;

import com.sun.xml.rpc.soap.message.SOAPMessageContext;

public interface ClientTransport {
  void invoke(String paramString, SOAPMessageContext paramSOAPMessageContext);
  
  void invokeOneWay(String paramString, SOAPMessageContext paramSOAPMessageContext);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\client\ClientTransport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */