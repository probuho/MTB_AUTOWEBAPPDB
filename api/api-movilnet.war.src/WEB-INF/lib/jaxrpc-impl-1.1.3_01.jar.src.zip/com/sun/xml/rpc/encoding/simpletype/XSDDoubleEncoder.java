/*    */ package com.sun.xml.rpc.encoding.simpletype;
/*    */ 
/*    */ import com.sun.xml.rpc.streaming.XMLReader;
/*    */ import com.sun.xml.rpc.streaming.XMLWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDDoubleEncoder
/*    */   extends SimpleTypeEncoderBase
/*    */ {
/* 37 */   private static final SimpleTypeEncoder encoder = new XSDDoubleEncoder();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SimpleTypeEncoder getInstance() {
/* 43 */     return encoder;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String objectToString(Object obj, XMLWriter writer) throws Exception {
/* 49 */     if (obj == null) {
/* 50 */       return null;
/*    */     }
/* 52 */     Double d = (Double)obj;
/* 53 */     double dVal = d.doubleValue();
/* 54 */     if (d.isInfinite()) {
/* 55 */       if (dVal == Double.NEGATIVE_INFINITY) {
/* 56 */         return "-INF";
/*    */       }
/* 58 */       return "INF";
/*    */     } 
/* 60 */     if (d.isNaN()) {
/* 61 */       return "NaN";
/*    */     }
/* 63 */     return d.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object stringToObject(String str, XMLReader reader) throws Exception {
/* 69 */     if (str == null) {
/* 70 */       return null;
/*    */     }
/* 72 */     str = EncoderUtils.collapseWhitespace(str);
/* 73 */     if (str.equals("-INF"))
/* 74 */       return new Double(Double.NEGATIVE_INFINITY); 
/* 75 */     if (str.equals("INF"))
/* 76 */       return new Double(Double.POSITIVE_INFINITY); 
/* 77 */     if (str.equals("NaN")) {
/* 78 */       return new Double(Double.NaN);
/*    */     }
/* 80 */     return new Double(str);
/*    */   }
/*    */   
/*    */   public void writeValue(Object obj, XMLWriter writer) throws Exception {
/* 84 */     writer.writeCharsUnquoted(objectToString(obj, writer));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\simpletype\XSDDoubleEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */