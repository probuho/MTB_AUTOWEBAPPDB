/*    */ package com.sun.xml.rpc.encoding.xsd;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDConstants
/*    */ {
/*    */   public static final String URI_XSI = "http://www.w3.org/2001/XMLSchema-instance";
/*    */   public static final String URI_XSD = "http://www.w3.org/2001/XMLSchema";
/* 42 */   public static final QName QNAME_XSI_TYPE = new QName("http://www.w3.org/2001/XMLSchema-instance", "type");
/* 43 */   public static final QName QNAME_XSI_NIL = new QName("http://www.w3.org/2001/XMLSchema-instance", "nil");
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\xsd\XSDConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */