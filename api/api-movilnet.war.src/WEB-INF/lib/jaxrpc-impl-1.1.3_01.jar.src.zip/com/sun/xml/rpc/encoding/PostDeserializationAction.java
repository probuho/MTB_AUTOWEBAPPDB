package com.sun.xml.rpc.encoding;

public interface PostDeserializationAction {
  void run(SOAPDeserializationContext paramSOAPDeserializationContext);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\PostDeserializationAction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */