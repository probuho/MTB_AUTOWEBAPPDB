/*    */ package com.sun.xml.rpc.encoding.soap;
/*    */ 
/*    */ import com.sun.xml.rpc.util.StructMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPResponseStructure
/*    */ {
/*    */   public Object returnValue;
/* 39 */   public Map outParameters = (Map)new StructMap();
/* 40 */   public Map outParametersStringKeys = (Map)new StructMap();
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\soap\SOAPResponseStructure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */