package com.sun.xml.rpc.encoding;

public interface SerializerConstants {
  public static final boolean ENCODE_TYPE = true;
  
  public static final boolean DONT_ENCODE_TYPE = false;
  
  public static final boolean SERIALIZE_AS_REF = true;
  
  public static final boolean DONT_SERIALIZE_AS_REF = false;
  
  public static final boolean REFERENCEABLE = true;
  
  public static final boolean NOT_REFERENCEABLE = false;
  
  public static final boolean NULLABLE = true;
  
  public static final boolean NOT_NULLABLE = false;
  
  public static final boolean REFERENCED_INSTANCE = true;
  
  public static final boolean UNREFERENCED_INSTANCE = false;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\SerializerConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */