/*    */ package com.sun.xml.rpc.encoding.simpletype;
/*    */ 
/*    */ import com.sun.msv.datatype.xsd.NegativeIntegerType;
/*    */ import com.sun.xml.rpc.encoding.DeserializationException;
/*    */ import com.sun.xml.rpc.streaming.XMLReader;
/*    */ import com.sun.xml.rpc.streaming.XMLWriter;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDNegativeIntegerEncoder
/*    */   extends SimpleTypeEncoderBase
/*    */ {
/* 40 */   private static final SimpleTypeEncoder encoder = new XSDNegativeIntegerEncoder();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SimpleTypeEncoder getInstance() {
/* 47 */     return encoder;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String objectToString(Object obj, XMLWriter writer) throws Exception {
/* 53 */     if (obj == null) {
/* 54 */       return null;
/*    */     }
/* 56 */     return ((BigInteger)obj).toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object stringToObject(String str, XMLReader reader) throws Exception {
/* 62 */     if (str == null) {
/* 63 */       return null;
/*    */     }
/* 65 */     Object obj = NegativeIntegerType.theInstance._createJavaObject(str, null);
/*    */     
/* 67 */     if (obj != null)
/* 68 */       return obj; 
/* 69 */     throw new DeserializationException("xsd.invalid.negativeInteger", str);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeValue(Object obj, XMLWriter writer) throws Exception {
/* 75 */     writer.writeCharsUnquoted(objectToString(obj, writer));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\simpletype\XSDNegativeIntegerEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */