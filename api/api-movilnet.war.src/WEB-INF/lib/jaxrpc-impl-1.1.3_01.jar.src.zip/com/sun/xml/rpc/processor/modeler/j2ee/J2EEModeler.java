/*    */ package com.sun.xml.rpc.processor.modeler.j2ee;
/*    */ 
/*    */ import com.sun.xml.rpc.processor.config.J2EEModelInfo;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class J2EEModeler
/*    */   extends J2EEModeler112
/*    */ {
/*    */   public J2EEModeler(J2EEModelInfo modelInfo, Properties options) {
/* 44 */     super(modelInfo, options);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\modeler\j2ee\J2EEModeler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */