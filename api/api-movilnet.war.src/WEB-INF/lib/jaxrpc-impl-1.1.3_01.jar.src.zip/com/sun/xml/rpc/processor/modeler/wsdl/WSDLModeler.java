/*    */ package com.sun.xml.rpc.processor.modeler.wsdl;
/*    */ 
/*    */ import com.sun.xml.rpc.processor.config.WSDLModelInfo;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDLModeler
/*    */   extends WSDLModeler112
/*    */ {
/*    */   public WSDLModeler(WSDLModelInfo modelInfo, Properties options) {
/* 45 */     super(modelInfo, options);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\modeler\wsdl\WSDLModeler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */