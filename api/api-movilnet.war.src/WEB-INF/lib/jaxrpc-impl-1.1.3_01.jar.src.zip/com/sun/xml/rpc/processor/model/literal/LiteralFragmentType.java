/*    */ package com.sun.xml.rpc.processor.model.literal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LiteralFragmentType
/*    */   extends LiteralType
/*    */ {
/*    */   public void accept(LiteralTypeVisitor visitor) throws Exception {
/* 38 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\model\literal\LiteralFragmentType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */