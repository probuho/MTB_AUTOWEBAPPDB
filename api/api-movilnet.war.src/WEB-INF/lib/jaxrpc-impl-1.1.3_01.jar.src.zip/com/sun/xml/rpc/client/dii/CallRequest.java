/*    */ package com.sun.xml.rpc.client.dii;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CallRequest
/*    */ {
/*    */   public BasicCall call;
/*    */   public Object request;
/*    */   
/*    */   public CallRequest(BasicCall call, Object request) {
/* 37 */     this.call = call;
/* 38 */     this.request = request;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\client\dii\CallRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */