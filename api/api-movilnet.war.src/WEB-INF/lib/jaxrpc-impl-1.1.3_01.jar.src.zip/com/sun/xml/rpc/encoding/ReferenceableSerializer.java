package com.sun.xml.rpc.encoding;

import com.sun.xml.rpc.streaming.XMLWriter;
import javax.xml.namespace.QName;

public interface ReferenceableSerializer extends JAXRPCSerializer {
  void serializeInstance(Object paramObject, QName paramQName, boolean paramBoolean, XMLWriter paramXMLWriter, SOAPSerializationContext paramSOAPSerializationContext);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\encoding\ReferenceableSerializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */