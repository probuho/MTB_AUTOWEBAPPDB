/*    */ package com.sun.xml.rpc.processor.modeler.j2ee;
/*    */ 
/*    */ import com.sun.xml.rpc.processor.config.J2EEModelInfo;
/*    */ import com.sun.xml.rpc.processor.modeler.JavaSimpleTypeCreator;
/*    */ import com.sun.xml.rpc.wsdl.framework.AbstractDocument;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class J2EESchemaAnalyzer
/*    */   extends J2EESchemaAnalyzer112
/*    */ {
/*    */   public J2EESchemaAnalyzer(AbstractDocument document, J2EEModelInfo modelInfo, Properties options, Set conflictingClassNames, JavaSimpleTypeCreator javaTypes) {
/* 48 */     super(document, modelInfo, options, conflictingClassNames, javaTypes);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-impl-1.1.3_01.jar!\com\sun\xml\rpc\processor\modeler\j2ee\J2EESchemaAnalyzer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */