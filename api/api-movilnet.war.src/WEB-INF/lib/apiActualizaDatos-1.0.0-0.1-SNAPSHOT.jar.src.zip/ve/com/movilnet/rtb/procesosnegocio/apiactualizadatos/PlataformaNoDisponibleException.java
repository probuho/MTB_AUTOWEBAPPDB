package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PlataformaNoDisponibleException")
public class PlataformaNoDisponibleException extends ErrorOperacionalException {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\PlataformaNoDisponibleException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */