/*     */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "EntradaTo", propOrder = {"seguridad", "aplicacion", "proveedor", "nodo", "tecnologia", "idUsuario"})
/*     */ public class EntradaTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected SeguridadTo seguridad;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected AplicacionTo aplicacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String proveedor;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nodo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tecnologia;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idUsuario;
/*     */   
/*     */   public SeguridadTo getSeguridad() {
/*  67 */     return this.seguridad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSeguridad(SeguridadTo value) {
/*  79 */     this.seguridad = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AplicacionTo getAplicacion() {
/*  91 */     return this.aplicacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAplicacion(AplicacionTo value) {
/* 103 */     this.aplicacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProveedor() {
/* 115 */     return this.proveedor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProveedor(String value) {
/* 127 */     this.proveedor = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNodo() {
/* 139 */     return this.nodo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNodo(String value) {
/* 151 */     this.nodo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTecnologia() {
/* 163 */     return this.tecnologia;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTecnologia(String value) {
/* 175 */     this.tecnologia = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdUsuario() {
/* 187 */     return this.idUsuario;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdUsuario(String value) {
/* 199 */     this.idUsuario = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\EntradaTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */