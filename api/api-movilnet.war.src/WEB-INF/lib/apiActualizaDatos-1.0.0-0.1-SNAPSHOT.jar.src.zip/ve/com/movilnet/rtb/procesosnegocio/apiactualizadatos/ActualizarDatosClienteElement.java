/*    */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "", propOrder = {"transaccionId", "cliente"})
/*    */ @XmlRootElement(name = "actualizarDatosClienteElement")
/*    */ public class ActualizarDatosClienteElement
/*    */ {
/*    */   @XmlElement(required = true, nillable = true)
/*    */   protected String transaccionId;
/*    */   @XmlElement(required = true, nillable = true)
/*    */   protected ActualizaClienteTo cliente;
/*    */   
/*    */   public String getTransaccionId() {
/* 53 */     return this.transaccionId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTransaccionId(String value) {
/* 65 */     this.transaccionId = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ActualizaClienteTo getCliente() {
/* 77 */     return this.cliente;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCliente(ActualizaClienteTo value) {
/* 89 */     this.cliente = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\ActualizarDatosClienteElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */