/*     */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebEndpoint;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceException;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @WebServiceClient(name = "ActualizarDatosClienteWebService", targetNamespace = "http://bp.procesosnegocio.rtb.movilnet.com.ve/", wsdlLocation = "http://192.168.0.4:8888/actualizarDatosClienteWs/ActualizarDatosClienteWebServiceSoapHttpPort?WSDL")
/*     */ public class ActualizarDatosClienteWebService_Service
/*     */   extends Service
/*     */ {
/*     */   private static final URL ACTUALIZARDATOSCLIENTEWEBSERVICE_WSDL_LOCATION;
/*     */   private static final WebServiceException ACTUALIZARDATOSCLIENTEWEBSERVICE_EXCEPTION;
/*  29 */   private static final QName ACTUALIZARDATOSCLIENTEWEBSERVICE_QNAME = new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "ActualizarDatosClienteWebService");
/*     */   
/*     */   static {
/*  32 */     URL url = null;
/*  33 */     WebServiceException e = null;
/*     */     try {
/*  35 */       url = new URL("http://192.168.0.4:8888/actualizarDatosClienteWs/ActualizarDatosClienteWebServiceSoapHttpPort?WSDL");
/*  36 */     } catch (MalformedURLException ex) {
/*  37 */       e = new WebServiceException(ex);
/*     */     } 
/*  39 */     ACTUALIZARDATOSCLIENTEWEBSERVICE_WSDL_LOCATION = url;
/*  40 */     ACTUALIZARDATOSCLIENTEWEBSERVICE_EXCEPTION = e;
/*     */   }
/*     */   
/*     */   public ActualizarDatosClienteWebService_Service() {
/*  44 */     super(__getWsdlLocation(), ACTUALIZARDATOSCLIENTEWEBSERVICE_QNAME);
/*     */   }
/*     */   
/*     */   public ActualizarDatosClienteWebService_Service(WebServiceFeature... features) {
/*  48 */     super(__getWsdlLocation(), ACTUALIZARDATOSCLIENTEWEBSERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */   public ActualizarDatosClienteWebService_Service(URL wsdlLocation) {
/*  52 */     super(wsdlLocation, ACTUALIZARDATOSCLIENTEWEBSERVICE_QNAME);
/*     */   }
/*     */   
/*     */   public ActualizarDatosClienteWebService_Service(URL wsdlLocation, WebServiceFeature... features) {
/*  56 */     super(wsdlLocation, ACTUALIZARDATOSCLIENTEWEBSERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */   public ActualizarDatosClienteWebService_Service(URL wsdlLocation, QName serviceName) {
/*  60 */     super(wsdlLocation, serviceName);
/*     */   }
/*     */   
/*     */   public ActualizarDatosClienteWebService_Service(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
/*  64 */     super(wsdlLocation, serviceName, features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "ActualizarDatosClienteWebServiceSoapHttpPort")
/*     */   public ActualizarDatosClienteWebService getActualizarDatosClienteWebServiceSoapHttpPort() {
/*  74 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "ActualizarDatosClienteWebServiceSoapHttpPort"), ActualizarDatosClienteWebService.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "ActualizarDatosClienteWebServiceSoapHttpPort")
/*     */   public ActualizarDatosClienteWebService getActualizarDatosClienteWebServiceSoapHttpPort(WebServiceFeature... features) {
/*  86 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "ActualizarDatosClienteWebServiceSoapHttpPort"), ActualizarDatosClienteWebService.class, features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "ActualizarDatosClienteWebServiceWSIFPort")
/*     */   public ActualizarDatosClienteWebService getActualizarDatosClienteWebServiceWSIFPort() {
/*  96 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "ActualizarDatosClienteWebServiceWSIFPort"), ActualizarDatosClienteWebService.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "ActualizarDatosClienteWebServiceWSIFPort")
/*     */   public ActualizarDatosClienteWebService getActualizarDatosClienteWebServiceWSIFPort(WebServiceFeature... features) {
/* 108 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "ActualizarDatosClienteWebServiceWSIFPort"), ActualizarDatosClienteWebService.class, features);
/*     */   }
/*     */   
/*     */   private static URL __getWsdlLocation() {
/* 112 */     if (ACTUALIZARDATOSCLIENTEWEBSERVICE_EXCEPTION != null) {
/* 113 */       throw ACTUALIZARDATOSCLIENTEWEBSERVICE_EXCEPTION;
/*     */     }
/* 115 */     return ACTUALIZARDATOSCLIENTEWEBSERVICE_WSDL_LOCATION;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\ActualizarDatosClienteWebService_Service.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */