/*     */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*     */ 
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.annotation.XmlElementDecl;
/*     */ import javax.xml.bind.annotation.XmlRegistry;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlRegistry
/*     */ public class ObjectFactory
/*     */ {
/*  27 */   private static final QName _AdvertenciaFuncionalExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "AdvertenciaFuncionalExceptionElement");
/*  28 */   private static final QName _ErrorOperacionalExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "ErrorOperacionalExceptionElement");
/*  29 */   private static final QName _PlataformaNoDisponibleExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "PlataformaNoDisponibleExceptionElement");
/*  30 */   private static final QName _MantenimientoExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "MantenimientoExceptionElement");
/*  31 */   private static final QName _SeguridadExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "SeguridadExceptionElement");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException createSeguridadException() {
/*  45 */     return new SeguridadException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdvertenciaFuncionalException createAdvertenciaFuncionalException() {
/*  53 */     return new AdvertenciaFuncionalException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActualizarDatosClienteElement createActualizarDatosClienteElement() {
/*  61 */     return new ActualizarDatosClienteElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActualizaClienteTo createActualizaClienteTo() {
/*  69 */     return new ActualizaClienteTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActualizarDatosClienteResponseElement createActualizarDatosClienteResponseElement() {
/*  77 */     return new ActualizarDatosClienteResponseElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RespuestaActualizaClienteTo createRespuestaActualizaClienteTo() {
/*  85 */     return new RespuestaActualizaClienteTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorOperacionalException createErrorOperacionalException() {
/*  93 */     return new ErrorOperacionalException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlataformaNoDisponibleException createPlataformaNoDisponibleException() {
/* 101 */     return new PlataformaNoDisponibleException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MantenimientoException createMantenimientoException() {
/* 109 */     return new MantenimientoException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClienteTo createClienteTo() {
/* 117 */     return new ClienteTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntradaTo createEntradaTo() {
/* 125 */     return new EntradaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DireccionTo createDireccionTo() {
/* 133 */     return new DireccionTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersonaTo createPersonaTo() {
/* 141 */     return new PersonaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AgenteTo createAgenteTo() {
/* 149 */     return new AgenteTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadTo createSeguridadTo() {
/* 157 */     return new SeguridadTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AplicacionTo createAplicacionTo() {
/* 165 */     return new AplicacionTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException createMovilnetException() {
/* 173 */     return new MovilnetException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "AdvertenciaFuncionalExceptionElement")
/*     */   public JAXBElement<AdvertenciaFuncionalException> createAdvertenciaFuncionalExceptionElement(AdvertenciaFuncionalException value) {
/* 182 */     return new JAXBElement<>(_AdvertenciaFuncionalExceptionElement_QNAME, AdvertenciaFuncionalException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "ErrorOperacionalExceptionElement")
/*     */   public JAXBElement<ErrorOperacionalException> createErrorOperacionalExceptionElement(ErrorOperacionalException value) {
/* 191 */     return new JAXBElement<>(_ErrorOperacionalExceptionElement_QNAME, ErrorOperacionalException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "PlataformaNoDisponibleExceptionElement")
/*     */   public JAXBElement<PlataformaNoDisponibleException> createPlataformaNoDisponibleExceptionElement(PlataformaNoDisponibleException value) {
/* 200 */     return new JAXBElement<>(_PlataformaNoDisponibleExceptionElement_QNAME, PlataformaNoDisponibleException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "MantenimientoExceptionElement")
/*     */   public JAXBElement<MantenimientoException> createMantenimientoExceptionElement(MantenimientoException value) {
/* 209 */     return new JAXBElement<>(_MantenimientoExceptionElement_QNAME, MantenimientoException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "SeguridadExceptionElement")
/*     */   public JAXBElement<SeguridadException> createSeguridadExceptionElement(SeguridadException value) {
/* 218 */     return new JAXBElement<>(_SeguridadExceptionElement_QNAME, SeguridadException.class, null, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */