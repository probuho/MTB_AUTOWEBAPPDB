/*    */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "RespuestaActualizaClienteTo", propOrder = {"cliente", "numeroContrato"})
/*    */ public class RespuestaActualizaClienteTo
/*    */ {
/*    */   @XmlElement(required = true, nillable = true)
/*    */   protected ClienteTo cliente;
/*    */   protected long numeroContrato;
/*    */   
/*    */   public ClienteTo getCliente() {
/* 50 */     return this.cliente;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCliente(ClienteTo value) {
/* 62 */     this.cliente = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getNumeroContrato() {
/* 70 */     return this.numeroContrato;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setNumeroContrato(long value) {
/* 78 */     this.numeroContrato = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\RespuestaActualizaClienteTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */