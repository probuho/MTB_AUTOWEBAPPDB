/*    */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*    */ 
/*    */ import javax.xml.ws.WebFault;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebFault(name = "PlataformaNoDisponibleExceptionElement", targetNamespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/")
/*    */ public class PlataformaNoDisponibleException_Exception
/*    */   extends Exception
/*    */ {
/*    */   private PlataformaNoDisponibleException faultInfo;
/*    */   
/*    */   public PlataformaNoDisponibleException_Exception(String message, PlataformaNoDisponibleException faultInfo) {
/* 30 */     super(message);
/* 31 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlataformaNoDisponibleException_Exception(String message, PlataformaNoDisponibleException faultInfo, Throwable cause) {
/* 41 */     super(message, cause);
/* 42 */     this.faultInfo = faultInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlataformaNoDisponibleException getFaultInfo() {
/* 51 */     return this.faultInfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\PlataformaNoDisponibleException_Exception.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */