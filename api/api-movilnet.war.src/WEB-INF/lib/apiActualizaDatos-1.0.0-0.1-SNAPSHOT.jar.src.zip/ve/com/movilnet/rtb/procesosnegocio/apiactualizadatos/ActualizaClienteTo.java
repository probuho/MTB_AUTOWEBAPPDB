/*     */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "ActualizaClienteTo", propOrder = {"agente", "personaContacto", "numero", "usuarioAutenticado", "cliente", "entrada", "personaAutorizada"})
/*     */ public class ActualizaClienteTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected AgenteTo agente;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PersonaTo personaContacto;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String numero;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PersonaTo usuarioAutenticado;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected ClienteTo cliente;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected EntradaTo entrada;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PersonaTo personaAutorizada;
/*     */   
/*     */   public AgenteTo getAgente() {
/*  71 */     return this.agente;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAgente(AgenteTo value) {
/*  83 */     this.agente = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersonaTo getPersonaContacto() {
/*  95 */     return this.personaContacto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersonaContacto(PersonaTo value) {
/* 107 */     this.personaContacto = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNumero() {
/* 119 */     return this.numero;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumero(String value) {
/* 131 */     this.numero = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersonaTo getUsuarioAutenticado() {
/* 143 */     return this.usuarioAutenticado;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsuarioAutenticado(PersonaTo value) {
/* 155 */     this.usuarioAutenticado = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClienteTo getCliente() {
/* 167 */     return this.cliente;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCliente(ClienteTo value) {
/* 179 */     this.cliente = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntradaTo getEntrada() {
/* 191 */     return this.entrada;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntrada(EntradaTo value) {
/* 203 */     this.entrada = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersonaTo getPersonaAutorizada() {
/* 215 */     return this.personaAutorizada;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersonaAutorizada(PersonaTo value) {
/* 227 */     this.personaAutorizada = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\ActualizaClienteTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */