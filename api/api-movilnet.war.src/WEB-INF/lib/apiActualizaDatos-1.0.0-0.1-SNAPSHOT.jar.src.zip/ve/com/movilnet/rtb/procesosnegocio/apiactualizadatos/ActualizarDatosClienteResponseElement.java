/*    */ package ve.com.movilnet.rtb.procesosnegocio.apiactualizadatos;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "", propOrder = {"result"})
/*    */ @XmlRootElement(name = "actualizarDatosClienteResponseElement")
/*    */ public class ActualizarDatosClienteResponseElement
/*    */ {
/*    */   @XmlElement(required = true, nillable = true)
/*    */   protected RespuestaActualizaClienteTo result;
/*    */   
/*    */   public RespuestaActualizaClienteTo getResult() {
/* 49 */     return this.result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResult(RespuestaActualizaClienteTo value) {
/* 61 */     this.result = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiActualizaDatos-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\apiactualizadatos\ActualizarDatosClienteResponseElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */