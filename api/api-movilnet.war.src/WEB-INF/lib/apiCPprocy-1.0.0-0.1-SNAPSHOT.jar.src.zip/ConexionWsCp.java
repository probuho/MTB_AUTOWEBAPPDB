/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.TimeZone;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.datatype.DatatypeConfigurationException;
/*     */ import javax.xml.datatype.DatatypeFactory;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ import ve.com.movilnet.apicpprocy.AdvertenciaFuncionalException_Exception;
/*     */ import ve.com.movilnet.apicpprocy.AplicacionTo;
/*     */ import ve.com.movilnet.apicpprocy.CambiarPlanElement;
/*     */ import ve.com.movilnet.apicpprocy.CambiarPlanResponseElement;
/*     */ import ve.com.movilnet.apicpprocy.CambiarPlanTo;
/*     */ import ve.com.movilnet.apicpprocy.CambiarPlanWs;
/*     */ import ve.com.movilnet.apicpprocy.CambiarPlanWs_Service;
/*     */ import ve.com.movilnet.apicpprocy.EntradaTo;
/*     */ import ve.com.movilnet.apicpprocy.ErrorOperacionalException_Exception;
/*     */ import ve.com.movilnet.apicpprocy.MantenimientoException_Exception;
/*     */ import ve.com.movilnet.apicpprocy.PlanConsejoComunalTo;
/*     */ import ve.com.movilnet.apicpprocy.PlanTo;
/*     */ import ve.com.movilnet.apicpprocy.PlataformaNoDisponibleException_Exception;
/*     */ import ve.com.movilnet.apicpprocy.SeguridadException_Exception;
/*     */ import ve.com.movilnet.apicpprocy.SeguridadTo;
/*     */ import ve.com.movilnet.apicpprocy.ServicioTo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConexionWsCp
/*     */ {
/*     */   public static void main(String[] args) {
/*     */     try {
/*  46 */       CambiarPlanElement Idtrans = new CambiarPlanElement();
/*  47 */       Idtrans.setTransaccionId("RTBNEG-4160523581");
/*     */       
/*  49 */       CambiarPlanTo cambioplan1 = new CambiarPlanTo();
/*     */ 
/*     */       
/*  52 */       EntradaTo entrada = new EntradaTo();
/*     */ 
/*     */ 
/*     */       
/*  56 */       AplicacionTo apli = new AplicacionTo();
/*  57 */       apli.setNombre("OVAM");
/*  58 */       apli.setTipoAplicacion("AG");
/*  59 */       apli.setCodigo("OVAM");
/*  60 */       entrada.setAplicacion(apli);
/*     */ 
/*     */ 
/*     */       
/*  64 */       SeguridadTo seguridad = new SeguridadTo();
/*  65 */       seguridad.setUsuario("WSNEGOCIO");
/*  66 */       seguridad.setClave("aplnegocio");
/*  67 */       entrada.setSeguridad(seguridad);
/*  68 */       entrada.setProveedor("MOVILNET");
/*  69 */       entrada.setNodo("GSM01");
/*  70 */       entrada.setTecnologia("3");
/*  71 */       entrada.setIdUsuario("derobcar");
/*  72 */       cambioplan1.setEntrada(entrada);
/*     */ 
/*     */       
/*  75 */       PlanConsejoComunalTo pccomunal = new PlanConsejoComunalTo();
/*  76 */       pccomunal.setNombreConsejo("");
/*  77 */       pccomunal.setCargoConsejo("");
/*  78 */       pccomunal.setCodigoConsejo4("");
/*  79 */       pccomunal.setCodigoConsejo2("");
/*  80 */       pccomunal.setCodigoConsejo3("");
/*  81 */       pccomunal.setCodigoConsejo1("");
/*  82 */       cambioplan1.setPlanConsejoComunal(pccomunal);
/*     */ 
/*     */       
/*  85 */       PlanTo plannew = new PlanTo();
/*     */       
/*  87 */       GregorianCalendar ahora = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
/*  88 */       XMLGregorianCalendar fecha = null;
/*     */       try {
/*  90 */         fecha = DatatypeFactory.newInstance().newXMLGregorianCalendar(ahora);
/*  91 */       } catch (DatatypeConfigurationException ex) {
/*  92 */         Logger.getLogger(ConexionWsCp.class.getName()).log(Level.SEVERE, "Error al Transformar Fecha de Activacion", ex);
/*     */       } 
/*  94 */       plannew.setFechaActivacion(fecha);
/*  95 */       plannew.setIdPlan("PV013");
/*  96 */       plannew.setDescripcion("MISION SOCIALISTA");
/*  97 */       plannew.setSufijoNombrePlan("ST_M_T_A_COOLCARD");
/*  98 */       plannew.setIdTipoPlan("PV");
/*  99 */       plannew.setUnidadPlan("S");
/* 100 */       plannew.setCargoPeriodicoAsociado("");
/* 101 */       cambioplan1.setPlanNuevo(plannew);
/*     */ 
/*     */       
/* 104 */       ServicioTo servicios = new ServicioTo();
/* 105 */       servicios = null;
/*     */ 
/*     */       
/* 108 */       cambioplan1.setNumeroCelular(Long.valueOf(Long.MIN_VALUE));
/* 109 */       cambioplan1.setPlanActual("CT_S_T_A_COOLCARD");
/* 110 */       cambioplan1.setCedulaCliente("12302979");
/* 111 */       cambioplan1.setImei("354895032452638");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 116 */       CambiarPlan("pc-fredy", cambioplan1, "url ");
/*     */     }
/* 118 */     catch (AdvertenciaFuncionalException_Exception ex) {
/* 119 */       Logger.getLogger(ConexionWsCp.class.getName()).log(Level.SEVERE, (String)null, (Throwable)ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String CambiarPlan(String transaccionId, CambiarPlanTo cambioplan1, String setEndpoint) throws AdvertenciaFuncionalException_Exception {
/* 125 */     CambiarPlanResponseElement resultado = new CambiarPlanResponseElement();
/* 126 */     System.out.println("resultado ");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     System.out.println("request ");
/* 132 */     CambiarPlanElement request = new CambiarPlanElement();
/* 133 */     System.out.println("luego request ");
/* 134 */     request.setTransaccionId(transaccionId);
/* 135 */     System.out.println("antes de setCambiarPlanTo ");
/* 136 */     request.setCambiarPlan(cambioplan1);
/* 137 */     System.out.println("setCambiarPlanTo ");
/*     */ 
/*     */ 
/*     */     
/* 141 */     CambiarPlanWs_Service service = new CambiarPlanWs_Service();
/* 142 */     CambiarPlanWs port = service.getCambiarPlanWsSoapHttpPort();
/* 143 */     System.out.println("getCambiarPlanWsSoapHttpPort ");
/*     */ 
/*     */ 
/*     */     
/* 147 */     System.out.println("antes de cambiarPlan ");
/* 148 */     CambiarPlanResponseElement responseElement = null;
/*     */     try {
/* 150 */       responseElement = port.cambiarPlan(request);
/* 151 */     } catch (ErrorOperacionalException_Exception ex) {
/* 152 */       Logger.getLogger(ConexionWsCp.class.getName()).log(Level.SEVERE, (String)null, (Throwable)ex);
/* 153 */     } catch (MantenimientoException_Exception ex) {
/* 154 */       Logger.getLogger(ConexionWsCp.class.getName()).log(Level.SEVERE, (String)null, (Throwable)ex);
/* 155 */     } catch (PlataformaNoDisponibleException_Exception ex) {
/* 156 */       Logger.getLogger(ConexionWsCp.class.getName()).log(Level.SEVERE, (String)null, (Throwable)ex);
/* 157 */     } catch (SeguridadException_Exception ex) {
/* 158 */       Logger.getLogger(ConexionWsCp.class.getName()).log(Level.SEVERE, (String)null, (Throwable)ex);
/*     */     } 
/* 160 */     System.out.println("luego de  cambiarPlan ");
/*     */     
/* 162 */     PlanTo response = responseElement.getResult();
/*     */ 
/*     */ 
/*     */     
/* 166 */     System.out.println(" response " + response.getDescripcion());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     if (resultado != null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ConexionWsCp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */