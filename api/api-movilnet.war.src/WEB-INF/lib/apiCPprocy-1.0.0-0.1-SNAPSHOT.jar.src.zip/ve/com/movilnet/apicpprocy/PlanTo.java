/*     */ package ve.com.movilnet.apicpprocy;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlSchemaType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "PlanTo", propOrder = {"fechaActivacion", "idPlan", "descripcion", "sufijoNombrePlan", "idTipoPlan", "unidadPlan", "cargoPeriodicoAsociado"})
/*     */ public class PlanTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaActivacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idPlan;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String descripcion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String sufijoNombrePlan;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idTipoPlan;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String unidadPlan;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String cargoPeriodicoAsociado;
/*     */   
/*     */   public XMLGregorianCalendar getFechaActivacion() {
/*  74 */     return this.fechaActivacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaActivacion(XMLGregorianCalendar value) {
/*  86 */     this.fechaActivacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdPlan() {
/*  98 */     return this.idPlan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdPlan(String value) {
/* 110 */     this.idPlan = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescripcion() {
/* 122 */     return this.descripcion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescripcion(String value) {
/* 134 */     this.descripcion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSufijoNombrePlan() {
/* 146 */     return this.sufijoNombrePlan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSufijoNombrePlan(String value) {
/* 158 */     this.sufijoNombrePlan = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdTipoPlan() {
/* 170 */     return this.idTipoPlan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdTipoPlan(String value) {
/* 182 */     this.idTipoPlan = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnidadPlan() {
/* 194 */     return this.unidadPlan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnidadPlan(String value) {
/* 206 */     this.unidadPlan = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCargoPeriodicoAsociado() {
/* 218 */     return this.cargoPeriodicoAsociado;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCargoPeriodicoAsociado(String value) {
/* 230 */     this.cargoPeriodicoAsociado = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\PlanTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */