/*     */ package ve.com.movilnet.apicpprocy;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebEndpoint;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceException;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @WebServiceClient(name = "cambiarPlanWs", targetNamespace = "http://bp.procesosnegocio.rtb.movilnet.com.ve/", wsdlLocation = "http://192.168.0.4:8888/cambioPlanWs/cambiarPlanWsSoapHttpPort?WSDL")
/*     */ public class CambiarPlanWs_Service
/*     */   extends Service
/*     */ {
/*     */   private static final URL CAMBIARPLANWS_WSDL_LOCATION;
/*     */   private static final WebServiceException CAMBIARPLANWS_EXCEPTION;
/*  29 */   private static final QName CAMBIARPLANWS_QNAME = new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "cambiarPlanWs");
/*     */   
/*     */   static {
/*  32 */     URL url = null;
/*  33 */     WebServiceException e = null;
/*     */     try {
/*  35 */       url = new URL("http://192.168.0.4:8888/cambioPlanWs/cambiarPlanWsSoapHttpPort?WSDL");
/*  36 */     } catch (MalformedURLException ex) {
/*  37 */       e = new WebServiceException(ex);
/*     */     } 
/*  39 */     CAMBIARPLANWS_WSDL_LOCATION = url;
/*  40 */     CAMBIARPLANWS_EXCEPTION = e;
/*     */   }
/*     */   
/*     */   public CambiarPlanWs_Service() {
/*  44 */     super(__getWsdlLocation(), CAMBIARPLANWS_QNAME);
/*     */   }
/*     */   
/*     */   public CambiarPlanWs_Service(WebServiceFeature... features) {
/*  48 */     super(__getWsdlLocation(), CAMBIARPLANWS_QNAME, features);
/*     */   }
/*     */   
/*     */   public CambiarPlanWs_Service(URL wsdlLocation) {
/*  52 */     super(wsdlLocation, CAMBIARPLANWS_QNAME);
/*     */   }
/*     */   
/*     */   public CambiarPlanWs_Service(URL wsdlLocation, WebServiceFeature... features) {
/*  56 */     super(wsdlLocation, CAMBIARPLANWS_QNAME, features);
/*     */   }
/*     */   
/*     */   public CambiarPlanWs_Service(URL wsdlLocation, QName serviceName) {
/*  60 */     super(wsdlLocation, serviceName);
/*     */   }
/*     */   
/*     */   public CambiarPlanWs_Service(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
/*  64 */     super(wsdlLocation, serviceName, features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "cambiarPlanWsSoapHttpPort")
/*     */   public CambiarPlanWs getCambiarPlanWsSoapHttpPort() {
/*  74 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "cambiarPlanWsSoapHttpPort"), CambiarPlanWs.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "cambiarPlanWsSoapHttpPort")
/*     */   public CambiarPlanWs getCambiarPlanWsSoapHttpPort(WebServiceFeature... features) {
/*  86 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "cambiarPlanWsSoapHttpPort"), CambiarPlanWs.class, features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "cambiarPlanWsWSIFPort")
/*     */   public CambiarPlanWs getCambiarPlanWsWSIFPort() {
/*  96 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "cambiarPlanWsWSIFPort"), CambiarPlanWs.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @WebEndpoint(name = "cambiarPlanWsWSIFPort")
/*     */   public CambiarPlanWs getCambiarPlanWsWSIFPort(WebServiceFeature... features) {
/* 108 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "cambiarPlanWsWSIFPort"), CambiarPlanWs.class, features);
/*     */   }
/*     */   
/*     */   private static URL __getWsdlLocation() {
/* 112 */     if (CAMBIARPLANWS_EXCEPTION != null) {
/* 113 */       throw CAMBIARPLANWS_EXCEPTION;
/*     */     }
/* 115 */     return CAMBIARPLANWS_WSDL_LOCATION;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\CambiarPlanWs_Service.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */