/*     */ package ve.com.movilnet.apicpprocy;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "PlanConsejoComunalTo", propOrder = {"nombreConsejo", "cargoConsejo", "codigoConsejo4", "codigoConsejo2", "codigoConsejo3", "codigoConsejo1"})
/*     */ public class PlanConsejoComunalTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nombreConsejo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String cargoConsejo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigoConsejo4;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigoConsejo2;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigoConsejo3;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigoConsejo1;
/*     */   
/*     */   public String getNombreConsejo() {
/*  67 */     return this.nombreConsejo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNombreConsejo(String value) {
/*  79 */     this.nombreConsejo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCargoConsejo() {
/*  91 */     return this.cargoConsejo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCargoConsejo(String value) {
/* 103 */     this.cargoConsejo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigoConsejo4() {
/* 115 */     return this.codigoConsejo4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigoConsejo4(String value) {
/* 127 */     this.codigoConsejo4 = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigoConsejo2() {
/* 139 */     return this.codigoConsejo2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigoConsejo2(String value) {
/* 151 */     this.codigoConsejo2 = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigoConsejo3() {
/* 163 */     return this.codigoConsejo3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigoConsejo3(String value) {
/* 175 */     this.codigoConsejo3 = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigoConsejo1() {
/* 187 */     return this.codigoConsejo1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigoConsejo1(String value) {
/* 199 */     this.codigoConsejo1 = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\PlanConsejoComunalTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */