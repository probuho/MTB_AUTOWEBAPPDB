/*     */ package ve.com.movilnet.apicpprocy;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlSchemaType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "ServicioTo", propOrder = {"fechaActivacion", "estatus", "minimoLineasAfiliadas", "indicadorProvisioning", "fechaInicioServicio", "indicadorCargoMensual", "descripcion", "maximoLineasAfiliadas", "idServicio", "fechaEstatus", "montoServicio", "tipoServicio", "fechaFinServicio", "nombreCargoMensual"})
/*     */ public class ServicioTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaActivacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String estatus;
/*     */   protected int minimoLineasAfiliadas;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String indicadorProvisioning;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaInicioServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String indicadorCargoMensual;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String descripcion;
/*     */   protected int maximoLineasAfiliadas;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaEstatus;
/*     */   @XmlElement(required = true, type = Double.class, nillable = true)
/*     */   protected Double montoServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaFinServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nombreCargoMensual;
/*     */   
/*     */   public XMLGregorianCalendar getFechaActivacion() {
/* 103 */     return this.fechaActivacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaActivacion(XMLGregorianCalendar value) {
/* 115 */     this.fechaActivacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEstatus() {
/* 127 */     return this.estatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEstatus(String value) {
/* 139 */     this.estatus = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimoLineasAfiliadas() {
/* 147 */     return this.minimoLineasAfiliadas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinimoLineasAfiliadas(int value) {
/* 155 */     this.minimoLineasAfiliadas = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndicadorProvisioning() {
/* 167 */     return this.indicadorProvisioning;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndicadorProvisioning(String value) {
/* 179 */     this.indicadorProvisioning = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaInicioServicio() {
/* 191 */     return this.fechaInicioServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaInicioServicio(XMLGregorianCalendar value) {
/* 203 */     this.fechaInicioServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndicadorCargoMensual() {
/* 215 */     return this.indicadorCargoMensual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndicadorCargoMensual(String value) {
/* 227 */     this.indicadorCargoMensual = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescripcion() {
/* 239 */     return this.descripcion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescripcion(String value) {
/* 251 */     this.descripcion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximoLineasAfiliadas() {
/* 259 */     return this.maximoLineasAfiliadas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaximoLineasAfiliadas(int value) {
/* 267 */     this.maximoLineasAfiliadas = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdServicio() {
/* 279 */     return this.idServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdServicio(String value) {
/* 291 */     this.idServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaEstatus() {
/* 303 */     return this.fechaEstatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaEstatus(XMLGregorianCalendar value) {
/* 315 */     this.fechaEstatus = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getMontoServicio() {
/* 327 */     return this.montoServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMontoServicio(Double value) {
/* 339 */     this.montoServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoServicio() {
/* 351 */     return this.tipoServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoServicio(String value) {
/* 363 */     this.tipoServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaFinServicio() {
/* 375 */     return this.fechaFinServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaFinServicio(XMLGregorianCalendar value) {
/* 387 */     this.fechaFinServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNombreCargoMensual() {
/* 399 */     return this.nombreCargoMensual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNombreCargoMensual(String value) {
/* 411 */     this.nombreCargoMensual = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\ServicioTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */