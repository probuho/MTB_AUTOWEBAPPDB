/*    */ package ve.com.movilnet.apicpprocy;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "SeguridadTo", propOrder = {"usuario", "clave"})
/*    */ public class SeguridadTo
/*    */ {
/*    */   @XmlElement(required = true, nillable = true)
/*    */   protected String usuario;
/*    */   @XmlElement(required = true, nillable = true)
/*    */   protected String clave;
/*    */   
/*    */   public String getUsuario() {
/* 51 */     return this.usuario;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUsuario(String value) {
/* 63 */     this.usuario = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClave() {
/* 75 */     return this.clave;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClave(String value) {
/* 87 */     this.clave = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\SeguridadTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */