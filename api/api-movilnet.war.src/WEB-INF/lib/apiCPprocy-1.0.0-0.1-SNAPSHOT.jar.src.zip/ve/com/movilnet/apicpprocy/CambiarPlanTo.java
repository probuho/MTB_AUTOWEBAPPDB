/*     */ package ve.com.movilnet.apicpprocy;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "CambiarPlanTo", propOrder = {"servicios", "numeroCelular", "planNuevo", "planActual", "cedulaCliente", "planConsejoComunal", "imei", "entrada"})
/*     */ public class CambiarPlanTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected List servicios;
/*     */   @XmlElement(required = true, type = Long.class, nillable = true)
/*     */   protected Long numeroCelular;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PlanTo planNuevo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String planActual;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String cedulaCliente;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PlanConsejoComunalTo planConsejoComunal;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String imei;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected EntradaTo entrada;
/*     */   
/*     */   public List getServicios() {
/*  75 */     return this.servicios;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServicios(List value) {
/*  87 */     this.servicios = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getNumeroCelular() {
/*  99 */     return this.numeroCelular;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumeroCelular(Long value) {
/* 111 */     this.numeroCelular = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlanTo getPlanNuevo() {
/* 123 */     return this.planNuevo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlanNuevo(PlanTo value) {
/* 135 */     this.planNuevo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPlanActual() {
/* 147 */     return this.planActual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlanActual(String value) {
/* 159 */     this.planActual = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCedulaCliente() {
/* 171 */     return this.cedulaCliente;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCedulaCliente(String value) {
/* 183 */     this.cedulaCliente = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlanConsejoComunalTo getPlanConsejoComunal() {
/* 195 */     return this.planConsejoComunal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlanConsejoComunal(PlanConsejoComunalTo value) {
/* 207 */     this.planConsejoComunal = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImei() {
/* 219 */     return this.imei;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImei(String value) {
/* 231 */     this.imei = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntradaTo getEntrada() {
/* 243 */     return this.entrada;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntrada(EntradaTo value) {
/* 255 */     this.entrada = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\CambiarPlanTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */