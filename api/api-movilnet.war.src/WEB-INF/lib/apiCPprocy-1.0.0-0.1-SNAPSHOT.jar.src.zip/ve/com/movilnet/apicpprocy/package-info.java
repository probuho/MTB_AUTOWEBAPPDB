package ve.com.movilnet.apicpprocy;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;



/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */