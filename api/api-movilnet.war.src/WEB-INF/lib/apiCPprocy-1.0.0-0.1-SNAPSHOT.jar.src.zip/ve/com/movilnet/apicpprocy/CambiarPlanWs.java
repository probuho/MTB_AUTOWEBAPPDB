package ve.com.movilnet.apicpprocy;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;

@WebService(name = "cambiarPlanWs", targetNamespace = "http://bp.procesosnegocio.rtb.movilnet.com.ve/")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({ObjectFactory.class})
public interface CambiarPlanWs {
  @WebMethod(action = "http://bp.procesosnegocio.rtb.movilnet.com.ve//cambiarPlan")
  @WebResult(name = "cambiarPlanResponseElement", targetNamespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", partName = "parameters")
  CambiarPlanResponseElement cambiarPlan(@WebParam(name = "cambiarPlanElement", targetNamespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", partName = "parameters") CambiarPlanElement paramCambiarPlanElement) throws AdvertenciaFuncionalException_Exception, ErrorOperacionalException_Exception, MantenimientoException_Exception, PlataformaNoDisponibleException_Exception, SeguridadException_Exception;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\CambiarPlanWs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */