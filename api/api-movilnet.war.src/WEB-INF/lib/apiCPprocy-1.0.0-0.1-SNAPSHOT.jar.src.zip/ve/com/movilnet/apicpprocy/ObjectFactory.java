/*     */ package ve.com.movilnet.apicpprocy;
/*     */ 
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.annotation.XmlElementDecl;
/*     */ import javax.xml.bind.annotation.XmlRegistry;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlRegistry
/*     */ public class ObjectFactory
/*     */ {
/*  27 */   private static final QName _AdvertenciaFuncionalExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "AdvertenciaFuncionalExceptionElement");
/*  28 */   private static final QName _ErrorOperacionalExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "ErrorOperacionalExceptionElement");
/*  29 */   private static final QName _PlataformaNoDisponibleExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "PlataformaNoDisponibleExceptionElement");
/*  30 */   private static final QName _MantenimientoExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "MantenimientoExceptionElement");
/*  31 */   private static final QName _SeguridadExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "SeguridadExceptionElement");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CambiarPlanResponseElement createCambiarPlanResponseElement() {
/*  45 */     return new CambiarPlanResponseElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlanTo createPlanTo() {
/*  53 */     return new PlanTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CambiarPlanElement createCambiarPlanElement() {
/*  61 */     return new CambiarPlanElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CambiarPlanTo createCambiarPlanTo() {
/*  69 */     return new CambiarPlanTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException createSeguridadException() {
/*  77 */     return new SeguridadException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdvertenciaFuncionalException createAdvertenciaFuncionalException() {
/*  85 */     return new AdvertenciaFuncionalException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorOperacionalException createErrorOperacionalException() {
/*  93 */     return new ErrorOperacionalException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlataformaNoDisponibleException createPlataformaNoDisponibleException() {
/* 101 */     return new PlataformaNoDisponibleException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MantenimientoException createMantenimientoException() {
/* 109 */     return new MantenimientoException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntradaTo createEntradaTo() {
/* 117 */     return new EntradaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlanConsejoComunalTo createPlanConsejoComunalTo() {
/* 125 */     return new PlanConsejoComunalTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServicioTo createServicioTo() {
/* 133 */     return new ServicioTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadTo createSeguridadTo() {
/* 141 */     return new SeguridadTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AplicacionTo createAplicacionTo() {
/* 149 */     return new AplicacionTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException createMovilnetException() {
/* 157 */     return new MovilnetException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection createCollection() {
/* 165 */     return new Collection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List createList() {
/* 173 */     return new List();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "AdvertenciaFuncionalExceptionElement")
/*     */   public JAXBElement<AdvertenciaFuncionalException> createAdvertenciaFuncionalExceptionElement(AdvertenciaFuncionalException value) {
/* 182 */     return new JAXBElement<>(_AdvertenciaFuncionalExceptionElement_QNAME, AdvertenciaFuncionalException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "ErrorOperacionalExceptionElement")
/*     */   public JAXBElement<ErrorOperacionalException> createErrorOperacionalExceptionElement(ErrorOperacionalException value) {
/* 191 */     return new JAXBElement<>(_ErrorOperacionalExceptionElement_QNAME, ErrorOperacionalException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "PlataformaNoDisponibleExceptionElement")
/*     */   public JAXBElement<PlataformaNoDisponibleException> createPlataformaNoDisponibleExceptionElement(PlataformaNoDisponibleException value) {
/* 200 */     return new JAXBElement<>(_PlataformaNoDisponibleExceptionElement_QNAME, PlataformaNoDisponibleException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "MantenimientoExceptionElement")
/*     */   public JAXBElement<MantenimientoException> createMantenimientoExceptionElement(MantenimientoException value) {
/* 209 */     return new JAXBElement<>(_MantenimientoExceptionElement_QNAME, MantenimientoException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "SeguridadExceptionElement")
/*     */   public JAXBElement<SeguridadException> createSeguridadExceptionElement(SeguridadException value) {
/* 218 */     return new JAXBElement<>(_SeguridadExceptionElement_QNAME, SeguridadException.class, null, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiCPprocy-1.0.0-0.1-SNAPSHOT.jar!\ve\com\movilnet\apicpprocy\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */