/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.ResponseTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ResponseTO _instance;
/*     */   private long executionTime;
/*     */   private String origin;
/*     */   private String responseCode;
/*     */   private String responseDescription;
/*     */   private String responseMessage;
/*     */   private String responseSubCode;
/*     */   private String transactionId;
/*     */   private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   
/*     */   public void setExecutionTime(long executionTime) {
/*  33 */     this.executionTime = executionTime;
/*     */   }
/*     */   
/*     */   public void setOrigin(String origin) {
/*  37 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public void setResponseCode(String responseCode) {
/*  41 */     this.responseCode = responseCode;
/*     */   }
/*     */   
/*     */   public void setResponseDescription(String responseDescription) {
/*  45 */     this.responseDescription = responseDescription;
/*     */   }
/*     */   
/*     */   public void setResponseMessage(String responseMessage) {
/*  49 */     this.responseMessage = responseMessage;
/*     */   }
/*     */   
/*     */   public void setResponseSubCode(String responseSubCode) {
/*  53 */     this.responseSubCode = responseSubCode;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  57 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  61 */     switch (memberIndex) {
/*     */       case 0:
/*  63 */         return 6;
/*     */       case 1:
/*  65 */         return 6;
/*     */       case 2:
/*  67 */         return 6;
/*     */       case 3:
/*  69 */         return 6;
/*     */       case 4:
/*  71 */         return 6;
/*     */       case 5:
/*  73 */         return 6;
/*     */       case 6:
/*  75 */         return 6;
/*     */     } 
/*  77 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/*  86 */       switch (index) {
/*     */         case 0:
/*  88 */           this._instance.setExecutionTime(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 1:
/*  91 */           this._instance.setOrigin((String)memberValue);
/*     */           return;
/*     */         case 2:
/*  94 */           this._instance.setResponseCode((String)memberValue);
/*     */           return;
/*     */         case 3:
/*  97 */           this._instance.setResponseDescription((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 100 */           this._instance.setResponseMessage((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 103 */           this._instance.setResponseSubCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 106 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */       } 
/* 109 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 112 */     catch (RuntimeException e) {
/* 113 */       throw e;
/*     */     }
/* 115 */     catch (Exception e) {
/* 116 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 124 */     this._instance = (ResponseTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 128 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\runtime\ResponseTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */