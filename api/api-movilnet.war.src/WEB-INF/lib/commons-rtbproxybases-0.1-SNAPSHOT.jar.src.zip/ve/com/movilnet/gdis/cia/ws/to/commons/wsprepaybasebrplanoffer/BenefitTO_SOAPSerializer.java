/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.BenefitTO_SOAPBuilder;
/*     */ 
/*     */ public class BenefitTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_balanceName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceName");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_chargeCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "chargeCode");
/*  23 */   private static final QName ns2_comment_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "comment");
/*  24 */   private static final QName ns2_expirationDays_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "expirationDays");
/*  25 */   private static final QName ns4_int_TYPE_QNAME = SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_11).getQNameTypeInt();
/*     */   private CombinedSerializer myns4__int__java_lang_Integer_Int_Serializer;
/*  27 */   private static final QName ns2_operation_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "operation");
/*  28 */   private static final QName ns2_quantity_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "quantity");
/*  29 */   private static final QName ns4_long_TYPE_QNAME = SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_11).getQNameTypeLong();
/*     */   private CombinedSerializer myns4__long__java_lang_Long_Long_Serializer;
/*  31 */   private static final QName ns2_unitType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "unitType"); private static final int mybalanceName_INDEX = 0; private static final int mychargeCode_INDEX = 1; private static final int mycomment_INDEX = 2;
/*     */   private static final int myexpirationDays_INDEX = 3;
/*     */   private static final int myoperation_INDEX = 4;
/*     */   private static final int myquantity_INDEX = 5;
/*     */   private static final int myunitType_INDEX = 6;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class class$java$lang$Integer;
/*     */   private static Class class$java$lang$Long;
/*     */   
/*     */   public BenefitTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  41 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  45 */     if (class$java$lang$String == null); ((BenefitTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  46 */     if (class$java$lang$Integer == null); ((BenefitTO_SOAPSerializer)registry).myns4__int__java_lang_Integer_Int_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$Integer, class$java$lang$Integer = class$("java.lang.Integer"), ns4_int_TYPE_QNAME);
/*  47 */     if (class$java$lang$Long == null); ((BenefitTO_SOAPSerializer)registry).myns4__long__java_lang_Long_Long_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$Long, class$java$lang$Long = class$("java.lang.Long"), ns4_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  52 */     BenefitTO instance = new BenefitTO();
/*  53 */     BenefitTO_SOAPBuilder builder = null;
/*     */     
/*  55 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  58 */     reader.nextElementContent();
/*  59 */     QName startName = reader.getName();
/*  60 */     for (int i = 0; i < 7; i++) {
/*  61 */       QName elementName = reader.getName();
/*  62 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  65 */       if (matchQName(elementName, ns2_balanceName_QNAME)) {
/*  66 */         context.setNillable(true);
/*  67 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_balanceName_QNAME, reader, context);
/*  68 */         if (member instanceof SOAPDeserializationState) {
/*  69 */           if (builder == null) {
/*  70 */             builder = new BenefitTO_SOAPBuilder();
/*     */           }
/*  72 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  73 */           isComplete = false;
/*  74 */         } else if (member != null) {
/*  75 */           instance.setBalanceName((String)member);
/*     */         } 
/*  77 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  80 */       else if (matchQName(elementName, ns2_chargeCode_QNAME)) {
/*  81 */         context.setNillable(true);
/*  82 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_chargeCode_QNAME, reader, context);
/*  83 */         if (object instanceof SOAPDeserializationState) {
/*  84 */           if (builder == null) {
/*  85 */             builder = new BenefitTO_SOAPBuilder();
/*     */           }
/*  87 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  88 */           isComplete = false;
/*  89 */         } else if (object != null) {
/*  90 */           instance.setChargeCode((String)object);
/*     */         } 
/*  92 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  95 */       else if (matchQName(elementName, ns2_comment_QNAME)) {
/*  96 */         context.setNillable(true);
/*  97 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_comment_QNAME, reader, context);
/*  98 */         if (object instanceof SOAPDeserializationState) {
/*  99 */           if (builder == null) {
/* 100 */             builder = new BenefitTO_SOAPBuilder();
/*     */           }
/* 102 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 103 */           isComplete = false;
/* 104 */         } else if (object != null) {
/* 105 */           instance.setComment((String)object);
/*     */         } 
/* 107 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 110 */       else if (matchQName(elementName, ns2_expirationDays_QNAME)) {
/* 111 */         context.setNillable(true);
/* 112 */         Object object = this.myns4__int__java_lang_Integer_Int_Serializer.deserialize(ns2_expirationDays_QNAME, reader, context);
/* 113 */         if (object instanceof SOAPDeserializationState) {
/* 114 */           if (builder == null) {
/* 115 */             builder = new BenefitTO_SOAPBuilder();
/*     */           }
/* 117 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 118 */           isComplete = false;
/* 119 */         } else if (object != null) {
/* 120 */           instance.setExpirationDays((Integer)object);
/*     */         } 
/* 122 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 125 */       else if (matchQName(elementName, ns2_operation_QNAME)) {
/* 126 */         context.setNillable(true);
/* 127 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_operation_QNAME, reader, context);
/* 128 */         if (object instanceof SOAPDeserializationState) {
/* 129 */           if (builder == null) {
/* 130 */             builder = new BenefitTO_SOAPBuilder();
/*     */           }
/* 132 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 133 */           isComplete = false;
/* 134 */         } else if (object != null) {
/* 135 */           instance.setOperation((String)object);
/*     */         } 
/* 137 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 140 */       else if (matchQName(elementName, ns2_quantity_QNAME)) {
/* 141 */         context.setNillable(true);
/* 142 */         Object object = this.myns4__long__java_lang_Long_Long_Serializer.deserialize(ns2_quantity_QNAME, reader, context);
/* 143 */         if (object instanceof SOAPDeserializationState) {
/* 144 */           if (builder == null) {
/* 145 */             builder = new BenefitTO_SOAPBuilder();
/*     */           }
/* 147 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 148 */           isComplete = false;
/* 149 */         } else if (object != null) {
/* 150 */           instance.setQuantity((Long)object);
/*     */         } 
/* 152 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 155 */       else if (matchQName(elementName, ns2_unitType_QNAME)) {
/* 156 */         context.setNillable(true);
/* 157 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_unitType_QNAME, reader, context);
/* 158 */         if (object instanceof SOAPDeserializationState) {
/* 159 */           if (builder == null) {
/* 160 */             builder = new BenefitTO_SOAPBuilder();
/*     */           }
/* 162 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 163 */           isComplete = false;
/* 164 */         } else if (object != null) {
/* 165 */           instance.setUnitType((String)object);
/*     */         } 
/* 167 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 170 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_unitType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 175 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 176 */     } catch (XMLReaderException xmle) {
/* 177 */       if (startName != null) {
/* 178 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 180 */       throw xmle;
/*     */     } 
/*     */     
/* 183 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 187 */     BenefitTO instance = (BenefitTO)obj;
/*     */     
/* 189 */     context.setNillable(true);
/* 190 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getBalanceName(), ns2_balanceName_QNAME, null, writer, context);
/* 191 */     context.setNillable(true);
/* 192 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getChargeCode(), ns2_chargeCode_QNAME, null, writer, context);
/* 193 */     context.setNillable(true);
/* 194 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getComment(), ns2_comment_QNAME, null, writer, context);
/* 195 */     context.setNillable(true);
/* 196 */     this.myns4__int__java_lang_Integer_Int_Serializer.serialize(instance.getExpirationDays(), ns2_expirationDays_QNAME, null, writer, context);
/* 197 */     context.setNillable(true);
/* 198 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOperation(), ns2_operation_QNAME, null, writer, context);
/* 199 */     context.setNillable(true);
/* 200 */     this.myns4__long__java_lang_Long_Long_Serializer.serialize(instance.getQuantity(), ns2_quantity_QNAME, null, writer, context);
/* 201 */     context.setNillable(true);
/* 202 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUnitType(), ns2_unitType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\BenefitTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */