/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO_v2;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidatePlanRequestTO_v2_SOAPBuilder;
/*     */ 
/*     */ public class ValidatePlanRequestTO_v2_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_aplicationType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "aplicationType");
/*  33 */   private static final QName ns2_customerType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "customerType");
/*  34 */   private static final QName ns2_entrada_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "entrada");
/*  35 */   private static final QName ns2_ArrayOfstring_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/*     */   private CombinedSerializer myns2_ArrayOfstring__String_Array_LiteralSerializer1;
/*  37 */   private static final QName ns2_planCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCode");
/*  38 */   private static final QName ns2_planCosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCosName");
/*  39 */   private static final QName ns2_ssn_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ssn");
/*  40 */   private static final QName ns2_subscriberId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subscriberId");
/*  41 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  43 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2; private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myaplicationType_INDEX = 5;
/*     */   private static final int mycustomerType_INDEX = 6;
/*     */   private static final int myentrada_INDEX = 7;
/*     */   private static final int myplanCode_INDEX = 8;
/*     */   private static final int myplanCosName_INDEX = 9;
/*     */   private static final int myssn_INDEX = 10;
/*     */   private static final int mysubscriberId_INDEX = 11;
/*     */   private static final int mytransactionType_INDEX = 12;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   
/*     */   public ValidatePlanRequestTO_v2_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  59 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  63 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidatePlanRequestTO_v2_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  64 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidatePlanRequestTO_v2_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  65 */     if (class$java$lang$String == null); ((ValidatePlanRequestTO_v2_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  66 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  67 */     if (array$Ljava$lang$String == null); ((ValidatePlanRequestTO_v2_SOAPSerializer)registry).myns2_ArrayOfstring__String_Array_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), ns2_ArrayOfstring_TYPE_QNAME);
/*  68 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  73 */     ValidatePlanRequestTO_v2 instance = new ValidatePlanRequestTO_v2();
/*  74 */     ValidatePlanRequestTO_v2_SOAPBuilder builder = null;
/*     */     
/*  76 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  79 */     reader.nextElementContent();
/*  80 */     QName startName = reader.getName();
/*  81 */     for (int i = 0; i < 13; i++) {
/*  82 */       QName elementName = reader.getName();
/*  83 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  86 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  87 */         context.setNillable(true);
/*  88 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  89 */         if (member instanceof SOAPDeserializationState) {
/*  90 */           if (builder == null) {
/*  91 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/*  93 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  94 */           isComplete = false;
/*  95 */         } else if (member != null) {
/*  96 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  98 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 101 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/* 102 */         context.setNillable(true);
/* 103 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/* 104 */         if (object instanceof SOAPDeserializationState) {
/* 105 */           if (builder == null) {
/* 106 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 108 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 109 */           isComplete = false;
/* 110 */         } else if (object != null) {
/* 111 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 113 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 116 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 117 */         context.setNillable(true);
/* 118 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 119 */         if (object instanceof SOAPDeserializationState) {
/* 120 */           if (builder == null) {
/* 121 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 123 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 124 */           isComplete = false;
/* 125 */         } else if (object != null) {
/* 126 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 128 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 131 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 132 */         context.setNillable(true);
/* 133 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 134 */         if (object instanceof SOAPDeserializationState) {
/* 135 */           if (builder == null) {
/* 136 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 138 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 139 */           isComplete = false;
/* 140 */         } else if (object != null) {
/* 141 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 143 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 146 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 147 */         context.setNillable(true);
/* 148 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 149 */         if (object instanceof SOAPDeserializationState) {
/* 150 */           if (builder == null) {
/* 151 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 153 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 154 */           isComplete = false;
/* 155 */         } else if (object != null) {
/* 156 */           instance.setTransactionId((String)object);
/*     */         } 
/* 158 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 161 */       else if (matchQName(elementName, ns2_aplicationType_QNAME)) {
/* 162 */         context.setNillable(true);
/* 163 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_aplicationType_QNAME, reader, context);
/* 164 */         if (object instanceof SOAPDeserializationState) {
/* 165 */           if (builder == null) {
/* 166 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 168 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 169 */           isComplete = false;
/* 170 */         } else if (object != null) {
/* 171 */           instance.setAplicationType((String)object);
/*     */         } 
/* 173 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 176 */       else if (matchQName(elementName, ns2_customerType_QNAME)) {
/* 177 */         context.setNillable(true);
/* 178 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_customerType_QNAME, reader, context);
/* 179 */         if (object instanceof SOAPDeserializationState) {
/* 180 */           if (builder == null) {
/* 181 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 183 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 184 */           isComplete = false;
/* 185 */         } else if (object != null) {
/* 186 */           instance.setCustomerType((String)object);
/*     */         } 
/* 188 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 191 */       else if (matchQName(elementName, ns2_entrada_QNAME)) {
/* 192 */         context.setNillable(true);
/* 193 */         Object object = this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.deserialize(ns2_entrada_QNAME, reader, context);
/* 194 */         if (object instanceof SOAPDeserializationState) {
/* 195 */           if (builder == null) {
/* 196 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 198 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 199 */           isComplete = false;
/* 200 */         } else if (object != null) {
/* 201 */           instance.setEntrada((String[])object);
/*     */         } 
/* 203 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 206 */       else if (matchQName(elementName, ns2_planCode_QNAME)) {
/* 207 */         context.setNillable(true);
/* 208 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCode_QNAME, reader, context);
/* 209 */         if (object instanceof SOAPDeserializationState) {
/* 210 */           if (builder == null) {
/* 211 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 213 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 214 */           isComplete = false;
/* 215 */         } else if (object != null) {
/* 216 */           instance.setPlanCode((String)object);
/*     */         } 
/* 218 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 221 */       else if (matchQName(elementName, ns2_planCosName_QNAME)) {
/* 222 */         context.setNillable(true);
/* 223 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCosName_QNAME, reader, context);
/* 224 */         if (object instanceof SOAPDeserializationState) {
/* 225 */           if (builder == null) {
/* 226 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 228 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 229 */           isComplete = false;
/* 230 */         } else if (object != null) {
/* 231 */           instance.setPlanCosName((String)object);
/*     */         } 
/* 233 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 236 */       else if (matchQName(elementName, ns2_ssn_QNAME)) {
/* 237 */         context.setNillable(true);
/* 238 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_ssn_QNAME, reader, context);
/* 239 */         if (object instanceof SOAPDeserializationState) {
/* 240 */           if (builder == null) {
/* 241 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 243 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 244 */           isComplete = false;
/* 245 */         } else if (object != null) {
/* 246 */           instance.setSsn((String)object);
/*     */         } 
/* 248 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 251 */       else if (matchQName(elementName, ns2_subscriberId_QNAME)) {
/* 252 */         context.setNillable(true);
/* 253 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_subscriberId_QNAME, reader, context);
/* 254 */         if (object instanceof SOAPDeserializationState) {
/* 255 */           if (builder == null) {
/* 256 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 258 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 259 */           isComplete = false;
/* 260 */         } else if (object != null) {
/* 261 */           instance.setSubscriberId(((Long)object).longValue());
/*     */         } 
/* 263 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 266 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 267 */         context.setNillable(true);
/* 268 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 269 */         if (object instanceof SOAPDeserializationState) {
/* 270 */           if (builder == null) {
/* 271 */             builder = new ValidatePlanRequestTO_v2_SOAPBuilder();
/*     */           }
/* 273 */           state = registerWithMemberState(instance, state, object, 12, (SOAPInstanceBuilder)builder);
/* 274 */           isComplete = false;
/* 275 */         } else if (object != null) {
/* 276 */           instance.setTransactionType((String)object);
/*     */         } 
/* 278 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 281 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 286 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 287 */     } catch (XMLReaderException xmle) {
/* 288 */       if (startName != null) {
/* 289 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 291 */       throw xmle;
/*     */     } 
/*     */     
/* 294 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 298 */     ValidatePlanRequestTO_v2 instance = (ValidatePlanRequestTO_v2)obj;
/*     */     
/* 300 */     context.setNillable(true);
/* 301 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 302 */     context.setNillable(true);
/* 303 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 304 */     context.setNillable(true);
/* 305 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 306 */     context.setNillable(true);
/* 307 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 308 */     context.setNillable(true);
/* 309 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 310 */     context.setNillable(true);
/* 311 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAplicationType(), ns2_aplicationType_QNAME, null, writer, context);
/* 312 */     context.setNillable(true);
/* 313 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCustomerType(), ns2_customerType_QNAME, null, writer, context);
/* 314 */     context.setNillable(true);
/* 315 */     this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.serialize(instance.getEntrada(), ns2_entrada_QNAME, null, writer, context);
/* 316 */     context.setNillable(true);
/* 317 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCode(), ns2_planCode_QNAME, null, writer, context);
/* 318 */     context.setNillable(true);
/* 319 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCosName(), ns2_planCosName_QNAME, null, writer, context);
/* 320 */     context.setNillable(true);
/* 321 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getSsn(), ns2_ssn_QNAME, null, writer, context);
/* 322 */     context.setNillable(true);
/* 323 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getSubscriberId()), ns2_subscriberId_QNAME, null, writer, context);
/* 324 */     context.setNillable(true);
/* 325 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidatePlanRequestTO_v2_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */