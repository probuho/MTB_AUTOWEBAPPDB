/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanPromotionDealerRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatePlanPromotionDealerRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidatePlanPromotionDealerRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String cosName;
/*     */   private String dealerCode;
/*     */   private String planCode;
/*     */   private String promoId;
/*     */   private String transactionType;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int mycosName_INDEX = 5;
/*     */   private static final int mydealerCode_INDEX = 6;
/*     */   private static final int myplanCode_INDEX = 7;
/*     */   private static final int mypromoId_INDEX = 8;
/*     */   private static final int mytransactionType_INDEX = 9;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  39 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  43 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  47 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  51 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  55 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setCosName(String cosName) {
/*  59 */     this.cosName = cosName;
/*     */   }
/*     */   
/*     */   public void setDealerCode(String dealerCode) {
/*  63 */     this.dealerCode = dealerCode;
/*     */   }
/*     */   
/*     */   public void setPlanCode(String planCode) {
/*  67 */     this.planCode = planCode;
/*     */   }
/*     */   
/*     */   public void setPromoId(String promoId) {
/*  71 */     this.promoId = promoId;
/*     */   }
/*     */   
/*     */   public void setTransactionType(String transactionType) {
/*  75 */     this.transactionType = transactionType;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  79 */     switch (memberIndex) {
/*     */       case 0:
/*  81 */         return 6;
/*     */       case 1:
/*  83 */         return 6;
/*     */       case 2:
/*  85 */         return 6;
/*     */       case 3:
/*  87 */         return 6;
/*     */       case 4:
/*  89 */         return 6;
/*     */       case 5:
/*  91 */         return 6;
/*     */       case 6:
/*  93 */         return 6;
/*     */       case 7:
/*  95 */         return 6;
/*     */       case 8:
/*  97 */         return 6;
/*     */       case 9:
/*  99 */         return 6;
/*     */     } 
/* 101 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 110 */       switch (index) {
/*     */         case 0:
/* 112 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/* 115 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/* 118 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 121 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 124 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 127 */           this._instance.setCosName((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 130 */           this._instance.setDealerCode((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 133 */           this._instance.setPlanCode((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 136 */           this._instance.setPromoId((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 139 */           this._instance.setTransactionType((String)memberValue);
/*     */           return;
/*     */       } 
/* 142 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 145 */     catch (RuntimeException e) {
/* 146 */       throw e;
/*     */     }
/* 148 */     catch (Exception e) {
/* 149 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 157 */     this._instance = (ValidatePlanPromotionDealerRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 161 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\ValidatePlanPromotionDealerRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */