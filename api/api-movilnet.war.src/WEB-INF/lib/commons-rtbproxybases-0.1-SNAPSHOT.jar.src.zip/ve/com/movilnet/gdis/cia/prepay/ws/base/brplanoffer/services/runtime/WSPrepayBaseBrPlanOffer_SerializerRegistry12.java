/*     */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;public class WSPrepayBaseBrPlanOffer_SerializerRegistry12 implements SerializerConstants { private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO;
/*     */   
/*     */   static Class class$(String paramString) {
/*     */     
/*  21 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*     */   
/*     */   }
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS;
/*     */   public TypeMappingRegistry getRegistry(TypeMappingRegistry registry) {
/*  26 */     TypeMapping mapping12 = registry.getTypeMapping(SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_12).getURIEncoding());
/*  27 */     TypeMapping mapping = registry.getTypeMapping("");
/*     */     
/*  29 */     QName type = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan");
/*  30 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer(type, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  32 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS"), type, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  35 */     QName qName1 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateNumberSpecialServicesResponseTO");
/*  36 */     ValidateNumberSpecialServicesResponseTO_SOAPSerializer validateNumberSpecialServicesResponseTO_SOAPSerializer = new ValidateNumberSpecialServicesResponseTO_SOAPSerializer(qName1, true, true, SOAPVersion.SOAP_12);
/*     */     
/*  38 */     ReferenceableSerializerImpl referenceableSerializerImpl1 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateNumberSpecialServicesResponseTO_SOAPSerializer, SOAPVersion.SOAP_12);
/*  39 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ValidateNumberSpecialServicesResponseTO"), qName1, (Serializer)referenceableSerializerImpl1);
/*     */ 
/*     */     
/*  42 */     QName qName2 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2Response");
/*  43 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer(qName2, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  45 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS"), qName2, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer);
/*     */ 
/*     */     
/*  48 */     QName qName3 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2Response");
/*  49 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer(qName3, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  51 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS"), qName3, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer);
/*     */ 
/*     */     
/*  54 */     QName qName4 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfile");
/*  55 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer(qName4, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  57 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS"), qName4, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  60 */     QName qName5 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2");
/*  61 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer(qName5, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  63 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS"), qName5, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  66 */     QName qName6 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "RequestTO");
/*  67 */     RequestTO_InterfaceSOAPSerializer requestTO_InterfaceSOAPSerializer = new RequestTO_InterfaceSOAPSerializer(qName6, true, true, SOAPVersion.SOAP_12);
/*     */     
/*  69 */     ReferenceableSerializerImpl referenceableSerializerImpl2 = new ReferenceableSerializerImpl(true, (CombinedSerializer)requestTO_InterfaceSOAPSerializer, SOAPVersion.SOAP_12);
/*  70 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.RequestTO"), qName6, (Serializer)referenceableSerializerImpl2);
/*     */ 
/*     */     
/*  73 */     QName qName7 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanText");
/*  74 */     WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer(qName7, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  76 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS"), qName7, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  79 */     QName qName8 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunal");
/*  80 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer(qName8, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  82 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS"), qName8, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  85 */     QName qName9 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel");
/*  86 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer(qName9, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  88 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS"), qName9, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  91 */     QName qName10 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationService");
/*  92 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer(qName10, false, false, SOAPVersion.SOAP_12);
/*     */     
/*  94 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS"), qName10, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  97 */     QName qName11 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlan");
/*  98 */     WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer(qName11, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 100 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS"), qName11, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 103 */     QName qName12 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateServicesModelRequestTO");
/* 104 */     ValidateServicesModelRequestTO_SOAPSerializer validateServicesModelRequestTO_SOAPSerializer = new ValidateServicesModelRequestTO_SOAPSerializer(qName12, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 106 */     ReferenceableSerializerImpl referenceableSerializerImpl3 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateServicesModelRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 107 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO"), qName12, (Serializer)referenceableSerializerImpl3);
/*     */ 
/*     */     
/* 110 */     QName qName13 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/* 111 */     ApplicationClientTO_SOAPSerializer applicationClientTO_SOAPSerializer = new ApplicationClientTO_SOAPSerializer(qName13, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 113 */     ReferenceableSerializerImpl referenceableSerializerImpl4 = new ReferenceableSerializerImpl(true, (CombinedSerializer)applicationClientTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 114 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), qName13, (Serializer)referenceableSerializerImpl4);
/*     */ 
/*     */     
/* 117 */     QName qName14 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlanResponse");
/* 118 */     WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer(qName14, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 120 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS"), qName14, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 123 */     QName qName15 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfBenefitTO");
/* 124 */     QName elemName = new QName("", "item");
/* 125 */     QName elemType = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BenefitTO");
/* 126 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO == null); super(true, true, elemName, elemType, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO"), 1, null, SOAPVersion.SOAP_12);
/*     */     
/*     */     ObjectArraySerializer objectArraySerializer1, objectArraySerializer2;
/* 129 */     ReferenceableSerializerImpl referenceableSerializerImpl5 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer1, SOAPVersion.SOAP_12);
/* 130 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO;"), qName15, (Serializer)referenceableSerializerImpl5);
/*     */ 
/*     */     
/* 133 */     QName qName16 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/* 134 */     QName qName17 = new QName("", "item");
/* 135 */     if (class$java$lang$String == null); super(true, true, qName17, SchemaConstants.QNAME_TYPE_STRING, (QName)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), 1, null, SOAPVersion.SOAP_12);
/*     */ 
/*     */     
/* 138 */     ReferenceableSerializerImpl referenceableSerializerImpl6 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer2, SOAPVersion.SOAP_12);
/* 139 */     if (array$Ljava$lang$String == null); registerSerializer((TypeMapping)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), qName16, (Serializer)referenceableSerializerImpl6);
/*     */ 
/*     */     
/* 142 */     QName qName18 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServicesResponse");
/* 143 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer(qName18, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 145 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS"), qName18, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 148 */     QName qName19 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateAffiliationServiceRequestTO");
/* 149 */     ValidateAffiliationServiceRequestTO_SOAPSerializer validateAffiliationServiceRequestTO_SOAPSerializer = new ValidateAffiliationServiceRequestTO_SOAPSerializer(qName19, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 151 */     ReferenceableSerializerImpl referenceableSerializerImpl7 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateAffiliationServiceRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 152 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAffiliationServiceRequestTO"), qName19, (Serializer)referenceableSerializerImpl7);
/*     */ 
/*     */     
/* 155 */     QName qName20 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateServicesModelRequestTO_v2");
/* 156 */     ValidateServicesModelRequestTO_v2_SOAPSerializer validateServicesModelRequestTO_v2_SOAPSerializer = new ValidateServicesModelRequestTO_v2_SOAPSerializer(qName20, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 158 */     ReferenceableSerializerImpl referenceableSerializerImpl8 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateServicesModelRequestTO_v2_SOAPSerializer, SOAPVersion.SOAP_12);
/* 159 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO_v2"), qName20, (Serializer)referenceableSerializerImpl8);
/*     */ 
/*     */     
/* 162 */     QName qName21 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealerResponse");
/* 163 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer(qName21, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 165 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS"), qName21, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 168 */     QName qName22 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanPromotionDealerRequestTO");
/* 169 */     ValidatePlanPromotionDealerRequestTO_SOAPSerializer validatePlanPromotionDealerRequestTO_SOAPSerializer = new ValidatePlanPromotionDealerRequestTO_SOAPSerializer(qName22, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 171 */     ReferenceableSerializerImpl referenceableSerializerImpl9 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanPromotionDealerRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 172 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanPromotionDealerRequestTO"), qName22, (Serializer)referenceableSerializerImpl9);
/*     */ 
/*     */     
/* 175 */     QName qName23 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanConsejoComunalRequestTO");
/* 176 */     ValidatePlanConsejoComunalRequestTO_SOAPSerializer validatePlanConsejoComunalRequestTO_SOAPSerializer = new ValidatePlanConsejoComunalRequestTO_SOAPSerializer(qName23, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 178 */     ReferenceableSerializerImpl referenceableSerializerImpl10 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanConsejoComunalRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 179 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanConsejoComunalRequestTO"), qName23, (Serializer)referenceableSerializerImpl10);
/*     */ 
/*     */     
/* 182 */     QName qName24 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanResponseTO");
/* 183 */     ValidatePlanResponseTO_SOAPSerializer validatePlanResponseTO_SOAPSerializer = new ValidatePlanResponseTO_SOAPSerializer(qName24, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 185 */     ReferenceableSerializerImpl referenceableSerializerImpl11 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanResponseTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 186 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ValidatePlanResponseTO"), qName24, (Serializer)referenceableSerializerImpl11);
/*     */ 
/*     */     
/* 189 */     QName qName25 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BRPlanOfferResponseTO");
/* 190 */     BRPlanOfferResponseTO_SOAPSerializer bRPlanOfferResponseTO_SOAPSerializer = new BRPlanOfferResponseTO_SOAPSerializer(qName25, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 192 */     ReferenceableSerializerImpl referenceableSerializerImpl12 = new ReferenceableSerializerImpl(true, (CombinedSerializer)bRPlanOfferResponseTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 193 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO"), qName25, (Serializer)referenceableSerializerImpl12);
/*     */ 
/*     */     
/* 196 */     QName qName26 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModelResponse");
/* 197 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer(qName26, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 199 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS"), qName26, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 202 */     QName qName27 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BooleanResponseTO");
/* 203 */     BooleanResponseTO_SOAPSerializer booleanResponseTO_SOAPSerializer = new BooleanResponseTO_SOAPSerializer(qName27, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 205 */     ReferenceableSerializerImpl referenceableSerializerImpl13 = new ReferenceableSerializerImpl(true, (CombinedSerializer)booleanResponseTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 206 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO"), qName27, (Serializer)referenceableSerializerImpl13);
/*     */ 
/*     */     
/* 209 */     QName qName28 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfileResponse");
/* 210 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer(qName28, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 212 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS"), qName28, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 215 */     QName qName29 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModelResponse");
/* 216 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer(qName29, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 218 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS"), qName29, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 221 */     QName qName30 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2");
/* 222 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer(qName30, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 224 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS"), qName30, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 227 */     QName qName31 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanModelRequestTO_v2");
/* 228 */     ValidatePlanModelRequestTO_v2_SOAPSerializer validatePlanModelRequestTO_v2_SOAPSerializer = new ValidatePlanModelRequestTO_v2_SOAPSerializer(qName31, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 230 */     ReferenceableSerializerImpl referenceableSerializerImpl14 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanModelRequestTO_v2_SOAPSerializer, SOAPVersion.SOAP_12);
/* 231 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO_v2"), qName31, (Serializer)referenceableSerializerImpl14);
/*     */ 
/*     */     
/* 234 */     QName qName32 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ResponseTO");
/* 235 */     ResponseTO_InterfaceSOAPSerializer responseTO_InterfaceSOAPSerializer = new ResponseTO_InterfaceSOAPSerializer(qName32, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 237 */     ReferenceableSerializerImpl referenceableSerializerImpl15 = new ReferenceableSerializerImpl(true, (CombinedSerializer)responseTO_InterfaceSOAPSerializer, SOAPVersion.SOAP_12);
/* 238 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ResponseTO"), qName32, (Serializer)referenceableSerializerImpl15);
/*     */ 
/*     */     
/* 241 */     QName qName33 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServices");
/* 242 */     WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer(qName33, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 244 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS"), qName33, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 247 */     QName qName34 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanServicesRequestTO");
/* 248 */     ValidatePlanServicesRequestTO_SOAPSerializer validatePlanServicesRequestTO_SOAPSerializer = new ValidatePlanServicesRequestTO_SOAPSerializer(qName34, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 250 */     ReferenceableSerializerImpl referenceableSerializerImpl16 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanServicesRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 251 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanServicesRequestTO"), qName34, (Serializer)referenceableSerializerImpl16);
/*     */ 
/*     */     
/* 254 */     QName qName35 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateAuthorisedProfileResponseTO");
/* 255 */     ValidateAuthorisedProfileResponseTO_SOAPSerializer validateAuthorisedProfileResponseTO_SOAPSerializer = new ValidateAuthorisedProfileResponseTO_SOAPSerializer(qName35, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 257 */     ReferenceableSerializerImpl referenceableSerializerImpl17 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateAuthorisedProfileResponseTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 258 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ValidateAuthorisedProfileResponseTO"), qName35, (Serializer)referenceableSerializerImpl17);
/*     */ 
/*     */     
/* 261 */     QName qName36 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunalResponse");
/* 262 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer(qName36, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 264 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS"), qName36, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 267 */     QName qName37 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServices");
/* 268 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer(qName37, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 270 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS"), qName37, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 273 */     QName qName38 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateNumberSpecialServicesRequestTO");
/* 274 */     ValidateNumberSpecialServicesRequestTO_SOAPSerializer validateNumberSpecialServicesRequestTO_SOAPSerializer = new ValidateNumberSpecialServicesRequestTO_SOAPSerializer(qName38, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 276 */     ReferenceableSerializerImpl referenceableSerializerImpl18 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateNumberSpecialServicesRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 277 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateNumberSpecialServicesRequestTO"), qName38, (Serializer)referenceableSerializerImpl18);
/*     */ 
/*     */     
/* 280 */     QName qName39 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanRequestTO_v2");
/* 281 */     ValidatePlanRequestTO_v2_SOAPSerializer validatePlanRequestTO_v2_SOAPSerializer = new ValidatePlanRequestTO_v2_SOAPSerializer(qName39, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 283 */     ReferenceableSerializerImpl referenceableSerializerImpl19 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanRequestTO_v2_SOAPSerializer, SOAPVersion.SOAP_12);
/* 284 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO_v2"), qName39, (Serializer)referenceableSerializerImpl19);
/*     */ 
/*     */     
/* 287 */     QName qName40 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/* 288 */     SecurityTO_SOAPSerializer securityTO_SOAPSerializer = new SecurityTO_SOAPSerializer(qName40, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 290 */     ReferenceableSerializerImpl referenceableSerializerImpl20 = new ReferenceableSerializerImpl(true, (CombinedSerializer)securityTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 291 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), qName40, (Serializer)referenceableSerializerImpl20);
/*     */ 
/*     */     
/* 294 */     QName qName41 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanTextResponse");
/* 295 */     WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer(qName41, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 297 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS"), qName41, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 300 */     QName qName42 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionServiceResponse");
/* 301 */     WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer(qName42, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 303 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS"), qName42, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 306 */     QName qName43 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2");
/* 307 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer(qName43, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 309 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS"), qName43, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 312 */     QName qName44 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealer");
/* 313 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer(qName44, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 315 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS"), qName44, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 318 */     QName qName45 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateAuthorisedProfileRequestTO");
/* 319 */     ValidateAuthorisedProfileRequestTO_SOAPSerializer validateAuthorisedProfileRequestTO_SOAPSerializer = new ValidateAuthorisedProfileRequestTO_SOAPSerializer(qName45, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 321 */     ReferenceableSerializerImpl referenceableSerializerImpl21 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateAuthorisedProfileRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 322 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAuthorisedProfileRequestTO"), qName45, (Serializer)referenceableSerializerImpl21);
/*     */ 
/*     */     
/* 325 */     QName qName46 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionService");
/* 326 */     WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer(qName46, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 328 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS"), qName46, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 331 */     QName qName47 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2Response");
/* 332 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer(qName47, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 334 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS"), qName47, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 337 */     QName qName48 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanModelRequestTO");
/* 338 */     ValidatePlanModelRequestTO_SOAPSerializer validatePlanModelRequestTO_SOAPSerializer = new ValidatePlanModelRequestTO_SOAPSerializer(qName48, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 340 */     ReferenceableSerializerImpl referenceableSerializerImpl22 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanModelRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 341 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO"), qName48, (Serializer)referenceableSerializerImpl22);
/*     */ 
/*     */     
/* 344 */     QName qName49 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel");
/* 345 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer(qName49, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 347 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS"), qName49, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 350 */     QName qName50 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateChangeBRPlanRequestTO");
/* 351 */     ValidateChangeBRPlanRequestTO_SOAPSerializer validateChangeBRPlanRequestTO_SOAPSerializer = new ValidateChangeBRPlanRequestTO_SOAPSerializer(qName50, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 353 */     ReferenceableSerializerImpl referenceableSerializerImpl23 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateChangeBRPlanRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 354 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangeBRPlanRequestTO"), qName50, (Serializer)referenceableSerializerImpl23);
/*     */ 
/*     */     
/* 357 */     QName qName51 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServicesResponse");
/* 358 */     WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer(qName51, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 360 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS"), qName51, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 363 */     QName qName52 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BenefitTO");
/* 364 */     BenefitTO_SOAPSerializer benefitTO_SOAPSerializer = new BenefitTO_SOAPSerializer(qName52, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 366 */     ReferenceableSerializerImpl referenceableSerializerImpl24 = new ReferenceableSerializerImpl(true, (CombinedSerializer)benefitTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 367 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO"), qName52, (Serializer)referenceableSerializerImpl24);
/*     */ 
/*     */     
/* 370 */     QName qName53 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanRequestTO");
/* 371 */     ValidatePlanRequestTO_SOAPSerializer validatePlanRequestTO_SOAPSerializer = new ValidatePlanRequestTO_SOAPSerializer(qName53, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 373 */     ReferenceableSerializerImpl referenceableSerializerImpl25 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 374 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO"), qName53, (Serializer)referenceableSerializerImpl25);
/*     */ 
/*     */     
/* 377 */     QName qName54 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateDisConnectionServiceRequestTO");
/* 378 */     ValidateDisConnectionServiceRequestTO_SOAPSerializer validateDisConnectionServiceRequestTO_SOAPSerializer = new ValidateDisConnectionServiceRequestTO_SOAPSerializer(qName54, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 380 */     ReferenceableSerializerImpl referenceableSerializerImpl26 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateDisConnectionServiceRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 381 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateDisConnectionServiceRequestTO"), qName54, (Serializer)referenceableSerializerImpl26);
/*     */ 
/*     */     
/* 384 */     QName qName55 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateChangePlanTextRequestTO");
/* 385 */     ValidateChangePlanTextRequestTO_SOAPSerializer validateChangePlanTextRequestTO_SOAPSerializer = new ValidateChangePlanTextRequestTO_SOAPSerializer(qName55, true, true, SOAPVersion.SOAP_12);
/*     */     
/* 387 */     ReferenceableSerializerImpl referenceableSerializerImpl27 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateChangePlanTextRequestTO_SOAPSerializer, SOAPVersion.SOAP_12);
/* 388 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangePlanTextRequestTO"), qName55, (Serializer)referenceableSerializerImpl27);
/*     */ 
/*     */     
/* 391 */     QName qName56 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationServiceResponse");
/* 392 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer(qName56, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 394 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS"), qName56, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 397 */     QName qName57 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanResponse");
/* 398 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer(qName57, false, false, SOAPVersion.SOAP_12);
/*     */     
/* 400 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS"), qName57, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer);
/*     */     
/* 402 */     return registry;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void registerSerializer(TypeMapping mapping, Class javaType, QName xmlType, Serializer ser) {
/* 407 */     mapping.register(javaType, xmlType, (SerializerFactory)new SingletonSerializerFactory(ser), (DeserializerFactory)new SingletonDeserializerFactory((Deserializer)ser));
/*     */   } }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOffer_SerializerRegistry12.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */