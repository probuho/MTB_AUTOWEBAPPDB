/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.ValidatePlanResponseTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatePlanResponseTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidatePlanResponseTO _instance;
/*     */   private long executionTime;
/*     */   private String origin;
/*     */   private String responseCode;
/*     */   private String responseDescription;
/*     */   private String responseMessage;
/*     */   private String responseSubCode;
/*     */   private String transactionId;
/*     */   private short maxGeneralQuantity;
/*     */   private short maxQuantityPerTecnology;
/*     */   private boolean result;
/*     */   private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static final int mymaxGeneralQuantity_INDEX = 7;
/*     */   private static final int mymaxQuantityPerTecnology_INDEX = 8;
/*     */   private static final int myresult_INDEX = 9;
/*     */   
/*     */   public void setExecutionTime(long executionTime) {
/*  39 */     this.executionTime = executionTime;
/*     */   }
/*     */   
/*     */   public void setOrigin(String origin) {
/*  43 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public void setResponseCode(String responseCode) {
/*  47 */     this.responseCode = responseCode;
/*     */   }
/*     */   
/*     */   public void setResponseDescription(String responseDescription) {
/*  51 */     this.responseDescription = responseDescription;
/*     */   }
/*     */   
/*     */   public void setResponseMessage(String responseMessage) {
/*  55 */     this.responseMessage = responseMessage;
/*     */   }
/*     */   
/*     */   public void setResponseSubCode(String responseSubCode) {
/*  59 */     this.responseSubCode = responseSubCode;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  63 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setMaxGeneralQuantity(short maxGeneralQuantity) {
/*  67 */     this.maxGeneralQuantity = maxGeneralQuantity;
/*     */   }
/*     */   
/*     */   public void setMaxQuantityPerTecnology(short maxQuantityPerTecnology) {
/*  71 */     this.maxQuantityPerTecnology = maxQuantityPerTecnology;
/*     */   }
/*     */   
/*     */   public void setResult(boolean result) {
/*  75 */     this.result = result;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  79 */     switch (memberIndex) {
/*     */       case 0:
/*  81 */         return 6;
/*     */       case 1:
/*  83 */         return 6;
/*     */       case 2:
/*  85 */         return 6;
/*     */       case 3:
/*  87 */         return 6;
/*     */       case 4:
/*  89 */         return 6;
/*     */       case 5:
/*  91 */         return 6;
/*     */       case 6:
/*  93 */         return 6;
/*     */       case 7:
/*  95 */         return 6;
/*     */       case 8:
/*  97 */         return 6;
/*     */       case 9:
/*  99 */         return 6;
/*     */     } 
/* 101 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 110 */       switch (index) {
/*     */         case 0:
/* 112 */           this._instance.setExecutionTime(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 1:
/* 115 */           this._instance.setOrigin((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 118 */           this._instance.setResponseCode((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 121 */           this._instance.setResponseDescription((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 124 */           this._instance.setResponseMessage((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 127 */           this._instance.setResponseSubCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 130 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 133 */           this._instance.setMaxGeneralQuantity(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 8:
/* 136 */           this._instance.setMaxQuantityPerTecnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 9:
/* 139 */           this._instance.setResult(((Boolean)memberValue).booleanValue());
/*     */           return;
/*     */       } 
/* 142 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 145 */     catch (RuntimeException e) {
/* 146 */       throw e;
/*     */     }
/* 148 */     catch (Exception e) {
/* 149 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 157 */     this._instance = (ValidatePlanResponseTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 161 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\runtime\ValidatePlanResponseTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */