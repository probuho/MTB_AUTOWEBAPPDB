/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BalanceListTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String adjustmentInd;
/*     */   protected String balanceCommercialName;
/*     */   protected int balanceId;
/*     */   protected String balanceName;
/*     */   protected String balanceSubType;
/*     */   protected String balanceType;
/*     */   protected double conversionFactor;
/*     */   protected String decimalInd;
/*     */   protected String taxInd;
/*     */   protected String unitCommercialName;
/*     */   
/*     */   public String getAdjustmentInd() {
/*  26 */     return this.adjustmentInd;
/*     */   }
/*     */   
/*     */   public void setAdjustmentInd(String adjustmentInd) {
/*  30 */     this.adjustmentInd = adjustmentInd;
/*     */   }
/*     */   
/*     */   public String getBalanceCommercialName() {
/*  34 */     return this.balanceCommercialName;
/*     */   }
/*     */   
/*     */   public void setBalanceCommercialName(String balanceCommercialName) {
/*  38 */     this.balanceCommercialName = balanceCommercialName;
/*     */   }
/*     */   
/*     */   public int getBalanceId() {
/*  42 */     return this.balanceId;
/*     */   }
/*     */   
/*     */   public void setBalanceId(int balanceId) {
/*  46 */     this.balanceId = balanceId;
/*     */   }
/*     */   
/*     */   public String getBalanceName() {
/*  50 */     return this.balanceName;
/*     */   }
/*     */   
/*     */   public void setBalanceName(String balanceName) {
/*  54 */     this.balanceName = balanceName;
/*     */   }
/*     */   
/*     */   public String getBalanceSubType() {
/*  58 */     return this.balanceSubType;
/*     */   }
/*     */   
/*     */   public void setBalanceSubType(String balanceSubType) {
/*  62 */     this.balanceSubType = balanceSubType;
/*     */   }
/*     */   
/*     */   public String getBalanceType() {
/*  66 */     return this.balanceType;
/*     */   }
/*     */   
/*     */   public void setBalanceType(String balanceType) {
/*  70 */     this.balanceType = balanceType;
/*     */   }
/*     */   
/*     */   public double getConversionFactor() {
/*  74 */     return this.conversionFactor;
/*     */   }
/*     */   
/*     */   public void setConversionFactor(double conversionFactor) {
/*  78 */     this.conversionFactor = conversionFactor;
/*     */   }
/*     */   
/*     */   public String getDecimalInd() {
/*  82 */     return this.decimalInd;
/*     */   }
/*     */   
/*     */   public void setDecimalInd(String decimalInd) {
/*  86 */     this.decimalInd = decimalInd;
/*     */   }
/*     */   
/*     */   public String getTaxInd() {
/*  90 */     return this.taxInd;
/*     */   }
/*     */   
/*     */   public void setTaxInd(String taxInd) {
/*  94 */     this.taxInd = taxInd;
/*     */   }
/*     */   
/*     */   public String getUnitCommercialName() {
/*  98 */     return this.unitCommercialName;
/*     */   }
/*     */   
/*     */   public void setUnitCommercialName(String unitCommercialName) {
/* 102 */     this.unitCommercialName = unitCommercialName;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\BalanceListTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */