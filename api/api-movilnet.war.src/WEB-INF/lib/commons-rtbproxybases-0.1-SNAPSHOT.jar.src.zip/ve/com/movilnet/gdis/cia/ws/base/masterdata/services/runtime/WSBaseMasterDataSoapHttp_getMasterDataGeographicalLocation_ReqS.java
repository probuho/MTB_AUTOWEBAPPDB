/*    */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected MasterDataRequestTO masterRequest;
/*    */   
/*    */   public MasterDataRequestTO getMasterRequest() {
/* 17 */     return this.masterRequest;
/*    */   }
/*    */   
/*    */   public void setMasterRequest(MasterDataRequestTO masterRequest) {
/* 21 */     this.masterRequest = masterRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\runtime\WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */