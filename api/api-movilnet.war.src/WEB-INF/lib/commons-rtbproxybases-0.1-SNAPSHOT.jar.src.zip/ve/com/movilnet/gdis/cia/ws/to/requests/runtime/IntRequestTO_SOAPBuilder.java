/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.IntRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private IntRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private int value;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myvalue_INDEX = 5;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  31 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  35 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  39 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  43 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  47 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setValue(int value) {
/*  51 */     this.value = value;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  55 */     switch (memberIndex) {
/*     */       case 0:
/*  57 */         return 6;
/*     */       case 1:
/*  59 */         return 6;
/*     */       case 2:
/*  61 */         return 6;
/*     */       case 3:
/*  63 */         return 6;
/*     */       case 4:
/*  65 */         return 6;
/*     */       case 5:
/*  67 */         return 6;
/*     */     } 
/*  69 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/*  78 */       switch (index) {
/*     */         case 0:
/*  80 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/*  83 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/*  86 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/*  89 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/*  92 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/*  95 */           this._instance.setValue(((Integer)memberValue).intValue());
/*     */           return;
/*     */       } 
/*  98 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 101 */     catch (RuntimeException e) {
/* 102 */       throw e;
/*     */     }
/* 104 */     catch (Exception e) {
/* 105 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 113 */     this._instance = (IntRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 117 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\IntRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */