/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommunalCouncilChargeTO
/*    */   implements Serializable
/*    */ {
/*    */   protected int cargoId;
/*    */   protected String cargos;
/*    */   
/*    */   public int getCargoId() {
/* 18 */     return this.cargoId;
/*    */   }
/*    */   
/*    */   public void setCargoId(int cargoId) {
/* 22 */     this.cargoId = cargoId;
/*    */   }
/*    */   
/*    */   public String getCargos() {
/* 26 */     return this.cargos;
/*    */   }
/*    */   
/*    */   public void setCargos(String cargos) {
/* 30 */     this.cargos = cargos;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\CommunalCouncilChargeTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */