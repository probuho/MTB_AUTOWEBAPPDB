/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidatePlanRequestTO_v2
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String aplicationType;
/*    */   protected String customerType;
/*    */   protected String[] entrada;
/*    */   protected String planCode;
/*    */   protected String planCosName;
/*    */   protected String ssn;
/*    */   protected long subscriberId;
/*    */   protected String transactionType;
/*    */   
/*    */   public String getAplicationType() {
/* 24 */     return this.aplicationType;
/*    */   }
/*    */   
/*    */   public void setAplicationType(String aplicationType) {
/* 28 */     this.aplicationType = aplicationType;
/*    */   }
/*    */   
/*    */   public String getCustomerType() {
/* 32 */     return this.customerType;
/*    */   }
/*    */   
/*    */   public void setCustomerType(String customerType) {
/* 36 */     this.customerType = customerType;
/*    */   }
/*    */   
/*    */   public String[] getEntrada() {
/* 40 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(String[] entrada) {
/* 44 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 48 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 52 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getPlanCosName() {
/* 56 */     return this.planCosName;
/*    */   }
/*    */   
/*    */   public void setPlanCosName(String planCosName) {
/* 60 */     this.planCosName = planCosName;
/*    */   }
/*    */   
/*    */   public String getSsn() {
/* 64 */     return this.ssn;
/*    */   }
/*    */   
/*    */   public void setSsn(String ssn) {
/* 68 */     this.ssn = ssn;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 72 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 76 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 80 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 84 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidatePlanRequestTO_v2.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */