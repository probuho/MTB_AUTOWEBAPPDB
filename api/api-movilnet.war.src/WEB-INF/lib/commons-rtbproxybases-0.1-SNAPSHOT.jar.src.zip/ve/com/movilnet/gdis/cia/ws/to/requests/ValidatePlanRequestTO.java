/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidatePlanRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String[] entrada;
/*    */   protected String planCode;
/*    */   protected String planCosName;
/*    */   protected String ssn;
/*    */   protected long subscriberId;
/*    */   protected String transactionType;
/*    */   
/*    */   public String[] getEntrada() {
/* 22 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(String[] entrada) {
/* 26 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 30 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 34 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getPlanCosName() {
/* 38 */     return this.planCosName;
/*    */   }
/*    */   
/*    */   public void setPlanCosName(String planCosName) {
/* 42 */     this.planCosName = planCosName;
/*    */   }
/*    */   
/*    */   public String getSsn() {
/* 46 */     return this.ssn;
/*    */   }
/*    */   
/*    */   public void setSsn(String ssn) {
/* 50 */     this.ssn = ssn;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 54 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 58 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 62 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 66 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidatePlanRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */