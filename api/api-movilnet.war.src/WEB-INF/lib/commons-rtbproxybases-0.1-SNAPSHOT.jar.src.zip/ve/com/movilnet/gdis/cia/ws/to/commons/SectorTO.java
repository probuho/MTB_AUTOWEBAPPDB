/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SectorTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String clasificacion;
/*    */   protected String parroquiaCode;
/*    */   protected String sectorCode;
/*    */   protected String sectorName;
/*    */   
/*    */   public String getClasificacion() {
/* 20 */     return this.clasificacion;
/*    */   }
/*    */   
/*    */   public void setClasificacion(String clasificacion) {
/* 24 */     this.clasificacion = clasificacion;
/*    */   }
/*    */   
/*    */   public String getParroquiaCode() {
/* 28 */     return this.parroquiaCode;
/*    */   }
/*    */   
/*    */   public void setParroquiaCode(String parroquiaCode) {
/* 32 */     this.parroquiaCode = parroquiaCode;
/*    */   }
/*    */   
/*    */   public String getSectorCode() {
/* 36 */     return this.sectorCode;
/*    */   }
/*    */   
/*    */   public void setSectorCode(String sectorCode) {
/* 40 */     this.sectorCode = sectorCode;
/*    */   }
/*    */   
/*    */   public String getSectorName() {
/* 44 */     return this.sectorName;
/*    */   }
/*    */   
/*    */   public void setSectorName(String sectorName) {
/* 48 */     this.sectorName = sectorName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\SectorTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */