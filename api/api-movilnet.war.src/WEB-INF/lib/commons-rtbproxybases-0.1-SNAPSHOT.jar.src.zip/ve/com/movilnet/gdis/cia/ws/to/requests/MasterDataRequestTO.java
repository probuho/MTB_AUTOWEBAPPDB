/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MasterDataRequestTO
/*     */   extends RequestTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String accountType;
/*     */   protected String categoryCode;
/*     */   protected String cosName;
/*     */   protected String iniCode;
/*     */   protected String razonType;
/*     */   protected String screenType;
/*     */   protected long subscriberId;
/*     */   protected String transactionType;
/*     */   protected String userId;
/*     */   protected int value;
/*     */   
/*     */   public String getAccountType() {
/*  26 */     return this.accountType;
/*     */   }
/*     */   
/*     */   public void setAccountType(String accountType) {
/*  30 */     this.accountType = accountType;
/*     */   }
/*     */   
/*     */   public String getCategoryCode() {
/*  34 */     return this.categoryCode;
/*     */   }
/*     */   
/*     */   public void setCategoryCode(String categoryCode) {
/*  38 */     this.categoryCode = categoryCode;
/*     */   }
/*     */   
/*     */   public String getCosName() {
/*  42 */     return this.cosName;
/*     */   }
/*     */   
/*     */   public void setCosName(String cosName) {
/*  46 */     this.cosName = cosName;
/*     */   }
/*     */   
/*     */   public String getIniCode() {
/*  50 */     return this.iniCode;
/*     */   }
/*     */   
/*     */   public void setIniCode(String iniCode) {
/*  54 */     this.iniCode = iniCode;
/*     */   }
/*     */   
/*     */   public String getRazonType() {
/*  58 */     return this.razonType;
/*     */   }
/*     */   
/*     */   public void setRazonType(String razonType) {
/*  62 */     this.razonType = razonType;
/*     */   }
/*     */   
/*     */   public String getScreenType() {
/*  66 */     return this.screenType;
/*     */   }
/*     */   
/*     */   public void setScreenType(String screenType) {
/*  70 */     this.screenType = screenType;
/*     */   }
/*     */   
/*     */   public long getSubscriberId() {
/*  74 */     return this.subscriberId;
/*     */   }
/*     */   
/*     */   public void setSubscriberId(long subscriberId) {
/*  78 */     this.subscriberId = subscriberId;
/*     */   }
/*     */   
/*     */   public String getTransactionType() {
/*  82 */     return this.transactionType;
/*     */   }
/*     */   
/*     */   public void setTransactionType(String transactionType) {
/*  86 */     this.transactionType = transactionType;
/*     */   }
/*     */   
/*     */   public String getUserId() {
/*  90 */     return this.userId;
/*     */   }
/*     */   
/*     */   public void setUserId(String userId) {
/*  94 */     this.userId = userId;
/*     */   }
/*     */   
/*     */   public int getValue() {
/*  98 */     return this.value;
/*     */   }
/*     */   
/*     */   public void setValue(int value) {
/* 102 */     this.value = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\MasterDataRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */