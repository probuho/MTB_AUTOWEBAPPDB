/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidatePlanServicesRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String[] alcsList;
/*    */   protected String cosName;
/*    */   protected String planCode;
/*    */   protected long subscriberId;
/*    */   protected String transactionType;
/*    */   
/*    */   public String[] getAlcsList() {
/* 21 */     return this.alcsList;
/*    */   }
/*    */   
/*    */   public void setAlcsList(String[] alcsList) {
/* 25 */     this.alcsList = alcsList;
/*    */   }
/*    */   
/*    */   public String getCosName() {
/* 29 */     return this.cosName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 33 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 37 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 41 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 45 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 49 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 53 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 57 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidatePlanServicesRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */