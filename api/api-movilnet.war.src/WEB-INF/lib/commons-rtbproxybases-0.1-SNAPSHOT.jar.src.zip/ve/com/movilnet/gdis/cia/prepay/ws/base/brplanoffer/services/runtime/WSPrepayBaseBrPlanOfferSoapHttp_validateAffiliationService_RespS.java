/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS
/*    */   implements Serializable
/*    */ {
/*    */   protected BRPlanOfferResponseTO result;
/*    */   
/*    */   public BRPlanOfferResponseTO getResult() {
/* 17 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(BRPlanOfferResponseTO result) {
/* 21 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */