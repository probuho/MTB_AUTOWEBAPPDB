/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAffiliationServiceRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidateAffiliationServiceRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidateAffiliationServiceRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String[] alcsList;
/*     */   private String cosName;
/*     */   private String phoneTypeId;
/*     */   private String serviceCode;
/*     */   private String status;
/*     */   private long subscriberId;
/*     */   private String userId;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myalcsList_INDEX = 5;
/*     */   private static final int mycosName_INDEX = 6;
/*     */   private static final int myphoneTypeId_INDEX = 7;
/*     */   private static final int myserviceCode_INDEX = 8;
/*     */   private static final int mystatus_INDEX = 9;
/*     */   private static final int mysubscriberId_INDEX = 10;
/*     */   private static final int myuserId_INDEX = 11;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  43 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  47 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  51 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  55 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  59 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAlcsList(String[] alcsList) {
/*  63 */     this.alcsList = alcsList;
/*     */   }
/*     */   
/*     */   public void setCosName(String cosName) {
/*  67 */     this.cosName = cosName;
/*     */   }
/*     */   
/*     */   public void setPhoneTypeId(String phoneTypeId) {
/*  71 */     this.phoneTypeId = phoneTypeId;
/*     */   }
/*     */   
/*     */   public void setServiceCode(String serviceCode) {
/*  75 */     this.serviceCode = serviceCode;
/*     */   }
/*     */   
/*     */   public void setStatus(String status) {
/*  79 */     this.status = status;
/*     */   }
/*     */   
/*     */   public void setSubscriberId(long subscriberId) {
/*  83 */     this.subscriberId = subscriberId;
/*     */   }
/*     */   
/*     */   public void setUserId(String userId) {
/*  87 */     this.userId = userId;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  91 */     switch (memberIndex) {
/*     */       case 0:
/*  93 */         return 6;
/*     */       case 1:
/*  95 */         return 6;
/*     */       case 2:
/*  97 */         return 6;
/*     */       case 3:
/*  99 */         return 6;
/*     */       case 4:
/* 101 */         return 6;
/*     */       case 5:
/* 103 */         return 6;
/*     */       case 6:
/* 105 */         return 6;
/*     */       case 7:
/* 107 */         return 6;
/*     */       case 8:
/* 109 */         return 6;
/*     */       case 9:
/* 111 */         return 6;
/*     */       case 10:
/* 113 */         return 6;
/*     */       case 11:
/* 115 */         return 6;
/*     */     } 
/* 117 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 126 */       switch (index) {
/*     */         case 0:
/* 128 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/* 131 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/* 134 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 137 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 140 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 143 */           this._instance.setAlcsList((String[])memberValue);
/*     */           return;
/*     */         case 6:
/* 146 */           this._instance.setCosName((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 149 */           this._instance.setPhoneTypeId((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 152 */           this._instance.setServiceCode((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 155 */           this._instance.setStatus((String)memberValue);
/*     */           return;
/*     */         case 10:
/* 158 */           this._instance.setSubscriberId(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 11:
/* 161 */           this._instance.setUserId((String)memberValue);
/*     */           return;
/*     */       } 
/* 164 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 167 */     catch (RuntimeException e) {
/* 168 */       throw e;
/*     */     }
/* 170 */     catch (Exception e) {
/* 171 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 179 */     this._instance = (ValidateAffiliationServiceRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 183 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\ValidateAffiliationServiceRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */