/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateAuthorisedProfileRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String aplicationType;
/*    */   protected String customerType;
/*    */   protected String[] genfield;
/*    */   protected String planCode;
/*    */   protected String serviceCode;
/*    */   protected String transactionType;
/*    */   protected String userSsnId;
/*    */   
/*    */   public String getAplicationType() {
/* 23 */     return this.aplicationType;
/*    */   }
/*    */   
/*    */   public void setAplicationType(String aplicationType) {
/* 27 */     this.aplicationType = aplicationType;
/*    */   }
/*    */   
/*    */   public String getCustomerType() {
/* 31 */     return this.customerType;
/*    */   }
/*    */   
/*    */   public void setCustomerType(String customerType) {
/* 35 */     this.customerType = customerType;
/*    */   }
/*    */   
/*    */   public String[] getGenfield() {
/* 39 */     return this.genfield;
/*    */   }
/*    */   
/*    */   public void setGenfield(String[] genfield) {
/* 43 */     this.genfield = genfield;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 47 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 51 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getServiceCode() {
/* 55 */     return this.serviceCode;
/*    */   }
/*    */   
/*    */   public void setServiceCode(String serviceCode) {
/* 59 */     this.serviceCode = serviceCode;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 63 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 67 */     this.transactionType = transactionType;
/*    */   }
/*    */   
/*    */   public String getUserSsnId() {
/* 71 */     return this.userSsnId;
/*    */   }
/*    */   
/*    */   public void setUserSsnId(String userSsnId) {
/* 75 */     this.userSsnId = userSsnId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateAuthorisedProfileRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */