/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PhoneModelTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String phoneName;
/*    */   protected String phoneTypeId;
/*    */   protected String sapMaterialCode;
/*    */   
/*    */   public String getPhoneName() {
/* 19 */     return this.phoneName;
/*    */   }
/*    */   
/*    */   public void setPhoneName(String phoneName) {
/* 23 */     this.phoneName = phoneName;
/*    */   }
/*    */   
/*    */   public String getPhoneTypeId() {
/* 27 */     return this.phoneTypeId;
/*    */   }
/*    */   
/*    */   public void setPhoneTypeId(String phoneTypeId) {
/* 31 */     this.phoneTypeId = phoneTypeId;
/*    */   }
/*    */   
/*    */   public String getSapMaterialCode() {
/* 35 */     return this.sapMaterialCode;
/*    */   }
/*    */   
/*    */   public void setSapMaterialCode(String sapMaterialCode) {
/* 39 */     this.sapMaterialCode = sapMaterialCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\PhoneModelTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */