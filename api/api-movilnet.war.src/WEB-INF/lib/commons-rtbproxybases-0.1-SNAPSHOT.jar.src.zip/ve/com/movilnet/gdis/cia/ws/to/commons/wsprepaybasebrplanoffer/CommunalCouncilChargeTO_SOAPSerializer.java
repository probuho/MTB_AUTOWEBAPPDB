/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.CommunalCouncilChargeTO_SOAPBuilder;
/*     */ 
/*     */ public class CommunalCouncilChargeTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_cargoId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cargoId");
/*  20 */   private static final QName ns3_int_TYPE_QNAME = SchemaConstants.QNAME_TYPE_INT;
/*     */   private CombinedSerializer myns3__int__int_Int_Serializer;
/*  22 */   private static final QName ns2_cargos_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cargos");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING; private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*     */   private static final int mycargoId_INDEX = 0;
/*     */   private static final int mycargos_INDEX = 1;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public CommunalCouncilChargeTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  29 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  33 */     this.myns3__int__int_Int_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), int.class, ns3_int_TYPE_QNAME);
/*  34 */     if (class$java$lang$String == null); ((CommunalCouncilChargeTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  39 */     CommunalCouncilChargeTO instance = new CommunalCouncilChargeTO();
/*  40 */     CommunalCouncilChargeTO_SOAPBuilder builder = null;
/*     */     
/*  42 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  45 */     reader.nextElementContent();
/*  46 */     QName startName = reader.getName();
/*  47 */     for (int i = 0; i < 2; i++) {
/*  48 */       QName elementName = reader.getName();
/*  49 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  52 */       if (matchQName(elementName, ns2_cargoId_QNAME)) {
/*  53 */         context.setNillable(true);
/*  54 */         Object member = this.myns3__int__int_Int_Serializer.deserialize(ns2_cargoId_QNAME, reader, context);
/*  55 */         if (member instanceof SOAPDeserializationState) {
/*  56 */           if (builder == null) {
/*  57 */             builder = new CommunalCouncilChargeTO_SOAPBuilder();
/*     */           }
/*  59 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  60 */           isComplete = false;
/*  61 */         } else if (member != null) {
/*  62 */           instance.setCargoId(((Integer)member).intValue());
/*     */         } 
/*  64 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  67 */       else if (matchQName(elementName, ns2_cargos_QNAME)) {
/*  68 */         context.setNillable(true);
/*  69 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cargos_QNAME, reader, context);
/*  70 */         if (object instanceof SOAPDeserializationState) {
/*  71 */           if (builder == null) {
/*  72 */             builder = new CommunalCouncilChargeTO_SOAPBuilder();
/*     */           }
/*  74 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  75 */           isComplete = false;
/*  76 */         } else if (object != null) {
/*  77 */           instance.setCargos((String)object);
/*     */         } 
/*  79 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/*  82 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_cargos_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/*  87 */       XMLReaderUtil.verifyReaderState(reader, 2);
/*  88 */     } catch (XMLReaderException xmle) {
/*  89 */       if (startName != null) {
/*  90 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/*  92 */       throw xmle;
/*     */     } 
/*     */     
/*  95 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/*  99 */     CommunalCouncilChargeTO instance = (CommunalCouncilChargeTO)obj;
/*     */     
/* 101 */     context.setNillable(true);
/* 102 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getCargoId()), ns2_cargoId_QNAME, null, writer, context);
/* 103 */     context.setNillable(true);
/* 104 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCargos(), ns2_cargos_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\CommunalCouncilChargeTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */