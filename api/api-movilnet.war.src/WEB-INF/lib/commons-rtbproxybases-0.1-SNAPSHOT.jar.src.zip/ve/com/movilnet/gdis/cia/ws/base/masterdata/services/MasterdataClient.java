/*     */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.xml.rpc.ServiceFactory;
/*     */ import javax.xml.rpc.Stub;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO;
/*     */ 
/*     */ public class MasterdataClient {
/*     */   private IWSBaseMasterData _port;
/*     */   
/*     */   static Class class$(String paramString) {
/*     */     
/*  13 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*     */   
/*     */   } private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$WSBaseMasterData;
/*     */   public MasterdataClient() throws Exception {
/*  17 */     ServiceFactory factory = ServiceFactory.newInstance();
/*  18 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$WSBaseMasterData == null); ((MasterdataClient)factory)._port = ((WSBaseMasterData)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$WSBaseMasterData.loadService(class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$WSBaseMasterData = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.WSBaseMasterData"))).getMasterdata();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*  26 */       MasterdataClient myPort = new MasterdataClient();
/*  27 */       System.out.println("calling " + myPort.getEndpoint());
/*     */     
/*     */     }
/*  30 */     catch (Exception ex) {
/*  31 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AlcoCosResponseTO getMasterDataAlcoAndCos(IntRequestTO request) throws RemoteException {
/*  40 */     return this._port.getMasterDataAlcoAndCos(request);
/*     */   }
/*     */   
/*     */   public MasterDataResponseTO getMasterDataGeographicalLocation(MasterDataRequestTO masterRequest) throws RemoteException {
/*  44 */     return this._port.getMasterDataGeographicalLocation(masterRequest);
/*     */   }
/*     */   
/*     */   public MasterDataResponseTO getMasterDataPersonalData(MasterDataRequestTO masterRequest) throws RemoteException {
/*  48 */     return this._port.getMasterDataPersonalData(masterRequest);
/*     */   }
/*     */   
/*     */   public MasterDataResponseTO getMasterDataProductAndService(MasterDataRequestTO masterRequest) throws RemoteException {
/*  52 */     return this._port.getMasterDataProductAndService(masterRequest);
/*     */   }
/*     */   
/*     */   public MasterDataResponseTO_v2 getMasterDataProductAndService2(MasterDataRequestTO masterRequest) throws RemoteException {
/*  56 */     return this._port.getMasterDataProductAndService2(masterRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IWSBaseMasterData getPort() {
/*  65 */     return this._port;
/*     */   }
/*     */   
/*     */   public String getEndpoint() {
/*  69 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.service.endpoint.address");
/*     */   }
/*     */   
/*     */   public void setEndpoint(String endpoint) {
/*  73 */     ((Stub)this._port)._setProperty("javax.xml.rpc.service.endpoint.address", endpoint);
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  77 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.security.auth.password");
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  81 */     ((Stub)this._port)._setProperty("javax.xml.rpc.security.auth.password", password);
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  85 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.security.auth.username");
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  89 */     ((Stub)this._port)._setProperty("javax.xml.rpc.security.auth.username", username);
/*     */   }
/*     */   
/*     */   public void setMaintainSession(boolean maintainSession) {
/*  93 */     ((Stub)this._port)._setProperty("javax.xml.rpc.session.maintain", Boolean.valueOf(maintainSession));
/*     */   }
/*     */   
/*     */   public boolean getMaintainSession() {
/*  97 */     return ((Boolean)((Stub)this._port)._getProperty("javax.xml.rpc.session.maintain")).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientTransport getClientTransport() {
/* 104 */     return ((OracleStub)this._port).getClientTransport();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\MasterdataClient.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */