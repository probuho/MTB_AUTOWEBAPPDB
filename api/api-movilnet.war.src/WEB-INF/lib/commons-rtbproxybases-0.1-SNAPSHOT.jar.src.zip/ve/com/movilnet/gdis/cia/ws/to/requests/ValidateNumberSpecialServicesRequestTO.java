/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateNumberSpecialServicesRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String alcoName;
/*    */   protected String newPhonebookNo;
/*    */   protected String[] phonebookList;
/*    */   protected long subscriberId;
/*    */   protected String transactionType;
/*    */   
/*    */   public String getAlcoName() {
/* 21 */     return this.alcoName;
/*    */   }
/*    */   
/*    */   public void setAlcoName(String alcoName) {
/* 25 */     this.alcoName = alcoName;
/*    */   }
/*    */   
/*    */   public String getNewPhonebookNo() {
/* 29 */     return this.newPhonebookNo;
/*    */   }
/*    */   
/*    */   public void setNewPhonebookNo(String newPhonebookNo) {
/* 33 */     this.newPhonebookNo = newPhonebookNo;
/*    */   }
/*    */   
/*    */   public String[] getPhonebookList() {
/* 37 */     return this.phonebookList;
/*    */   }
/*    */   
/*    */   public void setPhonebookList(String[] phonebookList) {
/* 41 */     this.phonebookList = phonebookList;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 45 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 49 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 53 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 57 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateNumberSpecialServicesRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */