/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BenefitTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private BenefitTO _instance;
/*     */   private String balanceName;
/*     */   private String chargeCode;
/*     */   private String comment;
/*     */   private Integer expirationDays;
/*     */   private String operation;
/*     */   private Long quantity;
/*     */   private String unitType;
/*     */   private static final int mybalanceName_INDEX = 0;
/*     */   private static final int mychargeCode_INDEX = 1;
/*     */   private static final int mycomment_INDEX = 2;
/*     */   private static final int myexpirationDays_INDEX = 3;
/*     */   private static final int myoperation_INDEX = 4;
/*     */   private static final int myquantity_INDEX = 5;
/*     */   private static final int myunitType_INDEX = 6;
/*     */   
/*     */   public void setBalanceName(String balanceName) {
/*  33 */     this.balanceName = balanceName;
/*     */   }
/*     */   
/*     */   public void setChargeCode(String chargeCode) {
/*  37 */     this.chargeCode = chargeCode;
/*     */   }
/*     */   
/*     */   public void setComment(String comment) {
/*  41 */     this.comment = comment;
/*     */   }
/*     */   
/*     */   public void setExpirationDays(Integer expirationDays) {
/*  45 */     this.expirationDays = expirationDays;
/*     */   }
/*     */   
/*     */   public void setOperation(String operation) {
/*  49 */     this.operation = operation;
/*     */   }
/*     */   
/*     */   public void setQuantity(Long quantity) {
/*  53 */     this.quantity = quantity;
/*     */   }
/*     */   
/*     */   public void setUnitType(String unitType) {
/*  57 */     this.unitType = unitType;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  61 */     switch (memberIndex) {
/*     */       case 0:
/*  63 */         return 6;
/*     */       case 1:
/*  65 */         return 6;
/*     */       case 2:
/*  67 */         return 6;
/*     */       case 3:
/*  69 */         return 6;
/*     */       case 4:
/*  71 */         return 6;
/*     */       case 5:
/*  73 */         return 6;
/*     */       case 6:
/*  75 */         return 6;
/*     */     } 
/*  77 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/*  86 */       switch (index) {
/*     */         case 0:
/*  88 */           this._instance.setBalanceName((String)memberValue);
/*     */           return;
/*     */         case 1:
/*  91 */           this._instance.setChargeCode((String)memberValue);
/*     */           return;
/*     */         case 2:
/*  94 */           this._instance.setComment((String)memberValue);
/*     */           return;
/*     */         case 3:
/*  97 */           this._instance.setExpirationDays((Integer)memberValue);
/*     */           return;
/*     */         case 4:
/* 100 */           this._instance.setOperation((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 103 */           this._instance.setQuantity((Long)memberValue);
/*     */           return;
/*     */         case 6:
/* 106 */           this._instance.setUnitType((String)memberValue);
/*     */           return;
/*     */       } 
/* 109 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 112 */     catch (RuntimeException e) {
/* 113 */       throw e;
/*     */     }
/* 115 */     catch (Exception e) {
/* 116 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 124 */     this._instance = (BenefitTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 128 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\BenefitTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */