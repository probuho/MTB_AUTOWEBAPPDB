/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.CityTO_SOAPBuilder;
/*     */ 
/*     */ public class CityTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_cityId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cityId");
/*  20 */   private static final QName ns3_int_TYPE_QNAME = SchemaConstants.QNAME_TYPE_INT;
/*     */   private CombinedSerializer myns3__int__int_Int_Serializer;
/*  22 */   private static final QName ns2_cityName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cityName");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  25 */   private static final QName ns2_stateCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "stateCode"); private static final int mycityId_INDEX = 0;
/*     */   private static final int mycityName_INDEX = 1;
/*     */   private static final int mystateCode_INDEX = 2;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public CityTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  31 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  35 */     this.myns3__int__int_Int_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), int.class, ns3_int_TYPE_QNAME);
/*  36 */     if (class$java$lang$String == null); ((CityTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  41 */     CityTO instance = new CityTO();
/*  42 */     CityTO_SOAPBuilder builder = null;
/*     */     
/*  44 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  47 */     reader.nextElementContent();
/*  48 */     QName startName = reader.getName();
/*  49 */     for (int i = 0; i < 3; i++) {
/*  50 */       QName elementName = reader.getName();
/*  51 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  54 */       if (matchQName(elementName, ns2_cityId_QNAME)) {
/*  55 */         context.setNillable(true);
/*  56 */         Object member = this.myns3__int__int_Int_Serializer.deserialize(ns2_cityId_QNAME, reader, context);
/*  57 */         if (member instanceof SOAPDeserializationState) {
/*  58 */           if (builder == null) {
/*  59 */             builder = new CityTO_SOAPBuilder();
/*     */           }
/*  61 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  62 */           isComplete = false;
/*  63 */         } else if (member != null) {
/*  64 */           instance.setCityId(((Integer)member).intValue());
/*     */         } 
/*  66 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  69 */       else if (matchQName(elementName, ns2_cityName_QNAME)) {
/*  70 */         context.setNillable(true);
/*  71 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cityName_QNAME, reader, context);
/*  72 */         if (object instanceof SOAPDeserializationState) {
/*  73 */           if (builder == null) {
/*  74 */             builder = new CityTO_SOAPBuilder();
/*     */           }
/*  76 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  77 */           isComplete = false;
/*  78 */         } else if (object != null) {
/*  79 */           instance.setCityName((String)object);
/*     */         } 
/*  81 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  84 */       else if (matchQName(elementName, ns2_stateCode_QNAME)) {
/*  85 */         context.setNillable(true);
/*  86 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_stateCode_QNAME, reader, context);
/*  87 */         if (object instanceof SOAPDeserializationState) {
/*  88 */           if (builder == null) {
/*  89 */             builder = new CityTO_SOAPBuilder();
/*     */           }
/*  91 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/*  92 */           isComplete = false;
/*  93 */         } else if (object != null) {
/*  94 */           instance.setStateCode((String)object);
/*     */         } 
/*  96 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/*  99 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_stateCode_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 104 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 105 */     } catch (XMLReaderException xmle) {
/* 106 */       if (startName != null) {
/* 107 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 109 */       throw xmle;
/*     */     } 
/*     */     
/* 112 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 116 */     CityTO instance = (CityTO)obj;
/*     */     
/* 118 */     context.setNillable(true);
/* 119 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getCityId()), ns2_cityId_QNAME, null, writer, context);
/* 120 */     context.setNillable(true);
/* 121 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCityName(), ns2_cityName_QNAME, null, writer, context);
/* 122 */     context.setNillable(true);
/* 123 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getStateCode(), ns2_stateCode_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\CityTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */