/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PromotionTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String promotionCode;
/*    */   protected String promotionDesc;
/*    */   
/*    */   public String getPromotionCode() {
/* 18 */     return this.promotionCode;
/*    */   }
/*    */   
/*    */   public void setPromotionCode(String promotionCode) {
/* 22 */     this.promotionCode = promotionCode;
/*    */   }
/*    */   
/*    */   public String getPromotionDesc() {
/* 26 */     return this.promotionDesc;
/*    */   }
/*    */   
/*    */   public void setPromotionDesc(String promotionDesc) {
/* 30 */     this.promotionDesc = promotionDesc;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\PromotionTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */