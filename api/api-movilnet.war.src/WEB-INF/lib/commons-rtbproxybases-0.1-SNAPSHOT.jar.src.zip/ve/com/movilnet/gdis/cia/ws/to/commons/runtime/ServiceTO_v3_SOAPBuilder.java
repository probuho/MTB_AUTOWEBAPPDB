/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceTO_v3_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ServiceTO_v3 _instance;
/*     */   private String alcoServicio;
/*     */   private String codServicio;
/*     */   private String descServicio;
/*     */   private String[] genericFields;
/*     */   private String group;
/*     */   private short maxCcNumber;
/*     */   private short minCcNumber;
/*     */   private String ovsaCommand;
/*     */   private String ovsaLabel;
/*     */   private String periodicChargeInd;
/*     */   private String periodicChargeName;
/*     */   private double precio;
/*     */   private String provisioningInd;
/*     */   private String subGroup;
/*     */   private String subType;
/*     */   private String type;
/*     */   private static final int myalcoServicio_INDEX = 0;
/*     */   private static final int mycodServicio_INDEX = 1;
/*     */   private static final int mydescServicio_INDEX = 2;
/*     */   private static final int mygenericFields_INDEX = 3;
/*     */   private static final int mygroup_INDEX = 4;
/*     */   private static final int mymaxCcNumber_INDEX = 5;
/*     */   private static final int myminCcNumber_INDEX = 6;
/*     */   private static final int myovsaCommand_INDEX = 7;
/*     */   private static final int myovsaLabel_INDEX = 8;
/*     */   private static final int myperiodicChargeInd_INDEX = 9;
/*     */   private static final int myperiodicChargeName_INDEX = 10;
/*     */   private static final int myprecio_INDEX = 11;
/*     */   private static final int myprovisioningInd_INDEX = 12;
/*     */   private static final int mysubGroup_INDEX = 13;
/*     */   private static final int mysubType_INDEX = 14;
/*     */   private static final int mytype_INDEX = 15;
/*     */   
/*     */   public void setAlcoServicio(String alcoServicio) {
/*  51 */     this.alcoServicio = alcoServicio;
/*     */   }
/*     */   
/*     */   public void setCodServicio(String codServicio) {
/*  55 */     this.codServicio = codServicio;
/*     */   }
/*     */   
/*     */   public void setDescServicio(String descServicio) {
/*  59 */     this.descServicio = descServicio;
/*     */   }
/*     */   
/*     */   public void setGenericFields(String[] genericFields) {
/*  63 */     this.genericFields = genericFields;
/*     */   }
/*     */   
/*     */   public void setGroup(String group) {
/*  67 */     this.group = group;
/*     */   }
/*     */   
/*     */   public void setMaxCcNumber(short maxCcNumber) {
/*  71 */     this.maxCcNumber = maxCcNumber;
/*     */   }
/*     */   
/*     */   public void setMinCcNumber(short minCcNumber) {
/*  75 */     this.minCcNumber = minCcNumber;
/*     */   }
/*     */   
/*     */   public void setOvsaCommand(String ovsaCommand) {
/*  79 */     this.ovsaCommand = ovsaCommand;
/*     */   }
/*     */   
/*     */   public void setOvsaLabel(String ovsaLabel) {
/*  83 */     this.ovsaLabel = ovsaLabel;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeInd(String periodicChargeInd) {
/*  87 */     this.periodicChargeInd = periodicChargeInd;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeName(String periodicChargeName) {
/*  91 */     this.periodicChargeName = periodicChargeName;
/*     */   }
/*     */   
/*     */   public void setPrecio(double precio) {
/*  95 */     this.precio = precio;
/*     */   }
/*     */   
/*     */   public void setProvisioningInd(String provisioningInd) {
/*  99 */     this.provisioningInd = provisioningInd;
/*     */   }
/*     */   
/*     */   public void setSubGroup(String subGroup) {
/* 103 */     this.subGroup = subGroup;
/*     */   }
/*     */   
/*     */   public void setSubType(String subType) {
/* 107 */     this.subType = subType;
/*     */   }
/*     */   
/*     */   public void setType(String type) {
/* 111 */     this.type = type;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/* 115 */     switch (memberIndex) {
/*     */       case 0:
/* 117 */         return 6;
/*     */       case 1:
/* 119 */         return 6;
/*     */       case 2:
/* 121 */         return 6;
/*     */       case 3:
/* 123 */         return 6;
/*     */       case 4:
/* 125 */         return 6;
/*     */       case 5:
/* 127 */         return 6;
/*     */       case 6:
/* 129 */         return 6;
/*     */       case 7:
/* 131 */         return 6;
/*     */       case 8:
/* 133 */         return 6;
/*     */       case 9:
/* 135 */         return 6;
/*     */       case 10:
/* 137 */         return 6;
/*     */       case 11:
/* 139 */         return 6;
/*     */       case 12:
/* 141 */         return 6;
/*     */       case 13:
/* 143 */         return 6;
/*     */       case 14:
/* 145 */         return 6;
/*     */       case 15:
/* 147 */         return 6;
/*     */     } 
/* 149 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 158 */       switch (index) {
/*     */         case 0:
/* 160 */           this._instance.setAlcoServicio((String)memberValue);
/*     */           return;
/*     */         case 1:
/* 163 */           this._instance.setCodServicio((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 166 */           this._instance.setDescServicio((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 169 */           this._instance.setGenericFields((String[])memberValue);
/*     */           return;
/*     */         case 4:
/* 172 */           this._instance.setGroup((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 175 */           this._instance.setMaxCcNumber(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 6:
/* 178 */           this._instance.setMinCcNumber(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 7:
/* 181 */           this._instance.setOvsaCommand((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 184 */           this._instance.setOvsaLabel((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 187 */           this._instance.setPeriodicChargeInd((String)memberValue);
/*     */           return;
/*     */         case 10:
/* 190 */           this._instance.setPeriodicChargeName((String)memberValue);
/*     */           return;
/*     */         case 11:
/* 193 */           this._instance.setPrecio(((Double)memberValue).doubleValue());
/*     */           return;
/*     */         case 12:
/* 196 */           this._instance.setProvisioningInd((String)memberValue);
/*     */           return;
/*     */         case 13:
/* 199 */           this._instance.setSubGroup((String)memberValue);
/*     */           return;
/*     */         case 14:
/* 202 */           this._instance.setSubType((String)memberValue);
/*     */           return;
/*     */         case 15:
/* 205 */           this._instance.setType((String)memberValue);
/*     */           return;
/*     */       } 
/* 208 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 211 */     catch (RuntimeException e) {
/* 212 */       throw e;
/*     */     }
/* 214 */     catch (Exception e) {
/* 215 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 223 */     this._instance = (ServiceTO_v3)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 227 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\ServiceTO_v3_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */