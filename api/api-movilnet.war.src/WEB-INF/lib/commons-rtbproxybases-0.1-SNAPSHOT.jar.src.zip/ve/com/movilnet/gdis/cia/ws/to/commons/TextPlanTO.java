/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextPlanTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String planCode;
/*    */   protected String planTextoDesc;
/*    */   protected String suffixAlcoCode;
/*    */   
/*    */   public String getPlanCode() {
/* 19 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 23 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getPlanTextoDesc() {
/* 27 */     return this.planTextoDesc;
/*    */   }
/*    */   
/*    */   public void setPlanTextoDesc(String planTextoDesc) {
/* 31 */     this.planTextoDesc = planTextoDesc;
/*    */   }
/*    */   
/*    */   public String getSuffixAlcoCode() {
/* 35 */     return this.suffixAlcoCode;
/*    */   }
/*    */   
/*    */   public void setSuffixAlcoCode(String suffixAlcoCode) {
/* 39 */     this.suffixAlcoCode = suffixAlcoCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\TextPlanTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */