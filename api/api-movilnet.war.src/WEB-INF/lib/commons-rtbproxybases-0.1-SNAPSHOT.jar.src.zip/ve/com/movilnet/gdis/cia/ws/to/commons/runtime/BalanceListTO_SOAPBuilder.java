/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BalanceListTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private BalanceListTO _instance;
/*     */   private String adjustmentInd;
/*     */   private String balanceCommercialName;
/*     */   private int balanceId;
/*     */   private String balanceName;
/*     */   private String balanceSubType;
/*     */   private String balanceType;
/*     */   private double conversionFactor;
/*     */   private String decimalInd;
/*     */   private String taxInd;
/*     */   private String unitCommercialName;
/*     */   private static final int myadjustmentInd_INDEX = 0;
/*     */   private static final int mybalanceCommercialName_INDEX = 1;
/*     */   private static final int mybalanceId_INDEX = 2;
/*     */   private static final int mybalanceName_INDEX = 3;
/*     */   private static final int mybalanceSubType_INDEX = 4;
/*     */   private static final int mybalanceType_INDEX = 5;
/*     */   private static final int myconversionFactor_INDEX = 6;
/*     */   private static final int mydecimalInd_INDEX = 7;
/*     */   private static final int mytaxInd_INDEX = 8;
/*     */   private static final int myunitCommercialName_INDEX = 9;
/*     */   
/*     */   public void setAdjustmentInd(String adjustmentInd) {
/*  39 */     this.adjustmentInd = adjustmentInd;
/*     */   }
/*     */   
/*     */   public void setBalanceCommercialName(String balanceCommercialName) {
/*  43 */     this.balanceCommercialName = balanceCommercialName;
/*     */   }
/*     */   
/*     */   public void setBalanceId(int balanceId) {
/*  47 */     this.balanceId = balanceId;
/*     */   }
/*     */   
/*     */   public void setBalanceName(String balanceName) {
/*  51 */     this.balanceName = balanceName;
/*     */   }
/*     */   
/*     */   public void setBalanceSubType(String balanceSubType) {
/*  55 */     this.balanceSubType = balanceSubType;
/*     */   }
/*     */   
/*     */   public void setBalanceType(String balanceType) {
/*  59 */     this.balanceType = balanceType;
/*     */   }
/*     */   
/*     */   public void setConversionFactor(double conversionFactor) {
/*  63 */     this.conversionFactor = conversionFactor;
/*     */   }
/*     */   
/*     */   public void setDecimalInd(String decimalInd) {
/*  67 */     this.decimalInd = decimalInd;
/*     */   }
/*     */   
/*     */   public void setTaxInd(String taxInd) {
/*  71 */     this.taxInd = taxInd;
/*     */   }
/*     */   
/*     */   public void setUnitCommercialName(String unitCommercialName) {
/*  75 */     this.unitCommercialName = unitCommercialName;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  79 */     switch (memberIndex) {
/*     */       case 0:
/*  81 */         return 6;
/*     */       case 1:
/*  83 */         return 6;
/*     */       case 2:
/*  85 */         return 6;
/*     */       case 3:
/*  87 */         return 6;
/*     */       case 4:
/*  89 */         return 6;
/*     */       case 5:
/*  91 */         return 6;
/*     */       case 6:
/*  93 */         return 6;
/*     */       case 7:
/*  95 */         return 6;
/*     */       case 8:
/*  97 */         return 6;
/*     */       case 9:
/*  99 */         return 6;
/*     */     } 
/* 101 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 110 */       switch (index) {
/*     */         case 0:
/* 112 */           this._instance.setAdjustmentInd((String)memberValue);
/*     */           return;
/*     */         case 1:
/* 115 */           this._instance.setBalanceCommercialName((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 118 */           this._instance.setBalanceId(((Integer)memberValue).intValue());
/*     */           return;
/*     */         case 3:
/* 121 */           this._instance.setBalanceName((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 124 */           this._instance.setBalanceSubType((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 127 */           this._instance.setBalanceType((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 130 */           this._instance.setConversionFactor(((Double)memberValue).doubleValue());
/*     */           return;
/*     */         case 7:
/* 133 */           this._instance.setDecimalInd((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 136 */           this._instance.setTaxInd((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 139 */           this._instance.setUnitCommercialName((String)memberValue);
/*     */           return;
/*     */       } 
/* 142 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 145 */     catch (RuntimeException e) {
/* 146 */       throw e;
/*     */     }
/* 148 */     catch (Exception e) {
/* 149 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 157 */     this._instance = (BalanceListTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 161 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\BalanceListTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */