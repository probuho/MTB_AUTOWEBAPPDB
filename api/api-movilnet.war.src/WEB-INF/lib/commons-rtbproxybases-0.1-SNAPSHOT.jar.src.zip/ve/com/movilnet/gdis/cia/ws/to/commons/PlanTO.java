/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlanTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String descPlan;
/*    */   protected String planCode;
/*    */   protected String planSuffix;
/*    */   protected String planType;
/*    */   protected String unitType;
/*    */   
/*    */   public String getDescPlan() {
/* 21 */     return this.descPlan;
/*    */   }
/*    */   
/*    */   public void setDescPlan(String descPlan) {
/* 25 */     this.descPlan = descPlan;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 29 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 33 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getPlanSuffix() {
/* 37 */     return this.planSuffix;
/*    */   }
/*    */   
/*    */   public void setPlanSuffix(String planSuffix) {
/* 41 */     this.planSuffix = planSuffix;
/*    */   }
/*    */   
/*    */   public String getPlanType() {
/* 45 */     return this.planType;
/*    */   }
/*    */   
/*    */   public void setPlanType(String planType) {
/* 49 */     this.planType = planType;
/*    */   }
/*    */   
/*    */   public String getUnitType() {
/* 53 */     return this.unitType;
/*    */   }
/*    */   
/*    */   public void setUnitType(String unitType) {
/* 57 */     this.unitType = unitType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\PlanTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */