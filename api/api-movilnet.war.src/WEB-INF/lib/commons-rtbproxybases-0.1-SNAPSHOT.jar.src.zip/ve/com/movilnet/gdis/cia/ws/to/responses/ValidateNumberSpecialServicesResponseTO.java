/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateNumberSpecialServicesResponseTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected BenefitTO[] activationFees;
/*    */   protected Short positionOnTheList;
/*    */   protected boolean result;
/*    */   
/*    */   public BenefitTO[] getActivationFees() {
/* 19 */     return this.activationFees;
/*    */   }
/*    */   
/*    */   public void setActivationFees(BenefitTO[] activationFees) {
/* 23 */     this.activationFees = activationFees;
/*    */   }
/*    */   
/*    */   public Short getPositionOnTheList() {
/* 27 */     return this.positionOnTheList;
/*    */   }
/*    */   
/*    */   public void setPositionOnTheList(Short positionOnTheList) {
/* 31 */     this.positionOnTheList = positionOnTheList;
/*    */   }
/*    */   
/*    */   public boolean isResult() {
/* 35 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(boolean result) {
/* 39 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\ValidateNumberSpecialServicesResponseTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */