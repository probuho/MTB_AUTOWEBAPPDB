/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangeBRPlanRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidateChangeBRPlanRequestTO changePlanRequest;
/*    */   
/*    */   public ValidateChangeBRPlanRequestTO getChangePlanRequest() {
/* 17 */     return this.changePlanRequest;
/*    */   }
/*    */   
/*    */   public void setChangePlanRequest(ValidateChangeBRPlanRequestTO changePlanRequest) {
/* 21 */     this.changePlanRequest = changePlanRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */