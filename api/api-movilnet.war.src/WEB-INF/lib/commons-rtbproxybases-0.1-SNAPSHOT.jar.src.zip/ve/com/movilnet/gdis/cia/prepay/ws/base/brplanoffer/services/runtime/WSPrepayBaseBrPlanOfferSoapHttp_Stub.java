/*      */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*      */ import java.rmi.RemoteException;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.rpc.JAXRPCException;
/*      */ import javax.xml.rpc.handler.HandlerChain;
/*      */ import oracle.j2ee.ws.client.ClientTransportException;
/*      */ import oracle.j2ee.ws.client.StreamingSenderState;
/*      */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*      */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*      */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*      */ import oracle.j2ee.ws.common.encoding.JAXRPCSerializer;
/*      */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*      */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*      */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*      */ import oracle.j2ee.ws.common.soap.message.InternalSOAPMessage;
/*      */ import oracle.j2ee.ws.common.soap.message.SOAPBlockInfo;
/*      */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*      */ import oracle.webservices.transport.ClientTransport;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAffiliationServiceRequestTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAuthorisedProfileRequestTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateNumberSpecialServicesRequestTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO_v2;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanServicesRequestTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO;
/*      */ import ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO;
/*      */ 
/*      */ public class WSPrepayBaseBrPlanOfferSoapHttp_Stub extends StubBase implements IWSPrepayBaseBrPlanOffer {
/*      */   static Class class$(String paramString) {
/*      */     
/*   33 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WSPrepayBaseBrPlanOfferSoapHttp_Stub(HandlerChain handlerChain) {
/*   42 */     super(handlerChain);
/*   43 */     _setProperty("javax.xml.rpc.service.endpoint.address", "http://172.16.216.71:8888/wsppaybasebrplanoffer/planoffer");
/*   44 */     setSoapVersion(SOAPVersion.SOAP_11);
/*   45 */     setServiceName(new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "WSPrepayBaseBrPlanOffer"));
/*   46 */     setPortName(new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "planoffer"));
/*   47 */     setupConfig("ve/com/movilnet/gdis/cia/prepay/ws/base/brplanoffer/services/runtime/WSPrepayBaseBrPlanOfferSoapHttp_Stub.xml");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validatePlanConsejoComunal(ValidatePlanConsejoComunalRequestTO planConsejoComunalRequest) throws RemoteException {
/*   56 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*   59 */       _state = _start(this._handlerChain);
/*   60 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*   61 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*   64 */       InternalSOAPMessage _request = _state.getRequest();
/*   65 */       _request.setOperationCode(0);
/*   66 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validatePlanConsejoComunal"));
/*      */       
/*   68 */       WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS();
/*      */       
/*   70 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS.setPlanConsejoComunalRequest(planConsejoComunalRequest);
/*   71 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validatePlanConsejoComunal_validatePlanConsejoComunal_QNAME);
/*   72 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS);
/*   73 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validatePlanConsejoComunal__WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer);
/*   74 */       _request.setBody(_bodyBlock);
/*      */       
/*   76 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validatePlanConsejoComunal");
/*      */ 
/*      */       
/*   79 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*   81 */       WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS = null;
/*   82 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*   83 */       if (_responseObj instanceof SOAPDeserializationState) {
/*   84 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*   87 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*   91 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS.getResult();
/*   92 */     } catch (RemoteException e) {
/*      */       
/*   94 */       throw e;
/*   95 */     } catch (ClientTransportException e) {
/*   96 */       throw new RemoteException("", e);
/*   97 */     } catch (JAXRPCException e) {
/*   98 */       throw e;
/*   99 */     } catch (Exception e) {
/*  100 */       if (e instanceof RuntimeException) {
/*  101 */         throw (RuntimeException)e;
/*      */       }
/*  103 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValidateAuthorisedProfileResponseTO validateAuthorisedProfile(ValidateAuthorisedProfileRequestTO validateAuthorisedProfileRequest) throws RemoteException {
/*  114 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  117 */       _state = _start(this._handlerChain);
/*  118 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  119 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  122 */       InternalSOAPMessage _request = _state.getRequest();
/*  123 */       _request.setOperationCode(1);
/*  124 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateAuthorisedProfile"));
/*      */       
/*  126 */       WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS();
/*      */       
/*  128 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS.setValidateAuthorisedProfileRequest(validateAuthorisedProfileRequest);
/*  129 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateAuthorisedProfile_validateAuthorisedProfile_QNAME);
/*  130 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS);
/*  131 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateAuthorisedProfile__WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer);
/*  132 */       _request.setBody(_bodyBlock);
/*      */       
/*  134 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateAuthorisedProfile");
/*      */ 
/*      */       
/*  137 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  139 */       WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS = null;
/*  140 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  141 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  142 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  145 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  149 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS.getResult();
/*  150 */     } catch (RemoteException e) {
/*      */       
/*  152 */       throw e;
/*  153 */     } catch (ClientTransportException e) {
/*  154 */       throw new RemoteException("", e);
/*  155 */     } catch (JAXRPCException e) {
/*  156 */       throw e;
/*  157 */     } catch (Exception e) {
/*  158 */       if (e instanceof RuntimeException) {
/*  159 */         throw (RuntimeException)e;
/*      */       }
/*  161 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validateCompatibilityPlanPromotionDealer(ValidatePlanPromotionDealerRequestTO planPromotionDealerRequest) throws RemoteException {
/*  172 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  175 */       _state = _start(this._handlerChain);
/*  176 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  177 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  180 */       InternalSOAPMessage _request = _state.getRequest();
/*  181 */       _request.setOperationCode(2);
/*  182 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateCompatibilityPlanPromotionDealer"));
/*      */       
/*  184 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS();
/*      */       
/*  186 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS.setPlanPromotionDealerRequest(planPromotionDealerRequest);
/*  187 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanPromotionDealer_validateCompatibilityPlanPromotionDealer_QNAME);
/*  188 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS);
/*  189 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateCompatibilityPlanPromotionDealer__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer);
/*  190 */       _request.setBody(_bodyBlock);
/*      */       
/*  192 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateCompatibilityPlanPromotionDealer");
/*      */ 
/*      */       
/*  195 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  197 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS = null;
/*  198 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  199 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  200 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  203 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  207 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS.getResult();
/*  208 */     } catch (RemoteException e) {
/*      */       
/*  210 */       throw e;
/*  211 */     } catch (ClientTransportException e) {
/*  212 */       throw new RemoteException("", e);
/*  213 */     } catch (JAXRPCException e) {
/*  214 */       throw e;
/*  215 */     } catch (Exception e) {
/*  216 */       if (e instanceof RuntimeException) {
/*  217 */         throw (RuntimeException)e;
/*      */       }
/*  219 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValidatePlanResponseTO validatePlan_v2(ValidatePlanRequestTO_v2 planRequest) throws RemoteException {
/*  230 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  233 */       _state = _start(this._handlerChain);
/*  234 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  235 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  238 */       InternalSOAPMessage _request = _state.getRequest();
/*  239 */       _request.setOperationCode(3);
/*  240 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validatePlan_v2"));
/*      */       
/*  242 */       WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS();
/*      */       
/*  244 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS.setPlanRequest(planRequest);
/*  245 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validatePlan_v2_validatePlan_v2_QNAME);
/*  246 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS);
/*  247 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validatePlan_v2__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer);
/*  248 */       _request.setBody(_bodyBlock);
/*      */       
/*  250 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validatePlan_v2");
/*      */ 
/*      */       
/*  253 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  255 */       WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS = null;
/*  256 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  257 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  258 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  261 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  265 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS.getResult();
/*  266 */     } catch (RemoteException e) {
/*      */       
/*  268 */       throw e;
/*  269 */     } catch (ClientTransportException e) {
/*  270 */       throw new RemoteException("", e);
/*  271 */     } catch (JAXRPCException e) {
/*  272 */       throw e;
/*  273 */     } catch (Exception e) {
/*  274 */       if (e instanceof RuntimeException) {
/*  275 */         throw (RuntimeException)e;
/*      */       }
/*  277 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validateCompatibilityServicesModel_v2(ValidateServicesModelRequestTO_v2 servicesModelRequest) throws RemoteException {
/*  288 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  291 */       _state = _start(this._handlerChain);
/*  292 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  293 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  296 */       InternalSOAPMessage _request = _state.getRequest();
/*  297 */       _request.setOperationCode(4);
/*  298 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateCompatibilityServicesModel_v2"));
/*      */       
/*  300 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS();
/*      */       
/*  302 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS.setServicesModelRequest(servicesModelRequest);
/*  303 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityServicesModel_v2_validateCompatibilityServicesModel_v2_QNAME);
/*  304 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS);
/*  305 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateCompatibilityServicesModel_v2__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer);
/*  306 */       _request.setBody(_bodyBlock);
/*      */       
/*  308 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateCompatibilityServicesModel_v2");
/*      */ 
/*      */       
/*  311 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  313 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS = null;
/*  314 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  315 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  316 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  319 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  323 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS.getResult();
/*  324 */     } catch (RemoteException e) {
/*      */       
/*  326 */       throw e;
/*  327 */     } catch (ClientTransportException e) {
/*  328 */       throw new RemoteException("", e);
/*  329 */     } catch (JAXRPCException e) {
/*  330 */       throw e;
/*  331 */     } catch (Exception e) {
/*  332 */       if (e instanceof RuntimeException) {
/*  333 */         throw (RuntimeException)e;
/*      */       }
/*  335 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BRPlanOfferResponseTO validateAffiliationService(ValidateAffiliationServiceRequestTO affiliationServiceRequest) throws RemoteException {
/*  346 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  349 */       _state = _start(this._handlerChain);
/*  350 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  351 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  354 */       InternalSOAPMessage _request = _state.getRequest();
/*  355 */       _request.setOperationCode(5);
/*  356 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateAffiliationService"));
/*      */       
/*  358 */       WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS();
/*      */       
/*  360 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS.setAffiliationServiceRequest(affiliationServiceRequest);
/*  361 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateAffiliationService_validateAffiliationService_QNAME);
/*  362 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS);
/*  363 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateAffiliationService__WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer);
/*  364 */       _request.setBody(_bodyBlock);
/*      */       
/*  366 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateAffiliationService");
/*      */ 
/*      */       
/*  369 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  371 */       WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS = null;
/*  372 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  373 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  374 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  377 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  381 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS.getResult();
/*  382 */     } catch (RemoteException e) {
/*      */       
/*  384 */       throw e;
/*  385 */     } catch (ClientTransportException e) {
/*  386 */       throw new RemoteException("", e);
/*  387 */     } catch (JAXRPCException e) {
/*  388 */       throw e;
/*  389 */     } catch (Exception e) {
/*  390 */       if (e instanceof RuntimeException) {
/*  391 */         throw (RuntimeException)e;
/*      */       }
/*  393 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BRPlanOfferResponseTO validateDisConnectionService(ValidateDisConnectionServiceRequestTO disConnectionServiceRequest) throws RemoteException {
/*  404 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  407 */       _state = _start(this._handlerChain);
/*  408 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  409 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  412 */       InternalSOAPMessage _request = _state.getRequest();
/*  413 */       _request.setOperationCode(6);
/*  414 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateDisConnectionService"));
/*      */       
/*  416 */       WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS();
/*      */       
/*  418 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS.setDisConnectionServiceRequest(disConnectionServiceRequest);
/*  419 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateDisConnectionService_validateDisConnectionService_QNAME);
/*  420 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS);
/*  421 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateDisConnectionService__WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer);
/*  422 */       _request.setBody(_bodyBlock);
/*      */       
/*  424 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateDisConnectionService");
/*      */ 
/*      */       
/*  427 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  429 */       WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS = null;
/*  430 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  431 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  432 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  435 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  439 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS.getResult();
/*  440 */     } catch (RemoteException e) {
/*      */       
/*  442 */       throw e;
/*  443 */     } catch (ClientTransportException e) {
/*  444 */       throw new RemoteException("", e);
/*  445 */     } catch (JAXRPCException e) {
/*  446 */       throw e;
/*  447 */     } catch (Exception e) {
/*  448 */       if (e instanceof RuntimeException) {
/*  449 */         throw (RuntimeException)e;
/*      */       }
/*  451 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BRPlanOfferResponseTO isChangePlan(ValidateChangeBRPlanRequestTO changePlanRequest) throws RemoteException {
/*  462 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  465 */       _state = _start(this._handlerChain);
/*  466 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  467 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  470 */       InternalSOAPMessage _request = _state.getRequest();
/*  471 */       _request.setOperationCode(7);
/*  472 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "isChangePlan"));
/*      */       
/*  474 */       WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS();
/*      */       
/*  476 */       _myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS.setChangePlanRequest(changePlanRequest);
/*  477 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_isChangePlan_isChangePlan_QNAME);
/*  478 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS);
/*  479 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_isChangePlan__WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer);
/*  480 */       _request.setBody(_bodyBlock);
/*      */       
/*  482 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//isChangePlan");
/*      */ 
/*      */       
/*  485 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  487 */       WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS = null;
/*  488 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  489 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  490 */         _myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  493 */         _myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  497 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS.getResult();
/*  498 */     } catch (RemoteException e) {
/*      */       
/*  500 */       throw e;
/*  501 */     } catch (ClientTransportException e) {
/*  502 */       throw new RemoteException("", e);
/*  503 */     } catch (JAXRPCException e) {
/*  504 */       throw e;
/*  505 */     } catch (Exception e) {
/*  506 */       if (e instanceof RuntimeException) {
/*  507 */         throw (RuntimeException)e;
/*      */       }
/*  509 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validateCompatibilityPlanModel_v2(ValidatePlanModelRequestTO_v2 planModelRequest) throws RemoteException {
/*  520 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  523 */       _state = _start(this._handlerChain);
/*  524 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  525 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  528 */       InternalSOAPMessage _request = _state.getRequest();
/*  529 */       _request.setOperationCode(8);
/*  530 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateCompatibilityPlanModel_v2"));
/*      */       
/*  532 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS();
/*      */       
/*  534 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS.setPlanModelRequest(planModelRequest);
/*  535 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanModel_v2_validateCompatibilityPlanModel_v2_QNAME);
/*  536 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS);
/*  537 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateCompatibilityPlanModel_v2__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer);
/*  538 */       _request.setBody(_bodyBlock);
/*      */       
/*  540 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateCompatibilityPlanModel_v2");
/*      */ 
/*      */       
/*  543 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  545 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS = null;
/*  546 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  547 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  548 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  551 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  555 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS.getResult();
/*  556 */     } catch (RemoteException e) {
/*      */       
/*  558 */       throw e;
/*  559 */     } catch (ClientTransportException e) {
/*  560 */       throw new RemoteException("", e);
/*  561 */     } catch (JAXRPCException e) {
/*  562 */       throw e;
/*  563 */     } catch (Exception e) {
/*  564 */       if (e instanceof RuntimeException) {
/*  565 */         throw (RuntimeException)e;
/*      */       }
/*  567 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValidateNumberSpecialServicesResponseTO validateNumberSpecialServices(ValidateNumberSpecialServicesRequestTO validateNumberSpecialServicesRequest) throws RemoteException {
/*  578 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  581 */       _state = _start(this._handlerChain);
/*  582 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  583 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  586 */       InternalSOAPMessage _request = _state.getRequest();
/*  587 */       _request.setOperationCode(9);
/*  588 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateNumberSpecialServices"));
/*      */       
/*  590 */       WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS();
/*      */       
/*  592 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS.setValidateNumberSpecialServicesRequest(validateNumberSpecialServicesRequest);
/*  593 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateNumberSpecialServices_validateNumberSpecialServices_QNAME);
/*  594 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS);
/*  595 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateNumberSpecialServices__WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer);
/*  596 */       _request.setBody(_bodyBlock);
/*      */       
/*  598 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateNumberSpecialServices");
/*      */ 
/*      */       
/*  601 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  603 */       WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS = null;
/*  604 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  605 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  606 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  609 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  613 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS.getResult();
/*  614 */     } catch (RemoteException e) {
/*      */       
/*  616 */       throw e;
/*  617 */     } catch (ClientTransportException e) {
/*  618 */       throw new RemoteException("", e);
/*  619 */     } catch (JAXRPCException e) {
/*  620 */       throw e;
/*  621 */     } catch (Exception e) {
/*  622 */       if (e instanceof RuntimeException) {
/*  623 */         throw (RuntimeException)e;
/*      */       }
/*  625 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BRPlanOfferResponseTO validateChangePlanText(ValidateChangePlanTextRequestTO changePlanTextRequest) throws RemoteException {
/*  636 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  639 */       _state = _start(this._handlerChain);
/*  640 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  641 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  644 */       InternalSOAPMessage _request = _state.getRequest();
/*  645 */       _request.setOperationCode(10);
/*  646 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateChangePlanText"));
/*      */       
/*  648 */       WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS();
/*      */       
/*  650 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS.setChangePlanTextRequest(changePlanTextRequest);
/*  651 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateChangePlanText_validateChangePlanText_QNAME);
/*  652 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS);
/*  653 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateChangePlanText__WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer);
/*  654 */       _request.setBody(_bodyBlock);
/*      */       
/*  656 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateChangePlanText");
/*      */ 
/*      */       
/*  659 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  661 */       WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS = null;
/*  662 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  663 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  664 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  667 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  671 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS.getResult();
/*  672 */     } catch (RemoteException e) {
/*      */       
/*  674 */       throw e;
/*  675 */     } catch (ClientTransportException e) {
/*  676 */       throw new RemoteException("", e);
/*  677 */     } catch (JAXRPCException e) {
/*  678 */       throw e;
/*  679 */     } catch (Exception e) {
/*  680 */       if (e instanceof RuntimeException) {
/*  681 */         throw (RuntimeException)e;
/*      */       }
/*  683 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validateCompatibilityPlanModel(ValidatePlanModelRequestTO planModelRequest) throws RemoteException {
/*  694 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  697 */       _state = _start(this._handlerChain);
/*  698 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  699 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  702 */       InternalSOAPMessage _request = _state.getRequest();
/*  703 */       _request.setOperationCode(11);
/*  704 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateCompatibilityPlanModel"));
/*      */       
/*  706 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS();
/*      */       
/*  708 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS.setPlanModelRequest(planModelRequest);
/*  709 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanModel_validateCompatibilityPlanModel_QNAME);
/*  710 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS);
/*  711 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateCompatibilityPlanModel__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer);
/*  712 */       _request.setBody(_bodyBlock);
/*      */       
/*  714 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateCompatibilityPlanModel");
/*      */ 
/*      */       
/*  717 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  719 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS = null;
/*  720 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  721 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  722 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  725 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  729 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS.getResult();
/*  730 */     } catch (RemoteException e) {
/*      */       
/*  732 */       throw e;
/*  733 */     } catch (ClientTransportException e) {
/*  734 */       throw new RemoteException("", e);
/*  735 */     } catch (JAXRPCException e) {
/*  736 */       throw e;
/*  737 */     } catch (Exception e) {
/*  738 */       if (e instanceof RuntimeException) {
/*  739 */         throw (RuntimeException)e;
/*      */       }
/*  741 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validateCompatibilityPlanServices(ValidatePlanServicesRequestTO planServicesRequest) throws RemoteException {
/*  752 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  755 */       _state = _start(this._handlerChain);
/*  756 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  757 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  760 */       InternalSOAPMessage _request = _state.getRequest();
/*  761 */       _request.setOperationCode(12);
/*  762 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateCompatibilityPlanServices"));
/*      */       
/*  764 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS();
/*      */       
/*  766 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS.setPlanServicesRequest(planServicesRequest);
/*  767 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanServices_validateCompatibilityPlanServices_QNAME);
/*  768 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS);
/*  769 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateCompatibilityPlanServices__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer);
/*  770 */       _request.setBody(_bodyBlock);
/*      */       
/*  772 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateCompatibilityPlanServices");
/*      */ 
/*      */       
/*  775 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  777 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS = null;
/*  778 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  779 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  780 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  783 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  787 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS.getResult();
/*  788 */     } catch (RemoteException e) {
/*      */       
/*  790 */       throw e;
/*  791 */     } catch (ClientTransportException e) {
/*  792 */       throw new RemoteException("", e);
/*  793 */     } catch (JAXRPCException e) {
/*  794 */       throw e;
/*  795 */     } catch (Exception e) {
/*  796 */       if (e instanceof RuntimeException) {
/*  797 */         throw (RuntimeException)e;
/*      */       }
/*  799 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validatePlan(ValidatePlanRequestTO planRequest) throws RemoteException {
/*  810 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  813 */       _state = _start(this._handlerChain);
/*  814 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  815 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  818 */       InternalSOAPMessage _request = _state.getRequest();
/*  819 */       _request.setOperationCode(13);
/*  820 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validatePlan"));
/*      */       
/*  822 */       WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS();
/*      */       
/*  824 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS.setPlanRequest(planRequest);
/*  825 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validatePlan_validatePlan_QNAME);
/*  826 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS);
/*  827 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validatePlan__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer);
/*  828 */       _request.setBody(_bodyBlock);
/*      */       
/*  830 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validatePlan");
/*      */ 
/*      */       
/*  833 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  835 */       WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS = null;
/*  836 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  837 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  838 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  841 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  845 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS.getResult();
/*  846 */     } catch (RemoteException e) {
/*      */       
/*  848 */       throw e;
/*  849 */     } catch (ClientTransportException e) {
/*  850 */       throw new RemoteException("", e);
/*  851 */     } catch (JAXRPCException e) {
/*  852 */       throw e;
/*  853 */     } catch (Exception e) {
/*  854 */       if (e instanceof RuntimeException) {
/*  855 */         throw (RuntimeException)e;
/*      */       }
/*  857 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanResponseTO validateCompatibilityServicesModel(ValidateServicesModelRequestTO servicesModelRequest) throws RemoteException {
/*  868 */     StreamingSenderState _state = null;
/*      */     
/*      */     try {
/*  871 */       _state = _start(this._handlerChain);
/*  872 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  873 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*      */       }
/*      */       
/*  876 */       InternalSOAPMessage _request = _state.getRequest();
/*  877 */       _request.setOperationCode(14);
/*  878 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "validateCompatibilityServicesModel"));
/*      */       
/*  880 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS();
/*      */       
/*  882 */       _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS.setServicesModelRequest(servicesModelRequest);
/*  883 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityServicesModel_validateCompatibilityServicesModel_QNAME);
/*  884 */       _bodyBlock.setValue(_myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS);
/*  885 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_validateCompatibilityServicesModel__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer);
/*  886 */       _request.setBody(_bodyBlock);
/*      */       
/*  888 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve//validateCompatibilityServicesModel");
/*      */ 
/*      */       
/*  891 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*      */       
/*  893 */       WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS = null;
/*  894 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  895 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  896 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*      */       } else {
/*      */         
/*  899 */         _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS = (WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS)_responseObj;
/*      */       } 
/*      */ 
/*      */       
/*  903 */       return _myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS.getResult();
/*  904 */     } catch (RemoteException e) {
/*      */       
/*  906 */       throw e;
/*  907 */     } catch (ClientTransportException e) {
/*  908 */       throw new RemoteException("", e);
/*  909 */     } catch (JAXRPCException e) {
/*  910 */       throw e;
/*  911 */     } catch (Exception e) {
/*  912 */       if (e instanceof RuntimeException) {
/*  913 */         throw (RuntimeException)e;
/*      */       }
/*  915 */       throw new RemoteException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _readFirstBodyElement(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*  925 */     int opcode = state.getRequest().getOperationCode();
/*  926 */     switch (opcode) {
/*      */       case 0:
/*  928 */         _deserialize_validatePlanConsejoComunal(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 1:
/*  931 */         _deserialize_validateAuthorisedProfile(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 2:
/*  934 */         _deserialize_validateCompatibilityPlanPromotionDealer(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 3:
/*  937 */         _deserialize_validatePlan_v2(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 4:
/*  940 */         _deserialize_validateCompatibilityServicesModel_v2(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 5:
/*  943 */         _deserialize_validateAffiliationService(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 6:
/*  946 */         _deserialize_validateDisConnectionService(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 7:
/*  949 */         _deserialize_isChangePlan(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 8:
/*  952 */         _deserialize_validateCompatibilityPlanModel_v2(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 9:
/*  955 */         _deserialize_validateNumberSpecialServices(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 10:
/*  958 */         _deserialize_validateChangePlanText(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 11:
/*  961 */         _deserialize_validateCompatibilityPlanModel(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 12:
/*  964 */         _deserialize_validateCompatibilityPlanServices(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 13:
/*  967 */         _deserialize_validatePlan(bodyReader, deserializationContext, state);
/*      */         return;
/*      */       case 14:
/*  970 */         _deserialize_validateCompatibilityServicesModel(bodyReader, deserializationContext, state);
/*      */         return;
/*      */     } 
/*  973 */     throw new SenderException("sender.response.unrecognizedOperation", Integer.toString(opcode));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validatePlanConsejoComunal(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/*  984 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespSObj = this.myns1_validatePlanConsejoComunalResponse__WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer.deserialize(ns1_validatePlanConsejoComunal_validatePlanConsejoComunalResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/*  988 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validatePlanConsejoComunal_validatePlanConsejoComunalResponse_QNAME);
/*  989 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespSObj);
/*  990 */       state.getResponse().setBody(bodyBlock);
/*  991 */     } catch (DeserializationException e) {
/*  992 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/*  993 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/*  995 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateAuthorisedProfile(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1004 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespSObj = this.myns1_validateAuthorisedProfileResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer.deserialize(ns1_validateAuthorisedProfile_validateAuthorisedProfileResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1008 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateAuthorisedProfile_validateAuthorisedProfileResponse_QNAME);
/* 1009 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespSObj);
/* 1010 */       state.getResponse().setBody(bodyBlock);
/* 1011 */     } catch (DeserializationException e) {
/* 1012 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1013 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1015 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateCompatibilityPlanPromotionDealer(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1024 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespSObj = this.myns1_validateCompatibilityPlanPromotionDealerResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer.deserialize(ns1_validateCompatibilityPlanPromotionDealer_validateCompatibilityPlanPromotionDealerResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1028 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanPromotionDealer_validateCompatibilityPlanPromotionDealerResponse_QNAME);
/* 1029 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespSObj);
/* 1030 */       state.getResponse().setBody(bodyBlock);
/* 1031 */     } catch (DeserializationException e) {
/* 1032 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1033 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1035 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validatePlan_v2(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1044 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespSObj = this.myns1_validatePlan_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer.deserialize(ns1_validatePlan_v2_validatePlan_v2Response_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1048 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validatePlan_v2_validatePlan_v2Response_QNAME);
/* 1049 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespSObj);
/* 1050 */       state.getResponse().setBody(bodyBlock);
/* 1051 */     } catch (DeserializationException e) {
/* 1052 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1053 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1055 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateCompatibilityServicesModel_v2(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1064 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespSObj = this.myns1_validateCompatibilityServicesModel_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer.deserialize(ns1_validateCompatibilityServicesModel_v2_validateCompatibilityServicesModel_v2Response_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1068 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityServicesModel_v2_validateCompatibilityServicesModel_v2Response_QNAME);
/* 1069 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespSObj);
/* 1070 */       state.getResponse().setBody(bodyBlock);
/* 1071 */     } catch (DeserializationException e) {
/* 1072 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1073 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1075 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateAffiliationService(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1084 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespSObj = this.myns1_validateAffiliationServiceResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer.deserialize(ns1_validateAffiliationService_validateAffiliationServiceResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1088 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateAffiliationService_validateAffiliationServiceResponse_QNAME);
/* 1089 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespSObj);
/* 1090 */       state.getResponse().setBody(bodyBlock);
/* 1091 */     } catch (DeserializationException e) {
/* 1092 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1093 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1095 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateDisConnectionService(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1104 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespSObj = this.myns1_validateDisConnectionServiceResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer.deserialize(ns1_validateDisConnectionService_validateDisConnectionServiceResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1108 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateDisConnectionService_validateDisConnectionServiceResponse_QNAME);
/* 1109 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespSObj);
/* 1110 */       state.getResponse().setBody(bodyBlock);
/* 1111 */     } catch (DeserializationException e) {
/* 1112 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1113 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1115 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_isChangePlan(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1124 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespSObj = this.myns1_isChangePlanResponse__WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer.deserialize(ns1_isChangePlan_isChangePlanResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1128 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_isChangePlan_isChangePlanResponse_QNAME);
/* 1129 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespSObj);
/* 1130 */       state.getResponse().setBody(bodyBlock);
/* 1131 */     } catch (DeserializationException e) {
/* 1132 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1133 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1135 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateCompatibilityPlanModel_v2(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1144 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespSObj = this.myns1_validateCompatibilityPlanModel_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer.deserialize(ns1_validateCompatibilityPlanModel_v2_validateCompatibilityPlanModel_v2Response_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1148 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanModel_v2_validateCompatibilityPlanModel_v2Response_QNAME);
/* 1149 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespSObj);
/* 1150 */       state.getResponse().setBody(bodyBlock);
/* 1151 */     } catch (DeserializationException e) {
/* 1152 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1153 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1155 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateNumberSpecialServices(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1164 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespSObj = this.myns1_validateNumberSpecialServicesResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer.deserialize(ns1_validateNumberSpecialServices_validateNumberSpecialServicesResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1168 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateNumberSpecialServices_validateNumberSpecialServicesResponse_QNAME);
/* 1169 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespSObj);
/* 1170 */       state.getResponse().setBody(bodyBlock);
/* 1171 */     } catch (DeserializationException e) {
/* 1172 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1173 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1175 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateChangePlanText(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1184 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespSObj = this.myns1_validateChangePlanTextResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer.deserialize(ns1_validateChangePlanText_validateChangePlanTextResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1188 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateChangePlanText_validateChangePlanTextResponse_QNAME);
/* 1189 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespSObj);
/* 1190 */       state.getResponse().setBody(bodyBlock);
/* 1191 */     } catch (DeserializationException e) {
/* 1192 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1193 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1195 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateCompatibilityPlanModel(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1204 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespSObj = this.myns1_validateCompatibilityPlanModelResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer.deserialize(ns1_validateCompatibilityPlanModel_validateCompatibilityPlanModelResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1208 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanModel_validateCompatibilityPlanModelResponse_QNAME);
/* 1209 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespSObj);
/* 1210 */       state.getResponse().setBody(bodyBlock);
/* 1211 */     } catch (DeserializationException e) {
/* 1212 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1213 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1215 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateCompatibilityPlanServices(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1224 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespSObj = this.myns1_validateCompatibilityPlanServicesResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer.deserialize(ns1_validateCompatibilityPlanServices_validateCompatibilityPlanServicesResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1228 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityPlanServices_validateCompatibilityPlanServicesResponse_QNAME);
/* 1229 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespSObj);
/* 1230 */       state.getResponse().setBody(bodyBlock);
/* 1231 */     } catch (DeserializationException e) {
/* 1232 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1233 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1235 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validatePlan(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1244 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespSObj = this.myns1_validatePlanResponse__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer.deserialize(ns1_validatePlan_validatePlanResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1248 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validatePlan_validatePlanResponse_QNAME);
/* 1249 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespSObj);
/* 1250 */       state.getResponse().setBody(bodyBlock);
/* 1251 */     } catch (DeserializationException e) {
/* 1252 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1253 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1255 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _deserialize_validateCompatibilityServicesModel(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*      */     try {
/* 1264 */       Object myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespSObj = this.myns1_validateCompatibilityServicesModelResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer.deserialize(ns1_validateCompatibilityServicesModel_validateCompatibilityServicesModelResponse_QNAME, bodyReader, deserializationContext);
/*      */ 
/*      */ 
/*      */       
/* 1268 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_validateCompatibilityServicesModel_validateCompatibilityServicesModelResponse_QNAME);
/* 1269 */       bodyBlock.setValue(myWSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespSObj);
/* 1270 */       state.getResponse().setBody(bodyBlock);
/* 1271 */     } catch (DeserializationException e) {
/* 1272 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 1273 */         e.setSoapFaultSubCodeType(6);
/*      */       }
/* 1275 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String _getEncodingStyle() {
/* 1283 */     return SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding();
/*      */   }
/*      */   
/*      */   public void _setEncodingStyle(String encodingStyle) {
/* 1287 */     throw new UnsupportedOperationException("cannot set encoding style");
/*      */   }
/*      */   
/*      */   public ClientTransport getClientTransport() {
/* 1291 */     return (ClientTransport)_getTransport();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] _getNamespaceDeclarations() {
/* 1302 */     return myNamespace_declarations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QName[] _getUnderstoodHeaders() {
/* 1309 */     return understoodHeaderNames;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleEmptyBody(XMLReader reader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void _initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 1319 */     super._initialize(registry);
/* 1320 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateAuthorisedProfileResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS"), ns1_validateAuthorisedProfileResponse_TYPE_QNAME);
/* 1321 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityServicesModel_v2__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS"), ns1_validateCompatibilityServicesModel_v2_TYPE_QNAME);
/* 1322 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanServices__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS"), ns1_validateCompatibilityPlanServices_TYPE_QNAME);
/* 1323 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateDisConnectionService__WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS"), ns1_validateDisConnectionService_TYPE_QNAME);
/* 1324 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validatePlan_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS"), ns1_validatePlan_v2Response_TYPE_QNAME);
/* 1325 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validatePlanResponse__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS"), ns1_validatePlanResponse_TYPE_QNAME);
/* 1326 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateChangePlanText__WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS"), ns1_validateChangePlanText_TYPE_QNAME);
/* 1327 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateDisConnectionServiceResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS"), ns1_validateDisConnectionServiceResponse_TYPE_QNAME);
/* 1328 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_isChangePlanResponse__WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS"), ns1_isChangePlanResponse_TYPE_QNAME);
/* 1329 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validatePlan__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS"), ns1_validatePlan_TYPE_QNAME);
/* 1330 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanServicesResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS"), ns1_validateCompatibilityPlanServicesResponse_TYPE_QNAME);
/* 1331 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateNumberSpecialServicesResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS"), ns1_validateNumberSpecialServicesResponse_TYPE_QNAME);
/* 1332 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateAffiliationService__WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS"), ns1_validateAffiliationService_TYPE_QNAME);
/* 1333 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanModel_v2__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS"), ns1_validateCompatibilityPlanModel_v2_TYPE_QNAME);
/* 1334 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanModelResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS"), ns1_validateCompatibilityPlanModelResponse_TYPE_QNAME);
/* 1335 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateAuthorisedProfile__WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS"), ns1_validateAuthorisedProfile_TYPE_QNAME);
/* 1336 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanPromotionDealer__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS"), ns1_validateCompatibilityPlanPromotionDealer_TYPE_QNAME);
/* 1337 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityServicesModel_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS"), ns1_validateCompatibilityServicesModel_v2Response_TYPE_QNAME);
/* 1338 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validatePlanConsejoComunal__WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS"), ns1_validatePlanConsejoComunal_TYPE_QNAME);
/* 1339 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanModel_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS"), ns1_validateCompatibilityPlanModel_v2Response_TYPE_QNAME);
/* 1340 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_isChangePlan__WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS"), ns1_isChangePlan_TYPE_QNAME);
/* 1341 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateChangePlanTextResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS"), ns1_validateChangePlanTextResponse_TYPE_QNAME);
/* 1342 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateAffiliationServiceResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS"), ns1_validateAffiliationServiceResponse_TYPE_QNAME);
/* 1343 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityServicesModel__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS"), ns1_validateCompatibilityServicesModel_TYPE_QNAME);
/* 1344 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanPromotionDealerResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS"), ns1_validateCompatibilityPlanPromotionDealerResponse_TYPE_QNAME);
/* 1345 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validatePlan_v2__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS"), ns1_validatePlan_v2_TYPE_QNAME);
/* 1346 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validatePlanConsejoComunalResponse__WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS"), ns1_validatePlanConsejoComunalResponse_TYPE_QNAME);
/* 1347 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateNumberSpecialServices__WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS"), ns1_validateNumberSpecialServices_TYPE_QNAME);
/* 1348 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityServicesModelResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS"), ns1_validateCompatibilityServicesModelResponse_TYPE_QNAME);
/* 1349 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS == null); ((WSPrepayBaseBrPlanOfferSoapHttp_Stub)registry).myns1_validateCompatibilityPlanModel__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS"), ns1_validateCompatibilityPlanModel_TYPE_QNAME);
/*      */   }
/*      */   
/* 1352 */   private static final QName _portName = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "planoffer");
/*      */   private static final int validatePlanConsejoComunal_OPCODE = 0;
/*      */   private static final int validateAuthorisedProfile_OPCODE = 1;
/*      */   private static final int validateCompatibilityPlanPromotionDealer_OPCODE = 2;
/*      */   private static final int validatePlan_v2_OPCODE = 3;
/*      */   private static final int validateCompatibilityServicesModel_v2_OPCODE = 4;
/*      */   private static final int validateAffiliationService_OPCODE = 5;
/*      */   private static final int validateDisConnectionService_OPCODE = 6;
/*      */   private static final int isChangePlan_OPCODE = 7;
/*      */   private static final int validateCompatibilityPlanModel_v2_OPCODE = 8;
/*      */   private static final int validateNumberSpecialServices_OPCODE = 9;
/*      */   private static final int validateChangePlanText_OPCODE = 10;
/*      */   private static final int validateCompatibilityPlanModel_OPCODE = 11;
/*      */   private static final int validateCompatibilityPlanServices_OPCODE = 12;
/*      */   private static final int validatePlan_OPCODE = 13;
/*      */   private static final int validateCompatibilityServicesModel_OPCODE = 14;
/* 1368 */   private static final QName ns1_validatePlanConsejoComunal_validatePlanConsejoComunal_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunal");
/* 1369 */   private static final QName ns1_validatePlanConsejoComunal_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunal");
/*      */   private CombinedSerializer myns1_validatePlanConsejoComunal__WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer;
/* 1371 */   private static final QName ns1_validatePlanConsejoComunal_validatePlanConsejoComunalResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunalResponse");
/* 1372 */   private static final QName ns1_validatePlanConsejoComunalResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunalResponse");
/*      */   private CombinedSerializer myns1_validatePlanConsejoComunalResponse__WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer;
/* 1374 */   private static final QName ns1_validateAuthorisedProfile_validateAuthorisedProfile_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfile");
/* 1375 */   private static final QName ns1_validateAuthorisedProfile_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfile");
/*      */   private CombinedSerializer myns1_validateAuthorisedProfile__WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer;
/* 1377 */   private static final QName ns1_validateAuthorisedProfile_validateAuthorisedProfileResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfileResponse");
/* 1378 */   private static final QName ns1_validateAuthorisedProfileResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfileResponse");
/*      */   private CombinedSerializer myns1_validateAuthorisedProfileResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer;
/* 1380 */   private static final QName ns1_validateCompatibilityPlanPromotionDealer_validateCompatibilityPlanPromotionDealer_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealer");
/* 1381 */   private static final QName ns1_validateCompatibilityPlanPromotionDealer_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealer");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanPromotionDealer__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer;
/* 1383 */   private static final QName ns1_validateCompatibilityPlanPromotionDealer_validateCompatibilityPlanPromotionDealerResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealerResponse");
/* 1384 */   private static final QName ns1_validateCompatibilityPlanPromotionDealerResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealerResponse");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanPromotionDealerResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer;
/* 1386 */   private static final QName ns1_validatePlan_v2_validatePlan_v2_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2");
/* 1387 */   private static final QName ns1_validatePlan_v2_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2");
/*      */   private CombinedSerializer myns1_validatePlan_v2__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer;
/* 1389 */   private static final QName ns1_validatePlan_v2_validatePlan_v2Response_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2Response");
/* 1390 */   private static final QName ns1_validatePlan_v2Response_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2Response");
/*      */   private CombinedSerializer myns1_validatePlan_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer;
/* 1392 */   private static final QName ns1_validateCompatibilityServicesModel_v2_validateCompatibilityServicesModel_v2_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2");
/* 1393 */   private static final QName ns1_validateCompatibilityServicesModel_v2_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2");
/*      */   private CombinedSerializer myns1_validateCompatibilityServicesModel_v2__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer;
/* 1395 */   private static final QName ns1_validateCompatibilityServicesModel_v2_validateCompatibilityServicesModel_v2Response_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2Response");
/* 1396 */   private static final QName ns1_validateCompatibilityServicesModel_v2Response_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2Response");
/*      */   private CombinedSerializer myns1_validateCompatibilityServicesModel_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer;
/* 1398 */   private static final QName ns1_validateAffiliationService_validateAffiliationService_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationService");
/* 1399 */   private static final QName ns1_validateAffiliationService_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationService");
/*      */   private CombinedSerializer myns1_validateAffiliationService__WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer;
/* 1401 */   private static final QName ns1_validateAffiliationService_validateAffiliationServiceResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationServiceResponse");
/* 1402 */   private static final QName ns1_validateAffiliationServiceResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationServiceResponse");
/*      */   private CombinedSerializer myns1_validateAffiliationServiceResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer;
/* 1404 */   private static final QName ns1_validateDisConnectionService_validateDisConnectionService_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionService");
/* 1405 */   private static final QName ns1_validateDisConnectionService_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionService");
/*      */   private CombinedSerializer myns1_validateDisConnectionService__WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer;
/* 1407 */   private static final QName ns1_validateDisConnectionService_validateDisConnectionServiceResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionServiceResponse");
/* 1408 */   private static final QName ns1_validateDisConnectionServiceResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionServiceResponse");
/*      */   private CombinedSerializer myns1_validateDisConnectionServiceResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer;
/* 1410 */   private static final QName ns1_isChangePlan_isChangePlan_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlan");
/* 1411 */   private static final QName ns1_isChangePlan_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlan");
/*      */   private CombinedSerializer myns1_isChangePlan__WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer;
/* 1413 */   private static final QName ns1_isChangePlan_isChangePlanResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlanResponse");
/* 1414 */   private static final QName ns1_isChangePlanResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlanResponse");
/*      */   private CombinedSerializer myns1_isChangePlanResponse__WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer;
/* 1416 */   private static final QName ns1_validateCompatibilityPlanModel_v2_validateCompatibilityPlanModel_v2_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2");
/* 1417 */   private static final QName ns1_validateCompatibilityPlanModel_v2_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanModel_v2__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer;
/* 1419 */   private static final QName ns1_validateCompatibilityPlanModel_v2_validateCompatibilityPlanModel_v2Response_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2Response");
/* 1420 */   private static final QName ns1_validateCompatibilityPlanModel_v2Response_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2Response");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanModel_v2Response__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer;
/* 1422 */   private static final QName ns1_validateNumberSpecialServices_validateNumberSpecialServices_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServices");
/* 1423 */   private static final QName ns1_validateNumberSpecialServices_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServices");
/*      */   private CombinedSerializer myns1_validateNumberSpecialServices__WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer;
/* 1425 */   private static final QName ns1_validateNumberSpecialServices_validateNumberSpecialServicesResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServicesResponse");
/* 1426 */   private static final QName ns1_validateNumberSpecialServicesResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServicesResponse");
/*      */   private CombinedSerializer myns1_validateNumberSpecialServicesResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer;
/* 1428 */   private static final QName ns1_validateChangePlanText_validateChangePlanText_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanText");
/* 1429 */   private static final QName ns1_validateChangePlanText_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanText");
/*      */   private CombinedSerializer myns1_validateChangePlanText__WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer;
/* 1431 */   private static final QName ns1_validateChangePlanText_validateChangePlanTextResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanTextResponse");
/* 1432 */   private static final QName ns1_validateChangePlanTextResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanTextResponse");
/*      */   private CombinedSerializer myns1_validateChangePlanTextResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer;
/* 1434 */   private static final QName ns1_validateCompatibilityPlanModel_validateCompatibilityPlanModel_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel");
/* 1435 */   private static final QName ns1_validateCompatibilityPlanModel_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanModel__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer;
/* 1437 */   private static final QName ns1_validateCompatibilityPlanModel_validateCompatibilityPlanModelResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModelResponse");
/* 1438 */   private static final QName ns1_validateCompatibilityPlanModelResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModelResponse");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanModelResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer;
/* 1440 */   private static final QName ns1_validateCompatibilityPlanServices_validateCompatibilityPlanServices_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServices");
/* 1441 */   private static final QName ns1_validateCompatibilityPlanServices_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServices");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanServices__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer;
/* 1443 */   private static final QName ns1_validateCompatibilityPlanServices_validateCompatibilityPlanServicesResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServicesResponse");
/* 1444 */   private static final QName ns1_validateCompatibilityPlanServicesResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServicesResponse");
/*      */   private CombinedSerializer myns1_validateCompatibilityPlanServicesResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer;
/* 1446 */   private static final QName ns1_validatePlan_validatePlan_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan");
/* 1447 */   private static final QName ns1_validatePlan_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan");
/*      */   private CombinedSerializer myns1_validatePlan__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer;
/* 1449 */   private static final QName ns1_validatePlan_validatePlanResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanResponse");
/* 1450 */   private static final QName ns1_validatePlanResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanResponse");
/*      */   private CombinedSerializer myns1_validatePlanResponse__WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer;
/* 1452 */   private static final QName ns1_validateCompatibilityServicesModel_validateCompatibilityServicesModel_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel");
/* 1453 */   private static final QName ns1_validateCompatibilityServicesModel_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel");
/*      */   private CombinedSerializer myns1_validateCompatibilityServicesModel__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer;
/* 1455 */   private static final QName ns1_validateCompatibilityServicesModel_validateCompatibilityServicesModelResponse_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModelResponse");
/* 1456 */   private static final QName ns1_validateCompatibilityServicesModelResponse_TYPE_QNAME = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModelResponse");
/*      */   private CombinedSerializer myns1_validateCompatibilityServicesModelResponse__WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer;
/* 1458 */   private static final String[] myNamespace_declarations = new String[] { "ns0", "http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "ns1", "http://to.ws.cia.gdis.movilnet.com.ve/types/" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1464 */   private static final QName[] understoodHeaderNames = new QName[0];
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS;
/*      */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS;
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_Stub.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */