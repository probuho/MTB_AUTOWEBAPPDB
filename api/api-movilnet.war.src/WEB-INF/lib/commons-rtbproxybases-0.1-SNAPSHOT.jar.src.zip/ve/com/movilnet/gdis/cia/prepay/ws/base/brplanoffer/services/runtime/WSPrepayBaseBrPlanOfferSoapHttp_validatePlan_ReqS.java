/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidatePlanRequestTO planRequest;
/*    */   
/*    */   public ValidatePlanRequestTO getPlanRequest() {
/* 17 */     return this.planRequest;
/*    */   }
/*    */   
/*    */   public void setPlanRequest(ValidatePlanRequestTO planRequest) {
/* 21 */     this.planRequest = planRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */