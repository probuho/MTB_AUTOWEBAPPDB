/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateChangePlanTextRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String newPlantextoCode;
/*    */   protected long subscriberId;
/*    */   protected String userId;
/*    */   
/*    */   public String getNewPlantextoCode() {
/* 19 */     return this.newPlantextoCode;
/*    */   }
/*    */   
/*    */   public void setNewPlantextoCode(String newPlantextoCode) {
/* 23 */     this.newPlantextoCode = newPlantextoCode;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 27 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 31 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getUserId() {
/* 35 */     return this.userId;
/*    */   }
/*    */   
/*    */   public void setUserId(String userId) {
/* 39 */     this.userId = userId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateChangePlanTextRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */