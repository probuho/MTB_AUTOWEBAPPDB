/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StateTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String stateCode;
/*    */   protected String stateName;
/*    */   
/*    */   public String getStateCode() {
/* 18 */     return this.stateCode;
/*    */   }
/*    */   
/*    */   public void setStateCode(String stateCode) {
/* 22 */     this.stateCode = stateCode;
/*    */   }
/*    */   
/*    */   public String getStateName() {
/* 26 */     return this.stateName;
/*    */   }
/*    */   
/*    */   public void setStateName(String stateName) {
/* 30 */     this.stateName = stateName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\StateTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */