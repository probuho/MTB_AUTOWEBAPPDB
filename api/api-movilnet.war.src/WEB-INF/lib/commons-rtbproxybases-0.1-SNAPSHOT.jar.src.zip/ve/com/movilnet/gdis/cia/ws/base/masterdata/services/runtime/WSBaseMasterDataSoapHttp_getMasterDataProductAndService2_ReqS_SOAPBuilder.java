/*    */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS _instance;
/*    */   private MasterDataRequestTO masterRequest;
/*    */   private static final int mymasterRequest_INDEX = 0;
/*    */   
/*    */   public void setMasterRequest(MasterDataRequestTO masterRequest) {
/* 21 */     this.masterRequest = masterRequest;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 25 */     switch (memberIndex) {
/*    */       case 0:
/* 27 */         return 6;
/*    */     } 
/* 29 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 38 */       switch (index) {
/*    */         case 0:
/* 40 */           this._instance.setMasterRequest((MasterDataRequestTO)memberValue);
/*    */           return;
/*    */       } 
/* 43 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 46 */     catch (RuntimeException e) {
/* 47 */       throw e;
/*    */     }
/* 49 */     catch (Exception e) {
/* 50 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 58 */     this._instance = (WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 62 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\runtime\WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */