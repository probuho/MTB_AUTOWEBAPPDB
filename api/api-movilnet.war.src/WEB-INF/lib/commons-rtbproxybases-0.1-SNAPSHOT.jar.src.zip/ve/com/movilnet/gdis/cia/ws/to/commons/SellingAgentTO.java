/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SellingAgentTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String dealerCode;
/*    */   protected String dealerName;
/*    */   protected String status;
/*    */   
/*    */   public String getDealerCode() {
/* 19 */     return this.dealerCode;
/*    */   }
/*    */   
/*    */   public void setDealerCode(String dealerCode) {
/* 23 */     this.dealerCode = dealerCode;
/*    */   }
/*    */   
/*    */   public String getDealerName() {
/* 27 */     return this.dealerName;
/*    */   }
/*    */   
/*    */   public void setDealerName(String dealerName) {
/* 31 */     this.dealerName = dealerName;
/*    */   }
/*    */   
/*    */   public String getStatus() {
/* 35 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(String status) {
/* 39 */     this.status = status;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\SellingAgentTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */