/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateChangeBRPlanRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String planCodeNew;
/*    */   protected long subscriberId;
/*    */   protected String userId;
/*    */   
/*    */   public String getPlanCodeNew() {
/* 19 */     return this.planCodeNew;
/*    */   }
/*    */   
/*    */   public void setPlanCodeNew(String planCodeNew) {
/* 23 */     this.planCodeNew = planCodeNew;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 27 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 31 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getUserId() {
/* 35 */     return this.userId;
/*    */   }
/*    */   
/*    */   public void setUserId(String userId) {
/* 39 */     this.userId = userId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateChangeBRPlanRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */