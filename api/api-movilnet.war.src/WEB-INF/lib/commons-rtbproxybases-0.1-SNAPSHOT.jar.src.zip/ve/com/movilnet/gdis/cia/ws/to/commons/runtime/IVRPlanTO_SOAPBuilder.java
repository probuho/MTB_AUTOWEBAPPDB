/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IVRPlanTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private IVRPlanTO _instance;
/*     */   private String accumulatedUsageInd;
/*     */   private String cosNameSuffix;
/*     */   private int minutosIncluidos;
/*     */   private String nombreComercial;
/*     */   private String planCode;
/*     */   private String planType;
/*     */   private String planUnitType;
/*     */   private String rentaBasicaInd;
/*     */   private int smsIncluidos;
/*     */   private static final int myaccumulatedUsageInd_INDEX = 0;
/*     */   private static final int mycosNameSuffix_INDEX = 1;
/*     */   private static final int myminutosIncluidos_INDEX = 2;
/*     */   private static final int mynombreComercial_INDEX = 3;
/*     */   private static final int myplanCode_INDEX = 4;
/*     */   private static final int myplanType_INDEX = 5;
/*     */   private static final int myplanUnitType_INDEX = 6;
/*     */   private static final int myrentaBasicaInd_INDEX = 7;
/*     */   private static final int mysmsIncluidos_INDEX = 8;
/*     */   
/*     */   public void setAccumulatedUsageInd(String accumulatedUsageInd) {
/*  37 */     this.accumulatedUsageInd = accumulatedUsageInd;
/*     */   }
/*     */   
/*     */   public void setCosNameSuffix(String cosNameSuffix) {
/*  41 */     this.cosNameSuffix = cosNameSuffix;
/*     */   }
/*     */   
/*     */   public void setMinutosIncluidos(int minutosIncluidos) {
/*  45 */     this.minutosIncluidos = minutosIncluidos;
/*     */   }
/*     */   
/*     */   public void setNombreComercial(String nombreComercial) {
/*  49 */     this.nombreComercial = nombreComercial;
/*     */   }
/*     */   
/*     */   public void setPlanCode(String planCode) {
/*  53 */     this.planCode = planCode;
/*     */   }
/*     */   
/*     */   public void setPlanType(String planType) {
/*  57 */     this.planType = planType;
/*     */   }
/*     */   
/*     */   public void setPlanUnitType(String planUnitType) {
/*  61 */     this.planUnitType = planUnitType;
/*     */   }
/*     */   
/*     */   public void setRentaBasicaInd(String rentaBasicaInd) {
/*  65 */     this.rentaBasicaInd = rentaBasicaInd;
/*     */   }
/*     */   
/*     */   public void setSmsIncluidos(int smsIncluidos) {
/*  69 */     this.smsIncluidos = smsIncluidos;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  73 */     switch (memberIndex) {
/*     */       case 0:
/*  75 */         return 6;
/*     */       case 1:
/*  77 */         return 6;
/*     */       case 2:
/*  79 */         return 6;
/*     */       case 3:
/*  81 */         return 6;
/*     */       case 4:
/*  83 */         return 6;
/*     */       case 5:
/*  85 */         return 6;
/*     */       case 6:
/*  87 */         return 6;
/*     */       case 7:
/*  89 */         return 6;
/*     */       case 8:
/*  91 */         return 6;
/*     */     } 
/*  93 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 102 */       switch (index) {
/*     */         case 0:
/* 104 */           this._instance.setAccumulatedUsageInd((String)memberValue);
/*     */           return;
/*     */         case 1:
/* 107 */           this._instance.setCosNameSuffix((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 110 */           this._instance.setMinutosIncluidos(((Integer)memberValue).intValue());
/*     */           return;
/*     */         case 3:
/* 113 */           this._instance.setNombreComercial((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 116 */           this._instance.setPlanCode((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 119 */           this._instance.setPlanType((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 122 */           this._instance.setPlanUnitType((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 125 */           this._instance.setRentaBasicaInd((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 128 */           this._instance.setSmsIncluidos(((Integer)memberValue).intValue());
/*     */           return;
/*     */       } 
/* 131 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 134 */     catch (RuntimeException e) {
/* 135 */       throw e;
/*     */     }
/* 137 */     catch (Exception e) {
/* 138 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 146 */     this._instance = (IVRPlanTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 150 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\IVRPlanTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */