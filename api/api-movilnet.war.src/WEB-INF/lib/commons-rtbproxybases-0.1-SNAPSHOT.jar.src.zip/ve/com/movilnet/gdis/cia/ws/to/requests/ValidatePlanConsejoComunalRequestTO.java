/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidatePlanConsejoComunalRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String ssn;
/*    */   protected String transactionType;
/*    */   
/*    */   public String getSsn() {
/* 18 */     return this.ssn;
/*    */   }
/*    */   
/*    */   public void setSsn(String ssn) {
/* 22 */     this.ssn = ssn;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 26 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 30 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidatePlanConsejoComunalRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */