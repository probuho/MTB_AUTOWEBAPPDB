/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChargeCodeTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String chargeCodeId;
/*    */   protected String chargeCodeName;
/*    */   protected String periodicChargeId;
/*    */   protected String periodicChargeName;
/*    */   
/*    */   public String getChargeCodeId() {
/* 20 */     return this.chargeCodeId;
/*    */   }
/*    */   
/*    */   public void setChargeCodeId(String chargeCodeId) {
/* 24 */     this.chargeCodeId = chargeCodeId;
/*    */   }
/*    */   
/*    */   public String getChargeCodeName() {
/* 28 */     return this.chargeCodeName;
/*    */   }
/*    */   
/*    */   public void setChargeCodeName(String chargeCodeName) {
/* 32 */     this.chargeCodeName = chargeCodeName;
/*    */   }
/*    */   
/*    */   public String getPeriodicChargeId() {
/* 36 */     return this.periodicChargeId;
/*    */   }
/*    */   
/*    */   public void setPeriodicChargeId(String periodicChargeId) {
/* 40 */     this.periodicChargeId = periodicChargeId;
/*    */   }
/*    */   
/*    */   public String getPeriodicChargeName() {
/* 44 */     return this.periodicChargeName;
/*    */   }
/*    */   
/*    */   public void setPeriodicChargeName(String periodicChargeName) {
/* 48 */     this.periodicChargeName = periodicChargeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ChargeCodeTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */