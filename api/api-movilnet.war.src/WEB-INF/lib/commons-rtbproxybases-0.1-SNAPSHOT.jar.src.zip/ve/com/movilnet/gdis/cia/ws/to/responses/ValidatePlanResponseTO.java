/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidatePlanResponseTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected short maxGeneralQuantity;
/*    */   protected short maxQuantityPerTecnology;
/*    */   protected boolean result;
/*    */   
/*    */   public short getMaxGeneralQuantity() {
/* 19 */     return this.maxGeneralQuantity;
/*    */   }
/*    */   
/*    */   public void setMaxGeneralQuantity(short maxGeneralQuantity) {
/* 23 */     this.maxGeneralQuantity = maxGeneralQuantity;
/*    */   }
/*    */   
/*    */   public short getMaxQuantityPerTecnology() {
/* 27 */     return this.maxQuantityPerTecnology;
/*    */   }
/*    */   
/*    */   public void setMaxQuantityPerTecnology(short maxQuantityPerTecnology) {
/* 31 */     this.maxQuantityPerTecnology = maxQuantityPerTecnology;
/*    */   }
/*    */   
/*    */   public boolean isResult() {
/* 35 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(boolean result) {
/* 39 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\ValidatePlanResponseTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */