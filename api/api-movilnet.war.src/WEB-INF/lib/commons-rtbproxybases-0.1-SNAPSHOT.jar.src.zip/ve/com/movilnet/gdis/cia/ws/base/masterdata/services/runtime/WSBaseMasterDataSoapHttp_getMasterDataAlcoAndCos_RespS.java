/*    */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS
/*    */   implements Serializable
/*    */ {
/*    */   protected AlcoCosResponseTO result;
/*    */   
/*    */   public AlcoCosResponseTO getResult() {
/* 17 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(AlcoCosResponseTO result) {
/* 21 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\runtime\WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */