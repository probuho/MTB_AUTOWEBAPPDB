/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IVRPlanTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String accumulatedUsageInd;
/*    */   protected String cosNameSuffix;
/*    */   protected int minutosIncluidos;
/*    */   protected String nombreComercial;
/*    */   protected String planCode;
/*    */   protected String planType;
/*    */   protected String planUnitType;
/*    */   protected String rentaBasicaInd;
/*    */   protected int smsIncluidos;
/*    */   
/*    */   public String getAccumulatedUsageInd() {
/* 25 */     return this.accumulatedUsageInd;
/*    */   }
/*    */   
/*    */   public void setAccumulatedUsageInd(String accumulatedUsageInd) {
/* 29 */     this.accumulatedUsageInd = accumulatedUsageInd;
/*    */   }
/*    */   
/*    */   public String getCosNameSuffix() {
/* 33 */     return this.cosNameSuffix;
/*    */   }
/*    */   
/*    */   public void setCosNameSuffix(String cosNameSuffix) {
/* 37 */     this.cosNameSuffix = cosNameSuffix;
/*    */   }
/*    */   
/*    */   public int getMinutosIncluidos() {
/* 41 */     return this.minutosIncluidos;
/*    */   }
/*    */   
/*    */   public void setMinutosIncluidos(int minutosIncluidos) {
/* 45 */     this.minutosIncluidos = minutosIncluidos;
/*    */   }
/*    */   
/*    */   public String getNombreComercial() {
/* 49 */     return this.nombreComercial;
/*    */   }
/*    */   
/*    */   public void setNombreComercial(String nombreComercial) {
/* 53 */     this.nombreComercial = nombreComercial;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 57 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 61 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getPlanType() {
/* 65 */     return this.planType;
/*    */   }
/*    */   
/*    */   public void setPlanType(String planType) {
/* 69 */     this.planType = planType;
/*    */   }
/*    */   
/*    */   public String getPlanUnitType() {
/* 73 */     return this.planUnitType;
/*    */   }
/*    */   
/*    */   public void setPlanUnitType(String planUnitType) {
/* 77 */     this.planUnitType = planUnitType;
/*    */   }
/*    */   
/*    */   public String getRentaBasicaInd() {
/* 81 */     return this.rentaBasicaInd;
/*    */   }
/*    */   
/*    */   public void setRentaBasicaInd(String rentaBasicaInd) {
/* 85 */     this.rentaBasicaInd = rentaBasicaInd;
/*    */   }
/*    */   
/*    */   public int getSmsIncluidos() {
/* 89 */     return this.smsIncluidos;
/*    */   }
/*    */   
/*    */   public void setSmsIncluidos(int smsIncluidos) {
/* 93 */     this.smsIncluidos = smsIncluidos;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\IVRPlanTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */