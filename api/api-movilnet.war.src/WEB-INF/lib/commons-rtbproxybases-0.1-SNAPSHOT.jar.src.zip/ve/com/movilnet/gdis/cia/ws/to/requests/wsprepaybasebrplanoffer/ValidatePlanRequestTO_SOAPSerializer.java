/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidatePlanRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidatePlanRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_entrada_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "entrada");
/*  33 */   private static final QName ns2_ArrayOfstring_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/*     */   private CombinedSerializer myns2_ArrayOfstring__String_Array_LiteralSerializer1;
/*  35 */   private static final QName ns2_planCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCode");
/*  36 */   private static final QName ns2_planCosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCosName");
/*  37 */   private static final QName ns2_ssn_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ssn");
/*  38 */   private static final QName ns2_subscriberId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subscriberId");
/*  39 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  41 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2; private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myentrada_INDEX = 5;
/*     */   private static final int myplanCode_INDEX = 6;
/*     */   private static final int myplanCosName_INDEX = 7;
/*     */   private static final int myssn_INDEX = 8;
/*     */   private static final int mysubscriberId_INDEX = 9;
/*     */   private static final int mytransactionType_INDEX = 10;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   
/*     */   public ValidatePlanRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  55 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  59 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidatePlanRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  60 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidatePlanRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  61 */     if (class$java$lang$String == null); ((ValidatePlanRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  62 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  63 */     if (array$Ljava$lang$String == null); ((ValidatePlanRequestTO_SOAPSerializer)registry).myns2_ArrayOfstring__String_Array_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), ns2_ArrayOfstring_TYPE_QNAME);
/*  64 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  69 */     ValidatePlanRequestTO instance = new ValidatePlanRequestTO();
/*  70 */     ValidatePlanRequestTO_SOAPBuilder builder = null;
/*     */     
/*  72 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  75 */     reader.nextElementContent();
/*  76 */     QName startName = reader.getName();
/*  77 */     for (int i = 0; i < 11; i++) {
/*  78 */       QName elementName = reader.getName();
/*  79 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  82 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  83 */         context.setNillable(true);
/*  84 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  85 */         if (member instanceof SOAPDeserializationState) {
/*  86 */           if (builder == null) {
/*  87 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/*  89 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  90 */           isComplete = false;
/*  91 */         } else if (member != null) {
/*  92 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  94 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  97 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  98 */         context.setNillable(true);
/*  99 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/* 100 */         if (object instanceof SOAPDeserializationState) {
/* 101 */           if (builder == null) {
/* 102 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 104 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 105 */           isComplete = false;
/* 106 */         } else if (object != null) {
/* 107 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 109 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 112 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 113 */         context.setNillable(true);
/* 114 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 115 */         if (object instanceof SOAPDeserializationState) {
/* 116 */           if (builder == null) {
/* 117 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 119 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 120 */           isComplete = false;
/* 121 */         } else if (object != null) {
/* 122 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 124 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 127 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 128 */         context.setNillable(true);
/* 129 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 130 */         if (object instanceof SOAPDeserializationState) {
/* 131 */           if (builder == null) {
/* 132 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 134 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 135 */           isComplete = false;
/* 136 */         } else if (object != null) {
/* 137 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 139 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 142 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 143 */         context.setNillable(true);
/* 144 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 145 */         if (object instanceof SOAPDeserializationState) {
/* 146 */           if (builder == null) {
/* 147 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 149 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 150 */           isComplete = false;
/* 151 */         } else if (object != null) {
/* 152 */           instance.setTransactionId((String)object);
/*     */         } 
/* 154 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 157 */       else if (matchQName(elementName, ns2_entrada_QNAME)) {
/* 158 */         context.setNillable(true);
/* 159 */         Object object = this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.deserialize(ns2_entrada_QNAME, reader, context);
/* 160 */         if (object instanceof SOAPDeserializationState) {
/* 161 */           if (builder == null) {
/* 162 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 164 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 165 */           isComplete = false;
/* 166 */         } else if (object != null) {
/* 167 */           instance.setEntrada((String[])object);
/*     */         } 
/* 169 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 172 */       else if (matchQName(elementName, ns2_planCode_QNAME)) {
/* 173 */         context.setNillable(true);
/* 174 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCode_QNAME, reader, context);
/* 175 */         if (object instanceof SOAPDeserializationState) {
/* 176 */           if (builder == null) {
/* 177 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 179 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 180 */           isComplete = false;
/* 181 */         } else if (object != null) {
/* 182 */           instance.setPlanCode((String)object);
/*     */         } 
/* 184 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 187 */       else if (matchQName(elementName, ns2_planCosName_QNAME)) {
/* 188 */         context.setNillable(true);
/* 189 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCosName_QNAME, reader, context);
/* 190 */         if (object instanceof SOAPDeserializationState) {
/* 191 */           if (builder == null) {
/* 192 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 194 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 195 */           isComplete = false;
/* 196 */         } else if (object != null) {
/* 197 */           instance.setPlanCosName((String)object);
/*     */         } 
/* 199 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 202 */       else if (matchQName(elementName, ns2_ssn_QNAME)) {
/* 203 */         context.setNillable(true);
/* 204 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_ssn_QNAME, reader, context);
/* 205 */         if (object instanceof SOAPDeserializationState) {
/* 206 */           if (builder == null) {
/* 207 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 209 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 210 */           isComplete = false;
/* 211 */         } else if (object != null) {
/* 212 */           instance.setSsn((String)object);
/*     */         } 
/* 214 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 217 */       else if (matchQName(elementName, ns2_subscriberId_QNAME)) {
/* 218 */         context.setNillable(true);
/* 219 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_subscriberId_QNAME, reader, context);
/* 220 */         if (object instanceof SOAPDeserializationState) {
/* 221 */           if (builder == null) {
/* 222 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 224 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 225 */           isComplete = false;
/* 226 */         } else if (object != null) {
/* 227 */           instance.setSubscriberId(((Long)object).longValue());
/*     */         } 
/* 229 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 232 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 233 */         context.setNillable(true);
/* 234 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 235 */         if (object instanceof SOAPDeserializationState) {
/* 236 */           if (builder == null) {
/* 237 */             builder = new ValidatePlanRequestTO_SOAPBuilder();
/*     */           }
/* 239 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 240 */           isComplete = false;
/* 241 */         } else if (object != null) {
/* 242 */           instance.setTransactionType((String)object);
/*     */         } 
/* 244 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 247 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 252 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 253 */     } catch (XMLReaderException xmle) {
/* 254 */       if (startName != null) {
/* 255 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 257 */       throw xmle;
/*     */     } 
/*     */     
/* 260 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 264 */     ValidatePlanRequestTO instance = (ValidatePlanRequestTO)obj;
/*     */     
/* 266 */     context.setNillable(true);
/* 267 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 268 */     context.setNillable(true);
/* 269 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 270 */     context.setNillable(true);
/* 271 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 272 */     context.setNillable(true);
/* 273 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 274 */     context.setNillable(true);
/* 275 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 276 */     context.setNillable(true);
/* 277 */     this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.serialize(instance.getEntrada(), ns2_entrada_QNAME, null, writer, context);
/* 278 */     context.setNillable(true);
/* 279 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCode(), ns2_planCode_QNAME, null, writer, context);
/* 280 */     context.setNillable(true);
/* 281 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCosName(), ns2_planCosName_QNAME, null, writer, context);
/* 282 */     context.setNillable(true);
/* 283 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getSsn(), ns2_ssn_QNAME, null, writer, context);
/* 284 */     context.setNillable(true);
/* 285 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getSubscriberId()), ns2_subscriberId_QNAME, null, writer, context);
/* 286 */     context.setNillable(true);
/* 287 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidatePlanRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */