/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanConsejoComunalRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidatePlanConsejoComunalRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidatePlanConsejoComunalRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_ssn_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ssn");
/*  33 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myssn_INDEX = 5;
/*     */   private static final int mytransactionType_INDEX = 6;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ValidatePlanConsejoComunalRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  43 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  47 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidatePlanConsejoComunalRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  48 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidatePlanConsejoComunalRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  49 */     if (class$java$lang$String == null); ((ValidatePlanConsejoComunalRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  50 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  55 */     ValidatePlanConsejoComunalRequestTO instance = new ValidatePlanConsejoComunalRequestTO();
/*  56 */     ValidatePlanConsejoComunalRequestTO_SOAPBuilder builder = null;
/*     */     
/*  58 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  61 */     reader.nextElementContent();
/*  62 */     QName startName = reader.getName();
/*  63 */     for (int i = 0; i < 7; i++) {
/*  64 */       QName elementName = reader.getName();
/*  65 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  68 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  69 */         context.setNillable(true);
/*  70 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  71 */         if (member instanceof SOAPDeserializationState) {
/*  72 */           if (builder == null) {
/*  73 */             builder = new ValidatePlanConsejoComunalRequestTO_SOAPBuilder();
/*     */           }
/*  75 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  76 */           isComplete = false;
/*  77 */         } else if (member != null) {
/*  78 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  80 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  83 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  84 */         context.setNillable(true);
/*  85 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  86 */         if (object instanceof SOAPDeserializationState) {
/*  87 */           if (builder == null) {
/*  88 */             builder = new ValidatePlanConsejoComunalRequestTO_SOAPBuilder();
/*     */           }
/*  90 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  91 */           isComplete = false;
/*  92 */         } else if (object != null) {
/*  93 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/*  95 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  98 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/*  99 */         context.setNillable(true);
/* 100 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 101 */         if (object instanceof SOAPDeserializationState) {
/* 102 */           if (builder == null) {
/* 103 */             builder = new ValidatePlanConsejoComunalRequestTO_SOAPBuilder();
/*     */           }
/* 105 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 106 */           isComplete = false;
/* 107 */         } else if (object != null) {
/* 108 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 110 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 113 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 114 */         context.setNillable(true);
/* 115 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 116 */         if (object instanceof SOAPDeserializationState) {
/* 117 */           if (builder == null) {
/* 118 */             builder = new ValidatePlanConsejoComunalRequestTO_SOAPBuilder();
/*     */           }
/* 120 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 121 */           isComplete = false;
/* 122 */         } else if (object != null) {
/* 123 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 125 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 128 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 129 */         context.setNillable(true);
/* 130 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 131 */         if (object instanceof SOAPDeserializationState) {
/* 132 */           if (builder == null) {
/* 133 */             builder = new ValidatePlanConsejoComunalRequestTO_SOAPBuilder();
/*     */           }
/* 135 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 136 */           isComplete = false;
/* 137 */         } else if (object != null) {
/* 138 */           instance.setTransactionId((String)object);
/*     */         } 
/* 140 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 143 */       else if (matchQName(elementName, ns2_ssn_QNAME)) {
/* 144 */         context.setNillable(true);
/* 145 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_ssn_QNAME, reader, context);
/* 146 */         if (object instanceof SOAPDeserializationState) {
/* 147 */           if (builder == null) {
/* 148 */             builder = new ValidatePlanConsejoComunalRequestTO_SOAPBuilder();
/*     */           }
/* 150 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 151 */           isComplete = false;
/* 152 */         } else if (object != null) {
/* 153 */           instance.setSsn((String)object);
/*     */         } 
/* 155 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 158 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 159 */         context.setNillable(true);
/* 160 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 161 */         if (object instanceof SOAPDeserializationState) {
/* 162 */           if (builder == null) {
/* 163 */             builder = new ValidatePlanConsejoComunalRequestTO_SOAPBuilder();
/*     */           }
/* 165 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 166 */           isComplete = false;
/* 167 */         } else if (object != null) {
/* 168 */           instance.setTransactionType((String)object);
/*     */         } 
/* 170 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 173 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 178 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 179 */     } catch (XMLReaderException xmle) {
/* 180 */       if (startName != null) {
/* 181 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 183 */       throw xmle;
/*     */     } 
/*     */     
/* 186 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 190 */     ValidatePlanConsejoComunalRequestTO instance = (ValidatePlanConsejoComunalRequestTO)obj;
/*     */     
/* 192 */     context.setNillable(true);
/* 193 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 194 */     context.setNillable(true);
/* 195 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 196 */     context.setNillable(true);
/* 197 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 198 */     context.setNillable(true);
/* 199 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 200 */     context.setNillable(true);
/* 201 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 202 */     context.setNillable(true);
/* 203 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getSsn(), ns2_ssn_QNAME, null, writer, context);
/* 204 */     context.setNillable(true);
/* 205 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidatePlanConsejoComunalRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */