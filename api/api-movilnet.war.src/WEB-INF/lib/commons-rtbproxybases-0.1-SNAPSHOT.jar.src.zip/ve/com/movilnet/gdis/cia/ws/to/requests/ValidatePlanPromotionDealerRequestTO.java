/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidatePlanPromotionDealerRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String cosName;
/*    */   protected String dealerCode;
/*    */   protected String planCode;
/*    */   protected String promoId;
/*    */   protected String transactionType;
/*    */   
/*    */   public String getCosName() {
/* 21 */     return this.cosName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 25 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public String getDealerCode() {
/* 29 */     return this.dealerCode;
/*    */   }
/*    */   
/*    */   public void setDealerCode(String dealerCode) {
/* 33 */     this.dealerCode = dealerCode;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 37 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 41 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getPromoId() {
/* 45 */     return this.promoId;
/*    */   }
/*    */   
/*    */   public void setPromoId(String promoId) {
/* 49 */     this.promoId = promoId;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 53 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 57 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidatePlanPromotionDealerRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */