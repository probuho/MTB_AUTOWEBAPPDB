/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateDisConnectionServiceRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidateDisConnectionServiceRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidateDisConnectionServiceRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_serviceCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceCode");
/*  33 */   private static final QName ns2_status_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "status");
/*  34 */   private static final QName ns2_subscriberId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subscriberId");
/*  35 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  37 */   private static final QName ns2_userId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "userId"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myserviceCode_INDEX = 5;
/*     */   private static final int mystatus_INDEX = 6;
/*     */   private static final int mysubscriberId_INDEX = 7;
/*     */   private static final int myuserId_INDEX = 8;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ValidateDisConnectionServiceRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  49 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  53 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidateDisConnectionServiceRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  54 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidateDisConnectionServiceRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  55 */     if (class$java$lang$String == null); ((ValidateDisConnectionServiceRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  56 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  57 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  62 */     ValidateDisConnectionServiceRequestTO instance = new ValidateDisConnectionServiceRequestTO();
/*  63 */     ValidateDisConnectionServiceRequestTO_SOAPBuilder builder = null;
/*     */     
/*  65 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  68 */     reader.nextElementContent();
/*  69 */     QName startName = reader.getName();
/*  70 */     for (int i = 0; i < 9; i++) {
/*  71 */       QName elementName = reader.getName();
/*  72 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  75 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  76 */         context.setNillable(true);
/*  77 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  78 */         if (member instanceof SOAPDeserializationState) {
/*  79 */           if (builder == null) {
/*  80 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/*  82 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  83 */           isComplete = false;
/*  84 */         } else if (member != null) {
/*  85 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  87 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  90 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  91 */         context.setNillable(true);
/*  92 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  93 */         if (object instanceof SOAPDeserializationState) {
/*  94 */           if (builder == null) {
/*  95 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/*  97 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  98 */           isComplete = false;
/*  99 */         } else if (object != null) {
/* 100 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 102 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 105 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 106 */         context.setNillable(true);
/* 107 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 108 */         if (object instanceof SOAPDeserializationState) {
/* 109 */           if (builder == null) {
/* 110 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/* 112 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 113 */           isComplete = false;
/* 114 */         } else if (object != null) {
/* 115 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 117 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 120 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 121 */         context.setNillable(true);
/* 122 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 123 */         if (object instanceof SOAPDeserializationState) {
/* 124 */           if (builder == null) {
/* 125 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/* 127 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 128 */           isComplete = false;
/* 129 */         } else if (object != null) {
/* 130 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 132 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 135 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 136 */         context.setNillable(true);
/* 137 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 138 */         if (object instanceof SOAPDeserializationState) {
/* 139 */           if (builder == null) {
/* 140 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/* 142 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 143 */           isComplete = false;
/* 144 */         } else if (object != null) {
/* 145 */           instance.setTransactionId((String)object);
/*     */         } 
/* 147 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 150 */       else if (matchQName(elementName, ns2_serviceCode_QNAME)) {
/* 151 */         context.setNillable(true);
/* 152 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceCode_QNAME, reader, context);
/* 153 */         if (object instanceof SOAPDeserializationState) {
/* 154 */           if (builder == null) {
/* 155 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/* 157 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 158 */           isComplete = false;
/* 159 */         } else if (object != null) {
/* 160 */           instance.setServiceCode((String)object);
/*     */         } 
/* 162 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 165 */       else if (matchQName(elementName, ns2_status_QNAME)) {
/* 166 */         context.setNillable(true);
/* 167 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_status_QNAME, reader, context);
/* 168 */         if (object instanceof SOAPDeserializationState) {
/* 169 */           if (builder == null) {
/* 170 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/* 172 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 173 */           isComplete = false;
/* 174 */         } else if (object != null) {
/* 175 */           instance.setStatus((String)object);
/*     */         } 
/* 177 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 180 */       else if (matchQName(elementName, ns2_subscriberId_QNAME)) {
/* 181 */         context.setNillable(true);
/* 182 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_subscriberId_QNAME, reader, context);
/* 183 */         if (object instanceof SOAPDeserializationState) {
/* 184 */           if (builder == null) {
/* 185 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/* 187 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 188 */           isComplete = false;
/* 189 */         } else if (object != null) {
/* 190 */           instance.setSubscriberId(((Long)object).longValue());
/*     */         } 
/* 192 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 195 */       else if (matchQName(elementName, ns2_userId_QNAME)) {
/* 196 */         context.setNillable(true);
/* 197 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_userId_QNAME, reader, context);
/* 198 */         if (object instanceof SOAPDeserializationState) {
/* 199 */           if (builder == null) {
/* 200 */             builder = new ValidateDisConnectionServiceRequestTO_SOAPBuilder();
/*     */           }
/* 202 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 203 */           isComplete = false;
/* 204 */         } else if (object != null) {
/* 205 */           instance.setUserId((String)object);
/*     */         } 
/* 207 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 210 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_userId_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 215 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 216 */     } catch (XMLReaderException xmle) {
/* 217 */       if (startName != null) {
/* 218 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 220 */       throw xmle;
/*     */     } 
/*     */     
/* 223 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 227 */     ValidateDisConnectionServiceRequestTO instance = (ValidateDisConnectionServiceRequestTO)obj;
/*     */     
/* 229 */     context.setNillable(true);
/* 230 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 231 */     context.setNillable(true);
/* 232 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 233 */     context.setNillable(true);
/* 234 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 235 */     context.setNillable(true);
/* 236 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 237 */     context.setNillable(true);
/* 238 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 239 */     context.setNillable(true);
/* 240 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceCode(), ns2_serviceCode_QNAME, null, writer, context);
/* 241 */     context.setNillable(true);
/* 242 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getStatus(), ns2_status_QNAME, null, writer, context);
/* 243 */     context.setNillable(true);
/* 244 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getSubscriberId()), ns2_subscriberId_QNAME, null, writer, context);
/* 245 */     context.setNillable(true);
/* 246 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUserId(), ns2_userId_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidateDisConnectionServiceRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */