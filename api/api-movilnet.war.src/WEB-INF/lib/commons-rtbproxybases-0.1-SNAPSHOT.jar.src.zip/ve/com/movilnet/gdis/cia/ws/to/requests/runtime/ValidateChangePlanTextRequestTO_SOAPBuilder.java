/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangePlanTextRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidateChangePlanTextRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidateChangePlanTextRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String newPlantextoCode;
/*     */   private long subscriberId;
/*     */   private String userId;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int mynewPlantextoCode_INDEX = 5;
/*     */   private static final int mysubscriberId_INDEX = 6;
/*     */   private static final int myuserId_INDEX = 7;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  35 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  39 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  43 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  47 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  51 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setNewPlantextoCode(String newPlantextoCode) {
/*  55 */     this.newPlantextoCode = newPlantextoCode;
/*     */   }
/*     */   
/*     */   public void setSubscriberId(long subscriberId) {
/*  59 */     this.subscriberId = subscriberId;
/*     */   }
/*     */   
/*     */   public void setUserId(String userId) {
/*  63 */     this.userId = userId;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  67 */     switch (memberIndex) {
/*     */       case 0:
/*  69 */         return 6;
/*     */       case 1:
/*  71 */         return 6;
/*     */       case 2:
/*  73 */         return 6;
/*     */       case 3:
/*  75 */         return 6;
/*     */       case 4:
/*  77 */         return 6;
/*     */       case 5:
/*  79 */         return 6;
/*     */       case 6:
/*  81 */         return 6;
/*     */       case 7:
/*  83 */         return 6;
/*     */     } 
/*  85 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/*  94 */       switch (index) {
/*     */         case 0:
/*  96 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/*  99 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/* 102 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 105 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 108 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 111 */           this._instance.setNewPlantextoCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 114 */           this._instance.setSubscriberId(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 7:
/* 117 */           this._instance.setUserId((String)memberValue);
/*     */           return;
/*     */       } 
/* 120 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 123 */     catch (RuntimeException e) {
/* 124 */       throw e;
/*     */     }
/* 126 */     catch (Exception e) {
/* 127 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 135 */     this._instance = (ValidateChangePlanTextRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 139 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\ValidateChangePlanTextRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */