/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAuthorisedProfileRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidateAuthorisedProfileRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidateAuthorisedProfileRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String aplicationType;
/*     */   private String customerType;
/*     */   private String[] genfield;
/*     */   private String planCode;
/*     */   private String serviceCode;
/*     */   private String transactionType;
/*     */   private String userSsnId;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myaplicationType_INDEX = 5;
/*     */   private static final int mycustomerType_INDEX = 6;
/*     */   private static final int mygenfield_INDEX = 7;
/*     */   private static final int myplanCode_INDEX = 8;
/*     */   private static final int myserviceCode_INDEX = 9;
/*     */   private static final int mytransactionType_INDEX = 10;
/*     */   private static final int myuserSsnId_INDEX = 11;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  43 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  47 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  51 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  55 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  59 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAplicationType(String aplicationType) {
/*  63 */     this.aplicationType = aplicationType;
/*     */   }
/*     */   
/*     */   public void setCustomerType(String customerType) {
/*  67 */     this.customerType = customerType;
/*     */   }
/*     */   
/*     */   public void setGenfield(String[] genfield) {
/*  71 */     this.genfield = genfield;
/*     */   }
/*     */   
/*     */   public void setPlanCode(String planCode) {
/*  75 */     this.planCode = planCode;
/*     */   }
/*     */   
/*     */   public void setServiceCode(String serviceCode) {
/*  79 */     this.serviceCode = serviceCode;
/*     */   }
/*     */   
/*     */   public void setTransactionType(String transactionType) {
/*  83 */     this.transactionType = transactionType;
/*     */   }
/*     */   
/*     */   public void setUserSsnId(String userSsnId) {
/*  87 */     this.userSsnId = userSsnId;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  91 */     switch (memberIndex) {
/*     */       case 0:
/*  93 */         return 6;
/*     */       case 1:
/*  95 */         return 6;
/*     */       case 2:
/*  97 */         return 6;
/*     */       case 3:
/*  99 */         return 6;
/*     */       case 4:
/* 101 */         return 6;
/*     */       case 5:
/* 103 */         return 6;
/*     */       case 6:
/* 105 */         return 6;
/*     */       case 7:
/* 107 */         return 6;
/*     */       case 8:
/* 109 */         return 6;
/*     */       case 9:
/* 111 */         return 6;
/*     */       case 10:
/* 113 */         return 6;
/*     */       case 11:
/* 115 */         return 6;
/*     */     } 
/* 117 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 126 */       switch (index) {
/*     */         case 0:
/* 128 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/* 131 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/* 134 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 137 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 140 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 143 */           this._instance.setAplicationType((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 146 */           this._instance.setCustomerType((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 149 */           this._instance.setGenfield((String[])memberValue);
/*     */           return;
/*     */         case 8:
/* 152 */           this._instance.setPlanCode((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 155 */           this._instance.setServiceCode((String)memberValue);
/*     */           return;
/*     */         case 10:
/* 158 */           this._instance.setTransactionType((String)memberValue);
/*     */           return;
/*     */         case 11:
/* 161 */           this._instance.setUserSsnId((String)memberValue);
/*     */           return;
/*     */       } 
/* 164 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 167 */     catch (RuntimeException e) {
/* 168 */       throw e;
/*     */     }
/* 170 */     catch (Exception e) {
/* 171 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 179 */     this._instance = (ValidateAuthorisedProfileRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 183 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\ValidateAuthorisedProfileRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */