/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateAffiliationServiceRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String[] alcsList;
/*    */   protected String cosName;
/*    */   protected String phoneTypeId;
/*    */   protected String serviceCode;
/*    */   protected String status;
/*    */   protected long subscriberId;
/*    */   protected String userId;
/*    */   
/*    */   public String[] getAlcsList() {
/* 23 */     return this.alcsList;
/*    */   }
/*    */   
/*    */   public void setAlcsList(String[] alcsList) {
/* 27 */     this.alcsList = alcsList;
/*    */   }
/*    */   
/*    */   public String getCosName() {
/* 31 */     return this.cosName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 35 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public String getPhoneTypeId() {
/* 39 */     return this.phoneTypeId;
/*    */   }
/*    */   
/*    */   public void setPhoneTypeId(String phoneTypeId) {
/* 43 */     this.phoneTypeId = phoneTypeId;
/*    */   }
/*    */   
/*    */   public String getServiceCode() {
/* 47 */     return this.serviceCode;
/*    */   }
/*    */   
/*    */   public void setServiceCode(String serviceCode) {
/* 51 */     this.serviceCode = serviceCode;
/*    */   }
/*    */   
/*    */   public String getStatus() {
/* 55 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(String status) {
/* 59 */     this.status = status;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 63 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 67 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getUserId() {
/* 71 */     return this.userId;
/*    */   }
/*    */   
/*    */   public void setUserId(String userId) {
/* 75 */     this.userId = userId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateAffiliationServiceRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */