/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses.wsprepaybasebrplanoffer;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*    */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*    */ import oracle.j2ee.ws.common.encoding.ReferenceableSerializerImpl;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*    */ import oracle.j2ee.ws.common.encoding.SerializerCallback;
/*    */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*    */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*    */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*    */ 
/*    */ public class ResponseTO_InterfaceSOAPSerializer extends InterfaceSerializerBase implements Initializable {
/*    */   static Class class$(String paramString) { 
/* 17 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/* 18 */      } private static final QName ns1_AlcoCosResponseTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "AlcoCosResponseTO");
/*    */   private CombinedSerializer myns1_AlcoCosResponseTO__AlcoCosResponseTO_SOAPSerializer;
/* 20 */   private static final QName ns1_MasterDataResponseTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MasterDataResponseTO");
/*    */   private CombinedSerializer myns1_MasterDataResponseTO__MasterDataResponseTO_SOAPSerializer;
/* 22 */   private static final QName ns1_MasterDataResponseTO_v2_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MasterDataResponseTO_v2"); private CombinedSerializer myns1_MasterDataResponseTO_v2__MasterDataResponseTO_v2_SOAPSerializer; private CombinedSerializer myns1_ResponseTO__ResponseTO_SOAPSerializer; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO;
/*    */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO;
/*    */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2;
/*    */   
/*    */   public ResponseTO_InterfaceSOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/* 27 */     super(type, encodeType, isNullable, soapVersion);
/*    */   }
/*    */   public ResponseTO_InterfaceSOAPSerializer(QName type, boolean encodeType) {
/* 30 */     super(type, encodeType, true, null);
/*    */   }
/*    */   
/*    */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 34 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO == null); ((ResponseTO_InterfaceSOAPSerializer)registry).myns1_AlcoCosResponseTO__AlcoCosResponseTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO"), ns1_AlcoCosResponseTO_TYPE_QNAME);
/* 35 */     this.myns1_AlcoCosResponseTO__AlcoCosResponseTO_SOAPSerializer = this.myns1_AlcoCosResponseTO__AlcoCosResponseTO_SOAPSerializer.getInnermostSerializer();
/* 36 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO == null); ((ResponseTO_InterfaceSOAPSerializer)registry).myns1_MasterDataResponseTO__MasterDataResponseTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO"), ns1_MasterDataResponseTO_TYPE_QNAME);
/* 37 */     this.myns1_MasterDataResponseTO__MasterDataResponseTO_SOAPSerializer = this.myns1_MasterDataResponseTO__MasterDataResponseTO_SOAPSerializer.getInnermostSerializer();
/* 38 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2 == null); ((ResponseTO_InterfaceSOAPSerializer)registry).myns1_MasterDataResponseTO_v2__MasterDataResponseTO_v2_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO_v2"), ns1_MasterDataResponseTO_v2_TYPE_QNAME);
/* 39 */     this.myns1_MasterDataResponseTO_v2__MasterDataResponseTO_v2_SOAPSerializer = this.myns1_MasterDataResponseTO_v2__MasterDataResponseTO_v2_SOAPSerializer.getInnermostSerializer();
/* 40 */     QName type = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ResponseTO");
/* 41 */     ResponseTO_SOAPSerializer responseTO_SOAPSerializer = new ResponseTO_SOAPSerializer(type, true, true, SOAPVersion.SOAP_11);
/*    */     
/* 43 */     ReferenceableSerializerImpl referenceableSerializerImpl = new ReferenceableSerializerImpl(false, (CombinedSerializer)responseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 44 */     this.myns1_ResponseTO__ResponseTO_SOAPSerializer = referenceableSerializerImpl.getInnermostSerializer();
/* 45 */     if (this.myns1_ResponseTO__ResponseTO_SOAPSerializer instanceof Initializable) {
/* 46 */       ((Initializable)this.myns1_ResponseTO__ResponseTO_SOAPSerializer).initialize(registry);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Object doDeserialize(QName name, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/* 52 */     QName elementType = getType(reader);
/* 53 */     if (elementType != null && elementType.equals(this.myns1_AlcoCosResponseTO__AlcoCosResponseTO_SOAPSerializer.getXmlType()))
/* 54 */       return this.myns1_AlcoCosResponseTO__AlcoCosResponseTO_SOAPSerializer.deserialize(name, reader, context); 
/* 55 */     if (elementType != null && elementType.equals(this.myns1_MasterDataResponseTO__MasterDataResponseTO_SOAPSerializer.getXmlType()))
/* 56 */       return this.myns1_MasterDataResponseTO__MasterDataResponseTO_SOAPSerializer.deserialize(name, reader, context); 
/* 57 */     if (elementType != null && elementType.equals(this.myns1_MasterDataResponseTO_v2__MasterDataResponseTO_v2_SOAPSerializer.getXmlType()))
/* 58 */       return this.myns1_MasterDataResponseTO_v2__MasterDataResponseTO_v2_SOAPSerializer.deserialize(name, reader, context); 
/* 59 */     if (elementType == null || elementType.equals(this.myns1_ResponseTO__ResponseTO_SOAPSerializer.getXmlType())) {
/* 60 */       Object obj = this.myns1_ResponseTO__ResponseTO_SOAPSerializer.deserialize(name, reader, context);
/* 61 */       return obj;
/*    */     } 
/* 63 */     throw new DeserializationException("soap.unexpectedElementType", new Object[] { "", elementType.toString() }, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public void doSerializeInstance(Object obj, QName name, SerializerCallback callback, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 68 */     ResponseTO instance = (ResponseTO)obj;
/*    */     
/* 70 */     if (obj instanceof ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO) {
/* 71 */       this.myns1_AlcoCosResponseTO__AlcoCosResponseTO_SOAPSerializer.serialize(obj, name, callback, writer, context);
/* 72 */     } else if (obj instanceof ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO) {
/* 73 */       this.myns1_MasterDataResponseTO__MasterDataResponseTO_SOAPSerializer.serialize(obj, name, callback, writer, context);
/* 74 */     } else if (obj instanceof ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO_v2) {
/* 75 */       this.myns1_MasterDataResponseTO_v2__MasterDataResponseTO_v2_SOAPSerializer.serialize(obj, name, callback, writer, context);
/*    */     } else {
/* 77 */       this.myns1_ResponseTO__ResponseTO_SOAPSerializer.serialize(obj, name, callback, writer, context);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\wsprepaybasebrplanoffer\ResponseTO_InterfaceSOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */