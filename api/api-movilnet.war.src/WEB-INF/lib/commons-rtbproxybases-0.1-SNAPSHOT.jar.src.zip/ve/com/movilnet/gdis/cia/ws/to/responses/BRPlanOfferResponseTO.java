/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BRPlanOfferResponseTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String alcoName;
/*    */   protected int applyDay;
/*    */   protected String cosName;
/*    */   protected String periodicCharge;
/*    */   protected boolean result;
/*    */   
/*    */   public String getAlcoName() {
/* 21 */     return this.alcoName;
/*    */   }
/*    */   
/*    */   public void setAlcoName(String alcoName) {
/* 25 */     this.alcoName = alcoName;
/*    */   }
/*    */   
/*    */   public int getApplyDay() {
/* 29 */     return this.applyDay;
/*    */   }
/*    */   
/*    */   public void setApplyDay(int applyDay) {
/* 33 */     this.applyDay = applyDay;
/*    */   }
/*    */   
/*    */   public String getCosName() {
/* 37 */     return this.cosName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 41 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public String getPeriodicCharge() {
/* 45 */     return this.periodicCharge;
/*    */   }
/*    */   
/*    */   public void setPeriodicCharge(String periodicCharge) {
/* 49 */     this.periodicCharge = periodicCharge;
/*    */   }
/*    */   
/*    */   public boolean isResult() {
/* 53 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(boolean result) {
/* 57 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\BRPlanOfferResponseTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */