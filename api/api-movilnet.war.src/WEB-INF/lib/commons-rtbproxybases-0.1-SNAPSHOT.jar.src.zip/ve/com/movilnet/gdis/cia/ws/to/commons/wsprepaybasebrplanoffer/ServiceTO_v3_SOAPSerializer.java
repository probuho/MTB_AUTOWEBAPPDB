/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.ServiceTO_v3_SOAPBuilder;
/*     */ 
/*     */ public class ServiceTO_v3_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_alcoServicio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcoServicio");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_codServicio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "codServicio");
/*  23 */   private static final QName ns2_descServicio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "descServicio");
/*  24 */   private static final QName ns2_genericFields_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "genericFields");
/*  25 */   private static final QName ns2_ArrayOfstring_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/*     */   private CombinedSerializer myns2_ArrayOfstring__String_Array_LiteralSerializer1;
/*  27 */   private static final QName ns2_group_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "group");
/*  28 */   private static final QName ns2_maxCcNumber_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "maxCcNumber");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_minCcNumber_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "minCcNumber");
/*  32 */   private static final QName ns2_ovsaCommand_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ovsaCommand");
/*  33 */   private static final QName ns2_ovsaLabel_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ovsaLabel");
/*  34 */   private static final QName ns2_periodicChargeInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "periodicChargeInd");
/*  35 */   private static final QName ns2_periodicChargeName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "periodicChargeName");
/*  36 */   private static final QName ns2_precio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "precio");
/*  37 */   private static final QName ns3_double_TYPE_QNAME = SchemaConstants.QNAME_TYPE_DOUBLE;
/*     */   private CombinedSerializer myns3__double__double_Double_Serializer;
/*  39 */   private static final QName ns2_provisioningInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "provisioningInd");
/*  40 */   private static final QName ns2_subGroup_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subGroup");
/*  41 */   private static final QName ns2_subType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subType");
/*  42 */   private static final QName ns2_type_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "type"); private static final int myalcoServicio_INDEX = 0; private static final int mycodServicio_INDEX = 1;
/*     */   private static final int mydescServicio_INDEX = 2;
/*     */   private static final int mygenericFields_INDEX = 3;
/*     */   private static final int mygroup_INDEX = 4;
/*     */   private static final int mymaxCcNumber_INDEX = 5;
/*     */   private static final int myminCcNumber_INDEX = 6;
/*     */   private static final int myovsaCommand_INDEX = 7;
/*     */   private static final int myovsaLabel_INDEX = 8;
/*     */   private static final int myperiodicChargeInd_INDEX = 9;
/*     */   private static final int myperiodicChargeName_INDEX = 10;
/*     */   private static final int myprecio_INDEX = 11;
/*     */   private static final int myprovisioningInd_INDEX = 12;
/*     */   private static final int mysubGroup_INDEX = 13;
/*     */   private static final int mysubType_INDEX = 14;
/*     */   private static final int mytype_INDEX = 15;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   
/*     */   public ServiceTO_v3_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  61 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  65 */     if (class$java$lang$String == null); ((ServiceTO_v3_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  66 */     if (array$Ljava$lang$String == null); ((ServiceTO_v3_SOAPSerializer)registry).myns2_ArrayOfstring__String_Array_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), ns2_ArrayOfstring_TYPE_QNAME);
/*  67 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  68 */     this.myns3__double__double_Double_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), double.class, ns3_double_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  73 */     ServiceTO_v3 instance = new ServiceTO_v3();
/*  74 */     ServiceTO_v3_SOAPBuilder builder = null;
/*     */     
/*  76 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  79 */     reader.nextElementContent();
/*  80 */     QName startName = reader.getName();
/*  81 */     for (int i = 0; i < 16; i++) {
/*  82 */       QName elementName = reader.getName();
/*  83 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  86 */       if (matchQName(elementName, ns2_alcoServicio_QNAME)) {
/*  87 */         context.setNillable(true);
/*  88 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_alcoServicio_QNAME, reader, context);
/*  89 */         if (member instanceof SOAPDeserializationState) {
/*  90 */           if (builder == null) {
/*  91 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/*  93 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  94 */           isComplete = false;
/*  95 */         } else if (member != null) {
/*  96 */           instance.setAlcoServicio((String)member);
/*     */         } 
/*  98 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 101 */       else if (matchQName(elementName, ns2_codServicio_QNAME)) {
/* 102 */         context.setNillable(true);
/* 103 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_codServicio_QNAME, reader, context);
/* 104 */         if (object instanceof SOAPDeserializationState) {
/* 105 */           if (builder == null) {
/* 106 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 108 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 109 */           isComplete = false;
/* 110 */         } else if (object != null) {
/* 111 */           instance.setCodServicio((String)object);
/*     */         } 
/* 113 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 116 */       else if (matchQName(elementName, ns2_descServicio_QNAME)) {
/* 117 */         context.setNillable(true);
/* 118 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_descServicio_QNAME, reader, context);
/* 119 */         if (object instanceof SOAPDeserializationState) {
/* 120 */           if (builder == null) {
/* 121 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 123 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 124 */           isComplete = false;
/* 125 */         } else if (object != null) {
/* 126 */           instance.setDescServicio((String)object);
/*     */         } 
/* 128 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 131 */       else if (matchQName(elementName, ns2_genericFields_QNAME)) {
/* 132 */         context.setNillable(true);
/* 133 */         Object object = this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.deserialize(ns2_genericFields_QNAME, reader, context);
/* 134 */         if (object instanceof SOAPDeserializationState) {
/* 135 */           if (builder == null) {
/* 136 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 138 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 139 */           isComplete = false;
/* 140 */         } else if (object != null) {
/* 141 */           instance.setGenericFields((String[])object);
/*     */         } 
/* 143 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 146 */       else if (matchQName(elementName, ns2_group_QNAME)) {
/* 147 */         context.setNillable(true);
/* 148 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_group_QNAME, reader, context);
/* 149 */         if (object instanceof SOAPDeserializationState) {
/* 150 */           if (builder == null) {
/* 151 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 153 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 154 */           isComplete = false;
/* 155 */         } else if (object != null) {
/* 156 */           instance.setGroup((String)object);
/*     */         } 
/* 158 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 161 */       else if (matchQName(elementName, ns2_maxCcNumber_QNAME)) {
/* 162 */         context.setNillable(true);
/* 163 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_maxCcNumber_QNAME, reader, context);
/* 164 */         if (object instanceof SOAPDeserializationState) {
/* 165 */           if (builder == null) {
/* 166 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 168 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 169 */           isComplete = false;
/* 170 */         } else if (object != null) {
/* 171 */           instance.setMaxCcNumber(((Short)object).shortValue());
/*     */         } 
/* 173 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 176 */       else if (matchQName(elementName, ns2_minCcNumber_QNAME)) {
/* 177 */         context.setNillable(true);
/* 178 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_minCcNumber_QNAME, reader, context);
/* 179 */         if (object instanceof SOAPDeserializationState) {
/* 180 */           if (builder == null) {
/* 181 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 183 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 184 */           isComplete = false;
/* 185 */         } else if (object != null) {
/* 186 */           instance.setMinCcNumber(((Short)object).shortValue());
/*     */         } 
/* 188 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 191 */       else if (matchQName(elementName, ns2_ovsaCommand_QNAME)) {
/* 192 */         context.setNillable(true);
/* 193 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_ovsaCommand_QNAME, reader, context);
/* 194 */         if (object instanceof SOAPDeserializationState) {
/* 195 */           if (builder == null) {
/* 196 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 198 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 199 */           isComplete = false;
/* 200 */         } else if (object != null) {
/* 201 */           instance.setOvsaCommand((String)object);
/*     */         } 
/* 203 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 206 */       else if (matchQName(elementName, ns2_ovsaLabel_QNAME)) {
/* 207 */         context.setNillable(true);
/* 208 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_ovsaLabel_QNAME, reader, context);
/* 209 */         if (object instanceof SOAPDeserializationState) {
/* 210 */           if (builder == null) {
/* 211 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 213 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 214 */           isComplete = false;
/* 215 */         } else if (object != null) {
/* 216 */           instance.setOvsaLabel((String)object);
/*     */         } 
/* 218 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 221 */       else if (matchQName(elementName, ns2_periodicChargeInd_QNAME)) {
/* 222 */         context.setNillable(true);
/* 223 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_periodicChargeInd_QNAME, reader, context);
/* 224 */         if (object instanceof SOAPDeserializationState) {
/* 225 */           if (builder == null) {
/* 226 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 228 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 229 */           isComplete = false;
/* 230 */         } else if (object != null) {
/* 231 */           instance.setPeriodicChargeInd((String)object);
/*     */         } 
/* 233 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 236 */       else if (matchQName(elementName, ns2_periodicChargeName_QNAME)) {
/* 237 */         context.setNillable(true);
/* 238 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_periodicChargeName_QNAME, reader, context);
/* 239 */         if (object instanceof SOAPDeserializationState) {
/* 240 */           if (builder == null) {
/* 241 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 243 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 244 */           isComplete = false;
/* 245 */         } else if (object != null) {
/* 246 */           instance.setPeriodicChargeName((String)object);
/*     */         } 
/* 248 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 251 */       else if (matchQName(elementName, ns2_precio_QNAME)) {
/* 252 */         context.setNillable(true);
/* 253 */         Object object = this.myns3__double__double_Double_Serializer.deserialize(ns2_precio_QNAME, reader, context);
/* 254 */         if (object instanceof SOAPDeserializationState) {
/* 255 */           if (builder == null) {
/* 256 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 258 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 259 */           isComplete = false;
/* 260 */         } else if (object != null) {
/* 261 */           instance.setPrecio(((Double)object).doubleValue());
/*     */         } 
/* 263 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 266 */       else if (matchQName(elementName, ns2_provisioningInd_QNAME)) {
/* 267 */         context.setNillable(true);
/* 268 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_provisioningInd_QNAME, reader, context);
/* 269 */         if (object instanceof SOAPDeserializationState) {
/* 270 */           if (builder == null) {
/* 271 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 273 */           state = registerWithMemberState(instance, state, object, 12, (SOAPInstanceBuilder)builder);
/* 274 */           isComplete = false;
/* 275 */         } else if (object != null) {
/* 276 */           instance.setProvisioningInd((String)object);
/*     */         } 
/* 278 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 281 */       else if (matchQName(elementName, ns2_subGroup_QNAME)) {
/* 282 */         context.setNillable(true);
/* 283 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_subGroup_QNAME, reader, context);
/* 284 */         if (object instanceof SOAPDeserializationState) {
/* 285 */           if (builder == null) {
/* 286 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 288 */           state = registerWithMemberState(instance, state, object, 13, (SOAPInstanceBuilder)builder);
/* 289 */           isComplete = false;
/* 290 */         } else if (object != null) {
/* 291 */           instance.setSubGroup((String)object);
/*     */         } 
/* 293 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 296 */       else if (matchQName(elementName, ns2_subType_QNAME)) {
/* 297 */         context.setNillable(true);
/* 298 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_subType_QNAME, reader, context);
/* 299 */         if (object instanceof SOAPDeserializationState) {
/* 300 */           if (builder == null) {
/* 301 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 303 */           state = registerWithMemberState(instance, state, object, 14, (SOAPInstanceBuilder)builder);
/* 304 */           isComplete = false;
/* 305 */         } else if (object != null) {
/* 306 */           instance.setSubType((String)object);
/*     */         } 
/* 308 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 311 */       else if (matchQName(elementName, ns2_type_QNAME)) {
/* 312 */         context.setNillable(true);
/* 313 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_type_QNAME, reader, context);
/* 314 */         if (object instanceof SOAPDeserializationState) {
/* 315 */           if (builder == null) {
/* 316 */             builder = new ServiceTO_v3_SOAPBuilder();
/*     */           }
/* 318 */           state = registerWithMemberState(instance, state, object, 15, (SOAPInstanceBuilder)builder);
/* 319 */           isComplete = false;
/* 320 */         } else if (object != null) {
/* 321 */           instance.setType((String)object);
/*     */         } 
/* 323 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 326 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_type_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 331 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 332 */     } catch (XMLReaderException xmle) {
/* 333 */       if (startName != null) {
/* 334 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 336 */       throw xmle;
/*     */     } 
/*     */     
/* 339 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 343 */     ServiceTO_v3 instance = (ServiceTO_v3)obj;
/*     */     
/* 345 */     context.setNillable(true);
/* 346 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAlcoServicio(), ns2_alcoServicio_QNAME, null, writer, context);
/* 347 */     context.setNillable(true);
/* 348 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCodServicio(), ns2_codServicio_QNAME, null, writer, context);
/* 349 */     context.setNillable(true);
/* 350 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getDescServicio(), ns2_descServicio_QNAME, null, writer, context);
/* 351 */     context.setNillable(true);
/* 352 */     this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.serialize(instance.getGenericFields(), ns2_genericFields_QNAME, null, writer, context);
/* 353 */     context.setNillable(true);
/* 354 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getGroup(), ns2_group_QNAME, null, writer, context);
/* 355 */     context.setNillable(true);
/* 356 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getMaxCcNumber()), ns2_maxCcNumber_QNAME, null, writer, context);
/* 357 */     context.setNillable(true);
/* 358 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getMinCcNumber()), ns2_minCcNumber_QNAME, null, writer, context);
/* 359 */     context.setNillable(true);
/* 360 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOvsaCommand(), ns2_ovsaCommand_QNAME, null, writer, context);
/* 361 */     context.setNillable(true);
/* 362 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOvsaLabel(), ns2_ovsaLabel_QNAME, null, writer, context);
/* 363 */     context.setNillable(true);
/* 364 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPeriodicChargeInd(), ns2_periodicChargeInd_QNAME, null, writer, context);
/* 365 */     context.setNillable(true);
/* 366 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPeriodicChargeName(), ns2_periodicChargeName_QNAME, null, writer, context);
/* 367 */     context.setNillable(true);
/* 368 */     this.myns3__double__double_Double_Serializer.serialize(new Double(instance.getPrecio()), ns2_precio_QNAME, null, writer, context);
/* 369 */     context.setNillable(true);
/* 370 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getProvisioningInd(), ns2_provisioningInd_QNAME, null, writer, context);
/* 371 */     context.setNillable(true);
/* 372 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getSubGroup(), ns2_subGroup_QNAME, null, writer, context);
/* 373 */     context.setNillable(true);
/* 374 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getSubType(), ns2_subType_QNAME, null, writer, context);
/* 375 */     context.setNillable(true);
/* 376 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getType(), ns2_type_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\ServiceTO_v3_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */