/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubCategoryTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private SubCategoryTO _instance;
/*    */   private String codCateg;
/*    */   private String descCateg;
/*    */   private static final int mycodCateg_INDEX = 0;
/*    */   private static final int mydescCateg_INDEX = 1;
/*    */   
/*    */   public void setCodCateg(String codCateg) {
/* 23 */     this.codCateg = codCateg;
/*    */   }
/*    */   
/*    */   public void setDescCateg(String descCateg) {
/* 27 */     this.descCateg = descCateg;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 31 */     switch (memberIndex) {
/*    */       case 0:
/* 33 */         return 6;
/*    */       case 1:
/* 35 */         return 6;
/*    */     } 
/* 37 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 46 */       switch (index) {
/*    */         case 0:
/* 48 */           this._instance.setCodCateg((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 51 */           this._instance.setDescCateg((String)memberValue);
/*    */           return;
/*    */       } 
/* 54 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 57 */     catch (RuntimeException e) {
/* 58 */       throw e;
/*    */     }
/* 60 */     catch (Exception e) {
/* 61 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 69 */     this._instance = (SubCategoryTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 73 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\SubCategoryTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */