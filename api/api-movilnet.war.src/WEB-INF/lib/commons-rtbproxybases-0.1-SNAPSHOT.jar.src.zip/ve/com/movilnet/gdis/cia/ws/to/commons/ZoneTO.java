/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZoneTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String distributionCode;
/*    */   protected int urbId;
/*    */   protected String zipCode;
/*    */   
/*    */   public String getDistributionCode() {
/* 19 */     return this.distributionCode;
/*    */   }
/*    */   
/*    */   public void setDistributionCode(String distributionCode) {
/* 23 */     this.distributionCode = distributionCode;
/*    */   }
/*    */   
/*    */   public int getUrbId() {
/* 27 */     return this.urbId;
/*    */   }
/*    */   
/*    */   public void setUrbId(int urbId) {
/* 31 */     this.urbId = urbId;
/*    */   }
/*    */   
/*    */   public String getZipCode() {
/* 35 */     return this.zipCode;
/*    */   }
/*    */   
/*    */   public void setZipCode(String zipCode) {
/* 39 */     this.zipCode = zipCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ZoneTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */