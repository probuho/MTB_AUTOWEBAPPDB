/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MasterDataRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private MasterDataRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String accountType;
/*     */   private String categoryCode;
/*     */   private String cosName;
/*     */   private String iniCode;
/*     */   private String razonType;
/*     */   private String screenType;
/*     */   private long subscriberId;
/*     */   private String transactionType;
/*     */   private String userId;
/*     */   private int value;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myaccountType_INDEX = 5;
/*     */   private static final int mycategoryCode_INDEX = 6;
/*     */   private static final int mycosName_INDEX = 7;
/*     */   private static final int myiniCode_INDEX = 8;
/*     */   private static final int myrazonType_INDEX = 9;
/*     */   private static final int myscreenType_INDEX = 10;
/*     */   private static final int mysubscriberId_INDEX = 11;
/*     */   private static final int mytransactionType_INDEX = 12;
/*     */   private static final int myuserId_INDEX = 13;
/*     */   private static final int myvalue_INDEX = 14;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  49 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  53 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  57 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  61 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  65 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAccountType(String accountType) {
/*  69 */     this.accountType = accountType;
/*     */   }
/*     */   
/*     */   public void setCategoryCode(String categoryCode) {
/*  73 */     this.categoryCode = categoryCode;
/*     */   }
/*     */   
/*     */   public void setCosName(String cosName) {
/*  77 */     this.cosName = cosName;
/*     */   }
/*     */   
/*     */   public void setIniCode(String iniCode) {
/*  81 */     this.iniCode = iniCode;
/*     */   }
/*     */   
/*     */   public void setRazonType(String razonType) {
/*  85 */     this.razonType = razonType;
/*     */   }
/*     */   
/*     */   public void setScreenType(String screenType) {
/*  89 */     this.screenType = screenType;
/*     */   }
/*     */   
/*     */   public void setSubscriberId(long subscriberId) {
/*  93 */     this.subscriberId = subscriberId;
/*     */   }
/*     */   
/*     */   public void setTransactionType(String transactionType) {
/*  97 */     this.transactionType = transactionType;
/*     */   }
/*     */   
/*     */   public void setUserId(String userId) {
/* 101 */     this.userId = userId;
/*     */   }
/*     */   
/*     */   public void setValue(int value) {
/* 105 */     this.value = value;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/* 109 */     switch (memberIndex) {
/*     */       case 0:
/* 111 */         return 6;
/*     */       case 1:
/* 113 */         return 6;
/*     */       case 2:
/* 115 */         return 6;
/*     */       case 3:
/* 117 */         return 6;
/*     */       case 4:
/* 119 */         return 6;
/*     */       case 5:
/* 121 */         return 6;
/*     */       case 6:
/* 123 */         return 6;
/*     */       case 7:
/* 125 */         return 6;
/*     */       case 8:
/* 127 */         return 6;
/*     */       case 9:
/* 129 */         return 6;
/*     */       case 10:
/* 131 */         return 6;
/*     */       case 11:
/* 133 */         return 6;
/*     */       case 12:
/* 135 */         return 6;
/*     */       case 13:
/* 137 */         return 6;
/*     */       case 14:
/* 139 */         return 6;
/*     */     } 
/* 141 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 150 */       switch (index) {
/*     */         case 0:
/* 152 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/* 155 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/* 158 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 161 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 164 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 167 */           this._instance.setAccountType((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 170 */           this._instance.setCategoryCode((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 173 */           this._instance.setCosName((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 176 */           this._instance.setIniCode((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 179 */           this._instance.setRazonType((String)memberValue);
/*     */           return;
/*     */         case 10:
/* 182 */           this._instance.setScreenType((String)memberValue);
/*     */           return;
/*     */         case 11:
/* 185 */           this._instance.setSubscriberId(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 12:
/* 188 */           this._instance.setTransactionType((String)memberValue);
/*     */           return;
/*     */         case 13:
/* 191 */           this._instance.setUserId((String)memberValue);
/*     */           return;
/*     */         case 14:
/* 194 */           this._instance.setValue(((Integer)memberValue).intValue());
/*     */           return;
/*     */       } 
/* 197 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 200 */     catch (RuntimeException e) {
/* 201 */       throw e;
/*     */     }
/* 203 */     catch (Exception e) {
/* 204 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 212 */     this._instance = (MasterDataRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 216 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\MasterDataRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */