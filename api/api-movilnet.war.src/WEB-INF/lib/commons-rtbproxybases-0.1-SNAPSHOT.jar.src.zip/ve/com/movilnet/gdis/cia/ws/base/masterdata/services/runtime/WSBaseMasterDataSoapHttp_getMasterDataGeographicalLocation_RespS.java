/*    */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS
/*    */   implements Serializable
/*    */ {
/*    */   protected MasterDataResponseTO result;
/*    */   
/*    */   public MasterDataResponseTO getResult() {
/* 17 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(MasterDataResponseTO result) {
/* 21 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\runtime\WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */