/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import oracle.j2ee.ws.common.wsdl.document.schema.SchemaConstants;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.runtime.BRPlanOfferResponseTO_SOAPBuilder;
/*     */ 
/*     */ public class BRPlanOfferResponseTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_executionTime_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "executionTime");
/*  20 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  22 */   private static final QName ns2_origin_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "origin");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  25 */   private static final QName ns2_responseCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseCode");
/*  26 */   private static final QName ns2_responseDescription_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseDescription");
/*  27 */   private static final QName ns2_responseMessage_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseMessage");
/*  28 */   private static final QName ns2_responseSubCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseSubCode");
/*  29 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  30 */   private static final QName ns2_alcoName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcoName");
/*  31 */   private static final QName ns2_applyDay_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applyDay");
/*  32 */   private static final QName ns3_int_TYPE_QNAME = SchemaConstants.QNAME_TYPE_INT;
/*     */   private CombinedSerializer myns3__int__int_Int_Serializer;
/*  34 */   private static final QName ns2_cosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cosName");
/*  35 */   private static final QName ns2_periodicCharge_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "periodicCharge");
/*  36 */   private static final QName ns2_result_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "result");
/*  37 */   private static final QName ns3_boolean_TYPE_QNAME = SchemaConstants.QNAME_TYPE_BOOLEAN; private CombinedSerializer myns3__boolean__boolean_Boolean_Serializer;
/*     */   private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static final int myalcoName_INDEX = 7;
/*     */   private static final int myapplyDay_INDEX = 8;
/*     */   private static final int mycosName_INDEX = 9;
/*     */   private static final int myperiodicCharge_INDEX = 10;
/*     */   private static final int myresult_INDEX = 11;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public BRPlanOfferResponseTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  53 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  57 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*  58 */     if (class$java$lang$String == null); ((BRPlanOfferResponseTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  59 */     this.myns3__int__int_Int_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), int.class, ns3_int_TYPE_QNAME);
/*  60 */     this.myns3__boolean__boolean_Boolean_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), boolean.class, ns3_boolean_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  65 */     BRPlanOfferResponseTO instance = new BRPlanOfferResponseTO();
/*  66 */     BRPlanOfferResponseTO_SOAPBuilder builder = null;
/*     */     
/*  68 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  71 */     reader.nextElementContent();
/*  72 */     QName startName = reader.getName();
/*  73 */     for (int i = 0; i < 12; i++) {
/*  74 */       QName elementName = reader.getName();
/*  75 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  78 */       if (matchQName(elementName, ns2_executionTime_QNAME)) {
/*  79 */         context.setNillable(true);
/*  80 */         Object member = this.myns3__long__long_Long_Serializer.deserialize(ns2_executionTime_QNAME, reader, context);
/*  81 */         if (member instanceof SOAPDeserializationState) {
/*  82 */           if (builder == null) {
/*  83 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/*  85 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  86 */           isComplete = false;
/*  87 */         } else if (member != null) {
/*  88 */           instance.setExecutionTime(((Long)member).longValue());
/*     */         } 
/*  90 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  93 */       else if (matchQName(elementName, ns2_origin_QNAME)) {
/*  94 */         context.setNillable(true);
/*  95 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_origin_QNAME, reader, context);
/*  96 */         if (object instanceof SOAPDeserializationState) {
/*  97 */           if (builder == null) {
/*  98 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 100 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 101 */           isComplete = false;
/* 102 */         } else if (object != null) {
/* 103 */           instance.setOrigin((String)object);
/*     */         } 
/* 105 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 108 */       else if (matchQName(elementName, ns2_responseCode_QNAME)) {
/* 109 */         context.setNillable(true);
/* 110 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseCode_QNAME, reader, context);
/* 111 */         if (object instanceof SOAPDeserializationState) {
/* 112 */           if (builder == null) {
/* 113 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 115 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 116 */           isComplete = false;
/* 117 */         } else if (object != null) {
/* 118 */           instance.setResponseCode((String)object);
/*     */         } 
/* 120 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 123 */       else if (matchQName(elementName, ns2_responseDescription_QNAME)) {
/* 124 */         context.setNillable(true);
/* 125 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseDescription_QNAME, reader, context);
/* 126 */         if (object instanceof SOAPDeserializationState) {
/* 127 */           if (builder == null) {
/* 128 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 130 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 131 */           isComplete = false;
/* 132 */         } else if (object != null) {
/* 133 */           instance.setResponseDescription((String)object);
/*     */         } 
/* 135 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 138 */       else if (matchQName(elementName, ns2_responseMessage_QNAME)) {
/* 139 */         context.setNillable(true);
/* 140 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseMessage_QNAME, reader, context);
/* 141 */         if (object instanceof SOAPDeserializationState) {
/* 142 */           if (builder == null) {
/* 143 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 145 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 146 */           isComplete = false;
/* 147 */         } else if (object != null) {
/* 148 */           instance.setResponseMessage((String)object);
/*     */         } 
/* 150 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 153 */       else if (matchQName(elementName, ns2_responseSubCode_QNAME)) {
/* 154 */         context.setNillable(true);
/* 155 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseSubCode_QNAME, reader, context);
/* 156 */         if (object instanceof SOAPDeserializationState) {
/* 157 */           if (builder == null) {
/* 158 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 160 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 161 */           isComplete = false;
/* 162 */         } else if (object != null) {
/* 163 */           instance.setResponseSubCode((String)object);
/*     */         } 
/* 165 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 168 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 169 */         context.setNillable(true);
/* 170 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 171 */         if (object instanceof SOAPDeserializationState) {
/* 172 */           if (builder == null) {
/* 173 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 175 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 176 */           isComplete = false;
/* 177 */         } else if (object != null) {
/* 178 */           instance.setTransactionId((String)object);
/*     */         } 
/* 180 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 183 */       else if (matchQName(elementName, ns2_alcoName_QNAME)) {
/* 184 */         context.setNillable(true);
/* 185 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_alcoName_QNAME, reader, context);
/* 186 */         if (object instanceof SOAPDeserializationState) {
/* 187 */           if (builder == null) {
/* 188 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 190 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 191 */           isComplete = false;
/* 192 */         } else if (object != null) {
/* 193 */           instance.setAlcoName((String)object);
/*     */         } 
/* 195 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 198 */       else if (matchQName(elementName, ns2_applyDay_QNAME)) {
/* 199 */         context.setNillable(true);
/* 200 */         Object object = this.myns3__int__int_Int_Serializer.deserialize(ns2_applyDay_QNAME, reader, context);
/* 201 */         if (object instanceof SOAPDeserializationState) {
/* 202 */           if (builder == null) {
/* 203 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 205 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 206 */           isComplete = false;
/* 207 */         } else if (object != null) {
/* 208 */           instance.setApplyDay(((Integer)object).intValue());
/*     */         } 
/* 210 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 213 */       else if (matchQName(elementName, ns2_cosName_QNAME)) {
/* 214 */         context.setNillable(true);
/* 215 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cosName_QNAME, reader, context);
/* 216 */         if (object instanceof SOAPDeserializationState) {
/* 217 */           if (builder == null) {
/* 218 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 220 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 221 */           isComplete = false;
/* 222 */         } else if (object != null) {
/* 223 */           instance.setCosName((String)object);
/*     */         } 
/* 225 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 228 */       else if (matchQName(elementName, ns2_periodicCharge_QNAME)) {
/* 229 */         context.setNillable(true);
/* 230 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_periodicCharge_QNAME, reader, context);
/* 231 */         if (object instanceof SOAPDeserializationState) {
/* 232 */           if (builder == null) {
/* 233 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 235 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 236 */           isComplete = false;
/* 237 */         } else if (object != null) {
/* 238 */           instance.setPeriodicCharge((String)object);
/*     */         } 
/* 240 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 243 */       else if (matchQName(elementName, ns2_result_QNAME)) {
/* 244 */         context.setNillable(true);
/* 245 */         Object object = this.myns3__boolean__boolean_Boolean_Serializer.deserialize(ns2_result_QNAME, reader, context);
/* 246 */         if (object instanceof SOAPDeserializationState) {
/* 247 */           if (builder == null) {
/* 248 */             builder = new BRPlanOfferResponseTO_SOAPBuilder();
/*     */           }
/* 250 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 251 */           isComplete = false;
/* 252 */         } else if (object != null) {
/* 253 */           instance.setResult(((Boolean)object).booleanValue());
/*     */         } 
/* 255 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 258 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_result_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 263 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 264 */     } catch (XMLReaderException xmle) {
/* 265 */       if (startName != null) {
/* 266 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 268 */       throw xmle;
/*     */     } 
/*     */     
/* 271 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 275 */     BRPlanOfferResponseTO instance = (BRPlanOfferResponseTO)obj;
/*     */     
/* 277 */     context.setNillable(true);
/* 278 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getExecutionTime()), ns2_executionTime_QNAME, null, writer, context);
/* 279 */     context.setNillable(true);
/* 280 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOrigin(), ns2_origin_QNAME, null, writer, context);
/* 281 */     context.setNillable(true);
/* 282 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseCode(), ns2_responseCode_QNAME, null, writer, context);
/* 283 */     context.setNillable(true);
/* 284 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseDescription(), ns2_responseDescription_QNAME, null, writer, context);
/* 285 */     context.setNillable(true);
/* 286 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseMessage(), ns2_responseMessage_QNAME, null, writer, context);
/* 287 */     context.setNillable(true);
/* 288 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseSubCode(), ns2_responseSubCode_QNAME, null, writer, context);
/* 289 */     context.setNillable(true);
/* 290 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 291 */     context.setNillable(true);
/* 292 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAlcoName(), ns2_alcoName_QNAME, null, writer, context);
/* 293 */     context.setNillable(true);
/* 294 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getApplyDay()), ns2_applyDay_QNAME, null, writer, context);
/* 295 */     context.setNillable(true);
/* 296 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCosName(), ns2_cosName_QNAME, null, writer, context);
/* 297 */     context.setNillable(true);
/* 298 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPeriodicCharge(), ns2_periodicCharge_QNAME, null, writer, context);
/* 299 */     context.setNillable(true);
/* 300 */     this.myns3__boolean__boolean_Boolean_Serializer.serialize(new Boolean(instance.isResult()), ns2_result_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\wsprepaybasebrplanoffer\BRPlanOfferResponseTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */