/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanConsejoComunalRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidatePlanConsejoComunalRequestTO planConsejoComunalRequest;
/*    */   
/*    */   public ValidatePlanConsejoComunalRequestTO getPlanConsejoComunalRequest() {
/* 17 */     return this.planConsejoComunalRequest;
/*    */   }
/*    */   
/*    */   public void setPlanConsejoComunalRequest(ValidatePlanConsejoComunalRequestTO planConsejoComunalRequest) {
/* 21 */     this.planConsejoComunalRequest = planConsejoComunalRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */