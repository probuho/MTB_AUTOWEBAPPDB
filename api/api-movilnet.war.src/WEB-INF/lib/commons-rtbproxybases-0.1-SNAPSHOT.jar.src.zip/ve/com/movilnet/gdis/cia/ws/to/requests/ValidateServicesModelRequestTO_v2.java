/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateServicesModelRequestTO_v2
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String alcoName;
/*    */   protected String itemCatId;
/*    */   protected String serial;
/*    */   protected String serviceCode;
/*    */   protected String transactionType;
/*    */   
/*    */   public String getAlcoName() {
/* 21 */     return this.alcoName;
/*    */   }
/*    */   
/*    */   public void setAlcoName(String alcoName) {
/* 25 */     this.alcoName = alcoName;
/*    */   }
/*    */   
/*    */   public String getItemCatId() {
/* 29 */     return this.itemCatId;
/*    */   }
/*    */   
/*    */   public void setItemCatId(String itemCatId) {
/* 33 */     this.itemCatId = itemCatId;
/*    */   }
/*    */   
/*    */   public String getSerial() {
/* 37 */     return this.serial;
/*    */   }
/*    */   
/*    */   public void setSerial(String serial) {
/* 41 */     this.serial = serial;
/*    */   }
/*    */   
/*    */   public String getServiceCode() {
/* 45 */     return this.serviceCode;
/*    */   }
/*    */   
/*    */   public void setServiceCode(String serviceCode) {
/* 49 */     this.serviceCode = serviceCode;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 53 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 57 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateServicesModelRequestTO_v2.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */