/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SellingAgentTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private SellingAgentTO _instance;
/*    */   private String dealerCode;
/*    */   private String dealerName;
/*    */   private String status;
/*    */   private static final int mydealerCode_INDEX = 0;
/*    */   private static final int mydealerName_INDEX = 1;
/*    */   private static final int mystatus_INDEX = 2;
/*    */   
/*    */   public void setDealerCode(String dealerCode) {
/* 25 */     this.dealerCode = dealerCode;
/*    */   }
/*    */   
/*    */   public void setDealerName(String dealerName) {
/* 29 */     this.dealerName = dealerName;
/*    */   }
/*    */   
/*    */   public void setStatus(String status) {
/* 33 */     this.status = status;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 37 */     switch (memberIndex) {
/*    */       case 0:
/* 39 */         return 6;
/*    */       case 1:
/* 41 */         return 6;
/*    */       case 2:
/* 43 */         return 6;
/*    */     } 
/* 45 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 54 */       switch (index) {
/*    */         case 0:
/* 56 */           this._instance.setDealerCode((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 59 */           this._instance.setDealerName((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 62 */           this._instance.setStatus((String)memberValue);
/*    */           return;
/*    */       } 
/* 65 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 68 */     catch (RuntimeException e) {
/* 69 */       throw e;
/*    */     }
/* 71 */     catch (Exception e) {
/* 72 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 80 */     this._instance = (SellingAgentTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 84 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\SellingAgentTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */