/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceTO
/*     */   implements Serializable
/*     */ {
/*     */   protected String alcoServicio;
/*     */   protected String codServicio;
/*     */   protected String descServicio;
/*     */   protected int maxCcNumber;
/*     */   protected int minCcNumber;
/*     */   protected String periodicChargeInd;
/*     */   protected String periodicChargeName;
/*     */   protected long precio;
/*     */   protected String provisioningInd;
/*     */   protected String tipoServicio;
/*     */   
/*     */   public String getAlcoServicio() {
/*  26 */     return this.alcoServicio;
/*     */   }
/*     */   
/*     */   public void setAlcoServicio(String alcoServicio) {
/*  30 */     this.alcoServicio = alcoServicio;
/*     */   }
/*     */   
/*     */   public String getCodServicio() {
/*  34 */     return this.codServicio;
/*     */   }
/*     */   
/*     */   public void setCodServicio(String codServicio) {
/*  38 */     this.codServicio = codServicio;
/*     */   }
/*     */   
/*     */   public String getDescServicio() {
/*  42 */     return this.descServicio;
/*     */   }
/*     */   
/*     */   public void setDescServicio(String descServicio) {
/*  46 */     this.descServicio = descServicio;
/*     */   }
/*     */   
/*     */   public int getMaxCcNumber() {
/*  50 */     return this.maxCcNumber;
/*     */   }
/*     */   
/*     */   public void setMaxCcNumber(int maxCcNumber) {
/*  54 */     this.maxCcNumber = maxCcNumber;
/*     */   }
/*     */   
/*     */   public int getMinCcNumber() {
/*  58 */     return this.minCcNumber;
/*     */   }
/*     */   
/*     */   public void setMinCcNumber(int minCcNumber) {
/*  62 */     this.minCcNumber = minCcNumber;
/*     */   }
/*     */   
/*     */   public String getPeriodicChargeInd() {
/*  66 */     return this.periodicChargeInd;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeInd(String periodicChargeInd) {
/*  70 */     this.periodicChargeInd = periodicChargeInd;
/*     */   }
/*     */   
/*     */   public String getPeriodicChargeName() {
/*  74 */     return this.periodicChargeName;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeName(String periodicChargeName) {
/*  78 */     this.periodicChargeName = periodicChargeName;
/*     */   }
/*     */   
/*     */   public long getPrecio() {
/*  82 */     return this.precio;
/*     */   }
/*     */   
/*     */   public void setPrecio(long precio) {
/*  86 */     this.precio = precio;
/*     */   }
/*     */   
/*     */   public String getProvisioningInd() {
/*  90 */     return this.provisioningInd;
/*     */   }
/*     */   
/*     */   public void setProvisioningInd(String provisioningInd) {
/*  94 */     this.provisioningInd = provisioningInd;
/*     */   }
/*     */   
/*     */   public String getTipoServicio() {
/*  98 */     return this.tipoServicio;
/*     */   }
/*     */   
/*     */   public void setTipoServicio(String tipoServicio) {
/* 102 */     this.tipoServicio = tipoServicio;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ServiceTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */