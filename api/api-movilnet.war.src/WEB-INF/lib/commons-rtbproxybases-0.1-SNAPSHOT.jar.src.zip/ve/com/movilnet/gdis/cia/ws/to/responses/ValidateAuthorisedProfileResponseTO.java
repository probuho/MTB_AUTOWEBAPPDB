/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateAuthorisedProfileResponseTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String[] genfield;
/*    */   protected boolean result;
/*    */   
/*    */   public String[] getGenfield() {
/* 18 */     return this.genfield;
/*    */   }
/*    */   
/*    */   public void setGenfield(String[] genfield) {
/* 22 */     this.genfield = genfield;
/*    */   }
/*    */   
/*    */   public boolean isResult() {
/* 26 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(boolean result) {
/* 30 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\ValidateAuthorisedProfileResponseTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */