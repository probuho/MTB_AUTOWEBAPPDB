/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdjustmentReasonsTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String razonCod;
/*    */   protected String razonDesc;
/*    */   
/*    */   public String getRazonCod() {
/* 18 */     return this.razonCod;
/*    */   }
/*    */   
/*    */   public void setRazonCod(String razonCod) {
/* 22 */     this.razonCod = razonCod;
/*    */   }
/*    */   
/*    */   public String getRazonDesc() {
/* 26 */     return this.razonDesc;
/*    */   }
/*    */   
/*    */   public void setRazonDesc(String razonDesc) {
/* 30 */     this.razonDesc = razonDesc;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\AdjustmentReasonsTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */