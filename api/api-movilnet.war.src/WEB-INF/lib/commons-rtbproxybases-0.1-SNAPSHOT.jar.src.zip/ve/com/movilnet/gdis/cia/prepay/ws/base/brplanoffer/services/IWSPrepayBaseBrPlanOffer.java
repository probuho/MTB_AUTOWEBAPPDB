package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services;

import java.rmi.Remote;
import java.rmi.RemoteException;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAffiliationServiceRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAuthorisedProfileRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangeBRPlanRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangePlanTextRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateDisConnectionServiceRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateNumberSpecialServicesRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanConsejoComunalRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO_v2;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanPromotionDealerRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO_v2;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanServicesRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO_v2;
import ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.ValidateAuthorisedProfileResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.ValidateNumberSpecialServicesResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.ValidatePlanResponseTO;

public interface IWSPrepayBaseBrPlanOffer extends Remote {
  BRPlanOfferResponseTO isChangePlan(ValidateChangeBRPlanRequestTO paramValidateChangeBRPlanRequestTO) throws RemoteException;
  
  BRPlanOfferResponseTO validateAffiliationService(ValidateAffiliationServiceRequestTO paramValidateAffiliationServiceRequestTO) throws RemoteException;
  
  ValidateAuthorisedProfileResponseTO validateAuthorisedProfile(ValidateAuthorisedProfileRequestTO paramValidateAuthorisedProfileRequestTO) throws RemoteException;
  
  BRPlanOfferResponseTO validateChangePlanText(ValidateChangePlanTextRequestTO paramValidateChangePlanTextRequestTO) throws RemoteException;
  
  BooleanResponseTO validateCompatibilityPlanModel(ValidatePlanModelRequestTO paramValidatePlanModelRequestTO) throws RemoteException;
  
  BooleanResponseTO validateCompatibilityPlanModel_v2(ValidatePlanModelRequestTO_v2 paramValidatePlanModelRequestTO_v2) throws RemoteException;
  
  BooleanResponseTO validateCompatibilityPlanPromotionDealer(ValidatePlanPromotionDealerRequestTO paramValidatePlanPromotionDealerRequestTO) throws RemoteException;
  
  BooleanResponseTO validateCompatibilityPlanServices(ValidatePlanServicesRequestTO paramValidatePlanServicesRequestTO) throws RemoteException;
  
  BooleanResponseTO validateCompatibilityServicesModel(ValidateServicesModelRequestTO paramValidateServicesModelRequestTO) throws RemoteException;
  
  BooleanResponseTO validateCompatibilityServicesModel_v2(ValidateServicesModelRequestTO_v2 paramValidateServicesModelRequestTO_v2) throws RemoteException;
  
  BRPlanOfferResponseTO validateDisConnectionService(ValidateDisConnectionServiceRequestTO paramValidateDisConnectionServiceRequestTO) throws RemoteException;
  
  ValidateNumberSpecialServicesResponseTO validateNumberSpecialServices(ValidateNumberSpecialServicesRequestTO paramValidateNumberSpecialServicesRequestTO) throws RemoteException;
  
  BooleanResponseTO validatePlan(ValidatePlanRequestTO paramValidatePlanRequestTO) throws RemoteException;
  
  BooleanResponseTO validatePlanConsejoComunal(ValidatePlanConsejoComunalRequestTO paramValidatePlanConsejoComunalRequestTO) throws RemoteException;
  
  ValidatePlanResponseTO validatePlan_v2(ValidatePlanRequestTO_v2 paramValidatePlanRequestTO_v2) throws RemoteException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\IWSPrepayBaseBrPlanOffer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */