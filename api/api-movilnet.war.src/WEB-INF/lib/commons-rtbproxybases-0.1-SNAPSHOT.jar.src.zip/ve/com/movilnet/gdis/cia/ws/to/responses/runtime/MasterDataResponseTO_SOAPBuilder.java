/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.NationalitiesTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ProfessionTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SectorTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.StateTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MasterDataResponseTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private MasterDataResponseTO _instance;
/*     */   private long executionTime;
/*     */   private String origin;
/*     */   private String responseCode;
/*     */   private String responseDescription;
/*     */   private String responseMessage;
/*     */   private String responseSubCode;
/*     */   private String transactionId;
/*     */   private AdjustmentReasonsTO[] adjustmentReasons;
/*     */   private BalanceListTO[] balanceList;
/*     */   private ChargeCodeTO[] chargeCodes;
/*     */   private CityTO[] city;
/*     */   private CommunalCouncilChargeTO[] communalCouncilCharges;
/*     */   private CoolingReasonTO[] coolingReason;
/*     */   private IVRPlanBenefitTO[] ivrPlanBenefits;
/*     */   private IVRPlanTO[] ivrPlans;
/*     */   private LocalityTO[] locality;
/*     */   private MemosCategoryTO[] memosCategory;
/*     */   private PhoneModelTO[] modelsPhones;
/*     */   private MunicipalitieTO[] municipalitie;
/*     */   private NationalitiesTO[] nationalities;
/*     */   private ParisheTO[] parishe;
/*     */   private PlanTO[] plans;
/*     */   private ProfessionTO[] profession;
/*     */   private PromotionTO[] promotions;
/*     */   private SectorTO[] sector;
/*     */   private SellingAgentTO[] sellingAgent;
/*     */   private ServiceTO[] services;
/*     */   private StateTO[] state;
/*     */   private CityStructuredTO[] structuredCities;
/*     */   private StateTO[] structuredStates;
/*     */   private ZoneStructuredTO[] structuredZones;
/*     */   private SubCategoryTO[] subCategory;
/*     */   private TextPlanTO[] textPlans;
/*     */   private UrbanizationTO[] urbanization;
/*     */   
/*     */   public void setExecutionTime(long executionTime) {
/*  89 */     this.executionTime = executionTime;
/*     */   }
/*     */   private ZoneTO[] zone; private static final int myexecutionTime_INDEX = 0; private static final int myorigin_INDEX = 1; private static final int myresponseCode_INDEX = 2; private static final int myresponseDescription_INDEX = 3; private static final int myresponseMessage_INDEX = 4; private static final int myresponseSubCode_INDEX = 5; private static final int mytransactionId_INDEX = 6; private static final int myadjustmentReasons_INDEX = 7; private static final int mybalanceList_INDEX = 8; private static final int mychargeCodes_INDEX = 9; private static final int mycity_INDEX = 10; private static final int mycommunalCouncilCharges_INDEX = 11; private static final int mycoolingReason_INDEX = 12; private static final int myivrPlanBenefits_INDEX = 13; private static final int myivrPlans_INDEX = 14; private static final int mylocality_INDEX = 15; private static final int mymemosCategory_INDEX = 16; private static final int mymodelsPhones_INDEX = 17; private static final int mymunicipalitie_INDEX = 18; private static final int mynationalities_INDEX = 19; private static final int myparishe_INDEX = 20; private static final int myplans_INDEX = 21; private static final int myprofession_INDEX = 22; private static final int mypromotions_INDEX = 23; private static final int mysector_INDEX = 24; private static final int mysellingAgent_INDEX = 25; private static final int myservices_INDEX = 26; private static final int mystate_INDEX = 27; private static final int mystructuredCities_INDEX = 28; private static final int mystructuredStates_INDEX = 29; private static final int mystructuredZones_INDEX = 30; private static final int mysubCategory_INDEX = 31; private static final int mytextPlans_INDEX = 32; private static final int myurbanization_INDEX = 33; private static final int myzone_INDEX = 34;
/*     */   public void setOrigin(String origin) {
/*  93 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public void setResponseCode(String responseCode) {
/*  97 */     this.responseCode = responseCode;
/*     */   }
/*     */   
/*     */   public void setResponseDescription(String responseDescription) {
/* 101 */     this.responseDescription = responseDescription;
/*     */   }
/*     */   
/*     */   public void setResponseMessage(String responseMessage) {
/* 105 */     this.responseMessage = responseMessage;
/*     */   }
/*     */   
/*     */   public void setResponseSubCode(String responseSubCode) {
/* 109 */     this.responseSubCode = responseSubCode;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/* 113 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAdjustmentReasons(AdjustmentReasonsTO[] adjustmentReasons) {
/* 117 */     this.adjustmentReasons = adjustmentReasons;
/*     */   }
/*     */   
/*     */   public void setBalanceList(BalanceListTO[] balanceList) {
/* 121 */     this.balanceList = balanceList;
/*     */   }
/*     */   
/*     */   public void setChargeCodes(ChargeCodeTO[] chargeCodes) {
/* 125 */     this.chargeCodes = chargeCodes;
/*     */   }
/*     */   
/*     */   public void setCity(CityTO[] city) {
/* 129 */     this.city = city;
/*     */   }
/*     */   
/*     */   public void setCommunalCouncilCharges(CommunalCouncilChargeTO[] communalCouncilCharges) {
/* 133 */     this.communalCouncilCharges = communalCouncilCharges;
/*     */   }
/*     */   
/*     */   public void setCoolingReason(CoolingReasonTO[] coolingReason) {
/* 137 */     this.coolingReason = coolingReason;
/*     */   }
/*     */   
/*     */   public void setIvrPlanBenefits(IVRPlanBenefitTO[] ivrPlanBenefits) {
/* 141 */     this.ivrPlanBenefits = ivrPlanBenefits;
/*     */   }
/*     */   
/*     */   public void setIvrPlans(IVRPlanTO[] ivrPlans) {
/* 145 */     this.ivrPlans = ivrPlans;
/*     */   }
/*     */   
/*     */   public void setLocality(LocalityTO[] locality) {
/* 149 */     this.locality = locality;
/*     */   }
/*     */   
/*     */   public void setMemosCategory(MemosCategoryTO[] memosCategory) {
/* 153 */     this.memosCategory = memosCategory;
/*     */   }
/*     */   
/*     */   public void setModelsPhones(PhoneModelTO[] modelsPhones) {
/* 157 */     this.modelsPhones = modelsPhones;
/*     */   }
/*     */   
/*     */   public void setMunicipalitie(MunicipalitieTO[] municipalitie) {
/* 161 */     this.municipalitie = municipalitie;
/*     */   }
/*     */   
/*     */   public void setNationalities(NationalitiesTO[] nationalities) {
/* 165 */     this.nationalities = nationalities;
/*     */   }
/*     */   
/*     */   public void setParishe(ParisheTO[] parishe) {
/* 169 */     this.parishe = parishe;
/*     */   }
/*     */   
/*     */   public void setPlans(PlanTO[] plans) {
/* 173 */     this.plans = plans;
/*     */   }
/*     */   
/*     */   public void setProfession(ProfessionTO[] profession) {
/* 177 */     this.profession = profession;
/*     */   }
/*     */   
/*     */   public void setPromotions(PromotionTO[] promotions) {
/* 181 */     this.promotions = promotions;
/*     */   }
/*     */   
/*     */   public void setSector(SectorTO[] sector) {
/* 185 */     this.sector = sector;
/*     */   }
/*     */   
/*     */   public void setSellingAgent(SellingAgentTO[] sellingAgent) {
/* 189 */     this.sellingAgent = sellingAgent;
/*     */   }
/*     */   
/*     */   public void setServices(ServiceTO[] services) {
/* 193 */     this.services = services;
/*     */   }
/*     */   
/*     */   public void setState(StateTO[] state) {
/* 197 */     this.state = state;
/*     */   }
/*     */   
/*     */   public void setStructuredCities(CityStructuredTO[] structuredCities) {
/* 201 */     this.structuredCities = structuredCities;
/*     */   }
/*     */   
/*     */   public void setStructuredStates(StateTO[] structuredStates) {
/* 205 */     this.structuredStates = structuredStates;
/*     */   }
/*     */   
/*     */   public void setStructuredZones(ZoneStructuredTO[] structuredZones) {
/* 209 */     this.structuredZones = structuredZones;
/*     */   }
/*     */   
/*     */   public void setSubCategory(SubCategoryTO[] subCategory) {
/* 213 */     this.subCategory = subCategory;
/*     */   }
/*     */   
/*     */   public void setTextPlans(TextPlanTO[] textPlans) {
/* 217 */     this.textPlans = textPlans;
/*     */   }
/*     */   
/*     */   public void setUrbanization(UrbanizationTO[] urbanization) {
/* 221 */     this.urbanization = urbanization;
/*     */   }
/*     */   
/*     */   public void setZone(ZoneTO[] zone) {
/* 225 */     this.zone = zone;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/* 229 */     switch (memberIndex) {
/*     */       case 0:
/* 231 */         return 6;
/*     */       case 1:
/* 233 */         return 6;
/*     */       case 2:
/* 235 */         return 6;
/*     */       case 3:
/* 237 */         return 6;
/*     */       case 4:
/* 239 */         return 6;
/*     */       case 5:
/* 241 */         return 6;
/*     */       case 6:
/* 243 */         return 6;
/*     */       case 7:
/* 245 */         return 6;
/*     */       case 8:
/* 247 */         return 6;
/*     */       case 9:
/* 249 */         return 6;
/*     */       case 10:
/* 251 */         return 6;
/*     */       case 11:
/* 253 */         return 6;
/*     */       case 12:
/* 255 */         return 6;
/*     */       case 13:
/* 257 */         return 6;
/*     */       case 14:
/* 259 */         return 6;
/*     */       case 15:
/* 261 */         return 6;
/*     */       case 16:
/* 263 */         return 6;
/*     */       case 17:
/* 265 */         return 6;
/*     */       case 18:
/* 267 */         return 6;
/*     */       case 19:
/* 269 */         return 6;
/*     */       case 20:
/* 271 */         return 6;
/*     */       case 21:
/* 273 */         return 6;
/*     */       case 22:
/* 275 */         return 6;
/*     */       case 23:
/* 277 */         return 6;
/*     */       case 24:
/* 279 */         return 6;
/*     */       case 25:
/* 281 */         return 6;
/*     */       case 26:
/* 283 */         return 6;
/*     */       case 27:
/* 285 */         return 6;
/*     */       case 28:
/* 287 */         return 6;
/*     */       case 29:
/* 289 */         return 6;
/*     */       case 30:
/* 291 */         return 6;
/*     */       case 31:
/* 293 */         return 6;
/*     */       case 32:
/* 295 */         return 6;
/*     */       case 33:
/* 297 */         return 6;
/*     */       case 34:
/* 299 */         return 6;
/*     */     } 
/* 301 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 310 */       switch (index) {
/*     */         case 0:
/* 312 */           this._instance.setExecutionTime(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 1:
/* 315 */           this._instance.setOrigin((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 318 */           this._instance.setResponseCode((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 321 */           this._instance.setResponseDescription((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 324 */           this._instance.setResponseMessage((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 327 */           this._instance.setResponseSubCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 330 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 333 */           this._instance.setAdjustmentReasons((AdjustmentReasonsTO[])memberValue);
/*     */           return;
/*     */         case 8:
/* 336 */           this._instance.setBalanceList((BalanceListTO[])memberValue);
/*     */           return;
/*     */         case 9:
/* 339 */           this._instance.setChargeCodes((ChargeCodeTO[])memberValue);
/*     */           return;
/*     */         case 10:
/* 342 */           this._instance.setCity((CityTO[])memberValue);
/*     */           return;
/*     */         case 11:
/* 345 */           this._instance.setCommunalCouncilCharges((CommunalCouncilChargeTO[])memberValue);
/*     */           return;
/*     */         case 12:
/* 348 */           this._instance.setCoolingReason((CoolingReasonTO[])memberValue);
/*     */           return;
/*     */         case 13:
/* 351 */           this._instance.setIvrPlanBenefits((IVRPlanBenefitTO[])memberValue);
/*     */           return;
/*     */         case 14:
/* 354 */           this._instance.setIvrPlans((IVRPlanTO[])memberValue);
/*     */           return;
/*     */         case 15:
/* 357 */           this._instance.setLocality((LocalityTO[])memberValue);
/*     */           return;
/*     */         case 16:
/* 360 */           this._instance.setMemosCategory((MemosCategoryTO[])memberValue);
/*     */           return;
/*     */         case 17:
/* 363 */           this._instance.setModelsPhones((PhoneModelTO[])memberValue);
/*     */           return;
/*     */         case 18:
/* 366 */           this._instance.setMunicipalitie((MunicipalitieTO[])memberValue);
/*     */           return;
/*     */         case 19:
/* 369 */           this._instance.setNationalities((NationalitiesTO[])memberValue);
/*     */           return;
/*     */         case 20:
/* 372 */           this._instance.setParishe((ParisheTO[])memberValue);
/*     */           return;
/*     */         case 21:
/* 375 */           this._instance.setPlans((PlanTO[])memberValue);
/*     */           return;
/*     */         case 22:
/* 378 */           this._instance.setProfession((ProfessionTO[])memberValue);
/*     */           return;
/*     */         case 23:
/* 381 */           this._instance.setPromotions((PromotionTO[])memberValue);
/*     */           return;
/*     */         case 24:
/* 384 */           this._instance.setSector((SectorTO[])memberValue);
/*     */           return;
/*     */         case 25:
/* 387 */           this._instance.setSellingAgent((SellingAgentTO[])memberValue);
/*     */           return;
/*     */         case 26:
/* 390 */           this._instance.setServices((ServiceTO[])memberValue);
/*     */           return;
/*     */         case 27:
/* 393 */           this._instance.setState((StateTO[])memberValue);
/*     */           return;
/*     */         case 28:
/* 396 */           this._instance.setStructuredCities((CityStructuredTO[])memberValue);
/*     */           return;
/*     */         case 29:
/* 399 */           this._instance.setStructuredStates((StateTO[])memberValue);
/*     */           return;
/*     */         case 30:
/* 402 */           this._instance.setStructuredZones((ZoneStructuredTO[])memberValue);
/*     */           return;
/*     */         case 31:
/* 405 */           this._instance.setSubCategory((SubCategoryTO[])memberValue);
/*     */           return;
/*     */         case 32:
/* 408 */           this._instance.setTextPlans((TextPlanTO[])memberValue);
/*     */           return;
/*     */         case 33:
/* 411 */           this._instance.setUrbanization((UrbanizationTO[])memberValue);
/*     */           return;
/*     */         case 34:
/* 414 */           this._instance.setZone((ZoneTO[])memberValue);
/*     */           return;
/*     */       } 
/* 417 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 420 */     catch (RuntimeException e) {
/* 421 */       throw e;
/*     */     }
/* 423 */     catch (Exception e) {
/* 424 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 432 */     this._instance = (MasterDataResponseTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 436 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\runtime\MasterDataResponseTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */