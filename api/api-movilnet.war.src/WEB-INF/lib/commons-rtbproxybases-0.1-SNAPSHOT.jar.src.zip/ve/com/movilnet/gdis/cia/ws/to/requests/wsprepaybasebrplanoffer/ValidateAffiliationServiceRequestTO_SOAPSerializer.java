/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAffiliationServiceRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidateAffiliationServiceRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidateAffiliationServiceRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_alcsList_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcsList");
/*  33 */   private static final QName ns2_ArrayOfstring_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/*     */   private CombinedSerializer myns2_ArrayOfstring__String_Array_LiteralSerializer1;
/*  35 */   private static final QName ns2_cosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cosName");
/*  36 */   private static final QName ns2_phoneTypeId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "phoneTypeId");
/*  37 */   private static final QName ns2_serviceCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceCode");
/*  38 */   private static final QName ns2_status_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "status");
/*  39 */   private static final QName ns2_subscriberId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subscriberId");
/*  40 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  42 */   private static final QName ns2_userId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "userId"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2; private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myalcsList_INDEX = 5;
/*     */   private static final int mycosName_INDEX = 6;
/*     */   private static final int myphoneTypeId_INDEX = 7;
/*     */   private static final int myserviceCode_INDEX = 8;
/*     */   private static final int mystatus_INDEX = 9;
/*     */   private static final int mysubscriberId_INDEX = 10;
/*     */   private static final int myuserId_INDEX = 11;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   
/*     */   public ValidateAffiliationServiceRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  57 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  61 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidateAffiliationServiceRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  62 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidateAffiliationServiceRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  63 */     if (class$java$lang$String == null); ((ValidateAffiliationServiceRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  64 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  65 */     if (array$Ljava$lang$String == null); ((ValidateAffiliationServiceRequestTO_SOAPSerializer)registry).myns2_ArrayOfstring__String_Array_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), ns2_ArrayOfstring_TYPE_QNAME);
/*  66 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  71 */     ValidateAffiliationServiceRequestTO instance = new ValidateAffiliationServiceRequestTO();
/*  72 */     ValidateAffiliationServiceRequestTO_SOAPBuilder builder = null;
/*     */     
/*  74 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  77 */     reader.nextElementContent();
/*  78 */     QName startName = reader.getName();
/*  79 */     for (int i = 0; i < 12; i++) {
/*  80 */       QName elementName = reader.getName();
/*  81 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  84 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  85 */         context.setNillable(true);
/*  86 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  87 */         if (member instanceof SOAPDeserializationState) {
/*  88 */           if (builder == null) {
/*  89 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/*  91 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  92 */           isComplete = false;
/*  93 */         } else if (member != null) {
/*  94 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  96 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  99 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/* 100 */         context.setNillable(true);
/* 101 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/* 102 */         if (object instanceof SOAPDeserializationState) {
/* 103 */           if (builder == null) {
/* 104 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 106 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 107 */           isComplete = false;
/* 108 */         } else if (object != null) {
/* 109 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 111 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 114 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 115 */         context.setNillable(true);
/* 116 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 117 */         if (object instanceof SOAPDeserializationState) {
/* 118 */           if (builder == null) {
/* 119 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 121 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 122 */           isComplete = false;
/* 123 */         } else if (object != null) {
/* 124 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 126 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 129 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 130 */         context.setNillable(true);
/* 131 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 132 */         if (object instanceof SOAPDeserializationState) {
/* 133 */           if (builder == null) {
/* 134 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 136 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 137 */           isComplete = false;
/* 138 */         } else if (object != null) {
/* 139 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 141 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 144 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 145 */         context.setNillable(true);
/* 146 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 147 */         if (object instanceof SOAPDeserializationState) {
/* 148 */           if (builder == null) {
/* 149 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 151 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 152 */           isComplete = false;
/* 153 */         } else if (object != null) {
/* 154 */           instance.setTransactionId((String)object);
/*     */         } 
/* 156 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 159 */       else if (matchQName(elementName, ns2_alcsList_QNAME)) {
/* 160 */         context.setNillable(true);
/* 161 */         Object object = this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.deserialize(ns2_alcsList_QNAME, reader, context);
/* 162 */         if (object instanceof SOAPDeserializationState) {
/* 163 */           if (builder == null) {
/* 164 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 166 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 167 */           isComplete = false;
/* 168 */         } else if (object != null) {
/* 169 */           instance.setAlcsList((String[])object);
/*     */         } 
/* 171 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 174 */       else if (matchQName(elementName, ns2_cosName_QNAME)) {
/* 175 */         context.setNillable(true);
/* 176 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cosName_QNAME, reader, context);
/* 177 */         if (object instanceof SOAPDeserializationState) {
/* 178 */           if (builder == null) {
/* 179 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 181 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 182 */           isComplete = false;
/* 183 */         } else if (object != null) {
/* 184 */           instance.setCosName((String)object);
/*     */         } 
/* 186 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 189 */       else if (matchQName(elementName, ns2_phoneTypeId_QNAME)) {
/* 190 */         context.setNillable(true);
/* 191 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_phoneTypeId_QNAME, reader, context);
/* 192 */         if (object instanceof SOAPDeserializationState) {
/* 193 */           if (builder == null) {
/* 194 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 196 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 197 */           isComplete = false;
/* 198 */         } else if (object != null) {
/* 199 */           instance.setPhoneTypeId((String)object);
/*     */         } 
/* 201 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 204 */       else if (matchQName(elementName, ns2_serviceCode_QNAME)) {
/* 205 */         context.setNillable(true);
/* 206 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceCode_QNAME, reader, context);
/* 207 */         if (object instanceof SOAPDeserializationState) {
/* 208 */           if (builder == null) {
/* 209 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 211 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 212 */           isComplete = false;
/* 213 */         } else if (object != null) {
/* 214 */           instance.setServiceCode((String)object);
/*     */         } 
/* 216 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 219 */       else if (matchQName(elementName, ns2_status_QNAME)) {
/* 220 */         context.setNillable(true);
/* 221 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_status_QNAME, reader, context);
/* 222 */         if (object instanceof SOAPDeserializationState) {
/* 223 */           if (builder == null) {
/* 224 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 226 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 227 */           isComplete = false;
/* 228 */         } else if (object != null) {
/* 229 */           instance.setStatus((String)object);
/*     */         } 
/* 231 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 234 */       else if (matchQName(elementName, ns2_subscriberId_QNAME)) {
/* 235 */         context.setNillable(true);
/* 236 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_subscriberId_QNAME, reader, context);
/* 237 */         if (object instanceof SOAPDeserializationState) {
/* 238 */           if (builder == null) {
/* 239 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 241 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 242 */           isComplete = false;
/* 243 */         } else if (object != null) {
/* 244 */           instance.setSubscriberId(((Long)object).longValue());
/*     */         } 
/* 246 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 249 */       else if (matchQName(elementName, ns2_userId_QNAME)) {
/* 250 */         context.setNillable(true);
/* 251 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_userId_QNAME, reader, context);
/* 252 */         if (object instanceof SOAPDeserializationState) {
/* 253 */           if (builder == null) {
/* 254 */             builder = new ValidateAffiliationServiceRequestTO_SOAPBuilder();
/*     */           }
/* 256 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 257 */           isComplete = false;
/* 258 */         } else if (object != null) {
/* 259 */           instance.setUserId((String)object);
/*     */         } 
/* 261 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 264 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_userId_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 269 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 270 */     } catch (XMLReaderException xmle) {
/* 271 */       if (startName != null) {
/* 272 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 274 */       throw xmle;
/*     */     } 
/*     */     
/* 277 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 281 */     ValidateAffiliationServiceRequestTO instance = (ValidateAffiliationServiceRequestTO)obj;
/*     */     
/* 283 */     context.setNillable(true);
/* 284 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 285 */     context.setNillable(true);
/* 286 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 287 */     context.setNillable(true);
/* 288 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 289 */     context.setNillable(true);
/* 290 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 291 */     context.setNillable(true);
/* 292 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 293 */     context.setNillable(true);
/* 294 */     this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.serialize(instance.getAlcsList(), ns2_alcsList_QNAME, null, writer, context);
/* 295 */     context.setNillable(true);
/* 296 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCosName(), ns2_cosName_QNAME, null, writer, context);
/* 297 */     context.setNillable(true);
/* 298 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPhoneTypeId(), ns2_phoneTypeId_QNAME, null, writer, context);
/* 299 */     context.setNillable(true);
/* 300 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceCode(), ns2_serviceCode_QNAME, null, writer, context);
/* 301 */     context.setNillable(true);
/* 302 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getStatus(), ns2_status_QNAME, null, writer, context);
/* 303 */     context.setNillable(true);
/* 304 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getSubscriberId()), ns2_subscriberId_QNAME, null, writer, context);
/* 305 */     context.setNillable(true);
/* 306 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUserId(), ns2_userId_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidateAffiliationServiceRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */