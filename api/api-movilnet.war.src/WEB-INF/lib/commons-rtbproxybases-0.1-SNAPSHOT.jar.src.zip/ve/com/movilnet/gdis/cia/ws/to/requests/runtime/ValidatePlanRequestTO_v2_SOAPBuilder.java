/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO_v2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatePlanRequestTO_v2_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidatePlanRequestTO_v2 _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String aplicationType;
/*     */   private String customerType;
/*     */   private String[] entrada;
/*     */   private String planCode;
/*     */   private String planCosName;
/*     */   private String ssn;
/*     */   private long subscriberId;
/*     */   private String transactionType;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myaplicationType_INDEX = 5;
/*     */   private static final int mycustomerType_INDEX = 6;
/*     */   private static final int myentrada_INDEX = 7;
/*     */   private static final int myplanCode_INDEX = 8;
/*     */   private static final int myplanCosName_INDEX = 9;
/*     */   private static final int myssn_INDEX = 10;
/*     */   private static final int mysubscriberId_INDEX = 11;
/*     */   private static final int mytransactionType_INDEX = 12;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  45 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  49 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  53 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  57 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  61 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAplicationType(String aplicationType) {
/*  65 */     this.aplicationType = aplicationType;
/*     */   }
/*     */   
/*     */   public void setCustomerType(String customerType) {
/*  69 */     this.customerType = customerType;
/*     */   }
/*     */   
/*     */   public void setEntrada(String[] entrada) {
/*  73 */     this.entrada = entrada;
/*     */   }
/*     */   
/*     */   public void setPlanCode(String planCode) {
/*  77 */     this.planCode = planCode;
/*     */   }
/*     */   
/*     */   public void setPlanCosName(String planCosName) {
/*  81 */     this.planCosName = planCosName;
/*     */   }
/*     */   
/*     */   public void setSsn(String ssn) {
/*  85 */     this.ssn = ssn;
/*     */   }
/*     */   
/*     */   public void setSubscriberId(long subscriberId) {
/*  89 */     this.subscriberId = subscriberId;
/*     */   }
/*     */   
/*     */   public void setTransactionType(String transactionType) {
/*  93 */     this.transactionType = transactionType;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  97 */     switch (memberIndex) {
/*     */       case 0:
/*  99 */         return 6;
/*     */       case 1:
/* 101 */         return 6;
/*     */       case 2:
/* 103 */         return 6;
/*     */       case 3:
/* 105 */         return 6;
/*     */       case 4:
/* 107 */         return 6;
/*     */       case 5:
/* 109 */         return 6;
/*     */       case 6:
/* 111 */         return 6;
/*     */       case 7:
/* 113 */         return 6;
/*     */       case 8:
/* 115 */         return 6;
/*     */       case 9:
/* 117 */         return 6;
/*     */       case 10:
/* 119 */         return 6;
/*     */       case 11:
/* 121 */         return 6;
/*     */       case 12:
/* 123 */         return 6;
/*     */     } 
/* 125 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 134 */       switch (index) {
/*     */         case 0:
/* 136 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/* 139 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/* 142 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 145 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 148 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 151 */           this._instance.setAplicationType((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 154 */           this._instance.setCustomerType((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 157 */           this._instance.setEntrada((String[])memberValue);
/*     */           return;
/*     */         case 8:
/* 160 */           this._instance.setPlanCode((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 163 */           this._instance.setPlanCosName((String)memberValue);
/*     */           return;
/*     */         case 10:
/* 166 */           this._instance.setSsn((String)memberValue);
/*     */           return;
/*     */         case 11:
/* 169 */           this._instance.setSubscriberId(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 12:
/* 172 */           this._instance.setTransactionType((String)memberValue);
/*     */           return;
/*     */       } 
/* 175 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 178 */     catch (RuntimeException e) {
/* 179 */       throw e;
/*     */     }
/* 181 */     catch (Exception e) {
/* 182 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 190 */     this._instance = (ValidatePlanRequestTO_v2)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 194 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\ValidatePlanRequestTO_v2_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */