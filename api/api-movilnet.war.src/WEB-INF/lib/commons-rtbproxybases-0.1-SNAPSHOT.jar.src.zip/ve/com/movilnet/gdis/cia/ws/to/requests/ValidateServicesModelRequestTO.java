/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateServicesModelRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String alcoName;
/*    */   protected String serial;
/*    */   protected String serviceCode;
/*    */   protected String transactionType;
/*    */   
/*    */   public String getAlcoName() {
/* 20 */     return this.alcoName;
/*    */   }
/*    */   
/*    */   public void setAlcoName(String alcoName) {
/* 24 */     this.alcoName = alcoName;
/*    */   }
/*    */   
/*    */   public String getSerial() {
/* 28 */     return this.serial;
/*    */   }
/*    */   
/*    */   public void setSerial(String serial) {
/* 32 */     this.serial = serial;
/*    */   }
/*    */   
/*    */   public String getServiceCode() {
/* 36 */     return this.serviceCode;
/*    */   }
/*    */   
/*    */   public void setServiceCode(String serviceCode) {
/* 40 */     this.serviceCode = serviceCode;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 44 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 48 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateServicesModelRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */