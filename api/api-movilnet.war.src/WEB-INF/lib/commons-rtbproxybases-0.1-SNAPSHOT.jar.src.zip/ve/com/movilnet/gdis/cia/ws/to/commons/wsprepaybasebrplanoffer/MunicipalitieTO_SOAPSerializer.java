/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.MunicipalitieTO_SOAPBuilder;
/*     */ 
/*     */ public class MunicipalitieTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_municipioCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "municipioCode");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_parroquiaName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "parroquiaName");
/*  23 */   private static final QName ns2_stateCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "stateCode"); private static final int mymunicipioCode_INDEX = 0;
/*     */   private static final int myparroquiaName_INDEX = 1;
/*     */   private static final int mystateCode_INDEX = 2;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public MunicipalitieTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  29 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  33 */     if (class$java$lang$String == null); ((MunicipalitieTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  38 */     MunicipalitieTO instance = new MunicipalitieTO();
/*  39 */     MunicipalitieTO_SOAPBuilder builder = null;
/*     */     
/*  41 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  44 */     reader.nextElementContent();
/*  45 */     QName startName = reader.getName();
/*  46 */     for (int i = 0; i < 3; i++) {
/*  47 */       QName elementName = reader.getName();
/*  48 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  51 */       if (matchQName(elementName, ns2_municipioCode_QNAME)) {
/*  52 */         context.setNillable(true);
/*  53 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_municipioCode_QNAME, reader, context);
/*  54 */         if (member instanceof SOAPDeserializationState) {
/*  55 */           if (builder == null) {
/*  56 */             builder = new MunicipalitieTO_SOAPBuilder();
/*     */           }
/*  58 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  59 */           isComplete = false;
/*  60 */         } else if (member != null) {
/*  61 */           instance.setMunicipioCode((String)member);
/*     */         } 
/*  63 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  66 */       else if (matchQName(elementName, ns2_parroquiaName_QNAME)) {
/*  67 */         context.setNillable(true);
/*  68 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_parroquiaName_QNAME, reader, context);
/*  69 */         if (object instanceof SOAPDeserializationState) {
/*  70 */           if (builder == null) {
/*  71 */             builder = new MunicipalitieTO_SOAPBuilder();
/*     */           }
/*  73 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  74 */           isComplete = false;
/*  75 */         } else if (object != null) {
/*  76 */           instance.setParroquiaName((String)object);
/*     */         } 
/*  78 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  81 */       else if (matchQName(elementName, ns2_stateCode_QNAME)) {
/*  82 */         context.setNillable(true);
/*  83 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_stateCode_QNAME, reader, context);
/*  84 */         if (object instanceof SOAPDeserializationState) {
/*  85 */           if (builder == null) {
/*  86 */             builder = new MunicipalitieTO_SOAPBuilder();
/*     */           }
/*  88 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/*  89 */           isComplete = false;
/*  90 */         } else if (object != null) {
/*  91 */           instance.setStateCode((String)object);
/*     */         } 
/*  93 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/*  96 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_stateCode_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 101 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 102 */     } catch (XMLReaderException xmle) {
/* 103 */       if (startName != null) {
/* 104 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 106 */       throw xmle;
/*     */     } 
/*     */     
/* 109 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 113 */     MunicipalitieTO instance = (MunicipalitieTO)obj;
/*     */     
/* 115 */     context.setNillable(true);
/* 116 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getMunicipioCode(), ns2_municipioCode_QNAME, null, writer, context);
/* 117 */     context.setNillable(true);
/* 118 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getParroquiaName(), ns2_parroquiaName_QNAME, null, writer, context);
/* 119 */     context.setNillable(true);
/* 120 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getStateCode(), ns2_stateCode_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\MunicipalitieTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */