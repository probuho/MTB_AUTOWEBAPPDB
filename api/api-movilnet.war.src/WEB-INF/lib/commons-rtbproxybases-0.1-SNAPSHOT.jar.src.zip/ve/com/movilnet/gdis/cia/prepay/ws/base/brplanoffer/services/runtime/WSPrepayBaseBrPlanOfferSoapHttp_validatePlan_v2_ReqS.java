/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO_v2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidatePlanRequestTO_v2 planRequest;
/*    */   
/*    */   public ValidatePlanRequestTO_v2 getPlanRequest() {
/* 17 */     return this.planRequest;
/*    */   }
/*    */   
/*    */   public void setPlanRequest(ValidatePlanRequestTO_v2 planRequest) {
/* 21 */     this.planRequest = planRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */