/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IVRPlanBenefitTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private IVRPlanBenefitTO _instance;
/*    */   private String balanceName;
/*    */   private String cosName;
/*    */   private long quantity;
/*    */   private String unitType;
/*    */   private static final int mybalanceName_INDEX = 0;
/*    */   private static final int mycosName_INDEX = 1;
/*    */   private static final int myquantity_INDEX = 2;
/*    */   private static final int myunitType_INDEX = 3;
/*    */   
/*    */   public void setBalanceName(String balanceName) {
/* 27 */     this.balanceName = balanceName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 31 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public void setQuantity(long quantity) {
/* 35 */     this.quantity = quantity;
/*    */   }
/*    */   
/*    */   public void setUnitType(String unitType) {
/* 39 */     this.unitType = unitType;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 43 */     switch (memberIndex) {
/*    */       case 0:
/* 45 */         return 6;
/*    */       case 1:
/* 47 */         return 6;
/*    */       case 2:
/* 49 */         return 6;
/*    */       case 3:
/* 51 */         return 6;
/*    */     } 
/* 53 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 62 */       switch (index) {
/*    */         case 0:
/* 64 */           this._instance.setBalanceName((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 67 */           this._instance.setCosName((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 70 */           this._instance.setQuantity(((Long)memberValue).longValue());
/*    */           return;
/*    */         case 3:
/* 73 */           this._instance.setUnitType((String)memberValue);
/*    */           return;
/*    */       } 
/* 76 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 79 */     catch (RuntimeException e) {
/* 80 */       throw e;
/*    */     }
/* 82 */     catch (Exception e) {
/* 83 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 91 */     this._instance = (IVRPlanBenefitTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 95 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\IVRPlanBenefitTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */