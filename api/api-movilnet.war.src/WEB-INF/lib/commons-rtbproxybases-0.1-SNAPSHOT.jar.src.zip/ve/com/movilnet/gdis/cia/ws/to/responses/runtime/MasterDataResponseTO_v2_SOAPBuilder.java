/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.EquipmentTypeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.NationalitiesTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ProfessionTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SectorTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.StateTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO_v2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MasterDataResponseTO_v2_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private MasterDataResponseTO_v2 _instance;
/*     */   private long executionTime;
/*     */   private String origin;
/*     */   private String responseCode;
/*     */   private String responseDescription;
/*     */   private String responseMessage;
/*     */   private String responseSubCode;
/*     */   private String transactionId;
/*     */   private AdjustmentReasonsTO[] adjustmentReasons;
/*     */   private AlcoCosTO alcoCosTO;
/*     */   private BalanceListTO[] balanceList;
/*     */   private ChargeCodeTO[] chargeCodes;
/*     */   private CityTO[] city;
/*     */   private CommunalCouncilChargeTO[] communalCouncilCharges;
/*     */   private CoolingReasonTO[] coolingReason;
/*     */   private EquipmentTypeTO[] equipmentTypeTO;
/*     */   private SubCategoryTO[] feechargeType;
/*     */   private IVRPlanBenefitTO[] ivrPlanBenefits;
/*     */   private IVRPlanTO[] ivrPlans;
/*     */   private LocalityTO[] locality;
/*     */   private MemosCategoryTO[] memosCategory;
/*     */   private PhoneModelTO[] modelsPhones;
/*     */   private MunicipalitieTO[] municipalitie;
/*     */   private NationalitiesTO[] nationalities;
/*     */   private ParisheTO[] parishe;
/*     */   private PlanTO[] plans;
/*     */   private ProfessionTO[] profession;
/*     */   private PromotionTO[] promotions;
/*     */   private PromotionTO[] promotionsMig;
/*     */   private SectorTO[] sector;
/*     */   private SellingAgentTO[] sellingAgent;
/*     */   private ServiceTO_v3[] services;
/*     */   private StateTO[] state;
/*     */   private CityStructuredTO[] structuredCities;
/*     */   private StateTO[] structuredStates;
/*     */   private ZoneStructuredTO[] structuredZones;
/*     */   private SubCategoryTO[] subCategory;
/*     */   private TextPlanTO[] textPlans;
/*     */   private UrbanizationTO[] urbanization;
/*     */   
/*     */   public void setExecutionTime(long executionTime) {
/*  97 */     this.executionTime = executionTime;
/*     */   }
/*     */   private ZoneTO[] zone; private static final int myexecutionTime_INDEX = 0; private static final int myorigin_INDEX = 1; private static final int myresponseCode_INDEX = 2; private static final int myresponseDescription_INDEX = 3; private static final int myresponseMessage_INDEX = 4; private static final int myresponseSubCode_INDEX = 5; private static final int mytransactionId_INDEX = 6; private static final int myadjustmentReasons_INDEX = 7; private static final int myalcoCosTO_INDEX = 8; private static final int mybalanceList_INDEX = 9; private static final int mychargeCodes_INDEX = 10; private static final int mycity_INDEX = 11; private static final int mycommunalCouncilCharges_INDEX = 12; private static final int mycoolingReason_INDEX = 13; private static final int myequipmentTypeTO_INDEX = 14; private static final int myfeechargeType_INDEX = 15; private static final int myivrPlanBenefits_INDEX = 16; private static final int myivrPlans_INDEX = 17; private static final int mylocality_INDEX = 18; private static final int mymemosCategory_INDEX = 19; private static final int mymodelsPhones_INDEX = 20; private static final int mymunicipalitie_INDEX = 21; private static final int mynationalities_INDEX = 22; private static final int myparishe_INDEX = 23; private static final int myplans_INDEX = 24; private static final int myprofession_INDEX = 25; private static final int mypromotions_INDEX = 26; private static final int mypromotionsMig_INDEX = 27; private static final int mysector_INDEX = 28; private static final int mysellingAgent_INDEX = 29; private static final int myservices_INDEX = 30; private static final int mystate_INDEX = 31; private static final int mystructuredCities_INDEX = 32; private static final int mystructuredStates_INDEX = 33; private static final int mystructuredZones_INDEX = 34; private static final int mysubCategory_INDEX = 35; private static final int mytextPlans_INDEX = 36; private static final int myurbanization_INDEX = 37; private static final int myzone_INDEX = 38;
/*     */   public void setOrigin(String origin) {
/* 101 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public void setResponseCode(String responseCode) {
/* 105 */     this.responseCode = responseCode;
/*     */   }
/*     */   
/*     */   public void setResponseDescription(String responseDescription) {
/* 109 */     this.responseDescription = responseDescription;
/*     */   }
/*     */   
/*     */   public void setResponseMessage(String responseMessage) {
/* 113 */     this.responseMessage = responseMessage;
/*     */   }
/*     */   
/*     */   public void setResponseSubCode(String responseSubCode) {
/* 117 */     this.responseSubCode = responseSubCode;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/* 121 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAdjustmentReasons(AdjustmentReasonsTO[] adjustmentReasons) {
/* 125 */     this.adjustmentReasons = adjustmentReasons;
/*     */   }
/*     */   
/*     */   public void setAlcoCosTO(AlcoCosTO alcoCosTO) {
/* 129 */     this.alcoCosTO = alcoCosTO;
/*     */   }
/*     */   
/*     */   public void setBalanceList(BalanceListTO[] balanceList) {
/* 133 */     this.balanceList = balanceList;
/*     */   }
/*     */   
/*     */   public void setChargeCodes(ChargeCodeTO[] chargeCodes) {
/* 137 */     this.chargeCodes = chargeCodes;
/*     */   }
/*     */   
/*     */   public void setCity(CityTO[] city) {
/* 141 */     this.city = city;
/*     */   }
/*     */   
/*     */   public void setCommunalCouncilCharges(CommunalCouncilChargeTO[] communalCouncilCharges) {
/* 145 */     this.communalCouncilCharges = communalCouncilCharges;
/*     */   }
/*     */   
/*     */   public void setCoolingReason(CoolingReasonTO[] coolingReason) {
/* 149 */     this.coolingReason = coolingReason;
/*     */   }
/*     */   
/*     */   public void setEquipmentTypeTO(EquipmentTypeTO[] equipmentTypeTO) {
/* 153 */     this.equipmentTypeTO = equipmentTypeTO;
/*     */   }
/*     */   
/*     */   public void setFeechargeType(SubCategoryTO[] feechargeType) {
/* 157 */     this.feechargeType = feechargeType;
/*     */   }
/*     */   
/*     */   public void setIvrPlanBenefits(IVRPlanBenefitTO[] ivrPlanBenefits) {
/* 161 */     this.ivrPlanBenefits = ivrPlanBenefits;
/*     */   }
/*     */   
/*     */   public void setIvrPlans(IVRPlanTO[] ivrPlans) {
/* 165 */     this.ivrPlans = ivrPlans;
/*     */   }
/*     */   
/*     */   public void setLocality(LocalityTO[] locality) {
/* 169 */     this.locality = locality;
/*     */   }
/*     */   
/*     */   public void setMemosCategory(MemosCategoryTO[] memosCategory) {
/* 173 */     this.memosCategory = memosCategory;
/*     */   }
/*     */   
/*     */   public void setModelsPhones(PhoneModelTO[] modelsPhones) {
/* 177 */     this.modelsPhones = modelsPhones;
/*     */   }
/*     */   
/*     */   public void setMunicipalitie(MunicipalitieTO[] municipalitie) {
/* 181 */     this.municipalitie = municipalitie;
/*     */   }
/*     */   
/*     */   public void setNationalities(NationalitiesTO[] nationalities) {
/* 185 */     this.nationalities = nationalities;
/*     */   }
/*     */   
/*     */   public void setParishe(ParisheTO[] parishe) {
/* 189 */     this.parishe = parishe;
/*     */   }
/*     */   
/*     */   public void setPlans(PlanTO[] plans) {
/* 193 */     this.plans = plans;
/*     */   }
/*     */   
/*     */   public void setProfession(ProfessionTO[] profession) {
/* 197 */     this.profession = profession;
/*     */   }
/*     */   
/*     */   public void setPromotions(PromotionTO[] promotions) {
/* 201 */     this.promotions = promotions;
/*     */   }
/*     */   
/*     */   public void setPromotionsMig(PromotionTO[] promotionsMig) {
/* 205 */     this.promotionsMig = promotionsMig;
/*     */   }
/*     */   
/*     */   public void setSector(SectorTO[] sector) {
/* 209 */     this.sector = sector;
/*     */   }
/*     */   
/*     */   public void setSellingAgent(SellingAgentTO[] sellingAgent) {
/* 213 */     this.sellingAgent = sellingAgent;
/*     */   }
/*     */   
/*     */   public void setServices(ServiceTO_v3[] services) {
/* 217 */     this.services = services;
/*     */   }
/*     */   
/*     */   public void setState(StateTO[] state) {
/* 221 */     this.state = state;
/*     */   }
/*     */   
/*     */   public void setStructuredCities(CityStructuredTO[] structuredCities) {
/* 225 */     this.structuredCities = structuredCities;
/*     */   }
/*     */   
/*     */   public void setStructuredStates(StateTO[] structuredStates) {
/* 229 */     this.structuredStates = structuredStates;
/*     */   }
/*     */   
/*     */   public void setStructuredZones(ZoneStructuredTO[] structuredZones) {
/* 233 */     this.structuredZones = structuredZones;
/*     */   }
/*     */   
/*     */   public void setSubCategory(SubCategoryTO[] subCategory) {
/* 237 */     this.subCategory = subCategory;
/*     */   }
/*     */   
/*     */   public void setTextPlans(TextPlanTO[] textPlans) {
/* 241 */     this.textPlans = textPlans;
/*     */   }
/*     */   
/*     */   public void setUrbanization(UrbanizationTO[] urbanization) {
/* 245 */     this.urbanization = urbanization;
/*     */   }
/*     */   
/*     */   public void setZone(ZoneTO[] zone) {
/* 249 */     this.zone = zone;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/* 253 */     switch (memberIndex) {
/*     */       case 0:
/* 255 */         return 6;
/*     */       case 1:
/* 257 */         return 6;
/*     */       case 2:
/* 259 */         return 6;
/*     */       case 3:
/* 261 */         return 6;
/*     */       case 4:
/* 263 */         return 6;
/*     */       case 5:
/* 265 */         return 6;
/*     */       case 6:
/* 267 */         return 6;
/*     */       case 7:
/* 269 */         return 6;
/*     */       case 8:
/* 271 */         return 6;
/*     */       case 9:
/* 273 */         return 6;
/*     */       case 10:
/* 275 */         return 6;
/*     */       case 11:
/* 277 */         return 6;
/*     */       case 12:
/* 279 */         return 6;
/*     */       case 13:
/* 281 */         return 6;
/*     */       case 14:
/* 283 */         return 6;
/*     */       case 15:
/* 285 */         return 6;
/*     */       case 16:
/* 287 */         return 6;
/*     */       case 17:
/* 289 */         return 6;
/*     */       case 18:
/* 291 */         return 6;
/*     */       case 19:
/* 293 */         return 6;
/*     */       case 20:
/* 295 */         return 6;
/*     */       case 21:
/* 297 */         return 6;
/*     */       case 22:
/* 299 */         return 6;
/*     */       case 23:
/* 301 */         return 6;
/*     */       case 24:
/* 303 */         return 6;
/*     */       case 25:
/* 305 */         return 6;
/*     */       case 26:
/* 307 */         return 6;
/*     */       case 27:
/* 309 */         return 6;
/*     */       case 28:
/* 311 */         return 6;
/*     */       case 29:
/* 313 */         return 6;
/*     */       case 30:
/* 315 */         return 6;
/*     */       case 31:
/* 317 */         return 6;
/*     */       case 32:
/* 319 */         return 6;
/*     */       case 33:
/* 321 */         return 6;
/*     */       case 34:
/* 323 */         return 6;
/*     */       case 35:
/* 325 */         return 6;
/*     */       case 36:
/* 327 */         return 6;
/*     */       case 37:
/* 329 */         return 6;
/*     */       case 38:
/* 331 */         return 6;
/*     */     } 
/* 333 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 342 */       switch (index) {
/*     */         case 0:
/* 344 */           this._instance.setExecutionTime(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 1:
/* 347 */           this._instance.setOrigin((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 350 */           this._instance.setResponseCode((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 353 */           this._instance.setResponseDescription((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 356 */           this._instance.setResponseMessage((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 359 */           this._instance.setResponseSubCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 362 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 365 */           this._instance.setAdjustmentReasons((AdjustmentReasonsTO[])memberValue);
/*     */           return;
/*     */         case 8:
/* 368 */           this._instance.setAlcoCosTO((AlcoCosTO)memberValue);
/*     */           return;
/*     */         case 9:
/* 371 */           this._instance.setBalanceList((BalanceListTO[])memberValue);
/*     */           return;
/*     */         case 10:
/* 374 */           this._instance.setChargeCodes((ChargeCodeTO[])memberValue);
/*     */           return;
/*     */         case 11:
/* 377 */           this._instance.setCity((CityTO[])memberValue);
/*     */           return;
/*     */         case 12:
/* 380 */           this._instance.setCommunalCouncilCharges((CommunalCouncilChargeTO[])memberValue);
/*     */           return;
/*     */         case 13:
/* 383 */           this._instance.setCoolingReason((CoolingReasonTO[])memberValue);
/*     */           return;
/*     */         case 14:
/* 386 */           this._instance.setEquipmentTypeTO((EquipmentTypeTO[])memberValue);
/*     */           return;
/*     */         case 15:
/* 389 */           this._instance.setFeechargeType((SubCategoryTO[])memberValue);
/*     */           return;
/*     */         case 16:
/* 392 */           this._instance.setIvrPlanBenefits((IVRPlanBenefitTO[])memberValue);
/*     */           return;
/*     */         case 17:
/* 395 */           this._instance.setIvrPlans((IVRPlanTO[])memberValue);
/*     */           return;
/*     */         case 18:
/* 398 */           this._instance.setLocality((LocalityTO[])memberValue);
/*     */           return;
/*     */         case 19:
/* 401 */           this._instance.setMemosCategory((MemosCategoryTO[])memberValue);
/*     */           return;
/*     */         case 20:
/* 404 */           this._instance.setModelsPhones((PhoneModelTO[])memberValue);
/*     */           return;
/*     */         case 21:
/* 407 */           this._instance.setMunicipalitie((MunicipalitieTO[])memberValue);
/*     */           return;
/*     */         case 22:
/* 410 */           this._instance.setNationalities((NationalitiesTO[])memberValue);
/*     */           return;
/*     */         case 23:
/* 413 */           this._instance.setParishe((ParisheTO[])memberValue);
/*     */           return;
/*     */         case 24:
/* 416 */           this._instance.setPlans((PlanTO[])memberValue);
/*     */           return;
/*     */         case 25:
/* 419 */           this._instance.setProfession((ProfessionTO[])memberValue);
/*     */           return;
/*     */         case 26:
/* 422 */           this._instance.setPromotions((PromotionTO[])memberValue);
/*     */           return;
/*     */         case 27:
/* 425 */           this._instance.setPromotionsMig((PromotionTO[])memberValue);
/*     */           return;
/*     */         case 28:
/* 428 */           this._instance.setSector((SectorTO[])memberValue);
/*     */           return;
/*     */         case 29:
/* 431 */           this._instance.setSellingAgent((SellingAgentTO[])memberValue);
/*     */           return;
/*     */         case 30:
/* 434 */           this._instance.setServices((ServiceTO_v3[])memberValue);
/*     */           return;
/*     */         case 31:
/* 437 */           this._instance.setState((StateTO[])memberValue);
/*     */           return;
/*     */         case 32:
/* 440 */           this._instance.setStructuredCities((CityStructuredTO[])memberValue);
/*     */           return;
/*     */         case 33:
/* 443 */           this._instance.setStructuredStates((StateTO[])memberValue);
/*     */           return;
/*     */         case 34:
/* 446 */           this._instance.setStructuredZones((ZoneStructuredTO[])memberValue);
/*     */           return;
/*     */         case 35:
/* 449 */           this._instance.setSubCategory((SubCategoryTO[])memberValue);
/*     */           return;
/*     */         case 36:
/* 452 */           this._instance.setTextPlans((TextPlanTO[])memberValue);
/*     */           return;
/*     */         case 37:
/* 455 */           this._instance.setUrbanization((UrbanizationTO[])memberValue);
/*     */           return;
/*     */         case 38:
/* 458 */           this._instance.setZone((ZoneTO[])memberValue);
/*     */           return;
/*     */       } 
/* 461 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 464 */     catch (RuntimeException e) {
/* 465 */       throw e;
/*     */     }
/* 467 */     catch (Exception e) {
/* 468 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 476 */     this._instance = (MasterDataResponseTO_v2)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 480 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\runtime\MasterDataResponseTO_v2_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */