/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatePlanRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidatePlanRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String[] entrada;
/*     */   private String planCode;
/*     */   private String planCosName;
/*     */   private String ssn;
/*     */   private long subscriberId;
/*     */   private String transactionType;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myentrada_INDEX = 5;
/*     */   private static final int myplanCode_INDEX = 6;
/*     */   private static final int myplanCosName_INDEX = 7;
/*     */   private static final int myssn_INDEX = 8;
/*     */   private static final int mysubscriberId_INDEX = 9;
/*     */   private static final int mytransactionType_INDEX = 10;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  41 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  45 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  49 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  53 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  57 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setEntrada(String[] entrada) {
/*  61 */     this.entrada = entrada;
/*     */   }
/*     */   
/*     */   public void setPlanCode(String planCode) {
/*  65 */     this.planCode = planCode;
/*     */   }
/*     */   
/*     */   public void setPlanCosName(String planCosName) {
/*  69 */     this.planCosName = planCosName;
/*     */   }
/*     */   
/*     */   public void setSsn(String ssn) {
/*  73 */     this.ssn = ssn;
/*     */   }
/*     */   
/*     */   public void setSubscriberId(long subscriberId) {
/*  77 */     this.subscriberId = subscriberId;
/*     */   }
/*     */   
/*     */   public void setTransactionType(String transactionType) {
/*  81 */     this.transactionType = transactionType;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  85 */     switch (memberIndex) {
/*     */       case 0:
/*  87 */         return 6;
/*     */       case 1:
/*  89 */         return 6;
/*     */       case 2:
/*  91 */         return 6;
/*     */       case 3:
/*  93 */         return 6;
/*     */       case 4:
/*  95 */         return 6;
/*     */       case 5:
/*  97 */         return 6;
/*     */       case 6:
/*  99 */         return 6;
/*     */       case 7:
/* 101 */         return 6;
/*     */       case 8:
/* 103 */         return 6;
/*     */       case 9:
/* 105 */         return 6;
/*     */       case 10:
/* 107 */         return 6;
/*     */     } 
/* 109 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 118 */       switch (index) {
/*     */         case 0:
/* 120 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/* 123 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/* 126 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 129 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 132 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 135 */           this._instance.setEntrada((String[])memberValue);
/*     */           return;
/*     */         case 6:
/* 138 */           this._instance.setPlanCode((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 141 */           this._instance.setPlanCosName((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 144 */           this._instance.setSsn((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 147 */           this._instance.setSubscriberId(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 10:
/* 150 */           this._instance.setTransactionType((String)memberValue);
/*     */           return;
/*     */       } 
/* 153 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 156 */     catch (RuntimeException e) {
/* 157 */       throw e;
/*     */     }
/* 159 */     catch (Exception e) {
/* 160 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 168 */     this._instance = (ValidatePlanRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 172 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\ValidatePlanRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */