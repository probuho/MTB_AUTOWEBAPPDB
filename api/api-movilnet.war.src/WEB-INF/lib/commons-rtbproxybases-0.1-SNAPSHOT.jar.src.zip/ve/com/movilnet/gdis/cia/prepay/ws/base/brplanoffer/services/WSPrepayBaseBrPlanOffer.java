package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface WSPrepayBaseBrPlanOffer extends Service {
  IWSPrepayBaseBrPlanOffer getPlanoffer() throws ServiceException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\WSPrepayBaseBrPlanOffer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */