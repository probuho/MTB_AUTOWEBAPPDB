/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidateServicesModelRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidateServicesModelRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_alcoName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcoName");
/*  33 */   private static final QName ns2_serial_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serial");
/*  34 */   private static final QName ns2_serviceCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceCode");
/*  35 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myalcoName_INDEX = 5;
/*     */   private static final int myserial_INDEX = 6;
/*     */   private static final int myserviceCode_INDEX = 7;
/*     */   private static final int mytransactionType_INDEX = 8;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ValidateServicesModelRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  47 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  51 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidateServicesModelRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  52 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidateServicesModelRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  53 */     if (class$java$lang$String == null); ((ValidateServicesModelRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  54 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  59 */     ValidateServicesModelRequestTO instance = new ValidateServicesModelRequestTO();
/*  60 */     ValidateServicesModelRequestTO_SOAPBuilder builder = null;
/*     */     
/*  62 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  65 */     reader.nextElementContent();
/*  66 */     QName startName = reader.getName();
/*  67 */     for (int i = 0; i < 9; i++) {
/*  68 */       QName elementName = reader.getName();
/*  69 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  72 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  73 */         context.setNillable(true);
/*  74 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  75 */         if (member instanceof SOAPDeserializationState) {
/*  76 */           if (builder == null) {
/*  77 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/*  79 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  80 */           isComplete = false;
/*  81 */         } else if (member != null) {
/*  82 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  84 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  87 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  88 */         context.setNillable(true);
/*  89 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  90 */         if (object instanceof SOAPDeserializationState) {
/*  91 */           if (builder == null) {
/*  92 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/*  94 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  95 */           isComplete = false;
/*  96 */         } else if (object != null) {
/*  97 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/*  99 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 102 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 103 */         context.setNillable(true);
/* 104 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 105 */         if (object instanceof SOAPDeserializationState) {
/* 106 */           if (builder == null) {
/* 107 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/* 109 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 110 */           isComplete = false;
/* 111 */         } else if (object != null) {
/* 112 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 114 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 117 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 118 */         context.setNillable(true);
/* 119 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 120 */         if (object instanceof SOAPDeserializationState) {
/* 121 */           if (builder == null) {
/* 122 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/* 124 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 125 */           isComplete = false;
/* 126 */         } else if (object != null) {
/* 127 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 129 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 132 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 133 */         context.setNillable(true);
/* 134 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 135 */         if (object instanceof SOAPDeserializationState) {
/* 136 */           if (builder == null) {
/* 137 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/* 139 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 140 */           isComplete = false;
/* 141 */         } else if (object != null) {
/* 142 */           instance.setTransactionId((String)object);
/*     */         } 
/* 144 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 147 */       else if (matchQName(elementName, ns2_alcoName_QNAME)) {
/* 148 */         context.setNillable(true);
/* 149 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_alcoName_QNAME, reader, context);
/* 150 */         if (object instanceof SOAPDeserializationState) {
/* 151 */           if (builder == null) {
/* 152 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/* 154 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 155 */           isComplete = false;
/* 156 */         } else if (object != null) {
/* 157 */           instance.setAlcoName((String)object);
/*     */         } 
/* 159 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 162 */       else if (matchQName(elementName, ns2_serial_QNAME)) {
/* 163 */         context.setNillable(true);
/* 164 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serial_QNAME, reader, context);
/* 165 */         if (object instanceof SOAPDeserializationState) {
/* 166 */           if (builder == null) {
/* 167 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/* 169 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 170 */           isComplete = false;
/* 171 */         } else if (object != null) {
/* 172 */           instance.setSerial((String)object);
/*     */         } 
/* 174 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 177 */       else if (matchQName(elementName, ns2_serviceCode_QNAME)) {
/* 178 */         context.setNillable(true);
/* 179 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceCode_QNAME, reader, context);
/* 180 */         if (object instanceof SOAPDeserializationState) {
/* 181 */           if (builder == null) {
/* 182 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/* 184 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 185 */           isComplete = false;
/* 186 */         } else if (object != null) {
/* 187 */           instance.setServiceCode((String)object);
/*     */         } 
/* 189 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 192 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 193 */         context.setNillable(true);
/* 194 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 195 */         if (object instanceof SOAPDeserializationState) {
/* 196 */           if (builder == null) {
/* 197 */             builder = new ValidateServicesModelRequestTO_SOAPBuilder();
/*     */           }
/* 199 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 200 */           isComplete = false;
/* 201 */         } else if (object != null) {
/* 202 */           instance.setTransactionType((String)object);
/*     */         } 
/* 204 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 207 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 212 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 213 */     } catch (XMLReaderException xmle) {
/* 214 */       if (startName != null) {
/* 215 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 217 */       throw xmle;
/*     */     } 
/*     */     
/* 220 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 224 */     ValidateServicesModelRequestTO instance = (ValidateServicesModelRequestTO)obj;
/*     */     
/* 226 */     context.setNillable(true);
/* 227 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 228 */     context.setNillable(true);
/* 229 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 230 */     context.setNillable(true);
/* 231 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 232 */     context.setNillable(true);
/* 233 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 234 */     context.setNillable(true);
/* 235 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 236 */     context.setNillable(true);
/* 237 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAlcoName(), ns2_alcoName_QNAME, null, writer, context);
/* 238 */     context.setNillable(true);
/* 239 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getSerial(), ns2_serial_QNAME, null, writer, context);
/* 240 */     context.setNillable(true);
/* 241 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceCode(), ns2_serviceCode_QNAME, null, writer, context);
/* 242 */     context.setNillable(true);
/* 243 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidateServicesModelRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */