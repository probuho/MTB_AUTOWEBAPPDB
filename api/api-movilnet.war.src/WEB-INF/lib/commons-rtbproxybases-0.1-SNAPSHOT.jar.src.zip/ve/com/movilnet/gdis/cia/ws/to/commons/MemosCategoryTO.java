/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemosCategoryTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String catMemoCode;
/*    */   protected String catMemoDesc;
/*    */   
/*    */   public String getCatMemoCode() {
/* 18 */     return this.catMemoCode;
/*    */   }
/*    */   
/*    */   public void setCatMemoCode(String catMemoCode) {
/* 22 */     this.catMemoCode = catMemoCode;
/*    */   }
/*    */   
/*    */   public String getCatMemoDesc() {
/* 26 */     return this.catMemoDesc;
/*    */   }
/*    */   
/*    */   public void setCatMemoDesc(String catMemoDesc) {
/* 30 */     this.catMemoDesc = catMemoDesc;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\MemosCategoryTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */