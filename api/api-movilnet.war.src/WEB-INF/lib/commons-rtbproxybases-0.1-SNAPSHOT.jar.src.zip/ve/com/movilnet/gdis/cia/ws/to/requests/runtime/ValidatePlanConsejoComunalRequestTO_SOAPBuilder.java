/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanConsejoComunalRequestTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatePlanConsejoComunalRequestTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidatePlanConsejoComunalRequestTO _instance;
/*     */   private ApplicationClientTO applicationClient;
/*     */   private SecurityTO security;
/*     */   private String serviceProvider;
/*     */   private short technology;
/*     */   private String transactionId;
/*     */   private String ssn;
/*     */   private String transactionType;
/*     */   private static final int myapplicationClient_INDEX = 0;
/*     */   private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myssn_INDEX = 5;
/*     */   private static final int mytransactionType_INDEX = 6;
/*     */   
/*     */   public void setApplicationClient(ApplicationClientTO applicationClient) {
/*  33 */     this.applicationClient = applicationClient;
/*     */   }
/*     */   
/*     */   public void setSecurity(SecurityTO security) {
/*  37 */     this.security = security;
/*     */   }
/*     */   
/*     */   public void setServiceProvider(String serviceProvider) {
/*  41 */     this.serviceProvider = serviceProvider;
/*     */   }
/*     */   
/*     */   public void setTechnology(short technology) {
/*  45 */     this.technology = technology;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  49 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setSsn(String ssn) {
/*  53 */     this.ssn = ssn;
/*     */   }
/*     */   
/*     */   public void setTransactionType(String transactionType) {
/*  57 */     this.transactionType = transactionType;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  61 */     switch (memberIndex) {
/*     */       case 0:
/*  63 */         return 6;
/*     */       case 1:
/*  65 */         return 6;
/*     */       case 2:
/*  67 */         return 6;
/*     */       case 3:
/*  69 */         return 6;
/*     */       case 4:
/*  71 */         return 6;
/*     */       case 5:
/*  73 */         return 6;
/*     */       case 6:
/*  75 */         return 6;
/*     */     } 
/*  77 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/*  86 */       switch (index) {
/*     */         case 0:
/*  88 */           this._instance.setApplicationClient((ApplicationClientTO)memberValue);
/*     */           return;
/*     */         case 1:
/*  91 */           this._instance.setSecurity((SecurityTO)memberValue);
/*     */           return;
/*     */         case 2:
/*  94 */           this._instance.setServiceProvider((String)memberValue);
/*     */           return;
/*     */         case 3:
/*  97 */           this._instance.setTechnology(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 100 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 103 */           this._instance.setSsn((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 106 */           this._instance.setTransactionType((String)memberValue);
/*     */           return;
/*     */       } 
/* 109 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 112 */     catch (RuntimeException e) {
/* 113 */       throw e;
/*     */     }
/* 115 */     catch (Exception e) {
/* 116 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 124 */     this._instance = (ValidatePlanConsejoComunalRequestTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 128 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\runtime\ValidatePlanConsejoComunalRequestTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */