/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CityStructuredTO
/*    */   implements Serializable
/*    */ {
/*    */   protected int cityId;
/*    */   protected String cityName;
/*    */   protected String parroquiaCode;
/*    */   
/*    */   public int getCityId() {
/* 19 */     return this.cityId;
/*    */   }
/*    */   
/*    */   public void setCityId(int cityId) {
/* 23 */     this.cityId = cityId;
/*    */   }
/*    */   
/*    */   public String getCityName() {
/* 27 */     return this.cityName;
/*    */   }
/*    */   
/*    */   public void setCityName(String cityName) {
/* 31 */     this.cityName = cityName;
/*    */   }
/*    */   
/*    */   public String getParroquiaCode() {
/* 35 */     return this.parroquiaCode;
/*    */   }
/*    */   
/*    */   public void setParroquiaCode(String parroquiaCode) {
/* 39 */     this.parroquiaCode = parroquiaCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\CityStructuredTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */