/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SectorTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.StateTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO;
/*     */ 
/*     */ public class MasterDataResponseTO extends ResponseTO implements Serializable {
/*     */   protected AdjustmentReasonsTO[] adjustmentReasons;
/*     */   protected BalanceListTO[] balanceList;
/*     */   protected ChargeCodeTO[] chargeCodes;
/*     */   protected CityTO[] city;
/*     */   protected CommunalCouncilChargeTO[] communalCouncilCharges;
/*     */   protected CoolingReasonTO[] coolingReason;
/*     */   protected IVRPlanBenefitTO[] ivrPlanBenefits;
/*     */   protected IVRPlanTO[] ivrPlans;
/*     */   protected LocalityTO[] locality;
/*     */   protected MemosCategoryTO[] memosCategory;
/*     */   protected PhoneModelTO[] modelsPhones;
/*     */   protected MunicipalitieTO[] municipalitie;
/*     */   protected NationalitiesTO[] nationalities;
/*     */   protected ParisheTO[] parishe;
/*     */   
/*     */   public AdjustmentReasonsTO[] getAdjustmentReasons() {
/*  44 */     return this.adjustmentReasons;
/*     */   }
/*     */   protected PlanTO[] plans; protected ProfessionTO[] profession; protected PromotionTO[] promotions; protected SectorTO[] sector; protected SellingAgentTO[] sellingAgent; protected ServiceTO[] services; protected StateTO[] state; protected CityStructuredTO[] structuredCities; protected StateTO[] structuredStates; protected ZoneStructuredTO[] structuredZones; protected SubCategoryTO[] subCategory; protected TextPlanTO[] textPlans; protected UrbanizationTO[] urbanization; protected ZoneTO[] zone;
/*     */   public void setAdjustmentReasons(AdjustmentReasonsTO[] adjustmentReasons) {
/*  48 */     this.adjustmentReasons = adjustmentReasons;
/*     */   }
/*     */   
/*     */   public BalanceListTO[] getBalanceList() {
/*  52 */     return this.balanceList;
/*     */   }
/*     */   
/*     */   public void setBalanceList(BalanceListTO[] balanceList) {
/*  56 */     this.balanceList = balanceList;
/*     */   }
/*     */   
/*     */   public ChargeCodeTO[] getChargeCodes() {
/*  60 */     return this.chargeCodes;
/*     */   }
/*     */   
/*     */   public void setChargeCodes(ChargeCodeTO[] chargeCodes) {
/*  64 */     this.chargeCodes = chargeCodes;
/*     */   }
/*     */   
/*     */   public CityTO[] getCity() {
/*  68 */     return this.city;
/*     */   }
/*     */   
/*     */   public void setCity(CityTO[] city) {
/*  72 */     this.city = city;
/*     */   }
/*     */   
/*     */   public CommunalCouncilChargeTO[] getCommunalCouncilCharges() {
/*  76 */     return this.communalCouncilCharges;
/*     */   }
/*     */   
/*     */   public void setCommunalCouncilCharges(CommunalCouncilChargeTO[] communalCouncilCharges) {
/*  80 */     this.communalCouncilCharges = communalCouncilCharges;
/*     */   }
/*     */   
/*     */   public CoolingReasonTO[] getCoolingReason() {
/*  84 */     return this.coolingReason;
/*     */   }
/*     */   
/*     */   public void setCoolingReason(CoolingReasonTO[] coolingReason) {
/*  88 */     this.coolingReason = coolingReason;
/*     */   }
/*     */   
/*     */   public IVRPlanBenefitTO[] getIvrPlanBenefits() {
/*  92 */     return this.ivrPlanBenefits;
/*     */   }
/*     */   
/*     */   public void setIvrPlanBenefits(IVRPlanBenefitTO[] ivrPlanBenefits) {
/*  96 */     this.ivrPlanBenefits = ivrPlanBenefits;
/*     */   }
/*     */   
/*     */   public IVRPlanTO[] getIvrPlans() {
/* 100 */     return this.ivrPlans;
/*     */   }
/*     */   
/*     */   public void setIvrPlans(IVRPlanTO[] ivrPlans) {
/* 104 */     this.ivrPlans = ivrPlans;
/*     */   }
/*     */   
/*     */   public LocalityTO[] getLocality() {
/* 108 */     return this.locality;
/*     */   }
/*     */   
/*     */   public void setLocality(LocalityTO[] locality) {
/* 112 */     this.locality = locality;
/*     */   }
/*     */   
/*     */   public MemosCategoryTO[] getMemosCategory() {
/* 116 */     return this.memosCategory;
/*     */   }
/*     */   
/*     */   public void setMemosCategory(MemosCategoryTO[] memosCategory) {
/* 120 */     this.memosCategory = memosCategory;
/*     */   }
/*     */   
/*     */   public PhoneModelTO[] getModelsPhones() {
/* 124 */     return this.modelsPhones;
/*     */   }
/*     */   
/*     */   public void setModelsPhones(PhoneModelTO[] modelsPhones) {
/* 128 */     this.modelsPhones = modelsPhones;
/*     */   }
/*     */   
/*     */   public MunicipalitieTO[] getMunicipalitie() {
/* 132 */     return this.municipalitie;
/*     */   }
/*     */   
/*     */   public void setMunicipalitie(MunicipalitieTO[] municipalitie) {
/* 136 */     this.municipalitie = municipalitie;
/*     */   }
/*     */   
/*     */   public NationalitiesTO[] getNationalities() {
/* 140 */     return this.nationalities;
/*     */   }
/*     */   
/*     */   public void setNationalities(NationalitiesTO[] nationalities) {
/* 144 */     this.nationalities = nationalities;
/*     */   }
/*     */   
/*     */   public ParisheTO[] getParishe() {
/* 148 */     return this.parishe;
/*     */   }
/*     */   
/*     */   public void setParishe(ParisheTO[] parishe) {
/* 152 */     this.parishe = parishe;
/*     */   }
/*     */   
/*     */   public PlanTO[] getPlans() {
/* 156 */     return this.plans;
/*     */   }
/*     */   
/*     */   public void setPlans(PlanTO[] plans) {
/* 160 */     this.plans = plans;
/*     */   }
/*     */   
/*     */   public ProfessionTO[] getProfession() {
/* 164 */     return this.profession;
/*     */   }
/*     */   
/*     */   public void setProfession(ProfessionTO[] profession) {
/* 168 */     this.profession = profession;
/*     */   }
/*     */   
/*     */   public PromotionTO[] getPromotions() {
/* 172 */     return this.promotions;
/*     */   }
/*     */   
/*     */   public void setPromotions(PromotionTO[] promotions) {
/* 176 */     this.promotions = promotions;
/*     */   }
/*     */   
/*     */   public SectorTO[] getSector() {
/* 180 */     return this.sector;
/*     */   }
/*     */   
/*     */   public void setSector(SectorTO[] sector) {
/* 184 */     this.sector = sector;
/*     */   }
/*     */   
/*     */   public SellingAgentTO[] getSellingAgent() {
/* 188 */     return this.sellingAgent;
/*     */   }
/*     */   
/*     */   public void setSellingAgent(SellingAgentTO[] sellingAgent) {
/* 192 */     this.sellingAgent = sellingAgent;
/*     */   }
/*     */   
/*     */   public ServiceTO[] getServices() {
/* 196 */     return this.services;
/*     */   }
/*     */   
/*     */   public void setServices(ServiceTO[] services) {
/* 200 */     this.services = services;
/*     */   }
/*     */   
/*     */   public StateTO[] getState() {
/* 204 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setState(StateTO[] state) {
/* 208 */     this.state = state;
/*     */   }
/*     */   
/*     */   public CityStructuredTO[] getStructuredCities() {
/* 212 */     return this.structuredCities;
/*     */   }
/*     */   
/*     */   public void setStructuredCities(CityStructuredTO[] structuredCities) {
/* 216 */     this.structuredCities = structuredCities;
/*     */   }
/*     */   
/*     */   public StateTO[] getStructuredStates() {
/* 220 */     return this.structuredStates;
/*     */   }
/*     */   
/*     */   public void setStructuredStates(StateTO[] structuredStates) {
/* 224 */     this.structuredStates = structuredStates;
/*     */   }
/*     */   
/*     */   public ZoneStructuredTO[] getStructuredZones() {
/* 228 */     return this.structuredZones;
/*     */   }
/*     */   
/*     */   public void setStructuredZones(ZoneStructuredTO[] structuredZones) {
/* 232 */     this.structuredZones = structuredZones;
/*     */   }
/*     */   
/*     */   public SubCategoryTO[] getSubCategory() {
/* 236 */     return this.subCategory;
/*     */   }
/*     */   
/*     */   public void setSubCategory(SubCategoryTO[] subCategory) {
/* 240 */     this.subCategory = subCategory;
/*     */   }
/*     */   
/*     */   public TextPlanTO[] getTextPlans() {
/* 244 */     return this.textPlans;
/*     */   }
/*     */   
/*     */   public void setTextPlans(TextPlanTO[] textPlans) {
/* 248 */     this.textPlans = textPlans;
/*     */   }
/*     */   
/*     */   public UrbanizationTO[] getUrbanization() {
/* 252 */     return this.urbanization;
/*     */   }
/*     */   
/*     */   public void setUrbanization(UrbanizationTO[] urbanization) {
/* 256 */     this.urbanization = urbanization;
/*     */   }
/*     */   
/*     */   public ZoneTO[] getZone() {
/* 260 */     return this.zone;
/*     */   }
/*     */   
/*     */   public void setZone(ZoneTO[] zone) {
/* 264 */     this.zone = zone;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\MasterDataResponseTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */