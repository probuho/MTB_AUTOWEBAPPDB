package ve.com.movilnet.gdis.cia.ws.base.masterdata.services;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface WSBaseMasterData extends Service {
  IWSBaseMasterData getMasterdata() throws ServiceException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\WSBaseMasterData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */