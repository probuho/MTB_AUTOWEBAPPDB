/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceTO_v3
/*     */   implements Serializable
/*     */ {
/*     */   protected String alcoServicio;
/*     */   protected String codServicio;
/*     */   protected String descServicio;
/*     */   protected String[] genericFields;
/*     */   protected String group;
/*     */   protected short maxCcNumber;
/*     */   protected short minCcNumber;
/*     */   protected String ovsaCommand;
/*     */   protected String ovsaLabel;
/*     */   protected String periodicChargeInd;
/*     */   protected String periodicChargeName;
/*     */   protected double precio;
/*     */   protected String provisioningInd;
/*     */   protected String subGroup;
/*     */   protected String subType;
/*     */   protected String type;
/*     */   
/*     */   public String getAlcoServicio() {
/*  32 */     return this.alcoServicio;
/*     */   }
/*     */   
/*     */   public void setAlcoServicio(String alcoServicio) {
/*  36 */     this.alcoServicio = alcoServicio;
/*     */   }
/*     */   
/*     */   public String getCodServicio() {
/*  40 */     return this.codServicio;
/*     */   }
/*     */   
/*     */   public void setCodServicio(String codServicio) {
/*  44 */     this.codServicio = codServicio;
/*     */   }
/*     */   
/*     */   public String getDescServicio() {
/*  48 */     return this.descServicio;
/*     */   }
/*     */   
/*     */   public void setDescServicio(String descServicio) {
/*  52 */     this.descServicio = descServicio;
/*     */   }
/*     */   
/*     */   public String[] getGenericFields() {
/*  56 */     return this.genericFields;
/*     */   }
/*     */   
/*     */   public void setGenericFields(String[] genericFields) {
/*  60 */     this.genericFields = genericFields;
/*     */   }
/*     */   
/*     */   public String getGroup() {
/*  64 */     return this.group;
/*     */   }
/*     */   
/*     */   public void setGroup(String group) {
/*  68 */     this.group = group;
/*     */   }
/*     */   
/*     */   public short getMaxCcNumber() {
/*  72 */     return this.maxCcNumber;
/*     */   }
/*     */   
/*     */   public void setMaxCcNumber(short maxCcNumber) {
/*  76 */     this.maxCcNumber = maxCcNumber;
/*     */   }
/*     */   
/*     */   public short getMinCcNumber() {
/*  80 */     return this.minCcNumber;
/*     */   }
/*     */   
/*     */   public void setMinCcNumber(short minCcNumber) {
/*  84 */     this.minCcNumber = minCcNumber;
/*     */   }
/*     */   
/*     */   public String getOvsaCommand() {
/*  88 */     return this.ovsaCommand;
/*     */   }
/*     */   
/*     */   public void setOvsaCommand(String ovsaCommand) {
/*  92 */     this.ovsaCommand = ovsaCommand;
/*     */   }
/*     */   
/*     */   public String getOvsaLabel() {
/*  96 */     return this.ovsaLabel;
/*     */   }
/*     */   
/*     */   public void setOvsaLabel(String ovsaLabel) {
/* 100 */     this.ovsaLabel = ovsaLabel;
/*     */   }
/*     */   
/*     */   public String getPeriodicChargeInd() {
/* 104 */     return this.periodicChargeInd;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeInd(String periodicChargeInd) {
/* 108 */     this.periodicChargeInd = periodicChargeInd;
/*     */   }
/*     */   
/*     */   public String getPeriodicChargeName() {
/* 112 */     return this.periodicChargeName;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeName(String periodicChargeName) {
/* 116 */     this.periodicChargeName = periodicChargeName;
/*     */   }
/*     */   
/*     */   public double getPrecio() {
/* 120 */     return this.precio;
/*     */   }
/*     */   
/*     */   public void setPrecio(double precio) {
/* 124 */     this.precio = precio;
/*     */   }
/*     */   
/*     */   public String getProvisioningInd() {
/* 128 */     return this.provisioningInd;
/*     */   }
/*     */   
/*     */   public void setProvisioningInd(String provisioningInd) {
/* 132 */     this.provisioningInd = provisioningInd;
/*     */   }
/*     */   
/*     */   public String getSubGroup() {
/* 136 */     return this.subGroup;
/*     */   }
/*     */   
/*     */   public void setSubGroup(String subGroup) {
/* 140 */     this.subGroup = subGroup;
/*     */   }
/*     */   
/*     */   public String getSubType() {
/* 144 */     return this.subType;
/*     */   }
/*     */   
/*     */   public void setSubType(String subType) {
/* 148 */     this.subType = subType;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 152 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(String type) {
/* 156 */     this.type = type;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ServiceTO_v3.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */