/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.ResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.runtime.ResponseTO_SOAPBuilder;
/*     */ 
/*     */ public class ResponseTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_executionTime_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "executionTime");
/*  20 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  22 */   private static final QName ns2_origin_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "origin");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  25 */   private static final QName ns2_responseCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseCode");
/*  26 */   private static final QName ns2_responseDescription_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseDescription");
/*  27 */   private static final QName ns2_responseMessage_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseMessage");
/*  28 */   private static final QName ns2_responseSubCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseSubCode");
/*  29 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId"); private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ResponseTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  39 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  43 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*  44 */     if (class$java$lang$String == null); ((ResponseTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  49 */     ResponseTO instance = new ResponseTO();
/*  50 */     ResponseTO_SOAPBuilder builder = null;
/*     */     
/*  52 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  55 */     reader.nextElementContent();
/*  56 */     QName startName = reader.getName();
/*  57 */     for (int i = 0; i < 7; i++) {
/*  58 */       QName elementName = reader.getName();
/*  59 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  62 */       if (matchQName(elementName, ns2_executionTime_QNAME)) {
/*  63 */         context.setNillable(true);
/*  64 */         Object member = this.myns3__long__long_Long_Serializer.deserialize(ns2_executionTime_QNAME, reader, context);
/*  65 */         if (member instanceof SOAPDeserializationState) {
/*  66 */           if (builder == null) {
/*  67 */             builder = new ResponseTO_SOAPBuilder();
/*     */           }
/*  69 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  70 */           isComplete = false;
/*  71 */         } else if (member != null) {
/*  72 */           instance.setExecutionTime(((Long)member).longValue());
/*     */         } 
/*  74 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  77 */       else if (matchQName(elementName, ns2_origin_QNAME)) {
/*  78 */         context.setNillable(true);
/*  79 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_origin_QNAME, reader, context);
/*  80 */         if (object instanceof SOAPDeserializationState) {
/*  81 */           if (builder == null) {
/*  82 */             builder = new ResponseTO_SOAPBuilder();
/*     */           }
/*  84 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  85 */           isComplete = false;
/*  86 */         } else if (object != null) {
/*  87 */           instance.setOrigin((String)object);
/*     */         } 
/*  89 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  92 */       else if (matchQName(elementName, ns2_responseCode_QNAME)) {
/*  93 */         context.setNillable(true);
/*  94 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseCode_QNAME, reader, context);
/*  95 */         if (object instanceof SOAPDeserializationState) {
/*  96 */           if (builder == null) {
/*  97 */             builder = new ResponseTO_SOAPBuilder();
/*     */           }
/*  99 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 100 */           isComplete = false;
/* 101 */         } else if (object != null) {
/* 102 */           instance.setResponseCode((String)object);
/*     */         } 
/* 104 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 107 */       else if (matchQName(elementName, ns2_responseDescription_QNAME)) {
/* 108 */         context.setNillable(true);
/* 109 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseDescription_QNAME, reader, context);
/* 110 */         if (object instanceof SOAPDeserializationState) {
/* 111 */           if (builder == null) {
/* 112 */             builder = new ResponseTO_SOAPBuilder();
/*     */           }
/* 114 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 115 */           isComplete = false;
/* 116 */         } else if (object != null) {
/* 117 */           instance.setResponseDescription((String)object);
/*     */         } 
/* 119 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 122 */       else if (matchQName(elementName, ns2_responseMessage_QNAME)) {
/* 123 */         context.setNillable(true);
/* 124 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseMessage_QNAME, reader, context);
/* 125 */         if (object instanceof SOAPDeserializationState) {
/* 126 */           if (builder == null) {
/* 127 */             builder = new ResponseTO_SOAPBuilder();
/*     */           }
/* 129 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 130 */           isComplete = false;
/* 131 */         } else if (object != null) {
/* 132 */           instance.setResponseMessage((String)object);
/*     */         } 
/* 134 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 137 */       else if (matchQName(elementName, ns2_responseSubCode_QNAME)) {
/* 138 */         context.setNillable(true);
/* 139 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseSubCode_QNAME, reader, context);
/* 140 */         if (object instanceof SOAPDeserializationState) {
/* 141 */           if (builder == null) {
/* 142 */             builder = new ResponseTO_SOAPBuilder();
/*     */           }
/* 144 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 145 */           isComplete = false;
/* 146 */         } else if (object != null) {
/* 147 */           instance.setResponseSubCode((String)object);
/*     */         } 
/* 149 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 152 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 153 */         context.setNillable(true);
/* 154 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 155 */         if (object instanceof SOAPDeserializationState) {
/* 156 */           if (builder == null) {
/* 157 */             builder = new ResponseTO_SOAPBuilder();
/*     */           }
/* 159 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 160 */           isComplete = false;
/* 161 */         } else if (object != null) {
/* 162 */           instance.setTransactionId((String)object);
/*     */         } 
/* 164 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 167 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionId_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 172 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 173 */     } catch (XMLReaderException xmle) {
/* 174 */       if (startName != null) {
/* 175 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 177 */       throw xmle;
/*     */     } 
/*     */     
/* 180 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 184 */     ResponseTO instance = (ResponseTO)obj;
/*     */     
/* 186 */     context.setNillable(true);
/* 187 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getExecutionTime()), ns2_executionTime_QNAME, null, writer, context);
/* 188 */     context.setNillable(true);
/* 189 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOrigin(), ns2_origin_QNAME, null, writer, context);
/* 190 */     context.setNillable(true);
/* 191 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseCode(), ns2_responseCode_QNAME, null, writer, context);
/* 192 */     context.setNillable(true);
/* 193 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseDescription(), ns2_responseDescription_QNAME, null, writer, context);
/* 194 */     context.setNillable(true);
/* 195 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseMessage(), ns2_responseMessage_QNAME, null, writer, context);
/* 196 */     context.setNillable(true);
/* 197 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseSubCode(), ns2_responseSubCode_QNAME, null, writer, context);
/* 198 */     context.setNillable(true);
/* 199 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\wsprepaybasebrplanoffer\ResponseTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */