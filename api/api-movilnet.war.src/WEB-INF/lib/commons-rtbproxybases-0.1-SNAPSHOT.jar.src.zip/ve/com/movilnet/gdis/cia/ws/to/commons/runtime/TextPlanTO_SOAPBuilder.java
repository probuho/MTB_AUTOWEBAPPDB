/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextPlanTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private TextPlanTO _instance;
/*    */   private String planCode;
/*    */   private String planTextoDesc;
/*    */   private String suffixAlcoCode;
/*    */   private static final int myplanCode_INDEX = 0;
/*    */   private static final int myplanTextoDesc_INDEX = 1;
/*    */   private static final int mysuffixAlcoCode_INDEX = 2;
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 25 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public void setPlanTextoDesc(String planTextoDesc) {
/* 29 */     this.planTextoDesc = planTextoDesc;
/*    */   }
/*    */   
/*    */   public void setSuffixAlcoCode(String suffixAlcoCode) {
/* 33 */     this.suffixAlcoCode = suffixAlcoCode;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 37 */     switch (memberIndex) {
/*    */       case 0:
/* 39 */         return 6;
/*    */       case 1:
/* 41 */         return 6;
/*    */       case 2:
/* 43 */         return 6;
/*    */     } 
/* 45 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 54 */       switch (index) {
/*    */         case 0:
/* 56 */           this._instance.setPlanCode((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 59 */           this._instance.setPlanTextoDesc((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 62 */           this._instance.setSuffixAlcoCode((String)memberValue);
/*    */           return;
/*    */       } 
/* 65 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 68 */     catch (RuntimeException e) {
/* 69 */       throw e;
/*    */     }
/* 71 */     catch (Exception e) {
/* 72 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 80 */     this._instance = (TextPlanTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 84 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\TextPlanTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */