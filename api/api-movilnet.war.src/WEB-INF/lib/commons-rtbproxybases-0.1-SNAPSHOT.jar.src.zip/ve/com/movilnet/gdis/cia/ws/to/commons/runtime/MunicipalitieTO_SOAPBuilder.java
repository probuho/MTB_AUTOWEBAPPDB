/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MunicipalitieTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private MunicipalitieTO _instance;
/*    */   private String municipioCode;
/*    */   private String parroquiaName;
/*    */   private String stateCode;
/*    */   private static final int mymunicipioCode_INDEX = 0;
/*    */   private static final int myparroquiaName_INDEX = 1;
/*    */   private static final int mystateCode_INDEX = 2;
/*    */   
/*    */   public void setMunicipioCode(String municipioCode) {
/* 25 */     this.municipioCode = municipioCode;
/*    */   }
/*    */   
/*    */   public void setParroquiaName(String parroquiaName) {
/* 29 */     this.parroquiaName = parroquiaName;
/*    */   }
/*    */   
/*    */   public void setStateCode(String stateCode) {
/* 33 */     this.stateCode = stateCode;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 37 */     switch (memberIndex) {
/*    */       case 0:
/* 39 */         return 6;
/*    */       case 1:
/* 41 */         return 6;
/*    */       case 2:
/* 43 */         return 6;
/*    */     } 
/* 45 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 54 */       switch (index) {
/*    */         case 0:
/* 56 */           this._instance.setMunicipioCode((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 59 */           this._instance.setParroquiaName((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 62 */           this._instance.setStateCode((String)memberValue);
/*    */           return;
/*    */       } 
/* 65 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 68 */     catch (RuntimeException e) {
/* 69 */       throw e;
/*    */     }
/* 71 */     catch (Exception e) {
/* 72 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 80 */     this._instance = (MunicipalitieTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 84 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\MunicipalitieTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */