/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.runtime.MasterDataResponseTO_SOAPBuilder;
/*     */ 
/*     */ public class MasterDataResponseTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_executionTime_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "executionTime");
/*  20 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  22 */   private static final QName ns2_origin_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "origin");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  25 */   private static final QName ns2_responseCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseCode");
/*  26 */   private static final QName ns2_responseDescription_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseDescription");
/*  27 */   private static final QName ns2_responseMessage_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseMessage");
/*  28 */   private static final QName ns2_responseSubCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseSubCode");
/*  29 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  30 */   private static final QName ns2_adjustmentReasons_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "adjustmentReasons");
/*  31 */   private static final QName ns2_ArrayOfAdjustmentReasonsTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfAdjustmentReasonsTO");
/*     */   private CombinedSerializer myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1;
/*  33 */   private static final QName ns2_balanceList_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceList");
/*  34 */   private static final QName ns2_ArrayOfBalanceListTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfBalanceListTO");
/*     */   private CombinedSerializer myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1;
/*  36 */   private static final QName ns2_chargeCodes_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "chargeCodes");
/*  37 */   private static final QName ns2_ArrayOfChargeCodeTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfChargeCodeTO");
/*     */   private CombinedSerializer myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1;
/*  39 */   private static final QName ns2_city_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "city");
/*  40 */   private static final QName ns2_ArrayOfCityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCityTO");
/*     */   private CombinedSerializer myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1;
/*  42 */   private static final QName ns2_communalCouncilCharges_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "communalCouncilCharges");
/*  43 */   private static final QName ns2_ArrayOfCommunalCouncilChargeTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCommunalCouncilChargeTO");
/*     */   private CombinedSerializer myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1;
/*  45 */   private static final QName ns2_coolingReason_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "coolingReason");
/*  46 */   private static final QName ns2_ArrayOfCoolingReasonTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCoolingReasonTO");
/*     */   private CombinedSerializer myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1;
/*  48 */   private static final QName ns2_ivrPlanBenefits_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ivrPlanBenefits");
/*  49 */   private static final QName ns2_ArrayOfIVRPlanBenefitTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfIVRPlanBenefitTO");
/*     */   private CombinedSerializer myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1;
/*  51 */   private static final QName ns2_ivrPlans_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ivrPlans");
/*  52 */   private static final QName ns2_ArrayOfIVRPlanTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfIVRPlanTO");
/*     */   private CombinedSerializer myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1;
/*  54 */   private static final QName ns2_locality_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "locality");
/*  55 */   private static final QName ns2_ArrayOfLocalityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfLocalityTO");
/*     */   private CombinedSerializer myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1;
/*  57 */   private static final QName ns2_memosCategory_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "memosCategory");
/*  58 */   private static final QName ns2_ArrayOfMemosCategoryTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfMemosCategoryTO");
/*     */   private CombinedSerializer myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1;
/*  60 */   private static final QName ns2_modelsPhones_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "modelsPhones");
/*  61 */   private static final QName ns2_ArrayOfPhoneModelTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPhoneModelTO");
/*     */   private CombinedSerializer myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1;
/*  63 */   private static final QName ns2_municipalitie_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "municipalitie");
/*  64 */   private static final QName ns2_ArrayOfMunicipalitieTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfMunicipalitieTO");
/*     */   private CombinedSerializer myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1;
/*  66 */   private static final QName ns2_nationalities_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "nationalities");
/*  67 */   private static final QName ns2_ArrayOfNationalitiesTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfNationalitiesTO");
/*     */   private CombinedSerializer myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1;
/*  69 */   private static final QName ns2_parishe_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "parishe");
/*  70 */   private static final QName ns2_ArrayOfParisheTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfParisheTO");
/*     */   private CombinedSerializer myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1;
/*  72 */   private static final QName ns2_plans_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "plans");
/*  73 */   private static final QName ns2_ArrayOfPlanTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPlanTO");
/*     */   private CombinedSerializer myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1;
/*  75 */   private static final QName ns2_profession_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "profession");
/*  76 */   private static final QName ns2_ArrayOfProfessionTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfProfessionTO");
/*     */   private CombinedSerializer myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1;
/*  78 */   private static final QName ns2_promotions_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "promotions");
/*  79 */   private static final QName ns2_ArrayOfPromotionTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPromotionTO");
/*     */   private CombinedSerializer myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1;
/*  81 */   private static final QName ns2_sector_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "sector");
/*  82 */   private static final QName ns2_ArrayOfSectorTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSectorTO");
/*     */   private CombinedSerializer myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1;
/*  84 */   private static final QName ns2_sellingAgent_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "sellingAgent");
/*  85 */   private static final QName ns2_ArrayOfSellingAgentTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSellingAgentTO");
/*     */   private CombinedSerializer myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1;
/*  87 */   private static final QName ns2_services_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "services");
/*  88 */   private static final QName ns2_ArrayOfServiceTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfServiceTO");
/*     */   private CombinedSerializer myns2_ArrayOfServiceTO__ServiceTOArray_LiteralSerializer1;
/*  90 */   private static final QName ns2_state_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "state");
/*  91 */   private static final QName ns2_ArrayOfStateTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfStateTO");
/*     */   private CombinedSerializer myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1;
/*  93 */   private static final QName ns2_structuredCities_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "structuredCities");
/*  94 */   private static final QName ns2_ArrayOfCityStructuredTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCityStructuredTO");
/*     */   private CombinedSerializer myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1;
/*  96 */   private static final QName ns2_structuredStates_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "structuredStates");
/*  97 */   private static final QName ns2_structuredZones_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "structuredZones");
/*  98 */   private static final QName ns2_ArrayOfZoneStructuredTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfZoneStructuredTO");
/*     */   private CombinedSerializer myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1;
/* 100 */   private static final QName ns2_subCategory_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subCategory");
/* 101 */   private static final QName ns2_ArrayOfSubCategoryTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSubCategoryTO");
/*     */   private CombinedSerializer myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1;
/* 103 */   private static final QName ns2_textPlans_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "textPlans");
/* 104 */   private static final QName ns2_ArrayOfTextPlanTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfTextPlanTO");
/*     */   private CombinedSerializer myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1;
/* 106 */   private static final QName ns2_urbanization_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "urbanization");
/* 107 */   private static final QName ns2_ArrayOfUrbanizationTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfUrbanizationTO");
/*     */   private CombinedSerializer myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1;
/* 109 */   private static final QName ns2_zone_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "zone");
/* 110 */   private static final QName ns2_ArrayOfZoneTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfZoneTO"); private CombinedSerializer myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1; private static final int myexecutionTime_INDEX = 0; private static final int myorigin_INDEX = 1; private static final int myresponseCode_INDEX = 2; private static final int myresponseDescription_INDEX = 3; private static final int myresponseMessage_INDEX = 4; private static final int myresponseSubCode_INDEX = 5; private static final int mytransactionId_INDEX = 6; private static final int myadjustmentReasons_INDEX = 7; private static final int mybalanceList_INDEX = 8; private static final int mychargeCodes_INDEX = 9; private static final int mycity_INDEX = 10; private static final int mycommunalCouncilCharges_INDEX = 11; private static final int mycoolingReason_INDEX = 12; private static final int myivrPlanBenefits_INDEX = 13; private static final int myivrPlans_INDEX = 14; private static final int mylocality_INDEX = 15; private static final int mymemosCategory_INDEX = 16; private static final int mymodelsPhones_INDEX = 17; private static final int mymunicipalitie_INDEX = 18; private static final int mynationalities_INDEX = 19; private static final int myparishe_INDEX = 20; private static final int myplans_INDEX = 21; private static final int myprofession_INDEX = 22; private static final int mypromotions_INDEX = 23; private static final int mysector_INDEX = 24; private static final int mysellingAgent_INDEX = 25; private static final int myservices_INDEX = 26;
/*     */   private static final int mystate_INDEX = 27;
/*     */   private static final int mystructuredCities_INDEX = 28;
/*     */   private static final int mystructuredStates_INDEX = 29;
/*     */   private static final int mystructuredZones_INDEX = 30;
/*     */   private static final int mysubCategory_INDEX = 31;
/*     */   private static final int mytextPlans_INDEX = 32;
/*     */   private static final int myurbanization_INDEX = 33;
/*     */   private static final int myzone_INDEX = 34;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO;
/*     */   
/*     */   public MasterDataResponseTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/* 149 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 153 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/* 154 */     if (class$java$lang$String == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/* 155 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO;"), ns2_ArrayOfAdjustmentReasonsTO_TYPE_QNAME);
/* 156 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;"), ns2_ArrayOfBalanceListTO_TYPE_QNAME);
/* 157 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;"), ns2_ArrayOfChargeCodeTO_TYPE_QNAME);
/* 158 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CityTO;"), ns2_ArrayOfCityTO_TYPE_QNAME);
/* 159 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;"), ns2_ArrayOfCommunalCouncilChargeTO_TYPE_QNAME);
/* 160 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;"), ns2_ArrayOfCoolingReasonTO_TYPE_QNAME);
/* 161 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;"), ns2_ArrayOfIVRPlanBenefitTO_TYPE_QNAME);
/* 162 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;"), ns2_ArrayOfIVRPlanTO_TYPE_QNAME);
/* 163 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO;"), ns2_ArrayOfLocalityTO_TYPE_QNAME);
/* 164 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO;"), ns2_ArrayOfMemosCategoryTO_TYPE_QNAME);
/* 165 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO;"), ns2_ArrayOfPhoneModelTO_TYPE_QNAME);
/* 166 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;"), ns2_ArrayOfMunicipalitieTO_TYPE_QNAME);
/* 167 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.NationalitiesTO;"), ns2_ArrayOfNationalitiesTO_TYPE_QNAME);
/* 168 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;"), ns2_ArrayOfParisheTO_TYPE_QNAME);
/* 169 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;"), ns2_ArrayOfPlanTO_TYPE_QNAME);
/* 170 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ProfessionTO;"), ns2_ArrayOfProfessionTO_TYPE_QNAME);
/* 171 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO;"), ns2_ArrayOfPromotionTO_TYPE_QNAME);
/* 172 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SectorTO;"), ns2_ArrayOfSectorTO_TYPE_QNAME);
/* 173 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;"), ns2_ArrayOfSellingAgentTO_TYPE_QNAME);
/* 174 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfServiceTO__ServiceTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO;"), ns2_ArrayOfServiceTO_TYPE_QNAME);
/* 175 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.StateTO;"), ns2_ArrayOfStateTO_TYPE_QNAME);
/* 176 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;"), ns2_ArrayOfCityStructuredTO_TYPE_QNAME);
/* 177 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO;"), ns2_ArrayOfZoneStructuredTO_TYPE_QNAME);
/* 178 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;"), ns2_ArrayOfSubCategoryTO_TYPE_QNAME);
/* 179 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;"), ns2_ArrayOfTextPlanTO_TYPE_QNAME);
/* 180 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO;"), ns2_ArrayOfUrbanizationTO_TYPE_QNAME);
/* 181 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO == null); ((MasterDataResponseTO_SOAPSerializer)registry).myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO;"), ns2_ArrayOfZoneTO_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/* 186 */     MasterDataResponseTO instance = new MasterDataResponseTO();
/* 187 */     MasterDataResponseTO_SOAPBuilder builder = null;
/*     */     
/* 189 */     boolean isComplete = true;
/*     */ 
/*     */     
/* 192 */     reader.nextElementContent();
/* 193 */     QName startName = reader.getName();
/* 194 */     for (int i = 0; i < 35; i++) {
/* 195 */       QName elementName = reader.getName();
/* 196 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/* 199 */       if (matchQName(elementName, ns2_executionTime_QNAME)) {
/* 200 */         context.setNillable(true);
/* 201 */         Object member = this.myns3__long__long_Long_Serializer.deserialize(ns2_executionTime_QNAME, reader, context);
/* 202 */         if (member instanceof SOAPDeserializationState) {
/* 203 */           if (builder == null) {
/* 204 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 206 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/* 207 */           isComplete = false;
/* 208 */         } else if (member != null) {
/* 209 */           instance.setExecutionTime(((Long)member).longValue());
/*     */         } 
/* 211 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 214 */       else if (matchQName(elementName, ns2_origin_QNAME)) {
/* 215 */         context.setNillable(true);
/* 216 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_origin_QNAME, reader, context);
/* 217 */         if (object instanceof SOAPDeserializationState) {
/* 218 */           if (builder == null) {
/* 219 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 221 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 222 */           isComplete = false;
/* 223 */         } else if (object != null) {
/* 224 */           instance.setOrigin((String)object);
/*     */         } 
/* 226 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 229 */       else if (matchQName(elementName, ns2_responseCode_QNAME)) {
/* 230 */         context.setNillable(true);
/* 231 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseCode_QNAME, reader, context);
/* 232 */         if (object instanceof SOAPDeserializationState) {
/* 233 */           if (builder == null) {
/* 234 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 236 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 237 */           isComplete = false;
/* 238 */         } else if (object != null) {
/* 239 */           instance.setResponseCode((String)object);
/*     */         } 
/* 241 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 244 */       else if (matchQName(elementName, ns2_responseDescription_QNAME)) {
/* 245 */         context.setNillable(true);
/* 246 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseDescription_QNAME, reader, context);
/* 247 */         if (object instanceof SOAPDeserializationState) {
/* 248 */           if (builder == null) {
/* 249 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 251 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 252 */           isComplete = false;
/* 253 */         } else if (object != null) {
/* 254 */           instance.setResponseDescription((String)object);
/*     */         } 
/* 256 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 259 */       else if (matchQName(elementName, ns2_responseMessage_QNAME)) {
/* 260 */         context.setNillable(true);
/* 261 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseMessage_QNAME, reader, context);
/* 262 */         if (object instanceof SOAPDeserializationState) {
/* 263 */           if (builder == null) {
/* 264 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 266 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 267 */           isComplete = false;
/* 268 */         } else if (object != null) {
/* 269 */           instance.setResponseMessage((String)object);
/*     */         } 
/* 271 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 274 */       else if (matchQName(elementName, ns2_responseSubCode_QNAME)) {
/* 275 */         context.setNillable(true);
/* 276 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseSubCode_QNAME, reader, context);
/* 277 */         if (object instanceof SOAPDeserializationState) {
/* 278 */           if (builder == null) {
/* 279 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 281 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 282 */           isComplete = false;
/* 283 */         } else if (object != null) {
/* 284 */           instance.setResponseSubCode((String)object);
/*     */         } 
/* 286 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 289 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 290 */         context.setNillable(true);
/* 291 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 292 */         if (object instanceof SOAPDeserializationState) {
/* 293 */           if (builder == null) {
/* 294 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 296 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 297 */           isComplete = false;
/* 298 */         } else if (object != null) {
/* 299 */           instance.setTransactionId((String)object);
/*     */         } 
/* 301 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 304 */       else if (matchQName(elementName, ns2_adjustmentReasons_QNAME)) {
/* 305 */         context.setNillable(true);
/* 306 */         Object object = this.myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1.deserialize(ns2_adjustmentReasons_QNAME, reader, context);
/* 307 */         if (object instanceof SOAPDeserializationState) {
/* 308 */           if (builder == null) {
/* 309 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 311 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 312 */           isComplete = false;
/* 313 */         } else if (object != null) {
/* 314 */           instance.setAdjustmentReasons((AdjustmentReasonsTO[])object);
/*     */         } 
/* 316 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 319 */       else if (matchQName(elementName, ns2_balanceList_QNAME)) {
/* 320 */         context.setNillable(true);
/* 321 */         Object object = this.myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1.deserialize(ns2_balanceList_QNAME, reader, context);
/* 322 */         if (object instanceof SOAPDeserializationState) {
/* 323 */           if (builder == null) {
/* 324 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 326 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 327 */           isComplete = false;
/* 328 */         } else if (object != null) {
/* 329 */           instance.setBalanceList((BalanceListTO[])object);
/*     */         } 
/* 331 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 334 */       else if (matchQName(elementName, ns2_chargeCodes_QNAME)) {
/* 335 */         context.setNillable(true);
/* 336 */         Object object = this.myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1.deserialize(ns2_chargeCodes_QNAME, reader, context);
/* 337 */         if (object instanceof SOAPDeserializationState) {
/* 338 */           if (builder == null) {
/* 339 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 341 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 342 */           isComplete = false;
/* 343 */         } else if (object != null) {
/* 344 */           instance.setChargeCodes((ChargeCodeTO[])object);
/*     */         } 
/* 346 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 349 */       else if (matchQName(elementName, ns2_city_QNAME)) {
/* 350 */         context.setNillable(true);
/* 351 */         Object object = this.myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1.deserialize(ns2_city_QNAME, reader, context);
/* 352 */         if (object instanceof SOAPDeserializationState) {
/* 353 */           if (builder == null) {
/* 354 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 356 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 357 */           isComplete = false;
/* 358 */         } else if (object != null) {
/* 359 */           instance.setCity((CityTO[])object);
/*     */         } 
/* 361 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 364 */       else if (matchQName(elementName, ns2_communalCouncilCharges_QNAME)) {
/* 365 */         context.setNillable(true);
/* 366 */         Object object = this.myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1.deserialize(ns2_communalCouncilCharges_QNAME, reader, context);
/* 367 */         if (object instanceof SOAPDeserializationState) {
/* 368 */           if (builder == null) {
/* 369 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 371 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 372 */           isComplete = false;
/* 373 */         } else if (object != null) {
/* 374 */           instance.setCommunalCouncilCharges((CommunalCouncilChargeTO[])object);
/*     */         } 
/* 376 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 379 */       else if (matchQName(elementName, ns2_coolingReason_QNAME)) {
/* 380 */         context.setNillable(true);
/* 381 */         Object object = this.myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1.deserialize(ns2_coolingReason_QNAME, reader, context);
/* 382 */         if (object instanceof SOAPDeserializationState) {
/* 383 */           if (builder == null) {
/* 384 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 386 */           state = registerWithMemberState(instance, state, object, 12, (SOAPInstanceBuilder)builder);
/* 387 */           isComplete = false;
/* 388 */         } else if (object != null) {
/* 389 */           instance.setCoolingReason((CoolingReasonTO[])object);
/*     */         } 
/* 391 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 394 */       else if (matchQName(elementName, ns2_ivrPlanBenefits_QNAME)) {
/* 395 */         context.setNillable(true);
/* 396 */         Object object = this.myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1.deserialize(ns2_ivrPlanBenefits_QNAME, reader, context);
/* 397 */         if (object instanceof SOAPDeserializationState) {
/* 398 */           if (builder == null) {
/* 399 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 401 */           state = registerWithMemberState(instance, state, object, 13, (SOAPInstanceBuilder)builder);
/* 402 */           isComplete = false;
/* 403 */         } else if (object != null) {
/* 404 */           instance.setIvrPlanBenefits((IVRPlanBenefitTO[])object);
/*     */         } 
/* 406 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 409 */       else if (matchQName(elementName, ns2_ivrPlans_QNAME)) {
/* 410 */         context.setNillable(true);
/* 411 */         Object object = this.myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1.deserialize(ns2_ivrPlans_QNAME, reader, context);
/* 412 */         if (object instanceof SOAPDeserializationState) {
/* 413 */           if (builder == null) {
/* 414 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 416 */           state = registerWithMemberState(instance, state, object, 14, (SOAPInstanceBuilder)builder);
/* 417 */           isComplete = false;
/* 418 */         } else if (object != null) {
/* 419 */           instance.setIvrPlans((IVRPlanTO[])object);
/*     */         } 
/* 421 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 424 */       else if (matchQName(elementName, ns2_locality_QNAME)) {
/* 425 */         context.setNillable(true);
/* 426 */         Object object = this.myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1.deserialize(ns2_locality_QNAME, reader, context);
/* 427 */         if (object instanceof SOAPDeserializationState) {
/* 428 */           if (builder == null) {
/* 429 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 431 */           state = registerWithMemberState(instance, state, object, 15, (SOAPInstanceBuilder)builder);
/* 432 */           isComplete = false;
/* 433 */         } else if (object != null) {
/* 434 */           instance.setLocality((LocalityTO[])object);
/*     */         } 
/* 436 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 439 */       else if (matchQName(elementName, ns2_memosCategory_QNAME)) {
/* 440 */         context.setNillable(true);
/* 441 */         Object object = this.myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1.deserialize(ns2_memosCategory_QNAME, reader, context);
/* 442 */         if (object instanceof SOAPDeserializationState) {
/* 443 */           if (builder == null) {
/* 444 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 446 */           state = registerWithMemberState(instance, state, object, 16, (SOAPInstanceBuilder)builder);
/* 447 */           isComplete = false;
/* 448 */         } else if (object != null) {
/* 449 */           instance.setMemosCategory((MemosCategoryTO[])object);
/*     */         } 
/* 451 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 454 */       else if (matchQName(elementName, ns2_modelsPhones_QNAME)) {
/* 455 */         context.setNillable(true);
/* 456 */         Object object = this.myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1.deserialize(ns2_modelsPhones_QNAME, reader, context);
/* 457 */         if (object instanceof SOAPDeserializationState) {
/* 458 */           if (builder == null) {
/* 459 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 461 */           state = registerWithMemberState(instance, state, object, 17, (SOAPInstanceBuilder)builder);
/* 462 */           isComplete = false;
/* 463 */         } else if (object != null) {
/* 464 */           instance.setModelsPhones((PhoneModelTO[])object);
/*     */         } 
/* 466 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 469 */       else if (matchQName(elementName, ns2_municipalitie_QNAME)) {
/* 470 */         context.setNillable(true);
/* 471 */         Object object = this.myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1.deserialize(ns2_municipalitie_QNAME, reader, context);
/* 472 */         if (object instanceof SOAPDeserializationState) {
/* 473 */           if (builder == null) {
/* 474 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 476 */           state = registerWithMemberState(instance, state, object, 18, (SOAPInstanceBuilder)builder);
/* 477 */           isComplete = false;
/* 478 */         } else if (object != null) {
/* 479 */           instance.setMunicipalitie((MunicipalitieTO[])object);
/*     */         } 
/* 481 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 484 */       else if (matchQName(elementName, ns2_nationalities_QNAME)) {
/* 485 */         context.setNillable(true);
/* 486 */         Object object = this.myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1.deserialize(ns2_nationalities_QNAME, reader, context);
/* 487 */         if (object instanceof SOAPDeserializationState) {
/* 488 */           if (builder == null) {
/* 489 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 491 */           state = registerWithMemberState(instance, state, object, 19, (SOAPInstanceBuilder)builder);
/* 492 */           isComplete = false;
/* 493 */         } else if (object != null) {
/* 494 */           instance.setNationalities((NationalitiesTO[])object);
/*     */         } 
/* 496 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 499 */       else if (matchQName(elementName, ns2_parishe_QNAME)) {
/* 500 */         context.setNillable(true);
/* 501 */         Object object = this.myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1.deserialize(ns2_parishe_QNAME, reader, context);
/* 502 */         if (object instanceof SOAPDeserializationState) {
/* 503 */           if (builder == null) {
/* 504 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 506 */           state = registerWithMemberState(instance, state, object, 20, (SOAPInstanceBuilder)builder);
/* 507 */           isComplete = false;
/* 508 */         } else if (object != null) {
/* 509 */           instance.setParishe((ParisheTO[])object);
/*     */         } 
/* 511 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 514 */       else if (matchQName(elementName, ns2_plans_QNAME)) {
/* 515 */         context.setNillable(true);
/* 516 */         Object object = this.myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1.deserialize(ns2_plans_QNAME, reader, context);
/* 517 */         if (object instanceof SOAPDeserializationState) {
/* 518 */           if (builder == null) {
/* 519 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 521 */           state = registerWithMemberState(instance, state, object, 21, (SOAPInstanceBuilder)builder);
/* 522 */           isComplete = false;
/* 523 */         } else if (object != null) {
/* 524 */           instance.setPlans((PlanTO[])object);
/*     */         } 
/* 526 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 529 */       else if (matchQName(elementName, ns2_profession_QNAME)) {
/* 530 */         context.setNillable(true);
/* 531 */         Object object = this.myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1.deserialize(ns2_profession_QNAME, reader, context);
/* 532 */         if (object instanceof SOAPDeserializationState) {
/* 533 */           if (builder == null) {
/* 534 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 536 */           state = registerWithMemberState(instance, state, object, 22, (SOAPInstanceBuilder)builder);
/* 537 */           isComplete = false;
/* 538 */         } else if (object != null) {
/* 539 */           instance.setProfession((ProfessionTO[])object);
/*     */         } 
/* 541 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 544 */       else if (matchQName(elementName, ns2_promotions_QNAME)) {
/* 545 */         context.setNillable(true);
/* 546 */         Object object = this.myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1.deserialize(ns2_promotions_QNAME, reader, context);
/* 547 */         if (object instanceof SOAPDeserializationState) {
/* 548 */           if (builder == null) {
/* 549 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 551 */           state = registerWithMemberState(instance, state, object, 23, (SOAPInstanceBuilder)builder);
/* 552 */           isComplete = false;
/* 553 */         } else if (object != null) {
/* 554 */           instance.setPromotions((PromotionTO[])object);
/*     */         } 
/* 556 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 559 */       else if (matchQName(elementName, ns2_sector_QNAME)) {
/* 560 */         context.setNillable(true);
/* 561 */         Object object = this.myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1.deserialize(ns2_sector_QNAME, reader, context);
/* 562 */         if (object instanceof SOAPDeserializationState) {
/* 563 */           if (builder == null) {
/* 564 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 566 */           state = registerWithMemberState(instance, state, object, 24, (SOAPInstanceBuilder)builder);
/* 567 */           isComplete = false;
/* 568 */         } else if (object != null) {
/* 569 */           instance.setSector((SectorTO[])object);
/*     */         } 
/* 571 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 574 */       else if (matchQName(elementName, ns2_sellingAgent_QNAME)) {
/* 575 */         context.setNillable(true);
/* 576 */         Object object = this.myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1.deserialize(ns2_sellingAgent_QNAME, reader, context);
/* 577 */         if (object instanceof SOAPDeserializationState) {
/* 578 */           if (builder == null) {
/* 579 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 581 */           state = registerWithMemberState(instance, state, object, 25, (SOAPInstanceBuilder)builder);
/* 582 */           isComplete = false;
/* 583 */         } else if (object != null) {
/* 584 */           instance.setSellingAgent((SellingAgentTO[])object);
/*     */         } 
/* 586 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 589 */       else if (matchQName(elementName, ns2_services_QNAME)) {
/* 590 */         context.setNillable(true);
/* 591 */         Object object = this.myns2_ArrayOfServiceTO__ServiceTOArray_LiteralSerializer1.deserialize(ns2_services_QNAME, reader, context);
/* 592 */         if (object instanceof SOAPDeserializationState) {
/* 593 */           if (builder == null) {
/* 594 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 596 */           state = registerWithMemberState(instance, state, object, 26, (SOAPInstanceBuilder)builder);
/* 597 */           isComplete = false;
/* 598 */         } else if (object != null) {
/* 599 */           instance.setServices((ServiceTO[])object);
/*     */         } 
/* 601 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 604 */       else if (matchQName(elementName, ns2_state_QNAME)) {
/* 605 */         context.setNillable(true);
/* 606 */         Object object = this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.deserialize(ns2_state_QNAME, reader, context);
/* 607 */         if (object instanceof SOAPDeserializationState) {
/* 608 */           if (builder == null) {
/* 609 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 611 */           state = registerWithMemberState(instance, state, object, 27, (SOAPInstanceBuilder)builder);
/* 612 */           isComplete = false;
/* 613 */         } else if (object != null) {
/* 614 */           instance.setState((StateTO[])object);
/*     */         } 
/* 616 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 619 */       else if (matchQName(elementName, ns2_structuredCities_QNAME)) {
/* 620 */         context.setNillable(true);
/* 621 */         Object object = this.myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1.deserialize(ns2_structuredCities_QNAME, reader, context);
/* 622 */         if (object instanceof SOAPDeserializationState) {
/* 623 */           if (builder == null) {
/* 624 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 626 */           state = registerWithMemberState(instance, state, object, 28, (SOAPInstanceBuilder)builder);
/* 627 */           isComplete = false;
/* 628 */         } else if (object != null) {
/* 629 */           instance.setStructuredCities((CityStructuredTO[])object);
/*     */         } 
/* 631 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 634 */       else if (matchQName(elementName, ns2_structuredStates_QNAME)) {
/* 635 */         context.setNillable(true);
/* 636 */         Object object = this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.deserialize(ns2_structuredStates_QNAME, reader, context);
/* 637 */         if (object instanceof SOAPDeserializationState) {
/* 638 */           if (builder == null) {
/* 639 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 641 */           state = registerWithMemberState(instance, state, object, 29, (SOAPInstanceBuilder)builder);
/* 642 */           isComplete = false;
/* 643 */         } else if (object != null) {
/* 644 */           instance.setStructuredStates((StateTO[])object);
/*     */         } 
/* 646 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 649 */       else if (matchQName(elementName, ns2_structuredZones_QNAME)) {
/* 650 */         context.setNillable(true);
/* 651 */         Object object = this.myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1.deserialize(ns2_structuredZones_QNAME, reader, context);
/* 652 */         if (object instanceof SOAPDeserializationState) {
/* 653 */           if (builder == null) {
/* 654 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 656 */           state = registerWithMemberState(instance, state, object, 30, (SOAPInstanceBuilder)builder);
/* 657 */           isComplete = false;
/* 658 */         } else if (object != null) {
/* 659 */           instance.setStructuredZones((ZoneStructuredTO[])object);
/*     */         } 
/* 661 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 664 */       else if (matchQName(elementName, ns2_subCategory_QNAME)) {
/* 665 */         context.setNillable(true);
/* 666 */         Object object = this.myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1.deserialize(ns2_subCategory_QNAME, reader, context);
/* 667 */         if (object instanceof SOAPDeserializationState) {
/* 668 */           if (builder == null) {
/* 669 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 671 */           state = registerWithMemberState(instance, state, object, 31, (SOAPInstanceBuilder)builder);
/* 672 */           isComplete = false;
/* 673 */         } else if (object != null) {
/* 674 */           instance.setSubCategory((SubCategoryTO[])object);
/*     */         } 
/* 676 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 679 */       else if (matchQName(elementName, ns2_textPlans_QNAME)) {
/* 680 */         context.setNillable(true);
/* 681 */         Object object = this.myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1.deserialize(ns2_textPlans_QNAME, reader, context);
/* 682 */         if (object instanceof SOAPDeserializationState) {
/* 683 */           if (builder == null) {
/* 684 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 686 */           state = registerWithMemberState(instance, state, object, 32, (SOAPInstanceBuilder)builder);
/* 687 */           isComplete = false;
/* 688 */         } else if (object != null) {
/* 689 */           instance.setTextPlans((TextPlanTO[])object);
/*     */         } 
/* 691 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 694 */       else if (matchQName(elementName, ns2_urbanization_QNAME)) {
/* 695 */         context.setNillable(true);
/* 696 */         Object object = this.myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1.deserialize(ns2_urbanization_QNAME, reader, context);
/* 697 */         if (object instanceof SOAPDeserializationState) {
/* 698 */           if (builder == null) {
/* 699 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 701 */           state = registerWithMemberState(instance, state, object, 33, (SOAPInstanceBuilder)builder);
/* 702 */           isComplete = false;
/* 703 */         } else if (object != null) {
/* 704 */           instance.setUrbanization((UrbanizationTO[])object);
/*     */         } 
/* 706 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 709 */       else if (matchQName(elementName, ns2_zone_QNAME)) {
/* 710 */         context.setNillable(true);
/* 711 */         Object object = this.myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1.deserialize(ns2_zone_QNAME, reader, context);
/* 712 */         if (object instanceof SOAPDeserializationState) {
/* 713 */           if (builder == null) {
/* 714 */             builder = new MasterDataResponseTO_SOAPBuilder();
/*     */           }
/* 716 */           state = registerWithMemberState(instance, state, object, 34, (SOAPInstanceBuilder)builder);
/* 717 */           isComplete = false;
/* 718 */         } else if (object != null) {
/* 719 */           instance.setZone((ZoneTO[])object);
/*     */         } 
/* 721 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 724 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_zone_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 729 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 730 */     } catch (XMLReaderException xmle) {
/* 731 */       if (startName != null) {
/* 732 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 734 */       throw xmle;
/*     */     } 
/*     */     
/* 737 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 741 */     MasterDataResponseTO instance = (MasterDataResponseTO)obj;
/*     */     
/* 743 */     context.setNillable(true);
/* 744 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getExecutionTime()), ns2_executionTime_QNAME, null, writer, context);
/* 745 */     context.setNillable(true);
/* 746 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOrigin(), ns2_origin_QNAME, null, writer, context);
/* 747 */     context.setNillable(true);
/* 748 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseCode(), ns2_responseCode_QNAME, null, writer, context);
/* 749 */     context.setNillable(true);
/* 750 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseDescription(), ns2_responseDescription_QNAME, null, writer, context);
/* 751 */     context.setNillable(true);
/* 752 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseMessage(), ns2_responseMessage_QNAME, null, writer, context);
/* 753 */     context.setNillable(true);
/* 754 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseSubCode(), ns2_responseSubCode_QNAME, null, writer, context);
/* 755 */     context.setNillable(true);
/* 756 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 757 */     context.setNillable(true);
/* 758 */     this.myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1.serialize(instance.getAdjustmentReasons(), ns2_adjustmentReasons_QNAME, null, writer, context);
/* 759 */     context.setNillable(true);
/* 760 */     this.myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1.serialize(instance.getBalanceList(), ns2_balanceList_QNAME, null, writer, context);
/* 761 */     context.setNillable(true);
/* 762 */     this.myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1.serialize(instance.getChargeCodes(), ns2_chargeCodes_QNAME, null, writer, context);
/* 763 */     context.setNillable(true);
/* 764 */     this.myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1.serialize(instance.getCity(), ns2_city_QNAME, null, writer, context);
/* 765 */     context.setNillable(true);
/* 766 */     this.myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1.serialize(instance.getCommunalCouncilCharges(), ns2_communalCouncilCharges_QNAME, null, writer, context);
/* 767 */     context.setNillable(true);
/* 768 */     this.myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1.serialize(instance.getCoolingReason(), ns2_coolingReason_QNAME, null, writer, context);
/* 769 */     context.setNillable(true);
/* 770 */     this.myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1.serialize(instance.getIvrPlanBenefits(), ns2_ivrPlanBenefits_QNAME, null, writer, context);
/* 771 */     context.setNillable(true);
/* 772 */     this.myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1.serialize(instance.getIvrPlans(), ns2_ivrPlans_QNAME, null, writer, context);
/* 773 */     context.setNillable(true);
/* 774 */     this.myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1.serialize(instance.getLocality(), ns2_locality_QNAME, null, writer, context);
/* 775 */     context.setNillable(true);
/* 776 */     this.myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1.serialize(instance.getMemosCategory(), ns2_memosCategory_QNAME, null, writer, context);
/* 777 */     context.setNillable(true);
/* 778 */     this.myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1.serialize(instance.getModelsPhones(), ns2_modelsPhones_QNAME, null, writer, context);
/* 779 */     context.setNillable(true);
/* 780 */     this.myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1.serialize(instance.getMunicipalitie(), ns2_municipalitie_QNAME, null, writer, context);
/* 781 */     context.setNillable(true);
/* 782 */     this.myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1.serialize(instance.getNationalities(), ns2_nationalities_QNAME, null, writer, context);
/* 783 */     context.setNillable(true);
/* 784 */     this.myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1.serialize(instance.getParishe(), ns2_parishe_QNAME, null, writer, context);
/* 785 */     context.setNillable(true);
/* 786 */     this.myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1.serialize(instance.getPlans(), ns2_plans_QNAME, null, writer, context);
/* 787 */     context.setNillable(true);
/* 788 */     this.myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1.serialize(instance.getProfession(), ns2_profession_QNAME, null, writer, context);
/* 789 */     context.setNillable(true);
/* 790 */     this.myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1.serialize(instance.getPromotions(), ns2_promotions_QNAME, null, writer, context);
/* 791 */     context.setNillable(true);
/* 792 */     this.myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1.serialize(instance.getSector(), ns2_sector_QNAME, null, writer, context);
/* 793 */     context.setNillable(true);
/* 794 */     this.myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1.serialize(instance.getSellingAgent(), ns2_sellingAgent_QNAME, null, writer, context);
/* 795 */     context.setNillable(true);
/* 796 */     this.myns2_ArrayOfServiceTO__ServiceTOArray_LiteralSerializer1.serialize(instance.getServices(), ns2_services_QNAME, null, writer, context);
/* 797 */     context.setNillable(true);
/* 798 */     this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.serialize(instance.getState(), ns2_state_QNAME, null, writer, context);
/* 799 */     context.setNillable(true);
/* 800 */     this.myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1.serialize(instance.getStructuredCities(), ns2_structuredCities_QNAME, null, writer, context);
/* 801 */     context.setNillable(true);
/* 802 */     this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.serialize(instance.getStructuredStates(), ns2_structuredStates_QNAME, null, writer, context);
/* 803 */     context.setNillable(true);
/* 804 */     this.myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1.serialize(instance.getStructuredZones(), ns2_structuredZones_QNAME, null, writer, context);
/* 805 */     context.setNillable(true);
/* 806 */     this.myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1.serialize(instance.getSubCategory(), ns2_subCategory_QNAME, null, writer, context);
/* 807 */     context.setNillable(true);
/* 808 */     this.myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1.serialize(instance.getTextPlans(), ns2_textPlans_QNAME, null, writer, context);
/* 809 */     context.setNillable(true);
/* 810 */     this.myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1.serialize(instance.getUrbanization(), ns2_urbanization_QNAME, null, writer, context);
/* 811 */     context.setNillable(true);
/* 812 */     this.myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1.serialize(instance.getZone(), ns2_zone_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\wsprepaybasebrplanoffer\MasterDataResponseTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */