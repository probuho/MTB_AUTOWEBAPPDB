/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangeBRPlanRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidateChangeBRPlanRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidateChangeBRPlanRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_planCodeNew_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCodeNew");
/*  33 */   private static final QName ns2_subscriberId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subscriberId");
/*  34 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  36 */   private static final QName ns2_userId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "userId"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myplanCodeNew_INDEX = 5;
/*     */   private static final int mysubscriberId_INDEX = 6;
/*     */   private static final int myuserId_INDEX = 7;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ValidateChangeBRPlanRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  47 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  51 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidateChangeBRPlanRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  52 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidateChangeBRPlanRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  53 */     if (class$java$lang$String == null); ((ValidateChangeBRPlanRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  54 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  55 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  60 */     ValidateChangeBRPlanRequestTO instance = new ValidateChangeBRPlanRequestTO();
/*  61 */     ValidateChangeBRPlanRequestTO_SOAPBuilder builder = null;
/*     */     
/*  63 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  66 */     reader.nextElementContent();
/*  67 */     QName startName = reader.getName();
/*  68 */     for (int i = 0; i < 8; i++) {
/*  69 */       QName elementName = reader.getName();
/*  70 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  73 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  74 */         context.setNillable(true);
/*  75 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  76 */         if (member instanceof SOAPDeserializationState) {
/*  77 */           if (builder == null) {
/*  78 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/*  80 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  81 */           isComplete = false;
/*  82 */         } else if (member != null) {
/*  83 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  85 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  88 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  89 */         context.setNillable(true);
/*  90 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  91 */         if (object instanceof SOAPDeserializationState) {
/*  92 */           if (builder == null) {
/*  93 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/*  95 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  96 */           isComplete = false;
/*  97 */         } else if (object != null) {
/*  98 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 100 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 103 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 104 */         context.setNillable(true);
/* 105 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 106 */         if (object instanceof SOAPDeserializationState) {
/* 107 */           if (builder == null) {
/* 108 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/* 110 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 111 */           isComplete = false;
/* 112 */         } else if (object != null) {
/* 113 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 115 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 118 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 119 */         context.setNillable(true);
/* 120 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 121 */         if (object instanceof SOAPDeserializationState) {
/* 122 */           if (builder == null) {
/* 123 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/* 125 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 126 */           isComplete = false;
/* 127 */         } else if (object != null) {
/* 128 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 130 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 133 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 134 */         context.setNillable(true);
/* 135 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 136 */         if (object instanceof SOAPDeserializationState) {
/* 137 */           if (builder == null) {
/* 138 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/* 140 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 141 */           isComplete = false;
/* 142 */         } else if (object != null) {
/* 143 */           instance.setTransactionId((String)object);
/*     */         } 
/* 145 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 148 */       else if (matchQName(elementName, ns2_planCodeNew_QNAME)) {
/* 149 */         context.setNillable(true);
/* 150 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCodeNew_QNAME, reader, context);
/* 151 */         if (object instanceof SOAPDeserializationState) {
/* 152 */           if (builder == null) {
/* 153 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/* 155 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 156 */           isComplete = false;
/* 157 */         } else if (object != null) {
/* 158 */           instance.setPlanCodeNew((String)object);
/*     */         } 
/* 160 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 163 */       else if (matchQName(elementName, ns2_subscriberId_QNAME)) {
/* 164 */         context.setNillable(true);
/* 165 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_subscriberId_QNAME, reader, context);
/* 166 */         if (object instanceof SOAPDeserializationState) {
/* 167 */           if (builder == null) {
/* 168 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/* 170 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 171 */           isComplete = false;
/* 172 */         } else if (object != null) {
/* 173 */           instance.setSubscriberId(((Long)object).longValue());
/*     */         } 
/* 175 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 178 */       else if (matchQName(elementName, ns2_userId_QNAME)) {
/* 179 */         context.setNillable(true);
/* 180 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_userId_QNAME, reader, context);
/* 181 */         if (object instanceof SOAPDeserializationState) {
/* 182 */           if (builder == null) {
/* 183 */             builder = new ValidateChangeBRPlanRequestTO_SOAPBuilder();
/*     */           }
/* 185 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 186 */           isComplete = false;
/* 187 */         } else if (object != null) {
/* 188 */           instance.setUserId((String)object);
/*     */         } 
/* 190 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 193 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_userId_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 198 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 199 */     } catch (XMLReaderException xmle) {
/* 200 */       if (startName != null) {
/* 201 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 203 */       throw xmle;
/*     */     } 
/*     */     
/* 206 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 210 */     ValidateChangeBRPlanRequestTO instance = (ValidateChangeBRPlanRequestTO)obj;
/*     */     
/* 212 */     context.setNillable(true);
/* 213 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 214 */     context.setNillable(true);
/* 215 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 216 */     context.setNillable(true);
/* 217 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 218 */     context.setNillable(true);
/* 219 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 220 */     context.setNillable(true);
/* 221 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 222 */     context.setNillable(true);
/* 223 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCodeNew(), ns2_planCodeNew_QNAME, null, writer, context);
/* 224 */     context.setNillable(true);
/* 225 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getSubscriberId()), ns2_subscriberId_QNAME, null, writer, context);
/* 226 */     context.setNillable(true);
/* 227 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUserId(), ns2_userId_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidateChangeBRPlanRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */