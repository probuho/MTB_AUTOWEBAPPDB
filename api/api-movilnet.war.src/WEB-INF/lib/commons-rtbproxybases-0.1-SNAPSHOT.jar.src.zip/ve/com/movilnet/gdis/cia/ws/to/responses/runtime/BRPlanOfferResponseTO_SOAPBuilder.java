/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BRPlanOfferResponseTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private BRPlanOfferResponseTO _instance;
/*     */   private long executionTime;
/*     */   private String origin;
/*     */   private String responseCode;
/*     */   private String responseDescription;
/*     */   private String responseMessage;
/*     */   private String responseSubCode;
/*     */   private String transactionId;
/*     */   private String alcoName;
/*     */   private int applyDay;
/*     */   private String cosName;
/*     */   private String periodicCharge;
/*     */   private boolean result;
/*     */   private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static final int myalcoName_INDEX = 7;
/*     */   private static final int myapplyDay_INDEX = 8;
/*     */   private static final int mycosName_INDEX = 9;
/*     */   private static final int myperiodicCharge_INDEX = 10;
/*     */   private static final int myresult_INDEX = 11;
/*     */   
/*     */   public void setExecutionTime(long executionTime) {
/*  43 */     this.executionTime = executionTime;
/*     */   }
/*     */   
/*     */   public void setOrigin(String origin) {
/*  47 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public void setResponseCode(String responseCode) {
/*  51 */     this.responseCode = responseCode;
/*     */   }
/*     */   
/*     */   public void setResponseDescription(String responseDescription) {
/*  55 */     this.responseDescription = responseDescription;
/*     */   }
/*     */   
/*     */   public void setResponseMessage(String responseMessage) {
/*  59 */     this.responseMessage = responseMessage;
/*     */   }
/*     */   
/*     */   public void setResponseSubCode(String responseSubCode) {
/*  63 */     this.responseSubCode = responseSubCode;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  67 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAlcoName(String alcoName) {
/*  71 */     this.alcoName = alcoName;
/*     */   }
/*     */   
/*     */   public void setApplyDay(int applyDay) {
/*  75 */     this.applyDay = applyDay;
/*     */   }
/*     */   
/*     */   public void setCosName(String cosName) {
/*  79 */     this.cosName = cosName;
/*     */   }
/*     */   
/*     */   public void setPeriodicCharge(String periodicCharge) {
/*  83 */     this.periodicCharge = periodicCharge;
/*     */   }
/*     */   
/*     */   public void setResult(boolean result) {
/*  87 */     this.result = result;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  91 */     switch (memberIndex) {
/*     */       case 0:
/*  93 */         return 6;
/*     */       case 1:
/*  95 */         return 6;
/*     */       case 2:
/*  97 */         return 6;
/*     */       case 3:
/*  99 */         return 6;
/*     */       case 4:
/* 101 */         return 6;
/*     */       case 5:
/* 103 */         return 6;
/*     */       case 6:
/* 105 */         return 6;
/*     */       case 7:
/* 107 */         return 6;
/*     */       case 8:
/* 109 */         return 6;
/*     */       case 9:
/* 111 */         return 6;
/*     */       case 10:
/* 113 */         return 6;
/*     */       case 11:
/* 115 */         return 6;
/*     */     } 
/* 117 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 126 */       switch (index) {
/*     */         case 0:
/* 128 */           this._instance.setExecutionTime(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 1:
/* 131 */           this._instance.setOrigin((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 134 */           this._instance.setResponseCode((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 137 */           this._instance.setResponseDescription((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 140 */           this._instance.setResponseMessage((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 143 */           this._instance.setResponseSubCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 146 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 149 */           this._instance.setAlcoName((String)memberValue);
/*     */           return;
/*     */         case 8:
/* 152 */           this._instance.setApplyDay(((Integer)memberValue).intValue());
/*     */           return;
/*     */         case 9:
/* 155 */           this._instance.setCosName((String)memberValue);
/*     */           return;
/*     */         case 10:
/* 158 */           this._instance.setPeriodicCharge((String)memberValue);
/*     */           return;
/*     */         case 11:
/* 161 */           this._instance.setResult(((Boolean)memberValue).booleanValue());
/*     */           return;
/*     */       } 
/* 164 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 167 */     catch (RuntimeException e) {
/* 168 */       throw e;
/*     */     }
/* 170 */     catch (Exception e) {
/* 171 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 179 */     this._instance = (BRPlanOfferResponseTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 183 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\runtime\BRPlanOfferResponseTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */