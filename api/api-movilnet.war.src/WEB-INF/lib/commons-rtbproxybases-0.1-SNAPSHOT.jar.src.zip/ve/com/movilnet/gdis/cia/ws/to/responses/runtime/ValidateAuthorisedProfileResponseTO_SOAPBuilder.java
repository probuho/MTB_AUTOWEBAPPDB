/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.ValidateAuthorisedProfileResponseTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidateAuthorisedProfileResponseTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ValidateAuthorisedProfileResponseTO _instance;
/*     */   private long executionTime;
/*     */   private String origin;
/*     */   private String responseCode;
/*     */   private String responseDescription;
/*     */   private String responseMessage;
/*     */   private String responseSubCode;
/*     */   private String transactionId;
/*     */   private String[] genfield;
/*     */   private boolean result;
/*     */   private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static final int mygenfield_INDEX = 7;
/*     */   private static final int myresult_INDEX = 8;
/*     */   
/*     */   public void setExecutionTime(long executionTime) {
/*  37 */     this.executionTime = executionTime;
/*     */   }
/*     */   
/*     */   public void setOrigin(String origin) {
/*  41 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public void setResponseCode(String responseCode) {
/*  45 */     this.responseCode = responseCode;
/*     */   }
/*     */   
/*     */   public void setResponseDescription(String responseDescription) {
/*  49 */     this.responseDescription = responseDescription;
/*     */   }
/*     */   
/*     */   public void setResponseMessage(String responseMessage) {
/*  53 */     this.responseMessage = responseMessage;
/*     */   }
/*     */   
/*     */   public void setResponseSubCode(String responseSubCode) {
/*  57 */     this.responseSubCode = responseSubCode;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  61 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setGenfield(String[] genfield) {
/*  65 */     this.genfield = genfield;
/*     */   }
/*     */   
/*     */   public void setResult(boolean result) {
/*  69 */     this.result = result;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  73 */     switch (memberIndex) {
/*     */       case 0:
/*  75 */         return 6;
/*     */       case 1:
/*  77 */         return 6;
/*     */       case 2:
/*  79 */         return 6;
/*     */       case 3:
/*  81 */         return 6;
/*     */       case 4:
/*  83 */         return 6;
/*     */       case 5:
/*  85 */         return 6;
/*     */       case 6:
/*  87 */         return 6;
/*     */       case 7:
/*  89 */         return 6;
/*     */       case 8:
/*  91 */         return 6;
/*     */     } 
/*  93 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 102 */       switch (index) {
/*     */         case 0:
/* 104 */           this._instance.setExecutionTime(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 1:
/* 107 */           this._instance.setOrigin((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 110 */           this._instance.setResponseCode((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 113 */           this._instance.setResponseDescription((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 116 */           this._instance.setResponseMessage((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 119 */           this._instance.setResponseSubCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 122 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 125 */           this._instance.setGenfield((String[])memberValue);
/*     */           return;
/*     */         case 8:
/* 128 */           this._instance.setResult(((Boolean)memberValue).booleanValue());
/*     */           return;
/*     */       } 
/* 131 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 134 */     catch (RuntimeException e) {
/* 135 */       throw e;
/*     */     }
/* 137 */     catch (Exception e) {
/* 138 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 146 */     this._instance = (ValidateAuthorisedProfileResponseTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 150 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\runtime\ValidateAuthorisedProfileResponseTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */