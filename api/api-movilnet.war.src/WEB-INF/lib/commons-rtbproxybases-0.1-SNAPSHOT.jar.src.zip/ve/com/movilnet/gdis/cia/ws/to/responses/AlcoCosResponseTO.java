/*    */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlcoCosResponseTO
/*    */   extends ResponseTO
/*    */   implements Serializable
/*    */ {
/*    */   protected AlcoCosTO alcoCosTO;
/*    */   
/*    */   public AlcoCosTO getAlcoCosTO() {
/* 17 */     return this.alcoCosTO;
/*    */   }
/*    */   
/*    */   public void setAlcoCosTO(AlcoCosTO alcoCosTO) {
/* 21 */     this.alcoCosTO = alcoCosTO;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\AlcoCosResponseTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */