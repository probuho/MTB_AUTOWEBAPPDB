/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AlcoCosResponseTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private AlcoCosResponseTO _instance;
/*     */   private long executionTime;
/*     */   private String origin;
/*     */   private String responseCode;
/*     */   private String responseDescription;
/*     */   private String responseMessage;
/*     */   private String responseSubCode;
/*     */   private String transactionId;
/*     */   private AlcoCosTO alcoCosTO;
/*     */   private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static final int myalcoCosTO_INDEX = 7;
/*     */   
/*     */   public void setExecutionTime(long executionTime) {
/*  35 */     this.executionTime = executionTime;
/*     */   }
/*     */   
/*     */   public void setOrigin(String origin) {
/*  39 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public void setResponseCode(String responseCode) {
/*  43 */     this.responseCode = responseCode;
/*     */   }
/*     */   
/*     */   public void setResponseDescription(String responseDescription) {
/*  47 */     this.responseDescription = responseDescription;
/*     */   }
/*     */   
/*     */   public void setResponseMessage(String responseMessage) {
/*  51 */     this.responseMessage = responseMessage;
/*     */   }
/*     */   
/*     */   public void setResponseSubCode(String responseSubCode) {
/*  55 */     this.responseSubCode = responseSubCode;
/*     */   }
/*     */   
/*     */   public void setTransactionId(String transactionId) {
/*  59 */     this.transactionId = transactionId;
/*     */   }
/*     */   
/*     */   public void setAlcoCosTO(AlcoCosTO alcoCosTO) {
/*  63 */     this.alcoCosTO = alcoCosTO;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  67 */     switch (memberIndex) {
/*     */       case 0:
/*  69 */         return 6;
/*     */       case 1:
/*  71 */         return 6;
/*     */       case 2:
/*  73 */         return 6;
/*     */       case 3:
/*  75 */         return 6;
/*     */       case 4:
/*  77 */         return 6;
/*     */       case 5:
/*  79 */         return 6;
/*     */       case 6:
/*  81 */         return 6;
/*     */       case 7:
/*  83 */         return 6;
/*     */     } 
/*  85 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/*  94 */       switch (index) {
/*     */         case 0:
/*  96 */           this._instance.setExecutionTime(((Long)memberValue).longValue());
/*     */           return;
/*     */         case 1:
/*  99 */           this._instance.setOrigin((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 102 */           this._instance.setResponseCode((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 105 */           this._instance.setResponseDescription((String)memberValue);
/*     */           return;
/*     */         case 4:
/* 108 */           this._instance.setResponseMessage((String)memberValue);
/*     */           return;
/*     */         case 5:
/* 111 */           this._instance.setResponseSubCode((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 114 */           this._instance.setTransactionId((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 117 */           this._instance.setAlcoCosTO((AlcoCosTO)memberValue);
/*     */           return;
/*     */       } 
/* 120 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 123 */     catch (RuntimeException e) {
/* 124 */       throw e;
/*     */     }
/* 126 */     catch (Exception e) {
/* 127 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 135 */     this._instance = (AlcoCosResponseTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 139 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\runtime\AlcoCosResponseTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */