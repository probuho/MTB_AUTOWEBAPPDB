/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.responses.ValidatePlanResponseTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidatePlanResponseTO result;
/*    */   
/*    */   public ValidatePlanResponseTO getResult() {
/* 17 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(ValidatePlanResponseTO result) {
/* 21 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */