/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.PlanTO_SOAPBuilder;
/*     */ 
/*     */ public class PlanTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_descPlan_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "descPlan");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_planCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCode");
/*  23 */   private static final QName ns2_planSuffix_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planSuffix");
/*  24 */   private static final QName ns2_planType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planType");
/*  25 */   private static final QName ns2_unitType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "unitType"); private static final int mydescPlan_INDEX = 0;
/*     */   private static final int myplanCode_INDEX = 1;
/*     */   private static final int myplanSuffix_INDEX = 2;
/*     */   private static final int myplanType_INDEX = 3;
/*     */   private static final int myunitType_INDEX = 4;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public PlanTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  33 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  37 */     if (class$java$lang$String == null); ((PlanTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  42 */     PlanTO instance = new PlanTO();
/*  43 */     PlanTO_SOAPBuilder builder = null;
/*     */     
/*  45 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  48 */     reader.nextElementContent();
/*  49 */     QName startName = reader.getName();
/*  50 */     for (int i = 0; i < 5; i++) {
/*  51 */       QName elementName = reader.getName();
/*  52 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  55 */       if (matchQName(elementName, ns2_descPlan_QNAME)) {
/*  56 */         context.setNillable(true);
/*  57 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_descPlan_QNAME, reader, context);
/*  58 */         if (member instanceof SOAPDeserializationState) {
/*  59 */           if (builder == null) {
/*  60 */             builder = new PlanTO_SOAPBuilder();
/*     */           }
/*  62 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  63 */           isComplete = false;
/*  64 */         } else if (member != null) {
/*  65 */           instance.setDescPlan((String)member);
/*     */         } 
/*  67 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  70 */       else if (matchQName(elementName, ns2_planCode_QNAME)) {
/*  71 */         context.setNillable(true);
/*  72 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCode_QNAME, reader, context);
/*  73 */         if (object instanceof SOAPDeserializationState) {
/*  74 */           if (builder == null) {
/*  75 */             builder = new PlanTO_SOAPBuilder();
/*     */           }
/*  77 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  78 */           isComplete = false;
/*  79 */         } else if (object != null) {
/*  80 */           instance.setPlanCode((String)object);
/*     */         } 
/*  82 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  85 */       else if (matchQName(elementName, ns2_planSuffix_QNAME)) {
/*  86 */         context.setNillable(true);
/*  87 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planSuffix_QNAME, reader, context);
/*  88 */         if (object instanceof SOAPDeserializationState) {
/*  89 */           if (builder == null) {
/*  90 */             builder = new PlanTO_SOAPBuilder();
/*     */           }
/*  92 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/*  93 */           isComplete = false;
/*  94 */         } else if (object != null) {
/*  95 */           instance.setPlanSuffix((String)object);
/*     */         } 
/*  97 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 100 */       else if (matchQName(elementName, ns2_planType_QNAME)) {
/* 101 */         context.setNillable(true);
/* 102 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planType_QNAME, reader, context);
/* 103 */         if (object instanceof SOAPDeserializationState) {
/* 104 */           if (builder == null) {
/* 105 */             builder = new PlanTO_SOAPBuilder();
/*     */           }
/* 107 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 108 */           isComplete = false;
/* 109 */         } else if (object != null) {
/* 110 */           instance.setPlanType((String)object);
/*     */         } 
/* 112 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 115 */       else if (matchQName(elementName, ns2_unitType_QNAME)) {
/* 116 */         context.setNillable(true);
/* 117 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_unitType_QNAME, reader, context);
/* 118 */         if (object instanceof SOAPDeserializationState) {
/* 119 */           if (builder == null) {
/* 120 */             builder = new PlanTO_SOAPBuilder();
/*     */           }
/* 122 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 123 */           isComplete = false;
/* 124 */         } else if (object != null) {
/* 125 */           instance.setUnitType((String)object);
/*     */         } 
/* 127 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 130 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_unitType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 135 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 136 */     } catch (XMLReaderException xmle) {
/* 137 */       if (startName != null) {
/* 138 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 140 */       throw xmle;
/*     */     } 
/*     */     
/* 143 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 147 */     PlanTO instance = (PlanTO)obj;
/*     */     
/* 149 */     context.setNillable(true);
/* 150 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getDescPlan(), ns2_descPlan_QNAME, null, writer, context);
/* 151 */     context.setNillable(true);
/* 152 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCode(), ns2_planCode_QNAME, null, writer, context);
/* 153 */     context.setNillable(true);
/* 154 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanSuffix(), ns2_planSuffix_QNAME, null, writer, context);
/* 155 */     context.setNillable(true);
/* 156 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanType(), ns2_planType_QNAME, null, writer, context);
/* 157 */     context.setNillable(true);
/* 158 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUnitType(), ns2_unitType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\PlanTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */