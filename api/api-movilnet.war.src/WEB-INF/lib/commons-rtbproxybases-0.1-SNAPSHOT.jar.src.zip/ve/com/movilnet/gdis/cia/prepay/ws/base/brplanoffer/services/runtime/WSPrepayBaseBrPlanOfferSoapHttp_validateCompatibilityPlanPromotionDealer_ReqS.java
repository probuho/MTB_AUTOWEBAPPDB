/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanPromotionDealerRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidatePlanPromotionDealerRequestTO planPromotionDealerRequest;
/*    */   
/*    */   public ValidatePlanPromotionDealerRequestTO getPlanPromotionDealerRequest() {
/* 17 */     return this.planPromotionDealerRequest;
/*    */   }
/*    */   
/*    */   public void setPlanPromotionDealerRequest(ValidatePlanPromotionDealerRequestTO planPromotionDealerRequest) {
/* 21 */     this.planPromotionDealerRequest = planPromotionDealerRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */