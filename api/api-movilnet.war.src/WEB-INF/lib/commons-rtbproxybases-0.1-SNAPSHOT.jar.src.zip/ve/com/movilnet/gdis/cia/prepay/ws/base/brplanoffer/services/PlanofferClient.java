/*     */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.xml.rpc.ServiceFactory;
/*     */ import javax.xml.rpc.Stub;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO;
/*     */ 
/*     */ public class PlanofferClient {
/*     */   private IWSPrepayBaseBrPlanOffer _port;
/*     */   
/*     */   static Class class$(String paramString) {
/*     */     
/*  13 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*     */   
/*     */   } private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$WSPrepayBaseBrPlanOffer;
/*     */   public PlanofferClient() throws Exception {
/*  17 */     ServiceFactory factory = ServiceFactory.newInstance();
/*  18 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$WSPrepayBaseBrPlanOffer == null); ((PlanofferClient)factory)._port = ((WSPrepayBaseBrPlanOffer)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$WSPrepayBaseBrPlanOffer.loadService(class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$WSPrepayBaseBrPlanOffer = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.WSPrepayBaseBrPlanOffer"))).getPlanoffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*  26 */       PlanofferClient myPort = new PlanofferClient();
/*  27 */       System.out.println("calling " + myPort.getEndpoint());
/*     */     
/*     */     }
/*  30 */     catch (Exception ex) {
/*  31 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BRPlanOfferResponseTO isChangePlan(ValidateChangeBRPlanRequestTO changePlanRequest) throws RemoteException {
/*  40 */     return this._port.isChangePlan(changePlanRequest);
/*     */   }
/*     */   
/*     */   public BRPlanOfferResponseTO validateAffiliationService(ValidateAffiliationServiceRequestTO affiliationServiceRequest) throws RemoteException {
/*  44 */     return this._port.validateAffiliationService(affiliationServiceRequest);
/*     */   }
/*     */   
/*     */   public ValidateAuthorisedProfileResponseTO validateAuthorisedProfile(ValidateAuthorisedProfileRequestTO validateAuthorisedProfileRequest) throws RemoteException {
/*  48 */     return this._port.validateAuthorisedProfile(validateAuthorisedProfileRequest);
/*     */   }
/*     */   
/*     */   public BRPlanOfferResponseTO validateChangePlanText(ValidateChangePlanTextRequestTO changePlanTextRequest) throws RemoteException {
/*  52 */     return this._port.validateChangePlanText(changePlanTextRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validateCompatibilityPlanModel(ValidatePlanModelRequestTO planModelRequest) throws RemoteException {
/*  56 */     return this._port.validateCompatibilityPlanModel(planModelRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validateCompatibilityPlanModel_v2(ValidatePlanModelRequestTO_v2 planModelRequest) throws RemoteException {
/*  60 */     return this._port.validateCompatibilityPlanModel_v2(planModelRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validateCompatibilityPlanPromotionDealer(ValidatePlanPromotionDealerRequestTO planPromotionDealerRequest) throws RemoteException {
/*  64 */     return this._port.validateCompatibilityPlanPromotionDealer(planPromotionDealerRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validateCompatibilityPlanServices(ValidatePlanServicesRequestTO planServicesRequest) throws RemoteException {
/*  68 */     return this._port.validateCompatibilityPlanServices(planServicesRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validateCompatibilityServicesModel(ValidateServicesModelRequestTO servicesModelRequest) throws RemoteException {
/*  72 */     return this._port.validateCompatibilityServicesModel(servicesModelRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validateCompatibilityServicesModel_v2(ValidateServicesModelRequestTO_v2 servicesModelRequest) throws RemoteException {
/*  76 */     return this._port.validateCompatibilityServicesModel_v2(servicesModelRequest);
/*     */   }
/*     */   
/*     */   public BRPlanOfferResponseTO validateDisConnectionService(ValidateDisConnectionServiceRequestTO disConnectionServiceRequest) throws RemoteException {
/*  80 */     return this._port.validateDisConnectionService(disConnectionServiceRequest);
/*     */   }
/*     */   
/*     */   public ValidateNumberSpecialServicesResponseTO validateNumberSpecialServices(ValidateNumberSpecialServicesRequestTO validateNumberSpecialServicesRequest) throws RemoteException {
/*  84 */     return this._port.validateNumberSpecialServices(validateNumberSpecialServicesRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validatePlan(ValidatePlanRequestTO planRequest) throws RemoteException {
/*  88 */     return this._port.validatePlan(planRequest);
/*     */   }
/*     */   
/*     */   public BooleanResponseTO validatePlanConsejoComunal(ValidatePlanConsejoComunalRequestTO planConsejoComunalRequest) throws RemoteException {
/*  92 */     return this._port.validatePlanConsejoComunal(planConsejoComunalRequest);
/*     */   }
/*     */   
/*     */   public ValidatePlanResponseTO validatePlan_v2(ValidatePlanRequestTO_v2 planRequest) throws RemoteException {
/*  96 */     return this._port.validatePlan_v2(planRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IWSPrepayBaseBrPlanOffer getPort() {
/* 105 */     return this._port;
/*     */   }
/*     */   
/*     */   public String getEndpoint() {
/* 109 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.service.endpoint.address");
/*     */   }
/*     */   
/*     */   public void setEndpoint(String endpoint) {
/* 113 */     ((Stub)this._port)._setProperty("javax.xml.rpc.service.endpoint.address", endpoint);
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 117 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.security.auth.password");
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 121 */     ((Stub)this._port)._setProperty("javax.xml.rpc.security.auth.password", password);
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 125 */     return (String)((Stub)this._port)._getProperty("javax.xml.rpc.security.auth.username");
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 129 */     ((Stub)this._port)._setProperty("javax.xml.rpc.security.auth.username", username);
/*     */   }
/*     */   
/*     */   public void setMaintainSession(boolean maintainSession) {
/* 133 */     ((Stub)this._port)._setProperty("javax.xml.rpc.session.maintain", Boolean.valueOf(maintainSession));
/*     */   }
/*     */   
/*     */   public boolean getMaintainSession() {
/* 137 */     return ((Boolean)((Stub)this._port)._getProperty("javax.xml.rpc.session.maintain")).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientTransport getClientTransport() {
/* 144 */     return ((OracleStub)this._port).getClientTransport();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\PlanofferClient.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */