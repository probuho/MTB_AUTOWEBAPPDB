/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.BalanceListTO_SOAPBuilder;
/*     */ 
/*     */ public class BalanceListTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_adjustmentInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "adjustmentInd");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_balanceCommercialName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceCommercialName");
/*  23 */   private static final QName ns2_balanceId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceId");
/*  24 */   private static final QName ns3_int_TYPE_QNAME = SchemaConstants.QNAME_TYPE_INT;
/*     */   private CombinedSerializer myns3__int__int_Int_Serializer;
/*  26 */   private static final QName ns2_balanceName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceName");
/*  27 */   private static final QName ns2_balanceSubType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceSubType");
/*  28 */   private static final QName ns2_balanceType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceType");
/*  29 */   private static final QName ns2_conversionFactor_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "conversionFactor");
/*  30 */   private static final QName ns3_double_TYPE_QNAME = SchemaConstants.QNAME_TYPE_DOUBLE;
/*     */   private CombinedSerializer myns3__double__double_Double_Serializer;
/*  32 */   private static final QName ns2_decimalInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "decimalInd");
/*  33 */   private static final QName ns2_taxInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "taxInd");
/*  34 */   private static final QName ns2_unitCommercialName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "unitCommercialName"); private static final int myadjustmentInd_INDEX = 0;
/*     */   private static final int mybalanceCommercialName_INDEX = 1;
/*     */   private static final int mybalanceId_INDEX = 2;
/*     */   private static final int mybalanceName_INDEX = 3;
/*     */   private static final int mybalanceSubType_INDEX = 4;
/*     */   private static final int mybalanceType_INDEX = 5;
/*     */   private static final int myconversionFactor_INDEX = 6;
/*     */   private static final int mydecimalInd_INDEX = 7;
/*     */   private static final int mytaxInd_INDEX = 8;
/*     */   private static final int myunitCommercialName_INDEX = 9;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public BalanceListTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  47 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  51 */     if (class$java$lang$String == null); ((BalanceListTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  52 */     this.myns3__int__int_Int_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), int.class, ns3_int_TYPE_QNAME);
/*  53 */     this.myns3__double__double_Double_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), double.class, ns3_double_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  58 */     BalanceListTO instance = new BalanceListTO();
/*  59 */     BalanceListTO_SOAPBuilder builder = null;
/*     */     
/*  61 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  64 */     reader.nextElementContent();
/*  65 */     QName startName = reader.getName();
/*  66 */     for (int i = 0; i < 10; i++) {
/*  67 */       QName elementName = reader.getName();
/*  68 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  71 */       if (matchQName(elementName, ns2_adjustmentInd_QNAME)) {
/*  72 */         context.setNillable(true);
/*  73 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_adjustmentInd_QNAME, reader, context);
/*  74 */         if (member instanceof SOAPDeserializationState) {
/*  75 */           if (builder == null) {
/*  76 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/*  78 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  79 */           isComplete = false;
/*  80 */         } else if (member != null) {
/*  81 */           instance.setAdjustmentInd((String)member);
/*     */         } 
/*  83 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  86 */       else if (matchQName(elementName, ns2_balanceCommercialName_QNAME)) {
/*  87 */         context.setNillable(true);
/*  88 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_balanceCommercialName_QNAME, reader, context);
/*  89 */         if (object instanceof SOAPDeserializationState) {
/*  90 */           if (builder == null) {
/*  91 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/*  93 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  94 */           isComplete = false;
/*  95 */         } else if (object != null) {
/*  96 */           instance.setBalanceCommercialName((String)object);
/*     */         } 
/*  98 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 101 */       else if (matchQName(elementName, ns2_balanceId_QNAME)) {
/* 102 */         context.setNillable(true);
/* 103 */         Object object = this.myns3__int__int_Int_Serializer.deserialize(ns2_balanceId_QNAME, reader, context);
/* 104 */         if (object instanceof SOAPDeserializationState) {
/* 105 */           if (builder == null) {
/* 106 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 108 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 109 */           isComplete = false;
/* 110 */         } else if (object != null) {
/* 111 */           instance.setBalanceId(((Integer)object).intValue());
/*     */         } 
/* 113 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 116 */       else if (matchQName(elementName, ns2_balanceName_QNAME)) {
/* 117 */         context.setNillable(true);
/* 118 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_balanceName_QNAME, reader, context);
/* 119 */         if (object instanceof SOAPDeserializationState) {
/* 120 */           if (builder == null) {
/* 121 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 123 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 124 */           isComplete = false;
/* 125 */         } else if (object != null) {
/* 126 */           instance.setBalanceName((String)object);
/*     */         } 
/* 128 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 131 */       else if (matchQName(elementName, ns2_balanceSubType_QNAME)) {
/* 132 */         context.setNillable(true);
/* 133 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_balanceSubType_QNAME, reader, context);
/* 134 */         if (object instanceof SOAPDeserializationState) {
/* 135 */           if (builder == null) {
/* 136 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 138 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 139 */           isComplete = false;
/* 140 */         } else if (object != null) {
/* 141 */           instance.setBalanceSubType((String)object);
/*     */         } 
/* 143 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 146 */       else if (matchQName(elementName, ns2_balanceType_QNAME)) {
/* 147 */         context.setNillable(true);
/* 148 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_balanceType_QNAME, reader, context);
/* 149 */         if (object instanceof SOAPDeserializationState) {
/* 150 */           if (builder == null) {
/* 151 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 153 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 154 */           isComplete = false;
/* 155 */         } else if (object != null) {
/* 156 */           instance.setBalanceType((String)object);
/*     */         } 
/* 158 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 161 */       else if (matchQName(elementName, ns2_conversionFactor_QNAME)) {
/* 162 */         context.setNillable(true);
/* 163 */         Object object = this.myns3__double__double_Double_Serializer.deserialize(ns2_conversionFactor_QNAME, reader, context);
/* 164 */         if (object instanceof SOAPDeserializationState) {
/* 165 */           if (builder == null) {
/* 166 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 168 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 169 */           isComplete = false;
/* 170 */         } else if (object != null) {
/* 171 */           instance.setConversionFactor(((Double)object).doubleValue());
/*     */         } 
/* 173 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 176 */       else if (matchQName(elementName, ns2_decimalInd_QNAME)) {
/* 177 */         context.setNillable(true);
/* 178 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_decimalInd_QNAME, reader, context);
/* 179 */         if (object instanceof SOAPDeserializationState) {
/* 180 */           if (builder == null) {
/* 181 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 183 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 184 */           isComplete = false;
/* 185 */         } else if (object != null) {
/* 186 */           instance.setDecimalInd((String)object);
/*     */         } 
/* 188 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 191 */       else if (matchQName(elementName, ns2_taxInd_QNAME)) {
/* 192 */         context.setNillable(true);
/* 193 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_taxInd_QNAME, reader, context);
/* 194 */         if (object instanceof SOAPDeserializationState) {
/* 195 */           if (builder == null) {
/* 196 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 198 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 199 */           isComplete = false;
/* 200 */         } else if (object != null) {
/* 201 */           instance.setTaxInd((String)object);
/*     */         } 
/* 203 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 206 */       else if (matchQName(elementName, ns2_unitCommercialName_QNAME)) {
/* 207 */         context.setNillable(true);
/* 208 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_unitCommercialName_QNAME, reader, context);
/* 209 */         if (object instanceof SOAPDeserializationState) {
/* 210 */           if (builder == null) {
/* 211 */             builder = new BalanceListTO_SOAPBuilder();
/*     */           }
/* 213 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 214 */           isComplete = false;
/* 215 */         } else if (object != null) {
/* 216 */           instance.setUnitCommercialName((String)object);
/*     */         } 
/* 218 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 221 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_unitCommercialName_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 226 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 227 */     } catch (XMLReaderException xmle) {
/* 228 */       if (startName != null) {
/* 229 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 231 */       throw xmle;
/*     */     } 
/*     */     
/* 234 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 238 */     BalanceListTO instance = (BalanceListTO)obj;
/*     */     
/* 240 */     context.setNillable(true);
/* 241 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAdjustmentInd(), ns2_adjustmentInd_QNAME, null, writer, context);
/* 242 */     context.setNillable(true);
/* 243 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getBalanceCommercialName(), ns2_balanceCommercialName_QNAME, null, writer, context);
/* 244 */     context.setNillable(true);
/* 245 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getBalanceId()), ns2_balanceId_QNAME, null, writer, context);
/* 246 */     context.setNillable(true);
/* 247 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getBalanceName(), ns2_balanceName_QNAME, null, writer, context);
/* 248 */     context.setNillable(true);
/* 249 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getBalanceSubType(), ns2_balanceSubType_QNAME, null, writer, context);
/* 250 */     context.setNillable(true);
/* 251 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getBalanceType(), ns2_balanceType_QNAME, null, writer, context);
/* 252 */     context.setNillable(true);
/* 253 */     this.myns3__double__double_Double_Serializer.serialize(new Double(instance.getConversionFactor()), ns2_conversionFactor_QNAME, null, writer, context);
/* 254 */     context.setNillable(true);
/* 255 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getDecimalInd(), ns2_decimalInd_QNAME, null, writer, context);
/* 256 */     context.setNillable(true);
/* 257 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTaxInd(), ns2_taxInd_QNAME, null, writer, context);
/* 258 */     context.setNillable(true);
/* 259 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUnitCommercialName(), ns2_unitCommercialName_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\BalanceListTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */