/*    */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime;
/*    */ 
/*    */ import java.rmi.Remote;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.ServiceException;
/*    */ import javax.xml.rpc.handler.HandlerChain;
/*    */ import oracle.j2ee.ws.client.BasicService;
/*    */ import oracle.j2ee.ws.client.HandlerChainImpl;
/*    */ import oracle.j2ee.ws.client.ServiceExceptionImpl;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.base.masterdata.services.IWSBaseMasterData;
/*    */ import ve.com.movilnet.gdis.cia.ws.base.masterdata.services.WSBaseMasterData;
/*    */ 
/*    */ public class WSBaseMasterData_Impl
/*    */   extends BasicService
/*    */   implements WSBaseMasterData {
/*    */   static Class class$(String paramString) {
/*    */     
/* 20 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/* 21 */      } private static final QName serviceName = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "WSBaseMasterData");
/* 22 */   private static final QName ns1_masterdata_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "masterdata"); private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$IWSBaseMasterData;
/* 23 */   private static final Class IWSBaseMasterData_PortClass = class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$IWSBaseMasterData = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.IWSBaseMasterData"); static { if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$IWSBaseMasterData == null); }
/*    */   
/*    */   public WSBaseMasterData_Impl() {
/* 26 */     super(serviceName, new QName[] { ns1_masterdata_QNAME }, (new WSBaseMasterData_SerializerRegistry()).getRegistry());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Remote getPort(QName portName, Class serviceDefInterface) throws ServiceException {
/*    */     try {
/* 35 */       if (portName.equals(ns1_masterdata_QNAME) && serviceDefInterface.equals(IWSBaseMasterData_PortClass))
/*    */       {
/* 37 */         return (Remote)getMasterdata();
/*    */       }
/* 39 */     } catch (Exception e) {
/* 40 */       throw new ServiceExceptionImpl(new LocalizableExceptionAdapter(e));
/*    */     } 
/* 42 */     return super.getPort(portName, serviceDefInterface);
/*    */   }
/*    */   
/*    */   public Remote getPort(Class serviceDefInterface) throws ServiceException {
/*    */     try {
/* 47 */       if (serviceDefInterface.equals(IWSBaseMasterData_PortClass)) {
/* 48 */         return (Remote)getMasterdata();
/*    */       }
/* 50 */     } catch (Exception e) {
/* 51 */       throw new ServiceExceptionImpl(new LocalizableExceptionAdapter(e));
/*    */     } 
/* 53 */     return super.getPort(serviceDefInterface);
/*    */   }
/*    */   
/*    */   public IWSBaseMasterData getMasterdata() {
/* 57 */     String[] roles = new String[0];
/* 58 */     HandlerChainImpl handlerChain = new HandlerChainImpl(getHandlerRegistry().getHandlerChain(ns1_masterdata_QNAME));
/* 59 */     handlerChain.setRoles(roles);
/* 60 */     WSBaseMasterDataSoapHttp_Stub stub = new WSBaseMasterDataSoapHttp_Stub((HandlerChain)handlerChain);
/*    */     try {
/* 62 */       stub._initialize(this.internalTypeRegistry);
/* 63 */     } catch (JAXRPCException e) {
/* 64 */       throw e;
/* 65 */     } catch (Exception e) {
/* 66 */       throw new JAXRPCException(e.getMessage(), e);
/*    */     } 
/* 68 */     return stub;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\runtime\WSBaseMasterData_Impl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */