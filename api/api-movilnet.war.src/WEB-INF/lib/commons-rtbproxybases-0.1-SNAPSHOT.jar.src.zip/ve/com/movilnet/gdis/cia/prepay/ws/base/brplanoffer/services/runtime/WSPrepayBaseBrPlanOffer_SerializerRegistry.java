/*     */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;public class WSPrepayBaseBrPlanOffer_SerializerRegistry extends SerializerRegistryBase implements SerializerConstants { private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO;
/*     */   
/*     */   static Class class$(String paramString) {
/*     */     
/*  21 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*     */   
/*     */   }
/*     */   private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS; private static Class class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS;
/*     */   public TypeMappingRegistry getRegistry() {
/*  26 */     TypeMappingRegistry registry = BasicService.createStandardTypeMappingRegistry();
/*  27 */     TypeMapping mapping11 = registry.getTypeMapping(SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_11).getURIEncoding());
/*  28 */     TypeMapping mapping = registry.getTypeMapping("");
/*     */     
/*  30 */     QName type = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan");
/*  31 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer(type, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  33 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS"), type, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  36 */     QName qName1 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateNumberSpecialServicesResponseTO");
/*  37 */     ValidateNumberSpecialServicesResponseTO_SOAPSerializer validateNumberSpecialServicesResponseTO_SOAPSerializer = new ValidateNumberSpecialServicesResponseTO_SOAPSerializer(qName1, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  39 */     ReferenceableSerializerImpl referenceableSerializerImpl1 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateNumberSpecialServicesResponseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/*  40 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateNumberSpecialServicesResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ValidateNumberSpecialServicesResponseTO"), qName1, (Serializer)referenceableSerializerImpl1);
/*     */ 
/*     */     
/*  43 */     QName qName2 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2Response");
/*  44 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer(qName2, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  46 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS"), qName2, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_RespS_SOAPSerializer);
/*     */ 
/*     */     
/*  49 */     QName qName3 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2Response");
/*  50 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer(qName3, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  52 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS"), qName3, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_RespS_SOAPSerializer);
/*     */ 
/*     */     
/*  55 */     QName qName4 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfile");
/*  56 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer(qName4, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  58 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS"), qName4, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  61 */     QName qName5 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2");
/*  62 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer(qName5, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  64 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS"), qName5, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  67 */     QName qName6 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "RequestTO");
/*  68 */     RequestTO_InterfaceSOAPSerializer requestTO_InterfaceSOAPSerializer = new RequestTO_InterfaceSOAPSerializer(qName6, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  70 */     ReferenceableSerializerImpl referenceableSerializerImpl2 = new ReferenceableSerializerImpl(true, (CombinedSerializer)requestTO_InterfaceSOAPSerializer, SOAPVersion.SOAP_11);
/*  71 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.RequestTO"), qName6, (Serializer)referenceableSerializerImpl2);
/*     */ 
/*     */     
/*  74 */     QName qName7 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanText");
/*  75 */     WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer(qName7, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  77 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS"), qName7, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  80 */     QName qName8 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunal");
/*  81 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer(qName8, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  83 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS"), qName8, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  86 */     QName qName9 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel");
/*  87 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer(qName9, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  89 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS"), qName9, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  92 */     QName qName10 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationService");
/*  93 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer(qName10, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  95 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS"), qName10, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  98 */     QName qName11 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlan");
/*  99 */     WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer(qName11, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 101 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS"), qName11, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 104 */     QName qName12 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateServicesModelRequestTO");
/* 105 */     ValidateServicesModelRequestTO_SOAPSerializer validateServicesModelRequestTO_SOAPSerializer = new ValidateServicesModelRequestTO_SOAPSerializer(qName12, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 107 */     ReferenceableSerializerImpl referenceableSerializerImpl3 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateServicesModelRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 108 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO"), qName12, (Serializer)referenceableSerializerImpl3);
/*     */ 
/*     */     
/* 111 */     QName qName13 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/* 112 */     ApplicationClientTO_SOAPSerializer applicationClientTO_SOAPSerializer = new ApplicationClientTO_SOAPSerializer(qName13, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 114 */     ReferenceableSerializerImpl referenceableSerializerImpl4 = new ReferenceableSerializerImpl(true, (CombinedSerializer)applicationClientTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 115 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), qName13, (Serializer)referenceableSerializerImpl4);
/*     */ 
/*     */     
/* 118 */     QName qName14 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "isChangePlanResponse");
/* 119 */     WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer(qName14, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 121 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS"), qName14, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_isChangePlan_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 124 */     QName qName15 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfBenefitTO");
/* 125 */     QName elemName = new QName("", "item");
/* 126 */     QName elemType = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BenefitTO");
/* 127 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO == null); super(true, true, elemName, elemType, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO"), 1, null, SOAPVersion.SOAP_11);
/*     */     
/*     */     ObjectArraySerializer objectArraySerializer1, objectArraySerializer2;
/* 130 */     ReferenceableSerializerImpl referenceableSerializerImpl5 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer1, SOAPVersion.SOAP_11);
/* 131 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO;"), qName15, (Serializer)referenceableSerializerImpl5);
/*     */ 
/*     */     
/* 134 */     QName qName16 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/* 135 */     QName qName17 = new QName("", "item");
/* 136 */     if (class$java$lang$String == null); super(true, true, qName17, SchemaConstants.QNAME_TYPE_STRING, (QName)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 139 */     ReferenceableSerializerImpl referenceableSerializerImpl6 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer2, SOAPVersion.SOAP_11);
/* 140 */     if (array$Ljava$lang$String == null); registerSerializer((TypeMapping)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), qName16, (Serializer)referenceableSerializerImpl6);
/*     */ 
/*     */     
/* 143 */     QName qName18 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServicesResponse");
/* 144 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer(qName18, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 146 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS"), qName18, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 149 */     QName qName19 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateAffiliationServiceRequestTO");
/* 150 */     ValidateAffiliationServiceRequestTO_SOAPSerializer validateAffiliationServiceRequestTO_SOAPSerializer = new ValidateAffiliationServiceRequestTO_SOAPSerializer(qName19, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 152 */     ReferenceableSerializerImpl referenceableSerializerImpl7 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateAffiliationServiceRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 153 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAffiliationServiceRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAffiliationServiceRequestTO"), qName19, (Serializer)referenceableSerializerImpl7);
/*     */ 
/*     */     
/* 156 */     QName qName20 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateServicesModelRequestTO_v2");
/* 157 */     ValidateServicesModelRequestTO_v2_SOAPSerializer validateServicesModelRequestTO_v2_SOAPSerializer = new ValidateServicesModelRequestTO_v2_SOAPSerializer(qName20, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 159 */     ReferenceableSerializerImpl referenceableSerializerImpl8 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateServicesModelRequestTO_v2_SOAPSerializer, SOAPVersion.SOAP_11);
/* 160 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateServicesModelRequestTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO_v2"), qName20, (Serializer)referenceableSerializerImpl8);
/*     */ 
/*     */     
/* 163 */     QName qName21 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealerResponse");
/* 164 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer(qName21, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 166 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS"), qName21, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 169 */     QName qName22 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanPromotionDealerRequestTO");
/* 170 */     ValidatePlanPromotionDealerRequestTO_SOAPSerializer validatePlanPromotionDealerRequestTO_SOAPSerializer = new ValidatePlanPromotionDealerRequestTO_SOAPSerializer(qName22, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 172 */     ReferenceableSerializerImpl referenceableSerializerImpl9 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanPromotionDealerRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 173 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanPromotionDealerRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanPromotionDealerRequestTO"), qName22, (Serializer)referenceableSerializerImpl9);
/*     */ 
/*     */     
/* 176 */     QName qName23 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanConsejoComunalRequestTO");
/* 177 */     ValidatePlanConsejoComunalRequestTO_SOAPSerializer validatePlanConsejoComunalRequestTO_SOAPSerializer = new ValidatePlanConsejoComunalRequestTO_SOAPSerializer(qName23, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 179 */     ReferenceableSerializerImpl referenceableSerializerImpl10 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanConsejoComunalRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 180 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanConsejoComunalRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanConsejoComunalRequestTO"), qName23, (Serializer)referenceableSerializerImpl10);
/*     */ 
/*     */     
/* 183 */     QName qName24 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanResponseTO");
/* 184 */     ValidatePlanResponseTO_SOAPSerializer validatePlanResponseTO_SOAPSerializer = new ValidatePlanResponseTO_SOAPSerializer(qName24, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 186 */     ReferenceableSerializerImpl referenceableSerializerImpl11 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanResponseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 187 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidatePlanResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ValidatePlanResponseTO"), qName24, (Serializer)referenceableSerializerImpl11);
/*     */ 
/*     */     
/* 190 */     QName qName25 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BRPlanOfferResponseTO");
/* 191 */     BRPlanOfferResponseTO_SOAPSerializer bRPlanOfferResponseTO_SOAPSerializer = new BRPlanOfferResponseTO_SOAPSerializer(qName25, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 193 */     ReferenceableSerializerImpl referenceableSerializerImpl12 = new ReferenceableSerializerImpl(true, (CombinedSerializer)bRPlanOfferResponseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 194 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$BRPlanOfferResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.BRPlanOfferResponseTO"), qName25, (Serializer)referenceableSerializerImpl12);
/*     */ 
/*     */     
/* 197 */     QName qName26 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModelResponse");
/* 198 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer(qName26, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 200 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS"), qName26, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 203 */     QName qName27 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BooleanResponseTO");
/* 204 */     BooleanResponseTO_SOAPSerializer booleanResponseTO_SOAPSerializer = new BooleanResponseTO_SOAPSerializer(qName27, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 206 */     ReferenceableSerializerImpl referenceableSerializerImpl13 = new ReferenceableSerializerImpl(true, (CombinedSerializer)booleanResponseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 207 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO"), qName27, (Serializer)referenceableSerializerImpl13);
/*     */ 
/*     */     
/* 210 */     QName qName28 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAuthorisedProfileResponse");
/* 211 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer(qName28, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 213 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS"), qName28, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 216 */     QName qName29 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModelResponse");
/* 217 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer(qName29, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 219 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS"), qName29, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 222 */     QName qName30 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel_v2");
/* 223 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer(qName30, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 225 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS"), qName30, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_v2_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 228 */     QName qName31 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanModelRequestTO_v2");
/* 229 */     ValidatePlanModelRequestTO_v2_SOAPSerializer validatePlanModelRequestTO_v2_SOAPSerializer = new ValidatePlanModelRequestTO_v2_SOAPSerializer(qName31, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 231 */     ReferenceableSerializerImpl referenceableSerializerImpl14 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanModelRequestTO_v2_SOAPSerializer, SOAPVersion.SOAP_11);
/* 232 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO_v2"), qName31, (Serializer)referenceableSerializerImpl14);
/*     */ 
/*     */     
/* 235 */     QName qName32 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ResponseTO");
/* 236 */     ResponseTO_InterfaceSOAPSerializer responseTO_InterfaceSOAPSerializer = new ResponseTO_InterfaceSOAPSerializer(qName32, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 238 */     ReferenceableSerializerImpl referenceableSerializerImpl15 = new ReferenceableSerializerImpl(true, (CombinedSerializer)responseTO_InterfaceSOAPSerializer, SOAPVersion.SOAP_11);
/* 239 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ResponseTO"), qName32, (Serializer)referenceableSerializerImpl15);
/*     */ 
/*     */     
/* 242 */     QName qName33 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServices");
/* 243 */     WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer(qName33, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 245 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS"), qName33, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 248 */     QName qName34 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanServicesRequestTO");
/* 249 */     ValidatePlanServicesRequestTO_SOAPSerializer validatePlanServicesRequestTO_SOAPSerializer = new ValidatePlanServicesRequestTO_SOAPSerializer(qName34, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 251 */     ReferenceableSerializerImpl referenceableSerializerImpl16 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanServicesRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 252 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanServicesRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanServicesRequestTO"), qName34, (Serializer)referenceableSerializerImpl16);
/*     */ 
/*     */     
/* 255 */     QName qName35 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateAuthorisedProfileResponseTO");
/* 256 */     ValidateAuthorisedProfileResponseTO_SOAPSerializer validateAuthorisedProfileResponseTO_SOAPSerializer = new ValidateAuthorisedProfileResponseTO_SOAPSerializer(qName35, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 258 */     ReferenceableSerializerImpl referenceableSerializerImpl17 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateAuthorisedProfileResponseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 259 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ValidateAuthorisedProfileResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ValidateAuthorisedProfileResponseTO"), qName35, (Serializer)referenceableSerializerImpl17);
/*     */ 
/*     */     
/* 262 */     QName qName36 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanConsejoComunalResponse");
/* 263 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer(qName36, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 265 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS"), qName36, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 268 */     QName qName37 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanServices");
/* 269 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer(qName37, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 271 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS"), qName37, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanServices_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 274 */     QName qName38 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateNumberSpecialServicesRequestTO");
/* 275 */     ValidateNumberSpecialServicesRequestTO_SOAPSerializer validateNumberSpecialServicesRequestTO_SOAPSerializer = new ValidateNumberSpecialServicesRequestTO_SOAPSerializer(qName38, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 277 */     ReferenceableSerializerImpl referenceableSerializerImpl18 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateNumberSpecialServicesRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 278 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateNumberSpecialServicesRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateNumberSpecialServicesRequestTO"), qName38, (Serializer)referenceableSerializerImpl18);
/*     */ 
/*     */     
/* 281 */     QName qName39 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanRequestTO_v2");
/* 282 */     ValidatePlanRequestTO_v2_SOAPSerializer validatePlanRequestTO_v2_SOAPSerializer = new ValidatePlanRequestTO_v2_SOAPSerializer(qName39, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 284 */     ReferenceableSerializerImpl referenceableSerializerImpl19 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanRequestTO_v2_SOAPSerializer, SOAPVersion.SOAP_11);
/* 285 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO_v2"), qName39, (Serializer)referenceableSerializerImpl19);
/*     */ 
/*     */     
/* 288 */     QName qName40 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/* 289 */     SecurityTO_SOAPSerializer securityTO_SOAPSerializer = new SecurityTO_SOAPSerializer(qName40, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 291 */     ReferenceableSerializerImpl referenceableSerializerImpl20 = new ReferenceableSerializerImpl(true, (CombinedSerializer)securityTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 292 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), qName40, (Serializer)referenceableSerializerImpl20);
/*     */ 
/*     */     
/* 295 */     QName qName41 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateChangePlanTextResponse");
/* 296 */     WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer(qName41, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 298 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS"), qName41, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateChangePlanText_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 301 */     QName qName42 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionServiceResponse");
/* 302 */     WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer(qName42, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 304 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS"), qName42, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 307 */     QName qName43 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityServicesModel_v2");
/* 308 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer(qName43, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 310 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS"), qName43, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_v2_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 313 */     QName qName44 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanPromotionDealer");
/* 314 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer(qName44, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 316 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS"), qName44, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanPromotionDealer_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 319 */     QName qName45 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateAuthorisedProfileRequestTO");
/* 320 */     ValidateAuthorisedProfileRequestTO_SOAPSerializer validateAuthorisedProfileRequestTO_SOAPSerializer = new ValidateAuthorisedProfileRequestTO_SOAPSerializer(qName45, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 322 */     ReferenceableSerializerImpl referenceableSerializerImpl21 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateAuthorisedProfileRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 323 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateAuthorisedProfileRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAuthorisedProfileRequestTO"), qName45, (Serializer)referenceableSerializerImpl21);
/*     */ 
/*     */     
/* 326 */     QName qName46 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateDisConnectionService");
/* 327 */     WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer(qName46, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 329 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS"), qName46, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 332 */     QName qName47 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlan_v2Response");
/* 333 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer(qName47, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 335 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS"), qName47, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_v2_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 338 */     QName qName48 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanModelRequestTO");
/* 339 */     ValidatePlanModelRequestTO_SOAPSerializer validatePlanModelRequestTO_SOAPSerializer = new ValidatePlanModelRequestTO_SOAPSerializer(qName48, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 341 */     ReferenceableSerializerImpl referenceableSerializerImpl22 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanModelRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 342 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanModelRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO"), qName48, (Serializer)referenceableSerializerImpl22);
/*     */ 
/*     */     
/* 345 */     QName qName49 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateCompatibilityPlanModel");
/* 346 */     WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer(qName49, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 348 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS"), qName49, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 351 */     QName qName50 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateChangeBRPlanRequestTO");
/* 352 */     ValidateChangeBRPlanRequestTO_SOAPSerializer validateChangeBRPlanRequestTO_SOAPSerializer = new ValidateChangeBRPlanRequestTO_SOAPSerializer(qName50, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 354 */     ReferenceableSerializerImpl referenceableSerializerImpl23 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateChangeBRPlanRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 355 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangeBRPlanRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangeBRPlanRequestTO"), qName50, (Serializer)referenceableSerializerImpl23);
/*     */ 
/*     */     
/* 358 */     QName qName51 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateNumberSpecialServicesResponse");
/* 359 */     WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer(qName51, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 361 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS"), qName51, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateNumberSpecialServices_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 364 */     QName qName52 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BenefitTO");
/* 365 */     BenefitTO_SOAPSerializer benefitTO_SOAPSerializer = new BenefitTO_SOAPSerializer(qName52, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 367 */     ReferenceableSerializerImpl referenceableSerializerImpl24 = new ReferenceableSerializerImpl(true, (CombinedSerializer)benefitTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 368 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO"), qName52, (Serializer)referenceableSerializerImpl24);
/*     */ 
/*     */     
/* 371 */     QName qName53 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanRequestTO");
/* 372 */     ValidatePlanRequestTO_SOAPSerializer validatePlanRequestTO_SOAPSerializer = new ValidatePlanRequestTO_SOAPSerializer(qName53, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 374 */     ReferenceableSerializerImpl referenceableSerializerImpl25 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validatePlanRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 375 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO"), qName53, (Serializer)referenceableSerializerImpl25);
/*     */ 
/*     */     
/* 378 */     QName qName54 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateDisConnectionServiceRequestTO");
/* 379 */     ValidateDisConnectionServiceRequestTO_SOAPSerializer validateDisConnectionServiceRequestTO_SOAPSerializer = new ValidateDisConnectionServiceRequestTO_SOAPSerializer(qName54, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 381 */     ReferenceableSerializerImpl referenceableSerializerImpl26 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateDisConnectionServiceRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 382 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateDisConnectionServiceRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateDisConnectionServiceRequestTO"), qName54, (Serializer)referenceableSerializerImpl26);
/*     */ 
/*     */     
/* 385 */     QName qName55 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidateChangePlanTextRequestTO");
/* 386 */     ValidateChangePlanTextRequestTO_SOAPSerializer validateChangePlanTextRequestTO_SOAPSerializer = new ValidateChangePlanTextRequestTO_SOAPSerializer(qName55, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 388 */     ReferenceableSerializerImpl referenceableSerializerImpl27 = new ReferenceableSerializerImpl(true, (CombinedSerializer)validateChangePlanTextRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 389 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidateChangePlanTextRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidateChangePlanTextRequestTO"), qName55, (Serializer)referenceableSerializerImpl27);
/*     */ 
/*     */     
/* 392 */     QName qName56 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validateAffiliationServiceResponse");
/* 393 */     WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer(qName56, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 395 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS"), qName56, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validateAffiliationService_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 398 */     QName qName57 = new QName("http://services.brplanoffer.base.ws.prepay.cia.gdis.movilnet.com.ve/", "validatePlanResponse");
/* 399 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer(qName57, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 401 */     if (class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS, class$ve$com$movilnet$gdis$cia$prepay$ws$base$brplanoffer$services$runtime$WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS = class$("ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS"), qName57, (Serializer)wSPrepayBaseBrPlanOfferSoapHttp_validatePlan_RespS_SOAPSerializer);
/*     */     
/* 403 */     WSPrepayBaseBrPlanOffer_SerializerRegistry12 internal12Registry = new WSPrepayBaseBrPlanOffer_SerializerRegistry12();
/* 404 */     return internal12Registry.getRegistry(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void registerSerializer(TypeMapping mapping, Class javaType, QName xmlType, Serializer ser) {
/* 409 */     mapping.register(javaType, xmlType, (SerializerFactory)new SingletonSerializerFactory(ser), (DeserializerFactory)new SingletonDeserializerFactory((Deserializer)ser));
/*     */   } }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOffer_SerializerRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */