/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.StateTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.StateTO_SOAPBuilder;
/*     */ 
/*     */ public class StateTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_stateCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "stateCode");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_stateName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "stateName"); private static final int mystateCode_INDEX = 0;
/*     */   private static final int mystateName_INDEX = 1;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public StateTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  27 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  31 */     if (class$java$lang$String == null); ((StateTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  36 */     StateTO instance = new StateTO();
/*  37 */     StateTO_SOAPBuilder builder = null;
/*     */     
/*  39 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  42 */     reader.nextElementContent();
/*  43 */     QName startName = reader.getName();
/*  44 */     for (int i = 0; i < 2; i++) {
/*  45 */       QName elementName = reader.getName();
/*  46 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  49 */       if (matchQName(elementName, ns2_stateCode_QNAME)) {
/*  50 */         context.setNillable(true);
/*  51 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_stateCode_QNAME, reader, context);
/*  52 */         if (member instanceof SOAPDeserializationState) {
/*  53 */           if (builder == null) {
/*  54 */             builder = new StateTO_SOAPBuilder();
/*     */           }
/*  56 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  57 */           isComplete = false;
/*  58 */         } else if (member != null) {
/*  59 */           instance.setStateCode((String)member);
/*     */         } 
/*  61 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  64 */       else if (matchQName(elementName, ns2_stateName_QNAME)) {
/*  65 */         context.setNillable(true);
/*  66 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_stateName_QNAME, reader, context);
/*  67 */         if (object instanceof SOAPDeserializationState) {
/*  68 */           if (builder == null) {
/*  69 */             builder = new StateTO_SOAPBuilder();
/*     */           }
/*  71 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  72 */           isComplete = false;
/*  73 */         } else if (object != null) {
/*  74 */           instance.setStateName((String)object);
/*     */         } 
/*  76 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/*  79 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_stateName_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/*  84 */       XMLReaderUtil.verifyReaderState(reader, 2);
/*  85 */     } catch (XMLReaderException xmle) {
/*  86 */       if (startName != null) {
/*  87 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/*  89 */       throw xmle;
/*     */     } 
/*     */     
/*  92 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/*  96 */     StateTO instance = (StateTO)obj;
/*     */     
/*  98 */     context.setNillable(true);
/*  99 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getStateCode(), ns2_stateCode_QNAME, null, writer, context);
/* 100 */     context.setNillable(true);
/* 101 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getStateName(), ns2_stateName_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\StateTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */