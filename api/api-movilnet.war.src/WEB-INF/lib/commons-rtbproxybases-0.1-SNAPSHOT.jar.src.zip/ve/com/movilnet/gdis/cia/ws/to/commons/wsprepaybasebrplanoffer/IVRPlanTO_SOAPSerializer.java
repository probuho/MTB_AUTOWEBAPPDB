/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.IVRPlanTO_SOAPBuilder;
/*     */ 
/*     */ public class IVRPlanTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_accumulatedUsageInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "accumulatedUsageInd");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_cosNameSuffix_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cosNameSuffix");
/*  23 */   private static final QName ns2_minutosIncluidos_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "minutosIncluidos");
/*  24 */   private static final QName ns3_int_TYPE_QNAME = SchemaConstants.QNAME_TYPE_INT;
/*     */   private CombinedSerializer myns3__int__int_Int_Serializer;
/*  26 */   private static final QName ns2_nombreComercial_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "nombreComercial");
/*  27 */   private static final QName ns2_planCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCode");
/*  28 */   private static final QName ns2_planType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planType");
/*  29 */   private static final QName ns2_planUnitType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planUnitType");
/*  30 */   private static final QName ns2_rentaBasicaInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "rentaBasicaInd");
/*  31 */   private static final QName ns2_smsIncluidos_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "smsIncluidos"); private static final int myaccumulatedUsageInd_INDEX = 0;
/*     */   private static final int mycosNameSuffix_INDEX = 1;
/*     */   private static final int myminutosIncluidos_INDEX = 2;
/*     */   private static final int mynombreComercial_INDEX = 3;
/*     */   private static final int myplanCode_INDEX = 4;
/*     */   private static final int myplanType_INDEX = 5;
/*     */   private static final int myplanUnitType_INDEX = 6;
/*     */   private static final int myrentaBasicaInd_INDEX = 7;
/*     */   private static final int mysmsIncluidos_INDEX = 8;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public IVRPlanTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  43 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  47 */     if (class$java$lang$String == null); ((IVRPlanTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  48 */     this.myns3__int__int_Int_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), int.class, ns3_int_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  53 */     IVRPlanTO instance = new IVRPlanTO();
/*  54 */     IVRPlanTO_SOAPBuilder builder = null;
/*     */     
/*  56 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  59 */     reader.nextElementContent();
/*  60 */     QName startName = reader.getName();
/*  61 */     for (int i = 0; i < 9; i++) {
/*  62 */       QName elementName = reader.getName();
/*  63 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  66 */       if (matchQName(elementName, ns2_accumulatedUsageInd_QNAME)) {
/*  67 */         context.setNillable(true);
/*  68 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_accumulatedUsageInd_QNAME, reader, context);
/*  69 */         if (member instanceof SOAPDeserializationState) {
/*  70 */           if (builder == null) {
/*  71 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/*  73 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  74 */           isComplete = false;
/*  75 */         } else if (member != null) {
/*  76 */           instance.setAccumulatedUsageInd((String)member);
/*     */         } 
/*  78 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  81 */       else if (matchQName(elementName, ns2_cosNameSuffix_QNAME)) {
/*  82 */         context.setNillable(true);
/*  83 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cosNameSuffix_QNAME, reader, context);
/*  84 */         if (object instanceof SOAPDeserializationState) {
/*  85 */           if (builder == null) {
/*  86 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/*  88 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  89 */           isComplete = false;
/*  90 */         } else if (object != null) {
/*  91 */           instance.setCosNameSuffix((String)object);
/*     */         } 
/*  93 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  96 */       else if (matchQName(elementName, ns2_minutosIncluidos_QNAME)) {
/*  97 */         context.setNillable(true);
/*  98 */         Object object = this.myns3__int__int_Int_Serializer.deserialize(ns2_minutosIncluidos_QNAME, reader, context);
/*  99 */         if (object instanceof SOAPDeserializationState) {
/* 100 */           if (builder == null) {
/* 101 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/* 103 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 104 */           isComplete = false;
/* 105 */         } else if (object != null) {
/* 106 */           instance.setMinutosIncluidos(((Integer)object).intValue());
/*     */         } 
/* 108 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 111 */       else if (matchQName(elementName, ns2_nombreComercial_QNAME)) {
/* 112 */         context.setNillable(true);
/* 113 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_nombreComercial_QNAME, reader, context);
/* 114 */         if (object instanceof SOAPDeserializationState) {
/* 115 */           if (builder == null) {
/* 116 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/* 118 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 119 */           isComplete = false;
/* 120 */         } else if (object != null) {
/* 121 */           instance.setNombreComercial((String)object);
/*     */         } 
/* 123 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 126 */       else if (matchQName(elementName, ns2_planCode_QNAME)) {
/* 127 */         context.setNillable(true);
/* 128 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCode_QNAME, reader, context);
/* 129 */         if (object instanceof SOAPDeserializationState) {
/* 130 */           if (builder == null) {
/* 131 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/* 133 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 134 */           isComplete = false;
/* 135 */         } else if (object != null) {
/* 136 */           instance.setPlanCode((String)object);
/*     */         } 
/* 138 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 141 */       else if (matchQName(elementName, ns2_planType_QNAME)) {
/* 142 */         context.setNillable(true);
/* 143 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planType_QNAME, reader, context);
/* 144 */         if (object instanceof SOAPDeserializationState) {
/* 145 */           if (builder == null) {
/* 146 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/* 148 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 149 */           isComplete = false;
/* 150 */         } else if (object != null) {
/* 151 */           instance.setPlanType((String)object);
/*     */         } 
/* 153 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 156 */       else if (matchQName(elementName, ns2_planUnitType_QNAME)) {
/* 157 */         context.setNillable(true);
/* 158 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planUnitType_QNAME, reader, context);
/* 159 */         if (object instanceof SOAPDeserializationState) {
/* 160 */           if (builder == null) {
/* 161 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/* 163 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 164 */           isComplete = false;
/* 165 */         } else if (object != null) {
/* 166 */           instance.setPlanUnitType((String)object);
/*     */         } 
/* 168 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 171 */       else if (matchQName(elementName, ns2_rentaBasicaInd_QNAME)) {
/* 172 */         context.setNillable(true);
/* 173 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_rentaBasicaInd_QNAME, reader, context);
/* 174 */         if (object instanceof SOAPDeserializationState) {
/* 175 */           if (builder == null) {
/* 176 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/* 178 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 179 */           isComplete = false;
/* 180 */         } else if (object != null) {
/* 181 */           instance.setRentaBasicaInd((String)object);
/*     */         } 
/* 183 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 186 */       else if (matchQName(elementName, ns2_smsIncluidos_QNAME)) {
/* 187 */         context.setNillable(true);
/* 188 */         Object object = this.myns3__int__int_Int_Serializer.deserialize(ns2_smsIncluidos_QNAME, reader, context);
/* 189 */         if (object instanceof SOAPDeserializationState) {
/* 190 */           if (builder == null) {
/* 191 */             builder = new IVRPlanTO_SOAPBuilder();
/*     */           }
/* 193 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 194 */           isComplete = false;
/* 195 */         } else if (object != null) {
/* 196 */           instance.setSmsIncluidos(((Integer)object).intValue());
/*     */         } 
/* 198 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 201 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_smsIncluidos_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 206 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 207 */     } catch (XMLReaderException xmle) {
/* 208 */       if (startName != null) {
/* 209 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 211 */       throw xmle;
/*     */     } 
/*     */     
/* 214 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 218 */     IVRPlanTO instance = (IVRPlanTO)obj;
/*     */     
/* 220 */     context.setNillable(true);
/* 221 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAccumulatedUsageInd(), ns2_accumulatedUsageInd_QNAME, null, writer, context);
/* 222 */     context.setNillable(true);
/* 223 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCosNameSuffix(), ns2_cosNameSuffix_QNAME, null, writer, context);
/* 224 */     context.setNillable(true);
/* 225 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getMinutosIncluidos()), ns2_minutosIncluidos_QNAME, null, writer, context);
/* 226 */     context.setNillable(true);
/* 227 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getNombreComercial(), ns2_nombreComercial_QNAME, null, writer, context);
/* 228 */     context.setNillable(true);
/* 229 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCode(), ns2_planCode_QNAME, null, writer, context);
/* 230 */     context.setNillable(true);
/* 231 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanType(), ns2_planType_QNAME, null, writer, context);
/* 232 */     context.setNillable(true);
/* 233 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanUnitType(), ns2_planUnitType_QNAME, null, writer, context);
/* 234 */     context.setNillable(true);
/* 235 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getRentaBasicaInd(), ns2_rentaBasicaInd_QNAME, null, writer, context);
/* 236 */     context.setNillable(true);
/* 237 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getSmsIncluidos()), ns2_smsIncluidos_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\IVRPlanTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */