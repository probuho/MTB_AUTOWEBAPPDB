/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoolingReasonTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private CoolingReasonTO _instance;
/*    */   private int extensionDaysForCycleLife;
/*    */   private String reasonCode;
/*    */   private String reasonDesc;
/*    */   private String specialCycleLifeInd;
/*    */   private static final int myextensionDaysForCycleLife_INDEX = 0;
/*    */   private static final int myreasonCode_INDEX = 1;
/*    */   private static final int myreasonDesc_INDEX = 2;
/*    */   private static final int myspecialCycleLifeInd_INDEX = 3;
/*    */   
/*    */   public void setExtensionDaysForCycleLife(int extensionDaysForCycleLife) {
/* 27 */     this.extensionDaysForCycleLife = extensionDaysForCycleLife;
/*    */   }
/*    */   
/*    */   public void setReasonCode(String reasonCode) {
/* 31 */     this.reasonCode = reasonCode;
/*    */   }
/*    */   
/*    */   public void setReasonDesc(String reasonDesc) {
/* 35 */     this.reasonDesc = reasonDesc;
/*    */   }
/*    */   
/*    */   public void setSpecialCycleLifeInd(String specialCycleLifeInd) {
/* 39 */     this.specialCycleLifeInd = specialCycleLifeInd;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 43 */     switch (memberIndex) {
/*    */       case 0:
/* 45 */         return 6;
/*    */       case 1:
/* 47 */         return 6;
/*    */       case 2:
/* 49 */         return 6;
/*    */       case 3:
/* 51 */         return 6;
/*    */     } 
/* 53 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 62 */       switch (index) {
/*    */         case 0:
/* 64 */           this._instance.setExtensionDaysForCycleLife(((Integer)memberValue).intValue());
/*    */           return;
/*    */         case 1:
/* 67 */           this._instance.setReasonCode((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 70 */           this._instance.setReasonDesc((String)memberValue);
/*    */           return;
/*    */         case 3:
/* 73 */           this._instance.setSpecialCycleLifeInd((String)memberValue);
/*    */           return;
/*    */       } 
/* 76 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 79 */     catch (RuntimeException e) {
/* 80 */       throw e;
/*    */     }
/* 82 */     catch (Exception e) {
/* 83 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 91 */     this._instance = (CoolingReasonTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 95 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\CoolingReasonTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */