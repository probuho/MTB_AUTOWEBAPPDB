/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlcoCosTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String[] alcoList;
/*    */   protected String[] cosList;
/*    */   
/*    */   public String[] getAlcoList() {
/* 18 */     return this.alcoList;
/*    */   }
/*    */   
/*    */   public void setAlcoList(String[] alcoList) {
/* 22 */     this.alcoList = alcoList;
/*    */   }
/*    */   
/*    */   public String[] getCosList() {
/* 26 */     return this.cosList;
/*    */   }
/*    */   
/*    */   public void setCosList(String[] cosList) {
/* 30 */     this.cosList = cosList;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\AlcoCosTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */