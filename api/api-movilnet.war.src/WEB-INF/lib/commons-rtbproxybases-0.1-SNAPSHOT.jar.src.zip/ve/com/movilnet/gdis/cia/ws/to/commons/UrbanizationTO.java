/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrbanizationTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String cityId;
/*    */   protected int urbId;
/*    */   protected String urbName;
/*    */   
/*    */   public String getCityId() {
/* 19 */     return this.cityId;
/*    */   }
/*    */   
/*    */   public void setCityId(String cityId) {
/* 23 */     this.cityId = cityId;
/*    */   }
/*    */   
/*    */   public int getUrbId() {
/* 27 */     return this.urbId;
/*    */   }
/*    */   
/*    */   public void setUrbId(int urbId) {
/* 31 */     this.urbId = urbId;
/*    */   }
/*    */   
/*    */   public String getUrbName() {
/* 35 */     return this.urbName;
/*    */   }
/*    */   
/*    */   public void setUrbName(String urbName) {
/* 39 */     this.urbName = urbName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\UrbanizationTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */