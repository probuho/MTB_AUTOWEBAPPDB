/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BenefitTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String balanceName;
/*    */   protected String chargeCode;
/*    */   protected String comment;
/*    */   protected Integer expirationDays;
/*    */   protected String operation;
/*    */   protected Long quantity;
/*    */   protected String unitType;
/*    */   
/*    */   public String getBalanceName() {
/* 23 */     return this.balanceName;
/*    */   }
/*    */   
/*    */   public void setBalanceName(String balanceName) {
/* 27 */     this.balanceName = balanceName;
/*    */   }
/*    */   
/*    */   public String getChargeCode() {
/* 31 */     return this.chargeCode;
/*    */   }
/*    */   
/*    */   public void setChargeCode(String chargeCode) {
/* 35 */     this.chargeCode = chargeCode;
/*    */   }
/*    */   
/*    */   public String getComment() {
/* 39 */     return this.comment;
/*    */   }
/*    */   
/*    */   public void setComment(String comment) {
/* 43 */     this.comment = comment;
/*    */   }
/*    */   
/*    */   public Integer getExpirationDays() {
/* 47 */     return this.expirationDays;
/*    */   }
/*    */   
/*    */   public void setExpirationDays(Integer expirationDays) {
/* 51 */     this.expirationDays = expirationDays;
/*    */   }
/*    */   
/*    */   public String getOperation() {
/* 55 */     return this.operation;
/*    */   }
/*    */   
/*    */   public void setOperation(String operation) {
/* 59 */     this.operation = operation;
/*    */   }
/*    */   
/*    */   public Long getQuantity() {
/* 63 */     return this.quantity;
/*    */   }
/*    */   
/*    */   public void setQuantity(Long quantity) {
/* 67 */     this.quantity = quantity;
/*    */   }
/*    */   
/*    */   public String getUnitType() {
/* 71 */     return this.unitType;
/*    */   }
/*    */   
/*    */   public void setUnitType(String unitType) {
/* 75 */     this.unitType = unitType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\BenefitTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */