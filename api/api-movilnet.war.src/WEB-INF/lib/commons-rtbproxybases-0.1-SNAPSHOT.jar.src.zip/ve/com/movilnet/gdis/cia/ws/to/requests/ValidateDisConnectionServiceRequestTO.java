/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateDisConnectionServiceRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String serviceCode;
/*    */   protected String status;
/*    */   protected long subscriberId;
/*    */   protected String userId;
/*    */   
/*    */   public String getServiceCode() {
/* 20 */     return this.serviceCode;
/*    */   }
/*    */   
/*    */   public void setServiceCode(String serviceCode) {
/* 24 */     this.serviceCode = serviceCode;
/*    */   }
/*    */   
/*    */   public String getStatus() {
/* 28 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(String status) {
/* 32 */     this.status = status;
/*    */   }
/*    */   
/*    */   public long getSubscriberId() {
/* 36 */     return this.subscriberId;
/*    */   }
/*    */   
/*    */   public void setSubscriberId(long subscriberId) {
/* 40 */     this.subscriberId = subscriberId;
/*    */   }
/*    */   
/*    */   public String getUserId() {
/* 44 */     return this.userId;
/*    */   }
/*    */   
/*    */   public void setUserId(String userId) {
/* 48 */     this.userId = userId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidateDisConnectionServiceRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */