/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.ValidateNumberSpecialServicesResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.runtime.ValidateNumberSpecialServicesResponseTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidateNumberSpecialServicesResponseTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_executionTime_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "executionTime");
/*  20 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  22 */   private static final QName ns2_origin_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "origin");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  25 */   private static final QName ns2_responseCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseCode");
/*  26 */   private static final QName ns2_responseDescription_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseDescription");
/*  27 */   private static final QName ns2_responseMessage_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseMessage");
/*  28 */   private static final QName ns2_responseSubCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseSubCode");
/*  29 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  30 */   private static final QName ns2_activationFees_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "activationFees");
/*  31 */   private static final QName ns2_ArrayOfBenefitTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfBenefitTO");
/*     */   private CombinedSerializer myns2_ArrayOfBenefitTO__BenefitTOArray_LiteralSerializer1;
/*  33 */   private static final QName ns2_positionOnTheList_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "positionOnTheList");
/*  34 */   private static final QName ns4_short_TYPE_QNAME = SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_11).getQNameTypeShort();
/*     */   private CombinedSerializer myns4__short__java_lang_Short_Short_Serializer;
/*  36 */   private static final QName ns2_result_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "result");
/*  37 */   private static final QName ns3_boolean_TYPE_QNAME = SchemaConstants.QNAME_TYPE_BOOLEAN; private CombinedSerializer myns3__boolean__boolean_Boolean_Serializer; private static final int myexecutionTime_INDEX = 0; private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static final int myactivationFees_INDEX = 7;
/*     */   private static final int mypositionOnTheList_INDEX = 8;
/*     */   private static final int myresult_INDEX = 9;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO;
/*     */   private static Class class$java$lang$Short;
/*     */   
/*     */   public ValidateNumberSpecialServicesResponseTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  51 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  55 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*  56 */     if (class$java$lang$String == null); ((ValidateNumberSpecialServicesResponseTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  57 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO == null); ((ValidateNumberSpecialServicesResponseTO_SOAPSerializer)registry).myns2_ArrayOfBenefitTO__BenefitTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$BenefitTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.BenefitTO;"), ns2_ArrayOfBenefitTO_TYPE_QNAME);
/*  58 */     if (class$java$lang$Short == null); ((ValidateNumberSpecialServicesResponseTO_SOAPSerializer)registry).myns4__short__java_lang_Short_Short_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$Short, class$java$lang$Short = class$("java.lang.Short"), ns4_short_TYPE_QNAME);
/*  59 */     this.myns3__boolean__boolean_Boolean_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), boolean.class, ns3_boolean_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  64 */     ValidateNumberSpecialServicesResponseTO instance = new ValidateNumberSpecialServicesResponseTO();
/*  65 */     ValidateNumberSpecialServicesResponseTO_SOAPBuilder builder = null;
/*     */     
/*  67 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  70 */     reader.nextElementContent();
/*  71 */     QName startName = reader.getName();
/*  72 */     for (int i = 0; i < 10; i++) {
/*  73 */       QName elementName = reader.getName();
/*  74 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  77 */       if (matchQName(elementName, ns2_executionTime_QNAME)) {
/*  78 */         context.setNillable(true);
/*  79 */         Object member = this.myns3__long__long_Long_Serializer.deserialize(ns2_executionTime_QNAME, reader, context);
/*  80 */         if (member instanceof SOAPDeserializationState) {
/*  81 */           if (builder == null) {
/*  82 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/*  84 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  85 */           isComplete = false;
/*  86 */         } else if (member != null) {
/*  87 */           instance.setExecutionTime(((Long)member).longValue());
/*     */         } 
/*  89 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  92 */       else if (matchQName(elementName, ns2_origin_QNAME)) {
/*  93 */         context.setNillable(true);
/*  94 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_origin_QNAME, reader, context);
/*  95 */         if (object instanceof SOAPDeserializationState) {
/*  96 */           if (builder == null) {
/*  97 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/*  99 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 100 */           isComplete = false;
/* 101 */         } else if (object != null) {
/* 102 */           instance.setOrigin((String)object);
/*     */         } 
/* 104 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 107 */       else if (matchQName(elementName, ns2_responseCode_QNAME)) {
/* 108 */         context.setNillable(true);
/* 109 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseCode_QNAME, reader, context);
/* 110 */         if (object instanceof SOAPDeserializationState) {
/* 111 */           if (builder == null) {
/* 112 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 114 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 115 */           isComplete = false;
/* 116 */         } else if (object != null) {
/* 117 */           instance.setResponseCode((String)object);
/*     */         } 
/* 119 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 122 */       else if (matchQName(elementName, ns2_responseDescription_QNAME)) {
/* 123 */         context.setNillable(true);
/* 124 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseDescription_QNAME, reader, context);
/* 125 */         if (object instanceof SOAPDeserializationState) {
/* 126 */           if (builder == null) {
/* 127 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 129 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 130 */           isComplete = false;
/* 131 */         } else if (object != null) {
/* 132 */           instance.setResponseDescription((String)object);
/*     */         } 
/* 134 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 137 */       else if (matchQName(elementName, ns2_responseMessage_QNAME)) {
/* 138 */         context.setNillable(true);
/* 139 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseMessage_QNAME, reader, context);
/* 140 */         if (object instanceof SOAPDeserializationState) {
/* 141 */           if (builder == null) {
/* 142 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 144 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 145 */           isComplete = false;
/* 146 */         } else if (object != null) {
/* 147 */           instance.setResponseMessage((String)object);
/*     */         } 
/* 149 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 152 */       else if (matchQName(elementName, ns2_responseSubCode_QNAME)) {
/* 153 */         context.setNillable(true);
/* 154 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseSubCode_QNAME, reader, context);
/* 155 */         if (object instanceof SOAPDeserializationState) {
/* 156 */           if (builder == null) {
/* 157 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 159 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 160 */           isComplete = false;
/* 161 */         } else if (object != null) {
/* 162 */           instance.setResponseSubCode((String)object);
/*     */         } 
/* 164 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 167 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 168 */         context.setNillable(true);
/* 169 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 170 */         if (object instanceof SOAPDeserializationState) {
/* 171 */           if (builder == null) {
/* 172 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 174 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 175 */           isComplete = false;
/* 176 */         } else if (object != null) {
/* 177 */           instance.setTransactionId((String)object);
/*     */         } 
/* 179 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 182 */       else if (matchQName(elementName, ns2_activationFees_QNAME)) {
/* 183 */         context.setNillable(true);
/* 184 */         Object object = this.myns2_ArrayOfBenefitTO__BenefitTOArray_LiteralSerializer1.deserialize(ns2_activationFees_QNAME, reader, context);
/* 185 */         if (object instanceof SOAPDeserializationState) {
/* 186 */           if (builder == null) {
/* 187 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 189 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 190 */           isComplete = false;
/* 191 */         } else if (object != null) {
/* 192 */           instance.setActivationFees((BenefitTO[])object);
/*     */         } 
/* 194 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 197 */       else if (matchQName(elementName, ns2_positionOnTheList_QNAME)) {
/* 198 */         context.setNillable(true);
/* 199 */         Object object = this.myns4__short__java_lang_Short_Short_Serializer.deserialize(ns2_positionOnTheList_QNAME, reader, context);
/* 200 */         if (object instanceof SOAPDeserializationState) {
/* 201 */           if (builder == null) {
/* 202 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 204 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 205 */           isComplete = false;
/* 206 */         } else if (object != null) {
/* 207 */           instance.setPositionOnTheList((Short)object);
/*     */         } 
/* 209 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 212 */       else if (matchQName(elementName, ns2_result_QNAME)) {
/* 213 */         context.setNillable(true);
/* 214 */         Object object = this.myns3__boolean__boolean_Boolean_Serializer.deserialize(ns2_result_QNAME, reader, context);
/* 215 */         if (object instanceof SOAPDeserializationState) {
/* 216 */           if (builder == null) {
/* 217 */             builder = new ValidateNumberSpecialServicesResponseTO_SOAPBuilder();
/*     */           }
/* 219 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 220 */           isComplete = false;
/* 221 */         } else if (object != null) {
/* 222 */           instance.setResult(((Boolean)object).booleanValue());
/*     */         } 
/* 224 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 227 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_result_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 232 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 233 */     } catch (XMLReaderException xmle) {
/* 234 */       if (startName != null) {
/* 235 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 237 */       throw xmle;
/*     */     } 
/*     */     
/* 240 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 244 */     ValidateNumberSpecialServicesResponseTO instance = (ValidateNumberSpecialServicesResponseTO)obj;
/*     */     
/* 246 */     context.setNillable(true);
/* 247 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getExecutionTime()), ns2_executionTime_QNAME, null, writer, context);
/* 248 */     context.setNillable(true);
/* 249 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOrigin(), ns2_origin_QNAME, null, writer, context);
/* 250 */     context.setNillable(true);
/* 251 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseCode(), ns2_responseCode_QNAME, null, writer, context);
/* 252 */     context.setNillable(true);
/* 253 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseDescription(), ns2_responseDescription_QNAME, null, writer, context);
/* 254 */     context.setNillable(true);
/* 255 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseMessage(), ns2_responseMessage_QNAME, null, writer, context);
/* 256 */     context.setNillable(true);
/* 257 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseSubCode(), ns2_responseSubCode_QNAME, null, writer, context);
/* 258 */     context.setNillable(true);
/* 259 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 260 */     context.setNillable(true);
/* 261 */     this.myns2_ArrayOfBenefitTO__BenefitTOArray_LiteralSerializer1.serialize(instance.getActivationFees(), ns2_activationFees_QNAME, null, writer, context);
/* 262 */     context.setNillable(true);
/* 263 */     this.myns4__short__java_lang_Short_Short_Serializer.serialize(instance.getPositionOnTheList(), ns2_positionOnTheList_QNAME, null, writer, context);
/* 264 */     context.setNillable(true);
/* 265 */     this.myns3__boolean__boolean_Boolean_Serializer.serialize(new Boolean(instance.isResult()), ns2_result_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\wsprepaybasebrplanoffer\ValidateNumberSpecialServicesResponseTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */