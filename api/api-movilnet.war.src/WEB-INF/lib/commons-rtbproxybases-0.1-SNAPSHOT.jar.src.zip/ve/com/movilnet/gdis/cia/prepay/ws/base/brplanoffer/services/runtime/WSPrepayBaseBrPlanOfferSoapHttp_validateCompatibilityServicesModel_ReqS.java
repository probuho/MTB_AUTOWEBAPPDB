/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateServicesModelRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidateServicesModelRequestTO servicesModelRequest;
/*    */   
/*    */   public ValidateServicesModelRequestTO getServicesModelRequest() {
/* 17 */     return this.servicesModelRequest;
/*    */   }
/*    */   
/*    */   public void setServicesModelRequest(ValidateServicesModelRequestTO servicesModelRequest) {
/* 21 */     this.servicesModelRequest = servicesModelRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityServicesModel_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */