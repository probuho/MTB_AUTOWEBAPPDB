/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*    */ import oracle.j2ee.ws.common.encoding.Initializable;
/*    */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*    */ import oracle.j2ee.ws.common.encoding.ReferenceableSerializerImpl;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*    */ import oracle.j2ee.ws.common.encoding.SerializerCallback;
/*    */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*    */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*    */ 
/*    */ public class RequestTO_InterfaceSOAPSerializer extends InterfaceSerializerBase implements Initializable {
/*    */   static Class class$(String paramString) { 
/* 17 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/* 18 */      } private static final QName ns1_IntRequestTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "IntRequestTO");
/*    */   private CombinedSerializer myns1_IntRequestTO__IntRequestTO_SOAPSerializer;
/* 20 */   private static final QName ns1_MasterDataRequestTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MasterDataRequestTO"); private CombinedSerializer myns1_MasterDataRequestTO__MasterDataRequestTO_SOAPSerializer; private CombinedSerializer myns1_RequestTO__RequestTO_SOAPSerializer;
/*    */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO;
/*    */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO;
/*    */   
/*    */   public RequestTO_InterfaceSOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/* 25 */     super(type, encodeType, isNullable, soapVersion);
/*    */   }
/*    */   public RequestTO_InterfaceSOAPSerializer(QName type, boolean encodeType) {
/* 28 */     super(type, encodeType, true, null);
/*    */   }
/*    */   
/*    */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 32 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO == null); ((RequestTO_InterfaceSOAPSerializer)registry).myns1_IntRequestTO__IntRequestTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.IntRequestTO"), ns1_IntRequestTO_TYPE_QNAME);
/* 33 */     this.myns1_IntRequestTO__IntRequestTO_SOAPSerializer = this.myns1_IntRequestTO__IntRequestTO_SOAPSerializer.getInnermostSerializer();
/* 34 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO == null); ((RequestTO_InterfaceSOAPSerializer)registry).myns1_MasterDataRequestTO__MasterDataRequestTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO"), ns1_MasterDataRequestTO_TYPE_QNAME);
/* 35 */     this.myns1_MasterDataRequestTO__MasterDataRequestTO_SOAPSerializer = this.myns1_MasterDataRequestTO__MasterDataRequestTO_SOAPSerializer.getInnermostSerializer();
/* 36 */     QName type = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "RequestTO");
/* 37 */     RequestTO_SOAPSerializer requestTO_SOAPSerializer = new RequestTO_SOAPSerializer(type, true, true, SOAPVersion.SOAP_11);
/*    */     
/* 39 */     ReferenceableSerializerImpl referenceableSerializerImpl = new ReferenceableSerializerImpl(false, (CombinedSerializer)requestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 40 */     this.myns1_RequestTO__RequestTO_SOAPSerializer = referenceableSerializerImpl.getInnermostSerializer();
/* 41 */     if (this.myns1_RequestTO__RequestTO_SOAPSerializer instanceof Initializable) {
/* 42 */       ((Initializable)this.myns1_RequestTO__RequestTO_SOAPSerializer).initialize(registry);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Object doDeserialize(QName name, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/* 48 */     QName elementType = getType(reader);
/* 49 */     if (elementType != null && elementType.equals(this.myns1_IntRequestTO__IntRequestTO_SOAPSerializer.getXmlType()))
/* 50 */       return this.myns1_IntRequestTO__IntRequestTO_SOAPSerializer.deserialize(name, reader, context); 
/* 51 */     if (elementType != null && elementType.equals(this.myns1_MasterDataRequestTO__MasterDataRequestTO_SOAPSerializer.getXmlType()))
/* 52 */       return this.myns1_MasterDataRequestTO__MasterDataRequestTO_SOAPSerializer.deserialize(name, reader, context); 
/* 53 */     if (elementType == null || elementType.equals(this.myns1_RequestTO__RequestTO_SOAPSerializer.getXmlType())) {
/* 54 */       Object obj = this.myns1_RequestTO__RequestTO_SOAPSerializer.deserialize(name, reader, context);
/* 55 */       return obj;
/*    */     } 
/* 57 */     throw new DeserializationException("soap.unexpectedElementType", new Object[] { "", elementType.toString() }, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public void doSerializeInstance(Object obj, QName name, SerializerCallback callback, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 62 */     RequestTO instance = (RequestTO)obj;
/*    */     
/* 64 */     if (obj instanceof ve.com.movilnet.gdis.cia.ws.to.requests.IntRequestTO) {
/* 65 */       this.myns1_IntRequestTO__IntRequestTO_SOAPSerializer.serialize(obj, name, callback, writer, context);
/* 66 */     } else if (obj instanceof ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO) {
/* 67 */       this.myns1_MasterDataRequestTO__MasterDataRequestTO_SOAPSerializer.serialize(obj, name, callback, writer, context);
/*    */     } else {
/* 69 */       this.myns1_RequestTO__RequestTO_SOAPSerializer.serialize(obj, name, callback, writer, context);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\RequestTO_InterfaceSOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */