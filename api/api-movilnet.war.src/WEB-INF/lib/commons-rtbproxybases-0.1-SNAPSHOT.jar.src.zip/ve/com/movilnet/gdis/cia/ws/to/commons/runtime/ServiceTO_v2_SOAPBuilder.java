/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceTO_v2_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private ServiceTO_v2 _instance;
/*     */   private String alcoServicio;
/*     */   private String codServicio;
/*     */   private String descServicio;
/*     */   private short maxCcNumber;
/*     */   private short minCcNumber;
/*     */   private String periodicChargeInd;
/*     */   private String periodicChargeName;
/*     */   private double precio;
/*     */   private String provisioningInd;
/*     */   private String tipoServicio;
/*     */   private static final int myalcoServicio_INDEX = 0;
/*     */   private static final int mycodServicio_INDEX = 1;
/*     */   private static final int mydescServicio_INDEX = 2;
/*     */   private static final int mymaxCcNumber_INDEX = 3;
/*     */   private static final int myminCcNumber_INDEX = 4;
/*     */   private static final int myperiodicChargeInd_INDEX = 5;
/*     */   private static final int myperiodicChargeName_INDEX = 6;
/*     */   private static final int myprecio_INDEX = 7;
/*     */   private static final int myprovisioningInd_INDEX = 8;
/*     */   private static final int mytipoServicio_INDEX = 9;
/*     */   
/*     */   public void setAlcoServicio(String alcoServicio) {
/*  39 */     this.alcoServicio = alcoServicio;
/*     */   }
/*     */   
/*     */   public void setCodServicio(String codServicio) {
/*  43 */     this.codServicio = codServicio;
/*     */   }
/*     */   
/*     */   public void setDescServicio(String descServicio) {
/*  47 */     this.descServicio = descServicio;
/*     */   }
/*     */   
/*     */   public void setMaxCcNumber(short maxCcNumber) {
/*  51 */     this.maxCcNumber = maxCcNumber;
/*     */   }
/*     */   
/*     */   public void setMinCcNumber(short minCcNumber) {
/*  55 */     this.minCcNumber = minCcNumber;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeInd(String periodicChargeInd) {
/*  59 */     this.periodicChargeInd = periodicChargeInd;
/*     */   }
/*     */   
/*     */   public void setPeriodicChargeName(String periodicChargeName) {
/*  63 */     this.periodicChargeName = periodicChargeName;
/*     */   }
/*     */   
/*     */   public void setPrecio(double precio) {
/*  67 */     this.precio = precio;
/*     */   }
/*     */   
/*     */   public void setProvisioningInd(String provisioningInd) {
/*  71 */     this.provisioningInd = provisioningInd;
/*     */   }
/*     */   
/*     */   public void setTipoServicio(String tipoServicio) {
/*  75 */     this.tipoServicio = tipoServicio;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  79 */     switch (memberIndex) {
/*     */       case 0:
/*  81 */         return 6;
/*     */       case 1:
/*  83 */         return 6;
/*     */       case 2:
/*  85 */         return 6;
/*     */       case 3:
/*  87 */         return 6;
/*     */       case 4:
/*  89 */         return 6;
/*     */       case 5:
/*  91 */         return 6;
/*     */       case 6:
/*  93 */         return 6;
/*     */       case 7:
/*  95 */         return 6;
/*     */       case 8:
/*  97 */         return 6;
/*     */       case 9:
/*  99 */         return 6;
/*     */     } 
/* 101 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/* 110 */       switch (index) {
/*     */         case 0:
/* 112 */           this._instance.setAlcoServicio((String)memberValue);
/*     */           return;
/*     */         case 1:
/* 115 */           this._instance.setCodServicio((String)memberValue);
/*     */           return;
/*     */         case 2:
/* 118 */           this._instance.setDescServicio((String)memberValue);
/*     */           return;
/*     */         case 3:
/* 121 */           this._instance.setMaxCcNumber(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 4:
/* 124 */           this._instance.setMinCcNumber(((Short)memberValue).shortValue());
/*     */           return;
/*     */         case 5:
/* 127 */           this._instance.setPeriodicChargeInd((String)memberValue);
/*     */           return;
/*     */         case 6:
/* 130 */           this._instance.setPeriodicChargeName((String)memberValue);
/*     */           return;
/*     */         case 7:
/* 133 */           this._instance.setPrecio(((Double)memberValue).doubleValue());
/*     */           return;
/*     */         case 8:
/* 136 */           this._instance.setProvisioningInd((String)memberValue);
/*     */           return;
/*     */         case 9:
/* 139 */           this._instance.setTipoServicio((String)memberValue);
/*     */           return;
/*     */       } 
/* 142 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/* 145 */     catch (RuntimeException e) {
/* 146 */       throw e;
/*     */     }
/* 148 */     catch (Exception e) {
/* 149 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 157 */     this._instance = (ServiceTO_v2)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 161 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\ServiceTO_v2_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */