/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZoneStructuredTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String distributionCode;
/*    */   protected String sectorCode;
/*    */   protected String zipCode;
/*    */   
/*    */   public String getDistributionCode() {
/* 19 */     return this.distributionCode;
/*    */   }
/*    */   
/*    */   public void setDistributionCode(String distributionCode) {
/* 23 */     this.distributionCode = distributionCode;
/*    */   }
/*    */   
/*    */   public String getSectorCode() {
/* 27 */     return this.sectorCode;
/*    */   }
/*    */   
/*    */   public void setSectorCode(String sectorCode) {
/* 31 */     this.sectorCode = sectorCode;
/*    */   }
/*    */   
/*    */   public String getZipCode() {
/* 35 */     return this.zipCode;
/*    */   }
/*    */   
/*    */   public void setZipCode(String zipCode) {
/* 39 */     this.zipCode = zipCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ZoneStructuredTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */