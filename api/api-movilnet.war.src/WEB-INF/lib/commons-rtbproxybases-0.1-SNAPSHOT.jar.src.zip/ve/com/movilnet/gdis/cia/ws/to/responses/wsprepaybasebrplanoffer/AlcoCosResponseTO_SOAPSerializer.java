/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.runtime.AlcoCosResponseTO_SOAPBuilder;
/*     */ 
/*     */ public class AlcoCosResponseTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_executionTime_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "executionTime");
/*  20 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  22 */   private static final QName ns2_origin_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "origin");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  25 */   private static final QName ns2_responseCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseCode");
/*  26 */   private static final QName ns2_responseDescription_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseDescription");
/*  27 */   private static final QName ns2_responseMessage_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseMessage");
/*  28 */   private static final QName ns2_responseSubCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseSubCode");
/*  29 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  30 */   private static final QName ns2_alcoCosTO_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcoCosTO");
/*  31 */   private static final QName ns2_AlcoCosTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "AlcoCosTO"); private CombinedSerializer myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer; private static final int myexecutionTime_INDEX = 0;
/*     */   private static final int myorigin_INDEX = 1;
/*     */   private static final int myresponseCode_INDEX = 2;
/*     */   private static final int myresponseDescription_INDEX = 3;
/*     */   private static final int myresponseMessage_INDEX = 4;
/*     */   private static final int myresponseSubCode_INDEX = 5;
/*     */   private static final int mytransactionId_INDEX = 6;
/*     */   private static final int myalcoCosTO_INDEX = 7;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO;
/*     */   
/*     */   public AlcoCosResponseTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  43 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  47 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*  48 */     if (class$java$lang$String == null); ((AlcoCosResponseTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  49 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO == null); ((AlcoCosResponseTO_SOAPSerializer)registry).myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO"), ns2_AlcoCosTO_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  54 */     AlcoCosResponseTO instance = new AlcoCosResponseTO();
/*  55 */     AlcoCosResponseTO_SOAPBuilder builder = null;
/*     */     
/*  57 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  60 */     reader.nextElementContent();
/*  61 */     QName startName = reader.getName();
/*  62 */     for (int i = 0; i < 8; i++) {
/*  63 */       QName elementName = reader.getName();
/*  64 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  67 */       if (matchQName(elementName, ns2_executionTime_QNAME)) {
/*  68 */         context.setNillable(true);
/*  69 */         Object member = this.myns3__long__long_Long_Serializer.deserialize(ns2_executionTime_QNAME, reader, context);
/*  70 */         if (member instanceof SOAPDeserializationState) {
/*  71 */           if (builder == null) {
/*  72 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/*  74 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  75 */           isComplete = false;
/*  76 */         } else if (member != null) {
/*  77 */           instance.setExecutionTime(((Long)member).longValue());
/*     */         } 
/*  79 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  82 */       else if (matchQName(elementName, ns2_origin_QNAME)) {
/*  83 */         context.setNillable(true);
/*  84 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_origin_QNAME, reader, context);
/*  85 */         if (object instanceof SOAPDeserializationState) {
/*  86 */           if (builder == null) {
/*  87 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/*  89 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  90 */           isComplete = false;
/*  91 */         } else if (object != null) {
/*  92 */           instance.setOrigin((String)object);
/*     */         } 
/*  94 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  97 */       else if (matchQName(elementName, ns2_responseCode_QNAME)) {
/*  98 */         context.setNillable(true);
/*  99 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseCode_QNAME, reader, context);
/* 100 */         if (object instanceof SOAPDeserializationState) {
/* 101 */           if (builder == null) {
/* 102 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/* 104 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 105 */           isComplete = false;
/* 106 */         } else if (object != null) {
/* 107 */           instance.setResponseCode((String)object);
/*     */         } 
/* 109 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 112 */       else if (matchQName(elementName, ns2_responseDescription_QNAME)) {
/* 113 */         context.setNillable(true);
/* 114 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseDescription_QNAME, reader, context);
/* 115 */         if (object instanceof SOAPDeserializationState) {
/* 116 */           if (builder == null) {
/* 117 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/* 119 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 120 */           isComplete = false;
/* 121 */         } else if (object != null) {
/* 122 */           instance.setResponseDescription((String)object);
/*     */         } 
/* 124 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 127 */       else if (matchQName(elementName, ns2_responseMessage_QNAME)) {
/* 128 */         context.setNillable(true);
/* 129 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseMessage_QNAME, reader, context);
/* 130 */         if (object instanceof SOAPDeserializationState) {
/* 131 */           if (builder == null) {
/* 132 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/* 134 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 135 */           isComplete = false;
/* 136 */         } else if (object != null) {
/* 137 */           instance.setResponseMessage((String)object);
/*     */         } 
/* 139 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 142 */       else if (matchQName(elementName, ns2_responseSubCode_QNAME)) {
/* 143 */         context.setNillable(true);
/* 144 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseSubCode_QNAME, reader, context);
/* 145 */         if (object instanceof SOAPDeserializationState) {
/* 146 */           if (builder == null) {
/* 147 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/* 149 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 150 */           isComplete = false;
/* 151 */         } else if (object != null) {
/* 152 */           instance.setResponseSubCode((String)object);
/*     */         } 
/* 154 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 157 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 158 */         context.setNillable(true);
/* 159 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 160 */         if (object instanceof SOAPDeserializationState) {
/* 161 */           if (builder == null) {
/* 162 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/* 164 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 165 */           isComplete = false;
/* 166 */         } else if (object != null) {
/* 167 */           instance.setTransactionId((String)object);
/*     */         } 
/* 169 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 172 */       else if (matchQName(elementName, ns2_alcoCosTO_QNAME)) {
/* 173 */         context.setNillable(true);
/* 174 */         Object object = this.myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer.deserialize(ns2_alcoCosTO_QNAME, reader, context);
/* 175 */         if (object instanceof SOAPDeserializationState) {
/* 176 */           if (builder == null) {
/* 177 */             builder = new AlcoCosResponseTO_SOAPBuilder();
/*     */           }
/* 179 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 180 */           isComplete = false;
/* 181 */         } else if (object != null) {
/* 182 */           instance.setAlcoCosTO((AlcoCosTO)object);
/*     */         } 
/* 184 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 187 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_alcoCosTO_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 192 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 193 */     } catch (XMLReaderException xmle) {
/* 194 */       if (startName != null) {
/* 195 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 197 */       throw xmle;
/*     */     } 
/*     */     
/* 200 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 204 */     AlcoCosResponseTO instance = (AlcoCosResponseTO)obj;
/*     */     
/* 206 */     context.setNillable(true);
/* 207 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getExecutionTime()), ns2_executionTime_QNAME, null, writer, context);
/* 208 */     context.setNillable(true);
/* 209 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOrigin(), ns2_origin_QNAME, null, writer, context);
/* 210 */     context.setNillable(true);
/* 211 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseCode(), ns2_responseCode_QNAME, null, writer, context);
/* 212 */     context.setNillable(true);
/* 213 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseDescription(), ns2_responseDescription_QNAME, null, writer, context);
/* 214 */     context.setNillable(true);
/* 215 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseMessage(), ns2_responseMessage_QNAME, null, writer, context);
/* 216 */     context.setNillable(true);
/* 217 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseSubCode(), ns2_responseSubCode_QNAME, null, writer, context);
/* 218 */     context.setNillable(true);
/* 219 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 220 */     context.setNillable(true);
/* 221 */     this.myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer.serialize(instance.getAlcoCosTO(), ns2_alcoCosTO_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\wsprepaybasebrplanoffer\AlcoCosResponseTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */