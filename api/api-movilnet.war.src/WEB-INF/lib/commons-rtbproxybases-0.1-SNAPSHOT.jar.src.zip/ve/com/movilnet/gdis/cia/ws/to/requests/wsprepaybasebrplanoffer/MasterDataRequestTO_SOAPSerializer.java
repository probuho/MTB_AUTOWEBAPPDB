/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.MasterDataRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class MasterDataRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_accountType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "accountType");
/*  33 */   private static final QName ns2_categoryCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "categoryCode");
/*  34 */   private static final QName ns2_cosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cosName");
/*  35 */   private static final QName ns2_iniCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "iniCode");
/*  36 */   private static final QName ns2_razonType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "razonType");
/*  37 */   private static final QName ns2_screenType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "screenType");
/*  38 */   private static final QName ns2_subscriberId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subscriberId");
/*  39 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  41 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType");
/*  42 */   private static final QName ns2_userId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "userId");
/*  43 */   private static final QName ns2_value_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "value");
/*  44 */   private static final QName ns3_int_TYPE_QNAME = SchemaConstants.QNAME_TYPE_INT; private CombinedSerializer myns3__int__int_Int_Serializer; private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myaccountType_INDEX = 5;
/*     */   private static final int mycategoryCode_INDEX = 6;
/*     */   private static final int mycosName_INDEX = 7;
/*     */   private static final int myiniCode_INDEX = 8;
/*     */   private static final int myrazonType_INDEX = 9;
/*     */   private static final int myscreenType_INDEX = 10;
/*     */   private static final int mysubscriberId_INDEX = 11;
/*     */   private static final int mytransactionType_INDEX = 12;
/*     */   private static final int myuserId_INDEX = 13;
/*     */   private static final int myvalue_INDEX = 14;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public MasterDataRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  63 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  67 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((MasterDataRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  68 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((MasterDataRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  69 */     if (class$java$lang$String == null); ((MasterDataRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  70 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  71 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*  72 */     this.myns3__int__int_Int_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), int.class, ns3_int_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  77 */     MasterDataRequestTO instance = new MasterDataRequestTO();
/*  78 */     MasterDataRequestTO_SOAPBuilder builder = null;
/*     */     
/*  80 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  83 */     reader.nextElementContent();
/*  84 */     QName startName = reader.getName();
/*  85 */     for (int i = 0; i < 15; i++) {
/*  86 */       QName elementName = reader.getName();
/*  87 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  90 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  91 */         context.setNillable(true);
/*  92 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  93 */         if (member instanceof SOAPDeserializationState) {
/*  94 */           if (builder == null) {
/*  95 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/*  97 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  98 */           isComplete = false;
/*  99 */         } else if (member != null) {
/* 100 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/* 102 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 105 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/* 106 */         context.setNillable(true);
/* 107 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/* 108 */         if (object instanceof SOAPDeserializationState) {
/* 109 */           if (builder == null) {
/* 110 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 112 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 113 */           isComplete = false;
/* 114 */         } else if (object != null) {
/* 115 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 117 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 120 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 121 */         context.setNillable(true);
/* 122 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 123 */         if (object instanceof SOAPDeserializationState) {
/* 124 */           if (builder == null) {
/* 125 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 127 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 128 */           isComplete = false;
/* 129 */         } else if (object != null) {
/* 130 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 132 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 135 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 136 */         context.setNillable(true);
/* 137 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 138 */         if (object instanceof SOAPDeserializationState) {
/* 139 */           if (builder == null) {
/* 140 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 142 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 143 */           isComplete = false;
/* 144 */         } else if (object != null) {
/* 145 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 147 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 150 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 151 */         context.setNillable(true);
/* 152 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 153 */         if (object instanceof SOAPDeserializationState) {
/* 154 */           if (builder == null) {
/* 155 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 157 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 158 */           isComplete = false;
/* 159 */         } else if (object != null) {
/* 160 */           instance.setTransactionId((String)object);
/*     */         } 
/* 162 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 165 */       else if (matchQName(elementName, ns2_accountType_QNAME)) {
/* 166 */         context.setNillable(true);
/* 167 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_accountType_QNAME, reader, context);
/* 168 */         if (object instanceof SOAPDeserializationState) {
/* 169 */           if (builder == null) {
/* 170 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 172 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 173 */           isComplete = false;
/* 174 */         } else if (object != null) {
/* 175 */           instance.setAccountType((String)object);
/*     */         } 
/* 177 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 180 */       else if (matchQName(elementName, ns2_categoryCode_QNAME)) {
/* 181 */         context.setNillable(true);
/* 182 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_categoryCode_QNAME, reader, context);
/* 183 */         if (object instanceof SOAPDeserializationState) {
/* 184 */           if (builder == null) {
/* 185 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 187 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 188 */           isComplete = false;
/* 189 */         } else if (object != null) {
/* 190 */           instance.setCategoryCode((String)object);
/*     */         } 
/* 192 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 195 */       else if (matchQName(elementName, ns2_cosName_QNAME)) {
/* 196 */         context.setNillable(true);
/* 197 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cosName_QNAME, reader, context);
/* 198 */         if (object instanceof SOAPDeserializationState) {
/* 199 */           if (builder == null) {
/* 200 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 202 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 203 */           isComplete = false;
/* 204 */         } else if (object != null) {
/* 205 */           instance.setCosName((String)object);
/*     */         } 
/* 207 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 210 */       else if (matchQName(elementName, ns2_iniCode_QNAME)) {
/* 211 */         context.setNillable(true);
/* 212 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_iniCode_QNAME, reader, context);
/* 213 */         if (object instanceof SOAPDeserializationState) {
/* 214 */           if (builder == null) {
/* 215 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 217 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 218 */           isComplete = false;
/* 219 */         } else if (object != null) {
/* 220 */           instance.setIniCode((String)object);
/*     */         } 
/* 222 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 225 */       else if (matchQName(elementName, ns2_razonType_QNAME)) {
/* 226 */         context.setNillable(true);
/* 227 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_razonType_QNAME, reader, context);
/* 228 */         if (object instanceof SOAPDeserializationState) {
/* 229 */           if (builder == null) {
/* 230 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 232 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 233 */           isComplete = false;
/* 234 */         } else if (object != null) {
/* 235 */           instance.setRazonType((String)object);
/*     */         } 
/* 237 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 240 */       else if (matchQName(elementName, ns2_screenType_QNAME)) {
/* 241 */         context.setNillable(true);
/* 242 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_screenType_QNAME, reader, context);
/* 243 */         if (object instanceof SOAPDeserializationState) {
/* 244 */           if (builder == null) {
/* 245 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 247 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 248 */           isComplete = false;
/* 249 */         } else if (object != null) {
/* 250 */           instance.setScreenType((String)object);
/*     */         } 
/* 252 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 255 */       else if (matchQName(elementName, ns2_subscriberId_QNAME)) {
/* 256 */         context.setNillable(true);
/* 257 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_subscriberId_QNAME, reader, context);
/* 258 */         if (object instanceof SOAPDeserializationState) {
/* 259 */           if (builder == null) {
/* 260 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 262 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 263 */           isComplete = false;
/* 264 */         } else if (object != null) {
/* 265 */           instance.setSubscriberId(((Long)object).longValue());
/*     */         } 
/* 267 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 270 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 271 */         context.setNillable(true);
/* 272 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 273 */         if (object instanceof SOAPDeserializationState) {
/* 274 */           if (builder == null) {
/* 275 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 277 */           state = registerWithMemberState(instance, state, object, 12, (SOAPInstanceBuilder)builder);
/* 278 */           isComplete = false;
/* 279 */         } else if (object != null) {
/* 280 */           instance.setTransactionType((String)object);
/*     */         } 
/* 282 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 285 */       else if (matchQName(elementName, ns2_userId_QNAME)) {
/* 286 */         context.setNillable(true);
/* 287 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_userId_QNAME, reader, context);
/* 288 */         if (object instanceof SOAPDeserializationState) {
/* 289 */           if (builder == null) {
/* 290 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 292 */           state = registerWithMemberState(instance, state, object, 13, (SOAPInstanceBuilder)builder);
/* 293 */           isComplete = false;
/* 294 */         } else if (object != null) {
/* 295 */           instance.setUserId((String)object);
/*     */         } 
/* 297 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 300 */       else if (matchQName(elementName, ns2_value_QNAME)) {
/* 301 */         context.setNillable(true);
/* 302 */         Object object = this.myns3__int__int_Int_Serializer.deserialize(ns2_value_QNAME, reader, context);
/* 303 */         if (object instanceof SOAPDeserializationState) {
/* 304 */           if (builder == null) {
/* 305 */             builder = new MasterDataRequestTO_SOAPBuilder();
/*     */           }
/* 307 */           state = registerWithMemberState(instance, state, object, 14, (SOAPInstanceBuilder)builder);
/* 308 */           isComplete = false;
/* 309 */         } else if (object != null) {
/* 310 */           instance.setValue(((Integer)object).intValue());
/*     */         } 
/* 312 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 315 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_value_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 320 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 321 */     } catch (XMLReaderException xmle) {
/* 322 */       if (startName != null) {
/* 323 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 325 */       throw xmle;
/*     */     } 
/*     */     
/* 328 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 332 */     MasterDataRequestTO instance = (MasterDataRequestTO)obj;
/*     */     
/* 334 */     context.setNillable(true);
/* 335 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 336 */     context.setNillable(true);
/* 337 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 338 */     context.setNillable(true);
/* 339 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 340 */     context.setNillable(true);
/* 341 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 342 */     context.setNillable(true);
/* 343 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 344 */     context.setNillable(true);
/* 345 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAccountType(), ns2_accountType_QNAME, null, writer, context);
/* 346 */     context.setNillable(true);
/* 347 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCategoryCode(), ns2_categoryCode_QNAME, null, writer, context);
/* 348 */     context.setNillable(true);
/* 349 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCosName(), ns2_cosName_QNAME, null, writer, context);
/* 350 */     context.setNillable(true);
/* 351 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getIniCode(), ns2_iniCode_QNAME, null, writer, context);
/* 352 */     context.setNillable(true);
/* 353 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getRazonType(), ns2_razonType_QNAME, null, writer, context);
/* 354 */     context.setNillable(true);
/* 355 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getScreenType(), ns2_screenType_QNAME, null, writer, context);
/* 356 */     context.setNillable(true);
/* 357 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getSubscriberId()), ns2_subscriberId_QNAME, null, writer, context);
/* 358 */     context.setNillable(true);
/* 359 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/* 360 */     context.setNillable(true);
/* 361 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUserId(), ns2_userId_QNAME, null, writer, context);
/* 362 */     context.setNillable(true);
/* 363 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getValue()), ns2_value_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\MasterDataRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */