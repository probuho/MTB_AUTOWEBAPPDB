/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.ChargeCodeTO_SOAPBuilder;
/*     */ 
/*     */ public class ChargeCodeTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_chargeCodeId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "chargeCodeId");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_chargeCodeName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "chargeCodeName");
/*  23 */   private static final QName ns2_periodicChargeId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "periodicChargeId");
/*  24 */   private static final QName ns2_periodicChargeName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "periodicChargeName"); private static final int mychargeCodeId_INDEX = 0;
/*     */   private static final int mychargeCodeName_INDEX = 1;
/*     */   private static final int myperiodicChargeId_INDEX = 2;
/*     */   private static final int myperiodicChargeName_INDEX = 3;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ChargeCodeTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  31 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  35 */     if (class$java$lang$String == null); ((ChargeCodeTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  40 */     ChargeCodeTO instance = new ChargeCodeTO();
/*  41 */     ChargeCodeTO_SOAPBuilder builder = null;
/*     */     
/*  43 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  46 */     reader.nextElementContent();
/*  47 */     QName startName = reader.getName();
/*  48 */     for (int i = 0; i < 4; i++) {
/*  49 */       QName elementName = reader.getName();
/*  50 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  53 */       if (matchQName(elementName, ns2_chargeCodeId_QNAME)) {
/*  54 */         context.setNillable(true);
/*  55 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_chargeCodeId_QNAME, reader, context);
/*  56 */         if (member instanceof SOAPDeserializationState) {
/*  57 */           if (builder == null) {
/*  58 */             builder = new ChargeCodeTO_SOAPBuilder();
/*     */           }
/*  60 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  61 */           isComplete = false;
/*  62 */         } else if (member != null) {
/*  63 */           instance.setChargeCodeId((String)member);
/*     */         } 
/*  65 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  68 */       else if (matchQName(elementName, ns2_chargeCodeName_QNAME)) {
/*  69 */         context.setNillable(true);
/*  70 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_chargeCodeName_QNAME, reader, context);
/*  71 */         if (object instanceof SOAPDeserializationState) {
/*  72 */           if (builder == null) {
/*  73 */             builder = new ChargeCodeTO_SOAPBuilder();
/*     */           }
/*  75 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  76 */           isComplete = false;
/*  77 */         } else if (object != null) {
/*  78 */           instance.setChargeCodeName((String)object);
/*     */         } 
/*  80 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  83 */       else if (matchQName(elementName, ns2_periodicChargeId_QNAME)) {
/*  84 */         context.setNillable(true);
/*  85 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_periodicChargeId_QNAME, reader, context);
/*  86 */         if (object instanceof SOAPDeserializationState) {
/*  87 */           if (builder == null) {
/*  88 */             builder = new ChargeCodeTO_SOAPBuilder();
/*     */           }
/*  90 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/*  91 */           isComplete = false;
/*  92 */         } else if (object != null) {
/*  93 */           instance.setPeriodicChargeId((String)object);
/*     */         } 
/*  95 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  98 */       else if (matchQName(elementName, ns2_periodicChargeName_QNAME)) {
/*  99 */         context.setNillable(true);
/* 100 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_periodicChargeName_QNAME, reader, context);
/* 101 */         if (object instanceof SOAPDeserializationState) {
/* 102 */           if (builder == null) {
/* 103 */             builder = new ChargeCodeTO_SOAPBuilder();
/*     */           }
/* 105 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 106 */           isComplete = false;
/* 107 */         } else if (object != null) {
/* 108 */           instance.setPeriodicChargeName((String)object);
/*     */         } 
/* 110 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 113 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_periodicChargeName_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 118 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 119 */     } catch (XMLReaderException xmle) {
/* 120 */       if (startName != null) {
/* 121 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 123 */       throw xmle;
/*     */     } 
/*     */     
/* 126 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 130 */     ChargeCodeTO instance = (ChargeCodeTO)obj;
/*     */     
/* 132 */     context.setNillable(true);
/* 133 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getChargeCodeId(), ns2_chargeCodeId_QNAME, null, writer, context);
/* 134 */     context.setNillable(true);
/* 135 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getChargeCodeName(), ns2_chargeCodeName_QNAME, null, writer, context);
/* 136 */     context.setNillable(true);
/* 137 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPeriodicChargeId(), ns2_periodicChargeId_QNAME, null, writer, context);
/* 138 */     context.setNillable(true);
/* 139 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPeriodicChargeName(), ns2_periodicChargeName_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\ChargeCodeTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */