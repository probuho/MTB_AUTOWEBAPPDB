/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.IVRPlanBenefitTO_SOAPBuilder;
/*     */ 
/*     */ public class IVRPlanBenefitTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_balanceName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceName");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_cosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cosName");
/*  23 */   private static final QName ns2_quantity_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "quantity");
/*  24 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  26 */   private static final QName ns2_unitType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "unitType"); private static final int mybalanceName_INDEX = 0;
/*     */   private static final int mycosName_INDEX = 1;
/*     */   private static final int myquantity_INDEX = 2;
/*     */   private static final int myunitType_INDEX = 3;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public IVRPlanBenefitTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  33 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  37 */     if (class$java$lang$String == null); ((IVRPlanBenefitTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  38 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  43 */     IVRPlanBenefitTO instance = new IVRPlanBenefitTO();
/*  44 */     IVRPlanBenefitTO_SOAPBuilder builder = null;
/*     */     
/*  46 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  49 */     reader.nextElementContent();
/*  50 */     QName startName = reader.getName();
/*  51 */     for (int i = 0; i < 4; i++) {
/*  52 */       QName elementName = reader.getName();
/*  53 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  56 */       if (matchQName(elementName, ns2_balanceName_QNAME)) {
/*  57 */         context.setNillable(true);
/*  58 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_balanceName_QNAME, reader, context);
/*  59 */         if (member instanceof SOAPDeserializationState) {
/*  60 */           if (builder == null) {
/*  61 */             builder = new IVRPlanBenefitTO_SOAPBuilder();
/*     */           }
/*  63 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  64 */           isComplete = false;
/*  65 */         } else if (member != null) {
/*  66 */           instance.setBalanceName((String)member);
/*     */         } 
/*  68 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  71 */       else if (matchQName(elementName, ns2_cosName_QNAME)) {
/*  72 */         context.setNillable(true);
/*  73 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cosName_QNAME, reader, context);
/*  74 */         if (object instanceof SOAPDeserializationState) {
/*  75 */           if (builder == null) {
/*  76 */             builder = new IVRPlanBenefitTO_SOAPBuilder();
/*     */           }
/*  78 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  79 */           isComplete = false;
/*  80 */         } else if (object != null) {
/*  81 */           instance.setCosName((String)object);
/*     */         } 
/*  83 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  86 */       else if (matchQName(elementName, ns2_quantity_QNAME)) {
/*  87 */         context.setNillable(true);
/*  88 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_quantity_QNAME, reader, context);
/*  89 */         if (object instanceof SOAPDeserializationState) {
/*  90 */           if (builder == null) {
/*  91 */             builder = new IVRPlanBenefitTO_SOAPBuilder();
/*     */           }
/*  93 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/*  94 */           isComplete = false;
/*  95 */         } else if (object != null) {
/*  96 */           instance.setQuantity(((Long)object).longValue());
/*     */         } 
/*  98 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 101 */       else if (matchQName(elementName, ns2_unitType_QNAME)) {
/* 102 */         context.setNillable(true);
/* 103 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_unitType_QNAME, reader, context);
/* 104 */         if (object instanceof SOAPDeserializationState) {
/* 105 */           if (builder == null) {
/* 106 */             builder = new IVRPlanBenefitTO_SOAPBuilder();
/*     */           }
/* 108 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 109 */           isComplete = false;
/* 110 */         } else if (object != null) {
/* 111 */           instance.setUnitType((String)object);
/*     */         } 
/* 113 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 116 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_unitType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 121 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 122 */     } catch (XMLReaderException xmle) {
/* 123 */       if (startName != null) {
/* 124 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 126 */       throw xmle;
/*     */     } 
/*     */     
/* 129 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 133 */     IVRPlanBenefitTO instance = (IVRPlanBenefitTO)obj;
/*     */     
/* 135 */     context.setNillable(true);
/* 136 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getBalanceName(), ns2_balanceName_QNAME, null, writer, context);
/* 137 */     context.setNillable(true);
/* 138 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCosName(), ns2_cosName_QNAME, null, writer, context);
/* 139 */     context.setNillable(true);
/* 140 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getQuantity()), ns2_quantity_QNAME, null, writer, context);
/* 141 */     context.setNillable(true);
/* 142 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUnitType(), ns2_unitType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\IVRPlanBenefitTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */