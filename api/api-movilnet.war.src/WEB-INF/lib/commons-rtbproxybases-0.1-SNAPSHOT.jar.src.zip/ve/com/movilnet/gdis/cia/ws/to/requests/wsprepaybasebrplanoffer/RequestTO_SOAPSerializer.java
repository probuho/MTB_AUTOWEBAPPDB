/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.RequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.RequestTO_SOAPBuilder;
/*     */ 
/*     */ public class RequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public RequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  39 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  43 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((RequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  44 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((RequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  45 */     if (class$java$lang$String == null); ((RequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  46 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  51 */     RequestTO instance = new RequestTO();
/*  52 */     RequestTO_SOAPBuilder builder = null;
/*     */     
/*  54 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  57 */     reader.nextElementContent();
/*  58 */     QName startName = reader.getName();
/*  59 */     for (int i = 0; i < 5; i++) {
/*  60 */       QName elementName = reader.getName();
/*  61 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  64 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  65 */         context.setNillable(true);
/*  66 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  67 */         if (member instanceof SOAPDeserializationState) {
/*  68 */           if (builder == null) {
/*  69 */             builder = new RequestTO_SOAPBuilder();
/*     */           }
/*  71 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  72 */           isComplete = false;
/*  73 */         } else if (member != null) {
/*  74 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  76 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  79 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  80 */         context.setNillable(true);
/*  81 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  82 */         if (object instanceof SOAPDeserializationState) {
/*  83 */           if (builder == null) {
/*  84 */             builder = new RequestTO_SOAPBuilder();
/*     */           }
/*  86 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  87 */           isComplete = false;
/*  88 */         } else if (object != null) {
/*  89 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/*  91 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  94 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/*  95 */         context.setNillable(true);
/*  96 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/*  97 */         if (object instanceof SOAPDeserializationState) {
/*  98 */           if (builder == null) {
/*  99 */             builder = new RequestTO_SOAPBuilder();
/*     */           }
/* 101 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 102 */           isComplete = false;
/* 103 */         } else if (object != null) {
/* 104 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 106 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 109 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 110 */         context.setNillable(true);
/* 111 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 112 */         if (object instanceof SOAPDeserializationState) {
/* 113 */           if (builder == null) {
/* 114 */             builder = new RequestTO_SOAPBuilder();
/*     */           }
/* 116 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 117 */           isComplete = false;
/* 118 */         } else if (object != null) {
/* 119 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 121 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 124 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 125 */         context.setNillable(true);
/* 126 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 127 */         if (object instanceof SOAPDeserializationState) {
/* 128 */           if (builder == null) {
/* 129 */             builder = new RequestTO_SOAPBuilder();
/*     */           }
/* 131 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 132 */           isComplete = false;
/* 133 */         } else if (object != null) {
/* 134 */           instance.setTransactionId((String)object);
/*     */         } 
/* 136 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 139 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionId_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 144 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 145 */     } catch (XMLReaderException xmle) {
/* 146 */       if (startName != null) {
/* 147 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 149 */       throw xmle;
/*     */     } 
/*     */     
/* 152 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 156 */     RequestTO instance = (RequestTO)obj;
/*     */     
/* 158 */     context.setNillable(true);
/* 159 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 160 */     context.setNillable(true);
/* 161 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 162 */     context.setNillable(true);
/* 163 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 164 */     context.setNillable(true);
/* 165 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 166 */     context.setNillable(true);
/* 167 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\RequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */