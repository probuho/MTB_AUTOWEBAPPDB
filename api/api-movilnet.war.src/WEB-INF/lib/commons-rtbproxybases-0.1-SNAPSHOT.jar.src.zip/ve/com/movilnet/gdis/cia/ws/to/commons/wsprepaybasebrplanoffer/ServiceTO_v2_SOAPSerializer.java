/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v2;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.runtime.ServiceTO_v2_SOAPBuilder;
/*     */ 
/*     */ public class ServiceTO_v2_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_alcoServicio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcoServicio");
/*  20 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  22 */   private static final QName ns2_codServicio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "codServicio");
/*  23 */   private static final QName ns2_descServicio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "descServicio");
/*  24 */   private static final QName ns2_maxCcNumber_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "maxCcNumber");
/*  25 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  27 */   private static final QName ns2_minCcNumber_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "minCcNumber");
/*  28 */   private static final QName ns2_periodicChargeInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "periodicChargeInd");
/*  29 */   private static final QName ns2_periodicChargeName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "periodicChargeName");
/*  30 */   private static final QName ns2_precio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "precio");
/*  31 */   private static final QName ns3_double_TYPE_QNAME = SchemaConstants.QNAME_TYPE_DOUBLE;
/*     */   private CombinedSerializer myns3__double__double_Double_Serializer;
/*  33 */   private static final QName ns2_provisioningInd_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "provisioningInd");
/*  34 */   private static final QName ns2_tipoServicio_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "tipoServicio"); private static final int myalcoServicio_INDEX = 0;
/*     */   private static final int mycodServicio_INDEX = 1;
/*     */   private static final int mydescServicio_INDEX = 2;
/*     */   private static final int mymaxCcNumber_INDEX = 3;
/*     */   private static final int myminCcNumber_INDEX = 4;
/*     */   private static final int myperiodicChargeInd_INDEX = 5;
/*     */   private static final int myperiodicChargeName_INDEX = 6;
/*     */   private static final int myprecio_INDEX = 7;
/*     */   private static final int myprovisioningInd_INDEX = 8;
/*     */   private static final int mytipoServicio_INDEX = 9;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ServiceTO_v2_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  47 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  51 */     if (class$java$lang$String == null); ((ServiceTO_v2_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  52 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  53 */     this.myns3__double__double_Double_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), double.class, ns3_double_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  58 */     ServiceTO_v2 instance = new ServiceTO_v2();
/*  59 */     ServiceTO_v2_SOAPBuilder builder = null;
/*     */     
/*  61 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  64 */     reader.nextElementContent();
/*  65 */     QName startName = reader.getName();
/*  66 */     for (int i = 0; i < 10; i++) {
/*  67 */       QName elementName = reader.getName();
/*  68 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  71 */       if (matchQName(elementName, ns2_alcoServicio_QNAME)) {
/*  72 */         context.setNillable(true);
/*  73 */         Object member = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_alcoServicio_QNAME, reader, context);
/*  74 */         if (member instanceof SOAPDeserializationState) {
/*  75 */           if (builder == null) {
/*  76 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/*  78 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  79 */           isComplete = false;
/*  80 */         } else if (member != null) {
/*  81 */           instance.setAlcoServicio((String)member);
/*     */         } 
/*  83 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  86 */       else if (matchQName(elementName, ns2_codServicio_QNAME)) {
/*  87 */         context.setNillable(true);
/*  88 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_codServicio_QNAME, reader, context);
/*  89 */         if (object instanceof SOAPDeserializationState) {
/*  90 */           if (builder == null) {
/*  91 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/*  93 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  94 */           isComplete = false;
/*  95 */         } else if (object != null) {
/*  96 */           instance.setCodServicio((String)object);
/*     */         } 
/*  98 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 101 */       else if (matchQName(elementName, ns2_descServicio_QNAME)) {
/* 102 */         context.setNillable(true);
/* 103 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_descServicio_QNAME, reader, context);
/* 104 */         if (object instanceof SOAPDeserializationState) {
/* 105 */           if (builder == null) {
/* 106 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 108 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 109 */           isComplete = false;
/* 110 */         } else if (object != null) {
/* 111 */           instance.setDescServicio((String)object);
/*     */         } 
/* 113 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 116 */       else if (matchQName(elementName, ns2_maxCcNumber_QNAME)) {
/* 117 */         context.setNillable(true);
/* 118 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_maxCcNumber_QNAME, reader, context);
/* 119 */         if (object instanceof SOAPDeserializationState) {
/* 120 */           if (builder == null) {
/* 121 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 123 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 124 */           isComplete = false;
/* 125 */         } else if (object != null) {
/* 126 */           instance.setMaxCcNumber(((Short)object).shortValue());
/*     */         } 
/* 128 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 131 */       else if (matchQName(elementName, ns2_minCcNumber_QNAME)) {
/* 132 */         context.setNillable(true);
/* 133 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_minCcNumber_QNAME, reader, context);
/* 134 */         if (object instanceof SOAPDeserializationState) {
/* 135 */           if (builder == null) {
/* 136 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 138 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 139 */           isComplete = false;
/* 140 */         } else if (object != null) {
/* 141 */           instance.setMinCcNumber(((Short)object).shortValue());
/*     */         } 
/* 143 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 146 */       else if (matchQName(elementName, ns2_periodicChargeInd_QNAME)) {
/* 147 */         context.setNillable(true);
/* 148 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_periodicChargeInd_QNAME, reader, context);
/* 149 */         if (object instanceof SOAPDeserializationState) {
/* 150 */           if (builder == null) {
/* 151 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 153 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 154 */           isComplete = false;
/* 155 */         } else if (object != null) {
/* 156 */           instance.setPeriodicChargeInd((String)object);
/*     */         } 
/* 158 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 161 */       else if (matchQName(elementName, ns2_periodicChargeName_QNAME)) {
/* 162 */         context.setNillable(true);
/* 163 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_periodicChargeName_QNAME, reader, context);
/* 164 */         if (object instanceof SOAPDeserializationState) {
/* 165 */           if (builder == null) {
/* 166 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 168 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 169 */           isComplete = false;
/* 170 */         } else if (object != null) {
/* 171 */           instance.setPeriodicChargeName((String)object);
/*     */         } 
/* 173 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 176 */       else if (matchQName(elementName, ns2_precio_QNAME)) {
/* 177 */         context.setNillable(true);
/* 178 */         Object object = this.myns3__double__double_Double_Serializer.deserialize(ns2_precio_QNAME, reader, context);
/* 179 */         if (object instanceof SOAPDeserializationState) {
/* 180 */           if (builder == null) {
/* 181 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 183 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 184 */           isComplete = false;
/* 185 */         } else if (object != null) {
/* 186 */           instance.setPrecio(((Double)object).doubleValue());
/*     */         } 
/* 188 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 191 */       else if (matchQName(elementName, ns2_provisioningInd_QNAME)) {
/* 192 */         context.setNillable(true);
/* 193 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_provisioningInd_QNAME, reader, context);
/* 194 */         if (object instanceof SOAPDeserializationState) {
/* 195 */           if (builder == null) {
/* 196 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 198 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 199 */           isComplete = false;
/* 200 */         } else if (object != null) {
/* 201 */           instance.setProvisioningInd((String)object);
/*     */         } 
/* 203 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 206 */       else if (matchQName(elementName, ns2_tipoServicio_QNAME)) {
/* 207 */         context.setNillable(true);
/* 208 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_tipoServicio_QNAME, reader, context);
/* 209 */         if (object instanceof SOAPDeserializationState) {
/* 210 */           if (builder == null) {
/* 211 */             builder = new ServiceTO_v2_SOAPBuilder();
/*     */           }
/* 213 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 214 */           isComplete = false;
/* 215 */         } else if (object != null) {
/* 216 */           instance.setTipoServicio((String)object);
/*     */         } 
/* 218 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 221 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_tipoServicio_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 226 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 227 */     } catch (XMLReaderException xmle) {
/* 228 */       if (startName != null) {
/* 229 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 231 */       throw xmle;
/*     */     } 
/*     */     
/* 234 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 238 */     ServiceTO_v2 instance = (ServiceTO_v2)obj;
/*     */     
/* 240 */     context.setNillable(true);
/* 241 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAlcoServicio(), ns2_alcoServicio_QNAME, null, writer, context);
/* 242 */     context.setNillable(true);
/* 243 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCodServicio(), ns2_codServicio_QNAME, null, writer, context);
/* 244 */     context.setNillable(true);
/* 245 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getDescServicio(), ns2_descServicio_QNAME, null, writer, context);
/* 246 */     context.setNillable(true);
/* 247 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getMaxCcNumber()), ns2_maxCcNumber_QNAME, null, writer, context);
/* 248 */     context.setNillable(true);
/* 249 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getMinCcNumber()), ns2_minCcNumber_QNAME, null, writer, context);
/* 250 */     context.setNillable(true);
/* 251 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPeriodicChargeInd(), ns2_periodicChargeInd_QNAME, null, writer, context);
/* 252 */     context.setNillable(true);
/* 253 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPeriodicChargeName(), ns2_periodicChargeName_QNAME, null, writer, context);
/* 254 */     context.setNillable(true);
/* 255 */     this.myns3__double__double_Double_Serializer.serialize(new Double(instance.getPrecio()), ns2_precio_QNAME, null, writer, context);
/* 256 */     context.setNillable(true);
/* 257 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getProvisioningInd(), ns2_provisioningInd_QNAME, null, writer, context);
/* 258 */     context.setNillable(true);
/* 259 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTipoServicio(), ns2_tipoServicio_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\wsprepaybasebrplanoffer\ServiceTO_v2_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */