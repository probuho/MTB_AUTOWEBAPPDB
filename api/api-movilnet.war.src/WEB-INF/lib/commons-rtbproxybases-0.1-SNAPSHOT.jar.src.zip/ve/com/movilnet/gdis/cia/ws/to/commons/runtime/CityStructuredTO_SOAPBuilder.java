/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CityStructuredTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private CityStructuredTO _instance;
/*    */   private int cityId;
/*    */   private String cityName;
/*    */   private String parroquiaCode;
/*    */   private static final int mycityId_INDEX = 0;
/*    */   private static final int mycityName_INDEX = 1;
/*    */   private static final int myparroquiaCode_INDEX = 2;
/*    */   
/*    */   public void setCityId(int cityId) {
/* 25 */     this.cityId = cityId;
/*    */   }
/*    */   
/*    */   public void setCityName(String cityName) {
/* 29 */     this.cityName = cityName;
/*    */   }
/*    */   
/*    */   public void setParroquiaCode(String parroquiaCode) {
/* 33 */     this.parroquiaCode = parroquiaCode;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 37 */     switch (memberIndex) {
/*    */       case 0:
/* 39 */         return 6;
/*    */       case 1:
/* 41 */         return 6;
/*    */       case 2:
/* 43 */         return 6;
/*    */     } 
/* 45 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 54 */       switch (index) {
/*    */         case 0:
/* 56 */           this._instance.setCityId(((Integer)memberValue).intValue());
/*    */           return;
/*    */         case 1:
/* 59 */           this._instance.setCityName((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 62 */           this._instance.setParroquiaCode((String)memberValue);
/*    */           return;
/*    */       } 
/* 65 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 68 */     catch (RuntimeException e) {
/* 69 */       throw e;
/*    */     }
/* 71 */     catch (Exception e) {
/* 72 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 80 */     this._instance = (CityStructuredTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 84 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\CityStructuredTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */