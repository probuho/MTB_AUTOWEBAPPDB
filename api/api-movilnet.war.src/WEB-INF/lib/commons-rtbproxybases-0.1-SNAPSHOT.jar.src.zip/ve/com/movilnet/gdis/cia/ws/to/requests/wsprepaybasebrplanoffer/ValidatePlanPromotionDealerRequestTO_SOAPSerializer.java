/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanPromotionDealerRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidatePlanPromotionDealerRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidatePlanPromotionDealerRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_cosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cosName");
/*  33 */   private static final QName ns2_dealerCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "dealerCode");
/*  34 */   private static final QName ns2_planCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCode");
/*  35 */   private static final QName ns2_promoId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "promoId");
/*  36 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int mycosName_INDEX = 5;
/*     */   private static final int mydealerCode_INDEX = 6;
/*     */   private static final int myplanCode_INDEX = 7;
/*     */   private static final int mypromoId_INDEX = 8;
/*     */   private static final int mytransactionType_INDEX = 9;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public ValidatePlanPromotionDealerRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  49 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  53 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidatePlanPromotionDealerRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  54 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidatePlanPromotionDealerRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  55 */     if (class$java$lang$String == null); ((ValidatePlanPromotionDealerRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  56 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  61 */     ValidatePlanPromotionDealerRequestTO instance = new ValidatePlanPromotionDealerRequestTO();
/*  62 */     ValidatePlanPromotionDealerRequestTO_SOAPBuilder builder = null;
/*     */     
/*  64 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  67 */     reader.nextElementContent();
/*  68 */     QName startName = reader.getName();
/*  69 */     for (int i = 0; i < 10; i++) {
/*  70 */       QName elementName = reader.getName();
/*  71 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  74 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  75 */         context.setNillable(true);
/*  76 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  77 */         if (member instanceof SOAPDeserializationState) {
/*  78 */           if (builder == null) {
/*  79 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/*  81 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  82 */           isComplete = false;
/*  83 */         } else if (member != null) {
/*  84 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  86 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  89 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  90 */         context.setNillable(true);
/*  91 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  92 */         if (object instanceof SOAPDeserializationState) {
/*  93 */           if (builder == null) {
/*  94 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/*  96 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  97 */           isComplete = false;
/*  98 */         } else if (object != null) {
/*  99 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 101 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 104 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 105 */         context.setNillable(true);
/* 106 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 107 */         if (object instanceof SOAPDeserializationState) {
/* 108 */           if (builder == null) {
/* 109 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 111 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 112 */           isComplete = false;
/* 113 */         } else if (object != null) {
/* 114 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 116 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 119 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 120 */         context.setNillable(true);
/* 121 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 122 */         if (object instanceof SOAPDeserializationState) {
/* 123 */           if (builder == null) {
/* 124 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 126 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 127 */           isComplete = false;
/* 128 */         } else if (object != null) {
/* 129 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 131 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 134 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 135 */         context.setNillable(true);
/* 136 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 137 */         if (object instanceof SOAPDeserializationState) {
/* 138 */           if (builder == null) {
/* 139 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 141 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 142 */           isComplete = false;
/* 143 */         } else if (object != null) {
/* 144 */           instance.setTransactionId((String)object);
/*     */         } 
/* 146 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 149 */       else if (matchQName(elementName, ns2_cosName_QNAME)) {
/* 150 */         context.setNillable(true);
/* 151 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cosName_QNAME, reader, context);
/* 152 */         if (object instanceof SOAPDeserializationState) {
/* 153 */           if (builder == null) {
/* 154 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 156 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 157 */           isComplete = false;
/* 158 */         } else if (object != null) {
/* 159 */           instance.setCosName((String)object);
/*     */         } 
/* 161 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 164 */       else if (matchQName(elementName, ns2_dealerCode_QNAME)) {
/* 165 */         context.setNillable(true);
/* 166 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_dealerCode_QNAME, reader, context);
/* 167 */         if (object instanceof SOAPDeserializationState) {
/* 168 */           if (builder == null) {
/* 169 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 171 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 172 */           isComplete = false;
/* 173 */         } else if (object != null) {
/* 174 */           instance.setDealerCode((String)object);
/*     */         } 
/* 176 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 179 */       else if (matchQName(elementName, ns2_planCode_QNAME)) {
/* 180 */         context.setNillable(true);
/* 181 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCode_QNAME, reader, context);
/* 182 */         if (object instanceof SOAPDeserializationState) {
/* 183 */           if (builder == null) {
/* 184 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 186 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 187 */           isComplete = false;
/* 188 */         } else if (object != null) {
/* 189 */           instance.setPlanCode((String)object);
/*     */         } 
/* 191 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 194 */       else if (matchQName(elementName, ns2_promoId_QNAME)) {
/* 195 */         context.setNillable(true);
/* 196 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_promoId_QNAME, reader, context);
/* 197 */         if (object instanceof SOAPDeserializationState) {
/* 198 */           if (builder == null) {
/* 199 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 201 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 202 */           isComplete = false;
/* 203 */         } else if (object != null) {
/* 204 */           instance.setPromoId((String)object);
/*     */         } 
/* 206 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 209 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 210 */         context.setNillable(true);
/* 211 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 212 */         if (object instanceof SOAPDeserializationState) {
/* 213 */           if (builder == null) {
/* 214 */             builder = new ValidatePlanPromotionDealerRequestTO_SOAPBuilder();
/*     */           }
/* 216 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 217 */           isComplete = false;
/* 218 */         } else if (object != null) {
/* 219 */           instance.setTransactionType((String)object);
/*     */         } 
/* 221 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 224 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 229 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 230 */     } catch (XMLReaderException xmle) {
/* 231 */       if (startName != null) {
/* 232 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 234 */       throw xmle;
/*     */     } 
/*     */     
/* 237 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 241 */     ValidatePlanPromotionDealerRequestTO instance = (ValidatePlanPromotionDealerRequestTO)obj;
/*     */     
/* 243 */     context.setNillable(true);
/* 244 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 245 */     context.setNillable(true);
/* 246 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 247 */     context.setNillable(true);
/* 248 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 249 */     context.setNillable(true);
/* 250 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 251 */     context.setNillable(true);
/* 252 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 253 */     context.setNillable(true);
/* 254 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCosName(), ns2_cosName_QNAME, null, writer, context);
/* 255 */     context.setNillable(true);
/* 256 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getDealerCode(), ns2_dealerCode_QNAME, null, writer, context);
/* 257 */     context.setNillable(true);
/* 258 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCode(), ns2_planCode_QNAME, null, writer, context);
/* 259 */     context.setNillable(true);
/* 260 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPromoId(), ns2_promoId_QNAME, null, writer, context);
/* 261 */     context.setNillable(true);
/* 262 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidatePlanPromotionDealerRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */