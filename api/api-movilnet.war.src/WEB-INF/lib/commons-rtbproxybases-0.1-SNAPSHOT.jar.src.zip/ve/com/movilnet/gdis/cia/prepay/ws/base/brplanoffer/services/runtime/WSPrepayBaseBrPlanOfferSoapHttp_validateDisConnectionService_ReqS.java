/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateDisConnectionServiceRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidateDisConnectionServiceRequestTO disConnectionServiceRequest;
/*    */   
/*    */   public ValidateDisConnectionServiceRequestTO getDisConnectionServiceRequest() {
/* 17 */     return this.disConnectionServiceRequest;
/*    */   }
/*    */   
/*    */   public void setDisConnectionServiceRequest(ValidateDisConnectionServiceRequestTO disConnectionServiceRequest) {
/* 21 */     this.disConnectionServiceRequest = disConnectionServiceRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validateDisConnectionService_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */