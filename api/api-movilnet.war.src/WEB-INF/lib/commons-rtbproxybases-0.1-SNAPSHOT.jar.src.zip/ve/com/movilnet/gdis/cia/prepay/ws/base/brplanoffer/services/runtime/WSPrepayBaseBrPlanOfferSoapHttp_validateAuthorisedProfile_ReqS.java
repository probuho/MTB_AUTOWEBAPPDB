/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAuthorisedProfileRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidateAuthorisedProfileRequestTO validateAuthorisedProfileRequest;
/*    */   
/*    */   public ValidateAuthorisedProfileRequestTO getValidateAuthorisedProfileRequest() {
/* 17 */     return this.validateAuthorisedProfileRequest;
/*    */   }
/*    */   
/*    */   public void setValidateAuthorisedProfileRequest(ValidateAuthorisedProfileRequestTO validateAuthorisedProfileRequest) {
/* 21 */     this.validateAuthorisedProfileRequest = validateAuthorisedProfileRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validateAuthorisedProfile_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */