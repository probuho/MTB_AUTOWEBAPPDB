/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CityTO
/*    */   implements Serializable
/*    */ {
/*    */   protected int cityId;
/*    */   protected String cityName;
/*    */   protected String stateCode;
/*    */   
/*    */   public int getCityId() {
/* 19 */     return this.cityId;
/*    */   }
/*    */   
/*    */   public void setCityId(int cityId) {
/* 23 */     this.cityId = cityId;
/*    */   }
/*    */   
/*    */   public String getCityName() {
/* 27 */     return this.cityName;
/*    */   }
/*    */   
/*    */   public void setCityName(String cityName) {
/* 31 */     this.cityName = cityName;
/*    */   }
/*    */   
/*    */   public String getStateCode() {
/* 35 */     return this.stateCode;
/*    */   }
/*    */   
/*    */   public void setStateCode(String stateCode) {
/* 39 */     this.stateCode = stateCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\CityTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */