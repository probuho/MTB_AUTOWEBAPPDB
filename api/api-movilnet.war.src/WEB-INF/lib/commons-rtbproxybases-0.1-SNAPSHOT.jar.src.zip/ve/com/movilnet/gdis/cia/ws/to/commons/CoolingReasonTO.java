/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoolingReasonTO
/*    */   implements Serializable
/*    */ {
/*    */   protected int extensionDaysForCycleLife;
/*    */   protected String reasonCode;
/*    */   protected String reasonDesc;
/*    */   protected String specialCycleLifeInd;
/*    */   
/*    */   public int getExtensionDaysForCycleLife() {
/* 20 */     return this.extensionDaysForCycleLife;
/*    */   }
/*    */   
/*    */   public void setExtensionDaysForCycleLife(int extensionDaysForCycleLife) {
/* 24 */     this.extensionDaysForCycleLife = extensionDaysForCycleLife;
/*    */   }
/*    */   
/*    */   public String getReasonCode() {
/* 28 */     return this.reasonCode;
/*    */   }
/*    */   
/*    */   public void setReasonCode(String reasonCode) {
/* 32 */     this.reasonCode = reasonCode;
/*    */   }
/*    */   
/*    */   public String getReasonDesc() {
/* 36 */     return this.reasonDesc;
/*    */   }
/*    */   
/*    */   public void setReasonDesc(String reasonDesc) {
/* 40 */     this.reasonDesc = reasonDesc;
/*    */   }
/*    */   
/*    */   public String getSpecialCycleLifeInd() {
/* 44 */     return this.specialCycleLifeInd;
/*    */   }
/*    */   
/*    */   public void setSpecialCycleLifeInd(String specialCycleLifeInd) {
/* 48 */     this.specialCycleLifeInd = specialCycleLifeInd;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\CoolingReasonTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */