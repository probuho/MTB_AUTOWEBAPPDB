/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParisheTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private ParisheTO _instance;
/*    */   private String municipioCode;
/*    */   private String parroquiaCode;
/*    */   private String parroquiaName;
/*    */   private static final int mymunicipioCode_INDEX = 0;
/*    */   private static final int myparroquiaCode_INDEX = 1;
/*    */   private static final int myparroquiaName_INDEX = 2;
/*    */   
/*    */   public void setMunicipioCode(String municipioCode) {
/* 25 */     this.municipioCode = municipioCode;
/*    */   }
/*    */   
/*    */   public void setParroquiaCode(String parroquiaCode) {
/* 29 */     this.parroquiaCode = parroquiaCode;
/*    */   }
/*    */   
/*    */   public void setParroquiaName(String parroquiaName) {
/* 33 */     this.parroquiaName = parroquiaName;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 37 */     switch (memberIndex) {
/*    */       case 0:
/* 39 */         return 6;
/*    */       case 1:
/* 41 */         return 6;
/*    */       case 2:
/* 43 */         return 6;
/*    */     } 
/* 45 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 54 */       switch (index) {
/*    */         case 0:
/* 56 */           this._instance.setMunicipioCode((String)memberValue);
/*    */           return;
/*    */         case 1:
/* 59 */           this._instance.setParroquiaCode((String)memberValue);
/*    */           return;
/*    */         case 2:
/* 62 */           this._instance.setParroquiaName((String)memberValue);
/*    */           return;
/*    */       } 
/* 65 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 68 */     catch (RuntimeException e) {
/* 69 */       throw e;
/*    */     }
/* 71 */     catch (Exception e) {
/* 72 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 80 */     this._instance = (ParisheTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 84 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\ParisheTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */