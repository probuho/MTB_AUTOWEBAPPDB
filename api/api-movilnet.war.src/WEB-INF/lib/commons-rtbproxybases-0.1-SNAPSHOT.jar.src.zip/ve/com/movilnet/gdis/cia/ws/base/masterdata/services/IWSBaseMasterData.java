package ve.com.movilnet.gdis.cia.ws.base.masterdata.services;

import java.rmi.Remote;
import java.rmi.RemoteException;
import ve.com.movilnet.gdis.cia.ws.to.requests.IntRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO;
import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO_v2;

public interface IWSBaseMasterData extends Remote {
  AlcoCosResponseTO getMasterDataAlcoAndCos(IntRequestTO paramIntRequestTO) throws RemoteException;
  
  MasterDataResponseTO getMasterDataGeographicalLocation(MasterDataRequestTO paramMasterDataRequestTO) throws RemoteException;
  
  MasterDataResponseTO getMasterDataPersonalData(MasterDataRequestTO paramMasterDataRequestTO) throws RemoteException;
  
  MasterDataResponseTO getMasterDataProductAndService(MasterDataRequestTO paramMasterDataRequestTO) throws RemoteException;
  
  MasterDataResponseTO_v2 getMasterDataProductAndService2(MasterDataRequestTO paramMasterDataRequestTO) throws RemoteException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\IWSBaseMasterData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */