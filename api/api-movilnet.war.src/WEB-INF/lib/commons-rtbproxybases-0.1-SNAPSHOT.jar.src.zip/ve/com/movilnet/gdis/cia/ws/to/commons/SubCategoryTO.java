/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubCategoryTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String codCateg;
/*    */   protected String descCateg;
/*    */   
/*    */   public String getCodCateg() {
/* 18 */     return this.codCateg;
/*    */   }
/*    */   
/*    */   public void setCodCateg(String codCateg) {
/* 22 */     this.codCateg = codCateg;
/*    */   }
/*    */   
/*    */   public String getDescCateg() {
/* 26 */     return this.descCateg;
/*    */   }
/*    */   
/*    */   public void setDescCateg(String descCateg) {
/* 30 */     this.descCateg = descCateg;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\SubCategoryTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */