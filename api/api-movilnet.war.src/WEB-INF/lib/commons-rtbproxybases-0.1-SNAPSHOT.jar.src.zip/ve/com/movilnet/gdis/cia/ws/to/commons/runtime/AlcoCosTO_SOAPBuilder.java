/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*    */ 
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*    */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlcoCosTO_SOAPBuilder
/*    */   implements SOAPInstanceBuilder
/*    */ {
/*    */   private AlcoCosTO _instance;
/*    */   private String[] alcoList;
/*    */   private String[] cosList;
/*    */   private static final int myalcoList_INDEX = 0;
/*    */   private static final int mycosList_INDEX = 1;
/*    */   
/*    */   public void setAlcoList(String[] alcoList) {
/* 23 */     this.alcoList = alcoList;
/*    */   }
/*    */   
/*    */   public void setCosList(String[] cosList) {
/* 27 */     this.cosList = cosList;
/*    */   }
/*    */   
/*    */   public int memberGateType(int memberIndex) {
/* 31 */     switch (memberIndex) {
/*    */       case 0:
/* 33 */         return 6;
/*    */       case 1:
/* 35 */         return 6;
/*    */     } 
/* 37 */     throw new IllegalArgumentException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void construct() {}
/*    */ 
/*    */   
/*    */   public void setMember(int index, Object memberValue) {
/*    */     try {
/* 46 */       switch (index) {
/*    */         case 0:
/* 48 */           this._instance.setAlcoList((String[])memberValue);
/*    */           return;
/*    */         case 1:
/* 51 */           this._instance.setCosList((String[])memberValue);
/*    */           return;
/*    */       } 
/* 54 */       throw new IllegalArgumentException();
/*    */     
/*    */     }
/* 57 */     catch (RuntimeException e) {
/* 58 */       throw e;
/*    */     }
/* 60 */     catch (Exception e) {
/* 61 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize() {}
/*    */   
/*    */   public void setInstance(Object instance) {
/* 69 */     this._instance = (AlcoCosTO)instance;
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 73 */     return this._instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\AlcoCosTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */