/*     */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime;public class WSBaseMasterData_SerializerRegistry extends SerializerRegistryBase implements SerializerConstants { private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$StateTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO; private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$CityTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$PlanTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SectorTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO;
/*     */   
/*     */   static Class class$(String paramString) {
/*     */     
/*  21 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*     */   
/*     */   }
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO; private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO; private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO; private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO; private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO; private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO; private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO; private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO;
/*     */   public TypeMappingRegistry getRegistry() {
/*  26 */     TypeMappingRegistry registry = BasicService.createStandardTypeMappingRegistry();
/*  27 */     TypeMapping mapping11 = registry.getTypeMapping(SOAPEncodingConstants.getSOAPEncodingConstants(SOAPVersion.SOAP_11).getURIEncoding());
/*  28 */     TypeMapping mapping = registry.getTypeMapping("");
/*     */     
/*  30 */     QName type = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ZoneTO");
/*  31 */     ZoneTO_SOAPSerializer zoneTO_SOAPSerializer = new ZoneTO_SOAPSerializer(type, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  33 */     ReferenceableSerializerImpl referenceableSerializerImpl1 = new ReferenceableSerializerImpl(true, (CombinedSerializer)zoneTO_SOAPSerializer, SOAPVersion.SOAP_11);
/*  34 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO"), type, (Serializer)referenceableSerializerImpl1);
/*     */ 
/*     */     
/*  37 */     QName qName1 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "NationalitiesTO");
/*  38 */     NationalitiesTO_SOAPSerializer nationalitiesTO_SOAPSerializer = new NationalitiesTO_SOAPSerializer(qName1, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  40 */     ReferenceableSerializerImpl referenceableSerializerImpl2 = new ReferenceableSerializerImpl(true, (CombinedSerializer)nationalitiesTO_SOAPSerializer, SOAPVersion.SOAP_11);
/*  41 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.NationalitiesTO"), qName1, (Serializer)referenceableSerializerImpl2);
/*     */ 
/*     */     
/*  44 */     QName qName2 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfNationalitiesTO");
/*  45 */     QName elemName = new QName("", "item");
/*  46 */     QName elemType = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "NationalitiesTO");
/*  47 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO == null); super(true, true, elemName, elemType, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.NationalitiesTO"), 1, null, SOAPVersion.SOAP_11);
/*     */     
/*     */     ObjectArraySerializer objectArraySerializer1, objectArraySerializer2, objectArraySerializer3, objectArraySerializer4, objectArraySerializer5, objectArraySerializer6, objectArraySerializer7, objectArraySerializer8, objectArraySerializer9, objectArraySerializer10, objectArraySerializer11, objectArraySerializer12, objectArraySerializer13, objectArraySerializer14, objectArraySerializer15, objectArraySerializer16, objectArraySerializer17, objectArraySerializer18, objectArraySerializer19, objectArraySerializer20, objectArraySerializer21, objectArraySerializer22, objectArraySerializer23, objectArraySerializer24, objectArraySerializer25, objectArraySerializer26, objectArraySerializer27, objectArraySerializer28, objectArraySerializer29, objectArraySerializer30;
/*  50 */     ReferenceableSerializerImpl referenceableSerializerImpl3 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer1, SOAPVersion.SOAP_11);
/*  51 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.NationalitiesTO;"), qName2, (Serializer)referenceableSerializerImpl3);
/*     */ 
/*     */     
/*  54 */     QName qName3 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "StateTO");
/*  55 */     StateTO_SOAPSerializer stateTO_SOAPSerializer = new StateTO_SOAPSerializer(qName3, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  57 */     ReferenceableSerializerImpl referenceableSerializerImpl4 = new ReferenceableSerializerImpl(true, (CombinedSerializer)stateTO_SOAPSerializer, SOAPVersion.SOAP_11);
/*  58 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$StateTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$StateTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$StateTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.StateTO"), qName3, (Serializer)referenceableSerializerImpl4);
/*     */ 
/*     */     
/*  61 */     QName qName4 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPromotionTO");
/*  62 */     QName qName5 = new QName("", "item");
/*  63 */     QName qName6 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "PromotionTO");
/*  64 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO == null); super(true, true, qName5, qName6, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/*  67 */     ReferenceableSerializerImpl referenceableSerializerImpl5 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer2, SOAPVersion.SOAP_11);
/*  68 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO;"), qName4, (Serializer)referenceableSerializerImpl5);
/*     */ 
/*     */     
/*  71 */     QName qName7 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MasterDataRequestTO");
/*  72 */     MasterDataRequestTO_SOAPSerializer masterDataRequestTO_SOAPSerializer = new MasterDataRequestTO_SOAPSerializer(qName7, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  74 */     ReferenceableSerializerImpl referenceableSerializerImpl6 = new ReferenceableSerializerImpl(true, (CombinedSerializer)masterDataRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/*  75 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$MasterDataRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO"), qName7, (Serializer)referenceableSerializerImpl6);
/*     */ 
/*     */     
/*  78 */     QName qName8 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataAlcoAndCos");
/*  79 */     WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS_SOAPSerializer(qName8, false, false, SOAPVersion.SOAP_11);
/*     */     
/*  81 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS"), qName8, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/*  84 */     QName qName9 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MunicipalitieTO");
/*  85 */     MunicipalitieTO_SOAPSerializer municipalitieTO_SOAPSerializer = new MunicipalitieTO_SOAPSerializer(qName9, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  87 */     ReferenceableSerializerImpl referenceableSerializerImpl7 = new ReferenceableSerializerImpl(true, (CombinedSerializer)municipalitieTO_SOAPSerializer, SOAPVersion.SOAP_11);
/*  88 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO"), qName9, (Serializer)referenceableSerializerImpl7);
/*     */ 
/*     */     
/*  91 */     QName qName10 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ResponseTO");
/*  92 */     ResponseTO_InterfaceSOAPSerializer responseTO_InterfaceSOAPSerializer = new ResponseTO_InterfaceSOAPSerializer(qName10, true, true, SOAPVersion.SOAP_11);
/*     */     
/*  94 */     ReferenceableSerializerImpl referenceableSerializerImpl8 = new ReferenceableSerializerImpl(true, (CombinedSerializer)responseTO_InterfaceSOAPSerializer, SOAPVersion.SOAP_11);
/*  95 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$ResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.ResponseTO"), qName10, (Serializer)referenceableSerializerImpl8);
/*     */ 
/*     */     
/*  98 */     QName qName11 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "AdjustmentReasonsTO");
/*  99 */     AdjustmentReasonsTO_SOAPSerializer adjustmentReasonsTO_SOAPSerializer = new AdjustmentReasonsTO_SOAPSerializer(qName11, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 101 */     ReferenceableSerializerImpl referenceableSerializerImpl9 = new ReferenceableSerializerImpl(true, (CombinedSerializer)adjustmentReasonsTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 102 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO"), qName11, (Serializer)referenceableSerializerImpl9);
/*     */ 
/*     */     
/* 105 */     QName qName12 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "AlcoCosResponseTO");
/* 106 */     AlcoCosResponseTO_SOAPSerializer alcoCosResponseTO_SOAPSerializer = new AlcoCosResponseTO_SOAPSerializer(qName12, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 108 */     ReferenceableSerializerImpl referenceableSerializerImpl10 = new ReferenceableSerializerImpl(true, (CombinedSerializer)alcoCosResponseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 109 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$AlcoCosResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO"), qName12, (Serializer)referenceableSerializerImpl10);
/*     */ 
/*     */     
/* 112 */     QName qName13 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCityTO");
/* 113 */     QName qName14 = new QName("", "item");
/* 114 */     QName qName15 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CityTO");
/* 115 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CityTO == null); super(true, true, qName14, qName15, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$CityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CityTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 118 */     ReferenceableSerializerImpl referenceableSerializerImpl11 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer3, SOAPVersion.SOAP_11);
/* 119 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CityTO;"), qName13, (Serializer)referenceableSerializerImpl11);
/*     */ 
/*     */     
/* 122 */     QName qName16 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MasterDataResponseTO");
/* 123 */     MasterDataResponseTO_SOAPSerializer masterDataResponseTO_SOAPSerializer = new MasterDataResponseTO_SOAPSerializer(qName16, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 125 */     ReferenceableSerializerImpl referenceableSerializerImpl12 = new ReferenceableSerializerImpl(true, (CombinedSerializer)masterDataResponseTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 126 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO"), qName16, (Serializer)referenceableSerializerImpl12);
/*     */ 
/*     */     
/* 129 */     QName qName17 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ServiceTO_v3");
/* 130 */     ServiceTO_v3_SOAPSerializer serviceTO_v3_SOAPSerializer = new ServiceTO_v3_SOAPSerializer(qName17, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 132 */     ReferenceableSerializerImpl referenceableSerializerImpl13 = new ReferenceableSerializerImpl(true, (CombinedSerializer)serviceTO_v3_SOAPSerializer, SOAPVersion.SOAP_11);
/* 133 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3, class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3"), qName17, (Serializer)referenceableSerializerImpl13);
/*     */ 
/*     */     
/* 136 */     QName qName18 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfTextPlanTO");
/* 137 */     QName qName19 = new QName("", "item");
/* 138 */     QName qName20 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "TextPlanTO");
/* 139 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO == null); super(true, true, qName19, qName20, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 142 */     ReferenceableSerializerImpl referenceableSerializerImpl14 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer4, SOAPVersion.SOAP_11);
/* 143 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;"), qName18, (Serializer)referenceableSerializerImpl14);
/*     */ 
/*     */     
/* 146 */     QName qName21 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CityStructuredTO");
/* 147 */     CityStructuredTO_SOAPSerializer cityStructuredTO_SOAPSerializer = new CityStructuredTO_SOAPSerializer(qName21, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 149 */     ReferenceableSerializerImpl referenceableSerializerImpl15 = new ReferenceableSerializerImpl(true, (CombinedSerializer)cityStructuredTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 150 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO"), qName21, (Serializer)referenceableSerializerImpl15);
/*     */ 
/*     */     
/* 153 */     QName qName22 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "UrbanizationTO");
/* 154 */     UrbanizationTO_SOAPSerializer urbanizationTO_SOAPSerializer = new UrbanizationTO_SOAPSerializer(qName22, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 156 */     ReferenceableSerializerImpl referenceableSerializerImpl16 = new ReferenceableSerializerImpl(true, (CombinedSerializer)urbanizationTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 157 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO"), qName22, (Serializer)referenceableSerializerImpl16);
/*     */ 
/*     */     
/* 160 */     QName qName23 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfAdjustmentReasonsTO");
/* 161 */     QName qName24 = new QName("", "item");
/* 162 */     QName qName25 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "AdjustmentReasonsTO");
/* 163 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO == null); super(true, true, qName24, qName25, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 166 */     ReferenceableSerializerImpl referenceableSerializerImpl17 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer5, SOAPVersion.SOAP_11);
/* 167 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO;"), qName23, (Serializer)referenceableSerializerImpl17);
/*     */ 
/*     */     
/* 170 */     QName qName26 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ParisheTO");
/* 171 */     ParisheTO_SOAPSerializer parisheTO_SOAPSerializer = new ParisheTO_SOAPSerializer(qName26, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 173 */     ReferenceableSerializerImpl referenceableSerializerImpl18 = new ReferenceableSerializerImpl(true, (CombinedSerializer)parisheTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 174 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO"), qName26, (Serializer)referenceableSerializerImpl18);
/*     */ 
/*     */     
/* 177 */     QName qName27 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "PlanTO");
/* 178 */     PlanTO_SOAPSerializer planTO_SOAPSerializer = new PlanTO_SOAPSerializer(qName27, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 180 */     ReferenceableSerializerImpl referenceableSerializerImpl19 = new ReferenceableSerializerImpl(true, (CombinedSerializer)planTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 181 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$PlanTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$PlanTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$PlanTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO"), qName27, (Serializer)referenceableSerializerImpl19);
/*     */ 
/*     */     
/* 184 */     QName qName28 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CityTO");
/* 185 */     CityTO_SOAPSerializer cityTO_SOAPSerializer = new CityTO_SOAPSerializer(qName28, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 187 */     ReferenceableSerializerImpl referenceableSerializerImpl20 = new ReferenceableSerializerImpl(true, (CombinedSerializer)cityTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 188 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CityTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$CityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CityTO"), qName28, (Serializer)referenceableSerializerImpl20);
/*     */ 
/*     */     
/* 191 */     QName qName29 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfServiceTO_v3");
/* 192 */     QName qName30 = new QName("", "item");
/* 193 */     QName qName31 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ServiceTO_v3");
/* 194 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 == null); super(true, true, qName30, qName31, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3, class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 197 */     ReferenceableSerializerImpl referenceableSerializerImpl21 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer6, SOAPVersion.SOAP_11);
/* 198 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3;"), qName29, (Serializer)referenceableSerializerImpl21);
/*     */ 
/*     */     
/* 201 */     QName qName32 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ServiceTO");
/* 202 */     ServiceTO_SOAPSerializer serviceTO_SOAPSerializer = new ServiceTO_SOAPSerializer(qName32, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 204 */     ReferenceableSerializerImpl referenceableSerializerImpl22 = new ReferenceableSerializerImpl(true, (CombinedSerializer)serviceTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 205 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO"), qName32, (Serializer)referenceableSerializerImpl22);
/*     */ 
/*     */     
/* 208 */     QName qName33 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfZoneTO");
/* 209 */     QName qName34 = new QName("", "item");
/* 210 */     QName qName35 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ZoneTO");
/* 211 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO == null); super(true, true, qName34, qName35, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 214 */     ReferenceableSerializerImpl referenceableSerializerImpl23 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer7, SOAPVersion.SOAP_11);
/* 215 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO;"), qName33, (Serializer)referenceableSerializerImpl23);
/*     */ 
/*     */     
/* 218 */     QName qName36 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/* 219 */     QName qName37 = new QName("", "item");
/* 220 */     if (class$java$lang$String == null); super(true, true, qName37, SchemaConstants.QNAME_TYPE_STRING, (QName)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 223 */     ReferenceableSerializerImpl referenceableSerializerImpl24 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer8, SOAPVersion.SOAP_11);
/* 224 */     if (array$Ljava$lang$String == null); registerSerializer((TypeMapping)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), qName36, (Serializer)referenceableSerializerImpl24);
/*     */ 
/*     */     
/* 227 */     QName qName38 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSectorTO");
/* 228 */     QName qName39 = new QName("", "item");
/* 229 */     QName qName40 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SectorTO");
/* 230 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SectorTO == null); super(true, true, qName39, qName40, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$SectorTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SectorTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SectorTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 233 */     ReferenceableSerializerImpl referenceableSerializerImpl25 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer9, SOAPVersion.SOAP_11);
/* 234 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SectorTO;"), qName38, (Serializer)referenceableSerializerImpl25);
/*     */ 
/*     */     
/* 237 */     QName qName41 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataAlcoAndCosResponse");
/* 238 */     WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS_SOAPSerializer(qName41, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 240 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS"), qName41, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 243 */     QName qName42 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "AlcoCosTO");
/* 244 */     AlcoCosTO_SOAPSerializer alcoCosTO_SOAPSerializer = new AlcoCosTO_SOAPSerializer(qName42, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 246 */     ReferenceableSerializerImpl referenceableSerializerImpl26 = new ReferenceableSerializerImpl(true, (CombinedSerializer)alcoCosTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 247 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO"), qName42, (Serializer)referenceableSerializerImpl26);
/*     */ 
/*     */     
/* 250 */     QName qName43 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MemosCategoryTO");
/* 251 */     MemosCategoryTO_SOAPSerializer memosCategoryTO_SOAPSerializer = new MemosCategoryTO_SOAPSerializer(qName43, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 253 */     ReferenceableSerializerImpl referenceableSerializerImpl27 = new ReferenceableSerializerImpl(true, (CombinedSerializer)memosCategoryTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 254 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO"), qName43, (Serializer)referenceableSerializerImpl27);
/*     */ 
/*     */     
/* 257 */     QName qName44 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService2");
/* 258 */     WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPSerializer(qName44, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 260 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS"), qName44, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 263 */     QName qName45 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService2Response");
/* 264 */     WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS_SOAPSerializer(qName45, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 266 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS"), qName45, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 269 */     QName qName46 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService");
/* 270 */     WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS_SOAPSerializer(qName46, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 272 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS"), qName46, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 275 */     QName qName47 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCityStructuredTO");
/* 276 */     QName qName48 = new QName("", "item");
/* 277 */     QName qName49 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CityStructuredTO");
/* 278 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO == null); super(true, true, qName48, qName49, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 281 */     ReferenceableSerializerImpl referenceableSerializerImpl28 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer10, SOAPVersion.SOAP_11);
/* 282 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;"), qName47, (Serializer)referenceableSerializerImpl28);
/*     */ 
/*     */     
/* 285 */     QName qName50 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfMunicipalitieTO");
/* 286 */     QName qName51 = new QName("", "item");
/* 287 */     QName qName52 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MunicipalitieTO");
/* 288 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO == null); super(true, true, qName51, qName52, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 291 */     ReferenceableSerializerImpl referenceableSerializerImpl29 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer11, SOAPVersion.SOAP_11);
/* 292 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;"), qName50, (Serializer)referenceableSerializerImpl29);
/*     */ 
/*     */     
/* 295 */     QName qName53 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CommunalCouncilChargeTO");
/* 296 */     CommunalCouncilChargeTO_SOAPSerializer communalCouncilChargeTO_SOAPSerializer = new CommunalCouncilChargeTO_SOAPSerializer(qName53, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 298 */     ReferenceableSerializerImpl referenceableSerializerImpl30 = new ReferenceableSerializerImpl(true, (CombinedSerializer)communalCouncilChargeTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 299 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO"), qName53, (Serializer)referenceableSerializerImpl30);
/*     */ 
/*     */     
/* 302 */     QName qName54 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "PromotionTO");
/* 303 */     PromotionTO_SOAPSerializer promotionTO_SOAPSerializer = new PromotionTO_SOAPSerializer(qName54, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 305 */     ReferenceableSerializerImpl referenceableSerializerImpl31 = new ReferenceableSerializerImpl(true, (CombinedSerializer)promotionTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 306 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO"), qName54, (Serializer)referenceableSerializerImpl31);
/*     */ 
/*     */     
/* 309 */     QName qName55 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "EquipmentTypeTO");
/* 310 */     EquipmentTypeTO_SOAPSerializer equipmentTypeTO_SOAPSerializer = new EquipmentTypeTO_SOAPSerializer(qName55, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 312 */     ReferenceableSerializerImpl referenceableSerializerImpl32 = new ReferenceableSerializerImpl(true, (CombinedSerializer)equipmentTypeTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 313 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.EquipmentTypeTO"), qName55, (Serializer)referenceableSerializerImpl32);
/*     */ 
/*     */     
/* 316 */     QName qName56 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "IntRequestTO");
/* 317 */     IntRequestTO_SOAPSerializer intRequestTO_SOAPSerializer = new IntRequestTO_SOAPSerializer(qName56, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 319 */     ReferenceableSerializerImpl referenceableSerializerImpl33 = new ReferenceableSerializerImpl(true, (CombinedSerializer)intRequestTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 320 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$IntRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.IntRequestTO"), qName56, (Serializer)referenceableSerializerImpl33);
/*     */ 
/*     */     
/* 323 */     QName qName57 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "TextPlanTO");
/* 324 */     TextPlanTO_SOAPSerializer textPlanTO_SOAPSerializer = new TextPlanTO_SOAPSerializer(qName57, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 326 */     ReferenceableSerializerImpl referenceableSerializerImpl34 = new ReferenceableSerializerImpl(true, (CombinedSerializer)textPlanTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 327 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO"), qName57, (Serializer)referenceableSerializerImpl34);
/*     */ 
/*     */     
/* 330 */     QName qName58 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfEquipmentTypeTO");
/* 331 */     QName qName59 = new QName("", "item");
/* 332 */     QName qName60 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "EquipmentTypeTO");
/* 333 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO == null); super(true, true, qName59, qName60, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.EquipmentTypeTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 336 */     ReferenceableSerializerImpl referenceableSerializerImpl35 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer12, SOAPVersion.SOAP_11);
/* 337 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.EquipmentTypeTO;"), qName58, (Serializer)referenceableSerializerImpl35);
/*     */ 
/*     */     
/* 340 */     QName qName61 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "PhoneModelTO");
/* 341 */     PhoneModelTO_SOAPSerializer phoneModelTO_SOAPSerializer = new PhoneModelTO_SOAPSerializer(qName61, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 343 */     ReferenceableSerializerImpl referenceableSerializerImpl36 = new ReferenceableSerializerImpl(true, (CombinedSerializer)phoneModelTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 344 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO"), qName61, (Serializer)referenceableSerializerImpl36);
/*     */ 
/*     */     
/* 347 */     QName qName62 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "IVRPlanBenefitTO");
/* 348 */     IVRPlanBenefitTO_SOAPSerializer iVRPlanBenefitTO_SOAPSerializer = new IVRPlanBenefitTO_SOAPSerializer(qName62, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 350 */     ReferenceableSerializerImpl referenceableSerializerImpl37 = new ReferenceableSerializerImpl(true, (CombinedSerializer)iVRPlanBenefitTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 351 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO"), qName62, (Serializer)referenceableSerializerImpl37);
/*     */ 
/*     */     
/* 354 */     QName qName63 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataGeographicalLocationResponse");
/* 355 */     WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS_SOAPSerializer(qName63, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 357 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS"), qName63, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 360 */     QName qName64 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CoolingReasonTO");
/* 361 */     CoolingReasonTO_SOAPSerializer coolingReasonTO_SOAPSerializer = new CoolingReasonTO_SOAPSerializer(qName64, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 363 */     ReferenceableSerializerImpl referenceableSerializerImpl38 = new ReferenceableSerializerImpl(true, (CombinedSerializer)coolingReasonTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 364 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO"), qName64, (Serializer)referenceableSerializerImpl38);
/*     */ 
/*     */     
/* 367 */     QName qName65 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/* 368 */     SecurityTO_SOAPSerializer securityTO_SOAPSerializer = new SecurityTO_SOAPSerializer(qName65, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 370 */     ReferenceableSerializerImpl referenceableSerializerImpl39 = new ReferenceableSerializerImpl(true, (CombinedSerializer)securityTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 371 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), qName65, (Serializer)referenceableSerializerImpl39);
/*     */ 
/*     */     
/* 374 */     QName qName66 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSubCategoryTO");
/* 375 */     QName qName67 = new QName("", "item");
/* 376 */     QName qName68 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SubCategoryTO");
/* 377 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO == null); super(true, true, qName67, qName68, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 380 */     ReferenceableSerializerImpl referenceableSerializerImpl40 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer13, SOAPVersion.SOAP_11);
/* 381 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;"), qName66, (Serializer)referenceableSerializerImpl40);
/*     */ 
/*     */     
/* 384 */     QName qName69 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ZoneStructuredTO");
/* 385 */     ZoneStructuredTO_SOAPSerializer zoneStructuredTO_SOAPSerializer = new ZoneStructuredTO_SOAPSerializer(qName69, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 387 */     ReferenceableSerializerImpl referenceableSerializerImpl41 = new ReferenceableSerializerImpl(true, (CombinedSerializer)zoneStructuredTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 388 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO"), qName69, (Serializer)referenceableSerializerImpl41);
/*     */ 
/*     */     
/* 391 */     QName qName70 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MasterDataResponseTO_v2");
/* 392 */     MasterDataResponseTO_v2_SOAPSerializer masterDataResponseTO_v2_SOAPSerializer = new MasterDataResponseTO_v2_SOAPSerializer(qName70, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 394 */     ReferenceableSerializerImpl referenceableSerializerImpl42 = new ReferenceableSerializerImpl(true, (CombinedSerializer)masterDataResponseTO_v2_SOAPSerializer, SOAPVersion.SOAP_11);
/* 395 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2 == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2, class$ve$com$movilnet$gdis$cia$ws$to$responses$MasterDataResponseTO_v2 = class$("ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO_v2"), qName70, (Serializer)referenceableSerializerImpl42);
/*     */ 
/*     */     
/* 398 */     QName qName71 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfUrbanizationTO");
/* 399 */     QName qName72 = new QName("", "item");
/* 400 */     QName qName73 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "UrbanizationTO");
/* 401 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO == null); super(true, true, qName72, qName73, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 404 */     ReferenceableSerializerImpl referenceableSerializerImpl43 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer14, SOAPVersion.SOAP_11);
/* 405 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO;"), qName71, (Serializer)referenceableSerializerImpl43);
/*     */ 
/*     */     
/* 408 */     QName qName74 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "LocalityTO");
/* 409 */     LocalityTO_SOAPSerializer localityTO_SOAPSerializer = new LocalityTO_SOAPSerializer(qName74, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 411 */     ReferenceableSerializerImpl referenceableSerializerImpl44 = new ReferenceableSerializerImpl(true, (CombinedSerializer)localityTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 412 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO"), qName74, (Serializer)referenceableSerializerImpl44);
/*     */ 
/*     */     
/* 415 */     QName qName75 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPlanTO");
/* 416 */     QName qName76 = new QName("", "item");
/* 417 */     QName qName77 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "PlanTO");
/* 418 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$PlanTO == null); super(true, true, qName76, qName77, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$PlanTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$PlanTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 421 */     ReferenceableSerializerImpl referenceableSerializerImpl45 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer15, SOAPVersion.SOAP_11);
/* 422 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;"), qName75, (Serializer)referenceableSerializerImpl45);
/*     */ 
/*     */     
/* 425 */     QName qName78 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCoolingReasonTO");
/* 426 */     QName qName79 = new QName("", "item");
/* 427 */     QName qName80 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CoolingReasonTO");
/* 428 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO == null); super(true, true, qName79, qName80, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 431 */     ReferenceableSerializerImpl referenceableSerializerImpl46 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer16, SOAPVersion.SOAP_11);
/* 432 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;"), qName78, (Serializer)referenceableSerializerImpl46);
/*     */ 
/*     */     
/* 435 */     QName qName81 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfParisheTO");
/* 436 */     QName qName82 = new QName("", "item");
/* 437 */     QName qName83 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ParisheTO");
/* 438 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO == null); super(true, true, qName82, qName83, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 441 */     ReferenceableSerializerImpl referenceableSerializerImpl47 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer17, SOAPVersion.SOAP_11);
/* 442 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;"), qName81, (Serializer)referenceableSerializerImpl47);
/*     */ 
/*     */     
/* 445 */     QName qName84 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataPersonalData");
/* 446 */     WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS_SOAPSerializer(qName84, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 448 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS"), qName84, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 451 */     QName qName85 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfServiceTO");
/* 452 */     QName qName86 = new QName("", "item");
/* 453 */     QName qName87 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ServiceTO");
/* 454 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO == null); super(true, true, qName86, qName87, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 457 */     ReferenceableSerializerImpl referenceableSerializerImpl48 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer18, SOAPVersion.SOAP_11);
/* 458 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO;"), qName85, (Serializer)referenceableSerializerImpl48);
/*     */ 
/*     */     
/* 461 */     QName qName88 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ProfessionTO");
/* 462 */     ProfessionTO_SOAPSerializer professionTO_SOAPSerializer = new ProfessionTO_SOAPSerializer(qName88, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 464 */     ReferenceableSerializerImpl referenceableSerializerImpl49 = new ReferenceableSerializerImpl(true, (CombinedSerializer)professionTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 465 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ProfessionTO"), qName88, (Serializer)referenceableSerializerImpl49);
/*     */ 
/*     */     
/* 468 */     QName qName89 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SubCategoryTO");
/* 469 */     SubCategoryTO_SOAPSerializer subCategoryTO_SOAPSerializer = new SubCategoryTO_SOAPSerializer(qName89, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 471 */     ReferenceableSerializerImpl referenceableSerializerImpl50 = new ReferenceableSerializerImpl(true, (CombinedSerializer)subCategoryTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 472 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO"), qName89, (Serializer)referenceableSerializerImpl50);
/*     */ 
/*     */     
/* 475 */     QName qName90 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfZoneStructuredTO");
/* 476 */     QName qName91 = new QName("", "item");
/* 477 */     QName qName92 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ZoneStructuredTO");
/* 478 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO == null); super(true, true, qName91, qName92, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 481 */     ReferenceableSerializerImpl referenceableSerializerImpl51 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer19, SOAPVersion.SOAP_11);
/* 482 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO;"), qName90, (Serializer)referenceableSerializerImpl51);
/*     */ 
/*     */     
/* 485 */     QName qName93 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfIVRPlanBenefitTO");
/* 486 */     QName qName94 = new QName("", "item");
/* 487 */     QName qName95 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "IVRPlanBenefitTO");
/* 488 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO == null); super(true, true, qName94, qName95, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 491 */     ReferenceableSerializerImpl referenceableSerializerImpl52 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer20, SOAPVersion.SOAP_11);
/* 492 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;"), qName93, (Serializer)referenceableSerializerImpl52);
/*     */ 
/*     */     
/* 495 */     QName qName96 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataPersonalDataResponse");
/* 496 */     WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS_SOAPSerializer(qName96, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 498 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS"), qName96, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 501 */     QName qName97 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCommunalCouncilChargeTO");
/* 502 */     QName qName98 = new QName("", "item");
/* 503 */     QName qName99 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "CommunalCouncilChargeTO");
/* 504 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO == null); super(true, true, qName98, qName99, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 507 */     ReferenceableSerializerImpl referenceableSerializerImpl53 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer21, SOAPVersion.SOAP_11);
/* 508 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;"), qName97, (Serializer)referenceableSerializerImpl53);
/*     */ 
/*     */     
/* 511 */     QName qName100 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfIVRPlanTO");
/* 512 */     QName qName101 = new QName("", "item");
/* 513 */     QName qName102 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "IVRPlanTO");
/* 514 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO == null); super(true, true, qName101, qName102, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 517 */     ReferenceableSerializerImpl referenceableSerializerImpl54 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer22, SOAPVersion.SOAP_11);
/* 518 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;"), qName100, (Serializer)referenceableSerializerImpl54);
/*     */ 
/*     */     
/* 521 */     QName qName103 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfBalanceListTO");
/* 522 */     QName qName104 = new QName("", "item");
/* 523 */     QName qName105 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BalanceListTO");
/* 524 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO == null); super(true, true, qName104, qName105, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 527 */     ReferenceableSerializerImpl referenceableSerializerImpl55 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer23, SOAPVersion.SOAP_11);
/* 528 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;"), qName103, (Serializer)referenceableSerializerImpl55);
/*     */ 
/*     */     
/* 531 */     QName qName106 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfProfessionTO");
/* 532 */     QName qName107 = new QName("", "item");
/* 533 */     QName qName108 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ProfessionTO");
/* 534 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO == null); super(true, true, qName107, qName108, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ProfessionTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 537 */     ReferenceableSerializerImpl referenceableSerializerImpl56 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer24, SOAPVersion.SOAP_11);
/* 538 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ProfessionTO;"), qName106, (Serializer)referenceableSerializerImpl56);
/*     */ 
/*     */     
/* 541 */     QName qName109 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "IVRPlanTO");
/* 542 */     IVRPlanTO_SOAPSerializer iVRPlanTO_SOAPSerializer = new IVRPlanTO_SOAPSerializer(qName109, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 544 */     ReferenceableSerializerImpl referenceableSerializerImpl57 = new ReferenceableSerializerImpl(true, (CombinedSerializer)iVRPlanTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 545 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO"), qName109, (Serializer)referenceableSerializerImpl57);
/*     */ 
/*     */     
/* 548 */     QName qName110 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfChargeCodeTO");
/* 549 */     QName qName111 = new QName("", "item");
/* 550 */     QName qName112 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ChargeCodeTO");
/* 551 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO == null); super(true, true, qName111, qName112, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 554 */     ReferenceableSerializerImpl referenceableSerializerImpl58 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer25, SOAPVersion.SOAP_11);
/* 555 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;"), qName110, (Serializer)referenceableSerializerImpl58);
/*     */ 
/*     */     
/* 558 */     QName qName113 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndServiceResponse");
/* 559 */     WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS_SOAPSerializer(qName113, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 561 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS"), qName113, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS_SOAPSerializer);
/*     */ 
/*     */     
/* 564 */     QName qName114 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfLocalityTO");
/* 565 */     QName qName115 = new QName("", "item");
/* 566 */     QName qName116 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "LocalityTO");
/* 567 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO == null); super(true, true, qName115, qName116, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 570 */     ReferenceableSerializerImpl referenceableSerializerImpl59 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer26, SOAPVersion.SOAP_11);
/* 571 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO;"), qName114, (Serializer)referenceableSerializerImpl59);
/*     */ 
/*     */     
/* 574 */     QName qName117 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/* 575 */     ApplicationClientTO_SOAPSerializer applicationClientTO_SOAPSerializer = new ApplicationClientTO_SOAPSerializer(qName117, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 577 */     ReferenceableSerializerImpl referenceableSerializerImpl60 = new ReferenceableSerializerImpl(true, (CombinedSerializer)applicationClientTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 578 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), qName117, (Serializer)referenceableSerializerImpl60);
/*     */ 
/*     */     
/* 581 */     QName qName118 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BalanceListTO");
/* 582 */     BalanceListTO_SOAPSerializer balanceListTO_SOAPSerializer = new BalanceListTO_SOAPSerializer(qName118, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 584 */     ReferenceableSerializerImpl referenceableSerializerImpl61 = new ReferenceableSerializerImpl(true, (CombinedSerializer)balanceListTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 585 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO"), qName118, (Serializer)referenceableSerializerImpl61);
/*     */ 
/*     */     
/* 588 */     QName qName119 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SellingAgentTO");
/* 589 */     SellingAgentTO_SOAPSerializer sellingAgentTO_SOAPSerializer = new SellingAgentTO_SOAPSerializer(qName119, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 591 */     ReferenceableSerializerImpl referenceableSerializerImpl62 = new ReferenceableSerializerImpl(true, (CombinedSerializer)sellingAgentTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 592 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO"), qName119, (Serializer)referenceableSerializerImpl62);
/*     */ 
/*     */     
/* 595 */     QName qName120 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "RequestTO");
/* 596 */     RequestTO_InterfaceSOAPSerializer requestTO_InterfaceSOAPSerializer = new RequestTO_InterfaceSOAPSerializer(qName120, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 598 */     ReferenceableSerializerImpl referenceableSerializerImpl63 = new ReferenceableSerializerImpl(true, (CombinedSerializer)requestTO_InterfaceSOAPSerializer, SOAPVersion.SOAP_11);
/* 599 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$RequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.RequestTO"), qName120, (Serializer)referenceableSerializerImpl63);
/*     */ 
/*     */     
/* 602 */     QName qName121 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SectorTO");
/* 603 */     SectorTO_SOAPSerializer sectorTO_SOAPSerializer = new SectorTO_SOAPSerializer(qName121, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 605 */     ReferenceableSerializerImpl referenceableSerializerImpl64 = new ReferenceableSerializerImpl(true, (CombinedSerializer)sectorTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 606 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SectorTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$SectorTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SectorTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SectorTO"), qName121, (Serializer)referenceableSerializerImpl64);
/*     */ 
/*     */     
/* 609 */     QName qName122 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPhoneModelTO");
/* 610 */     QName qName123 = new QName("", "item");
/* 611 */     QName qName124 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "PhoneModelTO");
/* 612 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO == null); super(true, true, qName123, qName124, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 615 */     ReferenceableSerializerImpl referenceableSerializerImpl65 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer27, SOAPVersion.SOAP_11);
/* 616 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO;"), qName122, (Serializer)referenceableSerializerImpl65);
/*     */ 
/*     */     
/* 619 */     QName qName125 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSellingAgentTO");
/* 620 */     QName qName126 = new QName("", "item");
/* 621 */     QName qName127 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SellingAgentTO");
/* 622 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO == null); super(true, true, qName126, qName127, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 625 */     ReferenceableSerializerImpl referenceableSerializerImpl66 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer28, SOAPVersion.SOAP_11);
/* 626 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;"), qName125, (Serializer)referenceableSerializerImpl66);
/*     */ 
/*     */     
/* 629 */     QName qName128 = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataGeographicalLocation");
/* 630 */     WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS_SOAPSerializer wSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS_SOAPSerializer = new WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS_SOAPSerializer(qName128, false, false, SOAPVersion.SOAP_11);
/*     */     
/* 632 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS"), qName128, (Serializer)wSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS_SOAPSerializer);
/*     */ 
/*     */     
/* 635 */     QName qName129 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ChargeCodeTO");
/* 636 */     ChargeCodeTO_SOAPSerializer chargeCodeTO_SOAPSerializer = new ChargeCodeTO_SOAPSerializer(qName129, true, true, SOAPVersion.SOAP_11);
/*     */     
/* 638 */     ReferenceableSerializerImpl referenceableSerializerImpl67 = new ReferenceableSerializerImpl(true, (CombinedSerializer)chargeCodeTO_SOAPSerializer, SOAPVersion.SOAP_11);
/* 639 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO == null); registerSerializer((TypeMapping)class$ve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO"), qName129, (Serializer)referenceableSerializerImpl67);
/*     */ 
/*     */     
/* 642 */     QName qName130 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfStateTO");
/* 643 */     QName qName131 = new QName("", "item");
/* 644 */     QName qName132 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "StateTO");
/* 645 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$StateTO == null); super(true, true, qName131, qName132, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$StateTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$StateTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.StateTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 648 */     ReferenceableSerializerImpl referenceableSerializerImpl68 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer29, SOAPVersion.SOAP_11);
/* 649 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.StateTO;"), qName130, (Serializer)referenceableSerializerImpl68);
/*     */ 
/*     */     
/* 652 */     QName qName133 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfMemosCategoryTO");
/* 653 */     QName qName134 = new QName("", "item");
/* 654 */     QName qName135 = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "MemosCategoryTO");
/* 655 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO == null); super(true, true, qName134, qName135, (QName)class$ve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO"), 1, null, SOAPVersion.SOAP_11);
/*     */ 
/*     */     
/* 658 */     ReferenceableSerializerImpl referenceableSerializerImpl69 = new ReferenceableSerializerImpl(true, (CombinedSerializer)objectArraySerializer30, SOAPVersion.SOAP_11);
/* 659 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO == null); registerSerializer((TypeMapping)array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO;"), qName133, (Serializer)referenceableSerializerImpl69);
/*     */     
/* 661 */     WSBaseMasterData_SerializerRegistry12 internal12Registry = new WSBaseMasterData_SerializerRegistry12();
/* 662 */     return internal12Registry.getRegistry(registry);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void registerSerializer(TypeMapping mapping, Class javaType, QName xmlType, Serializer ser) {
/* 667 */     mapping.register(javaType, xmlType, (SerializerFactory)new SingletonSerializerFactory(ser), (DeserializerFactory)new SingletonDeserializerFactory((Deserializer)ser));
/*     */   } }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\runtime\WSBaseMasterData_SerializerRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */