/*    */ package ve.com.movilnet.gdis.cia.ws.to.requests;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidatePlanModelRequestTO
/*    */   extends RequestTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String cosName;
/*    */   protected String planCode;
/*    */   protected String serial;
/*    */   protected String transactionType;
/*    */   
/*    */   public String getCosName() {
/* 20 */     return this.cosName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 24 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public String getPlanCode() {
/* 28 */     return this.planCode;
/*    */   }
/*    */   
/*    */   public void setPlanCode(String planCode) {
/* 32 */     this.planCode = planCode;
/*    */   }
/*    */   
/*    */   public String getSerial() {
/* 36 */     return this.serial;
/*    */   }
/*    */   
/*    */   public void setSerial(String serial) {
/* 40 */     this.serial = serial;
/*    */   }
/*    */   
/*    */   public String getTransactionType() {
/* 44 */     return this.transactionType;
/*    */   }
/*    */   
/*    */   public void setTransactionType(String transactionType) {
/* 48 */     this.transactionType = transactionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\ValidatePlanModelRequestTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */