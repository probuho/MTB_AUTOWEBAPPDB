/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MunicipalitieTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String municipioCode;
/*    */   protected String parroquiaName;
/*    */   protected String stateCode;
/*    */   
/*    */   public String getMunicipioCode() {
/* 19 */     return this.municipioCode;
/*    */   }
/*    */   
/*    */   public void setMunicipioCode(String municipioCode) {
/* 23 */     this.municipioCode = municipioCode;
/*    */   }
/*    */   
/*    */   public String getParroquiaName() {
/* 27 */     return this.parroquiaName;
/*    */   }
/*    */   
/*    */   public void setParroquiaName(String parroquiaName) {
/* 31 */     this.parroquiaName = parroquiaName;
/*    */   }
/*    */   
/*    */   public String getStateCode() {
/* 35 */     return this.stateCode;
/*    */   }
/*    */   
/*    */   public void setStateCode(String stateCode) {
/* 39 */     this.stateCode = stateCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\MunicipalitieTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */