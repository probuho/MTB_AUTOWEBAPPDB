/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidateAuthorisedProfileRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidateAuthorisedProfileRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidateAuthorisedProfileRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_aplicationType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "aplicationType");
/*  33 */   private static final QName ns2_customerType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "customerType");
/*  34 */   private static final QName ns2_genfield_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "genfield");
/*  35 */   private static final QName ns2_ArrayOfstring_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/*     */   private CombinedSerializer myns2_ArrayOfstring__String_Array_LiteralSerializer1;
/*  37 */   private static final QName ns2_planCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCode");
/*  38 */   private static final QName ns2_serviceCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceCode");
/*  39 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType");
/*  40 */   private static final QName ns2_userSsnId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "userSsnId"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2; private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myaplicationType_INDEX = 5;
/*     */   private static final int mycustomerType_INDEX = 6;
/*     */   private static final int mygenfield_INDEX = 7;
/*     */   private static final int myplanCode_INDEX = 8;
/*     */   private static final int myserviceCode_INDEX = 9;
/*     */   private static final int mytransactionType_INDEX = 10;
/*     */   private static final int myuserSsnId_INDEX = 11;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   
/*     */   public ValidateAuthorisedProfileRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  55 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  59 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidateAuthorisedProfileRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  60 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidateAuthorisedProfileRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  61 */     if (class$java$lang$String == null); ((ValidateAuthorisedProfileRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  62 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  63 */     if (array$Ljava$lang$String == null); ((ValidateAuthorisedProfileRequestTO_SOAPSerializer)registry).myns2_ArrayOfstring__String_Array_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), ns2_ArrayOfstring_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  68 */     ValidateAuthorisedProfileRequestTO instance = new ValidateAuthorisedProfileRequestTO();
/*  69 */     ValidateAuthorisedProfileRequestTO_SOAPBuilder builder = null;
/*     */     
/*  71 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  74 */     reader.nextElementContent();
/*  75 */     QName startName = reader.getName();
/*  76 */     for (int i = 0; i < 12; i++) {
/*  77 */       QName elementName = reader.getName();
/*  78 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  81 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  82 */         context.setNillable(true);
/*  83 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  84 */         if (member instanceof SOAPDeserializationState) {
/*  85 */           if (builder == null) {
/*  86 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/*  88 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  89 */           isComplete = false;
/*  90 */         } else if (member != null) {
/*  91 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  93 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  96 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  97 */         context.setNillable(true);
/*  98 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  99 */         if (object instanceof SOAPDeserializationState) {
/* 100 */           if (builder == null) {
/* 101 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 103 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 104 */           isComplete = false;
/* 105 */         } else if (object != null) {
/* 106 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 108 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 111 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 112 */         context.setNillable(true);
/* 113 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 114 */         if (object instanceof SOAPDeserializationState) {
/* 115 */           if (builder == null) {
/* 116 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 118 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 119 */           isComplete = false;
/* 120 */         } else if (object != null) {
/* 121 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 123 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 126 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 127 */         context.setNillable(true);
/* 128 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 129 */         if (object instanceof SOAPDeserializationState) {
/* 130 */           if (builder == null) {
/* 131 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 133 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 134 */           isComplete = false;
/* 135 */         } else if (object != null) {
/* 136 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 138 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 141 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 142 */         context.setNillable(true);
/* 143 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 144 */         if (object instanceof SOAPDeserializationState) {
/* 145 */           if (builder == null) {
/* 146 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 148 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 149 */           isComplete = false;
/* 150 */         } else if (object != null) {
/* 151 */           instance.setTransactionId((String)object);
/*     */         } 
/* 153 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 156 */       else if (matchQName(elementName, ns2_aplicationType_QNAME)) {
/* 157 */         context.setNillable(true);
/* 158 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_aplicationType_QNAME, reader, context);
/* 159 */         if (object instanceof SOAPDeserializationState) {
/* 160 */           if (builder == null) {
/* 161 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 163 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 164 */           isComplete = false;
/* 165 */         } else if (object != null) {
/* 166 */           instance.setAplicationType((String)object);
/*     */         } 
/* 168 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 171 */       else if (matchQName(elementName, ns2_customerType_QNAME)) {
/* 172 */         context.setNillable(true);
/* 173 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_customerType_QNAME, reader, context);
/* 174 */         if (object instanceof SOAPDeserializationState) {
/* 175 */           if (builder == null) {
/* 176 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 178 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 179 */           isComplete = false;
/* 180 */         } else if (object != null) {
/* 181 */           instance.setCustomerType((String)object);
/*     */         } 
/* 183 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 186 */       else if (matchQName(elementName, ns2_genfield_QNAME)) {
/* 187 */         context.setNillable(true);
/* 188 */         Object object = this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.deserialize(ns2_genfield_QNAME, reader, context);
/* 189 */         if (object instanceof SOAPDeserializationState) {
/* 190 */           if (builder == null) {
/* 191 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 193 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 194 */           isComplete = false;
/* 195 */         } else if (object != null) {
/* 196 */           instance.setGenfield((String[])object);
/*     */         } 
/* 198 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 201 */       else if (matchQName(elementName, ns2_planCode_QNAME)) {
/* 202 */         context.setNillable(true);
/* 203 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCode_QNAME, reader, context);
/* 204 */         if (object instanceof SOAPDeserializationState) {
/* 205 */           if (builder == null) {
/* 206 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 208 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 209 */           isComplete = false;
/* 210 */         } else if (object != null) {
/* 211 */           instance.setPlanCode((String)object);
/*     */         } 
/* 213 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 216 */       else if (matchQName(elementName, ns2_serviceCode_QNAME)) {
/* 217 */         context.setNillable(true);
/* 218 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceCode_QNAME, reader, context);
/* 219 */         if (object instanceof SOAPDeserializationState) {
/* 220 */           if (builder == null) {
/* 221 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 223 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 224 */           isComplete = false;
/* 225 */         } else if (object != null) {
/* 226 */           instance.setServiceCode((String)object);
/*     */         } 
/* 228 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 231 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 232 */         context.setNillable(true);
/* 233 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 234 */         if (object instanceof SOAPDeserializationState) {
/* 235 */           if (builder == null) {
/* 236 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 238 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 239 */           isComplete = false;
/* 240 */         } else if (object != null) {
/* 241 */           instance.setTransactionType((String)object);
/*     */         } 
/* 243 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 246 */       else if (matchQName(elementName, ns2_userSsnId_QNAME)) {
/* 247 */         context.setNillable(true);
/* 248 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_userSsnId_QNAME, reader, context);
/* 249 */         if (object instanceof SOAPDeserializationState) {
/* 250 */           if (builder == null) {
/* 251 */             builder = new ValidateAuthorisedProfileRequestTO_SOAPBuilder();
/*     */           }
/* 253 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 254 */           isComplete = false;
/* 255 */         } else if (object != null) {
/* 256 */           instance.setUserSsnId((String)object);
/*     */         } 
/* 258 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 261 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_userSsnId_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 266 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 267 */     } catch (XMLReaderException xmle) {
/* 268 */       if (startName != null) {
/* 269 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 271 */       throw xmle;
/*     */     } 
/*     */     
/* 274 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 278 */     ValidateAuthorisedProfileRequestTO instance = (ValidateAuthorisedProfileRequestTO)obj;
/*     */     
/* 280 */     context.setNillable(true);
/* 281 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 282 */     context.setNillable(true);
/* 283 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 284 */     context.setNillable(true);
/* 285 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 286 */     context.setNillable(true);
/* 287 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 288 */     context.setNillable(true);
/* 289 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 290 */     context.setNillable(true);
/* 291 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getAplicationType(), ns2_aplicationType_QNAME, null, writer, context);
/* 292 */     context.setNillable(true);
/* 293 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCustomerType(), ns2_customerType_QNAME, null, writer, context);
/* 294 */     context.setNillable(true);
/* 295 */     this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.serialize(instance.getGenfield(), ns2_genfield_QNAME, null, writer, context);
/* 296 */     context.setNillable(true);
/* 297 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCode(), ns2_planCode_QNAME, null, writer, context);
/* 298 */     context.setNillable(true);
/* 299 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceCode(), ns2_serviceCode_QNAME, null, writer, context);
/* 300 */     context.setNillable(true);
/* 301 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/* 302 */     context.setNillable(true);
/* 303 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getUserSsnId(), ns2_userSsnId_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidateAuthorisedProfileRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */