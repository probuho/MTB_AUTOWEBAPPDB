/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.IntRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.IntRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class IntRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_value_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "value");
/*  33 */   private static final QName ns3_int_TYPE_QNAME = SchemaConstants.QNAME_TYPE_INT; private CombinedSerializer myns3__int__int_Int_Serializer; private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1;
/*     */   private static final int myserviceProvider_INDEX = 2;
/*     */   private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myvalue_INDEX = 5;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   
/*     */   public IntRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  43 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  47 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((IntRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  48 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((IntRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  49 */     if (class$java$lang$String == null); ((IntRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  50 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  51 */     this.myns3__int__int_Int_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), int.class, ns3_int_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  56 */     IntRequestTO instance = new IntRequestTO();
/*  57 */     IntRequestTO_SOAPBuilder builder = null;
/*     */     
/*  59 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  62 */     reader.nextElementContent();
/*  63 */     QName startName = reader.getName();
/*  64 */     for (int i = 0; i < 6; i++) {
/*  65 */       QName elementName = reader.getName();
/*  66 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  69 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  70 */         context.setNillable(true);
/*  71 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  72 */         if (member instanceof SOAPDeserializationState) {
/*  73 */           if (builder == null) {
/*  74 */             builder = new IntRequestTO_SOAPBuilder();
/*     */           }
/*  76 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  77 */           isComplete = false;
/*  78 */         } else if (member != null) {
/*  79 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  81 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  84 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  85 */         context.setNillable(true);
/*  86 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  87 */         if (object instanceof SOAPDeserializationState) {
/*  88 */           if (builder == null) {
/*  89 */             builder = new IntRequestTO_SOAPBuilder();
/*     */           }
/*  91 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/*  92 */           isComplete = false;
/*  93 */         } else if (object != null) {
/*  94 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/*  96 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  99 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 100 */         context.setNillable(true);
/* 101 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 102 */         if (object instanceof SOAPDeserializationState) {
/* 103 */           if (builder == null) {
/* 104 */             builder = new IntRequestTO_SOAPBuilder();
/*     */           }
/* 106 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 107 */           isComplete = false;
/* 108 */         } else if (object != null) {
/* 109 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 111 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 114 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 115 */         context.setNillable(true);
/* 116 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 117 */         if (object instanceof SOAPDeserializationState) {
/* 118 */           if (builder == null) {
/* 119 */             builder = new IntRequestTO_SOAPBuilder();
/*     */           }
/* 121 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 122 */           isComplete = false;
/* 123 */         } else if (object != null) {
/* 124 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 126 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 129 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 130 */         context.setNillable(true);
/* 131 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 132 */         if (object instanceof SOAPDeserializationState) {
/* 133 */           if (builder == null) {
/* 134 */             builder = new IntRequestTO_SOAPBuilder();
/*     */           }
/* 136 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 137 */           isComplete = false;
/* 138 */         } else if (object != null) {
/* 139 */           instance.setTransactionId((String)object);
/*     */         } 
/* 141 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 144 */       else if (matchQName(elementName, ns2_value_QNAME)) {
/* 145 */         context.setNillable(true);
/* 146 */         Object object = this.myns3__int__int_Int_Serializer.deserialize(ns2_value_QNAME, reader, context);
/* 147 */         if (object instanceof SOAPDeserializationState) {
/* 148 */           if (builder == null) {
/* 149 */             builder = new IntRequestTO_SOAPBuilder();
/*     */           }
/* 151 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 152 */           isComplete = false;
/* 153 */         } else if (object != null) {
/* 154 */           instance.setValue(((Integer)object).intValue());
/*     */         } 
/* 156 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 159 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_value_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 164 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 165 */     } catch (XMLReaderException xmle) {
/* 166 */       if (startName != null) {
/* 167 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 169 */       throw xmle;
/*     */     } 
/*     */     
/* 172 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 176 */     IntRequestTO instance = (IntRequestTO)obj;
/*     */     
/* 178 */     context.setNillable(true);
/* 179 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 180 */     context.setNillable(true);
/* 181 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 182 */     context.setNillable(true);
/* 183 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 184 */     context.setNillable(true);
/* 185 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 186 */     context.setNillable(true);
/* 187 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 188 */     context.setNillable(true);
/* 189 */     this.myns3__int__int_Int_Serializer.serialize(new Integer(instance.getValue()), ns2_value_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\IntRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */