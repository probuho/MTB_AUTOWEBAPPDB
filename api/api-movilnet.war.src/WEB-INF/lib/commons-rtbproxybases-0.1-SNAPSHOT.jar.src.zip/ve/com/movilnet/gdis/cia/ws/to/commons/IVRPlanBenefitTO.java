/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IVRPlanBenefitTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String balanceName;
/*    */   protected String cosName;
/*    */   protected long quantity;
/*    */   protected String unitType;
/*    */   
/*    */   public String getBalanceName() {
/* 20 */     return this.balanceName;
/*    */   }
/*    */   
/*    */   public void setBalanceName(String balanceName) {
/* 24 */     this.balanceName = balanceName;
/*    */   }
/*    */   
/*    */   public String getCosName() {
/* 28 */     return this.cosName;
/*    */   }
/*    */   
/*    */   public void setCosName(String cosName) {
/* 32 */     this.cosName = cosName;
/*    */   }
/*    */   
/*    */   public long getQuantity() {
/* 36 */     return this.quantity;
/*    */   }
/*    */   
/*    */   public void setQuantity(long quantity) {
/* 40 */     this.quantity = quantity;
/*    */   }
/*    */   
/*    */   public String getUnitType() {
/* 44 */     return this.unitType;
/*    */   }
/*    */   
/*    */   public void setUnitType(String unitType) {
/* 48 */     this.unitType = unitType;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\IVRPlanBenefitTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */