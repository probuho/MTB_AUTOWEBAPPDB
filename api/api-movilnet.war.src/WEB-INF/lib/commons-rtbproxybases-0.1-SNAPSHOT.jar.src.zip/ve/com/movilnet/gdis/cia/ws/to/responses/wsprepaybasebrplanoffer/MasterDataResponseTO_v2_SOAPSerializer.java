/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO_v2;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.runtime.MasterDataResponseTO_v2_SOAPBuilder;
/*     */ 
/*     */ public class MasterDataResponseTO_v2_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_executionTime_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "executionTime");
/*  20 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  22 */   private static final QName ns2_origin_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "origin");
/*  23 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  25 */   private static final QName ns2_responseCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseCode");
/*  26 */   private static final QName ns2_responseDescription_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseDescription");
/*  27 */   private static final QName ns2_responseMessage_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseMessage");
/*  28 */   private static final QName ns2_responseSubCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "responseSubCode");
/*  29 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  30 */   private static final QName ns2_adjustmentReasons_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "adjustmentReasons");
/*  31 */   private static final QName ns2_ArrayOfAdjustmentReasonsTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfAdjustmentReasonsTO");
/*     */   private CombinedSerializer myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1;
/*  33 */   private static final QName ns2_alcoCosTO_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcoCosTO");
/*  34 */   private static final QName ns2_AlcoCosTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "AlcoCosTO");
/*     */   private CombinedSerializer myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer;
/*  36 */   private static final QName ns2_balanceList_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "balanceList");
/*  37 */   private static final QName ns2_ArrayOfBalanceListTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfBalanceListTO");
/*     */   private CombinedSerializer myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1;
/*  39 */   private static final QName ns2_chargeCodes_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "chargeCodes");
/*  40 */   private static final QName ns2_ArrayOfChargeCodeTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfChargeCodeTO");
/*     */   private CombinedSerializer myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1;
/*  42 */   private static final QName ns2_city_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "city");
/*  43 */   private static final QName ns2_ArrayOfCityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCityTO");
/*     */   private CombinedSerializer myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1;
/*  45 */   private static final QName ns2_communalCouncilCharges_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "communalCouncilCharges");
/*  46 */   private static final QName ns2_ArrayOfCommunalCouncilChargeTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCommunalCouncilChargeTO");
/*     */   private CombinedSerializer myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1;
/*  48 */   private static final QName ns2_coolingReason_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "coolingReason");
/*  49 */   private static final QName ns2_ArrayOfCoolingReasonTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCoolingReasonTO");
/*     */   private CombinedSerializer myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1;
/*  51 */   private static final QName ns2_equipmentTypeTO_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "equipmentTypeTO");
/*  52 */   private static final QName ns2_ArrayOfEquipmentTypeTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfEquipmentTypeTO");
/*     */   private CombinedSerializer myns2_ArrayOfEquipmentTypeTO__EquipmentTypeTOArray_LiteralSerializer1;
/*  54 */   private static final QName ns2_feechargeType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "feechargeType");
/*  55 */   private static final QName ns2_ArrayOfSubCategoryTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSubCategoryTO");
/*     */   private CombinedSerializer myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1;
/*  57 */   private static final QName ns2_ivrPlanBenefits_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ivrPlanBenefits");
/*  58 */   private static final QName ns2_ArrayOfIVRPlanBenefitTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfIVRPlanBenefitTO");
/*     */   private CombinedSerializer myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1;
/*  60 */   private static final QName ns2_ivrPlans_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ivrPlans");
/*  61 */   private static final QName ns2_ArrayOfIVRPlanTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfIVRPlanTO");
/*     */   private CombinedSerializer myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1;
/*  63 */   private static final QName ns2_locality_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "locality");
/*  64 */   private static final QName ns2_ArrayOfLocalityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfLocalityTO");
/*     */   private CombinedSerializer myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1;
/*  66 */   private static final QName ns2_memosCategory_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "memosCategory");
/*  67 */   private static final QName ns2_ArrayOfMemosCategoryTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfMemosCategoryTO");
/*     */   private CombinedSerializer myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1;
/*  69 */   private static final QName ns2_modelsPhones_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "modelsPhones");
/*  70 */   private static final QName ns2_ArrayOfPhoneModelTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPhoneModelTO");
/*     */   private CombinedSerializer myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1;
/*  72 */   private static final QName ns2_municipalitie_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "municipalitie");
/*  73 */   private static final QName ns2_ArrayOfMunicipalitieTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfMunicipalitieTO");
/*     */   private CombinedSerializer myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1;
/*  75 */   private static final QName ns2_nationalities_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "nationalities");
/*  76 */   private static final QName ns2_ArrayOfNationalitiesTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfNationalitiesTO");
/*     */   private CombinedSerializer myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1;
/*  78 */   private static final QName ns2_parishe_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "parishe");
/*  79 */   private static final QName ns2_ArrayOfParisheTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfParisheTO");
/*     */   private CombinedSerializer myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1;
/*  81 */   private static final QName ns2_plans_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "plans");
/*  82 */   private static final QName ns2_ArrayOfPlanTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPlanTO");
/*     */   private CombinedSerializer myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1;
/*  84 */   private static final QName ns2_profession_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "profession");
/*  85 */   private static final QName ns2_ArrayOfProfessionTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfProfessionTO");
/*     */   private CombinedSerializer myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1;
/*  87 */   private static final QName ns2_promotions_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "promotions");
/*  88 */   private static final QName ns2_ArrayOfPromotionTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfPromotionTO");
/*     */   private CombinedSerializer myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1;
/*  90 */   private static final QName ns2_promotionsMig_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "promotionsMig");
/*  91 */   private static final QName ns2_sector_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "sector");
/*  92 */   private static final QName ns2_ArrayOfSectorTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSectorTO");
/*     */   private CombinedSerializer myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1;
/*  94 */   private static final QName ns2_sellingAgent_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "sellingAgent");
/*  95 */   private static final QName ns2_ArrayOfSellingAgentTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfSellingAgentTO");
/*     */   private CombinedSerializer myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1;
/*  97 */   private static final QName ns2_services_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "services");
/*  98 */   private static final QName ns2_ArrayOfServiceTO_v3_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfServiceTO_v3");
/*     */   private CombinedSerializer myns2_ArrayOfServiceTO_v3__ServiceTO_v3Array_LiteralSerializer1;
/* 100 */   private static final QName ns2_state_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "state");
/* 101 */   private static final QName ns2_ArrayOfStateTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfStateTO");
/*     */   private CombinedSerializer myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1;
/* 103 */   private static final QName ns2_structuredCities_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "structuredCities");
/* 104 */   private static final QName ns2_ArrayOfCityStructuredTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfCityStructuredTO");
/*     */   private CombinedSerializer myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1;
/* 106 */   private static final QName ns2_structuredStates_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "structuredStates");
/* 107 */   private static final QName ns2_structuredZones_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "structuredZones");
/* 108 */   private static final QName ns2_ArrayOfZoneStructuredTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfZoneStructuredTO");
/*     */   private CombinedSerializer myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1;
/* 110 */   private static final QName ns2_subCategory_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subCategory");
/* 111 */   private static final QName ns2_textPlans_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "textPlans");
/* 112 */   private static final QName ns2_ArrayOfTextPlanTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfTextPlanTO");
/*     */   private CombinedSerializer myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1;
/* 114 */   private static final QName ns2_urbanization_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "urbanization");
/* 115 */   private static final QName ns2_ArrayOfUrbanizationTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfUrbanizationTO");
/*     */   private CombinedSerializer myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1;
/* 117 */   private static final QName ns2_zone_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "zone");
/* 118 */   private static final QName ns2_ArrayOfZoneTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfZoneTO"); private CombinedSerializer myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1; private static final int myexecutionTime_INDEX = 0; private static final int myorigin_INDEX = 1; private static final int myresponseCode_INDEX = 2; private static final int myresponseDescription_INDEX = 3; private static final int myresponseMessage_INDEX = 4; private static final int myresponseSubCode_INDEX = 5; private static final int mytransactionId_INDEX = 6; private static final int myadjustmentReasons_INDEX = 7; private static final int myalcoCosTO_INDEX = 8; private static final int mybalanceList_INDEX = 9; private static final int mychargeCodes_INDEX = 10; private static final int mycity_INDEX = 11; private static final int mycommunalCouncilCharges_INDEX = 12; private static final int mycoolingReason_INDEX = 13; private static final int myequipmentTypeTO_INDEX = 14; private static final int myfeechargeType_INDEX = 15; private static final int myivrPlanBenefits_INDEX = 16; private static final int myivrPlans_INDEX = 17; private static final int mylocality_INDEX = 18; private static final int mymemosCategory_INDEX = 19; private static final int mymodelsPhones_INDEX = 20; private static final int mymunicipalitie_INDEX = 21; private static final int mynationalities_INDEX = 22; private static final int myparishe_INDEX = 23; private static final int myplans_INDEX = 24; private static final int myprofession_INDEX = 25; private static final int mypromotions_INDEX = 26; private static final int mypromotionsMig_INDEX = 27; private static final int mysector_INDEX = 28;
/*     */   private static final int mysellingAgent_INDEX = 29;
/*     */   private static final int myservices_INDEX = 30;
/*     */   private static final int mystate_INDEX = 31;
/*     */   private static final int mystructuredCities_INDEX = 32;
/*     */   private static final int mystructuredStates_INDEX = 33;
/*     */   private static final int mystructuredZones_INDEX = 34;
/*     */   private static final int mysubCategory_INDEX = 35;
/*     */   private static final int mytextPlans_INDEX = 36;
/*     */   private static final int myurbanization_INDEX = 37;
/*     */   private static final int myzone_INDEX = 38;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO;
/*     */   private static Class array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO;
/*     */   
/*     */   public MasterDataResponseTO_v2_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/* 161 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 165 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/* 166 */     if (class$java$lang$String == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/* 167 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$AdjustmentReasonsTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO;"), ns2_ArrayOfAdjustmentReasonsTO_TYPE_QNAME);
/* 168 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$AlcoCosTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO"), ns2_AlcoCosTO_TYPE_QNAME);
/* 169 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$BalanceListTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;"), ns2_ArrayOfBalanceListTO_TYPE_QNAME);
/* 170 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ChargeCodeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;"), ns2_ArrayOfChargeCodeTO_TYPE_QNAME);
/* 171 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CityTO;"), ns2_ArrayOfCityTO_TYPE_QNAME);
/* 172 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CommunalCouncilChargeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;"), ns2_ArrayOfCommunalCouncilChargeTO_TYPE_QNAME);
/* 173 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CoolingReasonTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;"), ns2_ArrayOfCoolingReasonTO_TYPE_QNAME);
/* 174 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfEquipmentTypeTO__EquipmentTypeTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$EquipmentTypeTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.EquipmentTypeTO;"), ns2_ArrayOfEquipmentTypeTO_TYPE_QNAME);
/* 175 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SubCategoryTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;"), ns2_ArrayOfSubCategoryTO_TYPE_QNAME);
/* 176 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanBenefitTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;"), ns2_ArrayOfIVRPlanBenefitTO_TYPE_QNAME);
/* 177 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$IVRPlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;"), ns2_ArrayOfIVRPlanTO_TYPE_QNAME);
/* 178 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$LocalityTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO;"), ns2_ArrayOfLocalityTO_TYPE_QNAME);
/* 179 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$MemosCategoryTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO;"), ns2_ArrayOfMemosCategoryTO_TYPE_QNAME);
/* 180 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PhoneModelTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO;"), ns2_ArrayOfPhoneModelTO_TYPE_QNAME);
/* 181 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$MunicipalitieTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;"), ns2_ArrayOfMunicipalitieTO_TYPE_QNAME);
/* 182 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$NationalitiesTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.NationalitiesTO;"), ns2_ArrayOfNationalitiesTO_TYPE_QNAME);
/* 183 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ParisheTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;"), ns2_ArrayOfParisheTO_TYPE_QNAME);
/* 184 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;"), ns2_ArrayOfPlanTO_TYPE_QNAME);
/* 185 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ProfessionTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ProfessionTO;"), ns2_ArrayOfProfessionTO_TYPE_QNAME);
/* 186 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$PromotionTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO;"), ns2_ArrayOfPromotionTO_TYPE_QNAME);
/* 187 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SectorTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SectorTO;"), ns2_ArrayOfSectorTO_TYPE_QNAME);
/* 188 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$SellingAgentTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;"), ns2_ArrayOfSellingAgentTO_TYPE_QNAME);
/* 189 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfServiceTO_v3__ServiceTO_v3Array_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ServiceTO_v3 = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3;"), ns2_ArrayOfServiceTO_v3_TYPE_QNAME);
/* 190 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$StateTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.StateTO;"), ns2_ArrayOfStateTO_TYPE_QNAME);
/* 191 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$CityStructuredTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;"), ns2_ArrayOfCityStructuredTO_TYPE_QNAME);
/* 192 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneStructuredTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO;"), ns2_ArrayOfZoneStructuredTO_TYPE_QNAME);
/* 193 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$TextPlanTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;"), ns2_ArrayOfTextPlanTO_TYPE_QNAME);
/* 194 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$UrbanizationTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO;"), ns2_ArrayOfUrbanizationTO_TYPE_QNAME);
/* 195 */     if (array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO == null); ((MasterDataResponseTO_v2_SOAPSerializer)registry).myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO, array$Lve$com$movilnet$gdis$cia$ws$to$commons$ZoneTO = class$("[Lve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO;"), ns2_ArrayOfZoneTO_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/* 200 */     MasterDataResponseTO_v2 instance = new MasterDataResponseTO_v2();
/* 201 */     MasterDataResponseTO_v2_SOAPBuilder builder = null;
/*     */     
/* 203 */     boolean isComplete = true;
/*     */ 
/*     */     
/* 206 */     reader.nextElementContent();
/* 207 */     QName startName = reader.getName();
/* 208 */     for (int i = 0; i < 39; i++) {
/* 209 */       QName elementName = reader.getName();
/* 210 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/* 213 */       if (matchQName(elementName, ns2_executionTime_QNAME)) {
/* 214 */         context.setNillable(true);
/* 215 */         Object member = this.myns3__long__long_Long_Serializer.deserialize(ns2_executionTime_QNAME, reader, context);
/* 216 */         if (member instanceof SOAPDeserializationState) {
/* 217 */           if (builder == null) {
/* 218 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 220 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/* 221 */           isComplete = false;
/* 222 */         } else if (member != null) {
/* 223 */           instance.setExecutionTime(((Long)member).longValue());
/*     */         } 
/* 225 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 228 */       else if (matchQName(elementName, ns2_origin_QNAME)) {
/* 229 */         context.setNillable(true);
/* 230 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_origin_QNAME, reader, context);
/* 231 */         if (object instanceof SOAPDeserializationState) {
/* 232 */           if (builder == null) {
/* 233 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 235 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 236 */           isComplete = false;
/* 237 */         } else if (object != null) {
/* 238 */           instance.setOrigin((String)object);
/*     */         } 
/* 240 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 243 */       else if (matchQName(elementName, ns2_responseCode_QNAME)) {
/* 244 */         context.setNillable(true);
/* 245 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseCode_QNAME, reader, context);
/* 246 */         if (object instanceof SOAPDeserializationState) {
/* 247 */           if (builder == null) {
/* 248 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 250 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 251 */           isComplete = false;
/* 252 */         } else if (object != null) {
/* 253 */           instance.setResponseCode((String)object);
/*     */         } 
/* 255 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 258 */       else if (matchQName(elementName, ns2_responseDescription_QNAME)) {
/* 259 */         context.setNillable(true);
/* 260 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseDescription_QNAME, reader, context);
/* 261 */         if (object instanceof SOAPDeserializationState) {
/* 262 */           if (builder == null) {
/* 263 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 265 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 266 */           isComplete = false;
/* 267 */         } else if (object != null) {
/* 268 */           instance.setResponseDescription((String)object);
/*     */         } 
/* 270 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 273 */       else if (matchQName(elementName, ns2_responseMessage_QNAME)) {
/* 274 */         context.setNillable(true);
/* 275 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseMessage_QNAME, reader, context);
/* 276 */         if (object instanceof SOAPDeserializationState) {
/* 277 */           if (builder == null) {
/* 278 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 280 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 281 */           isComplete = false;
/* 282 */         } else if (object != null) {
/* 283 */           instance.setResponseMessage((String)object);
/*     */         } 
/* 285 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 288 */       else if (matchQName(elementName, ns2_responseSubCode_QNAME)) {
/* 289 */         context.setNillable(true);
/* 290 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_responseSubCode_QNAME, reader, context);
/* 291 */         if (object instanceof SOAPDeserializationState) {
/* 292 */           if (builder == null) {
/* 293 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 295 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 296 */           isComplete = false;
/* 297 */         } else if (object != null) {
/* 298 */           instance.setResponseSubCode((String)object);
/*     */         } 
/* 300 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 303 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 304 */         context.setNillable(true);
/* 305 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 306 */         if (object instanceof SOAPDeserializationState) {
/* 307 */           if (builder == null) {
/* 308 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 310 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 311 */           isComplete = false;
/* 312 */         } else if (object != null) {
/* 313 */           instance.setTransactionId((String)object);
/*     */         } 
/* 315 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 318 */       else if (matchQName(elementName, ns2_adjustmentReasons_QNAME)) {
/* 319 */         context.setNillable(true);
/* 320 */         Object object = this.myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1.deserialize(ns2_adjustmentReasons_QNAME, reader, context);
/* 321 */         if (object instanceof SOAPDeserializationState) {
/* 322 */           if (builder == null) {
/* 323 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 325 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 326 */           isComplete = false;
/* 327 */         } else if (object != null) {
/* 328 */           instance.setAdjustmentReasons((AdjustmentReasonsTO[])object);
/*     */         } 
/* 330 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 333 */       else if (matchQName(elementName, ns2_alcoCosTO_QNAME)) {
/* 334 */         context.setNillable(true);
/* 335 */         Object object = this.myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer.deserialize(ns2_alcoCosTO_QNAME, reader, context);
/* 336 */         if (object instanceof SOAPDeserializationState) {
/* 337 */           if (builder == null) {
/* 338 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 340 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 341 */           isComplete = false;
/* 342 */         } else if (object != null) {
/* 343 */           instance.setAlcoCosTO((AlcoCosTO)object);
/*     */         } 
/* 345 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 348 */       else if (matchQName(elementName, ns2_balanceList_QNAME)) {
/* 349 */         context.setNillable(true);
/* 350 */         Object object = this.myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1.deserialize(ns2_balanceList_QNAME, reader, context);
/* 351 */         if (object instanceof SOAPDeserializationState) {
/* 352 */           if (builder == null) {
/* 353 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 355 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 356 */           isComplete = false;
/* 357 */         } else if (object != null) {
/* 358 */           instance.setBalanceList((BalanceListTO[])object);
/*     */         } 
/* 360 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 363 */       else if (matchQName(elementName, ns2_chargeCodes_QNAME)) {
/* 364 */         context.setNillable(true);
/* 365 */         Object object = this.myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1.deserialize(ns2_chargeCodes_QNAME, reader, context);
/* 366 */         if (object instanceof SOAPDeserializationState) {
/* 367 */           if (builder == null) {
/* 368 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 370 */           state = registerWithMemberState(instance, state, object, 10, (SOAPInstanceBuilder)builder);
/* 371 */           isComplete = false;
/* 372 */         } else if (object != null) {
/* 373 */           instance.setChargeCodes((ChargeCodeTO[])object);
/*     */         } 
/* 375 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 378 */       else if (matchQName(elementName, ns2_city_QNAME)) {
/* 379 */         context.setNillable(true);
/* 380 */         Object object = this.myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1.deserialize(ns2_city_QNAME, reader, context);
/* 381 */         if (object instanceof SOAPDeserializationState) {
/* 382 */           if (builder == null) {
/* 383 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 385 */           state = registerWithMemberState(instance, state, object, 11, (SOAPInstanceBuilder)builder);
/* 386 */           isComplete = false;
/* 387 */         } else if (object != null) {
/* 388 */           instance.setCity((CityTO[])object);
/*     */         } 
/* 390 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 393 */       else if (matchQName(elementName, ns2_communalCouncilCharges_QNAME)) {
/* 394 */         context.setNillable(true);
/* 395 */         Object object = this.myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1.deserialize(ns2_communalCouncilCharges_QNAME, reader, context);
/* 396 */         if (object instanceof SOAPDeserializationState) {
/* 397 */           if (builder == null) {
/* 398 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 400 */           state = registerWithMemberState(instance, state, object, 12, (SOAPInstanceBuilder)builder);
/* 401 */           isComplete = false;
/* 402 */         } else if (object != null) {
/* 403 */           instance.setCommunalCouncilCharges((CommunalCouncilChargeTO[])object);
/*     */         } 
/* 405 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 408 */       else if (matchQName(elementName, ns2_coolingReason_QNAME)) {
/* 409 */         context.setNillable(true);
/* 410 */         Object object = this.myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1.deserialize(ns2_coolingReason_QNAME, reader, context);
/* 411 */         if (object instanceof SOAPDeserializationState) {
/* 412 */           if (builder == null) {
/* 413 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 415 */           state = registerWithMemberState(instance, state, object, 13, (SOAPInstanceBuilder)builder);
/* 416 */           isComplete = false;
/* 417 */         } else if (object != null) {
/* 418 */           instance.setCoolingReason((CoolingReasonTO[])object);
/*     */         } 
/* 420 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 423 */       else if (matchQName(elementName, ns2_equipmentTypeTO_QNAME)) {
/* 424 */         context.setNillable(true);
/* 425 */         Object object = this.myns2_ArrayOfEquipmentTypeTO__EquipmentTypeTOArray_LiteralSerializer1.deserialize(ns2_equipmentTypeTO_QNAME, reader, context);
/* 426 */         if (object instanceof SOAPDeserializationState) {
/* 427 */           if (builder == null) {
/* 428 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 430 */           state = registerWithMemberState(instance, state, object, 14, (SOAPInstanceBuilder)builder);
/* 431 */           isComplete = false;
/* 432 */         } else if (object != null) {
/* 433 */           instance.setEquipmentTypeTO((EquipmentTypeTO[])object);
/*     */         } 
/* 435 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 438 */       else if (matchQName(elementName, ns2_feechargeType_QNAME)) {
/* 439 */         context.setNillable(true);
/* 440 */         Object object = this.myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1.deserialize(ns2_feechargeType_QNAME, reader, context);
/* 441 */         if (object instanceof SOAPDeserializationState) {
/* 442 */           if (builder == null) {
/* 443 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 445 */           state = registerWithMemberState(instance, state, object, 15, (SOAPInstanceBuilder)builder);
/* 446 */           isComplete = false;
/* 447 */         } else if (object != null) {
/* 448 */           instance.setFeechargeType((SubCategoryTO[])object);
/*     */         } 
/* 450 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 453 */       else if (matchQName(elementName, ns2_ivrPlanBenefits_QNAME)) {
/* 454 */         context.setNillable(true);
/* 455 */         Object object = this.myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1.deserialize(ns2_ivrPlanBenefits_QNAME, reader, context);
/* 456 */         if (object instanceof SOAPDeserializationState) {
/* 457 */           if (builder == null) {
/* 458 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 460 */           state = registerWithMemberState(instance, state, object, 16, (SOAPInstanceBuilder)builder);
/* 461 */           isComplete = false;
/* 462 */         } else if (object != null) {
/* 463 */           instance.setIvrPlanBenefits((IVRPlanBenefitTO[])object);
/*     */         } 
/* 465 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 468 */       else if (matchQName(elementName, ns2_ivrPlans_QNAME)) {
/* 469 */         context.setNillable(true);
/* 470 */         Object object = this.myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1.deserialize(ns2_ivrPlans_QNAME, reader, context);
/* 471 */         if (object instanceof SOAPDeserializationState) {
/* 472 */           if (builder == null) {
/* 473 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 475 */           state = registerWithMemberState(instance, state, object, 17, (SOAPInstanceBuilder)builder);
/* 476 */           isComplete = false;
/* 477 */         } else if (object != null) {
/* 478 */           instance.setIvrPlans((IVRPlanTO[])object);
/*     */         } 
/* 480 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 483 */       else if (matchQName(elementName, ns2_locality_QNAME)) {
/* 484 */         context.setNillable(true);
/* 485 */         Object object = this.myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1.deserialize(ns2_locality_QNAME, reader, context);
/* 486 */         if (object instanceof SOAPDeserializationState) {
/* 487 */           if (builder == null) {
/* 488 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 490 */           state = registerWithMemberState(instance, state, object, 18, (SOAPInstanceBuilder)builder);
/* 491 */           isComplete = false;
/* 492 */         } else if (object != null) {
/* 493 */           instance.setLocality((LocalityTO[])object);
/*     */         } 
/* 495 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 498 */       else if (matchQName(elementName, ns2_memosCategory_QNAME)) {
/* 499 */         context.setNillable(true);
/* 500 */         Object object = this.myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1.deserialize(ns2_memosCategory_QNAME, reader, context);
/* 501 */         if (object instanceof SOAPDeserializationState) {
/* 502 */           if (builder == null) {
/* 503 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 505 */           state = registerWithMemberState(instance, state, object, 19, (SOAPInstanceBuilder)builder);
/* 506 */           isComplete = false;
/* 507 */         } else if (object != null) {
/* 508 */           instance.setMemosCategory((MemosCategoryTO[])object);
/*     */         } 
/* 510 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 513 */       else if (matchQName(elementName, ns2_modelsPhones_QNAME)) {
/* 514 */         context.setNillable(true);
/* 515 */         Object object = this.myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1.deserialize(ns2_modelsPhones_QNAME, reader, context);
/* 516 */         if (object instanceof SOAPDeserializationState) {
/* 517 */           if (builder == null) {
/* 518 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 520 */           state = registerWithMemberState(instance, state, object, 20, (SOAPInstanceBuilder)builder);
/* 521 */           isComplete = false;
/* 522 */         } else if (object != null) {
/* 523 */           instance.setModelsPhones((PhoneModelTO[])object);
/*     */         } 
/* 525 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 528 */       else if (matchQName(elementName, ns2_municipalitie_QNAME)) {
/* 529 */         context.setNillable(true);
/* 530 */         Object object = this.myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1.deserialize(ns2_municipalitie_QNAME, reader, context);
/* 531 */         if (object instanceof SOAPDeserializationState) {
/* 532 */           if (builder == null) {
/* 533 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 535 */           state = registerWithMemberState(instance, state, object, 21, (SOAPInstanceBuilder)builder);
/* 536 */           isComplete = false;
/* 537 */         } else if (object != null) {
/* 538 */           instance.setMunicipalitie((MunicipalitieTO[])object);
/*     */         } 
/* 540 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 543 */       else if (matchQName(elementName, ns2_nationalities_QNAME)) {
/* 544 */         context.setNillable(true);
/* 545 */         Object object = this.myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1.deserialize(ns2_nationalities_QNAME, reader, context);
/* 546 */         if (object instanceof SOAPDeserializationState) {
/* 547 */           if (builder == null) {
/* 548 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 550 */           state = registerWithMemberState(instance, state, object, 22, (SOAPInstanceBuilder)builder);
/* 551 */           isComplete = false;
/* 552 */         } else if (object != null) {
/* 553 */           instance.setNationalities((NationalitiesTO[])object);
/*     */         } 
/* 555 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 558 */       else if (matchQName(elementName, ns2_parishe_QNAME)) {
/* 559 */         context.setNillable(true);
/* 560 */         Object object = this.myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1.deserialize(ns2_parishe_QNAME, reader, context);
/* 561 */         if (object instanceof SOAPDeserializationState) {
/* 562 */           if (builder == null) {
/* 563 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 565 */           state = registerWithMemberState(instance, state, object, 23, (SOAPInstanceBuilder)builder);
/* 566 */           isComplete = false;
/* 567 */         } else if (object != null) {
/* 568 */           instance.setParishe((ParisheTO[])object);
/*     */         } 
/* 570 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 573 */       else if (matchQName(elementName, ns2_plans_QNAME)) {
/* 574 */         context.setNillable(true);
/* 575 */         Object object = this.myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1.deserialize(ns2_plans_QNAME, reader, context);
/* 576 */         if (object instanceof SOAPDeserializationState) {
/* 577 */           if (builder == null) {
/* 578 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 580 */           state = registerWithMemberState(instance, state, object, 24, (SOAPInstanceBuilder)builder);
/* 581 */           isComplete = false;
/* 582 */         } else if (object != null) {
/* 583 */           instance.setPlans((PlanTO[])object);
/*     */         } 
/* 585 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 588 */       else if (matchQName(elementName, ns2_profession_QNAME)) {
/* 589 */         context.setNillable(true);
/* 590 */         Object object = this.myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1.deserialize(ns2_profession_QNAME, reader, context);
/* 591 */         if (object instanceof SOAPDeserializationState) {
/* 592 */           if (builder == null) {
/* 593 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 595 */           state = registerWithMemberState(instance, state, object, 25, (SOAPInstanceBuilder)builder);
/* 596 */           isComplete = false;
/* 597 */         } else if (object != null) {
/* 598 */           instance.setProfession((ProfessionTO[])object);
/*     */         } 
/* 600 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 603 */       else if (matchQName(elementName, ns2_promotions_QNAME)) {
/* 604 */         context.setNillable(true);
/* 605 */         Object object = this.myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1.deserialize(ns2_promotions_QNAME, reader, context);
/* 606 */         if (object instanceof SOAPDeserializationState) {
/* 607 */           if (builder == null) {
/* 608 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 610 */           state = registerWithMemberState(instance, state, object, 26, (SOAPInstanceBuilder)builder);
/* 611 */           isComplete = false;
/* 612 */         } else if (object != null) {
/* 613 */           instance.setPromotions((PromotionTO[])object);
/*     */         } 
/* 615 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 618 */       else if (matchQName(elementName, ns2_promotionsMig_QNAME)) {
/* 619 */         context.setNillable(true);
/* 620 */         Object object = this.myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1.deserialize(ns2_promotionsMig_QNAME, reader, context);
/* 621 */         if (object instanceof SOAPDeserializationState) {
/* 622 */           if (builder == null) {
/* 623 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 625 */           state = registerWithMemberState(instance, state, object, 27, (SOAPInstanceBuilder)builder);
/* 626 */           isComplete = false;
/* 627 */         } else if (object != null) {
/* 628 */           instance.setPromotionsMig((PromotionTO[])object);
/*     */         } 
/* 630 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 633 */       else if (matchQName(elementName, ns2_sector_QNAME)) {
/* 634 */         context.setNillable(true);
/* 635 */         Object object = this.myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1.deserialize(ns2_sector_QNAME, reader, context);
/* 636 */         if (object instanceof SOAPDeserializationState) {
/* 637 */           if (builder == null) {
/* 638 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 640 */           state = registerWithMemberState(instance, state, object, 28, (SOAPInstanceBuilder)builder);
/* 641 */           isComplete = false;
/* 642 */         } else if (object != null) {
/* 643 */           instance.setSector((SectorTO[])object);
/*     */         } 
/* 645 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 648 */       else if (matchQName(elementName, ns2_sellingAgent_QNAME)) {
/* 649 */         context.setNillable(true);
/* 650 */         Object object = this.myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1.deserialize(ns2_sellingAgent_QNAME, reader, context);
/* 651 */         if (object instanceof SOAPDeserializationState) {
/* 652 */           if (builder == null) {
/* 653 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 655 */           state = registerWithMemberState(instance, state, object, 29, (SOAPInstanceBuilder)builder);
/* 656 */           isComplete = false;
/* 657 */         } else if (object != null) {
/* 658 */           instance.setSellingAgent((SellingAgentTO[])object);
/*     */         } 
/* 660 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 663 */       else if (matchQName(elementName, ns2_services_QNAME)) {
/* 664 */         context.setNillable(true);
/* 665 */         Object object = this.myns2_ArrayOfServiceTO_v3__ServiceTO_v3Array_LiteralSerializer1.deserialize(ns2_services_QNAME, reader, context);
/* 666 */         if (object instanceof SOAPDeserializationState) {
/* 667 */           if (builder == null) {
/* 668 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 670 */           state = registerWithMemberState(instance, state, object, 30, (SOAPInstanceBuilder)builder);
/* 671 */           isComplete = false;
/* 672 */         } else if (object != null) {
/* 673 */           instance.setServices((ServiceTO_v3[])object);
/*     */         } 
/* 675 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 678 */       else if (matchQName(elementName, ns2_state_QNAME)) {
/* 679 */         context.setNillable(true);
/* 680 */         Object object = this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.deserialize(ns2_state_QNAME, reader, context);
/* 681 */         if (object instanceof SOAPDeserializationState) {
/* 682 */           if (builder == null) {
/* 683 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 685 */           state = registerWithMemberState(instance, state, object, 31, (SOAPInstanceBuilder)builder);
/* 686 */           isComplete = false;
/* 687 */         } else if (object != null) {
/* 688 */           instance.setState((StateTO[])object);
/*     */         } 
/* 690 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 693 */       else if (matchQName(elementName, ns2_structuredCities_QNAME)) {
/* 694 */         context.setNillable(true);
/* 695 */         Object object = this.myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1.deserialize(ns2_structuredCities_QNAME, reader, context);
/* 696 */         if (object instanceof SOAPDeserializationState) {
/* 697 */           if (builder == null) {
/* 698 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 700 */           state = registerWithMemberState(instance, state, object, 32, (SOAPInstanceBuilder)builder);
/* 701 */           isComplete = false;
/* 702 */         } else if (object != null) {
/* 703 */           instance.setStructuredCities((CityStructuredTO[])object);
/*     */         } 
/* 705 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 708 */       else if (matchQName(elementName, ns2_structuredStates_QNAME)) {
/* 709 */         context.setNillable(true);
/* 710 */         Object object = this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.deserialize(ns2_structuredStates_QNAME, reader, context);
/* 711 */         if (object instanceof SOAPDeserializationState) {
/* 712 */           if (builder == null) {
/* 713 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 715 */           state = registerWithMemberState(instance, state, object, 33, (SOAPInstanceBuilder)builder);
/* 716 */           isComplete = false;
/* 717 */         } else if (object != null) {
/* 718 */           instance.setStructuredStates((StateTO[])object);
/*     */         } 
/* 720 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 723 */       else if (matchQName(elementName, ns2_structuredZones_QNAME)) {
/* 724 */         context.setNillable(true);
/* 725 */         Object object = this.myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1.deserialize(ns2_structuredZones_QNAME, reader, context);
/* 726 */         if (object instanceof SOAPDeserializationState) {
/* 727 */           if (builder == null) {
/* 728 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 730 */           state = registerWithMemberState(instance, state, object, 34, (SOAPInstanceBuilder)builder);
/* 731 */           isComplete = false;
/* 732 */         } else if (object != null) {
/* 733 */           instance.setStructuredZones((ZoneStructuredTO[])object);
/*     */         } 
/* 735 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 738 */       else if (matchQName(elementName, ns2_subCategory_QNAME)) {
/* 739 */         context.setNillable(true);
/* 740 */         Object object = this.myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1.deserialize(ns2_subCategory_QNAME, reader, context);
/* 741 */         if (object instanceof SOAPDeserializationState) {
/* 742 */           if (builder == null) {
/* 743 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 745 */           state = registerWithMemberState(instance, state, object, 35, (SOAPInstanceBuilder)builder);
/* 746 */           isComplete = false;
/* 747 */         } else if (object != null) {
/* 748 */           instance.setSubCategory((SubCategoryTO[])object);
/*     */         } 
/* 750 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 753 */       else if (matchQName(elementName, ns2_textPlans_QNAME)) {
/* 754 */         context.setNillable(true);
/* 755 */         Object object = this.myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1.deserialize(ns2_textPlans_QNAME, reader, context);
/* 756 */         if (object instanceof SOAPDeserializationState) {
/* 757 */           if (builder == null) {
/* 758 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 760 */           state = registerWithMemberState(instance, state, object, 36, (SOAPInstanceBuilder)builder);
/* 761 */           isComplete = false;
/* 762 */         } else if (object != null) {
/* 763 */           instance.setTextPlans((TextPlanTO[])object);
/*     */         } 
/* 765 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 768 */       else if (matchQName(elementName, ns2_urbanization_QNAME)) {
/* 769 */         context.setNillable(true);
/* 770 */         Object object = this.myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1.deserialize(ns2_urbanization_QNAME, reader, context);
/* 771 */         if (object instanceof SOAPDeserializationState) {
/* 772 */           if (builder == null) {
/* 773 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 775 */           state = registerWithMemberState(instance, state, object, 37, (SOAPInstanceBuilder)builder);
/* 776 */           isComplete = false;
/* 777 */         } else if (object != null) {
/* 778 */           instance.setUrbanization((UrbanizationTO[])object);
/*     */         } 
/* 780 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 783 */       else if (matchQName(elementName, ns2_zone_QNAME)) {
/* 784 */         context.setNillable(true);
/* 785 */         Object object = this.myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1.deserialize(ns2_zone_QNAME, reader, context);
/* 786 */         if (object instanceof SOAPDeserializationState) {
/* 787 */           if (builder == null) {
/* 788 */             builder = new MasterDataResponseTO_v2_SOAPBuilder();
/*     */           }
/* 790 */           state = registerWithMemberState(instance, state, object, 38, (SOAPInstanceBuilder)builder);
/* 791 */           isComplete = false;
/* 792 */         } else if (object != null) {
/* 793 */           instance.setZone((ZoneTO[])object);
/*     */         } 
/* 795 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 798 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_zone_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 803 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 804 */     } catch (XMLReaderException xmle) {
/* 805 */       if (startName != null) {
/* 806 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 808 */       throw xmle;
/*     */     } 
/*     */     
/* 811 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 815 */     MasterDataResponseTO_v2 instance = (MasterDataResponseTO_v2)obj;
/*     */     
/* 817 */     context.setNillable(true);
/* 818 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getExecutionTime()), ns2_executionTime_QNAME, null, writer, context);
/* 819 */     context.setNillable(true);
/* 820 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getOrigin(), ns2_origin_QNAME, null, writer, context);
/* 821 */     context.setNillable(true);
/* 822 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseCode(), ns2_responseCode_QNAME, null, writer, context);
/* 823 */     context.setNillable(true);
/* 824 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseDescription(), ns2_responseDescription_QNAME, null, writer, context);
/* 825 */     context.setNillable(true);
/* 826 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseMessage(), ns2_responseMessage_QNAME, null, writer, context);
/* 827 */     context.setNillable(true);
/* 828 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getResponseSubCode(), ns2_responseSubCode_QNAME, null, writer, context);
/* 829 */     context.setNillable(true);
/* 830 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 831 */     context.setNillable(true);
/* 832 */     this.myns2_ArrayOfAdjustmentReasonsTO__AdjustmentReasonsTOArray_LiteralSerializer1.serialize(instance.getAdjustmentReasons(), ns2_adjustmentReasons_QNAME, null, writer, context);
/* 833 */     context.setNillable(true);
/* 834 */     this.myns2_AlcoCosTO__AlcoCosTO_SOAPSerializer.serialize(instance.getAlcoCosTO(), ns2_alcoCosTO_QNAME, null, writer, context);
/* 835 */     context.setNillable(true);
/* 836 */     this.myns2_ArrayOfBalanceListTO__BalanceListTOArray_LiteralSerializer1.serialize(instance.getBalanceList(), ns2_balanceList_QNAME, null, writer, context);
/* 837 */     context.setNillable(true);
/* 838 */     this.myns2_ArrayOfChargeCodeTO__ChargeCodeTOArray_LiteralSerializer1.serialize(instance.getChargeCodes(), ns2_chargeCodes_QNAME, null, writer, context);
/* 839 */     context.setNillable(true);
/* 840 */     this.myns2_ArrayOfCityTO__CityTOArray_LiteralSerializer1.serialize(instance.getCity(), ns2_city_QNAME, null, writer, context);
/* 841 */     context.setNillable(true);
/* 842 */     this.myns2_ArrayOfCommunalCouncilChargeTO__CommunalCouncilChargeTOArray_LiteralSerializer1.serialize(instance.getCommunalCouncilCharges(), ns2_communalCouncilCharges_QNAME, null, writer, context);
/* 843 */     context.setNillable(true);
/* 844 */     this.myns2_ArrayOfCoolingReasonTO__CoolingReasonTOArray_LiteralSerializer1.serialize(instance.getCoolingReason(), ns2_coolingReason_QNAME, null, writer, context);
/* 845 */     context.setNillable(true);
/* 846 */     this.myns2_ArrayOfEquipmentTypeTO__EquipmentTypeTOArray_LiteralSerializer1.serialize(instance.getEquipmentTypeTO(), ns2_equipmentTypeTO_QNAME, null, writer, context);
/* 847 */     context.setNillable(true);
/* 848 */     this.myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1.serialize(instance.getFeechargeType(), ns2_feechargeType_QNAME, null, writer, context);
/* 849 */     context.setNillable(true);
/* 850 */     this.myns2_ArrayOfIVRPlanBenefitTO__IVRPlanBenefitTOArray_LiteralSerializer1.serialize(instance.getIvrPlanBenefits(), ns2_ivrPlanBenefits_QNAME, null, writer, context);
/* 851 */     context.setNillable(true);
/* 852 */     this.myns2_ArrayOfIVRPlanTO__IVRPlanTOArray_LiteralSerializer1.serialize(instance.getIvrPlans(), ns2_ivrPlans_QNAME, null, writer, context);
/* 853 */     context.setNillable(true);
/* 854 */     this.myns2_ArrayOfLocalityTO__LocalityTOArray_LiteralSerializer1.serialize(instance.getLocality(), ns2_locality_QNAME, null, writer, context);
/* 855 */     context.setNillable(true);
/* 856 */     this.myns2_ArrayOfMemosCategoryTO__MemosCategoryTOArray_LiteralSerializer1.serialize(instance.getMemosCategory(), ns2_memosCategory_QNAME, null, writer, context);
/* 857 */     context.setNillable(true);
/* 858 */     this.myns2_ArrayOfPhoneModelTO__PhoneModelTOArray_LiteralSerializer1.serialize(instance.getModelsPhones(), ns2_modelsPhones_QNAME, null, writer, context);
/* 859 */     context.setNillable(true);
/* 860 */     this.myns2_ArrayOfMunicipalitieTO__MunicipalitieTOArray_LiteralSerializer1.serialize(instance.getMunicipalitie(), ns2_municipalitie_QNAME, null, writer, context);
/* 861 */     context.setNillable(true);
/* 862 */     this.myns2_ArrayOfNationalitiesTO__NationalitiesTOArray_LiteralSerializer1.serialize(instance.getNationalities(), ns2_nationalities_QNAME, null, writer, context);
/* 863 */     context.setNillable(true);
/* 864 */     this.myns2_ArrayOfParisheTO__ParisheTOArray_LiteralSerializer1.serialize(instance.getParishe(), ns2_parishe_QNAME, null, writer, context);
/* 865 */     context.setNillable(true);
/* 866 */     this.myns2_ArrayOfPlanTO__PlanTOArray_LiteralSerializer1.serialize(instance.getPlans(), ns2_plans_QNAME, null, writer, context);
/* 867 */     context.setNillable(true);
/* 868 */     this.myns2_ArrayOfProfessionTO__ProfessionTOArray_LiteralSerializer1.serialize(instance.getProfession(), ns2_profession_QNAME, null, writer, context);
/* 869 */     context.setNillable(true);
/* 870 */     this.myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1.serialize(instance.getPromotions(), ns2_promotions_QNAME, null, writer, context);
/* 871 */     context.setNillable(true);
/* 872 */     this.myns2_ArrayOfPromotionTO__PromotionTOArray_LiteralSerializer1.serialize(instance.getPromotionsMig(), ns2_promotionsMig_QNAME, null, writer, context);
/* 873 */     context.setNillable(true);
/* 874 */     this.myns2_ArrayOfSectorTO__SectorTOArray_LiteralSerializer1.serialize(instance.getSector(), ns2_sector_QNAME, null, writer, context);
/* 875 */     context.setNillable(true);
/* 876 */     this.myns2_ArrayOfSellingAgentTO__SellingAgentTOArray_LiteralSerializer1.serialize(instance.getSellingAgent(), ns2_sellingAgent_QNAME, null, writer, context);
/* 877 */     context.setNillable(true);
/* 878 */     this.myns2_ArrayOfServiceTO_v3__ServiceTO_v3Array_LiteralSerializer1.serialize(instance.getServices(), ns2_services_QNAME, null, writer, context);
/* 879 */     context.setNillable(true);
/* 880 */     this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.serialize(instance.getState(), ns2_state_QNAME, null, writer, context);
/* 881 */     context.setNillable(true);
/* 882 */     this.myns2_ArrayOfCityStructuredTO__CityStructuredTOArray_LiteralSerializer1.serialize(instance.getStructuredCities(), ns2_structuredCities_QNAME, null, writer, context);
/* 883 */     context.setNillable(true);
/* 884 */     this.myns2_ArrayOfStateTO__StateTOArray_LiteralSerializer1.serialize(instance.getStructuredStates(), ns2_structuredStates_QNAME, null, writer, context);
/* 885 */     context.setNillable(true);
/* 886 */     this.myns2_ArrayOfZoneStructuredTO__ZoneStructuredTOArray_LiteralSerializer1.serialize(instance.getStructuredZones(), ns2_structuredZones_QNAME, null, writer, context);
/* 887 */     context.setNillable(true);
/* 888 */     this.myns2_ArrayOfSubCategoryTO__SubCategoryTOArray_LiteralSerializer1.serialize(instance.getSubCategory(), ns2_subCategory_QNAME, null, writer, context);
/* 889 */     context.setNillable(true);
/* 890 */     this.myns2_ArrayOfTextPlanTO__TextPlanTOArray_LiteralSerializer1.serialize(instance.getTextPlans(), ns2_textPlans_QNAME, null, writer, context);
/* 891 */     context.setNillable(true);
/* 892 */     this.myns2_ArrayOfUrbanizationTO__UrbanizationTOArray_LiteralSerializer1.serialize(instance.getUrbanization(), ns2_urbanization_QNAME, null, writer, context);
/* 893 */     context.setNillable(true);
/* 894 */     this.myns2_ArrayOfZoneTO__ZoneTOArray_LiteralSerializer1.serialize(instance.getZone(), ns2_zone_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\wsprepaybasebrplanoffer\MasterDataResponseTO_v2_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */