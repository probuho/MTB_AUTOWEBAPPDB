/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.wsprepaybasebrplanoffer;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*    */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*    */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*    */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*    */ import ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS;
/*    */ import ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPBuilder;
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*    */   static Class class$(String paramString) { 
/* 18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/* 19 */      } private static final QName ns1_result_QNAME = new QName("", "result");
/* 20 */   private static final QName ns2_BooleanResponseTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "BooleanResponseTO"); private CombinedSerializer myns2_BooleanResponseTO__BooleanResponseTO_SOAPSerializer;
/*    */   private static final int myresult_INDEX = 0;
/*    */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO;
/*    */   
/*    */   public WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/* 25 */     super(type, encodeType, isNullable, soapVersion);
/*    */   }
/*    */   
/*    */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 29 */     if (class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO == null); ((WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer)registry).myns2_BooleanResponseTO__BooleanResponseTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO, class$ve$com$movilnet$gdis$cia$ws$to$responses$BooleanResponseTO = class$("ve.com.movilnet.gdis.cia.ws.to.responses.BooleanResponseTO"), ns2_BooleanResponseTO_TYPE_QNAME);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/* 34 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS instance = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS();
/* 35 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPBuilder builder = null;
/*    */     
/* 37 */     boolean isComplete = true;
/*    */ 
/*    */     
/* 40 */     reader.nextElementContent();
/* 41 */     QName startName = reader.getName();
/* 42 */     if (reader.getState() == 1) {
/* 43 */       context.setNillable(true);
/* 44 */       Object member = this.myns2_BooleanResponseTO__BooleanResponseTO_SOAPSerializer.deserialize(null, reader, context);
/* 45 */       if (member instanceof SOAPDeserializationState) {
/* 46 */         if (builder == null) {
/* 47 */           builder = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPBuilder();
/*    */         }
/* 49 */         state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/* 50 */         isComplete = false;
/* 51 */       } else if (member != null) {
/* 52 */         instance.setResult((BooleanResponseTO)member);
/*    */       } 
/* 54 */       reader.nextElementContent();
/*    */     } 
/* 56 */     QName elementName = reader.getName();
/*    */     
/*    */     try {
/* 59 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 60 */     } catch (XMLReaderException xmle) {
/* 61 */       if (startName != null) {
/* 62 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*    */       }
/* 64 */       throw xmle;
/*    */     } 
/*    */     
/* 67 */     return isComplete ? instance : state;
/*    */   }
/*    */   
/*    */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 71 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS instance = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS)obj;
/*    */     
/* 73 */     context.setNillable(true);
/* 74 */     this.myns2_BooleanResponseTO__BooleanResponseTO_SOAPSerializer.serialize(instance.getResult(), ns1_result_QNAME, null, writer, context);
/*    */   }
/*    */   
/*    */   protected void verifyName(XMLReader reader, QName expectedName) throws Exception {}
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\wsprepaybasebrplanoffer\WSPrepayBaseBrPlanOfferSoapHttp_validatePlanConsejoComunal_RespS_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */