/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalityTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String description;
/*    */   protected String localidadCode;
/*    */   
/*    */   public String getDescription() {
/* 18 */     return this.description;
/*    */   }
/*    */   
/*    */   public void setDescription(String description) {
/* 22 */     this.description = description;
/*    */   }
/*    */   
/*    */   public String getLocalidadCode() {
/* 26 */     return this.localidadCode;
/*    */   }
/*    */   
/*    */   public void setLocalidadCode(String localidadCode) {
/* 30 */     this.localidadCode = localidadCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\LocalityTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */