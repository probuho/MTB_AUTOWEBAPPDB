/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProfessionTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String professionName;
/*    */   
/*    */   public String getProfessionName() {
/* 17 */     return this.professionName;
/*    */   }
/*    */   
/*    */   public void setProfessionName(String professionName) {
/* 21 */     this.professionName = professionName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\ProfessionTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */