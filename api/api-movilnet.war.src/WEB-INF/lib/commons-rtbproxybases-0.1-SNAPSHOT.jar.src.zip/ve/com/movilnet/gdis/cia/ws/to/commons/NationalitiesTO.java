/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NationalitiesTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String countryName;
/*    */   
/*    */   public String getCountryName() {
/* 17 */     return this.countryName;
/*    */   }
/*    */   
/*    */   public void setCountryName(String countryName) {
/* 21 */     this.countryName = countryName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\NationalitiesTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */