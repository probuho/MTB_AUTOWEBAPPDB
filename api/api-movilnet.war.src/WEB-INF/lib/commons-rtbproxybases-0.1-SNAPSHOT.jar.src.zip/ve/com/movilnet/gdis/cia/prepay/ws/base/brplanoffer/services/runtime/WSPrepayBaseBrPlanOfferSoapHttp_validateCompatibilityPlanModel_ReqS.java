/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanModelRequestTO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS
/*    */   implements Serializable
/*    */ {
/*    */   protected ValidatePlanModelRequestTO planModelRequest;
/*    */   
/*    */   public ValidatePlanModelRequestTO getPlanModelRequest() {
/* 17 */     return this.planModelRequest;
/*    */   }
/*    */   
/*    */   public void setPlanModelRequest(ValidatePlanModelRequestTO planModelRequest) {
/* 21 */     this.planModelRequest = planModelRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\WSPrepayBaseBrPlanOfferSoapHttp_validateCompatibilityPlanModel_ReqS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */