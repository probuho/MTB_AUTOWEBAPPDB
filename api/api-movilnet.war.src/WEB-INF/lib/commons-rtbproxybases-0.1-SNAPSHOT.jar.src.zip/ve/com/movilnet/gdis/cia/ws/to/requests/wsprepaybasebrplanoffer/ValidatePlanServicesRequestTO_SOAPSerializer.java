/*     */ package ve.com.movilnet.gdis.cia.ws.to.requests.wsprepaybasebrplanoffer;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanServicesRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.runtime.ValidatePlanServicesRequestTO_SOAPBuilder;
/*     */ 
/*     */ public class ValidatePlanServicesRequestTO_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*     */   static Class class$(String paramString) { 
/*  18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*  19 */      } private static final QName ns2_applicationClient_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "applicationClient");
/*  20 */   private static final QName ns2_ApplicationClientTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ApplicationClientTO");
/*     */   private CombinedSerializer myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer;
/*  22 */   private static final QName ns2_security_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "security");
/*  23 */   private static final QName ns2_SecurityTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "SecurityTO");
/*     */   private CombinedSerializer myns2_SecurityTO__SecurityTO_SOAPSerializer;
/*  25 */   private static final QName ns2_serviceProvider_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "serviceProvider");
/*  26 */   private static final QName ns3_string_TYPE_QNAME = SchemaConstants.QNAME_TYPE_STRING;
/*     */   private CombinedSerializer myns3_string__java_lang_String_String_Serializer;
/*  28 */   private static final QName ns2_technology_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "technology");
/*  29 */   private static final QName ns3_short_TYPE_QNAME = SchemaConstants.QNAME_TYPE_SHORT;
/*     */   private CombinedSerializer myns3__short__short_Short_Serializer;
/*  31 */   private static final QName ns2_transactionId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionId");
/*  32 */   private static final QName ns2_alcsList_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "alcsList");
/*  33 */   private static final QName ns2_ArrayOfstring_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ArrayOfstring");
/*     */   private CombinedSerializer myns2_ArrayOfstring__String_Array_LiteralSerializer1;
/*  35 */   private static final QName ns2_cosName_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "cosName");
/*  36 */   private static final QName ns2_planCode_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "planCode");
/*  37 */   private static final QName ns2_subscriberId_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "subscriberId");
/*  38 */   private static final QName ns3_long_TYPE_QNAME = SchemaConstants.QNAME_TYPE_LONG;
/*     */   private CombinedSerializer myns3__long__long_Long_Serializer;
/*  40 */   private static final QName ns2_transactionType_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "transactionType"); private static final int myapplicationClient_INDEX = 0; private static final int mysecurity_INDEX = 1; private static final int myserviceProvider_INDEX = 2; private static final int mytechnology_INDEX = 3;
/*     */   private static final int mytransactionId_INDEX = 4;
/*     */   private static final int myalcsList_INDEX = 5;
/*     */   private static final int mycosName_INDEX = 6;
/*     */   private static final int myplanCode_INDEX = 7;
/*     */   private static final int mysubscriberId_INDEX = 8;
/*     */   private static final int mytransactionType_INDEX = 9;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO;
/*     */   private static Class class$java$lang$String;
/*     */   private static Class array$Ljava$lang$String;
/*     */   
/*     */   public ValidatePlanServicesRequestTO_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/*  53 */     super(type, encodeType, isNullable, soapVersion);
/*     */   }
/*     */   
/*     */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/*  57 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO == null); ((ValidatePlanServicesRequestTO_SOAPSerializer)registry).myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$ApplicationClientTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.ApplicationClientTO"), ns2_ApplicationClientTO_TYPE_QNAME);
/*  58 */     if (class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO == null); ((ValidatePlanServicesRequestTO_SOAPSerializer)registry).myns2_SecurityTO__SecurityTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO, class$ve$com$movilnet$gdis$cia$ws$to$commons$SecurityTO = class$("ve.com.movilnet.gdis.cia.ws.to.commons.SecurityTO"), ns2_SecurityTO_TYPE_QNAME);
/*  59 */     if (class$java$lang$String == null); ((ValidatePlanServicesRequestTO_SOAPSerializer)registry).myns3_string__java_lang_String_String_Serializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$java$lang$String, class$java$lang$String = class$("java.lang.String"), ns3_string_TYPE_QNAME);
/*  60 */     this.myns3__short__short_Short_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), short.class, ns3_short_TYPE_QNAME);
/*  61 */     if (array$Ljava$lang$String == null); ((ValidatePlanServicesRequestTO_SOAPSerializer)registry).myns2_ArrayOfstring__String_Array_LiteralSerializer1 = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)array$Ljava$lang$String, array$Ljava$lang$String = class$("[Ljava.lang.String;"), ns2_ArrayOfstring_TYPE_QNAME);
/*  62 */     this.myns3__long__long_Long_Serializer = (CombinedSerializer)registry.getSerializer(SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding(), long.class, ns3_long_TYPE_QNAME);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/*  67 */     ValidatePlanServicesRequestTO instance = new ValidatePlanServicesRequestTO();
/*  68 */     ValidatePlanServicesRequestTO_SOAPBuilder builder = null;
/*     */     
/*  70 */     boolean isComplete = true;
/*     */ 
/*     */     
/*  73 */     reader.nextElementContent();
/*  74 */     QName startName = reader.getName();
/*  75 */     for (int i = 0; i < 10; i++) {
/*  76 */       QName elementName = reader.getName();
/*  77 */       if (reader.getState() == 2) {
/*     */         break;
/*     */       }
/*  80 */       if (matchQName(elementName, ns2_applicationClient_QNAME)) {
/*  81 */         context.setNillable(true);
/*  82 */         Object member = this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.deserialize(ns2_applicationClient_QNAME, reader, context);
/*  83 */         if (member instanceof SOAPDeserializationState) {
/*  84 */           if (builder == null) {
/*  85 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/*  87 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/*  88 */           isComplete = false;
/*  89 */         } else if (member != null) {
/*  90 */           instance.setApplicationClient((ApplicationClientTO)member);
/*     */         } 
/*  92 */         reader.nextElementContent();
/*     */       
/*     */       }
/*  95 */       else if (matchQName(elementName, ns2_security_QNAME)) {
/*  96 */         context.setNillable(true);
/*  97 */         Object object = this.myns2_SecurityTO__SecurityTO_SOAPSerializer.deserialize(ns2_security_QNAME, reader, context);
/*  98 */         if (object instanceof SOAPDeserializationState) {
/*  99 */           if (builder == null) {
/* 100 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 102 */           state = registerWithMemberState(instance, state, object, 1, (SOAPInstanceBuilder)builder);
/* 103 */           isComplete = false;
/* 104 */         } else if (object != null) {
/* 105 */           instance.setSecurity((SecurityTO)object);
/*     */         } 
/* 107 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 110 */       else if (matchQName(elementName, ns2_serviceProvider_QNAME)) {
/* 111 */         context.setNillable(true);
/* 112 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_serviceProvider_QNAME, reader, context);
/* 113 */         if (object instanceof SOAPDeserializationState) {
/* 114 */           if (builder == null) {
/* 115 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 117 */           state = registerWithMemberState(instance, state, object, 2, (SOAPInstanceBuilder)builder);
/* 118 */           isComplete = false;
/* 119 */         } else if (object != null) {
/* 120 */           instance.setServiceProvider((String)object);
/*     */         } 
/* 122 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 125 */       else if (matchQName(elementName, ns2_technology_QNAME)) {
/* 126 */         context.setNillable(true);
/* 127 */         Object object = this.myns3__short__short_Short_Serializer.deserialize(ns2_technology_QNAME, reader, context);
/* 128 */         if (object instanceof SOAPDeserializationState) {
/* 129 */           if (builder == null) {
/* 130 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 132 */           state = registerWithMemberState(instance, state, object, 3, (SOAPInstanceBuilder)builder);
/* 133 */           isComplete = false;
/* 134 */         } else if (object != null) {
/* 135 */           instance.setTechnology(((Short)object).shortValue());
/*     */         } 
/* 137 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 140 */       else if (matchQName(elementName, ns2_transactionId_QNAME)) {
/* 141 */         context.setNillable(true);
/* 142 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionId_QNAME, reader, context);
/* 143 */         if (object instanceof SOAPDeserializationState) {
/* 144 */           if (builder == null) {
/* 145 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 147 */           state = registerWithMemberState(instance, state, object, 4, (SOAPInstanceBuilder)builder);
/* 148 */           isComplete = false;
/* 149 */         } else if (object != null) {
/* 150 */           instance.setTransactionId((String)object);
/*     */         } 
/* 152 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 155 */       else if (matchQName(elementName, ns2_alcsList_QNAME)) {
/* 156 */         context.setNillable(true);
/* 157 */         Object object = this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.deserialize(ns2_alcsList_QNAME, reader, context);
/* 158 */         if (object instanceof SOAPDeserializationState) {
/* 159 */           if (builder == null) {
/* 160 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 162 */           state = registerWithMemberState(instance, state, object, 5, (SOAPInstanceBuilder)builder);
/* 163 */           isComplete = false;
/* 164 */         } else if (object != null) {
/* 165 */           instance.setAlcsList((String[])object);
/*     */         } 
/* 167 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 170 */       else if (matchQName(elementName, ns2_cosName_QNAME)) {
/* 171 */         context.setNillable(true);
/* 172 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_cosName_QNAME, reader, context);
/* 173 */         if (object instanceof SOAPDeserializationState) {
/* 174 */           if (builder == null) {
/* 175 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 177 */           state = registerWithMemberState(instance, state, object, 6, (SOAPInstanceBuilder)builder);
/* 178 */           isComplete = false;
/* 179 */         } else if (object != null) {
/* 180 */           instance.setCosName((String)object);
/*     */         } 
/* 182 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 185 */       else if (matchQName(elementName, ns2_planCode_QNAME)) {
/* 186 */         context.setNillable(true);
/* 187 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_planCode_QNAME, reader, context);
/* 188 */         if (object instanceof SOAPDeserializationState) {
/* 189 */           if (builder == null) {
/* 190 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 192 */           state = registerWithMemberState(instance, state, object, 7, (SOAPInstanceBuilder)builder);
/* 193 */           isComplete = false;
/* 194 */         } else if (object != null) {
/* 195 */           instance.setPlanCode((String)object);
/*     */         } 
/* 197 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 200 */       else if (matchQName(elementName, ns2_subscriberId_QNAME)) {
/* 201 */         context.setNillable(true);
/* 202 */         Object object = this.myns3__long__long_Long_Serializer.deserialize(ns2_subscriberId_QNAME, reader, context);
/* 203 */         if (object instanceof SOAPDeserializationState) {
/* 204 */           if (builder == null) {
/* 205 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 207 */           state = registerWithMemberState(instance, state, object, 8, (SOAPInstanceBuilder)builder);
/* 208 */           isComplete = false;
/* 209 */         } else if (object != null) {
/* 210 */           instance.setSubscriberId(((Long)object).longValue());
/*     */         } 
/* 212 */         reader.nextElementContent();
/*     */       
/*     */       }
/* 215 */       else if (matchQName(elementName, ns2_transactionType_QNAME)) {
/* 216 */         context.setNillable(true);
/* 217 */         Object object = this.myns3_string__java_lang_String_String_Serializer.deserialize(ns2_transactionType_QNAME, reader, context);
/* 218 */         if (object instanceof SOAPDeserializationState) {
/* 219 */           if (builder == null) {
/* 220 */             builder = new ValidatePlanServicesRequestTO_SOAPBuilder();
/*     */           }
/* 222 */           state = registerWithMemberState(instance, state, object, 9, (SOAPInstanceBuilder)builder);
/* 223 */           isComplete = false;
/* 224 */         } else if (object != null) {
/* 225 */           instance.setTransactionType((String)object);
/*     */         } 
/* 227 */         reader.nextElementContent();
/*     */       } else {
/*     */         
/* 230 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns2_transactionType_QNAME, elementName }, 1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 235 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 236 */     } catch (XMLReaderException xmle) {
/* 237 */       if (startName != null) {
/* 238 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*     */       }
/* 240 */       throw xmle;
/*     */     } 
/*     */     
/* 243 */     return isComplete ? instance : state;
/*     */   }
/*     */   
/*     */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 247 */     ValidatePlanServicesRequestTO instance = (ValidatePlanServicesRequestTO)obj;
/*     */     
/* 249 */     context.setNillable(true);
/* 250 */     this.myns2_ApplicationClientTO__ApplicationClientTO_SOAPSerializer.serialize(instance.getApplicationClient(), ns2_applicationClient_QNAME, null, writer, context);
/* 251 */     context.setNillable(true);
/* 252 */     this.myns2_SecurityTO__SecurityTO_SOAPSerializer.serialize(instance.getSecurity(), ns2_security_QNAME, null, writer, context);
/* 253 */     context.setNillable(true);
/* 254 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getServiceProvider(), ns2_serviceProvider_QNAME, null, writer, context);
/* 255 */     context.setNillable(true);
/* 256 */     this.myns3__short__short_Short_Serializer.serialize(new Short(instance.getTechnology()), ns2_technology_QNAME, null, writer, context);
/* 257 */     context.setNillable(true);
/* 258 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionId(), ns2_transactionId_QNAME, null, writer, context);
/* 259 */     context.setNillable(true);
/* 260 */     this.myns2_ArrayOfstring__String_Array_LiteralSerializer1.serialize(instance.getAlcsList(), ns2_alcsList_QNAME, null, writer, context);
/* 261 */     context.setNillable(true);
/* 262 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getCosName(), ns2_cosName_QNAME, null, writer, context);
/* 263 */     context.setNillable(true);
/* 264 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getPlanCode(), ns2_planCode_QNAME, null, writer, context);
/* 265 */     context.setNillable(true);
/* 266 */     this.myns3__long__long_Long_Serializer.serialize(new Long(instance.getSubscriberId()), ns2_subscriberId_QNAME, null, writer, context);
/* 267 */     context.setNillable(true);
/* 268 */     this.myns3_string__java_lang_String_String_Serializer.serialize(instance.getTransactionType(), ns2_transactionType_QNAME, null, writer, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\requests\wsprepaybasebrplanoffer\ValidatePlanServicesRequestTO_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */