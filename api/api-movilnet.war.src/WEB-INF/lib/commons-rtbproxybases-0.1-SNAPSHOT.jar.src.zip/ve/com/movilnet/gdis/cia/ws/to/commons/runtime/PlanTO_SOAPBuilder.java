/*     */ package ve.com.movilnet.gdis.cia.ws.to.commons.runtime;
/*     */ 
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPInstanceBuilder;
/*     */ import oracle.j2ee.ws.common.util.exception.LocalizableExceptionAdapter;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlanTO_SOAPBuilder
/*     */   implements SOAPInstanceBuilder
/*     */ {
/*     */   private PlanTO _instance;
/*     */   private String descPlan;
/*     */   private String planCode;
/*     */   private String planSuffix;
/*     */   private String planType;
/*     */   private String unitType;
/*     */   private static final int mydescPlan_INDEX = 0;
/*     */   private static final int myplanCode_INDEX = 1;
/*     */   private static final int myplanSuffix_INDEX = 2;
/*     */   private static final int myplanType_INDEX = 3;
/*     */   private static final int myunitType_INDEX = 4;
/*     */   
/*     */   public void setDescPlan(String descPlan) {
/*  29 */     this.descPlan = descPlan;
/*     */   }
/*     */   
/*     */   public void setPlanCode(String planCode) {
/*  33 */     this.planCode = planCode;
/*     */   }
/*     */   
/*     */   public void setPlanSuffix(String planSuffix) {
/*  37 */     this.planSuffix = planSuffix;
/*     */   }
/*     */   
/*     */   public void setPlanType(String planType) {
/*  41 */     this.planType = planType;
/*     */   }
/*     */   
/*     */   public void setUnitType(String unitType) {
/*  45 */     this.unitType = unitType;
/*     */   }
/*     */   
/*     */   public int memberGateType(int memberIndex) {
/*  49 */     switch (memberIndex) {
/*     */       case 0:
/*  51 */         return 6;
/*     */       case 1:
/*  53 */         return 6;
/*     */       case 2:
/*  55 */         return 6;
/*     */       case 3:
/*  57 */         return 6;
/*     */       case 4:
/*  59 */         return 6;
/*     */     } 
/*  61 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void construct() {}
/*     */ 
/*     */   
/*     */   public void setMember(int index, Object memberValue) {
/*     */     try {
/*  70 */       switch (index) {
/*     */         case 0:
/*  72 */           this._instance.setDescPlan((String)memberValue);
/*     */           return;
/*     */         case 1:
/*  75 */           this._instance.setPlanCode((String)memberValue);
/*     */           return;
/*     */         case 2:
/*  78 */           this._instance.setPlanSuffix((String)memberValue);
/*     */           return;
/*     */         case 3:
/*  81 */           this._instance.setPlanType((String)memberValue);
/*     */           return;
/*     */         case 4:
/*  84 */           this._instance.setUnitType((String)memberValue);
/*     */           return;
/*     */       } 
/*  87 */       throw new IllegalArgumentException();
/*     */     
/*     */     }
/*  90 */     catch (RuntimeException e) {
/*  91 */       throw e;
/*     */     }
/*  93 */     catch (Exception e) {
/*  94 */       throw new DeserializationException(new LocalizableExceptionAdapter(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {}
/*     */   
/*     */   public void setInstance(Object instance) {
/* 102 */     this._instance = (PlanTO)instance;
/*     */   }
/*     */   
/*     */   public Object getInstance() {
/* 106 */     return this._instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\runtime\PlanTO_SOAPBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */