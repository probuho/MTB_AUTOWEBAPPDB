/*     */ package ve.com.movilnet.gdis.cia.ws.to.responses;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.AdjustmentReasonsTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.AlcoCosTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.BalanceListTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ChargeCodeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CityStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CommunalCouncilChargeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.CoolingReasonTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.EquipmentTypeTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanBenefitTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.IVRPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.LocalityTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MemosCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.MunicipalitieTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ParisheTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PhoneModelTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.PromotionTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SectorTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SellingAgentTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ServiceTO_v3;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.StateTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.SubCategoryTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.TextPlanTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.UrbanizationTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneStructuredTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.commons.ZoneTO;
/*     */ 
/*     */ public class MasterDataResponseTO_v2 extends ResponseTO implements Serializable {
/*     */   protected AdjustmentReasonsTO[] adjustmentReasons;
/*     */   protected AlcoCosTO alcoCosTO;
/*     */   protected BalanceListTO[] balanceList;
/*     */   protected ChargeCodeTO[] chargeCodes;
/*     */   protected CityTO[] city;
/*     */   protected CommunalCouncilChargeTO[] communalCouncilCharges;
/*     */   protected CoolingReasonTO[] coolingReason;
/*     */   protected EquipmentTypeTO[] equipmentTypeTO;
/*     */   protected SubCategoryTO[] feechargeType;
/*     */   protected IVRPlanBenefitTO[] ivrPlanBenefits;
/*     */   protected IVRPlanTO[] ivrPlans;
/*     */   protected LocalityTO[] locality;
/*     */   protected MemosCategoryTO[] memosCategory;
/*     */   protected PhoneModelTO[] modelsPhones;
/*     */   protected MunicipalitieTO[] municipalitie;
/*     */   protected NationalitiesTO[] nationalities;
/*     */   
/*     */   public AdjustmentReasonsTO[] getAdjustmentReasons() {
/*  48 */     return this.adjustmentReasons;
/*     */   }
/*     */   protected ParisheTO[] parishe; protected PlanTO[] plans; protected ProfessionTO[] profession; protected PromotionTO[] promotions; protected PromotionTO[] promotionsMig; protected SectorTO[] sector; protected SellingAgentTO[] sellingAgent; protected ServiceTO_v3[] services; protected StateTO[] state; protected CityStructuredTO[] structuredCities; protected StateTO[] structuredStates; protected ZoneStructuredTO[] structuredZones; protected SubCategoryTO[] subCategory; protected TextPlanTO[] textPlans; protected UrbanizationTO[] urbanization; protected ZoneTO[] zone;
/*     */   public void setAdjustmentReasons(AdjustmentReasonsTO[] adjustmentReasons) {
/*  52 */     this.adjustmentReasons = adjustmentReasons;
/*     */   }
/*     */   
/*     */   public AlcoCosTO getAlcoCosTO() {
/*  56 */     return this.alcoCosTO;
/*     */   }
/*     */   
/*     */   public void setAlcoCosTO(AlcoCosTO alcoCosTO) {
/*  60 */     this.alcoCosTO = alcoCosTO;
/*     */   }
/*     */   
/*     */   public BalanceListTO[] getBalanceList() {
/*  64 */     return this.balanceList;
/*     */   }
/*     */   
/*     */   public void setBalanceList(BalanceListTO[] balanceList) {
/*  68 */     this.balanceList = balanceList;
/*     */   }
/*     */   
/*     */   public ChargeCodeTO[] getChargeCodes() {
/*  72 */     return this.chargeCodes;
/*     */   }
/*     */   
/*     */   public void setChargeCodes(ChargeCodeTO[] chargeCodes) {
/*  76 */     this.chargeCodes = chargeCodes;
/*     */   }
/*     */   
/*     */   public CityTO[] getCity() {
/*  80 */     return this.city;
/*     */   }
/*     */   
/*     */   public void setCity(CityTO[] city) {
/*  84 */     this.city = city;
/*     */   }
/*     */   
/*     */   public CommunalCouncilChargeTO[] getCommunalCouncilCharges() {
/*  88 */     return this.communalCouncilCharges;
/*     */   }
/*     */   
/*     */   public void setCommunalCouncilCharges(CommunalCouncilChargeTO[] communalCouncilCharges) {
/*  92 */     this.communalCouncilCharges = communalCouncilCharges;
/*     */   }
/*     */   
/*     */   public CoolingReasonTO[] getCoolingReason() {
/*  96 */     return this.coolingReason;
/*     */   }
/*     */   
/*     */   public void setCoolingReason(CoolingReasonTO[] coolingReason) {
/* 100 */     this.coolingReason = coolingReason;
/*     */   }
/*     */   
/*     */   public EquipmentTypeTO[] getEquipmentTypeTO() {
/* 104 */     return this.equipmentTypeTO;
/*     */   }
/*     */   
/*     */   public void setEquipmentTypeTO(EquipmentTypeTO[] equipmentTypeTO) {
/* 108 */     this.equipmentTypeTO = equipmentTypeTO;
/*     */   }
/*     */   
/*     */   public SubCategoryTO[] getFeechargeType() {
/* 112 */     return this.feechargeType;
/*     */   }
/*     */   
/*     */   public void setFeechargeType(SubCategoryTO[] feechargeType) {
/* 116 */     this.feechargeType = feechargeType;
/*     */   }
/*     */   
/*     */   public IVRPlanBenefitTO[] getIvrPlanBenefits() {
/* 120 */     return this.ivrPlanBenefits;
/*     */   }
/*     */   
/*     */   public void setIvrPlanBenefits(IVRPlanBenefitTO[] ivrPlanBenefits) {
/* 124 */     this.ivrPlanBenefits = ivrPlanBenefits;
/*     */   }
/*     */   
/*     */   public IVRPlanTO[] getIvrPlans() {
/* 128 */     return this.ivrPlans;
/*     */   }
/*     */   
/*     */   public void setIvrPlans(IVRPlanTO[] ivrPlans) {
/* 132 */     this.ivrPlans = ivrPlans;
/*     */   }
/*     */   
/*     */   public LocalityTO[] getLocality() {
/* 136 */     return this.locality;
/*     */   }
/*     */   
/*     */   public void setLocality(LocalityTO[] locality) {
/* 140 */     this.locality = locality;
/*     */   }
/*     */   
/*     */   public MemosCategoryTO[] getMemosCategory() {
/* 144 */     return this.memosCategory;
/*     */   }
/*     */   
/*     */   public void setMemosCategory(MemosCategoryTO[] memosCategory) {
/* 148 */     this.memosCategory = memosCategory;
/*     */   }
/*     */   
/*     */   public PhoneModelTO[] getModelsPhones() {
/* 152 */     return this.modelsPhones;
/*     */   }
/*     */   
/*     */   public void setModelsPhones(PhoneModelTO[] modelsPhones) {
/* 156 */     this.modelsPhones = modelsPhones;
/*     */   }
/*     */   
/*     */   public MunicipalitieTO[] getMunicipalitie() {
/* 160 */     return this.municipalitie;
/*     */   }
/*     */   
/*     */   public void setMunicipalitie(MunicipalitieTO[] municipalitie) {
/* 164 */     this.municipalitie = municipalitie;
/*     */   }
/*     */   
/*     */   public NationalitiesTO[] getNationalities() {
/* 168 */     return this.nationalities;
/*     */   }
/*     */   
/*     */   public void setNationalities(NationalitiesTO[] nationalities) {
/* 172 */     this.nationalities = nationalities;
/*     */   }
/*     */   
/*     */   public ParisheTO[] getParishe() {
/* 176 */     return this.parishe;
/*     */   }
/*     */   
/*     */   public void setParishe(ParisheTO[] parishe) {
/* 180 */     this.parishe = parishe;
/*     */   }
/*     */   
/*     */   public PlanTO[] getPlans() {
/* 184 */     return this.plans;
/*     */   }
/*     */   
/*     */   public void setPlans(PlanTO[] plans) {
/* 188 */     this.plans = plans;
/*     */   }
/*     */   
/*     */   public ProfessionTO[] getProfession() {
/* 192 */     return this.profession;
/*     */   }
/*     */   
/*     */   public void setProfession(ProfessionTO[] profession) {
/* 196 */     this.profession = profession;
/*     */   }
/*     */   
/*     */   public PromotionTO[] getPromotions() {
/* 200 */     return this.promotions;
/*     */   }
/*     */   
/*     */   public void setPromotions(PromotionTO[] promotions) {
/* 204 */     this.promotions = promotions;
/*     */   }
/*     */   
/*     */   public PromotionTO[] getPromotionsMig() {
/* 208 */     return this.promotionsMig;
/*     */   }
/*     */   
/*     */   public void setPromotionsMig(PromotionTO[] promotionsMig) {
/* 212 */     this.promotionsMig = promotionsMig;
/*     */   }
/*     */   
/*     */   public SectorTO[] getSector() {
/* 216 */     return this.sector;
/*     */   }
/*     */   
/*     */   public void setSector(SectorTO[] sector) {
/* 220 */     this.sector = sector;
/*     */   }
/*     */   
/*     */   public SellingAgentTO[] getSellingAgent() {
/* 224 */     return this.sellingAgent;
/*     */   }
/*     */   
/*     */   public void setSellingAgent(SellingAgentTO[] sellingAgent) {
/* 228 */     this.sellingAgent = sellingAgent;
/*     */   }
/*     */   
/*     */   public ServiceTO_v3[] getServices() {
/* 232 */     return this.services;
/*     */   }
/*     */   
/*     */   public void setServices(ServiceTO_v3[] services) {
/* 236 */     this.services = services;
/*     */   }
/*     */   
/*     */   public StateTO[] getState() {
/* 240 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setState(StateTO[] state) {
/* 244 */     this.state = state;
/*     */   }
/*     */   
/*     */   public CityStructuredTO[] getStructuredCities() {
/* 248 */     return this.structuredCities;
/*     */   }
/*     */   
/*     */   public void setStructuredCities(CityStructuredTO[] structuredCities) {
/* 252 */     this.structuredCities = structuredCities;
/*     */   }
/*     */   
/*     */   public StateTO[] getStructuredStates() {
/* 256 */     return this.structuredStates;
/*     */   }
/*     */   
/*     */   public void setStructuredStates(StateTO[] structuredStates) {
/* 260 */     this.structuredStates = structuredStates;
/*     */   }
/*     */   
/*     */   public ZoneStructuredTO[] getStructuredZones() {
/* 264 */     return this.structuredZones;
/*     */   }
/*     */   
/*     */   public void setStructuredZones(ZoneStructuredTO[] structuredZones) {
/* 268 */     this.structuredZones = structuredZones;
/*     */   }
/*     */   
/*     */   public SubCategoryTO[] getSubCategory() {
/* 272 */     return this.subCategory;
/*     */   }
/*     */   
/*     */   public void setSubCategory(SubCategoryTO[] subCategory) {
/* 276 */     this.subCategory = subCategory;
/*     */   }
/*     */   
/*     */   public TextPlanTO[] getTextPlans() {
/* 280 */     return this.textPlans;
/*     */   }
/*     */   
/*     */   public void setTextPlans(TextPlanTO[] textPlans) {
/* 284 */     this.textPlans = textPlans;
/*     */   }
/*     */   
/*     */   public UrbanizationTO[] getUrbanization() {
/* 288 */     return this.urbanization;
/*     */   }
/*     */   
/*     */   public void setUrbanization(UrbanizationTO[] urbanization) {
/* 292 */     this.urbanization = urbanization;
/*     */   }
/*     */   
/*     */   public ZoneTO[] getZone() {
/* 296 */     return this.zone;
/*     */   }
/*     */   
/*     */   public void setZone(ZoneTO[] zone) {
/* 300 */     this.zone = zone;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\responses\MasterDataResponseTO_v2.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */