/*    */ package ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.wsprepaybasebrplanoffer;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*    */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*    */ import oracle.j2ee.ws.common.encoding.SOAPSerializationContext;
/*    */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*    */ import oracle.j2ee.ws.common.streaming.XMLReaderException;
/*    */ import oracle.j2ee.ws.common.streaming.XMLWriter;
/*    */ import ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS;
/*    */ import ve.com.movilnet.gdis.cia.prepay.ws.base.brplanoffer.services.runtime.WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPBuilder;
/*    */ 
/*    */ public class WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer extends ObjectSerializerBase implements Initializable {
/*    */   static Class class$(String paramString) { 
/* 18 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/* 19 */      } private static final QName ns1_planRequest_QNAME = new QName("", "planRequest");
/* 20 */   private static final QName ns2_ValidatePlanRequestTO_TYPE_QNAME = new QName("http://to.ws.cia.gdis.movilnet.com.ve/types/", "ValidatePlanRequestTO"); private CombinedSerializer myns2_ValidatePlanRequestTO__ValidatePlanRequestTO_SOAPSerializer;
/*    */   private static final int myplanRequest_INDEX = 0;
/*    */   private static Class class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO;
/*    */   
/*    */   public WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer(QName type, boolean encodeType, boolean isNullable, SOAPVersion soapVersion) {
/* 25 */     super(type, encodeType, isNullable, soapVersion);
/*    */   }
/*    */   
/*    */   public void initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 29 */     if (class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO == null); ((WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer)registry).myns2_ValidatePlanRequestTO__ValidatePlanRequestTO_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO, class$ve$com$movilnet$gdis$cia$ws$to$requests$ValidatePlanRequestTO = class$("ve.com.movilnet.gdis.cia.ws.to.requests.ValidatePlanRequestTO"), ns2_ValidatePlanRequestTO_TYPE_QNAME);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object doDeserialize(SOAPDeserializationState state, XMLReader reader, SOAPDeserializationContext context) throws Exception {
/* 34 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS instance = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS();
/* 35 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPBuilder builder = null;
/*    */     
/* 37 */     boolean isComplete = true;
/*    */ 
/*    */     
/* 40 */     reader.nextElementContent();
/* 41 */     QName startName = reader.getName();
/* 42 */     QName elementName = reader.getName();
/* 43 */     if (reader.getState() == 1) {
/* 44 */       if (matchQName(elementName, ns1_planRequest_QNAME)) {
/* 45 */         context.setNillable(true);
/* 46 */         Object member = this.myns2_ValidatePlanRequestTO__ValidatePlanRequestTO_SOAPSerializer.deserialize(ns1_planRequest_QNAME, reader, context);
/* 47 */         if (member instanceof SOAPDeserializationState) {
/* 48 */           if (builder == null) {
/* 49 */             builder = new WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPBuilder();
/*    */           }
/* 51 */           state = registerWithMemberState(instance, state, member, 0, (SOAPInstanceBuilder)builder);
/* 52 */           isComplete = false;
/* 53 */         } else if (member != null) {
/* 54 */           instance.setPlanRequest((ValidatePlanRequestTO)member);
/*    */         } 
/* 56 */         reader.nextElementContent();
/*    */       } else {
/* 58 */         throw new DeserializationException("soap.unexpectedElementName", new Object[] { ns1_planRequest_QNAME, elementName }, 1);
/*    */       } 
/*    */     }
/*    */     
/*    */     try {
/* 63 */       XMLReaderUtil.verifyReaderState(reader, 2);
/* 64 */     } catch (XMLReaderException xmle) {
/* 65 */       if (startName != null) {
/* 66 */         throw new DeserializationException("Expect END: " + startName, xmle);
/*    */       }
/* 68 */       throw xmle;
/*    */     } 
/*    */     
/* 71 */     return isComplete ? instance : state;
/*    */   }
/*    */   
/*    */   public void doSerializeInstance(Object obj, XMLWriter writer, SOAPSerializationContext context) throws Exception {
/* 75 */     WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS instance = (WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS)obj;
/*    */     
/* 77 */     context.setNillable(true);
/* 78 */     this.myns2_ValidatePlanRequestTO__ValidatePlanRequestTO_SOAPSerializer.serialize(instance.getPlanRequest(), ns1_planRequest_QNAME, null, writer, context);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\prepay\ws\base\brplanoffer\services\runtime\wsprepaybasebrplanoffer\WSPrepayBaseBrPlanOfferSoapHttp_validatePlan_ReqS_SOAPSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */