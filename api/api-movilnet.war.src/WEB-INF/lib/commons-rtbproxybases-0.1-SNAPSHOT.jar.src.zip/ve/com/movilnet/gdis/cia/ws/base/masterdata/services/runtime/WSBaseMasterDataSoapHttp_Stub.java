/*     */ package ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.HandlerChain;
/*     */ import oracle.j2ee.ws.client.ClientTransportException;
/*     */ import oracle.j2ee.ws.client.SenderException;
/*     */ import oracle.j2ee.ws.client.StreamingSenderState;
/*     */ import oracle.j2ee.ws.client.StubBase;
/*     */ import oracle.j2ee.ws.common.encoding.CombinedSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.DeserializationException;
/*     */ import oracle.j2ee.ws.common.encoding.InternalTypeMappingRegistry;
/*     */ import oracle.j2ee.ws.common.encoding.JAXRPCSerializer;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationContext;
/*     */ import oracle.j2ee.ws.common.encoding.SOAPDeserializationState;
/*     */ import oracle.j2ee.ws.common.soap.SOAPEncodingConstants;
/*     */ import oracle.j2ee.ws.common.soap.SOAPVersion;
/*     */ import oracle.j2ee.ws.common.soap.message.InternalSOAPMessage;
/*     */ import oracle.j2ee.ws.common.soap.message.SOAPBlockInfo;
/*     */ import oracle.j2ee.ws.common.streaming.XMLReader;
/*     */ import oracle.webservices.transport.ClientTransport;
/*     */ import ve.com.movilnet.gdis.cia.ws.base.masterdata.services.IWSBaseMasterData;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.IntRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.requests.MasterDataRequestTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.AlcoCosResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO;
/*     */ import ve.com.movilnet.gdis.cia.ws.to.responses.MasterDataResponseTO_v2;
/*     */ 
/*     */ public class WSBaseMasterDataSoapHttp_Stub extends StubBase implements IWSBaseMasterData {
/*     */   static Class class$(String paramString) {
/*     */     
/*  33 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(null.getMessage()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WSBaseMasterDataSoapHttp_Stub(HandlerChain handlerChain) {
/*  42 */     super(handlerChain);
/*  43 */     _setProperty("javax.xml.rpc.service.endpoint.address", "http://172.16.216.203:8888/wsbasemasterdata/masterdata");
/*  44 */     setSoapVersion(SOAPVersion.SOAP_11);
/*  45 */     setServiceName(new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "WSBaseMasterData"));
/*  46 */     setPortName(new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "masterdata"));
/*  47 */     setupConfig("ve/com/movilnet/gdis/cia/ws/base/masterdata/services/runtime/WSBaseMasterDataSoapHttp_Stub.xml");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AlcoCosResponseTO getMasterDataAlcoAndCos(IntRequestTO request) throws RemoteException {
/*  56 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/*  59 */       _state = _start(this._handlerChain);
/*  60 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/*  61 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/*  64 */       InternalSOAPMessage _request = _state.getRequest();
/*  65 */       _request.setOperationCode(0);
/*  66 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "getMasterDataAlcoAndCos"));
/*     */       
/*  68 */       WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS _myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS = new WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS();
/*     */       
/*  70 */       _myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS.setRequest(request);
/*  71 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_getMasterDataAlcoAndCos_getMasterDataAlcoAndCos_QNAME);
/*  72 */       _bodyBlock.setValue(_myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS);
/*  73 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_getMasterDataAlcoAndCos__WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS_SOAPSerializer);
/*  74 */       _request.setBody(_bodyBlock);
/*     */       
/*  76 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve//getMasterDataAlcoAndCos");
/*     */ 
/*     */       
/*  79 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/*  81 */       WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS _myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS = null;
/*  82 */       Object _responseObj = _state.getResponse().getBody().getValue();
/*  83 */       if (_responseObj instanceof SOAPDeserializationState) {
/*  84 */         _myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS = (WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/*  87 */         _myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS = (WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/*  91 */       return _myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS.getResult();
/*  92 */     } catch (RemoteException e) {
/*     */       
/*  94 */       throw e;
/*  95 */     } catch (ClientTransportException e) {
/*  96 */       throw new RemoteException("", e);
/*  97 */     } catch (JAXRPCException e) {
/*  98 */       throw e;
/*  99 */     } catch (Exception e) {
/* 100 */       if (e instanceof RuntimeException) {
/* 101 */         throw (RuntimeException)e;
/*     */       }
/* 103 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MasterDataResponseTO getMasterDataGeographicalLocation(MasterDataRequestTO masterRequest) throws RemoteException {
/* 114 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/* 117 */       _state = _start(this._handlerChain);
/* 118 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/* 119 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/* 122 */       InternalSOAPMessage _request = _state.getRequest();
/* 123 */       _request.setOperationCode(1);
/* 124 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "getMasterDataGeographicalLocation"));
/*     */       
/* 126 */       WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS _myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS = new WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS();
/*     */       
/* 128 */       _myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS.setMasterRequest(masterRequest);
/* 129 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_getMasterDataGeographicalLocation_getMasterDataGeographicalLocation_QNAME);
/* 130 */       _bodyBlock.setValue(_myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS);
/* 131 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_getMasterDataGeographicalLocation__WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS_SOAPSerializer);
/* 132 */       _request.setBody(_bodyBlock);
/*     */       
/* 134 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve//getMasterDataGeographicalLocation");
/*     */ 
/*     */       
/* 137 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/* 139 */       WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS _myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS = null;
/* 140 */       Object _responseObj = _state.getResponse().getBody().getValue();
/* 141 */       if (_responseObj instanceof SOAPDeserializationState) {
/* 142 */         _myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS = (WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/* 145 */         _myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS = (WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/* 149 */       return _myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS.getResult();
/* 150 */     } catch (RemoteException e) {
/*     */       
/* 152 */       throw e;
/* 153 */     } catch (ClientTransportException e) {
/* 154 */       throw new RemoteException("", e);
/* 155 */     } catch (JAXRPCException e) {
/* 156 */       throw e;
/* 157 */     } catch (Exception e) {
/* 158 */       if (e instanceof RuntimeException) {
/* 159 */         throw (RuntimeException)e;
/*     */       }
/* 161 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MasterDataResponseTO getMasterDataPersonalData(MasterDataRequestTO masterRequest) throws RemoteException {
/* 172 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/* 175 */       _state = _start(this._handlerChain);
/* 176 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/* 177 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/* 180 */       InternalSOAPMessage _request = _state.getRequest();
/* 181 */       _request.setOperationCode(2);
/* 182 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "getMasterDataPersonalData"));
/*     */       
/* 184 */       WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS _myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS = new WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS();
/*     */       
/* 186 */       _myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS.setMasterRequest(masterRequest);
/* 187 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_getMasterDataPersonalData_getMasterDataPersonalData_QNAME);
/* 188 */       _bodyBlock.setValue(_myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS);
/* 189 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_getMasterDataPersonalData__WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS_SOAPSerializer);
/* 190 */       _request.setBody(_bodyBlock);
/*     */       
/* 192 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve//getMasterDataPersonalData");
/*     */ 
/*     */       
/* 195 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/* 197 */       WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS _myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS = null;
/* 198 */       Object _responseObj = _state.getResponse().getBody().getValue();
/* 199 */       if (_responseObj instanceof SOAPDeserializationState) {
/* 200 */         _myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS = (WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/* 203 */         _myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS = (WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/* 207 */       return _myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS.getResult();
/* 208 */     } catch (RemoteException e) {
/*     */       
/* 210 */       throw e;
/* 211 */     } catch (ClientTransportException e) {
/* 212 */       throw new RemoteException("", e);
/* 213 */     } catch (JAXRPCException e) {
/* 214 */       throw e;
/* 215 */     } catch (Exception e) {
/* 216 */       if (e instanceof RuntimeException) {
/* 217 */         throw (RuntimeException)e;
/*     */       }
/* 219 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MasterDataResponseTO getMasterDataProductAndService(MasterDataRequestTO masterRequest) throws RemoteException {
/* 230 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/* 233 */       _state = _start(this._handlerChain);
/* 234 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/* 235 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/* 238 */       InternalSOAPMessage _request = _state.getRequest();
/* 239 */       _request.setOperationCode(3);
/* 240 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "getMasterDataProductAndService"));
/*     */       
/* 242 */       WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS = new WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS();
/*     */       
/* 244 */       _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS.setMasterRequest(masterRequest);
/* 245 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_getMasterDataProductAndService_getMasterDataProductAndService_QNAME);
/* 246 */       _bodyBlock.setValue(_myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS);
/* 247 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_getMasterDataProductAndService__WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS_SOAPSerializer);
/* 248 */       _request.setBody(_bodyBlock);
/*     */       
/* 250 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve//getMasterDataProductAndService");
/*     */ 
/*     */       
/* 253 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/* 255 */       WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS = null;
/* 256 */       Object _responseObj = _state.getResponse().getBody().getValue();
/* 257 */       if (_responseObj instanceof SOAPDeserializationState) {
/* 258 */         _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS = (WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/* 261 */         _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS = (WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/* 265 */       return _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS.getResult();
/* 266 */     } catch (RemoteException e) {
/*     */       
/* 268 */       throw e;
/* 269 */     } catch (ClientTransportException e) {
/* 270 */       throw new RemoteException("", e);
/* 271 */     } catch (JAXRPCException e) {
/* 272 */       throw e;
/* 273 */     } catch (Exception e) {
/* 274 */       if (e instanceof RuntimeException) {
/* 275 */         throw (RuntimeException)e;
/*     */       }
/* 277 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MasterDataResponseTO_v2 getMasterDataProductAndService2(MasterDataRequestTO masterRequest) throws RemoteException {
/* 288 */     StreamingSenderState _state = null;
/*     */     
/*     */     try {
/* 291 */       _state = _start(this._handlerChain);
/* 292 */       if (_getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments") != null) {
/* 293 */         _state.getMessageContext().getMessage().setProperty("DimeEncode", _getProperty("oracle.webservices.dimeEncodeMessagesWithAttachments"));
/*     */       }
/*     */       
/* 296 */       InternalSOAPMessage _request = _state.getRequest();
/* 297 */       _request.setOperationCode(4);
/* 298 */       _state.getMessageContext().setProperty("oracle.j2ee.ws.mgmt.interceptor.operation-qname", new QName("", "getMasterDataProductAndService2"));
/*     */       
/* 300 */       WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS = new WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS();
/*     */       
/* 302 */       _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS.setMasterRequest(masterRequest);
/* 303 */       SOAPBlockInfo _bodyBlock = new SOAPBlockInfo(ns1_getMasterDataProductAndService2_getMasterDataProductAndService2_QNAME);
/* 304 */       _bodyBlock.setValue(_myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS);
/* 305 */       _bodyBlock.setSerializer((JAXRPCSerializer)this.myns1_getMasterDataProductAndService2__WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPSerializer);
/* 306 */       _request.setBody(_bodyBlock);
/*     */       
/* 308 */       _state.getMessageContext().setProperty("http.soap.action", "http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve//getMasterDataProductAndService2");
/*     */ 
/*     */       
/* 311 */       _send((String)_getProperty("javax.xml.rpc.service.endpoint.address"), _state);
/*     */       
/* 313 */       WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS = null;
/* 314 */       Object _responseObj = _state.getResponse().getBody().getValue();
/* 315 */       if (_responseObj instanceof SOAPDeserializationState) {
/* 316 */         _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS = (WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS)((SOAPDeserializationState)_responseObj).getInstance();
/*     */       } else {
/*     */         
/* 319 */         _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS = (WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS)_responseObj;
/*     */       } 
/*     */ 
/*     */       
/* 323 */       return _myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS.getResult();
/* 324 */     } catch (RemoteException e) {
/*     */       
/* 326 */       throw e;
/* 327 */     } catch (ClientTransportException e) {
/* 328 */       throw new RemoteException("", e);
/* 329 */     } catch (JAXRPCException e) {
/* 330 */       throw e;
/* 331 */     } catch (Exception e) {
/* 332 */       if (e instanceof RuntimeException) {
/* 333 */         throw (RuntimeException)e;
/*     */       }
/* 335 */       throw new RemoteException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _readFirstBodyElement(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/* 345 */     int opcode = state.getRequest().getOperationCode();
/* 346 */     switch (opcode) {
/*     */       case 0:
/* 348 */         _deserialize_getMasterDataAlcoAndCos(bodyReader, deserializationContext, state);
/*     */         return;
/*     */       case 1:
/* 351 */         _deserialize_getMasterDataGeographicalLocation(bodyReader, deserializationContext, state);
/*     */         return;
/*     */       case 2:
/* 354 */         _deserialize_getMasterDataPersonalData(bodyReader, deserializationContext, state);
/*     */         return;
/*     */       case 3:
/* 357 */         _deserialize_getMasterDataProductAndService(bodyReader, deserializationContext, state);
/*     */         return;
/*     */       case 4:
/* 360 */         _deserialize_getMasterDataProductAndService2(bodyReader, deserializationContext, state);
/*     */         return;
/*     */     } 
/* 363 */     throw new SenderException("sender.response.unrecognizedOperation", Integer.toString(opcode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_getMasterDataAlcoAndCos(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 374 */       Object myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespSObj = this.myns1_getMasterDataAlcoAndCosResponse__WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS_SOAPSerializer.deserialize(ns1_getMasterDataAlcoAndCos_getMasterDataAlcoAndCosResponse_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 378 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_getMasterDataAlcoAndCos_getMasterDataAlcoAndCosResponse_QNAME);
/* 379 */       bodyBlock.setValue(myWSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespSObj);
/* 380 */       state.getResponse().setBody(bodyBlock);
/* 381 */     } catch (DeserializationException e) {
/* 382 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 383 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 385 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_getMasterDataGeographicalLocation(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 394 */       Object myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespSObj = this.myns1_getMasterDataGeographicalLocationResponse__WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS_SOAPSerializer.deserialize(ns1_getMasterDataGeographicalLocation_getMasterDataGeographicalLocationResponse_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 398 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_getMasterDataGeographicalLocation_getMasterDataGeographicalLocationResponse_QNAME);
/* 399 */       bodyBlock.setValue(myWSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespSObj);
/* 400 */       state.getResponse().setBody(bodyBlock);
/* 401 */     } catch (DeserializationException e) {
/* 402 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 403 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 405 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_getMasterDataPersonalData(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 414 */       Object myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespSObj = this.myns1_getMasterDataPersonalDataResponse__WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS_SOAPSerializer.deserialize(ns1_getMasterDataPersonalData_getMasterDataPersonalDataResponse_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 418 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_getMasterDataPersonalData_getMasterDataPersonalDataResponse_QNAME);
/* 419 */       bodyBlock.setValue(myWSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespSObj);
/* 420 */       state.getResponse().setBody(bodyBlock);
/* 421 */     } catch (DeserializationException e) {
/* 422 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 423 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 425 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_getMasterDataProductAndService(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 434 */       Object myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespSObj = this.myns1_getMasterDataProductAndServiceResponse__WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS_SOAPSerializer.deserialize(ns1_getMasterDataProductAndService_getMasterDataProductAndServiceResponse_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 438 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_getMasterDataProductAndService_getMasterDataProductAndServiceResponse_QNAME);
/* 439 */       bodyBlock.setValue(myWSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespSObj);
/* 440 */       state.getResponse().setBody(bodyBlock);
/* 441 */     } catch (DeserializationException e) {
/* 442 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 443 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 445 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _deserialize_getMasterDataProductAndService2(XMLReader bodyReader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {
/*     */     try {
/* 454 */       Object myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespSObj = this.myns1_getMasterDataProductAndService2Response__WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS_SOAPSerializer.deserialize(ns1_getMasterDataProductAndService2_getMasterDataProductAndService2Response_QNAME, bodyReader, deserializationContext);
/*     */ 
/*     */ 
/*     */       
/* 458 */       SOAPBlockInfo bodyBlock = new SOAPBlockInfo(ns1_getMasterDataProductAndService2_getMasterDataProductAndService2Response_QNAME);
/* 459 */       bodyBlock.setValue(myWSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespSObj);
/* 460 */       state.getResponse().setBody(bodyBlock);
/* 461 */     } catch (DeserializationException e) {
/* 462 */       if (e.getSoapFaultSubCodeType() == -1 && e.getSoapFaultCodeType() != 4) {
/* 463 */         e.setSoapFaultSubCodeType(6);
/*     */       }
/* 465 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String _getEncodingStyle() {
/* 473 */     return SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding();
/*     */   }
/*     */   
/*     */   public void _setEncodingStyle(String encodingStyle) {
/* 477 */     throw new UnsupportedOperationException("cannot set encoding style");
/*     */   }
/*     */   
/*     */   public ClientTransport getClientTransport() {
/* 481 */     return (ClientTransport)_getTransport();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] _getNamespaceDeclarations() {
/* 492 */     return myNamespace_declarations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName[] _getUnderstoodHeaders() {
/* 499 */     return understoodHeaderNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _handleEmptyBody(XMLReader reader, SOAPDeserializationContext deserializationContext, StreamingSenderState state) throws Exception {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void _initialize(InternalTypeMappingRegistry registry) throws Exception {
/* 509 */     super._initialize(registry);
/* 510 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataGeographicalLocation__WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS"), ns1_getMasterDataGeographicalLocation_TYPE_QNAME);
/* 511 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataAlcoAndCos__WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS"), ns1_getMasterDataAlcoAndCos_TYPE_QNAME);
/* 512 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataGeographicalLocationResponse__WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS"), ns1_getMasterDataGeographicalLocationResponse_TYPE_QNAME);
/* 513 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataProductAndService__WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS"), ns1_getMasterDataProductAndService_TYPE_QNAME);
/* 514 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataProductAndServiceResponse__WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS"), ns1_getMasterDataProductAndServiceResponse_TYPE_QNAME);
/* 515 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataProductAndService2__WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS"), ns1_getMasterDataProductAndService2_TYPE_QNAME);
/* 516 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataAlcoAndCosResponse__WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS"), ns1_getMasterDataAlcoAndCosResponse_TYPE_QNAME);
/* 517 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataPersonalDataResponse__WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS"), ns1_getMasterDataPersonalDataResponse_TYPE_QNAME);
/* 518 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataProductAndService2Response__WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS"), ns1_getMasterDataProductAndService2Response_TYPE_QNAME);
/* 519 */     if (class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS == null); ((WSBaseMasterDataSoapHttp_Stub)registry).myns1_getMasterDataPersonalData__WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS_SOAPSerializer = (CombinedSerializer)SOAPEncodingConstants.getSOAPEncodingConstants(this.soapVersion).getURIEncoding().getSerializer((String)class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS, class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS = class$("ve.com.movilnet.gdis.cia.ws.base.masterdata.services.runtime.WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS"), ns1_getMasterDataPersonalData_TYPE_QNAME);
/*     */   }
/*     */   
/* 522 */   private static final QName _portName = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "masterdata");
/*     */   private static final int getMasterDataAlcoAndCos_OPCODE = 0;
/*     */   private static final int getMasterDataGeographicalLocation_OPCODE = 1;
/*     */   private static final int getMasterDataPersonalData_OPCODE = 2;
/*     */   private static final int getMasterDataProductAndService_OPCODE = 3;
/*     */   private static final int getMasterDataProductAndService2_OPCODE = 4;
/* 528 */   private static final QName ns1_getMasterDataAlcoAndCos_getMasterDataAlcoAndCos_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataAlcoAndCos");
/* 529 */   private static final QName ns1_getMasterDataAlcoAndCos_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataAlcoAndCos");
/*     */   private CombinedSerializer myns1_getMasterDataAlcoAndCos__WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS_SOAPSerializer;
/* 531 */   private static final QName ns1_getMasterDataAlcoAndCos_getMasterDataAlcoAndCosResponse_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataAlcoAndCosResponse");
/* 532 */   private static final QName ns1_getMasterDataAlcoAndCosResponse_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataAlcoAndCosResponse");
/*     */   private CombinedSerializer myns1_getMasterDataAlcoAndCosResponse__WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS_SOAPSerializer;
/* 534 */   private static final QName ns1_getMasterDataGeographicalLocation_getMasterDataGeographicalLocation_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataGeographicalLocation");
/* 535 */   private static final QName ns1_getMasterDataGeographicalLocation_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataGeographicalLocation");
/*     */   private CombinedSerializer myns1_getMasterDataGeographicalLocation__WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS_SOAPSerializer;
/* 537 */   private static final QName ns1_getMasterDataGeographicalLocation_getMasterDataGeographicalLocationResponse_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataGeographicalLocationResponse");
/* 538 */   private static final QName ns1_getMasterDataGeographicalLocationResponse_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataGeographicalLocationResponse");
/*     */   private CombinedSerializer myns1_getMasterDataGeographicalLocationResponse__WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS_SOAPSerializer;
/* 540 */   private static final QName ns1_getMasterDataPersonalData_getMasterDataPersonalData_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataPersonalData");
/* 541 */   private static final QName ns1_getMasterDataPersonalData_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataPersonalData");
/*     */   private CombinedSerializer myns1_getMasterDataPersonalData__WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS_SOAPSerializer;
/* 543 */   private static final QName ns1_getMasterDataPersonalData_getMasterDataPersonalDataResponse_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataPersonalDataResponse");
/* 544 */   private static final QName ns1_getMasterDataPersonalDataResponse_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataPersonalDataResponse");
/*     */   private CombinedSerializer myns1_getMasterDataPersonalDataResponse__WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS_SOAPSerializer;
/* 546 */   private static final QName ns1_getMasterDataProductAndService_getMasterDataProductAndService_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService");
/* 547 */   private static final QName ns1_getMasterDataProductAndService_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService");
/*     */   private CombinedSerializer myns1_getMasterDataProductAndService__WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS_SOAPSerializer;
/* 549 */   private static final QName ns1_getMasterDataProductAndService_getMasterDataProductAndServiceResponse_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndServiceResponse");
/* 550 */   private static final QName ns1_getMasterDataProductAndServiceResponse_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndServiceResponse");
/*     */   private CombinedSerializer myns1_getMasterDataProductAndServiceResponse__WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS_SOAPSerializer;
/* 552 */   private static final QName ns1_getMasterDataProductAndService2_getMasterDataProductAndService2_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService2");
/* 553 */   private static final QName ns1_getMasterDataProductAndService2_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService2");
/*     */   private CombinedSerializer myns1_getMasterDataProductAndService2__WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS_SOAPSerializer;
/* 555 */   private static final QName ns1_getMasterDataProductAndService2_getMasterDataProductAndService2Response_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService2Response");
/* 556 */   private static final QName ns1_getMasterDataProductAndService2Response_TYPE_QNAME = new QName("http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "getMasterDataProductAndService2Response");
/*     */   private CombinedSerializer myns1_getMasterDataProductAndService2Response__WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS_SOAPSerializer;
/* 558 */   private static final String[] myNamespace_declarations = new String[] { "ns0", "http://services.masterdata.base.ws.cia.gdis.movilnet.com.ve/", "ns1", "http://to.ws.cia.gdis.movilnet.com.ve/types/" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 564 */   private static final QName[] understoodHeaderNames = new QName[0];
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_ReqS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_ReqS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataGeographicalLocation_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_ReqS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_ReqS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataAlcoAndCos_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataProductAndService2_RespS;
/*     */   private static Class class$ve$com$movilnet$gdis$cia$ws$base$masterdata$services$runtime$WSBaseMasterDataSoapHttp_getMasterDataPersonalData_ReqS;
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\base\masterdata\services\runtime\WSBaseMasterDataSoapHttp_Stub.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */