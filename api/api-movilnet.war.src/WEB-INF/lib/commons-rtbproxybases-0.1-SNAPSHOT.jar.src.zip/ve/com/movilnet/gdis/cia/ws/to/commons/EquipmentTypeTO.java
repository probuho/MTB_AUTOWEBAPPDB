/*    */ package ve.com.movilnet.gdis.cia.ws.to.commons;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EquipmentTypeTO
/*    */   implements Serializable
/*    */ {
/*    */   protected String apllyPlanType;
/*    */   protected String catlDesc;
/*    */   protected String itemCatId;
/*    */   
/*    */   public String getApllyPlanType() {
/* 19 */     return this.apllyPlanType;
/*    */   }
/*    */   
/*    */   public void setApllyPlanType(String apllyPlanType) {
/* 23 */     this.apllyPlanType = apllyPlanType;
/*    */   }
/*    */   
/*    */   public String getCatlDesc() {
/* 27 */     return this.catlDesc;
/*    */   }
/*    */   
/*    */   public void setCatlDesc(String catlDesc) {
/* 31 */     this.catlDesc = catlDesc;
/*    */   }
/*    */   
/*    */   public String getItemCatId() {
/* 35 */     return this.itemCatId;
/*    */   }
/*    */   
/*    */   public void setItemCatId(String itemCatId) {
/* 39 */     this.itemCatId = itemCatId;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtbproxybases-0.1-SNAPSHOT.jar!\ve\com\movilnet\gdis\cia\ws\to\commons\EquipmentTypeTO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */