/*    */ package ve.com.movilnet.commons2.servicios.constantes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Constantes
/*    */ {
/* 28 */   public static final byte[] CIPHER_SALT = new byte[] { -57, 115, 33, -116, 126, -56, -18, -103 };
/*    */   public static final int ITERATION_COUNT = 20;
/*    */   public static final String CIPHER_PASSWORD = "RecPre2011";
/*    */   public static final String CIPHER_ALGORITHM = "PBEWithMD5AndDES";
/*    */   public static final String BYTE_ENCODING = "ISO8859-1";
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\encriptador-1.0-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\constantes\Constantes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */