/*     */ package ve.com.movilnet.commons2.servicios.crypto;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ import ve.com.movilnet.commons2.servicios.constantes.Constantes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovilnetPBECipher
/*     */ {
/*     */   private static PBEKeySpec pbeKeySpec;
/*     */   private static PBEParameterSpec pbeParamSpec;
/*     */   private static SecretKeyFactory keyFac;
/*     */   
/*     */   private static void prepare() {
/*  75 */     pbeParamSpec = new PBEParameterSpec(Constantes.CIPHER_SALT, 20);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SecretKey generateKey() throws NoSuchAlgorithmException, InvalidKeySpecException {
/*  86 */     pbeKeySpec = new PBEKeySpec("RecPre2011".toCharArray());
/*  87 */     keyFac = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
/*  88 */     return keyFac.generateSecret(pbeKeySpec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encrypt(String clearText) throws Exception {
/*  98 */     SecretKey pbeKey = null;
/*  99 */     Cipher pbeCipher = null;
/* 100 */     byte[] cipherText = null;
/*     */     
/* 102 */     prepare();
/*     */     
/* 104 */     pbeKey = generateKey();
/*     */     
/* 106 */     pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
/*     */     
/* 108 */     pbeCipher.init(1, pbeKey, pbeParamSpec);
/*     */     
/* 110 */     cipherText = pbeCipher.doFinal(clearText.getBytes("ISO8859-1"));
/*     */     
/* 112 */     return new String(cipherText, "ISO8859-1");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decrypt(String cipherText) throws Exception {
/* 122 */     SecretKey pbeKey = null;
/* 123 */     Cipher pbeCipher = null;
/* 124 */     byte[] clearText = null;
/*     */     
/* 126 */     prepare();
/*     */     
/* 128 */     pbeKey = generateKey();
/*     */     
/* 130 */     pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
/*     */     
/* 132 */     pbeCipher.init(2, pbeKey, pbeParamSpec);
/*     */     
/* 134 */     clearText = pbeCipher.doFinal(cipherText.getBytes("ISO8859-1"));
/*     */     
/* 136 */     return new String(clearText, "ISO8859-1");
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\encriptador-1.0-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\crypto\MovilnetPBECipher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */