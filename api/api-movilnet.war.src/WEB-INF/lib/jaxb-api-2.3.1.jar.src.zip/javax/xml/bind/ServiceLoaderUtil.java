/*     */ package javax.xml.bind;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServiceLoaderUtil
/*     */ {
/*     */   private static final String OSGI_SERVICE_LOADER_CLASS_NAME = "org.glassfish.hk2.osgiresourcelocator.ServiceLoader";
/*     */   private static final String OSGI_SERVICE_LOADER_METHOD_NAME = "lookupProviderClasses";
/*     */   
/*     */   static <P, T extends Exception> P firstByServiceLoader(Class<P> spiClass, Logger logger, ExceptionHandler<T> handler) throws T {
/*     */     try {
/*  67 */       ServiceLoader<P> serviceLoader = ServiceLoader.load(spiClass);
/*     */       
/*  69 */       Iterator<P> iterator = serviceLoader.iterator(); if (iterator.hasNext()) { P impl = iterator.next();
/*  70 */         logger.fine("ServiceProvider loading Facility used; returning object [" + impl
/*  71 */             .getClass().getName() + "]");
/*     */         
/*  73 */         return impl; }
/*     */     
/*  75 */     } catch (Throwable t) {
/*  76 */       throw handler.createException(t, "Error while searching for service [" + spiClass.getName() + "]");
/*     */     } 
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Object lookupUsingOSGiServiceLoader(String factoryId, Logger logger) {
/*     */     try {
/*  85 */       Class<?> serviceClass = Class.forName(factoryId);
/*  86 */       Class<?> target = Class.forName("org.glassfish.hk2.osgiresourcelocator.ServiceLoader");
/*  87 */       Method m = target.getMethod("lookupProviderClasses", new Class[] { Class.class });
/*  88 */       Iterator iter = ((Iterable)m.invoke(null, new Object[] { serviceClass })).iterator();
/*  89 */       if (iter.hasNext()) {
/*  90 */         Object next = iter.next();
/*  91 */         logger.fine("Found implementation using OSGi facility; returning object [" + next
/*  92 */             .getClass().getName() + "].");
/*  93 */         return next;
/*     */       } 
/*  95 */       return null;
/*     */     }
/*  97 */     catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|ClassNotFoundException|NoSuchMethodException ignored) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       logger.log(Level.FINE, "Unable to find from OSGi: [" + factoryId + "]", ignored);
/* 103 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void checkPackageAccess(String className) {
/* 109 */     SecurityManager s = System.getSecurityManager();
/* 110 */     if (s != null) {
/* 111 */       int i = className.lastIndexOf('.');
/* 112 */       if (i != -1) {
/* 113 */         s.checkPackageAccess(className.substring(0, i));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static Class nullSafeLoadClass(String className, ClassLoader classLoader) throws ClassNotFoundException {
/* 119 */     if (classLoader == null) {
/* 120 */       return Class.forName(className);
/*     */     }
/* 122 */     return classLoader.loadClass(className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Exception> Object newInstance(String className, String defaultImplClassName, ExceptionHandler<T> handler) throws T {
/*     */     try {
/* 133 */       return safeLoadClass(className, defaultImplClassName, contextClassLoader(handler)).newInstance();
/* 134 */     } catch (ClassNotFoundException x) {
/* 135 */       throw handler.createException(x, "Provider " + className + " not found");
/* 136 */     } catch (Exception x) {
/* 137 */       throw handler.createException(x, "Provider " + className + " could not be instantiated: " + x);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class safeLoadClass(String className, String defaultImplClassName, ClassLoader classLoader) throws ClassNotFoundException {
/*     */     try {
/* 146 */       checkPackageAccess(className);
/* 147 */     } catch (SecurityException se) {
/*     */       
/* 149 */       if (defaultImplClassName != null && defaultImplClassName.equals(className)) {
/* 150 */         return Class.forName(className);
/*     */       }
/*     */       
/* 153 */       throw se;
/*     */     } 
/* 155 */     return nullSafeLoadClass(className, classLoader);
/*     */   }
/*     */   
/*     */   static ClassLoader contextClassLoader(ExceptionHandler exceptionHandler) throws Exception {
/*     */     try {
/* 160 */       return Thread.currentThread().getContextClassLoader();
/* 161 */     } catch (Exception x) {
/* 162 */       throw exceptionHandler.createException(x, x.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   static abstract class ExceptionHandler<T extends Exception> {
/*     */     public abstract T createException(Throwable param1Throwable, String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\ServiceLoaderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */