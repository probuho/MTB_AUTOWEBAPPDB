/*     */ package javax.xml.bind;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.ConsoleHandler;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ContextFinder
/*     */ {
/*     */   private static final String PLATFORM_DEFAULT_FACTORY_CLASS = "com.sun.xml.internal.bind.v2.ContextFactory";
/*     */   private static final String JAXB_CONTEXT_FACTORY_DEPRECATED = "javax.xml.bind.context.factory";
/*  93 */   private static final Logger logger = Logger.getLogger("javax.xml.bind"); static {
/*     */     try {
/*  95 */       if (AccessController.doPrivileged(new GetPropertyAction("jaxb.debug")) != null)
/*     */       {
/*     */         
/*  98 */         logger.setUseParentHandlers(false);
/*  99 */         logger.setLevel(Level.ALL);
/* 100 */         ConsoleHandler handler = new ConsoleHandler();
/* 101 */         handler.setLevel(Level.ALL);
/* 102 */         logger.addHandler(handler);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 108 */     catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private static ServiceLoaderUtil.ExceptionHandler<JAXBException> EXCEPTION_HANDLER = new ServiceLoaderUtil.ExceptionHandler<JAXBException>()
/*     */     {
/*     */       public JAXBException createException(Throwable throwable, String message)
/*     */       {
/* 118 */         return new JAXBException(message, throwable);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Throwable handleInvocationTargetException(InvocationTargetException x) throws JAXBException {
/* 127 */     Throwable t = x.getTargetException();
/* 128 */     if (t != null) {
/* 129 */       if (t instanceof JAXBException)
/*     */       {
/* 131 */         throw (JAXBException)t; } 
/* 132 */       if (t instanceof RuntimeException)
/*     */       {
/* 134 */         throw (RuntimeException)t; } 
/* 135 */       if (t instanceof Error)
/* 136 */         throw (Error)t; 
/* 137 */       return t;
/*     */     } 
/* 139 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JAXBException handleClassCastException(Class originalType, Class targetType) {
/* 155 */     URL targetTypeURL = which(targetType);
/*     */     
/* 157 */     return new JAXBException(Messages.format("JAXBContext.IllegalCast", 
/*     */ 
/*     */           
/* 160 */           getClassClassLoader(originalType).getResource("javax/xml/bind/JAXBContext.class"), targetTypeURL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JAXBContext newInstance(String contextPath, Class[] contextPathClasses, String className, ClassLoader classLoader, Map properties) throws JAXBException {
/*     */     try {
/* 174 */       Class spFactory = ServiceLoaderUtil.safeLoadClass(className, "com.sun.xml.internal.bind.v2.ContextFactory", classLoader);
/* 175 */       return newInstance(contextPath, contextPathClasses, spFactory, classLoader, properties);
/* 176 */     } catch (ClassNotFoundException x) {
/* 177 */       throw new JAXBException(Messages.format("ContextFinder.DefaultProviderNotFound"), x);
/*     */     }
/* 179 */     catch (RuntimeException|JAXBException x) {
/*     */ 
/*     */ 
/*     */       
/* 183 */       throw x;
/* 184 */     } catch (Exception x) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       throw new JAXBException(Messages.format("ContextFinder.CouldNotInstantiate", className, x), x);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JAXBContext newInstance(String contextPath, Class[] contextPathClasses, Class<?> spFactory, ClassLoader classLoader, Map properties) throws JAXBException {
/*     */     try {
/* 201 */       ModuleUtil.delegateAddOpensToImplModule(contextPathClasses, spFactory);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 209 */       Object context = null;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 214 */         Method m = spFactory.getMethod("createContext", new Class[] { String.class, ClassLoader.class, Map.class });
/*     */         
/* 216 */         Object obj = instantiateProviderIfNecessary(spFactory);
/* 217 */         context = m.invoke(obj, new Object[] { contextPath, classLoader, properties });
/* 218 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */ 
/*     */       
/* 222 */       if (context == null) {
/*     */ 
/*     */         
/* 225 */         Method m = spFactory.getMethod("createContext", new Class[] { String.class, ClassLoader.class });
/* 226 */         Object obj = instantiateProviderIfNecessary(spFactory);
/*     */         
/* 228 */         context = m.invoke(obj, new Object[] { contextPath, classLoader });
/*     */       } 
/*     */       
/* 231 */       if (!(context instanceof JAXBContext))
/*     */       {
/* 233 */         throw handleClassCastException(context.getClass(), JAXBContext.class);
/*     */       }
/*     */       
/* 236 */       return (JAXBContext)context;
/* 237 */     } catch (InvocationTargetException x) {
/*     */ 
/*     */       
/* 240 */       Throwable e = handleInvocationTargetException(x);
/* 241 */       throw new JAXBException(Messages.format("ContextFinder.CouldNotInstantiate", spFactory, e), e);
/*     */     }
/* 243 */     catch (Exception x) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       throw new JAXBException(Messages.format("ContextFinder.CouldNotInstantiate", spFactory, x), x);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object instantiateProviderIfNecessary(final Class<?> implClass) throws JAXBException {
/*     */     try {
/* 254 */       if (JAXBContextFactory.class.isAssignableFrom(implClass)) {
/* 255 */         return AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */             {
/*     */               public Object run() throws Exception {
/* 258 */                 return implClass.newInstance();
/*     */               }
/*     */             });
/*     */       }
/* 262 */       return null;
/* 263 */     } catch (PrivilegedActionException x) {
/* 264 */       Throwable e = (x.getCause() == null) ? x : x.getCause();
/* 265 */       throw new JAXBException(Messages.format("ContextFinder.CouldNotInstantiate", implClass, e), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JAXBContext newInstance(Class[] classes, Map properties, String className) throws JAXBException {
/*     */     Class spi;
/*     */     try {
/* 276 */       spi = ServiceLoaderUtil.safeLoadClass(className, "com.sun.xml.internal.bind.v2.ContextFactory", getContextClassLoader());
/* 277 */     } catch (ClassNotFoundException e) {
/* 278 */       throw new JAXBException(Messages.format("ContextFinder.DefaultProviderNotFound"), e);
/*     */     } 
/*     */     
/* 281 */     if (logger.isLoggable(Level.FINE))
/*     */     {
/* 283 */       logger.log(Level.FINE, "loaded {0} from {1}", new Object[] { className, which(spi) });
/*     */     }
/*     */     
/* 286 */     return newInstance(classes, properties, spi);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static JAXBContext newInstance(Class[] classes, Map properties, Class<?> spFactory) throws JAXBException {
/*     */     try {
/* 293 */       ModuleUtil.delegateAddOpensToImplModule(classes, spFactory);
/*     */       
/* 295 */       Method m = spFactory.getMethod("createContext", new Class[] { Class[].class, Map.class });
/* 296 */       Object obj = instantiateProviderIfNecessary(spFactory);
/* 297 */       Object context = m.invoke(obj, new Object[] { classes, properties });
/* 298 */       if (!(context instanceof JAXBContext))
/*     */       {
/* 300 */         throw handleClassCastException(context.getClass(), JAXBContext.class);
/*     */       }
/* 302 */       return (JAXBContext)context;
/*     */     }
/* 304 */     catch (NoSuchMethodException|IllegalAccessException e) {
/* 305 */       throw new JAXBException(e);
/* 306 */     } catch (InvocationTargetException e) {
/*     */ 
/*     */       
/* 309 */       Throwable x = handleInvocationTargetException(e);
/*     */       
/* 311 */       throw new JAXBException(x);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JAXBContext find(String factoryId, String contextPath, ClassLoader classLoader, Map<String, ?> properties) throws JAXBException {
/* 320 */     if (contextPath == null || contextPath.isEmpty())
/*     */     {
/* 322 */       throw new JAXBException(Messages.format("ContextFinder.NoPackageInContextPath"));
/*     */     }
/*     */ 
/*     */     
/* 326 */     Class[] contextPathClasses = ModuleUtil.getClassesFromContextPath(contextPath, classLoader);
/*     */ 
/*     */     
/* 329 */     String factoryClassName = jaxbProperties(contextPath, classLoader, factoryId);
/* 330 */     if (factoryClassName == null && contextPathClasses != null)
/*     */     {
/* 332 */       factoryClassName = jaxbProperties(contextPathClasses, factoryId);
/*     */     }
/*     */     
/* 335 */     if (factoryClassName != null) {
/* 336 */       return newInstance(contextPath, contextPathClasses, factoryClassName, classLoader, properties);
/*     */     }
/*     */ 
/*     */     
/* 340 */     String factoryName = classNameFromSystemProperties();
/* 341 */     if (factoryName != null) return newInstance(contextPath, contextPathClasses, factoryName, classLoader, properties);
/*     */     
/* 343 */     JAXBContextFactory obj = ServiceLoaderUtil.<JAXBContextFactory, JAXBException>firstByServiceLoader(JAXBContextFactory.class, logger, EXCEPTION_HANDLER);
/*     */ 
/*     */     
/* 346 */     if (obj != null) {
/* 347 */       ModuleUtil.delegateAddOpensToImplModule(contextPathClasses, obj.getClass());
/* 348 */       return obj.createContext(contextPath, classLoader, properties);
/*     */     } 
/*     */ 
/*     */     
/* 352 */     factoryName = firstByServiceLoaderDeprecated(JAXBContext.class, classLoader);
/* 353 */     if (factoryName != null) return newInstance(contextPath, contextPathClasses, factoryName, classLoader, properties);
/*     */     
/* 355 */     Class ctxFactory = (Class)ServiceLoaderUtil.lookupUsingOSGiServiceLoader("javax.xml.bind.JAXBContext", logger);
/*     */ 
/*     */     
/* 358 */     if (ctxFactory != null) {
/* 359 */       return newInstance(contextPath, contextPathClasses, ctxFactory, classLoader, properties);
/*     */     }
/*     */ 
/*     */     
/* 363 */     logger.fine("Trying to create the platform default provider");
/* 364 */     return newInstance(contextPath, contextPathClasses, "com.sun.xml.internal.bind.v2.ContextFactory", classLoader, properties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static JAXBContext find(Class<?>[] classes, Map<String, ?> properties) throws JAXBException {
/* 370 */     logger.fine("Searching jaxb.properties");
/* 371 */     for (Class<?> c : classes) {
/*     */ 
/*     */ 
/*     */       
/* 375 */       if (c.getPackage() != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 382 */         URL jaxbPropertiesUrl = getResourceUrl(c, "jaxb.properties");
/*     */         
/* 384 */         if (jaxbPropertiesUrl != null) {
/*     */ 
/*     */           
/* 387 */           String str = classNameFromPackageProperties(jaxbPropertiesUrl, new String[] { "javax.xml.bind.JAXBContextFactory", "javax.xml.bind.context.factory" });
/*     */ 
/*     */ 
/*     */           
/* 391 */           return newInstance(classes, properties, str);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 396 */     String factoryClassName = classNameFromSystemProperties();
/* 397 */     if (factoryClassName != null) return newInstance(classes, properties, factoryClassName);
/*     */ 
/*     */     
/* 400 */     JAXBContextFactory factory = ServiceLoaderUtil.<JAXBContextFactory, JAXBException>firstByServiceLoader(JAXBContextFactory.class, logger, EXCEPTION_HANDLER);
/*     */     
/* 402 */     if (factory != null) {
/* 403 */       ModuleUtil.delegateAddOpensToImplModule(classes, factory.getClass());
/* 404 */       return factory.createContext(classes, properties);
/*     */     } 
/*     */ 
/*     */     
/* 408 */     String className = firstByServiceLoaderDeprecated(JAXBContext.class, getContextClassLoader());
/* 409 */     if (className != null) return newInstance(classes, properties, className);
/*     */     
/* 411 */     logger.fine("Trying to create the platform default provider");
/*     */     
/* 413 */     Class ctxFactoryClass = (Class)ServiceLoaderUtil.lookupUsingOSGiServiceLoader("javax.xml.bind.JAXBContext", logger);
/*     */     
/* 415 */     if (ctxFactoryClass != null) {
/* 416 */       return newInstance(classes, properties, ctxFactoryClass);
/*     */     }
/*     */ 
/*     */     
/* 420 */     logger.fine("Trying to create the platform default provider");
/* 421 */     return newInstance(classes, properties, "com.sun.xml.internal.bind.v2.ContextFactory");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String classNameFromPackageProperties(URL packagePropertiesUrl, String... factoryIds) throws JAXBException {
/* 432 */     logger.log(Level.FINE, "Trying to locate {0}", packagePropertiesUrl.toString());
/* 433 */     Properties props = loadJAXBProperties(packagePropertiesUrl);
/* 434 */     for (String factoryId : factoryIds) {
/* 435 */       if (props.containsKey(factoryId)) {
/* 436 */         return props.getProperty(factoryId);
/*     */       }
/*     */     } 
/*     */     
/* 440 */     String propertiesUrl = packagePropertiesUrl.toExternalForm();
/* 441 */     String packageName = propertiesUrl.substring(0, propertiesUrl.indexOf("/jaxb.properties"));
/* 442 */     throw new JAXBException(Messages.format("ContextFinder.MissingProperty", packageName, factoryIds[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   private static String classNameFromSystemProperties() throws JAXBException {
/* 447 */     String factoryClassName = getSystemProperty("javax.xml.bind.JAXBContextFactory");
/* 448 */     if (factoryClassName != null) {
/* 449 */       return factoryClassName;
/*     */     }
/*     */     
/* 452 */     factoryClassName = getDeprecatedSystemProperty("javax.xml.bind.context.factory");
/* 453 */     if (factoryClassName != null) {
/* 454 */       return factoryClassName;
/*     */     }
/*     */     
/* 457 */     factoryClassName = getDeprecatedSystemProperty(JAXBContext.class.getName());
/* 458 */     if (factoryClassName != null) {
/* 459 */       return factoryClassName;
/*     */     }
/* 461 */     return null;
/*     */   }
/*     */   
/*     */   private static String getDeprecatedSystemProperty(String property) {
/* 465 */     String value = getSystemProperty(property);
/* 466 */     if (value != null) {
/* 467 */       logger.log(Level.WARNING, "Using non-standard property: {0}. Property {1} should be used instead.", new Object[] { property, "javax.xml.bind.JAXBContextFactory" });
/*     */     }
/*     */     
/* 470 */     return value;
/*     */   }
/*     */   
/*     */   private static String getSystemProperty(String property) {
/* 474 */     logger.log(Level.FINE, "Checking system property {0}", property);
/* 475 */     String value = AccessController.<String>doPrivileged(new GetPropertyAction(property));
/* 476 */     if (value != null) {
/* 477 */       logger.log(Level.FINE, "  found {0}", value);
/*     */     } else {
/* 479 */       logger.log(Level.FINE, "  not found");
/*     */     } 
/* 481 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Properties loadJAXBProperties(URL url) throws JAXBException {
/*     */     try {
/* 488 */       logger.log(Level.FINE, "loading props from {0}", url);
/* 489 */       Properties props = new Properties();
/* 490 */       InputStream is = url.openStream();
/* 491 */       props.load(is);
/* 492 */       is.close();
/* 493 */       return props;
/* 494 */     } catch (IOException ioe) {
/* 495 */       logger.log(Level.FINE, "Unable to load " + url.toString(), ioe);
/* 496 */       throw new JAXBException(ioe.toString(), ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URL getResourceUrl(ClassLoader classLoader, String resourceName) {
/*     */     URL url;
/* 509 */     if (classLoader == null) {
/* 510 */       url = ClassLoader.getSystemResource(resourceName);
/*     */     } else {
/* 512 */       url = classLoader.getResource(resourceName);
/* 513 */     }  return url;
/*     */   }
/*     */   
/*     */   private static URL getResourceUrl(Class<?> clazz, String resourceName) {
/* 517 */     return clazz.getResource(resourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static URL which(Class clazz, ClassLoader loader) {
/* 535 */     String classnameAsResource = clazz.getName().replace('.', '/') + ".class";
/*     */     
/* 537 */     if (loader == null) {
/* 538 */       loader = getSystemClassLoader();
/*     */     }
/*     */     
/* 541 */     return loader.getResource(classnameAsResource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static URL which(Class clazz) {
/* 557 */     return which(clazz, getClassClassLoader(clazz));
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClassLoader getContextClassLoader() {
/* 562 */     if (System.getSecurityManager() == null) {
/* 563 */       return Thread.currentThread().getContextClassLoader();
/*     */     }
/* 565 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*     */         {
/*     */           public Object run()
/*     */           {
/* 569 */             return Thread.currentThread().getContextClassLoader();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ClassLoader getClassClassLoader(final Class c) {
/* 577 */     if (System.getSecurityManager() == null) {
/* 578 */       return c.getClassLoader();
/*     */     }
/* 580 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*     */         {
/*     */           public Object run()
/*     */           {
/* 584 */             return c.getClassLoader();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private static ClassLoader getSystemClassLoader() {
/* 591 */     if (System.getSecurityManager() == null) {
/* 592 */       return ClassLoader.getSystemClassLoader();
/*     */     }
/* 594 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*     */         {
/*     */           public Object run()
/*     */           {
/* 598 */             return ClassLoader.getSystemClassLoader();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static String firstByServiceLoaderDeprecated(Class spiClass, ClassLoader classLoader) throws JAXBException {
/* 609 */     String jaxbContextFQCN = spiClass.getName();
/*     */     
/* 611 */     logger.fine("Searching META-INF/services");
/*     */ 
/*     */     
/* 614 */     BufferedReader r = null;
/* 615 */     String resource = "META-INF/services/" + jaxbContextFQCN;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 620 */       InputStream resourceStream = (classLoader == null) ? ClassLoader.getSystemResourceAsStream(resource) : classLoader.getResourceAsStream(resource);
/*     */       
/* 622 */       if (resourceStream != null) {
/* 623 */         r = new BufferedReader(new InputStreamReader(resourceStream, "UTF-8"));
/* 624 */         String factoryClassName = r.readLine();
/* 625 */         if (factoryClassName != null) {
/* 626 */           factoryClassName = factoryClassName.trim();
/*     */         }
/* 628 */         r.close();
/* 629 */         logger.log(Level.FINE, "Configured factorty class:{0}", factoryClassName);
/* 630 */         return factoryClassName;
/*     */       } 
/* 632 */       logger.log(Level.FINE, "Unable to load:{0}", resource);
/* 633 */       return null;
/*     */     }
/* 635 */     catch (IOException e) {
/* 636 */       throw new JAXBException(e);
/*     */     } finally {
/*     */       try {
/* 639 */         if (r != null) {
/* 640 */           r.close();
/*     */         }
/* 642 */       } catch (IOException ex) {
/* 643 */         logger.log(Level.SEVERE, "Unable to close resource: " + resource, ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String jaxbProperties(String contextPath, ClassLoader classLoader, String factoryId) throws JAXBException {
/* 649 */     String[] packages = contextPath.split(":");
/*     */     
/* 651 */     for (String pkg : packages) {
/* 652 */       String pkgUrl = pkg.replace('.', '/');
/* 653 */       URL jaxbPropertiesUrl = getResourceUrl(classLoader, pkgUrl + "/jaxb.properties");
/* 654 */       if (jaxbPropertiesUrl != null) {
/* 655 */         return classNameFromPackageProperties(jaxbPropertiesUrl, new String[] { factoryId, "javax.xml.bind.context.factory" });
/*     */       }
/*     */     } 
/*     */     
/* 659 */     return null;
/*     */   }
/*     */   
/*     */   private static String jaxbProperties(Class[] classesFromContextPath, String factoryId) throws JAXBException {
/* 663 */     for (Class<?> c : classesFromContextPath) {
/* 664 */       URL jaxbPropertiesUrl = getResourceUrl(c, "jaxb.properties");
/* 665 */       if (jaxbPropertiesUrl != null) {
/* 666 */         return classNameFromPackageProperties(jaxbPropertiesUrl, new String[] { factoryId, "javax.xml.bind.context.factory" });
/*     */       }
/*     */     } 
/* 669 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\ContextFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */