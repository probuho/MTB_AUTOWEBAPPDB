package javax.xml.bind;

public interface ParseConversionEvent extends ValidationEvent {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\ParseConversionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */