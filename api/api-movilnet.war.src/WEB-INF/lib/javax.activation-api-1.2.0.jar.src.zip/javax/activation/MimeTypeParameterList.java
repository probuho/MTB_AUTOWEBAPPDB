/*     */ package javax.activation;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeTypeParameterList
/*     */ {
/*     */   private Hashtable parameters;
/*     */   private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";
/*     */   
/*     */   public MimeTypeParameterList() {
/*  67 */     this.parameters = new Hashtable<Object, Object>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeParameterList(String parameterList) throws MimeTypeParseException {
/*  78 */     this.parameters = new Hashtable<Object, Object>();
/*     */ 
/*     */     
/*  81 */     parse(parameterList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parse(String parameterList) throws MimeTypeParseException {
/*  91 */     if (parameterList == null) {
/*     */       return;
/*     */     }
/*  94 */     int length = parameterList.length();
/*  95 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 100 */     int i = skipWhiteSpace(parameterList, 0); char c;
/* 101 */     for (; i < length && (c = parameterList.charAt(i)) == ';'; 
/* 102 */       i = skipWhiteSpace(parameterList, i)) {
/*     */       String value;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 108 */       i++;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       i = skipWhiteSpace(parameterList, i);
/*     */ 
/*     */       
/* 116 */       if (i >= length) {
/*     */         return;
/*     */       }
/*     */       
/* 120 */       int lastIndex = i;
/* 121 */       while (i < length && isTokenChar(parameterList.charAt(i))) {
/* 122 */         i++;
/*     */       }
/*     */       
/* 125 */       String name = parameterList.substring(lastIndex, i).toLowerCase(Locale.ENGLISH);
/*     */ 
/*     */       
/* 128 */       i = skipWhiteSpace(parameterList, i);
/*     */       
/* 130 */       if (i >= length || parameterList.charAt(i) != '=') {
/* 131 */         throw new MimeTypeParseException("Couldn't find the '=' that separates a parameter name from its value.");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 136 */       i++;
/* 137 */       i = skipWhiteSpace(parameterList, i);
/*     */       
/* 139 */       if (i >= length) {
/* 140 */         throw new MimeTypeParseException("Couldn't find a value for parameter named " + name);
/*     */       }
/*     */ 
/*     */       
/* 144 */       c = parameterList.charAt(i);
/* 145 */       if (c == '"') {
/*     */         
/* 147 */         i++;
/* 148 */         if (i >= length) {
/* 149 */           throw new MimeTypeParseException("Encountered unterminated quoted parameter value.");
/*     */         }
/*     */         
/* 152 */         lastIndex = i;
/*     */ 
/*     */         
/* 155 */         while (i < length) {
/* 156 */           c = parameterList.charAt(i);
/* 157 */           if (c == '"')
/*     */             break; 
/* 159 */           if (c == '\\')
/*     */           {
/*     */ 
/*     */             
/* 163 */             i++;
/*     */           }
/* 165 */           i++;
/*     */         } 
/* 167 */         if (c != '"') {
/* 168 */           throw new MimeTypeParseException("Encountered unterminated quoted parameter value.");
/*     */         }
/*     */         
/* 171 */         value = unquote(parameterList.substring(lastIndex, i));
/*     */         
/* 173 */         i++;
/* 174 */       } else if (isTokenChar(c)) {
/*     */ 
/*     */         
/* 177 */         lastIndex = i;
/* 178 */         while (i < length && isTokenChar(parameterList.charAt(i)))
/* 179 */           i++; 
/* 180 */         value = parameterList.substring(lastIndex, i);
/*     */       } else {
/*     */         
/* 183 */         throw new MimeTypeParseException("Unexpected character encountered at index " + i);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 188 */       this.parameters.put(name, value);
/*     */     } 
/* 190 */     if (i < length) {
/* 191 */       throw new MimeTypeParseException("More characters encountered in input than expected.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 202 */     return this.parameters.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 211 */     return this.parameters.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(String name) {
/* 222 */     return (String)this.parameters.get(name.trim().toLowerCase(Locale.ENGLISH));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(String name, String value) {
/* 233 */     this.parameters.put(name.trim().toLowerCase(Locale.ENGLISH), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String name) {
/* 242 */     this.parameters.remove(name.trim().toLowerCase(Locale.ENGLISH));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration getNames() {
/* 251 */     return this.parameters.keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 258 */     StringBuffer buffer = new StringBuffer();
/* 259 */     buffer.ensureCapacity(this.parameters.size() * 16);
/*     */ 
/*     */     
/* 262 */     Enumeration<String> keys = this.parameters.keys();
/* 263 */     while (keys.hasMoreElements()) {
/* 264 */       String key = keys.nextElement();
/* 265 */       buffer.append("; ");
/* 266 */       buffer.append(key);
/* 267 */       buffer.append('=');
/* 268 */       buffer.append(quote((String)this.parameters.get(key)));
/*     */     } 
/*     */     
/* 271 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isTokenChar(char c) {
/* 280 */     return (c > ' ' && c < '' && "()<>@,;:/[]?=\\\"".indexOf(c) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int skipWhiteSpace(String rawdata, int i) {
/* 288 */     int length = rawdata.length();
/* 289 */     while (i < length && Character.isWhitespace(rawdata.charAt(i)))
/* 290 */       i++; 
/* 291 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String quote(String value) {
/* 298 */     boolean needsQuotes = false;
/*     */ 
/*     */     
/* 301 */     int length = value.length();
/* 302 */     for (int i = 0; i < length && !needsQuotes; i++) {
/* 303 */       needsQuotes = !isTokenChar(value.charAt(i));
/*     */     }
/*     */     
/* 306 */     if (needsQuotes) {
/* 307 */       StringBuffer buffer = new StringBuffer();
/* 308 */       buffer.ensureCapacity((int)(length * 1.5D));
/*     */ 
/*     */       
/* 311 */       buffer.append('"');
/*     */ 
/*     */       
/* 314 */       for (int j = 0; j < length; j++) {
/* 315 */         char c = value.charAt(j);
/* 316 */         if (c == '\\' || c == '"')
/* 317 */           buffer.append('\\'); 
/* 318 */         buffer.append(c);
/*     */       } 
/*     */ 
/*     */       
/* 322 */       buffer.append('"');
/*     */       
/* 324 */       return buffer.toString();
/*     */     } 
/* 326 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String unquote(String value) {
/* 335 */     int valueLength = value.length();
/* 336 */     StringBuffer buffer = new StringBuffer();
/* 337 */     buffer.ensureCapacity(valueLength);
/*     */     
/* 339 */     boolean escaped = false;
/* 340 */     for (int i = 0; i < valueLength; i++) {
/* 341 */       char currentChar = value.charAt(i);
/* 342 */       if (!escaped && currentChar != '\\') {
/* 343 */         buffer.append(currentChar);
/* 344 */       } else if (escaped) {
/* 345 */         buffer.append(currentChar);
/* 346 */         escaped = false;
/*     */       } else {
/* 348 */         escaped = true;
/*     */       } 
/*     */     } 
/*     */     
/* 352 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\MimeTypeParameterList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */