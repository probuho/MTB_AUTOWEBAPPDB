package javax.activation;

public interface DataContentHandlerFactory {
  DataContentHandler createDataContentHandler(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\DataContentHandlerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */