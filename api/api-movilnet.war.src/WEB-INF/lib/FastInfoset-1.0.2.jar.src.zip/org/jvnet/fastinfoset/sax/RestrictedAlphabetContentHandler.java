package org.jvnet.fastinfoset.sax;

import org.xml.sax.SAXException;

public interface RestrictedAlphabetContentHandler {
  void numericCharacters(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SAXException;
  
  void dateTimeCharacters(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SAXException;
  
  void alphabetCharacters(String paramString, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SAXException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\sax\RestrictedAlphabetContentHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */