package org.jvnet.fastinfoset;

public final class RestrictedAlphabet {
  public static final String NUMERIC_CHARACTERS = "0123456789-+.E ";
  
  public static final int NUMERIC_CHARACTERS_INDEX = 0;
  
  public static final String DATE_TIME_CHARACTERS = "0123456789-:TZ ";
  
  public static final int DATE_TIME_CHARACTERS_INDEX = 1;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\RestrictedAlphabet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */