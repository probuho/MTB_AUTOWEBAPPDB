package org.jvnet.fastinfoset;

import java.util.Map;

public interface FastInfosetParser {
  public static final String STRING_INTERNING_PROPERTY = "http://jvnet.org/fastinfoset/parser/properties/string-interning";
  
  public static final String BUFFER_SIZE_PROPERTY = "http://jvnet.org/fastinfoset/parser/properties/buffer-size";
  
  public static final String REGISTERED_ENCODING_ALGORITHMS_PROPERTY = "http://jvnet.org/fastinfoset/parser/properties/registered-encoding-algorithms";
  
  public static final String EXTERNAL_VOCABULARIES_PROPERTY = "http://jvnet.org/fastinfoset/parser/properties/external-vocabularies";
  
  void setStringInterning(boolean paramBoolean);
  
  boolean getStringInterning();
  
  void setBufferSize(int paramInt);
  
  int getBufferSize();
  
  void setRegisteredEncodingAlgorithms(Map paramMap);
  
  Map getRegisteredEncodingAlgorithms();
  
  void setExternalVocabularies(Map paramMap);
  
  Map getExternalVocabularies();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\FastInfosetParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */