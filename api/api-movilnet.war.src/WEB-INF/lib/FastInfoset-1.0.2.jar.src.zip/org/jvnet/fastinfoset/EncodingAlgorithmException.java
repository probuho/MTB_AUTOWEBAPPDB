/*    */ package org.jvnet.fastinfoset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EncodingAlgorithmException
/*    */   extends FastInfosetException
/*    */ {
/*    */   public EncodingAlgorithmException(String message) {
/* 45 */     super(message);
/*    */   }
/*    */   
/*    */   public EncodingAlgorithmException(String message, Exception e) {
/* 49 */     super(message, e);
/*    */   }
/*    */   
/*    */   public EncodingAlgorithmException(Exception e) {
/* 53 */     super(e);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\EncodingAlgorithmException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */