/*    */ package org.jvnet.fastinfoset;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.sax.SAXDocumentParser;
/*    */ import java.io.InputStream;
/*    */ import javax.xml.transform.sax.SAXSource;
/*    */ import org.xml.sax.InputSource;
/*    */ import org.xml.sax.XMLReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastInfosetSource
/*    */   extends SAXSource
/*    */ {
/*    */   public FastInfosetSource(InputStream inputStream) {
/* 79 */     super(new InputSource(inputStream));
/*    */   }
/*    */   public XMLReader getXMLReader() {
/*    */     SAXDocumentParser sAXDocumentParser;
/* 83 */     XMLReader reader = super.getXMLReader();
/* 84 */     if (reader == null) {
/* 85 */       sAXDocumentParser = new SAXDocumentParser();
/* 86 */       setXMLReader((XMLReader)sAXDocumentParser);
/*    */     } 
/* 88 */     sAXDocumentParser.setInputStream(getInputStream());
/* 89 */     return (XMLReader)sAXDocumentParser;
/*    */   }
/*    */   
/*    */   public InputStream getInputStream() {
/* 93 */     return getInputSource().getByteStream();
/*    */   }
/*    */   
/*    */   public void setInputStream(InputStream inputStream) {
/* 97 */     setInputSource(new InputSource(inputStream));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\FastInfosetSource.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */