package org.jvnet.fastinfoset;

public final class EncodingAlgorithmIndexes {
  public static final int HEXADECIMAL = 0;
  
  public static final int BASE64 = 1;
  
  public static final int SHORT = 2;
  
  public static final int INT = 3;
  
  public static final int LONG = 4;
  
  public static final int BOOLEAN = 5;
  
  public static final int FLOAT = 6;
  
  public static final int DOUBLE = 7;
  
  public static final int UUID = 8;
  
  public static final int CDATA = 9;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\EncodingAlgorithmIndexes.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */