package org.jvnet.fastinfoset;

import java.util.List;

public interface Vocabulary {
  public static final int RESTRICTED_ALPHABET = 0;
  
  public static final int ENCODING_ALGORITHM = 1;
  
  public static final int PREFIX = 2;
  
  public static final int NAMESPACE_NAME = 3;
  
  public static final int LOCAL_NAME = 4;
  
  public static final int OTHER_NCNAME = 5;
  
  public static final int OTHER_URI = 6;
  
  public static final int ATTRIBUTE_VALUE = 7;
  
  public static final int OTHER_STRING = 8;
  
  public static final int CHARACTER_CONTENT_CHUNK = 9;
  
  public static final int ELEMENT_NAME = 10;
  
  public static final int ATTRIBUTE_NAME = 11;
  
  void setTableFromArray(int paramInt, Object paramObject);
  
  void setTableFromList(int paramInt, List paramList);
  
  Object getTableAsArray(int paramInt);
  
  List getTableAsList(int paramInt);
  
  void clear();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\Vocabulary.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */