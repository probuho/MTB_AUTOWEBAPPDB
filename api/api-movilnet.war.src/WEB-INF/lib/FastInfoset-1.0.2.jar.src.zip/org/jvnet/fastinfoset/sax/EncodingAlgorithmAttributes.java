package org.jvnet.fastinfoset.sax;

import org.xml.sax.Attributes;

public interface EncodingAlgorithmAttributes extends Attributes {
  String getAlgorithmURI(int paramInt);
  
  int getAlgorithmIndex(int paramInt);
  
  Object getAlgorithmData(int paramInt);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\sax\EncodingAlgorithmAttributes.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */