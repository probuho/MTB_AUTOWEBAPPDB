/*    */ package org.jvnet.fastinfoset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastInfosetException
/*    */   extends Exception
/*    */ {
/*    */   public FastInfosetException(String message) {
/* 45 */     super(message);
/*    */   }
/*    */   
/*    */   public FastInfosetException(String message, Exception e) {
/* 49 */     super(message, e);
/*    */   }
/*    */   
/*    */   public FastInfosetException(Exception e) {
/* 53 */     super(e);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\FastInfosetException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */