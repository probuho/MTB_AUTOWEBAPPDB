/*    */ package org.jvnet.fastinfoset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReferencedVocabulary
/*    */ {
/*    */   private final String URI;
/*    */   private final Vocabulary vocabulary;
/*    */   
/*    */   public ReferencedVocabulary(String URI, Vocabulary vocabulary) {
/* 47 */     this.URI = URI;
/* 48 */     this.vocabulary = vocabulary;
/*    */   }
/*    */   
/*    */   public String getURI() {
/* 52 */     return this.URI;
/*    */   }
/*    */   
/*    */   public Vocabulary getVocabulary() {
/* 56 */     return this.vocabulary;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\ReferencedVocabulary.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */