package org.jvnet.fastinfoset;

import java.util.Map;

public interface FastInfosetSerializer {
  public static final int CHARACTER_CONTENT_CHUNK_SIZE_CONSTRAINT = 7;
  
  public static final int ATTRIBUTE_VALUE_SIZE_CONSTRAINT = 7;
  
  public static final String UTF_8 = "UTF-8";
  
  public static final String UTF_16BE = "UTF-16BE";
  
  void setCharacterEncodingScheme(String paramString);
  
  String getCharacterEncodingScheme();
  
  void setRegisteredEncodingAlgorithms(Map paramMap);
  
  Map getRegisteredEncodingAlgorithms();
  
  void setCharacterContentChunkSizeLimit(int paramInt);
  
  int getCharacterContentChunkSizeLimit();
  
  void setAttributeValueSizeLimit(int paramInt);
  
  int getAttributeValueSizeLimit();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\FastInfosetSerializer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */