package org.jvnet.fastinfoset;

import java.io.OutputStream;

public abstract class AccessibleByteBufferOutputStream extends OutputStream {
  public abstract byte[] getBuffer();
  
  public abstract byte[] getBuffer(int paramInt);
  
  public abstract void commitBytes(int paramInt);
  
  public abstract int getStart();
  
  public abstract int getLength();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\AccessibleByteBufferOutputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */