/*    */ package org.jvnet.fastinfoset;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.sax.SAXDocumentSerializer;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.transform.sax.SAXResult;
/*    */ import org.xml.sax.ContentHandler;
/*    */ import org.xml.sax.ext.LexicalHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastInfosetResult
/*    */   extends SAXResult
/*    */ {
/*    */   OutputStream _outputStream;
/*    */   
/*    */   public FastInfosetResult(OutputStream outputStream) {
/* 73 */     this._outputStream = outputStream;
/*    */   }
/*    */   public ContentHandler getHandler() {
/*    */     SAXDocumentSerializer sAXDocumentSerializer;
/* 77 */     ContentHandler handler = super.getHandler();
/* 78 */     if (handler == null) {
/* 79 */       sAXDocumentSerializer = new SAXDocumentSerializer();
/* 80 */       setHandler((ContentHandler)sAXDocumentSerializer);
/*    */     } 
/* 82 */     sAXDocumentSerializer.setOutputStream(this._outputStream);
/* 83 */     return (ContentHandler)sAXDocumentSerializer;
/*    */   }
/*    */   
/*    */   public LexicalHandler getLexicalHandler() {
/* 87 */     return (LexicalHandler)getHandler();
/*    */   }
/*    */   
/*    */   public OutputStream getOutputStream() {
/* 91 */     return this._outputStream;
/*    */   }
/*    */   
/*    */   public void setOutputStream(OutputStream outputStream) {
/* 95 */     this._outputStream = outputStream;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\org\jvnet\fastinfoset\FastInfosetResult.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */