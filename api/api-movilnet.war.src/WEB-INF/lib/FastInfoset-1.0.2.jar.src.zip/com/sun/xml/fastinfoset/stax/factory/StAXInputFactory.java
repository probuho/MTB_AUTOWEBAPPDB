/*     */ package com.sun.xml.fastinfoset.stax.factory;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.stax.StAXDocumentParser;
/*     */ import com.sun.xml.fastinfoset.stax.StAXManager;
/*     */ import com.sun.xml.fastinfoset.stax.events.StAXEventReader;
/*     */ import com.sun.xml.fastinfoset.stax.events.StAXFilteredEvent;
/*     */ import com.sun.xml.fastinfoset.stax.util.StAXFilteredParser;
/*     */ import com.sun.xml.fastinfoset.tools.XML_SAX_FI;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import javax.xml.stream.EventFilter;
/*     */ import javax.xml.stream.StreamFilter;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLReporter;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ import javax.xml.transform.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXInputFactory
/*     */   extends XMLInputFactory
/*     */ {
/*  63 */   private StAXManager _manager = new StAXManager(1);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XMLInputFactory newInstance() {
/*  69 */     return XMLInputFactory.newInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(Reader xmlfile) throws XMLStreamException {
/*  78 */     return getXMLStreamReader(xmlfile);
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(InputStream s) throws XMLStreamException {
/*  82 */     return (XMLStreamReader)new StAXDocumentParser(s, this._manager);
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(String systemId, Reader xmlfile) throws XMLStreamException {
/*  86 */     return getXMLStreamReader(xmlfile);
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(Source source) throws XMLStreamException {
/*  90 */     return null;
/*     */   }
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(String systemId, InputStream inputstream) throws XMLStreamException {
/*  94 */     return createXMLStreamReader(inputstream);
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLStreamReader createXMLStreamReader(InputStream inputstream, String encoding) throws XMLStreamException {
/*  99 */     return createXMLStreamReader(inputstream);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XMLStreamReader getXMLStreamReader(String systemId, InputStream inputstream, String encoding) throws XMLStreamException {
/* 105 */     return createXMLStreamReader(inputstream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XMLStreamReader getXMLStreamReader(Reader xmlfile) throws XMLStreamException {
/* 117 */     ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
/* 118 */     BufferedOutputStream bufferedStream = new BufferedOutputStream(byteStream);
/* 119 */     StAXDocumentParser sr = null;
/*     */     try {
/* 121 */       XML_SAX_FI convertor = new XML_SAX_FI();
/* 122 */       convertor.convert(xmlfile, bufferedStream);
/*     */       
/* 124 */       ByteArrayInputStream byteInputStream = new ByteArrayInputStream(byteStream.toByteArray());
/* 125 */       InputStream document = new BufferedInputStream(byteInputStream);
/* 126 */       sr = new StAXDocumentParser();
/* 127 */       sr.setInputStream(document);
/* 128 */       sr.setManager(this._manager);
/* 129 */       return (XMLStreamReader)sr;
/*     */     }
/* 131 */     catch (Exception e) {
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEventReader createXMLEventReader(InputStream inputstream) throws XMLStreamException {
/* 144 */     return (XMLEventReader)new StAXEventReader(createXMLStreamReader(inputstream));
/*     */   }
/*     */   
/*     */   public XMLEventReader createXMLEventReader(Reader reader) throws XMLStreamException {
/* 148 */     return (XMLEventReader)new StAXEventReader(createXMLStreamReader(reader));
/*     */   }
/*     */   
/*     */   public XMLEventReader createXMLEventReader(Source source) throws XMLStreamException {
/* 152 */     return (XMLEventReader)new StAXEventReader(createXMLStreamReader(source));
/*     */   }
/*     */   
/*     */   public XMLEventReader createXMLEventReader(String systemId, InputStream inputstream) throws XMLStreamException {
/* 156 */     return (XMLEventReader)new StAXEventReader(createXMLStreamReader(systemId, inputstream));
/*     */   }
/*     */   
/*     */   public XMLEventReader createXMLEventReader(InputStream stream, String encoding) throws XMLStreamException {
/* 160 */     return (XMLEventReader)new StAXEventReader(createXMLStreamReader(stream, encoding));
/*     */   }
/*     */   
/*     */   public XMLEventReader createXMLEventReader(String systemId, Reader reader) throws XMLStreamException {
/* 164 */     return (XMLEventReader)new StAXEventReader(createXMLStreamReader(systemId, reader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEventReader createXMLEventReader(XMLStreamReader streamReader) throws XMLStreamException {
/* 175 */     return (XMLEventReader)new StAXEventReader(streamReader);
/*     */   }
/*     */   
/*     */   public XMLEventAllocator getEventAllocator() {
/* 179 */     return (XMLEventAllocator)getProperty("javax.xml.stream.allocator");
/*     */   }
/*     */   
/*     */   public XMLReporter getXMLReporter() {
/* 183 */     return (XMLReporter)this._manager.getProperty("javax.xml.stream.reporter");
/*     */   }
/*     */   
/*     */   public XMLResolver getXMLResolver() {
/* 187 */     Object object = this._manager.getProperty("javax.xml.stream.resolver");
/* 188 */     return (XMLResolver)object;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setXMLReporter(XMLReporter xmlreporter) {
/* 193 */     this._manager.setProperty("javax.xml.stream.reporter", xmlreporter);
/*     */   }
/*     */   
/*     */   public void setXMLResolver(XMLResolver xmlresolver) {
/* 197 */     this._manager.setProperty("javax.xml.stream.resolver", xmlresolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEventReader createFilteredReader(XMLEventReader reader, EventFilter filter) throws XMLStreamException {
/* 206 */     return (XMLEventReader)new StAXFilteredEvent(reader, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLStreamReader createFilteredReader(XMLStreamReader reader, StreamFilter filter) throws XMLStreamException {
/* 216 */     if (reader != null && filter != null) {
/* 217 */       return (XMLStreamReader)new StAXFilteredParser(reader, filter);
/*     */     }
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws IllegalArgumentException {
/* 230 */     if (name == null) {
/* 231 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.nullPropertyName"));
/*     */     }
/* 233 */     if (this._manager.containsProperty(name))
/* 234 */       return this._manager.getProperty(name); 
/* 235 */     throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.propertyNotSupported", new Object[] { name }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPropertySupported(String name) {
/* 244 */     if (name == null) {
/* 245 */       return false;
/*     */     }
/* 247 */     return this._manager.containsProperty(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEventAllocator(XMLEventAllocator allocator) {
/* 254 */     this._manager.setProperty("javax.xml.stream.allocator", allocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws IllegalArgumentException {
/* 265 */     this._manager.setProperty(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\factory\StAXInputFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */