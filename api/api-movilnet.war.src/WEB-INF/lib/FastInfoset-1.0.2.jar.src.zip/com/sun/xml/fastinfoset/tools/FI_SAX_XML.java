/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.transform.Source;
/*    */ import javax.xml.transform.Transformer;
/*    */ import javax.xml.transform.TransformerFactory;
/*    */ import javax.xml.transform.stream.StreamResult;
/*    */ import org.jvnet.fastinfoset.FastInfosetSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FI_SAX_XML
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream finf, OutputStream xml) throws Exception {
/* 55 */     Transformer tx = TransformerFactory.newInstance().newTransformer();
/* 56 */     tx.transform((Source)new FastInfosetSource(finf), new StreamResult(xml));
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 60 */     FI_SAX_XML p = new FI_SAX_XML();
/* 61 */     p.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\FI_SAX_XML.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */