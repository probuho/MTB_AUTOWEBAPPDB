/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import javax.xml.stream.EventFilter;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXFilteredEvent
/*     */   implements XMLEventReader
/*     */ {
/*     */   private XMLEventReader eventReader;
/*     */   private EventFilter _filter;
/*     */   
/*     */   public StAXFilteredEvent() {}
/*     */   
/*     */   public StAXFilteredEvent(XMLEventReader reader, EventFilter filter) throws XMLStreamException {
/*  26 */     this.eventReader = reader;
/*  27 */     this._filter = filter;
/*     */   }
/*     */   
/*     */   public void setEventReader(XMLEventReader reader) {
/*  31 */     this.eventReader = reader;
/*     */   }
/*     */   
/*     */   public void setFilter(EventFilter filter) {
/*  35 */     this._filter = filter;
/*     */   }
/*     */   
/*     */   public Object next() {
/*     */     try {
/*  40 */       return nextEvent();
/*  41 */     } catch (XMLStreamException e) {
/*  42 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent nextEvent() throws XMLStreamException {
/*  48 */     if (hasNext())
/*  49 */       return this.eventReader.nextEvent(); 
/*  50 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementText() throws XMLStreamException {
/*  55 */     StringBuffer buffer = new StringBuffer();
/*  56 */     XMLEvent e = nextEvent();
/*  57 */     if (!e.isStartElement()) {
/*  58 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.mustBeOnSTART_ELEMENT"));
/*     */     }
/*     */     
/*  61 */     while (hasNext()) {
/*  62 */       e = nextEvent();
/*  63 */       if (e.isStartElement()) {
/*  64 */         throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.getElementTextExpectTextOnly"));
/*     */       }
/*  66 */       if (e.isCharacters())
/*  67 */         buffer.append(((Characters)e).getData()); 
/*  68 */       if (e.isEndElement())
/*  69 */         return buffer.toString(); 
/*     */     } 
/*  71 */     throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.END_ELEMENTnotFound"));
/*     */   }
/*     */   
/*     */   public XMLEvent nextTag() throws XMLStreamException {
/*  75 */     while (hasNext()) {
/*  76 */       XMLEvent e = nextEvent();
/*  77 */       if (e.isStartElement() || e.isEndElement())
/*  78 */         return e; 
/*     */     } 
/*  80 */     throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.startOrEndNotFound"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*     */     try {
/*  87 */       while (this.eventReader.hasNext()) {
/*  88 */         if (this._filter.accept(this.eventReader.peek())) return true; 
/*  89 */         this.eventReader.nextEvent();
/*     */       } 
/*  91 */       return false;
/*  92 */     } catch (XMLStreamException e) {
/*  93 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void remove() {
/*  98 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent peek() throws XMLStreamException {
/* 103 */     if (hasNext())
/* 104 */       return this.eventReader.peek(); 
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws XMLStreamException {
/* 110 */     this.eventReader.close();
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) {
/* 114 */     return this.eventReader.getProperty(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\StAXFilteredEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */