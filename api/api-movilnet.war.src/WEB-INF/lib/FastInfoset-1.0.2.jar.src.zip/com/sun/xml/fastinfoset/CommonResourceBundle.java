/*     */ package com.sun.xml.fastinfoset;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonResourceBundle
/*     */   extends AbstractResourceBundle
/*     */ {
/*     */   public static final String BASE_NAME = "com.sun.xml.fastinfoset.resources.ResourceBundle";
/*  48 */   private static CommonResourceBundle instance = null;
/*  49 */   private static Locale locale = null;
/*  50 */   private ResourceBundle bundle = null;
/*     */ 
/*     */   
/*     */   protected CommonResourceBundle() {
/*  54 */     this.bundle = ResourceBundle.getBundle("com.sun.xml.fastinfoset.resources.ResourceBundle");
/*     */   }
/*     */ 
/*     */   
/*     */   protected CommonResourceBundle(Locale locale) {
/*  59 */     this.bundle = ResourceBundle.getBundle("com.sun.xml.fastinfoset.resources.ResourceBundle", locale);
/*     */   }
/*     */   
/*     */   public static CommonResourceBundle getInstance() {
/*  63 */     if (instance == null) {
/*  64 */       synchronized (CommonResourceBundle.class) {
/*  65 */         if (instance == null) {
/*  66 */           instance = new CommonResourceBundle();
/*     */ 
/*     */ 
/*     */           
/*  70 */           String localeString = null;
/*  71 */           locale = parseLocale(localeString);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*  76 */     return instance;
/*     */   }
/*     */   
/*     */   public static CommonResourceBundle getInstance(Locale locale) {
/*  80 */     if (instance == null) {
/*  81 */       synchronized (CommonResourceBundle.class) {
/*  82 */         if (instance == null) {
/*  83 */           instance = new CommonResourceBundle(locale);
/*     */         }
/*     */       } 
/*     */     } else {
/*  87 */       synchronized (CommonResourceBundle.class) {
/*  88 */         if (CommonResourceBundle.locale != locale) {
/*  89 */           instance = new CommonResourceBundle(locale);
/*     */         }
/*     */       } 
/*     */     } 
/*  93 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceBundle getBundle() {
/*  98 */     return this.bundle;
/*     */   }
/*     */   public ResourceBundle getBundle(Locale locale) {
/* 101 */     return ResourceBundle.getBundle("com.sun.xml.fastinfoset.resources.ResourceBundle", locale);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\CommonResourceBundle.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */