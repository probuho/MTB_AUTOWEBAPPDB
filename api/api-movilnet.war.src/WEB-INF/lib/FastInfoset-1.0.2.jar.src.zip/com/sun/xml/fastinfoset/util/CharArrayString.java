/*    */ package com.sun.xml.fastinfoset.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharArrayString
/*    */   extends CharArray
/*    */ {
/*    */   protected String _s;
/*    */   
/*    */   public CharArrayString(String s) {
/* 46 */     this(s, true);
/*    */   }
/*    */   
/*    */   public CharArrayString(String s, boolean createArray) {
/* 50 */     this._s = s;
/* 51 */     if (createArray) {
/* 52 */       this.ch = this._s.toCharArray();
/* 53 */       this.start = 0;
/* 54 */       this.length = this.ch.length;
/*    */     } 
/*    */   }
/*    */   
/*    */   public String toString() {
/* 59 */     return this._s;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 63 */     return this._s.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 67 */     if (this == obj) {
/* 68 */       return true;
/*    */     }
/* 70 */     if (obj instanceof CharArrayString) {
/* 71 */       CharArrayString chas = (CharArrayString)obj;
/* 72 */       return this._s.equals(chas._s);
/* 73 */     }  if (obj instanceof CharArray) {
/* 74 */       CharArray cha = (CharArray)obj;
/* 75 */       if (this.length == cha.length) {
/* 76 */         int n = this.length;
/* 77 */         int i = this.start;
/* 78 */         int j = cha.start;
/* 79 */         while (n-- != 0) {
/* 80 */           if (this.ch[i++] != cha.ch[j++])
/* 81 */             return false; 
/*    */         } 
/* 83 */         return true;
/*    */       } 
/*    */     } 
/* 86 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\CharArrayString.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */