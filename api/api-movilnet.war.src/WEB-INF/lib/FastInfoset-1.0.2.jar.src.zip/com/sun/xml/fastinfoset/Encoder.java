/*      */ package com.sun.xml.fastinfoset;
/*      */ 
/*      */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithm;
/*      */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithmFactory;
/*      */ import com.sun.xml.fastinfoset.org.apache.xerces.util.XMLChar;
/*      */ import com.sun.xml.fastinfoset.util.CharArrayIntMap;
/*      */ import com.sun.xml.fastinfoset.util.LocalNameQualifiedNamesMap;
/*      */ import com.sun.xml.fastinfoset.util.StringIntMap;
/*      */ import com.sun.xml.fastinfoset.vocab.SerializerVocabulary;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import org.jvnet.fastinfoset.EncodingAlgorithm;
/*      */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*      */ import org.jvnet.fastinfoset.FastInfosetException;
/*      */ import org.jvnet.fastinfoset.FastInfosetSerializer;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Encoder
/*      */   extends DefaultHandler
/*      */   implements FastInfosetSerializer
/*      */ {
/*      */   public static final String CHARACTER_ENCODING_SCHEME_SYSTEM_PROPERTY = "com.sun.xml.fastinfoset.serializer.character-encoding-scheme";
/*   97 */   protected static String _characterEncodingSchemeSystemDefault = "UTF-8";
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  102 */     String p = System.getProperty("com.sun.xml.fastinfoset.serializer.character-encoding-scheme", _characterEncodingSchemeSystemDefault);
/*      */     
/*  104 */     if (p.equals("UTF-16BE")) {
/*  105 */       _characterEncodingSchemeSystemDefault = "UTF-16BE";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _encodingStringsAsUtf8 = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _nonIdentifyingStringOnThirdBitCES;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _nonIdentifyingStringOnFirstBitCES;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   private Map _registeredEncodingAlgorithms = new HashMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerVocabulary _v;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _vIsInternal;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _terminate = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _b;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OutputStream _s;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   protected char[] _charBuffer = new char[512];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  165 */   protected byte[] _octetBuffer = new byte[1024];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _octetBufferIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   protected int _markIndex = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  184 */   protected int attributeValueSizeConstraint = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  191 */   protected int characterContentChunkSizeContraint = 7;
/*      */ 
/*      */   
/*      */   private int _bitsLeftInOctet;
/*      */ 
/*      */   
/*      */   private EncodingBufferOutputStream _encodingBufferOutputStream;
/*      */ 
/*      */   
/*      */   private byte[] _encodingBuffer;
/*      */ 
/*      */   
/*      */   private int _encodingBufferIndex;
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterEncodingScheme(String characterEncodingScheme) {
/*  208 */     if (characterEncodingScheme.equals("UTF-16BE")) {
/*  209 */       this._encodingStringsAsUtf8 = false;
/*  210 */       this._nonIdentifyingStringOnThirdBitCES = 132;
/*  211 */       this._nonIdentifyingStringOnFirstBitCES = 16;
/*      */     } else {
/*  213 */       this._encodingStringsAsUtf8 = true;
/*  214 */       this._nonIdentifyingStringOnThirdBitCES = 128;
/*  215 */       this._nonIdentifyingStringOnFirstBitCES = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCharacterEncodingScheme() {
/*  223 */     return this._encodingStringsAsUtf8 ? "UTF-8" : "UTF-16BE";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRegisteredEncodingAlgorithms(Map algorithms) {
/*  230 */     this._registeredEncodingAlgorithms = algorithms;
/*  231 */     if (this._registeredEncodingAlgorithms == null) {
/*  232 */       this._registeredEncodingAlgorithms = new HashMap();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getRegisteredEncodingAlgorithms() {
/*  240 */     return this._registeredEncodingAlgorithms;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterContentChunkSizeLimit(int size) {
/*  247 */     if (size < 0) {
/*  248 */       size = 0;
/*      */     }
/*      */     
/*  251 */     this.characterContentChunkSizeContraint = size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCharacterContentChunkSizeLimit() {
/*  258 */     return this.characterContentChunkSizeContraint;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeValueSizeLimit(int size) {
/*  265 */     if (size < 0) {
/*  266 */       size = 0;
/*      */     }
/*      */     
/*  269 */     this.attributeValueSizeConstraint = size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributeValueSizeLimit() {
/*  276 */     return this.attributeValueSizeConstraint;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/*  308 */     this._terminate = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOutputStream(OutputStream s) {
/*  318 */     this._octetBufferIndex = 0;
/*  319 */     this._markIndex = -1;
/*  320 */     this._s = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVocabulary(SerializerVocabulary vocabulary) {
/*  329 */     this._v = vocabulary;
/*  330 */     this._vIsInternal = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeHeader(boolean encodeXmlDecl) throws IOException {
/*  339 */     if (encodeXmlDecl) {
/*  340 */       this._s.write(EncodingConstants.XML_DECLARATION_VALUES[0]);
/*      */     }
/*  342 */     this._s.write(EncodingConstants.BINARY_HEADER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeInitialVocabulary() throws IOException {
/*  350 */     if (this._v == null) {
/*  351 */       this._v = new SerializerVocabulary();
/*  352 */       this._vIsInternal = true;
/*  353 */     } else if (this._vIsInternal) {
/*  354 */       this._v.clear();
/*      */     } 
/*      */     
/*  357 */     if (this._v.hasInitialVocabulary()) {
/*  358 */       this._b = 32;
/*  359 */       write(this._b);
/*      */       
/*  361 */       SerializerVocabulary initialVocabulary = this._v.getReadOnlyVocabulary();
/*      */ 
/*      */       
/*  364 */       if (initialVocabulary.hasExternalVocabulary()) {
/*  365 */         this._b = 16;
/*  366 */         write(this._b);
/*  367 */         write(0);
/*      */       } 
/*      */       
/*  370 */       if (initialVocabulary.hasExternalVocabulary()) {
/*  371 */         encodeNonEmptyOctetStringOnSecondBit(this._v.getExternalVocabularyURI().toString());
/*      */       
/*      */       }
/*      */     }
/*  375 */     else if (this._v.hasExternalVocabulary()) {
/*  376 */       this._b = 32;
/*  377 */       write(this._b);
/*      */       
/*  379 */       this._b = 16;
/*  380 */       write(this._b);
/*  381 */       write(0);
/*      */       
/*  383 */       encodeNonEmptyOctetStringOnSecondBit(this._v.getExternalVocabularyURI().toString());
/*      */     } else {
/*  385 */       write(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeDocumentTermination() throws IOException {
/*  394 */     encodeElementTermination();
/*  395 */     encodeTermination();
/*  396 */     _flush();
/*  397 */     this._s.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeElementTermination() throws IOException {
/*  405 */     this._terminate = true;
/*  406 */     switch (this._b) {
/*      */       case 240:
/*  408 */         this._b = 255;
/*      */         return;
/*      */       case 255:
/*  411 */         write(255); break;
/*      */     } 
/*  413 */     this._b = 240;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeTermination() throws IOException {
/*  422 */     if (this._terminate) {
/*  423 */       write(this._b);
/*  424 */       this._terminate = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNamespaceAttribute(String prefix, String uri) throws IOException {
/*  437 */     this._b = 204;
/*  438 */     if (prefix != "") {
/*  439 */       this._b |= 0x2;
/*      */     }
/*  441 */     if (uri != "") {
/*  442 */       this._b |= 0x1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  450 */     write(this._b);
/*      */     
/*  452 */     if (prefix != "") {
/*  453 */       encodeIdentifyingNonEmptyStringOnFirstBit(prefix, this._v.prefix);
/*      */     }
/*  455 */     if (uri != "") {
/*  456 */       encodeIdentifyingNonEmptyStringOnFirstBit(uri, this._v.namespaceName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeCharacters(char[] ch, int offset, int length) throws IOException {
/*  469 */     boolean addToTable = (length < this.characterContentChunkSizeContraint);
/*  470 */     encodeNonIdentifyingStringOnThirdBit(ch, offset, length, this._v.characterContentChunk, addToTable, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeCharactersNoClone(char[] ch, int offset, int length) throws IOException {
/*  486 */     boolean addToTable = (length < this.characterContentChunkSizeContraint);
/*  487 */     encodeNonIdentifyingStringOnThirdBit(ch, offset, length, this._v.characterContentChunk, addToTable, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeFourBitCharacters(int id, int[] table, char[] ch, int offset, int length) throws FastInfosetException, IOException {
/*  504 */     this._b = (length < this.characterContentChunkSizeContraint) ? 152 : 136;
/*      */ 
/*      */     
/*  507 */     write(this._b);
/*      */ 
/*      */     
/*  510 */     this._b = id << 2;
/*      */     
/*  512 */     encodeNonEmptyFourBitCharacterStringOnSeventhBit(table, ch, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeAlphabetCharacters(String alphabet, char[] ch, int offset, int length) throws FastInfosetException, IOException {
/*  529 */     int id = this._v.restrictedAlphabet.get(alphabet);
/*  530 */     if (id == -1) {
/*  531 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.restrictedAlphabetNotPresent"));
/*      */     }
/*  533 */     id += 32;
/*      */     
/*  535 */     this._b = (length < this.characterContentChunkSizeContraint) ? 152 : 136;
/*      */ 
/*      */     
/*  538 */     this._b |= (id & 0xC0) >> 6;
/*  539 */     write(this._b);
/*      */ 
/*      */     
/*  542 */     this._b = (id & 0x3F) << 2;
/*      */     
/*  544 */     encodeNonEmptyNBitCharacterStringOnSeventhBit(alphabet, ch, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeProcessingInstruction(String target, String data) throws IOException {
/*  554 */     write(225);
/*      */ 
/*      */     
/*  557 */     encodeIdentifyingNonEmptyStringOnFirstBit(target, this._v.otherNCName);
/*      */ 
/*      */     
/*  560 */     boolean addToTable = (data.length() < this.characterContentChunkSizeContraint);
/*  561 */     encodeNonIdentifyingStringOnFirstBit(data, this._v.otherString, addToTable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeComment(char[] ch, int offset, int length) throws IOException {
/*  573 */     write(226);
/*      */     
/*  575 */     boolean addToTable = (length < this.characterContentChunkSizeContraint);
/*  576 */     encodeNonIdentifyingStringOnFirstBit(ch, offset, length, this._v.otherString, addToTable, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeCommentNoClone(char[] ch, int offset, int length) throws IOException {
/*  592 */     write(226);
/*      */     
/*  594 */     boolean addToTable = (length < this.characterContentChunkSizeContraint);
/*  595 */     encodeNonIdentifyingStringOnFirstBit(ch, offset, length, this._v.otherString, addToTable, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeElementQualifiedNameOnThirdBit(String namespaceURI, String prefix, String localName) throws IOException {
/*  613 */     LocalNameQualifiedNamesMap.Entry entry = this._v.elementName.obtainEntry(localName);
/*  614 */     if (entry._valueIndex > 0) {
/*  615 */       QualifiedName[] names = entry._value;
/*  616 */       for (int i = 0; i < entry._valueIndex; i++) {
/*  617 */         if ((prefix == (names[i]).prefix || prefix.equals((names[i]).prefix)) && (namespaceURI == (names[i]).namespaceName || namespaceURI.equals((names[i]).namespaceName))) {
/*      */           
/*  619 */           encodeNonZeroIntegerOnThirdBit((names[i]).index);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*  625 */     encodeLiteralElementQualifiedNameOnThirdBit(namespaceURI, prefix, localName, entry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeLiteralElementQualifiedNameOnThirdBit(String namespaceURI, String prefix, String localName, LocalNameQualifiedNamesMap.Entry entry) throws IOException {
/*  640 */     QualifiedName name = new QualifiedName(prefix, namespaceURI, localName, "", this._v.elementName.getNextIndex());
/*  641 */     entry.addQualifiedName(name);
/*      */     
/*  643 */     int namespaceURIIndex = -1;
/*  644 */     int prefixIndex = -1;
/*  645 */     if (namespaceURI != "") {
/*  646 */       namespaceURIIndex = this._v.namespaceName.get(namespaceURI);
/*  647 */       if (namespaceURIIndex == -1) {
/*  648 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.namespaceURINotIndexed", new Object[] { namespaceURI }));
/*      */       }
/*      */       
/*  651 */       if (prefix != "") {
/*  652 */         prefixIndex = this._v.prefix.get(prefix);
/*  653 */         if (prefixIndex == -1) {
/*  654 */           throw new IOException(CommonResourceBundle.getInstance().getString("message.prefixNotIndexed", new Object[] { prefix }));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  659 */     int localNameIndex = this._v.localName.obtainIndex(localName);
/*      */     
/*  661 */     this._b |= 0x3C;
/*  662 */     if (namespaceURIIndex >= 0) {
/*  663 */       this._b |= 0x1;
/*  664 */       if (prefixIndex >= 0) {
/*  665 */         this._b |= 0x2;
/*      */       }
/*      */     } 
/*  668 */     write(this._b);
/*      */     
/*  670 */     if (namespaceURIIndex >= 0) {
/*  671 */       if (prefixIndex >= 0) {
/*  672 */         encodeNonZeroIntegerOnSecondBitFirstBitOne(prefixIndex);
/*      */       }
/*  674 */       encodeNonZeroIntegerOnSecondBitFirstBitOne(namespaceURIIndex);
/*      */     } 
/*      */     
/*  677 */     if (localNameIndex >= 0) {
/*  678 */       encodeNonZeroIntegerOnSecondBitFirstBitOne(localNameIndex);
/*      */     } else {
/*  680 */       encodeNonEmptyOctetStringOnSecondBit(localName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeAttributeQualifiedNameOnSecondBit(String namespaceURI, String prefix, String localName) throws IOException {
/*  699 */     LocalNameQualifiedNamesMap.Entry entry = this._v.attributeName.obtainEntry(localName);
/*  700 */     if (entry._valueIndex > 0) {
/*  701 */       QualifiedName[] names = entry._value;
/*  702 */       for (int i = 0; i < entry._valueIndex; i++) {
/*  703 */         if ((prefix == (names[i]).prefix || prefix.equals((names[i]).prefix)) && (namespaceURI == (names[i]).namespaceName || namespaceURI.equals((names[i]).namespaceName))) {
/*      */           
/*  705 */           encodeNonZeroIntegerOnSecondBitFirstBitZero((names[i]).index);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*  711 */     encodeLiteralAttributeQualifiedNameOnSecondBit(namespaceURI, prefix, localName, entry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean encodeLiteralAttributeQualifiedNameOnSecondBit(String namespaceURI, String prefix, String localName, LocalNameQualifiedNamesMap.Entry entry) throws IOException {
/*  726 */     int namespaceURIIndex = -1;
/*  727 */     int prefixIndex = -1;
/*  728 */     if (namespaceURI != "") {
/*  729 */       namespaceURIIndex = this._v.namespaceName.get(namespaceURI);
/*  730 */       if (namespaceURIIndex == -1) {
/*  731 */         if (namespaceURI == "http://www.w3.org/2000/xmlns/" || namespaceURI.equals("http://www.w3.org/2000/xmlns/"))
/*      */         {
/*  733 */           return false;
/*      */         }
/*  735 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.namespaceURINotIndexed", new Object[] { namespaceURI }));
/*      */       } 
/*      */ 
/*      */       
/*  739 */       if (prefix != "") {
/*  740 */         prefixIndex = this._v.prefix.get(prefix);
/*  741 */         if (prefixIndex == -1) {
/*  742 */           throw new IOException(CommonResourceBundle.getInstance().getString("message.prefixNotIndexed", new Object[] { prefix }));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  747 */     int localNameIndex = this._v.localName.obtainIndex(localName);
/*      */     
/*  749 */     QualifiedName name = new QualifiedName(prefix, namespaceURI, localName, "", this._v.attributeName.getNextIndex());
/*  750 */     entry.addQualifiedName(name);
/*      */     
/*  752 */     this._b = 120;
/*  753 */     if (namespaceURI != "") {
/*  754 */       this._b |= 0x1;
/*  755 */       if (prefix != "") {
/*  756 */         this._b |= 0x2;
/*      */       }
/*      */     } 
/*      */     
/*  760 */     write(this._b);
/*      */     
/*  762 */     if (namespaceURIIndex >= 0) {
/*  763 */       if (prefixIndex >= 0) {
/*  764 */         encodeNonZeroIntegerOnSecondBitFirstBitOne(prefixIndex);
/*      */       }
/*  766 */       encodeNonZeroIntegerOnSecondBitFirstBitOne(namespaceURIIndex);
/*  767 */     } else if (namespaceURI != "") {
/*      */       
/*  769 */       encodeNonEmptyOctetStringOnSecondBit("xml");
/*  770 */       encodeNonEmptyOctetStringOnSecondBit("http://www.w3.org/XML/1998/namespace");
/*      */     } 
/*      */     
/*  773 */     if (localNameIndex >= 0) {
/*  774 */       encodeNonZeroIntegerOnSecondBitFirstBitOne(localNameIndex);
/*      */     } else {
/*  776 */       encodeNonEmptyOctetStringOnSecondBit(localName);
/*      */     } 
/*      */     
/*  779 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonIdentifyingStringOnFirstBit(String s, StringIntMap map, boolean addToTable) throws IOException {
/*  792 */     if (s == null || s.length() == 0) {
/*      */       
/*  794 */       write(255);
/*      */     }
/*  796 */     else if (addToTable) {
/*  797 */       int index = map.obtainIndex(s);
/*  798 */       if (index == -1) {
/*  799 */         this._b = 0x40 | this._nonIdentifyingStringOnFirstBitCES;
/*  800 */         encodeNonEmptyCharacterStringOnFifthBit(s);
/*      */       } else {
/*  802 */         encodeNonZeroIntegerOnSecondBitFirstBitOne(index);
/*      */       } 
/*      */     } else {
/*  805 */       this._b = this._nonIdentifyingStringOnFirstBitCES;
/*  806 */       encodeNonEmptyCharacterStringOnFifthBit(s);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonIdentifyingStringOnFirstBit(String s, CharArrayIntMap map, boolean addToTable) throws IOException {
/*  821 */     if (s == null || s.length() == 0) {
/*      */       
/*  823 */       write(255);
/*      */     }
/*  825 */     else if (addToTable) {
/*  826 */       char[] ch = s.toCharArray();
/*  827 */       int length = s.length();
/*  828 */       int index = map.obtainIndex(ch, 0, length, false);
/*  829 */       if (index == -1) {
/*  830 */         this._b = 0x40 | this._nonIdentifyingStringOnFirstBitCES;
/*  831 */         encodeNonEmptyCharacterStringOnFifthBit(ch, 0, length);
/*      */       } else {
/*  833 */         encodeNonZeroIntegerOnSecondBitFirstBitOne(index);
/*      */       } 
/*      */     } else {
/*  836 */       this._b = this._nonIdentifyingStringOnFirstBitCES;
/*  837 */       encodeNonEmptyCharacterStringOnFifthBit(s);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonIdentifyingStringOnFirstBit(char[] ch, int offset, int length, CharArrayIntMap map, boolean addToTable, boolean clone) throws IOException {
/*  857 */     if (length == 0) {
/*      */       
/*  859 */       write(255);
/*      */     }
/*  861 */     else if (addToTable) {
/*  862 */       int index = map.obtainIndex(ch, offset, length, clone);
/*  863 */       if (index == -1) {
/*  864 */         this._b = 0x40 | this._nonIdentifyingStringOnFirstBitCES;
/*  865 */         encodeNonEmptyCharacterStringOnFifthBit(ch, offset, length);
/*      */       } else {
/*  867 */         encodeNonZeroIntegerOnSecondBitFirstBitOne(index);
/*      */       } 
/*      */     } else {
/*  870 */       this._b = this._nonIdentifyingStringOnFirstBitCES;
/*  871 */       encodeNonEmptyCharacterStringOnFifthBit(ch, offset, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonIdentifyingStringOnFirstBit(String URI, int id, Object data) throws FastInfosetException, IOException {
/*  890 */     if (URI != null) {
/*  891 */       id = this._v.encodingAlgorithm.get(URI);
/*  892 */       if (id == -1) {
/*  893 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.EncodingAlgorithmURI", new Object[] { URI }));
/*      */       }
/*  895 */       id += 32;
/*      */       
/*  897 */       EncodingAlgorithm ea = (EncodingAlgorithm)this._registeredEncodingAlgorithms.get(URI);
/*  898 */       if (ea != null) {
/*  899 */         encodeAIIObjectAlgorithmData(id, data, ea);
/*      */       }
/*  901 */       else if (data instanceof byte[]) {
/*  902 */         byte[] d = (byte[])data;
/*  903 */         encodeAIIOctetAlgorithmData(id, d, 0, d.length);
/*      */       } else {
/*  905 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.nullEncodingAlgorithmURI"));
/*      */       }
/*      */     
/*  908 */     } else if (id <= 9) {
/*  909 */       BuiltInEncodingAlgorithm a = BuiltInEncodingAlgorithmFactory.table[id];
/*  910 */       int length = 0;
/*  911 */       switch (id) {
/*      */         case 0:
/*  913 */           length = ((byte[])data).length;
/*      */           break;
/*      */         case 1:
/*  916 */           length = ((byte[])data).length;
/*      */           break;
/*      */         case 2:
/*  919 */           length = ((short[])data).length;
/*      */           break;
/*      */         case 3:
/*  922 */           length = ((int[])data).length;
/*      */           break;
/*      */         case 4:
/*  925 */           length = ((long[])data).length;
/*      */           break;
/*      */         case 5:
/*  928 */           length = ((boolean[])data).length;
/*      */           break;
/*      */         case 6:
/*  931 */           length = ((float[])data).length;
/*      */           break;
/*      */         case 7:
/*  934 */           length = ((double[])data).length;
/*      */           break;
/*      */         case 8:
/*  937 */           length = ((long[])data).length;
/*      */           break;
/*      */         case 9:
/*  940 */           throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.CDATA"));
/*      */         default:
/*  942 */           throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.UnsupportedBuiltInAlgorithm", new Object[] { new Integer(id) }));
/*      */       } 
/*  944 */       encodeAIIBuiltInAlgorithmData(id, data, 0, length);
/*  945 */     } else if (id >= 32) {
/*  946 */       if (data instanceof byte[]) {
/*  947 */         byte[] d = (byte[])data;
/*  948 */         encodeAIIOctetAlgorithmData(id, d, 0, d.length);
/*      */       } else {
/*  950 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.nullEncodingAlgorithmURI"));
/*      */       } 
/*      */     } else {
/*  953 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.identifiers10to31Reserved"));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeAIIOctetAlgorithmData(int id, byte[] d, int offset, int length) throws IOException {
/*  969 */     write(0x30 | (id & 0xF0) >> 4);
/*      */ 
/*      */ 
/*      */     
/*  973 */     this._b = (id & 0xF) << 4;
/*      */ 
/*      */     
/*  976 */     encodeNonZeroOctetStringLengthOnFifthBit(length);
/*      */     
/*  978 */     write(d, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeAIIObjectAlgorithmData(int id, Object data, EncodingAlgorithm ea) throws FastInfosetException, IOException {
/*  993 */     write(0x30 | (id & 0xF0) >> 4);
/*      */ 
/*      */ 
/*      */     
/*  997 */     this._b = (id & 0xF) << 4;
/*      */     
/*  999 */     this._encodingBufferOutputStream.reset();
/* 1000 */     ea.encodeToOutputStream(data, this._encodingBufferOutputStream);
/* 1001 */     encodeNonZeroOctetStringLengthOnFifthBit(this._encodingBufferIndex);
/* 1002 */     write(this._encodingBuffer, this._encodingBufferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeAIIBuiltInAlgorithmData(int id, Object data, int offset, int length) throws IOException {
/* 1019 */     write(0x30 | (id & 0xF0) >> 4);
/*      */ 
/*      */ 
/*      */     
/* 1023 */     this._b = (id & 0xF) << 4;
/*      */     
/* 1025 */     int octetLength = BuiltInEncodingAlgorithmFactory.table[id].getOctetLengthFromPrimitiveLength(length);
/*      */ 
/*      */     
/* 1028 */     encodeNonZeroOctetStringLengthOnFifthBit(octetLength);
/*      */     
/* 1030 */     ensureSize(octetLength);
/* 1031 */     BuiltInEncodingAlgorithmFactory.table[id].encodeToBytes(data, offset, length, this._octetBuffer, this._octetBufferIndex);
/*      */     
/* 1033 */     this._octetBufferIndex += octetLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonIdentifyingStringOnThirdBit(char[] ch, int offset, int length, CharArrayIntMap map, boolean addToTable, boolean clone) throws IOException {
/* 1053 */     if (addToTable) {
/* 1054 */       int index = map.obtainIndex(ch, offset, length, clone);
/* 1055 */       if (index == -1) {
/* 1056 */         this._b = 0x10 | this._nonIdentifyingStringOnThirdBitCES;
/*      */         
/* 1058 */         encodeNonEmptyCharacterStringOnSeventhBit(ch, offset, length);
/*      */       } else {
/* 1060 */         this._b = 160;
/* 1061 */         encodeNonZeroIntegerOnFourthBit(index);
/*      */       } 
/*      */     } else {
/* 1064 */       this._b = this._nonIdentifyingStringOnThirdBitCES;
/* 1065 */       encodeNonEmptyCharacterStringOnSeventhBit(ch, offset, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonIdentifyingStringOnThirdBit(String URI, int id, Object data) throws FastInfosetException, IOException {
/* 1083 */     if (URI != null) {
/* 1084 */       id = this._v.encodingAlgorithm.get(URI);
/* 1085 */       if (id == -1) {
/* 1086 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.EncodingAlgorithmURI", new Object[] { URI }));
/*      */       }
/* 1088 */       id += 32;
/*      */       
/* 1090 */       EncodingAlgorithm ea = (EncodingAlgorithm)this._registeredEncodingAlgorithms.get(URI);
/* 1091 */       if (ea != null) {
/* 1092 */         encodeCIIObjectAlgorithmData(id, data, ea);
/*      */       }
/* 1094 */       else if (data instanceof byte[]) {
/* 1095 */         byte[] d = (byte[])data;
/* 1096 */         encodeCIIOctetAlgorithmData(id, d, 0, d.length);
/*      */       } else {
/* 1098 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.nullEncodingAlgorithmURI"));
/*      */       }
/*      */     
/* 1101 */     } else if (id <= 9) {
/* 1102 */       int length = 0;
/* 1103 */       switch (id) {
/*      */         case 0:
/* 1105 */           length = ((byte[])data).length;
/*      */           break;
/*      */         case 1:
/* 1108 */           length = ((byte[])data).length;
/*      */           break;
/*      */         case 2:
/* 1111 */           length = ((short[])data).length;
/*      */           break;
/*      */         case 3:
/* 1114 */           length = ((int[])data).length;
/*      */           break;
/*      */         case 4:
/* 1117 */           length = ((int[])data).length;
/*      */           break;
/*      */         case 5:
/* 1120 */           length = ((boolean[])data).length;
/*      */           break;
/*      */         case 6:
/* 1123 */           length = ((float[])data).length;
/*      */           break;
/*      */         case 7:
/* 1126 */           length = ((double[])data).length;
/*      */           break;
/*      */         case 8:
/* 1129 */           length = ((int[])data).length;
/*      */           break;
/*      */         case 9:
/* 1132 */           throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.CDATA"));
/*      */         default:
/* 1134 */           throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.UnsupportedBuiltInAlgorithm", new Object[] { new Integer(id) }));
/*      */       } 
/* 1136 */       encodeCIIBuiltInAlgorithmData(id, data, 0, length);
/* 1137 */     } else if (id >= 32) {
/* 1138 */       if (data instanceof byte[]) {
/* 1139 */         byte[] d = (byte[])data;
/* 1140 */         encodeCIIOctetAlgorithmData(id, d, 0, d.length);
/*      */       } else {
/* 1142 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.nullEncodingAlgorithmURI"));
/*      */       } 
/*      */     } else {
/* 1145 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.identifiers10to31Reserved"));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonIdentifyingStringOnThirdBit(String URI, int id, byte[] d, int offset, int length) throws FastInfosetException, IOException {
/* 1164 */     if (URI != null) {
/* 1165 */       id = this._v.encodingAlgorithm.get(URI);
/* 1166 */       if (id == -1) {
/* 1167 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.EncodingAlgorithmURI", new Object[] { URI }));
/*      */       }
/* 1169 */       id += 32;
/*      */     } 
/*      */     
/* 1172 */     encodeCIIOctetAlgorithmData(id, d, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeCIIOctetAlgorithmData(int id, byte[] d, int offset, int length) throws IOException {
/* 1187 */     write(0x8C | (id & 0xC0) >> 6);
/*      */ 
/*      */ 
/*      */     
/* 1191 */     this._b = (id & 0x3F) << 2;
/*      */ 
/*      */     
/* 1194 */     encodeNonZeroOctetStringLengthOnSenventhBit(length);
/*      */     
/* 1196 */     write(d, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeCIIObjectAlgorithmData(int id, Object data, EncodingAlgorithm ea) throws FastInfosetException, IOException {
/* 1211 */     write(0x8C | (id & 0xC0) >> 6);
/*      */ 
/*      */ 
/*      */     
/* 1215 */     this._b = (id & 0x3F) << 2;
/*      */     
/* 1217 */     this._encodingBufferOutputStream.reset();
/* 1218 */     ea.encodeToOutputStream(data, this._encodingBufferOutputStream);
/* 1219 */     encodeNonZeroOctetStringLengthOnSenventhBit(this._encodingBufferIndex);
/* 1220 */     write(this._encodingBuffer, this._encodingBufferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeCIIBuiltInAlgorithmData(int id, Object data, int offset, int length) throws FastInfosetException, IOException {
/* 1237 */     write(0x8C | (id & 0xC0) >> 6);
/*      */ 
/*      */ 
/*      */     
/* 1241 */     this._b = (id & 0x3F) << 2;
/*      */     
/* 1243 */     int octetLength = BuiltInEncodingAlgorithmFactory.table[id].getOctetLengthFromPrimitiveLength(length);
/*      */ 
/*      */     
/* 1246 */     encodeNonZeroOctetStringLengthOnSenventhBit(octetLength);
/*      */     
/* 1248 */     ensureSize(octetLength);
/* 1249 */     BuiltInEncodingAlgorithmFactory.table[id].encodeToBytes(data, offset, length, this._octetBuffer, this._octetBufferIndex);
/*      */     
/* 1251 */     this._octetBufferIndex += octetLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeCIIBuiltInAlgorithmDataAsCDATA(char[] ch, int offset, int length) throws FastInfosetException, IOException {
/* 1265 */     write(140);
/*      */ 
/*      */     
/* 1268 */     this._b = 36;
/*      */ 
/*      */     
/* 1271 */     length = encodeUTF8String(ch, offset, length);
/* 1272 */     encodeNonZeroOctetStringLengthOnSenventhBit(length);
/* 1273 */     write(this._encodingBuffer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeIdentifyingNonEmptyStringOnFirstBit(String s, StringIntMap map) throws IOException {
/* 1285 */     int index = map.obtainIndex(s);
/* 1286 */     if (index == -1) {
/*      */       
/* 1288 */       encodeNonEmptyOctetStringOnSecondBit(s);
/*      */     } else {
/*      */       
/* 1291 */       encodeNonZeroIntegerOnSecondBitFirstBitOne(index);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyOctetStringOnSecondBit(String s) throws IOException {
/* 1303 */     int length = encodeUTF8String(s);
/* 1304 */     encodeNonZeroOctetStringLengthOnSecondBit(length);
/* 1305 */     write(this._encodingBuffer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroOctetStringLengthOnSecondBit(int length) throws IOException {
/* 1315 */     if (length < 65) {
/*      */       
/* 1317 */       write(length - 1);
/* 1318 */     } else if (length < 321) {
/*      */       
/* 1320 */       write(64);
/* 1321 */       write(length - 65);
/*      */     } else {
/*      */       
/* 1324 */       write(96);
/* 1325 */       length -= 321;
/* 1326 */       write(length >>> 24);
/* 1327 */       write(length >> 16 & 0xFF);
/* 1328 */       write(length >> 8 & 0xFF);
/* 1329 */       write(length & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyCharacterStringOnFifthBit(String s) throws IOException {
/* 1341 */     int length = this._encodingStringsAsUtf8 ? encodeUTF8String(s) : encodeUtf16String(s);
/* 1342 */     encodeNonZeroOctetStringLengthOnFifthBit(length);
/* 1343 */     write(this._encodingBuffer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyCharacterStringOnFifthBit(char[] ch, int offset, int length) throws IOException {
/* 1356 */     length = this._encodingStringsAsUtf8 ? encodeUTF8String(ch, offset, length) : encodeUtf16String(ch, offset, length);
/* 1357 */     encodeNonZeroOctetStringLengthOnFifthBit(length);
/* 1358 */     write(this._encodingBuffer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroOctetStringLengthOnFifthBit(int length) throws IOException {
/* 1369 */     if (length < 9) {
/*      */       
/* 1371 */       write(this._b | length - 1);
/* 1372 */     } else if (length < 265) {
/*      */       
/* 1374 */       write(this._b | 0x8);
/* 1375 */       write(length - 9);
/*      */     } else {
/*      */       
/* 1378 */       write(this._b | 0xC);
/* 1379 */       length -= 265;
/* 1380 */       write(length >>> 24);
/* 1381 */       write(length >> 16 & 0xFF);
/* 1382 */       write(length >> 8 & 0xFF);
/* 1383 */       write(length & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyCharacterStringOnSeventhBit(char[] ch, int offset, int length) throws IOException {
/* 1397 */     length = this._encodingStringsAsUtf8 ? encodeUTF8String(ch, offset, length) : encodeUtf16String(ch, offset, length);
/* 1398 */     encodeNonZeroOctetStringLengthOnSenventhBit(length);
/* 1399 */     write(this._encodingBuffer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyFourBitCharacterStringOnSeventhBit(int[] table, char[] ch, int offset, int length) throws FastInfosetException, IOException {
/* 1414 */     int octetPairLength = length / 2;
/* 1415 */     int octetSingleLength = length % 2;
/*      */ 
/*      */     
/* 1418 */     encodeNonZeroOctetStringLengthOnSenventhBit(octetPairLength + octetSingleLength);
/*      */     
/* 1420 */     ensureSize(octetPairLength + octetSingleLength);
/*      */     
/* 1422 */     int v = 0;
/* 1423 */     for (int i = 0; i < octetPairLength; i++) {
/* 1424 */       v = table[ch[offset++]] << 4 | table[ch[offset++]];
/* 1425 */       if (v < 0) {
/* 1426 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.characterOutofAlphabetRange"));
/*      */       }
/* 1428 */       this._octetBuffer[this._octetBufferIndex++] = (byte)v;
/*      */     } 
/*      */     
/* 1431 */     if (octetSingleLength == 1) {
/* 1432 */       v = table[ch[offset]] << 4 | 0xF;
/* 1433 */       if (v < 0) {
/* 1434 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.characterOutofAlphabetRange"));
/*      */       }
/* 1436 */       this._octetBuffer[this._octetBufferIndex++] = (byte)v;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyNBitCharacterStringOnSeventhBit(String alphabet, char[] ch, int offset, int length) throws FastInfosetException, IOException {
/* 1452 */     int bitsPerCharacter = 1;
/* 1453 */     while (1 << bitsPerCharacter <= alphabet.length()) {
/* 1454 */       bitsPerCharacter++;
/*      */     }
/* 1456 */     int terminatingValue = (1 << bitsPerCharacter) - 1;
/*      */     
/* 1458 */     int bits = length * bitsPerCharacter;
/* 1459 */     int octets = bits / 8;
/* 1460 */     int bitsOfLastOctet = bits % 8;
/* 1461 */     int totalOctets = octets + ((bitsOfLastOctet > 0) ? 1 : 0);
/*      */ 
/*      */     
/* 1464 */     encodeNonZeroOctetStringLengthOnSenventhBit(totalOctets);
/*      */     
/* 1466 */     resetBits();
/* 1467 */     ensureSize(totalOctets);
/* 1468 */     int v = 0;
/* 1469 */     for (int i = 0; i < length; i++) {
/* 1470 */       char c = ch[offset + i];
/*      */       
/* 1472 */       for (v = 0; v < alphabet.length() && 
/* 1473 */         c != alphabet.charAt(v); v++);
/*      */ 
/*      */ 
/*      */       
/* 1477 */       if (v == alphabet.length()) {
/* 1478 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.characterOutofAlphabetRange"));
/*      */       }
/* 1480 */       writeBits(bitsPerCharacter, v);
/*      */     } 
/*      */     
/* 1483 */     if (bitsOfLastOctet > 0) {
/* 1484 */       this._b |= (1 << 8 - bitsOfLastOctet) - 1;
/* 1485 */       write(this._b);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void resetBits() {
/* 1492 */     this._bitsLeftInOctet = 8;
/* 1493 */     this._b = 0;
/*      */   }
/*      */   
/*      */   private final void writeBits(int bits, int v) throws IOException {
/* 1497 */     while (bits > 0) {
/* 1498 */       int bit = ((v & 1 << --bits) > 0) ? 1 : 0;
/* 1499 */       this._b |= bit << --this._bitsLeftInOctet;
/* 1500 */       if (this._bitsLeftInOctet == 0) {
/* 1501 */         write(this._b);
/* 1502 */         this._bitsLeftInOctet = 8;
/* 1503 */         this._b = 0;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroOctetStringLengthOnSenventhBit(int length) throws IOException {
/* 1516 */     if (length < 3) {
/*      */       
/* 1518 */       write(this._b | length - 1);
/* 1519 */     } else if (length < 259) {
/*      */       
/* 1521 */       write(this._b | 0x2);
/* 1522 */       write(length - 3);
/*      */     } else {
/*      */       
/* 1525 */       write(this._b | 0x3);
/* 1526 */       length -= 259;
/* 1527 */       write(length >>> 24);
/* 1528 */       write(length >> 16 & 0xFF);
/* 1529 */       write(length >> 8 & 0xFF);
/* 1530 */       write(length & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroIntegerOnSecondBitFirstBitOne(int i) throws IOException {
/* 1548 */     if (i < 64) {
/*      */       
/* 1550 */       write(0x80 | i);
/* 1551 */     } else if (i < 8256) {
/*      */       
/* 1553 */       i -= 64;
/* 1554 */       this._b = 0xC0 | i >> 8;
/*      */       
/* 1556 */       write(this._b);
/* 1557 */       write(i & 0xFF);
/*      */     } else {
/*      */       
/* 1560 */       i -= 8256;
/* 1561 */       this._b = 0xE0 | i >> 16;
/*      */       
/* 1563 */       write(this._b);
/* 1564 */       write(i >> 8 & 0xFF);
/* 1565 */       write(i & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroIntegerOnSecondBitFirstBitZero(int i) throws IOException {
/* 1583 */     if (i < 64) {
/*      */       
/* 1585 */       write(i);
/* 1586 */     } else if (i < 8256) {
/*      */       
/* 1588 */       i -= 64;
/* 1589 */       this._b = 0x40 | i >> 8;
/* 1590 */       write(this._b);
/* 1591 */       write(i & 0xFF);
/*      */     } else {
/*      */       
/* 1594 */       i -= 8256;
/* 1595 */       this._b = 0x60 | i >> 16;
/* 1596 */       write(this._b);
/* 1597 */       write(i >> 8 & 0xFF);
/* 1598 */       write(i & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroIntegerOnThirdBit(int i) throws IOException {
/* 1611 */     if (i < 32) {
/*      */       
/* 1613 */       write(this._b | i);
/* 1614 */     } else if (i < 2080) {
/*      */       
/* 1616 */       i -= 32;
/* 1617 */       this._b |= 0x20 | i >> 8;
/* 1618 */       write(this._b);
/* 1619 */       write(i & 0xFF);
/* 1620 */     } else if (i < 526368) {
/*      */       
/* 1622 */       i -= 2080;
/* 1623 */       this._b |= 0x28 | i >> 16;
/* 1624 */       write(this._b);
/* 1625 */       write(i >> 8 & 0xFF);
/* 1626 */       write(i & 0xFF);
/*      */     } else {
/*      */       
/* 1629 */       i -= 526368;
/* 1630 */       this._b |= 0x30;
/* 1631 */       write(this._b);
/* 1632 */       write(i >> 16);
/* 1633 */       write(i >> 8 & 0xFF);
/* 1634 */       write(i & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroIntegerOnFourthBit(int i) throws IOException {
/* 1647 */     if (i < 16) {
/*      */       
/* 1649 */       write(this._b | i);
/* 1650 */     } else if (i < 1040) {
/*      */       
/* 1652 */       i -= 16;
/* 1653 */       this._b |= 0x10 | i >> 8;
/* 1654 */       write(this._b);
/* 1655 */       write(i & 0xFF);
/* 1656 */     } else if (i < 263184) {
/*      */       
/* 1658 */       i -= 1040;
/* 1659 */       this._b |= 0x14 | i >> 16;
/* 1660 */       write(this._b);
/* 1661 */       write(i >> 8 & 0xFF);
/* 1662 */       write(i & 0xFF);
/*      */     } else {
/*      */       
/* 1665 */       i -= 263184;
/* 1666 */       this._b |= 0x18;
/* 1667 */       write(this._b);
/* 1668 */       write(i >> 16);
/* 1669 */       write(i >> 8 & 0xFF);
/* 1670 */       write(i & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyUTF8StringAsOctetString(int b, String s, int[] constants) throws IOException {
/* 1683 */     char[] ch = s.toCharArray();
/* 1684 */     encodeNonEmptyUTF8StringAsOctetString(b, ch, 0, ch.length, constants);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonEmptyUTF8StringAsOctetString(int b, char[] ch, int offset, int length, int[] constants) throws IOException {
/* 1699 */     length = encodeUTF8String(ch, offset, length);
/* 1700 */     encodeNonZeroOctetStringLength(b, length, constants);
/* 1701 */     write(this._encodingBuffer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroOctetStringLength(int b, int length, int[] constants) throws IOException {
/* 1714 */     if (length < constants[0]) {
/* 1715 */       write(b | length - 1);
/* 1716 */     } else if (length < constants[1]) {
/* 1717 */       write(b | constants[2]);
/* 1718 */       write(length - constants[0]);
/*      */     } else {
/* 1720 */       write(b | constants[3]);
/* 1721 */       length -= constants[1];
/* 1722 */       write(length >>> 24);
/* 1723 */       write(length >> 16 & 0xFF);
/* 1724 */       write(length >> 8 & 0xFF);
/* 1725 */       write(length & 0xFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void encodeNonZeroInteger(int b, int i, int[] constants) throws IOException {
/* 1738 */     if (i < constants[0]) {
/* 1739 */       write(b | i);
/* 1740 */     } else if (i < constants[1]) {
/* 1741 */       i -= constants[0];
/* 1742 */       write(b | constants[3] | i >> 8);
/* 1743 */       write(i & 0xFF);
/* 1744 */     } else if (i < constants[2]) {
/* 1745 */       i -= constants[1];
/* 1746 */       write(b | constants[4] | i >> 16);
/* 1747 */       write(i >> 8 & 0xFF);
/* 1748 */       write(i & 0xFF);
/* 1749 */     } else if (i < 1048576) {
/* 1750 */       i -= constants[2];
/* 1751 */       write(b | constants[5]);
/* 1752 */       write(i >> 16);
/* 1753 */       write(i >> 8 & 0xFF);
/* 1754 */       write(i & 0xFF);
/*      */     } else {
/* 1756 */       throw new IOException(CommonResourceBundle.getInstance().getString("message.integerMaxSize", new Object[] { new Integer(1048576) }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void mark() throws IOException {
/* 1764 */     this._markIndex = this._octetBufferIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void resetMark() throws IOException {
/* 1771 */     this._markIndex = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void write(int i) throws IOException {
/* 1778 */     if (this._octetBufferIndex < this._octetBuffer.length) {
/* 1779 */       this._octetBuffer[this._octetBufferIndex++] = (byte)i;
/*      */     }
/* 1781 */     else if (this._markIndex == -1) {
/* 1782 */       this._s.write(this._octetBuffer);
/* 1783 */       this._octetBufferIndex = 1;
/* 1784 */       this._octetBuffer[0] = (byte)i;
/*      */     } else {
/* 1786 */       resize(this._octetBuffer.length * 3 / 2);
/* 1787 */       this._octetBuffer[this._octetBufferIndex++] = (byte)i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void write(byte[] b, int length) throws IOException {
/* 1799 */     write(b, 0, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void write(byte[] b, int offset, int length) throws IOException {
/* 1810 */     if (this._octetBufferIndex + length < this._octetBuffer.length) {
/* 1811 */       System.arraycopy(b, offset, this._octetBuffer, this._octetBufferIndex, length);
/* 1812 */       this._octetBufferIndex += length;
/*      */     }
/* 1814 */     else if (this._markIndex == -1) {
/* 1815 */       this._s.write(this._octetBuffer, 0, this._octetBufferIndex);
/* 1816 */       this._s.write(b, offset, length);
/* 1817 */       this._octetBufferIndex = 0;
/*      */     } else {
/* 1819 */       resize((this._octetBuffer.length + length) * 3 / 2 + 1);
/* 1820 */       System.arraycopy(b, offset, this._octetBuffer, this._octetBufferIndex, length);
/* 1821 */       this._octetBufferIndex += length;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void ensureSize(int length) {
/* 1827 */     if (this._octetBufferIndex + length > this._octetBuffer.length) {
/* 1828 */       resize((this._octetBufferIndex + length) * 3 / 2 + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private void resize(int length) {
/* 1833 */     byte[] b = new byte[length];
/* 1834 */     System.arraycopy(this._octetBuffer, 0, b, 0, this._octetBufferIndex);
/* 1835 */     this._octetBuffer = b;
/*      */   }
/*      */   
/*      */   private void _flush() throws IOException {
/* 1839 */     if (this._octetBufferIndex > 0) {
/* 1840 */       this._s.write(this._octetBuffer, 0, this._octetBufferIndex);
/* 1841 */       this._octetBufferIndex = 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Encoder() {
/* 1846 */     this._encodingBufferOutputStream = new EncodingBufferOutputStream();
/*      */     
/* 1848 */     this._encodingBuffer = new byte[512];
/*      */     setCharacterEncodingScheme(_characterEncodingSchemeSystemDefault);
/*      */   }
/*      */   
/*      */   private class EncodingBufferOutputStream extends OutputStream { private final Encoder this$0;
/*      */     
/*      */     public void write(int b) throws IOException {
/* 1855 */       if (Encoder.this._encodingBufferIndex < Encoder.this._encodingBuffer.length) {
/* 1856 */         Encoder.this._encodingBuffer[Encoder.this._encodingBufferIndex++] = (byte)b;
/*      */       } else {
/* 1858 */         byte[] newbuf = new byte[Math.max(Encoder.this._encodingBuffer.length << 1, Encoder.this._encodingBufferIndex)];
/* 1859 */         System.arraycopy(Encoder.this._encodingBuffer, 0, newbuf, 0, Encoder.this._encodingBufferIndex);
/* 1860 */         Encoder.this._encodingBuffer = newbuf;
/*      */         
/* 1862 */         Encoder.this._encodingBuffer[Encoder.this._encodingBufferIndex++] = (byte)b;
/*      */       } 
/*      */     }
/*      */     private EncodingBufferOutputStream() {}
/*      */     public void write(byte[] b, int off, int len) throws IOException {
/* 1867 */       if (off < 0 || off > b.length || len < 0 || off + len > b.length || off + len < 0)
/*      */       {
/* 1869 */         throw new IndexOutOfBoundsException(); } 
/* 1870 */       if (len == 0) {
/*      */         return;
/*      */       }
/* 1873 */       int newoffset = Encoder.this._encodingBufferIndex + len;
/* 1874 */       if (newoffset > Encoder.this._encodingBuffer.length) {
/* 1875 */         byte[] newbuf = new byte[Math.max(Encoder.this._encodingBuffer.length << 1, newoffset)];
/* 1876 */         System.arraycopy(Encoder.this._encodingBuffer, 0, newbuf, 0, Encoder.this._encodingBufferIndex);
/* 1877 */         Encoder.this._encodingBuffer = newbuf;
/*      */       } 
/* 1879 */       System.arraycopy(b, off, Encoder.this._encodingBuffer, Encoder.this._encodingBufferIndex, len);
/* 1880 */       Encoder.this._encodingBufferIndex = newoffset;
/*      */     }
/*      */     
/*      */     public int getLength() {
/* 1884 */       return Encoder.this._encodingBufferIndex;
/*      */     }
/*      */     
/*      */     public void reset() {
/* 1888 */       Encoder.this._encodingBufferIndex = 0;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int encodeUTF8String(String s) throws IOException {
/* 1898 */     int length = s.length();
/* 1899 */     if (length < this._charBuffer.length) {
/* 1900 */       s.getChars(0, length, this._charBuffer, 0);
/* 1901 */       return encodeUTF8String(this._charBuffer, 0, length);
/*      */     } 
/* 1903 */     char[] ch = s.toCharArray();
/* 1904 */     return encodeUTF8String(ch, 0, length);
/*      */   }
/*      */ 
/*      */   
/*      */   private void ensureEncodingBufferSizeForUtf8String(int length) {
/* 1909 */     int newLength = 4 * length;
/* 1910 */     if (this._encodingBuffer.length < newLength) {
/* 1911 */       this._encodingBuffer = new byte[newLength];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int encodeUTF8String(char[] ch, int offset, int length) throws IOException {
/* 1923 */     int bpos = 0;
/*      */ 
/*      */     
/* 1926 */     ensureEncodingBufferSizeForUtf8String(length);
/*      */     
/* 1928 */     int end = offset + length;
/*      */     
/* 1930 */     while (end != offset) {
/* 1931 */       int c = ch[offset++];
/* 1932 */       if (c < 128) {
/*      */         
/* 1934 */         this._encodingBuffer[bpos++] = (byte)c; continue;
/* 1935 */       }  if (c < 2048) {
/*      */         
/* 1937 */         this._encodingBuffer[bpos++] = (byte)(0xC0 | c >> 6);
/*      */         
/* 1939 */         this._encodingBuffer[bpos++] = (byte)(0x80 | c & 0x3F); continue;
/*      */       } 
/* 1941 */       if (c <= 65535) {
/* 1942 */         if (!XMLChar.isHighSurrogate(c) && !XMLChar.isLowSurrogate(c)) {
/*      */           
/* 1944 */           this._encodingBuffer[bpos++] = (byte)(0xE0 | c >> 12);
/*      */           
/* 1946 */           this._encodingBuffer[bpos++] = (byte)(0x80 | c >> 6 & 0x3F);
/*      */           
/* 1948 */           this._encodingBuffer[bpos++] = (byte)(0x80 | c & 0x3F);
/*      */           
/*      */           continue;
/*      */         } 
/* 1952 */         encodeCharacterAsUtf8FourByte(c, ch, offset, end, bpos);
/* 1953 */         bpos += 4;
/* 1954 */         offset++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1959 */     return bpos;
/*      */   }
/*      */   
/*      */   private void encodeCharacterAsUtf8FourByte(int c, char[] ch, int chpos, int chend, int bpos) throws IOException {
/* 1963 */     if (chpos == chend) {
/* 1964 */       throw new IOException("");
/*      */     }
/*      */     
/* 1967 */     char d = ch[chpos];
/* 1968 */     if (!XMLChar.isLowSurrogate(d)) {
/* 1969 */       throw new IOException("");
/*      */     }
/*      */     
/* 1972 */     int uc = ((c & 0x3FF) << 10 | d & 0x3FF) + 65536;
/* 1973 */     if (uc < 0 || uc >= 2097152) {
/* 1974 */       throw new IOException("");
/*      */     }
/*      */     
/* 1977 */     this._encodingBuffer[bpos++] = (byte)(0xF0 | uc >> 18);
/* 1978 */     this._encodingBuffer[bpos++] = (byte)(0x80 | uc >> 12 & 0x3F);
/* 1979 */     this._encodingBuffer[bpos++] = (byte)(0x80 | uc >> 6 & 0x3F);
/* 1980 */     this._encodingBuffer[bpos++] = (byte)(0x80 | uc & 0x3F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int encodeUtf16String(String s) throws IOException {
/* 1989 */     int length = s.length();
/* 1990 */     if (length < this._charBuffer.length) {
/* 1991 */       s.getChars(0, length, this._charBuffer, 0);
/* 1992 */       return encodeUtf16String(this._charBuffer, 0, length);
/*      */     } 
/* 1994 */     char[] ch = s.toCharArray();
/* 1995 */     return encodeUtf16String(ch, 0, length);
/*      */   }
/*      */ 
/*      */   
/*      */   private void ensureEncodingBufferSizeForUtf16String(int length) {
/* 2000 */     int newLength = 2 * length;
/* 2001 */     if (this._encodingBuffer.length < newLength) {
/* 2002 */       this._encodingBuffer = new byte[newLength];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int encodeUtf16String(char[] ch, int offset, int length) throws IOException {
/* 2014 */     int byteLength = 0;
/*      */ 
/*      */     
/* 2017 */     ensureEncodingBufferSizeForUtf16String(length);
/*      */     
/* 2019 */     int n = offset + length;
/* 2020 */     for (int i = offset; i < n; i++) {
/* 2021 */       int c = ch[i];
/* 2022 */       this._encodingBuffer[byteLength++] = (byte)(c >> 8);
/* 2023 */       this._encodingBuffer[byteLength++] = (byte)(c & 0xFF);
/*      */     } 
/*      */     
/* 2026 */     return byteLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPrefixFromQualifiedName(String qName) {
/* 2036 */     int i = qName.indexOf(':');
/* 2037 */     String prefix = "";
/* 2038 */     if (i != -1) {
/* 2039 */       prefix = qName.substring(0, i);
/*      */     }
/* 2041 */     return prefix;
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\Encoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */