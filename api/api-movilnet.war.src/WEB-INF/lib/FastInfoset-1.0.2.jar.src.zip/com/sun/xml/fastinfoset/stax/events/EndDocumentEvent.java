/*    */ package com.sun.xml.fastinfoset.stax.events;
/*    */ 
/*    */ import javax.xml.stream.events.EndDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndDocumentEvent
/*    */   extends EventBase
/*    */   implements EndDocument
/*    */ {
/*    */   public EndDocumentEvent() {
/* 47 */     super(8);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     return "<? EndDocument ?>";
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\EndDocumentEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */