/*     */ package com.sun.xml.fastinfoset.vocab;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.util.CharArrayIntMap;
/*     */ import com.sun.xml.fastinfoset.util.FixedEntryStringIntMap;
/*     */ import com.sun.xml.fastinfoset.util.KeyIntMap;
/*     */ import com.sun.xml.fastinfoset.util.LocalNameQualifiedNamesMap;
/*     */ import com.sun.xml.fastinfoset.util.StringIntMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializerVocabulary
/*     */   extends Vocabulary
/*     */ {
/*     */   public final StringIntMap restrictedAlphabet;
/*     */   public final StringIntMap encodingAlgorithm;
/*     */   public final StringIntMap namespaceName;
/*     */   public final StringIntMap prefix;
/*     */   public final StringIntMap localName;
/*     */   public final StringIntMap otherNCName;
/*     */   public final StringIntMap otherURI;
/*     */   public final StringIntMap attributeValue;
/*     */   public final CharArrayIntMap otherString;
/*     */   public final CharArrayIntMap characterContentChunk;
/*     */   public final LocalNameQualifiedNamesMap elementName;
/*     */   public final LocalNameQualifiedNamesMap attributeName;
/*  71 */   public final KeyIntMap[] tables = new KeyIntMap[12];
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializerVocabulary _readOnlyVocabulary;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerVocabulary() {
/*  81 */     this.tables[0] = (KeyIntMap)(this.restrictedAlphabet = new StringIntMap(4));
/*  82 */     this.tables[1] = (KeyIntMap)(this.encodingAlgorithm = new StringIntMap(4));
/*  83 */     this.tables[2] = (KeyIntMap)(this.prefix = (StringIntMap)new FixedEntryStringIntMap("xml", 8));
/*  84 */     this.tables[3] = (KeyIntMap)(this.namespaceName = (StringIntMap)new FixedEntryStringIntMap("http://www.w3.org/XML/1998/namespace", 8));
/*  85 */     this.tables[4] = (KeyIntMap)(this.localName = new StringIntMap());
/*  86 */     this.tables[5] = (KeyIntMap)(this.otherNCName = new StringIntMap(4));
/*  87 */     this.tables[6] = (KeyIntMap)(this.otherURI = new StringIntMap(4));
/*  88 */     this.tables[7] = (KeyIntMap)(this.attributeValue = new StringIntMap());
/*  89 */     this.tables[8] = (KeyIntMap)(this.otherString = new CharArrayIntMap(4));
/*  90 */     this.tables[9] = (KeyIntMap)(this.characterContentChunk = new CharArrayIntMap());
/*  91 */     this.tables[10] = (KeyIntMap)(this.elementName = new LocalNameQualifiedNamesMap());
/*  92 */     this.tables[11] = (KeyIntMap)(this.attributeName = new LocalNameQualifiedNamesMap());
/*     */   }
/*     */   
/*     */   public SerializerVocabulary getReadOnlyVocabulary() {
/*  96 */     return this._readOnlyVocabulary;
/*     */   }
/*     */   
/*     */   protected void setReadOnlyVocabulary(SerializerVocabulary readOnlyVocabulary, boolean clear) {
/* 100 */     for (int i = 0; i < this.tables.length; i++) {
/* 101 */       this.tables[i].setReadOnlyMap(readOnlyVocabulary.tables[i], clear);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setInitialVocabulary(SerializerVocabulary initialVocabulary, boolean clear) {
/* 106 */     setExternalVocabularyURI(null);
/* 107 */     setInitialReadOnlyVocabulary(true);
/* 108 */     setReadOnlyVocabulary(initialVocabulary, clear);
/*     */   }
/*     */   
/*     */   public void setExternalVocabulary(String externalVocabularyURI, SerializerVocabulary externalVocabulary, boolean clear) {
/* 112 */     setInitialReadOnlyVocabulary(false);
/* 113 */     setExternalVocabularyURI(externalVocabularyURI);
/* 114 */     setReadOnlyVocabulary(externalVocabulary, clear);
/*     */   }
/*     */   
/*     */   public void clear() {
/* 118 */     for (int i = 0; i < this.tables.length; i++)
/* 119 */       this.tables[i].clear(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\vocab\SerializerVocabulary.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */