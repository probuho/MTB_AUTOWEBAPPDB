/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.Writer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EventBase
/*     */   implements XMLEvent
/*     */ {
/*     */   protected int _eventType;
/*  56 */   protected Location _location = null;
/*     */ 
/*     */   
/*     */   public EventBase() {}
/*     */ 
/*     */   
/*     */   public EventBase(int eventType) {
/*  63 */     this._eventType = eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEventType() {
/*  70 */     return this._eventType;
/*     */   }
/*     */   
/*     */   protected void setEventType(int eventType) {
/*  74 */     this._eventType = eventType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStartElement() {
/*  79 */     return (this._eventType == 1);
/*     */   }
/*     */   
/*     */   public boolean isEndElement() {
/*  83 */     return (this._eventType == 2);
/*     */   }
/*     */   
/*     */   public boolean isEntityReference() {
/*  87 */     return (this._eventType == 9);
/*     */   }
/*     */   
/*     */   public boolean isProcessingInstruction() {
/*  91 */     return (this._eventType == 3);
/*     */   }
/*     */   
/*     */   public boolean isStartDocument() {
/*  95 */     return (this._eventType == 7);
/*     */   }
/*     */   
/*     */   public boolean isEndDocument() {
/*  99 */     return (this._eventType == 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/* 109 */     return this._location;
/*     */   }
/*     */   
/*     */   public void setLocation(Location loc) {
/* 113 */     this._location = loc;
/*     */   }
/*     */   public String getSystemId() {
/* 116 */     if (this._location == null) {
/* 117 */       return "";
/*     */     }
/* 119 */     return this._location.getSystemId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Characters asCharacters() {
/* 126 */     if (isCharacters()) {
/* 127 */       return (Characters)this;
/*     */     }
/* 129 */     throw new ClassCastException(CommonResourceBundle.getInstance().getString("message.charactersCast", new Object[] { getEventTypeString() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EndElement asEndElement() {
/* 136 */     if (isEndElement()) {
/* 137 */       return (EndElement)this;
/*     */     }
/* 139 */     throw new ClassCastException(CommonResourceBundle.getInstance().getString("message.endElementCase", new Object[] { getEventTypeString() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartElement asStartElement() {
/* 147 */     if (isStartElement()) {
/* 148 */       return (StartElement)this;
/*     */     }
/* 150 */     throw new ClassCastException(CommonResourceBundle.getInstance().getString("message.startElementCase", new Object[] { getEventTypeString() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getSchemaType() {
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttribute() {
/* 167 */     return (this._eventType == 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCharacters() {
/* 174 */     return (this._eventType == 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNamespace() {
/* 181 */     return (this._eventType == 13);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getEventTypeString() {
/* 205 */     switch (this._eventType) {
/*     */       case 1:
/* 207 */         return "StartElementEvent";
/*     */       case 2:
/* 209 */         return "EndElementEvent";
/*     */       case 3:
/* 211 */         return "ProcessingInstructionEvent";
/*     */       case 4:
/* 213 */         return "CharacterEvent";
/*     */       case 5:
/* 215 */         return "CommentEvent";
/*     */       case 7:
/* 217 */         return "StartDocumentEvent";
/*     */       case 8:
/* 219 */         return "EndDocumentEvent";
/*     */       case 9:
/* 221 */         return "EntityReferenceEvent";
/*     */       case 10:
/* 223 */         return "AttributeBase";
/*     */       case 11:
/* 225 */         return "DTDEvent";
/*     */       case 12:
/* 227 */         return "CDATA";
/*     */     } 
/* 229 */     return "UNKNOWN_EVENT_TYPE";
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\EventBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */