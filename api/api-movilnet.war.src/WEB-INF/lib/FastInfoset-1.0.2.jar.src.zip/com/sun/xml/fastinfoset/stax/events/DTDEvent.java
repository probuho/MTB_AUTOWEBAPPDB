/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.xml.stream.events.DTD;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DTDEvent
/*     */   extends EventBase
/*     */   implements DTD
/*     */ {
/*     */   private String _dtd;
/*     */   private List _notations;
/*     */   private List _entities;
/*     */   
/*     */   public DTDEvent() {
/*  58 */     setEventType(11);
/*     */   }
/*     */   
/*     */   public DTDEvent(String dtd) {
/*  62 */     setEventType(11);
/*  63 */     this._dtd = dtd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDocumentTypeDeclaration() {
/*  75 */     return this._dtd;
/*     */   }
/*     */   public void setDTD(String dtd) {
/*  78 */     this._dtd = dtd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getEntities() {
/*  89 */     return this._entities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getNotations() {
/*  99 */     return this._notations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProcessedDTD() {
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   public void setEntities(List entites) {
/* 112 */     this._entities = entites;
/*     */   }
/*     */   
/*     */   public void setNotations(List notations) {
/* 116 */     this._notations = notations;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 120 */     return this._dtd;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\DTDEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */