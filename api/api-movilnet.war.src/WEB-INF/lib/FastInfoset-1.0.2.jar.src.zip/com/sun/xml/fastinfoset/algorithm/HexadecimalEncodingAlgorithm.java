/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HexadecimalEncodingAlgorithm
/*     */   extends BuiltInEncodingAlgorithm
/*     */ {
/*  49 */   private static final char[] NIBBLE_TO_HEXADECIMAL_TABLE = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'B', 'D', 'E', 'F' };
/*     */ 
/*     */ 
/*     */   
/*  53 */   private static final int[] HEXADECIMAL_TO_NIBBLE_TABLE = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object decodeFromBytes(byte[] b, int start, int length) throws EncodingAlgorithmException {
/*  80 */     byte[] data = new byte[length];
/*  81 */     System.arraycopy(b, start, data, 0, length);
/*  82 */     return data;
/*     */   }
/*     */   
/*     */   public final Object decodeFromInputStream(InputStream s) throws IOException {
/*  86 */     throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.notImplemented"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeToOutputStream(Object data, OutputStream s) throws IOException {
/*  91 */     if (!(data instanceof byte[])) {
/*  92 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotByteArray"));
/*     */     }
/*     */     
/*  95 */     s.write((byte[])data);
/*     */   }
/*     */   
/*     */   public final Object convertFromCharacters(char[] ch, int start, int length) {
/*  99 */     if (length == 0) {
/* 100 */       return new byte[0];
/*     */     }
/*     */     
/* 103 */     StringBuffer encodedValue = removeWhitespace(ch, start, length);
/* 104 */     int encodedLength = encodedValue.length();
/* 105 */     if (encodedLength == 0) {
/* 106 */       return new byte[0];
/*     */     }
/*     */     
/* 109 */     int valueLength = encodedValue.length() / 2;
/* 110 */     byte[] value = new byte[valueLength];
/*     */     
/* 112 */     int encodedIdx = 0;
/* 113 */     for (int i = 0; i < valueLength; i++) {
/* 114 */       int nibble1 = HEXADECIMAL_TO_NIBBLE_TABLE[encodedValue.charAt(encodedIdx++) - 48];
/* 115 */       int nibble2 = HEXADECIMAL_TO_NIBBLE_TABLE[encodedValue.charAt(encodedIdx++) - 48];
/* 116 */       value[i] = (byte)(nibble1 << 4 | nibble2);
/*     */     } 
/*     */     
/* 119 */     return value;
/*     */   }
/*     */   
/*     */   public final void convertToCharacters(Object data, StringBuffer s) {
/* 123 */     if (data == null) {
/*     */       return;
/*     */     }
/* 126 */     byte[] value = (byte[])data;
/* 127 */     if (value.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 131 */     s.ensureCapacity(value.length * 2);
/* 132 */     for (int i = 0; i < value.length; i++) {
/* 133 */       s.append(NIBBLE_TO_HEXADECIMAL_TABLE[value[i] >>> 4 & 0xF]);
/* 134 */       s.append(NIBBLE_TO_HEXADECIMAL_TABLE[value[i] & 0xF]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/* 141 */     return octetLength * 2;
/*     */   }
/*     */   
/*     */   public int getOctetLengthFromPrimitiveLength(int primitiveLength) {
/* 145 */     return primitiveLength / 2;
/*     */   }
/*     */   
/*     */   public final void encodeToBytes(Object array, int astart, int alength, byte[] b, int start) {
/* 149 */     System.arraycopy(array, astart, b, start, alength);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\HexadecimalEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */