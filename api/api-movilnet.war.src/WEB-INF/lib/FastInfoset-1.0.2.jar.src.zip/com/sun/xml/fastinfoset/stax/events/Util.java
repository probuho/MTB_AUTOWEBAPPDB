/*    */ package com.sun.xml.fastinfoset.stax.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public static boolean isEmptyString(String s) {
/* 52 */     if (s != null && !s.equals("")) {
/* 53 */       return false;
/*    */     }
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   public static final String getEventTypeString(int eventType) {
/* 59 */     switch (eventType) {
/*    */       case 1:
/* 61 */         return "START_ELEMENT";
/*    */       case 2:
/* 63 */         return "END_ELEMENT";
/*    */       case 3:
/* 65 */         return "PROCESSING_INSTRUCTION";
/*    */       case 4:
/* 67 */         return "CHARACTERS";
/*    */       case 5:
/* 69 */         return "COMMENT";
/*    */       case 7:
/* 71 */         return "START_DOCUMENT";
/*    */       case 8:
/* 73 */         return "END_DOCUMENT";
/*    */       case 9:
/* 75 */         return "ENTITY_REFERENCE";
/*    */       case 10:
/* 77 */         return "ATTRIBUTE";
/*    */       case 11:
/* 79 */         return "DTD";
/*    */       case 12:
/* 81 */         return "CDATA";
/*    */     } 
/* 83 */     return "UNKNOWN_EVENT_TYPE";
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */