/*      */ package com.sun.xml.fastinfoset.stax;
/*      */ 
/*      */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*      */ import com.sun.xml.fastinfoset.Decoder;
/*      */ import com.sun.xml.fastinfoset.DecoderStateTables;
/*      */ import com.sun.xml.fastinfoset.QualifiedName;
/*      */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithmFactory;
/*      */ import com.sun.xml.fastinfoset.org.apache.xerces.util.XMLChar;
/*      */ import com.sun.xml.fastinfoset.sax.AttributesHolder;
/*      */ import com.sun.xml.fastinfoset.util.CharArray;
/*      */ import com.sun.xml.fastinfoset.util.CharArrayString;
/*      */ import com.sun.xml.fastinfoset.util.PrefixArray;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.Iterator;
/*      */ import java.util.NoSuchElementException;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import javax.xml.stream.XMLStreamReader;
/*      */ import org.jvnet.fastinfoset.EncodingAlgorithm;
/*      */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*      */ import org.jvnet.fastinfoset.FastInfosetException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StAXDocumentParser
/*      */   extends Decoder
/*      */   implements XMLStreamReader
/*      */ {
/*      */   protected static final int INTERNAL_STATE_START_DOCUMENT = 0;
/*      */   protected static final int INTERNAL_STATE_START_ELEMENT_TERMINATE = 1;
/*      */   protected static final int INTERNAL_STATE_SINGLE_TERMINATE_ELEMENT_WITH_NAMESPACES = 2;
/*      */   protected static final int INTERNAL_STATE_DOUBLE_TERMINATE_ELEMENT = 3;
/*      */   protected static final int INTERNAL_STATE_END_DOCUMENT = 4;
/*      */   protected static final int INTERNAL_STATE_VOID = -1;
/*      */   protected int _internalState;
/*      */   protected int _eventType;
/*   85 */   protected QualifiedName[] _qNameStack = new QualifiedName[32];
/*   86 */   protected int[] _namespaceAIIsStartStack = new int[32];
/*   87 */   protected int[] _namespaceAIIsEndStack = new int[32];
/*   88 */   protected int _stackCount = -1;
/*      */   
/*   90 */   protected String[] _namespaceAIIsPrefix = new String[32];
/*   91 */   protected String[] _namespaceAIIsNamespaceName = new String[32];
/*   92 */   protected int[] _namespaceAIIsPrefixIndex = new int[32];
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _namespaceAIIsIndex;
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _currentNamespaceAIIsStart;
/*      */ 
/*      */   
/*      */   protected int _currentNamespaceAIIsEnd;
/*      */ 
/*      */   
/*      */   protected QualifiedName _qualifiedName;
/*      */ 
/*      */   
/*  109 */   protected AttributesHolder _attributes = new AttributesHolder();
/*      */   
/*      */   protected boolean _clearAttributes = false;
/*      */   
/*      */   protected char[] _characters;
/*      */   
/*      */   protected int _charactersOffset;
/*      */   
/*      */   protected int _charactersLength;
/*      */   
/*      */   protected String _algorithmURI;
/*      */   
/*      */   protected int _algorithmId;
/*      */   
/*      */   protected byte[] _algorithmData;
/*      */   
/*      */   protected int _algorithmDataOffset;
/*      */   
/*      */   protected int _algorithmDataLength;
/*      */   
/*      */   protected String _piTarget;
/*      */   
/*      */   protected String _piData;
/*  132 */   protected NamespaceContextImpl _nsContext = new NamespaceContextImpl();
/*      */   
/*      */   protected String _characterEncodingScheme;
/*      */   
/*      */   protected StAXManager _manager;
/*      */   
/*      */   public StAXDocumentParser() {
/*  139 */     reset();
/*      */   }
/*      */   
/*      */   public StAXDocumentParser(InputStream s) {
/*  143 */     this();
/*  144 */     setInputStream(s);
/*      */   }
/*      */   
/*      */   public StAXDocumentParser(InputStream s, StAXManager manager) {
/*  148 */     this(s);
/*  149 */     this._manager = manager;
/*      */   }
/*      */   
/*      */   public void setInputStream(InputStream s) {
/*  153 */     super.setInputStream(s);
/*  154 */     reset();
/*      */   }
/*      */   
/*      */   public void reset() {
/*  158 */     super.reset();
/*  159 */     if (this._internalState != 0 && this._internalState != 4) {
/*      */ 
/*      */       
/*  162 */       for (int i = this._namespaceAIIsIndex - 1; i >= 0; i--) {
/*  163 */         this._prefixTable.popScopeWithPrefixEntry(this._namespaceAIIsPrefixIndex[i]);
/*      */       }
/*      */       
/*  166 */       this._stackCount = -1;
/*      */       
/*  168 */       this._namespaceAIIsIndex = 0;
/*  169 */       this._characters = null;
/*  170 */       this._algorithmData = null;
/*      */     } 
/*      */     
/*  173 */     this._characterEncodingScheme = "UTF-8";
/*  174 */     this._eventType = 7;
/*  175 */     this._internalState = 0;
/*      */   }
/*      */   
/*      */   protected void resetOnError() {
/*  179 */     super.reset();
/*      */     
/*  181 */     if (this._v != null) {
/*  182 */       this._prefixTable.clearCompletely();
/*      */     }
/*  184 */     this._duplicateAttributeVerifier.clear();
/*      */     
/*  186 */     this._stackCount = -1;
/*      */     
/*  188 */     this._namespaceAIIsIndex = 0;
/*  189 */     this._characters = null;
/*  190 */     this._algorithmData = null;
/*      */     
/*  192 */     this._eventType = 7;
/*  193 */     this._internalState = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getProperty(String name) throws IllegalArgumentException {
/*  200 */     if (this._manager != null) {
/*  201 */       return this._manager.getProperty(name);
/*      */     }
/*  203 */     return null; } public int next() throws XMLStreamException { try {
/*      */       QualifiedName qn; boolean addToTable; int b2, index;
/*      */       String entity_reference_name;
/*      */       int i;
/*      */       String system_identifier, public_identifier;
/*  208 */       if (this._internalState != -1) {
/*  209 */         int j; switch (this._internalState) {
/*      */           case 0:
/*  211 */             decodeHeader();
/*  212 */             processDII();
/*      */             
/*  214 */             this._internalState = -1;
/*      */             break;
/*      */           case 1:
/*  217 */             if (this._currentNamespaceAIIsEnd > 0) {
/*  218 */               for (int k = this._currentNamespaceAIIsEnd - 1; k >= this._currentNamespaceAIIsStart; k--) {
/*  219 */                 this._prefixTable.popScopeWithPrefixEntry(this._namespaceAIIsPrefixIndex[k]);
/*      */               }
/*  221 */               this._namespaceAIIsIndex = this._currentNamespaceAIIsStart;
/*      */             } 
/*      */ 
/*      */             
/*  225 */             popStack();
/*      */             
/*  227 */             this._internalState = -1;
/*  228 */             return this._eventType = 2;
/*      */           
/*      */           case 2:
/*  231 */             for (j = this._currentNamespaceAIIsEnd - 1; j >= this._currentNamespaceAIIsStart; j--) {
/*  232 */               this._prefixTable.popScopeWithPrefixEntry(this._namespaceAIIsPrefixIndex[j]);
/*      */             }
/*  234 */             this._namespaceAIIsIndex = this._currentNamespaceAIIsStart;
/*  235 */             this._internalState = -1;
/*      */             break;
/*      */           
/*      */           case 3:
/*  239 */             if (this._currentNamespaceAIIsEnd > 0) {
/*  240 */               for (j = this._currentNamespaceAIIsEnd - 1; j >= this._currentNamespaceAIIsStart; j--) {
/*  241 */                 this._prefixTable.popScopeWithPrefixEntry(this._namespaceAIIsPrefixIndex[j]);
/*      */               }
/*  243 */               this._namespaceAIIsIndex = this._currentNamespaceAIIsStart;
/*      */             } 
/*      */             
/*  246 */             if (this._stackCount == -1) {
/*  247 */               this._internalState = 4;
/*  248 */               return this._eventType = 8;
/*      */             } 
/*      */ 
/*      */             
/*  252 */             popStack();
/*      */             
/*  254 */             this._internalState = (this._currentNamespaceAIIsEnd > 0) ? 2 : -1;
/*      */ 
/*      */             
/*  257 */             return this._eventType = 2;
/*      */           case 4:
/*  259 */             throw new NoSuchElementException(CommonResourceBundle.getInstance().getString("message.noMoreEvents"));
/*      */         } 
/*      */ 
/*      */       
/*      */       } 
/*  264 */       this._characters = null;
/*  265 */       this._algorithmData = null;
/*  266 */       this._currentNamespaceAIIsEnd = 0;
/*      */ 
/*      */       
/*  269 */       int b = read();
/*  270 */       switch (DecoderStateTables.EII[b]) {
/*      */         case 0:
/*  272 */           processEII(this._elementNameTable._array[b], false);
/*  273 */           return this._eventType;
/*      */         case 1:
/*  275 */           processEII(this._elementNameTable._array[b & 0x1F], true);
/*  276 */           return this._eventType;
/*      */         case 2:
/*  278 */           processEII(processEIIIndexMedium(b), ((b & 0x40) > 0));
/*  279 */           return this._eventType;
/*      */         case 3:
/*  281 */           processEII(processEIIIndexLarge(b), ((b & 0x40) > 0));
/*  282 */           return this._eventType;
/*      */         
/*      */         case 5:
/*  285 */           qn = processLiteralQualifiedName(b & 0x3);
/*      */           
/*  287 */           this._elementNameTable.add(qn);
/*  288 */           processEII(qn, ((b & 0x40) > 0));
/*  289 */           return this._eventType;
/*      */         
/*      */         case 4:
/*  292 */           processEIIWithNamespaces(((b & 0x40) > 0));
/*  293 */           return this._eventType;
/*      */         case 6:
/*  295 */           this._octetBufferLength = (b & 0x1) + 1;
/*      */           
/*  297 */           decodeUtf8StringAsCharBuffer();
/*  298 */           if ((b & 0x10) > 0) {
/*  299 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*  302 */           this._characters = this._charBuffer;
/*  303 */           this._charactersOffset = 0;
/*  304 */           this._charactersLength = this._charBufferLength;
/*  305 */           return this._eventType = 4;
/*      */         case 7:
/*  307 */           this._octetBufferLength = read() + 3;
/*  308 */           decodeUtf8StringAsCharBuffer();
/*  309 */           if ((b & 0x10) > 0) {
/*  310 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*  313 */           this._characters = this._charBuffer;
/*  314 */           this._charactersOffset = 0;
/*  315 */           this._charactersLength = this._charBufferLength;
/*  316 */           return this._eventType = 4;
/*      */         case 8:
/*  318 */           this._octetBufferLength = (read() << 24 | read() << 16 | read() << 8 | read()) + 259;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  323 */           decodeUtf8StringAsCharBuffer();
/*  324 */           if ((b & 0x10) > 0) {
/*  325 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*  328 */           this._characters = this._charBuffer;
/*  329 */           this._charactersOffset = 0;
/*  330 */           this._charactersLength = this._charBufferLength;
/*  331 */           return this._eventType = 4;
/*      */         case 9:
/*  333 */           this._octetBufferLength = (b & 0x1) + 1;
/*      */           
/*  335 */           decodeUtf16StringAsCharBuffer();
/*  336 */           if ((b & 0x10) > 0) {
/*  337 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*  340 */           this._characters = this._charBuffer;
/*  341 */           this._charactersOffset = 0;
/*  342 */           this._charactersLength = this._charBufferLength;
/*  343 */           return this._eventType = 4;
/*      */         case 10:
/*  345 */           this._octetBufferLength = read() + 3;
/*  346 */           decodeUtf16StringAsCharBuffer();
/*  347 */           if ((b & 0x10) > 0) {
/*  348 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*  351 */           this._characters = this._charBuffer;
/*  352 */           this._charactersOffset = 0;
/*  353 */           this._charactersLength = this._charBufferLength;
/*  354 */           return this._eventType = 4;
/*      */         case 11:
/*  356 */           this._octetBufferLength = (read() << 24 | read() << 16 | read() << 8 | read()) + 259;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  361 */           decodeUtf16StringAsCharBuffer();
/*  362 */           if ((b & 0x10) > 0) {
/*  363 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*  366 */           this._characters = this._charBuffer;
/*  367 */           this._charactersOffset = 0;
/*  368 */           this._charactersLength = this._charBufferLength;
/*  369 */           return this._eventType = 4;
/*      */         
/*      */         case 12:
/*  372 */           addToTable = ((this._b & 0x10) > 0);
/*      */           
/*  374 */           this._identifier = (b & 0x2) << 6;
/*  375 */           i = read();
/*  376 */           this._identifier |= (i & 0xFC) >> 2;
/*      */           
/*  378 */           decodeOctetsOnSeventhBitOfNonIdentifyingStringOnThirdBit(i);
/*      */           
/*  380 */           decodeRestrictedAlphabetAsCharBuffer();
/*      */           
/*  382 */           if (addToTable) {
/*  383 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*  386 */           this._characters = this._charBuffer;
/*  387 */           this._charactersOffset = 0;
/*  388 */           this._charactersLength = this._charBufferLength;
/*  389 */           return this._eventType = 4;
/*      */ 
/*      */         
/*      */         case 13:
/*  393 */           if ((b & 0x40) > 0) {
/*  394 */             throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.addToTableNotSupported"));
/*      */           }
/*      */ 
/*      */           
/*  398 */           this._algorithmId = (b & 0x2) << 6;
/*  399 */           b2 = read();
/*  400 */           this._algorithmId |= (b2 & 0xFC) >> 2;
/*      */           
/*  402 */           decodeOctetsOnSeventhBitOfNonIdentifyingStringOnThirdBit(b2);
/*  403 */           processCIIEncodingAlgorithm();
/*      */           
/*  405 */           return this._eventType = 4;
/*      */ 
/*      */         
/*      */         case 14:
/*  409 */           index = b & 0xF;
/*      */           
/*  411 */           this._characters = this._characterContentChunkTable._array;
/*  412 */           this._charactersOffset = this._characterContentChunkTable._offset[index];
/*  413 */           this._charactersLength = this._characterContentChunkTable._length[index];
/*  414 */           return this._eventType = 4;
/*      */ 
/*      */         
/*      */         case 15:
/*  418 */           index = ((b & 0x3) << 8 | read()) + 16;
/*      */ 
/*      */           
/*  421 */           this._characters = this._characterContentChunkTable._array;
/*  422 */           this._charactersOffset = this._characterContentChunkTable._offset[index];
/*  423 */           this._charactersLength = this._characterContentChunkTable._length[index];
/*  424 */           return this._eventType = 4;
/*      */ 
/*      */         
/*      */         case 16:
/*  428 */           index = ((b & 0x3) << 16 | read() << 8 | read()) + 1040;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  433 */           this._characters = this._characterContentChunkTable._array;
/*  434 */           this._charactersOffset = this._characterContentChunkTable._offset[index];
/*  435 */           this._charactersLength = this._characterContentChunkTable._length[index];
/*  436 */           return this._eventType = 4;
/*      */ 
/*      */         
/*      */         case 17:
/*  440 */           index = (read() << 16 | read() << 8 | read()) + 263184;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  445 */           this._characters = this._characterContentChunkTable._array;
/*  446 */           this._charactersOffset = this._characterContentChunkTable._offset[index];
/*  447 */           this._charactersLength = this._characterContentChunkTable._length[index];
/*  448 */           return this._eventType = 4;
/*      */         
/*      */         case 18:
/*  451 */           processCommentII();
/*  452 */           return this._eventType;
/*      */         case 19:
/*  454 */           processProcessingII();
/*  455 */           return this._eventType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 21:
/*  462 */           entity_reference_name = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*      */           
/*  464 */           system_identifier = ((b & 0x2) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */           
/*  466 */           public_identifier = ((b & 0x1) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */           
/*  468 */           return this._eventType;
/*      */         
/*      */         case 23:
/*  471 */           if (this._stackCount != -1) {
/*      */             
/*  473 */             popStack();
/*      */             
/*  475 */             this._internalState = 3;
/*  476 */             return this._eventType = 2;
/*      */           } 
/*      */           
/*  479 */           this._internalState = 4;
/*  480 */           return this._eventType = 8;
/*      */         case 22:
/*  482 */           if (this._stackCount != -1) {
/*      */             
/*  484 */             popStack();
/*      */             
/*  486 */             if (this._currentNamespaceAIIsEnd > 0) {
/*  487 */               this._internalState = 2;
/*      */             }
/*  489 */             return this._eventType = 2;
/*      */           } 
/*      */           
/*  492 */           this._internalState = 4;
/*  493 */           return this._eventType = 8;
/*      */       } 
/*  495 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingEII"));
/*      */     }
/*  497 */     catch (IOException e) {
/*  498 */       resetOnError();
/*  499 */       e.printStackTrace();
/*  500 */       throw new XMLStreamException(e);
/*  501 */     } catch (FastInfosetException e) {
/*  502 */       resetOnError();
/*  503 */       e.printStackTrace();
/*  504 */       throw new XMLStreamException(e);
/*  505 */     } catch (RuntimeException e) {
/*  506 */       resetOnError();
/*  507 */       e.printStackTrace();
/*  508 */       throw e;
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void popStack() {
/*  514 */     this._qualifiedName = this._qNameStack[this._stackCount];
/*  515 */     this._currentNamespaceAIIsStart = this._namespaceAIIsStartStack[this._stackCount];
/*  516 */     this._currentNamespaceAIIsEnd = this._namespaceAIIsEndStack[this._stackCount];
/*  517 */     this._qNameStack[this._stackCount--] = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void require(int type, String namespaceURI, String localName) throws XMLStreamException {
/*  529 */     if (type != this._eventType)
/*  530 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.eventTypeNotMatch", new Object[] { getEventTypeString(type) })); 
/*  531 */     if (namespaceURI != null && !namespaceURI.equals(getNamespaceURI()))
/*  532 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.namespaceURINotMatch", new Object[] { namespaceURI })); 
/*  533 */     if (localName != null && !localName.equals(getLocalName())) {
/*  534 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.localNameNotMatch", new Object[] { localName }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getElementText() throws XMLStreamException {
/*  547 */     if (getEventType() != 1) {
/*  548 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.mustBeOnSTARTELEMENT"), getLocation());
/*      */     }
/*      */ 
/*      */     
/*  552 */     int eventType = next();
/*  553 */     return getElementText(true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getElementText(boolean startElementRead) throws XMLStreamException {
/*  559 */     if (!startElementRead) {
/*  560 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.mustBeOnSTARTELEMENT"), getLocation());
/*      */     }
/*      */     
/*  563 */     int eventType = getEventType();
/*  564 */     StringBuffer content = new StringBuffer();
/*  565 */     while (eventType != 2) {
/*  566 */       if (eventType == 4 || eventType == 12 || eventType == 6 || eventType == 9) {
/*      */ 
/*      */ 
/*      */         
/*  570 */         content.append(getText());
/*  571 */       } else if (eventType != 3 && eventType != 5) {
/*      */ 
/*      */         
/*  574 */         if (eventType == 8)
/*  575 */           throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.unexpectedEOF")); 
/*  576 */         if (eventType == 1) {
/*  577 */           throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.getElementTextExpectTextOnly"), getLocation());
/*      */         }
/*      */         
/*  580 */         throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.unexpectedEventType") + getEventTypeString(eventType), getLocation());
/*      */       } 
/*      */       
/*  583 */       eventType = next();
/*      */     } 
/*  585 */     return content.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int nextTag() throws XMLStreamException {
/*  602 */     int eventType = next();
/*  603 */     return nextTag(true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int nextTag(boolean currentTagRead) throws XMLStreamException {
/*  609 */     int eventType = getEventType();
/*  610 */     if (!currentTagRead) {
/*  611 */       eventType = next();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  617 */     while ((eventType == 4 && isWhiteSpace()) || (eventType == 12 && isWhiteSpace()) || eventType == 6 || eventType == 3 || eventType == 5) {
/*  618 */       eventType = next();
/*      */     }
/*  620 */     if (eventType != 1 && eventType != 2) {
/*  621 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.expectedStartOrEnd"), getLocation());
/*      */     }
/*  623 */     return eventType;
/*      */   }
/*      */   
/*      */   public final boolean hasNext() throws XMLStreamException {
/*  627 */     return (this._eventType != 8);
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws XMLStreamException {}
/*      */   
/*      */   public final String getNamespaceURI(String prefix) {
/*  634 */     String namespace = getNamespaceDecl(prefix);
/*  635 */     if (namespace == null) {
/*  636 */       if (prefix == null) {
/*  637 */         throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.nullPrefix"));
/*      */       }
/*  639 */       return null;
/*      */     } 
/*  641 */     return namespace;
/*      */   }
/*      */   
/*      */   public final boolean isStartElement() {
/*  645 */     return (this._eventType == 1);
/*      */   }
/*      */   
/*      */   public final boolean isEndElement() {
/*  649 */     return (this._eventType == 2);
/*      */   }
/*      */   
/*      */   public final boolean isCharacters() {
/*  653 */     return (this._eventType == 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isWhiteSpace() {
/*  663 */     if (isCharacters() || this._eventType == 12) {
/*  664 */       char[] ch = getTextCharacters();
/*  665 */       int start = getTextStart();
/*  666 */       int length = getTextLength();
/*  667 */       for (int i = start; i < length; i++) {
/*  668 */         if (!XMLChar.isSpace(ch[i])) {
/*  669 */           return false;
/*      */         }
/*      */       } 
/*  672 */       return true;
/*      */     } 
/*  674 */     return false;
/*      */   }
/*      */   
/*      */   public final String getAttributeValue(String namespaceURI, String localName) {
/*  678 */     if (this._eventType != 1) {
/*  679 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*      */     
/*  682 */     if (localName == null) {
/*  683 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  686 */     if (namespaceURI != null) {
/*  687 */       for (int i = 0; i < this._attributes.getLength(); i++) {
/*  688 */         if (this._attributes.getLocalName(i).equals(localName) && this._attributes.getURI(i).equals(namespaceURI))
/*      */         {
/*  690 */           return this._attributes.getValue(i);
/*      */         }
/*      */       } 
/*      */     } else {
/*  694 */       for (int i = 0; i < this._attributes.getLength(); i++) {
/*  695 */         if (this._attributes.getLocalName(i).equals(localName)) {
/*  696 */           return this._attributes.getValue(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  701 */     return null;
/*      */   }
/*      */   
/*      */   public final int getAttributeCount() {
/*  705 */     if (this._eventType != 1) {
/*  706 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*      */     
/*  709 */     return this._attributes.getLength();
/*      */   }
/*      */   
/*      */   public final QName getAttributeName(int index) {
/*  713 */     if (this._eventType != 1) {
/*  714 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*  716 */     return this._attributes.getQualifiedName(index).getQName();
/*      */   }
/*      */   
/*      */   public final String getAttributeNamespace(int index) {
/*  720 */     if (this._eventType != 1) {
/*  721 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*      */     
/*  724 */     return this._attributes.getURI(index);
/*      */   }
/*      */   
/*      */   public final String getAttributeLocalName(int index) {
/*  728 */     if (this._eventType != 1) {
/*  729 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*  731 */     return this._attributes.getLocalName(index);
/*      */   }
/*      */   
/*      */   public final String getAttributePrefix(int index) {
/*  735 */     if (this._eventType != 1) {
/*  736 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*  738 */     return this._attributes.getPrefix(index);
/*      */   }
/*      */   
/*      */   public final String getAttributeType(int index) {
/*  742 */     if (this._eventType != 1) {
/*  743 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*  745 */     return this._attributes.getType(index);
/*      */   }
/*      */   
/*      */   public final String getAttributeValue(int index) {
/*  749 */     if (this._eventType != 1) {
/*  750 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*  752 */     return this._attributes.getValue(index);
/*      */   }
/*      */   
/*      */   public final boolean isAttributeSpecified(int index) {
/*  756 */     return false;
/*      */   }
/*      */   
/*      */   public final int getNamespaceCount() {
/*  760 */     if (this._eventType == 1 || this._eventType == 2) {
/*  761 */       return (this._currentNamespaceAIIsEnd > 0) ? (this._currentNamespaceAIIsEnd - this._currentNamespaceAIIsStart) : 0;
/*      */     }
/*  763 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetNamespaceCount"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getNamespacePrefix(int index) {
/*  768 */     if (this._eventType == 1 || this._eventType == 2) {
/*  769 */       return this._namespaceAIIsPrefix[this._currentNamespaceAIIsStart + index];
/*      */     }
/*  771 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetNamespacePrefix"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getNamespaceURI(int index) {
/*  776 */     if (this._eventType == 1 || this._eventType == 2) {
/*  777 */       return this._namespaceAIIsNamespaceName[this._currentNamespaceAIIsStart + index];
/*      */     }
/*  779 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetNamespacePrefix"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final NamespaceContext getNamespaceContext() {
/*  784 */     return this._nsContext;
/*      */   }
/*      */   
/*      */   public final int getEventType() {
/*  788 */     return this._eventType;
/*      */   }
/*      */   
/*      */   public final String getText() {
/*  792 */     if (this._characters == null) {
/*  793 */       checkTextState();
/*      */     }
/*      */     
/*  796 */     return new String(this._characters, this._charactersOffset, this._charactersLength);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final char[] getTextCharacters() {
/*  802 */     if (this._characters == null) {
/*  803 */       checkTextState();
/*      */     }
/*      */     
/*  806 */     return this._characters;
/*      */   }
/*      */   
/*      */   public final int getTextStart() {
/*  810 */     if (this._characters == null) {
/*  811 */       checkTextState();
/*      */     }
/*      */     
/*  814 */     return this._charactersOffset;
/*      */   }
/*      */   
/*      */   public final int getTextLength() {
/*  818 */     if (this._characters == null) {
/*  819 */       checkTextState();
/*      */     }
/*      */     
/*  822 */     return this._charactersLength;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getTextCharacters(int sourceStart, char[] target, int targetStart, int length) throws XMLStreamException {
/*  827 */     if (this._characters == null) {
/*  828 */       checkTextState();
/*      */     }
/*      */     
/*      */     try {
/*  832 */       System.arraycopy(this._characters, sourceStart, target, targetStart, length);
/*      */       
/*  834 */       return length;
/*  835 */     } catch (IndexOutOfBoundsException e) {
/*  836 */       throw new XMLStreamException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void checkTextState() {
/*  841 */     if (this._algorithmData == null) {
/*  842 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.InvalidStateForText"));
/*      */     }
/*      */     
/*      */     try {
/*  846 */       convertEncodingAlgorithmDataToCharacters();
/*  847 */     } catch (Exception e) {
/*  848 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.InvalidStateForText"));
/*      */     } 
/*      */   }
/*      */   
/*      */   public final String getEncoding() {
/*  853 */     return this._characterEncodingScheme;
/*      */   }
/*      */   
/*      */   public final boolean hasText() {
/*  857 */     return (this._characters != null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Location getLocation() {
/*  863 */     return EventLocation.getNilLocation();
/*      */   }
/*      */   
/*      */   public final QName getName() {
/*  867 */     if (this._eventType == 1 || this._eventType == 2) {
/*  868 */       return this._qualifiedName.getQName();
/*      */     }
/*  870 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetName"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getLocalName() {
/*  875 */     if (this._eventType == 1 || this._eventType == 2) {
/*  876 */       return this._qualifiedName.localName;
/*      */     }
/*  878 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetLocalName"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean hasName() {
/*  883 */     return (this._eventType == 1 || this._eventType == 2);
/*      */   }
/*      */   
/*      */   public final String getNamespaceURI() {
/*  887 */     if (this._eventType == 1 || this._eventType == 2) {
/*  888 */       return this._qualifiedName.namespaceName;
/*      */     }
/*  890 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetNamespaceURI"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getPrefix() {
/*  895 */     if (this._eventType == 1 || this._eventType == 2) {
/*  896 */       return this._qualifiedName.prefix;
/*      */     }
/*  898 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetPrefix"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getVersion() {
/*  903 */     return null;
/*      */   }
/*      */   
/*      */   public final boolean isStandalone() {
/*  907 */     return false;
/*      */   }
/*      */   
/*      */   public final boolean standaloneSet() {
/*  911 */     return false;
/*      */   }
/*      */   
/*      */   public final String getCharacterEncodingScheme() {
/*  915 */     return null;
/*      */   }
/*      */   
/*      */   public final String getPITarget() {
/*  919 */     if (this._eventType != 3) {
/*  920 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetPITarget"));
/*      */     }
/*      */     
/*  923 */     return this._piTarget;
/*      */   }
/*      */   
/*      */   public final String getPIData() {
/*  927 */     if (this._eventType != 3) {
/*  928 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetPIData"));
/*      */     }
/*      */     
/*  931 */     return this._piData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getNameString() {
/*  938 */     if (this._eventType == 1 || this._eventType == 2) {
/*  939 */       return this._qualifiedName.getQNameString();
/*      */     }
/*  941 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetName"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getAttributeNameString(int index) {
/*  946 */     if (this._eventType != 1) {
/*  947 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.invalidCallingGetAttributeValue"));
/*      */     }
/*  949 */     return this._attributes.getQualifiedName(index).getQNameString();
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getTextAlgorithmURI() {
/*  954 */     return this._algorithmURI;
/*      */   }
/*      */   
/*      */   public final int getTextAlgorithmIndex() {
/*  958 */     return this._algorithmId;
/*      */   }
/*      */   
/*      */   public final byte[] getTextAlgorithmBytes() {
/*  962 */     return this._algorithmData;
/*      */   }
/*      */   
/*      */   public final byte[] getTextAlgorithmBytesClone() {
/*  966 */     if (this._algorithmData == null) {
/*  967 */       return null;
/*      */     }
/*      */     
/*  970 */     byte[] algorithmData = new byte[this._algorithmDataLength];
/*  971 */     System.arraycopy(this._algorithmData, this._algorithmDataOffset, algorithmData, 0, this._algorithmDataLength);
/*  972 */     return algorithmData;
/*      */   }
/*      */   
/*      */   public final int getTextAlgorithmStart() {
/*  976 */     return this._algorithmDataOffset;
/*      */   }
/*      */   
/*      */   public final int getTextAlgorithmLength() {
/*  980 */     return this._algorithmDataLength;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getTextAlgorithmBytes(int sourceStart, byte[] target, int targetStart, int length) throws XMLStreamException {
/*      */     try {
/*  986 */       System.arraycopy(this._algorithmData, sourceStart, target, targetStart, length);
/*      */       
/*  988 */       return length;
/*  989 */     } catch (IndexOutOfBoundsException e) {
/*  990 */       throw new XMLStreamException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void processDII() throws FastInfosetException, IOException {
/*  999 */     int b = read();
/* 1000 */     if (b > 0) {
/* 1001 */       processDIIOptionalProperties(b);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void processDIIOptionalProperties(int b) throws FastInfosetException, IOException {
/* 1007 */     if (b == 32) {
/* 1008 */       decodeInitialVocabulary();
/*      */       
/*      */       return;
/*      */     } 
/* 1012 */     if ((b & 0x40) > 0) {
/* 1013 */       decodeAdditionalData();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1020 */     if ((b & 0x20) > 0) {
/* 1021 */       decodeInitialVocabulary();
/*      */     }
/*      */     
/* 1024 */     if ((b & 0x10) > 0) {
/* 1025 */       decodeNotations();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1035 */     if ((b & 0x8) > 0) {
/* 1036 */       decodeUnparsedEntities();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1046 */     if ((b & 0x4) > 0) {
/* 1047 */       this._characterEncodingScheme = decodeCharacterEncodingScheme();
/*      */     }
/*      */     
/* 1050 */     if ((b & 0x2) > 0) {
/* 1051 */       boolean standalone = (read() > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1058 */     if ((b & 0x1) > 0) {
/* 1059 */       String version = decodeVersion();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void resizeNamespaceAIIs() {
/* 1069 */     String[] namespaceAIIsPrefix = new String[this._namespaceAIIsIndex * 2];
/* 1070 */     System.arraycopy(this._namespaceAIIsPrefix, 0, namespaceAIIsPrefix, 0, this._namespaceAIIsIndex);
/* 1071 */     this._namespaceAIIsPrefix = namespaceAIIsPrefix;
/*      */     
/* 1073 */     String[] namespaceAIIsNamespaceName = new String[this._namespaceAIIsIndex * 2];
/* 1074 */     System.arraycopy(this._namespaceAIIsNamespaceName, 0, namespaceAIIsNamespaceName, 0, this._namespaceAIIsIndex);
/* 1075 */     this._namespaceAIIsNamespaceName = namespaceAIIsNamespaceName;
/*      */     
/* 1077 */     int[] namespaceAIIsPrefixIndex = new int[this._namespaceAIIsIndex * 2];
/* 1078 */     System.arraycopy(this._namespaceAIIsPrefixIndex, 0, namespaceAIIsPrefixIndex, 0, this._namespaceAIIsIndex);
/* 1079 */     this._namespaceAIIsPrefixIndex = namespaceAIIsPrefixIndex;
/*      */   }
/*      */   protected final void processEIIWithNamespaces(boolean hasAttributes) throws FastInfosetException, IOException {
/*      */     QualifiedName qn;
/* 1083 */     if (++this._prefixTable._declarationId == Integer.MAX_VALUE) {
/* 1084 */       this._prefixTable.clearDeclarationIds();
/*      */     }
/*      */     
/* 1087 */     this._currentNamespaceAIIsStart = this._namespaceAIIsIndex;
/* 1088 */     String prefix = "", namespaceName = "";
/* 1089 */     int b = read();
/* 1090 */     while ((b & 0xFC) == 204) {
/* 1091 */       if (this._namespaceAIIsIndex == this._namespaceAIIsPrefix.length) {
/* 1092 */         resizeNamespaceAIIs();
/*      */       }
/*      */       
/* 1095 */       switch (b & 0x3) {
/*      */ 
/*      */         
/*      */         case 0:
/* 1099 */           this._namespaceAIIsNamespaceName[this._namespaceAIIsIndex] = ""; this._namespaceAIIsPrefix[this._namespaceAIIsIndex] = ""; prefix = namespaceName = "";
/*      */ 
/*      */ 
/*      */           
/* 1103 */           this._namespaceAIIsPrefixIndex[this._namespaceAIIsIndex++] = -1; this._namespaceNameIndex = this._prefixIndex = -1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/* 1108 */           prefix = this._namespaceAIIsPrefix[this._namespaceAIIsIndex] = "";
/* 1109 */           namespaceName = this._namespaceAIIsNamespaceName[this._namespaceAIIsIndex] = decodeIdentifyingNonEmptyStringOnFirstBitAsNamespaceName(false);
/*      */ 
/*      */           
/* 1112 */           this._prefixIndex = this._namespaceAIIsPrefixIndex[this._namespaceAIIsIndex++] = -1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/* 1117 */           prefix = this._namespaceAIIsPrefix[this._namespaceAIIsIndex] = decodeIdentifyingNonEmptyStringOnFirstBitAsPrefix(false);
/*      */           
/* 1119 */           namespaceName = this._namespaceAIIsNamespaceName[this._namespaceAIIsIndex] = "";
/*      */           
/* 1121 */           this._namespaceNameIndex = -1;
/* 1122 */           this._namespaceAIIsPrefixIndex[this._namespaceAIIsIndex++] = this._prefixIndex;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/* 1127 */           prefix = this._namespaceAIIsPrefix[this._namespaceAIIsIndex] = decodeIdentifyingNonEmptyStringOnFirstBitAsPrefix(true);
/*      */           
/* 1129 */           namespaceName = this._namespaceAIIsNamespaceName[this._namespaceAIIsIndex] = decodeIdentifyingNonEmptyStringOnFirstBitAsNamespaceName(true);
/*      */ 
/*      */           
/* 1132 */           this._namespaceAIIsPrefixIndex[this._namespaceAIIsIndex++] = this._prefixIndex;
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 1137 */       this._prefixTable.pushScopeWithPrefixEntry(prefix, namespaceName, this._prefixIndex, this._namespaceNameIndex);
/*      */       
/* 1139 */       b = read();
/*      */     } 
/* 1141 */     if (b != 240) {
/* 1142 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.EIInamespaceNameNotTerminatedCorrectly"));
/*      */     }
/* 1144 */     this._currentNamespaceAIIsEnd = this._namespaceAIIsIndex;
/*      */     
/* 1146 */     b = read();
/* 1147 */     switch (DecoderStateTables.EII[b]) {
/*      */       case 0:
/* 1149 */         processEII(this._elementNameTable._array[b], hasAttributes);
/*      */         return;
/*      */       case 2:
/* 1152 */         processEII(processEIIIndexMedium(b), hasAttributes);
/*      */         return;
/*      */       case 3:
/* 1155 */         processEII(processEIIIndexLarge(b), hasAttributes);
/*      */         return;
/*      */       
/*      */       case 5:
/* 1159 */         qn = processLiteralQualifiedName(b & 0x3);
/*      */         
/* 1161 */         this._elementNameTable.add(qn);
/* 1162 */         processEII(qn, hasAttributes);
/*      */         return;
/*      */     } 
/*      */     
/* 1166 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingEIIAfterAIIs"));
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void processEII(QualifiedName name, boolean hasAttributes) throws FastInfosetException, IOException {
/* 1171 */     if (this._prefixTable._currentInScope[name.prefixIndex] != name.namespaceNameIndex) {
/* 1172 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.qnameOfEIINotInScope"));
/*      */     }
/*      */     
/* 1175 */     this._eventType = 1;
/* 1176 */     this._qualifiedName = name;
/*      */     
/* 1178 */     if (this._clearAttributes) {
/* 1179 */       this._attributes.clear();
/* 1180 */       this._clearAttributes = false;
/*      */     } 
/*      */     
/* 1183 */     if (hasAttributes) {
/* 1184 */       processAIIs();
/*      */     }
/*      */ 
/*      */     
/* 1188 */     this._stackCount++;
/* 1189 */     if (this._stackCount == this._qNameStack.length) {
/* 1190 */       QualifiedName[] qNameStack = new QualifiedName[this._qNameStack.length * 2];
/* 1191 */       System.arraycopy(this._qNameStack, 0, qNameStack, 0, this._qNameStack.length);
/* 1192 */       this._qNameStack = qNameStack;
/*      */       
/* 1194 */       int[] namespaceAIIsStartStack = new int[this._namespaceAIIsStartStack.length * 2];
/* 1195 */       System.arraycopy(this._namespaceAIIsStartStack, 0, namespaceAIIsStartStack, 0, this._namespaceAIIsStartStack.length);
/* 1196 */       this._namespaceAIIsStartStack = namespaceAIIsStartStack;
/*      */       
/* 1198 */       int[] namespaceAIIsEndStack = new int[this._namespaceAIIsEndStack.length * 2];
/* 1199 */       System.arraycopy(this._namespaceAIIsEndStack, 0, namespaceAIIsEndStack, 0, this._namespaceAIIsEndStack.length);
/* 1200 */       this._namespaceAIIsEndStack = namespaceAIIsEndStack;
/*      */     } 
/* 1202 */     this._qNameStack[this._stackCount] = this._qualifiedName;
/* 1203 */     this._namespaceAIIsStartStack[this._stackCount] = this._currentNamespaceAIIsStart;
/* 1204 */     this._namespaceAIIsEndStack[this._stackCount] = this._currentNamespaceAIIsEnd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void processAIIs() throws FastInfosetException, IOException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   4: dup
/*      */     //   5: getfield _currentIteration : I
/*      */     //   8: iconst_1
/*      */     //   9: iadd
/*      */     //   10: dup_x1
/*      */     //   11: putfield _currentIteration : I
/*      */     //   14: ldc 2147483647
/*      */     //   16: if_icmpne -> 26
/*      */     //   19: aload_0
/*      */     //   20: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   23: invokevirtual clear : ()V
/*      */     //   26: aload_0
/*      */     //   27: iconst_1
/*      */     //   28: putfield _clearAttributes : Z
/*      */     //   31: iconst_0
/*      */     //   32: istore #4
/*      */     //   34: aload_0
/*      */     //   35: invokevirtual read : ()I
/*      */     //   38: istore_2
/*      */     //   39: getstatic com/sun/xml/fastinfoset/DecoderStateTables.AII : [I
/*      */     //   42: iload_2
/*      */     //   43: iaload
/*      */     //   44: tableswitch default -> 210, 0 -> 84, 1 -> 97, 2 -> 128, 3 -> 168, 4 -> 204, 5 -> 199
/*      */     //   84: aload_0
/*      */     //   85: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   88: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   91: iload_2
/*      */     //   92: aaload
/*      */     //   93: astore_1
/*      */     //   94: goto -> 226
/*      */     //   97: iload_2
/*      */     //   98: bipush #31
/*      */     //   100: iand
/*      */     //   101: bipush #8
/*      */     //   103: ishl
/*      */     //   104: aload_0
/*      */     //   105: invokevirtual read : ()I
/*      */     //   108: ior
/*      */     //   109: bipush #64
/*      */     //   111: iadd
/*      */     //   112: istore #5
/*      */     //   114: aload_0
/*      */     //   115: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   118: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   121: iload #5
/*      */     //   123: aaload
/*      */     //   124: astore_1
/*      */     //   125: goto -> 226
/*      */     //   128: iload_2
/*      */     //   129: bipush #15
/*      */     //   131: iand
/*      */     //   132: bipush #16
/*      */     //   134: ishl
/*      */     //   135: aload_0
/*      */     //   136: invokevirtual read : ()I
/*      */     //   139: bipush #8
/*      */     //   141: ishl
/*      */     //   142: ior
/*      */     //   143: aload_0
/*      */     //   144: invokevirtual read : ()I
/*      */     //   147: ior
/*      */     //   148: sipush #8256
/*      */     //   151: iadd
/*      */     //   152: istore #5
/*      */     //   154: aload_0
/*      */     //   155: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   158: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   161: iload #5
/*      */     //   163: aaload
/*      */     //   164: astore_1
/*      */     //   165: goto -> 226
/*      */     //   168: aload_0
/*      */     //   169: iload_2
/*      */     //   170: iconst_3
/*      */     //   171: iand
/*      */     //   172: invokevirtual processLiteralQualifiedName : (I)Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   175: astore_1
/*      */     //   176: aload_1
/*      */     //   177: aload_0
/*      */     //   178: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   181: pop
/*      */     //   182: sipush #256
/*      */     //   185: invokevirtual createAttributeValues : (I)V
/*      */     //   188: aload_0
/*      */     //   189: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   192: aload_1
/*      */     //   193: invokevirtual add : (Lcom/sun/xml/fastinfoset/QualifiedName;)V
/*      */     //   196: goto -> 226
/*      */     //   199: aload_0
/*      */     //   200: iconst_1
/*      */     //   201: putfield _internalState : I
/*      */     //   204: iconst_1
/*      */     //   205: istore #4
/*      */     //   207: goto -> 953
/*      */     //   210: new org/jvnet/fastinfoset/FastInfosetException
/*      */     //   213: dup
/*      */     //   214: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   217: ldc 'message.decodingAIIs'
/*      */     //   219: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   222: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   225: athrow
/*      */     //   226: aload_1
/*      */     //   227: getfield prefixIndex : I
/*      */     //   230: ifle -> 268
/*      */     //   233: aload_0
/*      */     //   234: getfield _prefixTable : Lcom/sun/xml/fastinfoset/util/PrefixArray;
/*      */     //   237: getfield _currentInScope : [I
/*      */     //   240: aload_1
/*      */     //   241: getfield prefixIndex : I
/*      */     //   244: iaload
/*      */     //   245: aload_1
/*      */     //   246: getfield namespaceNameIndex : I
/*      */     //   249: if_icmpeq -> 268
/*      */     //   252: new org/jvnet/fastinfoset/FastInfosetException
/*      */     //   255: dup
/*      */     //   256: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   259: ldc 'message.AIIqNameNotInScope'
/*      */     //   261: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   264: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   267: athrow
/*      */     //   268: aload_0
/*      */     //   269: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   272: aload_1
/*      */     //   273: getfield attributeHash : I
/*      */     //   276: aload_1
/*      */     //   277: getfield attributeId : I
/*      */     //   280: invokevirtual checkForDuplicateAttribute : (II)V
/*      */     //   283: aload_0
/*      */     //   284: invokevirtual read : ()I
/*      */     //   287: istore_2
/*      */     //   288: getstatic com/sun/xml/fastinfoset/DecoderStateTables.NISTRING : [I
/*      */     //   291: iload_2
/*      */     //   292: iaload
/*      */     //   293: tableswitch default -> 937, 0 -> 356, 1 -> 399, 2 -> 443, 3 -> 512, 4 -> 555, 5 -> 599, 6 -> 668, 7 -> 749, 8 -> 816, 9 -> 839, 10 -> 877, 11 -> 924
/*      */     //   356: aload_0
/*      */     //   357: iload_2
/*      */     //   358: bipush #7
/*      */     //   360: iand
/*      */     //   361: iconst_1
/*      */     //   362: iadd
/*      */     //   363: putfield _octetBufferLength : I
/*      */     //   366: aload_0
/*      */     //   367: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*      */     //   370: astore_3
/*      */     //   371: iload_2
/*      */     //   372: bipush #64
/*      */     //   374: iand
/*      */     //   375: ifle -> 387
/*      */     //   378: aload_0
/*      */     //   379: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   382: aload_3
/*      */     //   383: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   386: pop
/*      */     //   387: aload_0
/*      */     //   388: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   391: aload_1
/*      */     //   392: aload_3
/*      */     //   393: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   396: goto -> 953
/*      */     //   399: aload_0
/*      */     //   400: aload_0
/*      */     //   401: invokevirtual read : ()I
/*      */     //   404: bipush #9
/*      */     //   406: iadd
/*      */     //   407: putfield _octetBufferLength : I
/*      */     //   410: aload_0
/*      */     //   411: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*      */     //   414: astore_3
/*      */     //   415: iload_2
/*      */     //   416: bipush #64
/*      */     //   418: iand
/*      */     //   419: ifle -> 431
/*      */     //   422: aload_0
/*      */     //   423: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   426: aload_3
/*      */     //   427: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   430: pop
/*      */     //   431: aload_0
/*      */     //   432: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   435: aload_1
/*      */     //   436: aload_3
/*      */     //   437: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   440: goto -> 953
/*      */     //   443: aload_0
/*      */     //   444: aload_0
/*      */     //   445: invokevirtual read : ()I
/*      */     //   448: bipush #24
/*      */     //   450: ishl
/*      */     //   451: aload_0
/*      */     //   452: invokevirtual read : ()I
/*      */     //   455: bipush #16
/*      */     //   457: ishl
/*      */     //   458: ior
/*      */     //   459: aload_0
/*      */     //   460: invokevirtual read : ()I
/*      */     //   463: bipush #8
/*      */     //   465: ishl
/*      */     //   466: ior
/*      */     //   467: aload_0
/*      */     //   468: invokevirtual read : ()I
/*      */     //   471: ior
/*      */     //   472: sipush #265
/*      */     //   475: iadd
/*      */     //   476: putfield _octetBufferLength : I
/*      */     //   479: aload_0
/*      */     //   480: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*      */     //   483: astore_3
/*      */     //   484: iload_2
/*      */     //   485: bipush #64
/*      */     //   487: iand
/*      */     //   488: ifle -> 500
/*      */     //   491: aload_0
/*      */     //   492: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   495: aload_3
/*      */     //   496: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   499: pop
/*      */     //   500: aload_0
/*      */     //   501: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   504: aload_1
/*      */     //   505: aload_3
/*      */     //   506: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   509: goto -> 953
/*      */     //   512: aload_0
/*      */     //   513: iload_2
/*      */     //   514: bipush #7
/*      */     //   516: iand
/*      */     //   517: iconst_1
/*      */     //   518: iadd
/*      */     //   519: putfield _octetBufferLength : I
/*      */     //   522: aload_0
/*      */     //   523: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*      */     //   526: astore_3
/*      */     //   527: iload_2
/*      */     //   528: bipush #64
/*      */     //   530: iand
/*      */     //   531: ifle -> 543
/*      */     //   534: aload_0
/*      */     //   535: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   538: aload_3
/*      */     //   539: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   542: pop
/*      */     //   543: aload_0
/*      */     //   544: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   547: aload_1
/*      */     //   548: aload_3
/*      */     //   549: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   552: goto -> 953
/*      */     //   555: aload_0
/*      */     //   556: aload_0
/*      */     //   557: invokevirtual read : ()I
/*      */     //   560: bipush #9
/*      */     //   562: iadd
/*      */     //   563: putfield _octetBufferLength : I
/*      */     //   566: aload_0
/*      */     //   567: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*      */     //   570: astore_3
/*      */     //   571: iload_2
/*      */     //   572: bipush #64
/*      */     //   574: iand
/*      */     //   575: ifle -> 587
/*      */     //   578: aload_0
/*      */     //   579: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   582: aload_3
/*      */     //   583: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   586: pop
/*      */     //   587: aload_0
/*      */     //   588: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   591: aload_1
/*      */     //   592: aload_3
/*      */     //   593: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   596: goto -> 953
/*      */     //   599: aload_0
/*      */     //   600: aload_0
/*      */     //   601: invokevirtual read : ()I
/*      */     //   604: bipush #24
/*      */     //   606: ishl
/*      */     //   607: aload_0
/*      */     //   608: invokevirtual read : ()I
/*      */     //   611: bipush #16
/*      */     //   613: ishl
/*      */     //   614: ior
/*      */     //   615: aload_0
/*      */     //   616: invokevirtual read : ()I
/*      */     //   619: bipush #8
/*      */     //   621: ishl
/*      */     //   622: ior
/*      */     //   623: aload_0
/*      */     //   624: invokevirtual read : ()I
/*      */     //   627: ior
/*      */     //   628: sipush #265
/*      */     //   631: iadd
/*      */     //   632: putfield _octetBufferLength : I
/*      */     //   635: aload_0
/*      */     //   636: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*      */     //   639: astore_3
/*      */     //   640: iload_2
/*      */     //   641: bipush #64
/*      */     //   643: iand
/*      */     //   644: ifle -> 656
/*      */     //   647: aload_0
/*      */     //   648: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   651: aload_3
/*      */     //   652: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   655: pop
/*      */     //   656: aload_0
/*      */     //   657: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   660: aload_1
/*      */     //   661: aload_3
/*      */     //   662: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   665: goto -> 953
/*      */     //   668: iload_2
/*      */     //   669: bipush #64
/*      */     //   671: iand
/*      */     //   672: ifle -> 679
/*      */     //   675: iconst_1
/*      */     //   676: goto -> 680
/*      */     //   679: iconst_0
/*      */     //   680: istore #5
/*      */     //   682: aload_0
/*      */     //   683: iload_2
/*      */     //   684: bipush #15
/*      */     //   686: iand
/*      */     //   687: iconst_4
/*      */     //   688: ishl
/*      */     //   689: putfield _identifier : I
/*      */     //   692: aload_0
/*      */     //   693: invokevirtual read : ()I
/*      */     //   696: istore_2
/*      */     //   697: aload_0
/*      */     //   698: dup
/*      */     //   699: getfield _identifier : I
/*      */     //   702: iload_2
/*      */     //   703: sipush #240
/*      */     //   706: iand
/*      */     //   707: iconst_4
/*      */     //   708: ishr
/*      */     //   709: ior
/*      */     //   710: putfield _identifier : I
/*      */     //   713: aload_0
/*      */     //   714: iload_2
/*      */     //   715: invokevirtual decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit : (I)V
/*      */     //   718: aload_0
/*      */     //   719: invokevirtual decodeRestrictedAlphabetAsString : ()Ljava/lang/String;
/*      */     //   722: astore_3
/*      */     //   723: iload #5
/*      */     //   725: ifeq -> 737
/*      */     //   728: aload_0
/*      */     //   729: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   732: aload_3
/*      */     //   733: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   736: pop
/*      */     //   737: aload_0
/*      */     //   738: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   741: aload_1
/*      */     //   742: aload_3
/*      */     //   743: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   746: goto -> 953
/*      */     //   749: iload_2
/*      */     //   750: bipush #64
/*      */     //   752: iand
/*      */     //   753: ifle -> 772
/*      */     //   756: new org/jvnet/fastinfoset/EncodingAlgorithmException
/*      */     //   759: dup
/*      */     //   760: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   763: ldc 'message.addToTableNotSupported'
/*      */     //   765: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   768: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   771: athrow
/*      */     //   772: aload_0
/*      */     //   773: iload_2
/*      */     //   774: bipush #15
/*      */     //   776: iand
/*      */     //   777: iconst_4
/*      */     //   778: ishl
/*      */     //   779: putfield _identifier : I
/*      */     //   782: aload_0
/*      */     //   783: invokevirtual read : ()I
/*      */     //   786: istore_2
/*      */     //   787: aload_0
/*      */     //   788: dup
/*      */     //   789: getfield _identifier : I
/*      */     //   792: iload_2
/*      */     //   793: sipush #240
/*      */     //   796: iand
/*      */     //   797: iconst_4
/*      */     //   798: ishr
/*      */     //   799: ior
/*      */     //   800: putfield _identifier : I
/*      */     //   803: aload_0
/*      */     //   804: iload_2
/*      */     //   805: invokevirtual decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit : (I)V
/*      */     //   808: aload_0
/*      */     //   809: aload_1
/*      */     //   810: invokevirtual processAIIEncodingAlgorithm : (Lcom/sun/xml/fastinfoset/QualifiedName;)V
/*      */     //   813: goto -> 953
/*      */     //   816: aload_0
/*      */     //   817: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   820: aload_1
/*      */     //   821: aload_0
/*      */     //   822: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   825: getfield _array : [Ljava/lang/String;
/*      */     //   828: iload_2
/*      */     //   829: bipush #63
/*      */     //   831: iand
/*      */     //   832: aaload
/*      */     //   833: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   836: goto -> 953
/*      */     //   839: iload_2
/*      */     //   840: bipush #31
/*      */     //   842: iand
/*      */     //   843: bipush #8
/*      */     //   845: ishl
/*      */     //   846: aload_0
/*      */     //   847: invokevirtual read : ()I
/*      */     //   850: ior
/*      */     //   851: bipush #64
/*      */     //   853: iadd
/*      */     //   854: istore #5
/*      */     //   856: aload_0
/*      */     //   857: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   860: aload_1
/*      */     //   861: aload_0
/*      */     //   862: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   865: getfield _array : [Ljava/lang/String;
/*      */     //   868: iload #5
/*      */     //   870: aaload
/*      */     //   871: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   874: goto -> 953
/*      */     //   877: iload_2
/*      */     //   878: bipush #15
/*      */     //   880: iand
/*      */     //   881: bipush #16
/*      */     //   883: ishl
/*      */     //   884: aload_0
/*      */     //   885: invokevirtual read : ()I
/*      */     //   888: bipush #8
/*      */     //   890: ishl
/*      */     //   891: ior
/*      */     //   892: aload_0
/*      */     //   893: invokevirtual read : ()I
/*      */     //   896: ior
/*      */     //   897: sipush #8256
/*      */     //   900: iadd
/*      */     //   901: istore #5
/*      */     //   903: aload_0
/*      */     //   904: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   907: aload_1
/*      */     //   908: aload_0
/*      */     //   909: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   912: getfield _array : [Ljava/lang/String;
/*      */     //   915: iload #5
/*      */     //   917: aaload
/*      */     //   918: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   921: goto -> 953
/*      */     //   924: aload_0
/*      */     //   925: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   928: aload_1
/*      */     //   929: ldc ''
/*      */     //   931: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   934: goto -> 953
/*      */     //   937: new org/jvnet/fastinfoset/FastInfosetException
/*      */     //   940: dup
/*      */     //   941: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   944: ldc 'message.decodingAIIValue'
/*      */     //   946: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   949: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   952: athrow
/*      */     //   953: iload #4
/*      */     //   955: ifeq -> 34
/*      */     //   958: aload_0
/*      */     //   959: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   962: aload_0
/*      */     //   963: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   966: getfield _poolHead : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier$Entry;
/*      */     //   969: putfield _poolCurrent : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier$Entry;
/*      */     //   972: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1212	-> 0
/*      */     //   #1213	-> 19
/*      */     //   #1216	-> 26
/*      */     //   #1217	-> 31
/*      */     //   #1220	-> 34
/*      */     //   #1221	-> 39
/*      */     //   #1223	-> 84
/*      */     //   #1224	-> 94
/*      */     //   #1227	-> 97
/*      */     //   #1229	-> 114
/*      */     //   #1230	-> 125
/*      */     //   #1234	-> 128
/*      */     //   #1236	-> 154
/*      */     //   #1237	-> 165
/*      */     //   #1240	-> 168
/*      */     //   #1242	-> 176
/*      */     //   #1243	-> 188
/*      */     //   #1244	-> 196
/*      */     //   #1246	-> 199
/*      */     //   #1248	-> 204
/*      */     //   #1250	-> 207
/*      */     //   #1252	-> 210
/*      */     //   #1257	-> 226
/*      */     //   #1258	-> 252
/*      */     //   #1261	-> 268
/*      */     //   #1263	-> 283
/*      */     //   #1264	-> 288
/*      */     //   #1266	-> 356
/*      */     //   #1267	-> 366
/*      */     //   #1268	-> 371
/*      */     //   #1269	-> 378
/*      */     //   #1272	-> 387
/*      */     //   #1273	-> 396
/*      */     //   #1275	-> 399
/*      */     //   #1276	-> 410
/*      */     //   #1277	-> 415
/*      */     //   #1278	-> 422
/*      */     //   #1281	-> 431
/*      */     //   #1282	-> 440
/*      */     //   #1284	-> 443
/*      */     //   #1289	-> 479
/*      */     //   #1290	-> 484
/*      */     //   #1291	-> 491
/*      */     //   #1294	-> 500
/*      */     //   #1295	-> 509
/*      */     //   #1297	-> 512
/*      */     //   #1298	-> 522
/*      */     //   #1299	-> 527
/*      */     //   #1300	-> 534
/*      */     //   #1303	-> 543
/*      */     //   #1304	-> 552
/*      */     //   #1306	-> 555
/*      */     //   #1307	-> 566
/*      */     //   #1308	-> 571
/*      */     //   #1309	-> 578
/*      */     //   #1312	-> 587
/*      */     //   #1313	-> 596
/*      */     //   #1315	-> 599
/*      */     //   #1320	-> 635
/*      */     //   #1321	-> 640
/*      */     //   #1322	-> 647
/*      */     //   #1325	-> 656
/*      */     //   #1326	-> 665
/*      */     //   #1329	-> 668
/*      */     //   #1331	-> 682
/*      */     //   #1332	-> 692
/*      */     //   #1333	-> 697
/*      */     //   #1335	-> 713
/*      */     //   #1337	-> 718
/*      */     //   #1338	-> 723
/*      */     //   #1339	-> 728
/*      */     //   #1342	-> 737
/*      */     //   #1343	-> 746
/*      */     //   #1347	-> 749
/*      */     //   #1348	-> 756
/*      */     //   #1352	-> 772
/*      */     //   #1353	-> 782
/*      */     //   #1354	-> 787
/*      */     //   #1356	-> 803
/*      */     //   #1357	-> 808
/*      */     //   #1358	-> 813
/*      */     //   #1361	-> 816
/*      */     //   #1363	-> 836
/*      */     //   #1366	-> 839
/*      */     //   #1369	-> 856
/*      */     //   #1371	-> 874
/*      */     //   #1375	-> 877
/*      */     //   #1378	-> 903
/*      */     //   #1380	-> 921
/*      */     //   #1383	-> 924
/*      */     //   #1384	-> 934
/*      */     //   #1386	-> 937
/*      */     //   #1389	-> 953
/*      */     //   #1392	-> 958
/*      */     //   #1393	-> 972
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   114	14	5	i	I
/*      */     //   154	14	5	i	I
/*      */     //   682	67	5	addToTable	Z
/*      */     //   856	21	5	index	I
/*      */     //   903	21	5	index	I
/*      */     //   94	859	1	name	Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   0	973	0	this	Lcom/sun/xml/fastinfoset/stax/StAXDocumentParser;
/*      */     //   39	934	2	b	I
/*      */     //   371	602	3	value	Ljava/lang/String;
/*      */     //   34	939	4	terminate	Z
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final QualifiedName processEIIIndexMedium(int b) throws FastInfosetException, IOException {
/* 1396 */     int i = ((b & 0x7) << 8 | read()) + 32;
/*      */     
/* 1398 */     return this._elementNameTable._array[i];
/*      */   }
/*      */   
/*      */   protected final QualifiedName processEIIIndexLarge(int b) throws FastInfosetException, IOException {
/*      */     int i;
/* 1403 */     if ((b & 0x30) == 32) {
/*      */       
/* 1405 */       i = ((b & 0x7) << 16 | read() << 8 | read()) + 2080;
/*      */     }
/*      */     else {
/*      */       
/* 1409 */       i = ((read() & 0xF) << 16 | read() << 8 | read()) + 526368;
/*      */     } 
/*      */     
/* 1412 */     return this._elementNameTable._array[i];
/*      */   }
/*      */   
/*      */   protected final QualifiedName processLiteralQualifiedName(int state) throws FastInfosetException, IOException {
/* 1416 */     switch (state) {
/*      */       
/*      */       case 0:
/* 1419 */         return new QualifiedName("", "", decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), "", 0, -1, -1, this._identifier);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 1430 */         return new QualifiedName("", decodeIdentifyingNonEmptyStringIndexOnFirstBitAsNamespaceName(false), decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), "", 0, -1, this._namespaceNameIndex, this._identifier);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1441 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.qNameMissingNamespaceName"));
/*      */       
/*      */       case 3:
/* 1444 */         return new QualifiedName(decodeIdentifyingNonEmptyStringIndexOnFirstBitAsPrefix(true), decodeIdentifyingNonEmptyStringIndexOnFirstBitAsNamespaceName(true), decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), "", 0, this._prefixIndex, this._namespaceNameIndex, this._identifier);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1454 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingEII"));
/*      */   }
/*      */   
/*      */   protected final void processCommentII() throws FastInfosetException, IOException {
/*      */     CharArray ca;
/* 1459 */     this._eventType = 5;
/*      */     
/* 1461 */     switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */       case 0:
/* 1463 */         if (this._addToTable) {
/* 1464 */           this._v.otherString.add(new CharArray(this._charBuffer, 0, this._charBufferLength, true));
/*      */         }
/*      */         
/* 1467 */         this._characters = this._charBuffer;
/* 1468 */         this._charactersOffset = 0;
/* 1469 */         this._charactersLength = this._charBufferLength;
/*      */         break;
/*      */       case 2:
/* 1472 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.commentIIAlgorithmNotSupported"));
/*      */       case 1:
/* 1474 */         ca = this._v.otherString.get(this._integer);
/*      */         
/* 1476 */         this._characters = ca.ch;
/* 1477 */         this._charactersOffset = ca.start;
/* 1478 */         this._charactersLength = ca.length;
/*      */         break;
/*      */       case 3:
/* 1481 */         this._characters = this._charBuffer;
/* 1482 */         this._charactersOffset = 0;
/* 1483 */         this._charactersLength = 0;
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void processProcessingII() throws FastInfosetException, IOException {
/* 1489 */     this._eventType = 3;
/*      */     
/* 1491 */     this._piTarget = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*      */     
/* 1493 */     switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */       case 0:
/* 1495 */         this._piData = new String(this._charBuffer, 0, this._charBufferLength);
/* 1496 */         if (this._addToTable) {
/* 1497 */           this._v.otherString.add((CharArray)new CharArrayString(this._piData));
/*      */         }
/*      */         break;
/*      */       case 2:
/* 1501 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.processingIIWithEncodingAlgorithm"));
/*      */       case 1:
/* 1503 */         this._piData = this._v.otherString.get(this._integer).toString();
/*      */         break;
/*      */       case 3:
/* 1506 */         this._piData = "";
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void processCIIEncodingAlgorithm() throws FastInfosetException, IOException {
/* 1512 */     this._algorithmData = this._octetBuffer;
/* 1513 */     this._algorithmDataOffset = this._octetBufferStart;
/* 1514 */     this._algorithmDataLength = this._octetBufferLength;
/*      */     
/* 1516 */     if (this._algorithmId >= 32) {
/* 1517 */       this._algorithmURI = this._v.encodingAlgorithm.get(this._algorithmId - 32);
/* 1518 */       if (this._algorithmURI == null) {
/* 1519 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.URINotPresent", new Object[] { new Integer(this._identifier) }));
/*      */       }
/* 1521 */     } else if (this._algorithmId > 9) {
/*      */ 
/*      */ 
/*      */       
/* 1525 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.identifiers10to31Reserved"));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void processAIIEncodingAlgorithm(QualifiedName name) throws FastInfosetException, IOException {
/* 1530 */     String URI = null;
/* 1531 */     if (this._identifier >= 32) {
/* 1532 */       URI = this._v.encodingAlgorithm.get(this._identifier - 32);
/* 1533 */       if (URI == null) {
/* 1534 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.URINotPresent", new Object[] { new Integer(this._identifier) }));
/*      */       }
/* 1536 */     } else if (this._identifier >= 9) {
/* 1537 */       if (this._identifier == 9) {
/* 1538 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.CDATAAlgorithmNotSupported"));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1544 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.identifiers10to31Reserved"));
/*      */     } 
/*      */     
/* 1547 */     byte[] data = new byte[this._octetBufferLength];
/* 1548 */     System.arraycopy(this._octetBuffer, this._octetBufferStart, data, 0, this._octetBufferLength);
/* 1549 */     this._attributes.addAttributeWithAlgorithmData(name, URI, this._identifier, data);
/*      */   }
/*      */   
/*      */   protected final void convertEncodingAlgorithmDataToCharacters() throws FastInfosetException, IOException {
/* 1553 */     StringBuffer buffer = new StringBuffer();
/* 1554 */     if (this._algorithmId < 9)
/* 1555 */     { Object array = BuiltInEncodingAlgorithmFactory.table[this._algorithmId].decodeFromBytes(this._algorithmData, this._algorithmDataOffset, this._algorithmDataLength);
/*      */       
/* 1557 */       BuiltInEncodingAlgorithmFactory.table[this._algorithmId].convertToCharacters(array, buffer); }
/* 1558 */     else { if (this._algorithmId == 9) {
/* 1559 */         this._octetBufferOffset -= this._octetBufferLength;
/* 1560 */         decodeUtf8StringIntoCharBuffer();
/*      */         
/* 1562 */         this._characters = this._charBuffer;
/* 1563 */         this._charactersOffset = 0;
/* 1564 */         this._charactersLength = this._charBufferLength; return;
/*      */       } 
/* 1566 */       if (this._algorithmId >= 32) {
/* 1567 */         EncodingAlgorithm ea = (EncodingAlgorithm)this._registeredEncodingAlgorithms.get(this._algorithmURI);
/* 1568 */         if (ea != null) {
/* 1569 */           Object data = ea.decodeFromBytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/* 1570 */           ea.convertToCharacters(data, buffer);
/*      */         } else {
/* 1572 */           throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.algorithmDataCannotBeReported"));
/*      */         } 
/*      */       }  }
/*      */ 
/*      */     
/* 1577 */     this._characters = new char[buffer.length()];
/* 1578 */     buffer.getChars(0, buffer.length(), this._characters, 0);
/* 1579 */     this._charactersOffset = 0;
/* 1580 */     this._charactersLength = this._characters.length;
/*      */   }
/*      */   protected class NamespaceContextImpl implements NamespaceContext { private final StAXDocumentParser this$0;
/*      */     
/*      */     public final String getNamespaceURI(String prefix) {
/* 1585 */       return StAXDocumentParser.this._prefixTable.getNamespaceFromPrefix(prefix);
/*      */     }
/*      */     
/*      */     public final String getPrefix(String namespaceURI) {
/* 1589 */       return StAXDocumentParser.this._prefixTable.getPrefixFromNamespace(namespaceURI);
/*      */     }
/*      */     
/*      */     public final Iterator getPrefixes(String namespaceURI) {
/* 1593 */       return StAXDocumentParser.this._prefixTable.getPrefixesFromNamespace(namespaceURI);
/*      */     } }
/*      */ 
/*      */   
/*      */   public final String getNamespaceDecl(String prefix) {
/* 1598 */     return this._prefixTable.getNamespaceFromPrefix(prefix);
/*      */   }
/*      */   
/*      */   public final String getURI(String prefix) {
/* 1602 */     return getNamespaceDecl(prefix);
/*      */   }
/*      */   
/*      */   public final Iterator getPrefixes() {
/* 1606 */     return this._prefixTable.getPrefixes();
/*      */   }
/*      */   
/*      */   public final AttributesHolder getAttributesHolder() {
/* 1610 */     return this._attributes;
/*      */   }
/*      */   
/*      */   public final void setManager(StAXManager manager) {
/* 1614 */     this._manager = manager;
/*      */   }
/*      */   
/*      */   static final String getEventTypeString(int eventType) {
/* 1618 */     switch (eventType) {
/*      */       case 1:
/* 1620 */         return "START_ELEMENT";
/*      */       case 2:
/* 1622 */         return "END_ELEMENT";
/*      */       case 3:
/* 1624 */         return "PROCESSING_INSTRUCTION";
/*      */       case 4:
/* 1626 */         return "CHARACTERS";
/*      */       case 5:
/* 1628 */         return "COMMENT";
/*      */       case 7:
/* 1630 */         return "START_DOCUMENT";
/*      */       case 8:
/* 1632 */         return "END_DOCUMENT";
/*      */       case 9:
/* 1634 */         return "ENTITY_REFERENCE";
/*      */       case 10:
/* 1636 */         return "ATTRIBUTE";
/*      */       case 11:
/* 1638 */         return "DTD";
/*      */       case 12:
/* 1640 */         return "CDATA";
/*      */     } 
/* 1642 */     return "UNKNOWN_EVENT_TYPE";
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\StAXDocumentParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */