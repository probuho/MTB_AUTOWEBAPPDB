/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContiguousCharArrayArray
/*     */   extends ValueArray
/*     */ {
/*     */   public static final int INITIAL_CHARACTER_SIZE = 512;
/*     */   public static final int MAXIMUM_CHARACTER_SIZE = 2147483647;
/*     */   protected int _maximumCharacterSize;
/*     */   public int[] _offset;
/*     */   public int[] _length;
/*     */   public char[] _array;
/*     */   public int _arrayIndex;
/*     */   public int _readOnlyArrayIndex;
/*  56 */   private CharArray _charArray = new CharArray();
/*     */   
/*     */   private ContiguousCharArrayArray _readOnlyArray;
/*     */ 
/*     */   
/*     */   public ContiguousCharArrayArray(int initialCapacity, int maximumCapacity, int initialCharacterSize, int maximumCharacterSize) {
/*  62 */     this._offset = new int[initialCapacity];
/*  63 */     this._length = new int[initialCapacity];
/*  64 */     this._array = new char[initialCharacterSize];
/*  65 */     this._charArray.ch = this._array;
/*  66 */     this._maximumCapacity = maximumCapacity;
/*  67 */     this._maximumCharacterSize = maximumCharacterSize;
/*     */   }
/*     */   
/*     */   public ContiguousCharArrayArray() {
/*  71 */     this(10, 2147483647, 512, 2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void clear() {
/*  76 */     this._arrayIndex = this._readOnlyArrayIndex;
/*  77 */     this._size = this._readOnlyArraySize;
/*     */   }
/*     */   
/*     */   public final int getArrayIndex() {
/*  81 */     return this._arrayIndex;
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(ValueArray readOnlyArray, boolean clear) {
/*  85 */     if (!(readOnlyArray instanceof ContiguousCharArrayArray)) {
/*  86 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyArray }));
/*     */     }
/*     */     
/*  89 */     setReadOnlyArray((ContiguousCharArrayArray)readOnlyArray, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(ContiguousCharArrayArray readOnlyArray, boolean clear) {
/*  93 */     if (readOnlyArray != null) {
/*  94 */       this._readOnlyArray = readOnlyArray;
/*  95 */       this._readOnlyArraySize = readOnlyArray.getSize();
/*  96 */       this._readOnlyArrayIndex = readOnlyArray.getArrayIndex();
/*     */       
/*  98 */       if (clear) {
/*  99 */         clear();
/*     */       }
/*     */       
/* 102 */       this._charArray.ch = this._array = getCompleteCharArray();
/* 103 */       this._offset = getCompleteOffsetArray();
/* 104 */       this._length = getCompleteLengthArray();
/* 105 */       this._size = this._readOnlyArraySize;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final char[] getCompleteCharArray() {
/* 110 */     if (this._readOnlyArray == null) {
/* 111 */       return this._array;
/*     */     }
/* 113 */     char[] ra = this._readOnlyArray.getCompleteCharArray();
/* 114 */     char[] a = new char[this._readOnlyArrayIndex + this._array.length];
/* 115 */     System.arraycopy(ra, 0, a, 0, this._readOnlyArrayIndex);
/* 116 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int[] getCompleteOffsetArray() {
/* 121 */     if (this._readOnlyArray == null) {
/* 122 */       return this._offset;
/*     */     }
/* 124 */     int[] ra = this._readOnlyArray.getCompleteOffsetArray();
/* 125 */     int[] a = new int[this._readOnlyArraySize + this._offset.length];
/* 126 */     System.arraycopy(ra, 0, a, 0, this._readOnlyArraySize);
/* 127 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int[] getCompleteLengthArray() {
/* 132 */     if (this._readOnlyArray == null) {
/* 133 */       return this._length;
/*     */     }
/* 135 */     int[] ra = this._readOnlyArray.getCompleteOffsetArray();
/* 136 */     int[] a = new int[this._readOnlyArraySize + this._length.length];
/* 137 */     System.arraycopy(ra, 0, a, 0, this._readOnlyArraySize);
/* 138 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public final CharArray get(int i) {
/* 143 */     this._charArray.start = this._offset[i];
/* 144 */     this._charArray.length = this._length[i];
/* 145 */     return this._charArray;
/*     */   }
/*     */   
/*     */   public final void add(int o, int l) {
/* 149 */     if (this._size == this._offset.length) {
/* 150 */       resize();
/*     */     }
/*     */     
/* 153 */     this._offset[this._size] = o;
/* 154 */     this._length[this._size++] = l;
/*     */   }
/*     */   
/*     */   public final void add(char[] c, int l) {
/* 158 */     if (this._size == this._offset.length) {
/* 159 */       resize();
/*     */     }
/*     */     
/* 162 */     this._offset[this._size] = this._arrayIndex;
/* 163 */     this._length[this._size++] = l;
/*     */     
/* 165 */     int arrayIndex = this._arrayIndex + l;
/* 166 */     if (arrayIndex >= this._array.length) {
/* 167 */       resizeArray(arrayIndex);
/*     */     }
/*     */     
/* 170 */     System.arraycopy(c, 0, this._array, this._arrayIndex, l);
/* 171 */     this._arrayIndex = arrayIndex;
/*     */   }
/*     */   
/*     */   protected final void resize() {
/* 175 */     if (this._size == this._maximumCapacity) {
/* 176 */       throw new ValueArrayResourceException(CommonResourceBundle.getInstance().getString("message.arrayMaxCapacity"));
/*     */     }
/*     */     
/* 179 */     int newSize = this._size * 3 / 2 + 1;
/* 180 */     if (newSize > this._maximumCapacity) {
/* 181 */       newSize = this._maximumCapacity;
/*     */     }
/*     */     
/* 184 */     int[] offset = new int[newSize];
/* 185 */     System.arraycopy(this._offset, 0, offset, 0, this._size);
/* 186 */     this._offset = offset;
/*     */     
/* 188 */     int[] length = new int[newSize];
/* 189 */     System.arraycopy(this._length, 0, length, 0, this._size);
/* 190 */     this._length = length;
/*     */   }
/*     */   
/*     */   protected final void resizeArray(int requestedSize) {
/* 194 */     if (this._arrayIndex == this._maximumCharacterSize) {
/* 195 */       throw new ValueArrayResourceException(CommonResourceBundle.getInstance().getString("message.maxNumberOfCharacters"));
/*     */     }
/*     */     
/* 198 */     int newSize = requestedSize * 3 / 2 + 1;
/* 199 */     if (newSize > this._maximumCharacterSize) {
/* 200 */       newSize = this._maximumCharacterSize;
/*     */     }
/*     */     
/* 203 */     char[] array = new char[newSize];
/* 204 */     System.arraycopy(this._array, 0, array, 0, this._arrayIndex);
/* 205 */     this._charArray.ch = this._array = array;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\ContiguousCharArrayArray.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */