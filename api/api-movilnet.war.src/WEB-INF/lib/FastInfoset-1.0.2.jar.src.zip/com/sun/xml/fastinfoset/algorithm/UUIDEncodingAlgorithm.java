/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.nio.CharBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UUIDEncodingAlgorithm
/*     */   extends LongEncodingAlgorithm
/*     */ {
/*     */   private long _msb;
/*     */   private long _lsb;
/*     */   
/*     */   public final int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/*  50 */     if (octetLength % 16 != 0) {
/*  51 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.lengthNotMultipleOfUUID", new Object[] { new Integer(16) }));
/*     */     }
/*     */ 
/*     */     
/*  55 */     return octetLength / 8;
/*     */   }
/*     */   
/*     */   public final Object convertFromCharacters(char[] ch, int start, int length) {
/*  59 */     final CharBuffer cb = CharBuffer.wrap(ch, start, length);
/*  60 */     final List longList = new ArrayList();
/*     */     
/*  62 */     matchWhiteSpaceDelimnatedWords(cb, new BuiltInEncodingAlgorithm.WordListener()
/*     */         {
/*     */           public void word(int start, int end) {
/*  65 */             String uuidValue = cb.subSequence(start, end).toString();
/*  66 */             UUIDEncodingAlgorithm.this.fromUUIDString(uuidValue);
/*  67 */             longList.add(new Long(UUIDEncodingAlgorithm.this._msb));
/*  68 */             longList.add(new Long(UUIDEncodingAlgorithm.this._lsb));
/*     */           }
/*     */           private final CharBuffer val$cb; private final List val$longList;
/*     */           private final UUIDEncodingAlgorithm this$0;
/*     */         });
/*  73 */     return generateArrayFromList(longList);
/*     */   }
/*     */   
/*     */   public final void convertToCharacters(Object data, StringBuffer s) {
/*  77 */     if (!(data instanceof long[])) {
/*  78 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotLongArray"));
/*     */     }
/*     */     
/*  81 */     long[] ldata = (long[])data;
/*     */     
/*  83 */     int end = ldata.length - 1;
/*  84 */     for (int i = 0; i <= end; i += 2) {
/*  85 */       s.append(toUUIDString(ldata[i], ldata[i + 1]));
/*  86 */       if (i != end) {
/*  87 */         s.append(' ');
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void fromUUIDString(String name) {
/*  97 */     String[] components = name.split("-");
/*  98 */     if (components.length != 5) {
/*  99 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.invalidUUID", new Object[] { name }));
/*     */     }
/*     */     
/* 102 */     for (int i = 0; i < 5; i++) {
/* 103 */       components[i] = "0x" + components[i];
/*     */     }
/* 105 */     this._msb = Long.parseLong(components[0], 16);
/* 106 */     this._msb <<= 16L;
/* 107 */     this._msb |= Long.parseLong(components[1], 16);
/* 108 */     this._msb <<= 16L;
/* 109 */     this._msb |= Long.parseLong(components[2], 16);
/*     */     
/* 111 */     this._lsb = Long.parseLong(components[3], 16);
/* 112 */     this._lsb <<= 48L;
/* 113 */     this._lsb |= Long.parseLong(components[4], 16);
/*     */   }
/*     */   
/*     */   final String toUUIDString(long msb, long lsb) {
/* 117 */     return digits(msb >> 32L, 8) + "-" + digits(msb >> 16L, 4) + "-" + digits(msb, 4) + "-" + digits(lsb >> 48L, 4) + "-" + digits(lsb, 12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String digits(long val, int digits) {
/* 125 */     long hi = 1L << digits * 4;
/* 126 */     return Long.toHexString(hi | val & hi - 1L).substring(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\UUIDEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */