/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringArray
/*     */   extends ValueArray
/*     */ {
/*     */   public String[] _array;
/*     */   private StringArray _readOnlyArray;
/*     */   
/*     */   public StringArray(int initialCapacity, int maximumCapacity) {
/*  50 */     this._array = new String[initialCapacity];
/*  51 */     this._maximumCapacity = maximumCapacity;
/*     */   }
/*     */   
/*     */   public StringArray() {
/*  55 */     this(10, 2147483647);
/*     */   }
/*     */   
/*     */   public final void clear() {
/*  59 */     for (int i = this._readOnlyArraySize; i < this._size; i++) {
/*  60 */       this._array[i] = null;
/*     */     }
/*  62 */     this._size = this._readOnlyArraySize;
/*     */   }
/*     */   
/*     */   public final String[] getArray() {
/*  66 */     return this._array;
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(ValueArray readOnlyArray, boolean clear) {
/*  70 */     if (!(readOnlyArray instanceof StringArray)) {
/*  71 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyArray }));
/*     */     }
/*     */ 
/*     */     
/*  75 */     setReadOnlyArray((StringArray)readOnlyArray, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(StringArray readOnlyArray, boolean clear) {
/*  79 */     if (readOnlyArray != null) {
/*  80 */       this._readOnlyArray = readOnlyArray;
/*  81 */       this._readOnlyArraySize = readOnlyArray.getSize();
/*     */       
/*  83 */       if (clear) {
/*  84 */         clear();
/*     */       }
/*     */       
/*  87 */       this._array = getCompleteArray();
/*  88 */       this._size = this._readOnlyArraySize;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final String[] getCompleteArray() {
/*  93 */     if (this._readOnlyArray == null) {
/*  94 */       return this._array;
/*     */     }
/*  96 */     String[] ra = this._readOnlyArray.getCompleteArray();
/*  97 */     String[] a = new String[this._readOnlyArraySize + this._array.length];
/*  98 */     System.arraycopy(ra, 0, a, 0, this._readOnlyArraySize);
/*  99 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String get(int i) {
/* 104 */     return this._array[i];
/*     */   }
/*     */   
/*     */   public final int add(String s) {
/* 108 */     if (this._size == this._array.length) {
/* 109 */       resize();
/*     */     }
/*     */     
/* 112 */     this._array[this._size++] = s;
/* 113 */     return this._size;
/*     */   }
/*     */   
/*     */   protected final void resize() {
/* 117 */     if (this._size == this._maximumCapacity) {
/* 118 */       throw new ValueArrayResourceException(CommonResourceBundle.getInstance().getString("message.arrayMaxCapacity"));
/*     */     }
/*     */     
/* 121 */     int newSize = this._size * 3 / 2 + 1;
/* 122 */     if (newSize > this._maximumCapacity) {
/* 123 */       newSize = this._maximumCapacity;
/*     */     }
/*     */     
/* 126 */     String[] newArray = new String[newSize];
/* 127 */     System.arraycopy(this._array, 0, newArray, 0, this._size);
/* 128 */     this._array = newArray;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\StringArray.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */