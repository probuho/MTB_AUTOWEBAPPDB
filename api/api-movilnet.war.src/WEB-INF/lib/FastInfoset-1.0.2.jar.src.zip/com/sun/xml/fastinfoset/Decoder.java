/*      */ package com.sun.xml.fastinfoset;
/*      */ 
/*      */ import com.sun.xml.fastinfoset.alphabet.BuiltInRestrictedAlphabets;
/*      */ import com.sun.xml.fastinfoset.org.apache.xerces.util.XMLChar;
/*      */ import com.sun.xml.fastinfoset.util.CharArray;
/*      */ import com.sun.xml.fastinfoset.util.CharArrayArray;
/*      */ import com.sun.xml.fastinfoset.util.CharArrayString;
/*      */ import com.sun.xml.fastinfoset.util.ContiguousCharArrayArray;
/*      */ import com.sun.xml.fastinfoset.util.DuplicateAttributeVerifier;
/*      */ import com.sun.xml.fastinfoset.util.PrefixArray;
/*      */ import com.sun.xml.fastinfoset.util.QualifiedNameArray;
/*      */ import com.sun.xml.fastinfoset.util.StringArray;
/*      */ import com.sun.xml.fastinfoset.vocab.ParserVocabulary;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.jvnet.fastinfoset.FastInfosetException;
/*      */ import org.jvnet.fastinfoset.FastInfosetParser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Decoder
/*      */   implements FastInfosetParser
/*      */ {
/*      */   public static final String STRING_INTERNING_SYSTEM_PROPERTY = "com.sun.xml.fastinfoset.parser.string-interning";
/*      */   public static final String BUFFER_SIZE_SYSTEM_PROPERTY = "com.sun.xml.fastinfoset.parser.buffer-size";
/*      */   private static boolean _stringInterningSystemDefault = false;
/*  102 */   private static int _bufferSizeSystemDefault = 1024;
/*      */   
/*      */   static {
/*  105 */     String p = System.getProperty("com.sun.xml.fastinfoset.parser.string-interning", Boolean.toString(_stringInterningSystemDefault));
/*      */     
/*  107 */     _stringInterningSystemDefault = Boolean.valueOf(p).booleanValue();
/*      */     
/*  109 */     p = System.getProperty("com.sun.xml.fastinfoset.parser.buffer-size", Integer.toString(_bufferSizeSystemDefault));
/*      */     
/*      */     try {
/*  112 */       int i = Integer.valueOf(p).intValue();
/*  113 */       if (i > 0) {
/*  114 */         _bufferSizeSystemDefault = i;
/*      */       }
/*  116 */     } catch (NumberFormatException e) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   private boolean _stringInterning = _stringInterningSystemDefault;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InputStream _s;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map _externalVocabularies;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _vIsInternal;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List _notations;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List _unparsedEntities;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   protected Map _registeredEncodingAlgorithms = new HashMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ParserVocabulary _v;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PrefixArray _prefixTable;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected QualifiedNameArray _elementNameTable;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected QualifiedNameArray _attributeNameTable;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContiguousCharArrayArray _characterContentChunkTable;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StringArray _attributeValueTable;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _b;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _terminate;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _doubleTerminate;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _addToTable;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _integer;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _identifier;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  221 */   protected int _bufferSize = _bufferSizeSystemDefault;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  226 */   protected byte[] _octetBuffer = new byte[_bufferSizeSystemDefault];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _octetBufferStart;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _octetBufferOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _octetBufferEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _octetBufferLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   protected char[] _charBuffer = new char[512];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _charBufferLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  262 */   protected DuplicateAttributeVerifier _duplicateAttributeVerifier = new DuplicateAttributeVerifier(); protected static final int NISTRING_STRING = 0;
/*      */   protected static final int NISTRING_INDEX = 1;
/*      */   protected static final int NISTRING_ENCODING_ALGORITHM = 2;
/*      */   protected static final int NISTRING_EMPTY_STRING = 3;
/*      */   
/*      */   protected Decoder() {
/*  268 */     this._v = new ParserVocabulary();
/*  269 */     this._prefixTable = this._v.prefix;
/*  270 */     this._elementNameTable = this._v.elementName;
/*  271 */     this._attributeNameTable = this._v.attributeName;
/*  272 */     this._characterContentChunkTable = this._v.characterContentChunk;
/*  273 */     this._attributeValueTable = this._v.attributeValue;
/*  274 */     this._vIsInternal = true;
/*      */   }
/*      */   
/*      */   protected int _prefixIndex;
/*      */   protected int _namespaceNameIndex;
/*      */   private int _bitsLeftInOctet;
/*      */   private char _utf8_highSurrogate;
/*      */   private char _utf8_lowSurrogate;
/*      */   
/*      */   public void setStringInterning(boolean stringInterning) {
/*  284 */     this._stringInterning = stringInterning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getStringInterning() {
/*  291 */     return this._stringInterning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBufferSize(int bufferSize) {
/*  298 */     if (this._bufferSize > this._octetBuffer.length) {
/*  299 */       this._bufferSize = bufferSize;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBufferSize() {
/*  307 */     return this._bufferSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRegisteredEncodingAlgorithms(Map algorithms) {
/*  314 */     this._registeredEncodingAlgorithms = algorithms;
/*  315 */     if (this._registeredEncodingAlgorithms == null) {
/*  316 */       this._registeredEncodingAlgorithms = new HashMap();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getRegisteredEncodingAlgorithms() {
/*  324 */     return this._registeredEncodingAlgorithms;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExternalVocabularies(Map referencedVocabualries) {
/*  331 */     this._externalVocabularies = referencedVocabualries;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getExternalVocabularies() {
/*  338 */     return this._externalVocabularies;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/*  370 */     this._terminate = this._doubleTerminate = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVocabulary(ParserVocabulary v) {
/*  379 */     this._v = v;
/*  380 */     this._prefixTable = this._v.prefix;
/*  381 */     this._elementNameTable = this._v.elementName;
/*  382 */     this._attributeNameTable = this._v.attributeName;
/*  383 */     this._characterContentChunkTable = this._v.characterContentChunk;
/*  384 */     this._attributeValueTable = this._v.attributeValue;
/*  385 */     this._vIsInternal = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInputStream(InputStream s) {
/*  394 */     this._s = s;
/*  395 */     this._octetBufferOffset = 0;
/*  396 */     this._octetBufferEnd = 0;
/*  397 */     if (this._vIsInternal == true) {
/*  398 */       this._v.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void decodeDII() throws FastInfosetException, IOException {
/*  403 */     int b = read();
/*  404 */     if (b == 32) {
/*  405 */       decodeInitialVocabulary();
/*  406 */     } else if (b != 0) {
/*  407 */       throw new IOException(CommonResourceBundle.getInstance().getString("message.optinalValues"));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void decodeAdditionalData() throws FastInfosetException, IOException {
/*  413 */     for (int i = 0; i < decodeNumberOfItemsOfSequence(); i++) {
/*  414 */       String URI = decodeNonEmptyOctetStringOnSecondBitAsUtf8String();
/*      */       
/*  416 */       decodeNonEmptyOctetStringLengthOnSecondBit();
/*  417 */       ensureOctetBufferSize();
/*  418 */       this._octetBufferStart = this._octetBufferOffset;
/*  419 */       this._octetBufferOffset += this._octetBufferLength;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void decodeInitialVocabulary() throws FastInfosetException, IOException {
/*  425 */     int b = read();
/*      */     
/*  427 */     int b2 = read();
/*      */ 
/*      */     
/*  430 */     if (b == 16 && b2 == 0) {
/*  431 */       decodeExternalVocabularyURI();
/*      */       
/*      */       return;
/*      */     } 
/*  435 */     if ((b & 0x10) > 0) {
/*  436 */       decodeExternalVocabularyURI();
/*      */     }
/*      */     
/*  439 */     if ((b & 0x8) > 0) {
/*  440 */       decodeTableItems(this._v.restrictedAlphabet);
/*      */     }
/*      */     
/*  443 */     if ((b & 0x4) > 0) {
/*  444 */       decodeTableItems(this._v.encodingAlgorithm);
/*      */     }
/*      */     
/*  447 */     if ((b & 0x2) > 0) {
/*  448 */       decodeTableItems(this._v.prefix);
/*      */     }
/*      */     
/*  451 */     if ((b & 0x1) > 0) {
/*  452 */       decodeTableItems(this._v.namespaceName);
/*      */     }
/*      */     
/*  455 */     if ((b2 & 0x80) > 0) {
/*  456 */       decodeTableItems(this._v.localName);
/*      */     }
/*      */     
/*  459 */     if ((b2 & 0x40) > 0) {
/*  460 */       decodeTableItems(this._v.otherNCName);
/*      */     }
/*      */     
/*  463 */     if ((b2 & 0x20) > 0) {
/*  464 */       decodeTableItems(this._v.otherURI);
/*      */     }
/*      */     
/*  467 */     if ((b2 & 0x10) > 0) {
/*  468 */       decodeTableItems(this._v.attributeValue);
/*      */     }
/*      */     
/*  471 */     if ((b2 & 0x8) > 0) {
/*  472 */       decodeTableItems(this._v.characterContentChunk);
/*      */     }
/*      */     
/*  475 */     if ((b2 & 0x4) > 0) {
/*  476 */       decodeTableItems(this._v.otherString);
/*      */     }
/*      */     
/*  479 */     if ((b2 & 0x2) > 0) {
/*  480 */       decodeTableItems(this._v.elementName, false);
/*      */     }
/*      */     
/*  483 */     if ((b2 & 0x1) > 0) {
/*  484 */       decodeTableItems(this._v.attributeName, true);
/*      */     }
/*      */   }
/*      */   
/*      */   private void decodeExternalVocabularyURI() throws FastInfosetException, IOException {
/*  489 */     if (this._externalVocabularies == null) {
/*  490 */       throw new IOException(CommonResourceBundle.getInstance().getString("message.noExternalVocabularies"));
/*      */     }
/*      */     
/*  493 */     String externalVocabularyURI = decodeNonEmptyOctetStringOnSecondBitAsUtf8String();
/*  494 */     ParserVocabulary externalVocabulary = (ParserVocabulary)this._externalVocabularies.get(externalVocabularyURI);
/*      */     
/*  496 */     if (externalVocabulary == null) {
/*  497 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.externalVocabularyNotRegistered", new Object[] { externalVocabularyURI }));
/*      */     }
/*      */     
/*  500 */     this._v.setReferencedVocabulary(externalVocabularyURI, externalVocabulary, false);
/*      */   }
/*      */   
/*      */   private void decodeTableItems(StringArray array) throws FastInfosetException, IOException {
/*  504 */     for (int i = 0; i < decodeNumberOfItemsOfSequence(); i++) {
/*  505 */       array.add(decodeNonEmptyOctetStringOnSecondBitAsUtf8String());
/*      */     }
/*      */   }
/*      */   
/*      */   private void decodeTableItems(PrefixArray array) throws FastInfosetException, IOException {
/*  510 */     for (int i = 0; i < decodeNumberOfItemsOfSequence(); i++) {
/*  511 */       array.add(decodeNonEmptyOctetStringOnSecondBitAsUtf8String());
/*      */     }
/*      */   }
/*      */   
/*      */   private void decodeTableItems(ContiguousCharArrayArray array) throws FastInfosetException, IOException {
/*  516 */     for (int i = 0; i < decodeNumberOfItemsOfSequence(); i++) {
/*  517 */       switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */         case 0:
/*  519 */           array.add(this._charBuffer, this._charBufferLength);
/*      */           break;
/*      */         default:
/*  522 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.illegalState"));
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void decodeTableItems(CharArrayArray array) throws FastInfosetException, IOException {
/*  528 */     for (int i = 0; i < decodeNumberOfItemsOfSequence(); i++) {
/*  529 */       switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */         case 0:
/*  531 */           array.add(new CharArray(this._charBuffer, 0, this._charBufferLength, true));
/*      */           break;
/*      */         default:
/*  534 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.illegalState"));
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void decodeTableItems(QualifiedNameArray array, boolean isAttribute) throws FastInfosetException, IOException {
/*  540 */     for (int i = 0; i < decodeNumberOfItemsOfSequence(); i++) {
/*  541 */       int b = read();
/*      */       
/*  543 */       String prefix = "";
/*  544 */       int prefixIndex = -1;
/*  545 */       if ((b & 0x2) > 0) {
/*  546 */         prefixIndex = decodeIntegerIndexOnSecondBit();
/*  547 */         prefix = this._v.prefix.get(prefixIndex);
/*      */       } 
/*      */       
/*  550 */       String namespaceName = "";
/*  551 */       int namespaceNameIndex = -1;
/*  552 */       if ((b & 0x1) > 0) {
/*  553 */         namespaceNameIndex = decodeIntegerIndexOnSecondBit();
/*  554 */         namespaceName = this._v.prefix.get(prefixIndex);
/*      */       } 
/*      */       
/*  557 */       if (namespaceName == "" && prefix != "") {
/*  558 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.missingNamespace"));
/*      */       }
/*      */       
/*  561 */       int localNameIndex = decodeIntegerIndexOnSecondBit();
/*  562 */       String localName = this._v.localName.get(localNameIndex);
/*      */       
/*  564 */       QualifiedName qualifiedName = new QualifiedName(prefix, namespaceName, localName, prefixIndex, namespaceNameIndex, localNameIndex, this._charBuffer);
/*      */ 
/*      */       
/*  567 */       if (isAttribute) {
/*  568 */         qualifiedName.createAttributeValues(256);
/*      */       }
/*  570 */       array.add(qualifiedName);
/*      */     } 
/*      */   }
/*      */   
/*      */   private int decodeNumberOfItemsOfSequence() throws IOException {
/*  575 */     int b = read();
/*  576 */     if (b < 128) {
/*  577 */       return b;
/*      */     }
/*  579 */     return (b & 0xF) << 16 | read() << 8 | read();
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void decodeNotations() throws FastInfosetException, IOException {
/*  584 */     if (this._notations == null) {
/*  585 */       this._notations = new ArrayList();
/*      */     } else {
/*  587 */       this._notations.clear();
/*      */     } 
/*      */     
/*  590 */     int b = read();
/*  591 */     while ((b & 0xFC) == 192) {
/*  592 */       String name = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*      */       
/*  594 */       String system_identifier = ((this._b & 0x2) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */       
/*  596 */       String public_identifier = ((this._b & 0x1) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */ 
/*      */       
/*  599 */       Notation notation = new Notation(name, system_identifier, public_identifier);
/*  600 */       this._notations.add(notation);
/*      */       
/*  602 */       b = read();
/*      */     } 
/*  604 */     if (b != 240) {
/*  605 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IIsNotTerminatedCorrectly"));
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void decodeUnparsedEntities() throws FastInfosetException, IOException {
/*  610 */     if (this._unparsedEntities == null) {
/*  611 */       this._unparsedEntities = new ArrayList();
/*      */     } else {
/*  613 */       this._unparsedEntities.clear();
/*      */     } 
/*      */     
/*  616 */     int b = read();
/*  617 */     while ((b & 0xFE) == 208) {
/*  618 */       String name = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*  619 */       String system_identifier = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI);
/*      */       
/*  621 */       String public_identifier = ((this._b & 0x1) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */ 
/*      */       
/*  624 */       String notation_name = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*      */       
/*  626 */       UnparsedEntity unparsedEntity = new UnparsedEntity(name, system_identifier, public_identifier, notation_name);
/*  627 */       this._unparsedEntities.add(unparsedEntity);
/*      */       
/*  629 */       b = read();
/*      */     } 
/*  631 */     if (b != 240) {
/*  632 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.unparsedEntities"));
/*      */     }
/*      */   }
/*      */   
/*      */   protected final String decodeCharacterEncodingScheme() throws FastInfosetException, IOException {
/*  637 */     return decodeNonEmptyOctetStringOnSecondBitAsUtf8String();
/*      */   }
/*      */   protected final String decodeVersion() throws FastInfosetException, IOException {
/*      */     String data;
/*  641 */     switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */       case 0:
/*  643 */         data = new String(this._charBuffer, 0, this._charBufferLength);
/*  644 */         if (this._addToTable) {
/*  645 */           this._v.otherString.add((CharArray)new CharArrayString(data));
/*      */         }
/*  647 */         return data;
/*      */       case 2:
/*  649 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingNotSupported"));
/*      */       case 1:
/*  651 */         return this._v.otherString.get(this._integer).toString();
/*      */     } 
/*      */     
/*  654 */     return "";
/*      */   }
/*      */ 
/*      */   
/*      */   protected final QualifiedName decodeEIIIndexMedium() throws FastInfosetException, IOException {
/*  659 */     int i = ((this._b & 0x7) << 8 | read()) + 32;
/*      */     
/*  661 */     return this._v.elementName._array[i];
/*      */   }
/*      */   
/*      */   protected final QualifiedName decodeEIIIndexLarge() throws FastInfosetException, IOException {
/*      */     int i;
/*  666 */     if ((this._b & 0x30) == 32) {
/*      */       
/*  668 */       i = ((this._b & 0x7) << 16 | read() << 8 | read()) + 2080;
/*      */     }
/*      */     else {
/*      */       
/*  672 */       i = ((read() & 0xF) << 16 | read() << 8 | read()) + 526368;
/*      */     } 
/*      */     
/*  675 */     return this._v.elementName._array[i];
/*      */   }
/*      */   
/*      */   protected final QualifiedName decodeLiteralQualifiedName(int state) throws FastInfosetException, IOException {
/*  679 */     switch (state) {
/*      */       
/*      */       case 0:
/*  682 */         return new QualifiedName("", "", decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), -1, -1, this._identifier, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  692 */         return new QualifiedName("", decodeIdentifyingNonEmptyStringIndexOnFirstBitAsNamespaceName(false), decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), -1, this._namespaceNameIndex, this._identifier, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  702 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.qNameMissingNamespaceName"));
/*      */       
/*      */       case 3:
/*  705 */         return new QualifiedName(decodeIdentifyingNonEmptyStringIndexOnFirstBitAsPrefix(true), decodeIdentifyingNonEmptyStringIndexOnFirstBitAsNamespaceName(true), decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), this._prefixIndex, this._namespaceNameIndex, this._identifier, this._charBuffer);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  714 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingEII"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int decodeNonIdentifyingStringOnFirstBit() throws FastInfosetException, IOException {
/*  728 */     int length, b2, b = read();
/*  729 */     switch (DecoderStateTables.NISTRING[b]) {
/*      */       case 0:
/*  731 */         this._addToTable = ((b & 0x40) > 0);
/*  732 */         this._octetBufferLength = (b & 0x7) + 1;
/*  733 */         decodeUtf8StringAsCharBuffer();
/*  734 */         return 0;
/*      */       case 1:
/*  736 */         this._addToTable = ((b & 0x40) > 0);
/*  737 */         this._octetBufferLength = read() + 9;
/*  738 */         decodeUtf8StringAsCharBuffer();
/*  739 */         return 0;
/*      */       
/*      */       case 2:
/*  742 */         this._addToTable = ((b & 0x40) > 0);
/*  743 */         length = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/*  747 */         this._octetBufferLength = length + 265;
/*  748 */         decodeUtf8StringAsCharBuffer();
/*  749 */         return 0;
/*      */       
/*      */       case 3:
/*  752 */         this._addToTable = ((b & 0x40) > 0);
/*  753 */         this._octetBufferLength = (b & 0x7) + 1;
/*  754 */         decodeUtf16StringAsCharBuffer();
/*  755 */         return 0;
/*      */       case 4:
/*  757 */         this._addToTable = ((b & 0x40) > 0);
/*  758 */         this._octetBufferLength = read() + 9;
/*  759 */         decodeUtf16StringAsCharBuffer();
/*  760 */         return 0;
/*      */       
/*      */       case 5:
/*  763 */         this._addToTable = ((b & 0x40) > 0);
/*  764 */         length = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/*  768 */         this._octetBufferLength = length + 265;
/*  769 */         decodeUtf16StringAsCharBuffer();
/*  770 */         return 0;
/*      */ 
/*      */       
/*      */       case 6:
/*  774 */         this._addToTable = ((b & 0x40) > 0);
/*      */         
/*  776 */         this._identifier = (b & 0xF) << 4;
/*  777 */         b2 = read();
/*  778 */         this._identifier |= (b2 & 0xF0) >> 4;
/*      */         
/*  780 */         decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit(b2);
/*      */         
/*  782 */         decodeRestrictedAlphabetAsCharBuffer();
/*  783 */         return 0;
/*      */ 
/*      */       
/*      */       case 7:
/*  787 */         this._addToTable = ((b & 0x40) > 0);
/*      */         
/*  789 */         this._identifier = (b & 0xF) << 4;
/*  790 */         b2 = read();
/*  791 */         this._identifier |= (b2 & 0xF0) >> 4;
/*      */         
/*  793 */         decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit(b2);
/*  794 */         return 2;
/*      */       
/*      */       case 8:
/*  797 */         this._integer = b & 0x3F;
/*  798 */         return 1;
/*      */       case 9:
/*  800 */         this._integer = ((b & 0x1F) << 8 | read()) + 64;
/*      */         
/*  802 */         return 1;
/*      */       case 10:
/*  804 */         this._integer = ((b & 0xF) << 16 | read() << 8 | read()) + 8256;
/*      */         
/*  806 */         return 1;
/*      */       case 11:
/*  808 */         return 3;
/*      */     } 
/*  810 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingNonIdentifyingString"));
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit(int b) throws FastInfosetException, IOException {
/*      */     int length;
/*  816 */     b &= 0xF;
/*      */     
/*  818 */     switch (DecoderStateTables.NISTRING[b]) {
/*      */       case 0:
/*  820 */         this._octetBufferLength = b + 1;
/*      */         break;
/*      */       case 1:
/*  823 */         this._octetBufferLength = read() + 9;
/*      */         break;
/*      */       case 2:
/*  826 */         length = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/*  830 */         this._octetBufferLength = length + 265;
/*      */         break;
/*      */       default:
/*  833 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingOctets"));
/*      */     } 
/*  835 */     ensureOctetBufferSize();
/*  836 */     this._octetBufferStart = this._octetBufferOffset;
/*  837 */     this._octetBufferOffset += this._octetBufferLength;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void decodeOctetsOnSeventhBitOfNonIdentifyingStringOnThirdBit(int b) throws FastInfosetException, IOException {
/*  842 */     switch (b & 0x3) {
/*      */       
/*      */       case 0:
/*  845 */         this._octetBufferLength = 1;
/*      */         break;
/*      */       
/*      */       case 1:
/*  849 */         this._octetBufferLength = 2;
/*      */         break;
/*      */       
/*      */       case 2:
/*  853 */         this._octetBufferLength = read() + 3;
/*      */         break;
/*      */       
/*      */       case 3:
/*  857 */         this._octetBufferLength = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/*  861 */         this._octetBufferLength += 259;
/*      */         break;
/*      */     } 
/*      */     
/*  865 */     ensureOctetBufferSize();
/*  866 */     this._octetBufferStart = this._octetBufferOffset;
/*  867 */     this._octetBufferOffset += this._octetBufferLength;
/*      */   }
/*      */   
/*      */   protected final String decodeIdentifyingNonEmptyStringOnFirstBit(StringArray table) throws FastInfosetException, IOException {
/*      */     String s;
/*      */     int length;
/*      */     String str1;
/*  874 */     int b = read();
/*  875 */     switch (DecoderStateTables.ISTRING[b]) {
/*      */       
/*      */       case 0:
/*  878 */         this._octetBufferLength = b + 1;
/*  879 */         s = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/*  880 */         this._identifier = table.add(s) - 1;
/*  881 */         return s;
/*      */ 
/*      */       
/*      */       case 1:
/*  885 */         this._octetBufferLength = read() + 65;
/*  886 */         s = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/*  887 */         this._identifier = table.add(s) - 1;
/*  888 */         return s;
/*      */ 
/*      */       
/*      */       case 2:
/*  892 */         length = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/*  896 */         this._octetBufferLength = length + 321;
/*  897 */         str1 = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/*  898 */         this._identifier = table.add(str1) - 1;
/*  899 */         return str1;
/*      */       
/*      */       case 3:
/*  902 */         this._identifier = b & 0x3F;
/*  903 */         return table._array[this._identifier];
/*      */       case 4:
/*  905 */         this._identifier = ((b & 0x1F) << 8 | read()) + 64;
/*      */         
/*  907 */         return table._array[this._identifier];
/*      */       case 5:
/*  909 */         this._identifier = ((b & 0xF) << 16 | read() << 8 | read()) + 8256;
/*      */         
/*  911 */         return table._array[this._identifier];
/*      */     } 
/*  913 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingIdentifyingString"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String decodeIdentifyingNonEmptyStringOnFirstBitAsPrefix(boolean namespaceNamePresent) throws FastInfosetException, IOException {
/*      */     String s;
/*      */     int length;
/*      */     String str1;
/*  923 */     int b = read();
/*  924 */     switch (DecoderStateTables.ISTRING_PREFIX_NAMESPACE[b]) {
/*      */       
/*      */       case 6:
/*  927 */         this._octetBufferLength = EncodingConstants.XML_NAMESPACE_PREFIX_LENGTH;
/*  928 */         decodeUtf8StringAsCharBuffer();
/*      */         
/*  930 */         if (this._charBuffer[0] == 'x' && this._charBuffer[1] == 'm' && this._charBuffer[2] == 'l')
/*      */         {
/*      */           
/*  933 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.prefixIllegal"));
/*      */         }
/*      */         
/*  936 */         s = this._stringInterning ? (new String(this._charBuffer, 0, this._charBufferLength)).intern() : new String(this._charBuffer, 0, this._charBufferLength);
/*      */         
/*  938 */         this._prefixIndex = this._v.prefix.add(s);
/*  939 */         return s;
/*      */ 
/*      */       
/*      */       case 7:
/*  943 */         this._octetBufferLength = EncodingConstants.XMLNS_NAMESPACE_PREFIX_LENGTH;
/*  944 */         decodeUtf8StringAsCharBuffer();
/*      */         
/*  946 */         if (this._charBuffer[0] == 'x' && this._charBuffer[1] == 'm' && this._charBuffer[2] == 'l' && this._charBuffer[3] == 'n' && this._charBuffer[4] == 's')
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  951 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.xmlns"));
/*      */         }
/*      */         
/*  954 */         s = this._stringInterning ? (new String(this._charBuffer, 0, this._charBufferLength)).intern() : new String(this._charBuffer, 0, this._charBufferLength);
/*      */         
/*  956 */         this._prefixIndex = this._v.prefix.add(s);
/*  957 */         return s;
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 8:
/*      */       case 9:
/*  963 */         this._octetBufferLength = b + 1;
/*  964 */         s = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/*  965 */         this._prefixIndex = this._v.prefix.add(s);
/*  966 */         return s;
/*      */ 
/*      */       
/*      */       case 1:
/*  970 */         this._octetBufferLength = read() + 65;
/*  971 */         s = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/*  972 */         this._prefixIndex = this._v.prefix.add(s);
/*  973 */         return s;
/*      */ 
/*      */       
/*      */       case 2:
/*  977 */         length = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/*  981 */         this._octetBufferLength = length + 321;
/*  982 */         str1 = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/*  983 */         this._prefixIndex = this._v.prefix.add(str1);
/*  984 */         return str1;
/*      */       
/*      */       case 10:
/*  987 */         if (namespaceNamePresent) {
/*  988 */           this._prefixIndex = 0;
/*      */           
/*  990 */           if (DecoderStateTables.ISTRING_PREFIX_NAMESPACE[peak()] != 10)
/*      */           {
/*  992 */             throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.wrongNamespaceName"));
/*      */           }
/*  994 */           return "xml";
/*      */         } 
/*  996 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.missingNamespaceName"));
/*      */       
/*      */       case 3:
/*  999 */         this._prefixIndex = b & 0x3F;
/* 1000 */         return this._v.prefix._array[this._prefixIndex - 1];
/*      */       case 4:
/* 1002 */         this._prefixIndex = ((b & 0x1F) << 8 | read()) + 64;
/*      */         
/* 1004 */         return this._v.prefix._array[this._prefixIndex - 1];
/*      */       case 5:
/* 1006 */         this._prefixIndex = ((b & 0xF) << 16 | read() << 8 | read()) + 8256;
/*      */         
/* 1008 */         return this._v.prefix._array[this._prefixIndex - 1];
/*      */     } 
/* 1010 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingIdentifyingStringForPrefix"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String decodeIdentifyingNonEmptyStringIndexOnFirstBitAsPrefix(boolean namespaceNamePresent) throws FastInfosetException, IOException {
/* 1018 */     int b = read();
/* 1019 */     switch (DecoderStateTables.ISTRING_PREFIX_NAMESPACE[b]) {
/*      */       case 10:
/* 1021 */         if (namespaceNamePresent) {
/* 1022 */           this._prefixIndex = 0;
/*      */           
/* 1024 */           if (DecoderStateTables.ISTRING_PREFIX_NAMESPACE[peak()] != 10)
/*      */           {
/* 1026 */             throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.wrongNamespaceName"));
/*      */           }
/* 1028 */           return "xml";
/*      */         } 
/* 1030 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.missingNamespaceName"));
/*      */       
/*      */       case 3:
/* 1033 */         this._prefixIndex = b & 0x3F;
/* 1034 */         return this._v.prefix._array[this._prefixIndex - 1];
/*      */       case 4:
/* 1036 */         this._prefixIndex = ((b & 0x1F) << 8 | read()) + 64;
/*      */         
/* 1038 */         return this._v.prefix._array[this._prefixIndex - 1];
/*      */       case 5:
/* 1040 */         this._prefixIndex = ((b & 0xF) << 16 | read() << 8 | read()) + 8256;
/*      */         
/* 1042 */         return this._v.prefix._array[this._prefixIndex - 1];
/*      */     } 
/* 1044 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingIdentifyingStringForPrefix"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String decodeIdentifyingNonEmptyStringOnFirstBitAsNamespaceName(boolean prefixPresent) throws FastInfosetException, IOException {
/*      */     String s;
/*      */     int length;
/*      */     String str1;
/* 1054 */     int b = read();
/* 1055 */     switch (DecoderStateTables.ISTRING_PREFIX_NAMESPACE[b]) {
/*      */       
/*      */       case 0:
/*      */       case 6:
/*      */       case 7:
/* 1060 */         this._octetBufferLength = b + 1;
/* 1061 */         s = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/* 1062 */         this._namespaceNameIndex = this._v.namespaceName.add(s);
/* 1063 */         return s;
/*      */ 
/*      */       
/*      */       case 8:
/* 1067 */         this._octetBufferLength = EncodingConstants.XMLNS_NAMESPACE_NAME_LENGTH;
/* 1068 */         decodeUtf8StringAsCharBuffer();
/*      */         
/* 1070 */         if (compareCharsWithCharBufferFromEndToStart(EncodingConstants.XMLNS_NAMESPACE_NAME_CHARS)) {
/* 1071 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.xmlnsConnotBeBoundToPrefix"));
/*      */         }
/*      */         
/* 1074 */         s = this._stringInterning ? (new String(this._charBuffer, 0, this._charBufferLength)).intern() : new String(this._charBuffer, 0, this._charBufferLength);
/*      */         
/* 1076 */         this._namespaceNameIndex = this._v.namespaceName.add(s);
/* 1077 */         return s;
/*      */ 
/*      */       
/*      */       case 9:
/* 1081 */         this._octetBufferLength = EncodingConstants.XML_NAMESPACE_NAME_LENGTH;
/* 1082 */         decodeUtf8StringAsCharBuffer();
/*      */         
/* 1084 */         if (compareCharsWithCharBufferFromEndToStart(EncodingConstants.XML_NAMESPACE_NAME_CHARS)) {
/* 1085 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.illegalNamespaceName"));
/*      */         }
/*      */         
/* 1088 */         s = this._stringInterning ? (new String(this._charBuffer, 0, this._charBufferLength)).intern() : new String(this._charBuffer, 0, this._charBufferLength);
/*      */         
/* 1090 */         this._namespaceNameIndex = this._v.namespaceName.add(s);
/* 1091 */         return s;
/*      */ 
/*      */       
/*      */       case 1:
/* 1095 */         this._octetBufferLength = read() + 65;
/* 1096 */         s = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/* 1097 */         this._namespaceNameIndex = this._v.namespaceName.add(s);
/* 1098 */         return s;
/*      */ 
/*      */       
/*      */       case 2:
/* 1102 */         length = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/* 1106 */         this._octetBufferLength = length + 321;
/* 1107 */         str1 = this._stringInterning ? decodeUtf8StringAsString().intern() : decodeUtf8StringAsString();
/* 1108 */         this._namespaceNameIndex = this._v.namespaceName.add(str1);
/* 1109 */         return str1;
/*      */       
/*      */       case 10:
/* 1112 */         if (prefixPresent) {
/* 1113 */           this._namespaceNameIndex = 0;
/* 1114 */           return "http://www.w3.org/XML/1998/namespace";
/*      */         } 
/* 1116 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.namespaceWithoutPrefix"));
/*      */       
/*      */       case 3:
/* 1119 */         this._namespaceNameIndex = b & 0x3F;
/* 1120 */         return this._v.namespaceName._array[this._namespaceNameIndex - 1];
/*      */       case 4:
/* 1122 */         this._namespaceNameIndex = ((b & 0x1F) << 8 | read()) + 64;
/*      */         
/* 1124 */         return this._v.namespaceName._array[this._namespaceNameIndex - 1];
/*      */       case 5:
/* 1126 */         this._namespaceNameIndex = ((b & 0xF) << 16 | read() << 8 | read()) + 8256;
/*      */         
/* 1128 */         return this._v.namespaceName._array[this._namespaceNameIndex - 1];
/*      */     } 
/* 1130 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingForNamespaceName"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String decodeIdentifyingNonEmptyStringIndexOnFirstBitAsNamespaceName(boolean prefixPresent) throws FastInfosetException, IOException {
/* 1138 */     int b = read();
/* 1139 */     switch (DecoderStateTables.ISTRING_PREFIX_NAMESPACE[b]) {
/*      */       case 10:
/* 1141 */         if (prefixPresent) {
/* 1142 */           this._namespaceNameIndex = 0;
/* 1143 */           return "http://www.w3.org/XML/1998/namespace";
/*      */         } 
/* 1145 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.namespaceWithoutPrefix"));
/*      */       
/*      */       case 3:
/* 1148 */         this._namespaceNameIndex = b & 0x3F;
/* 1149 */         return this._v.namespaceName._array[this._namespaceNameIndex - 1];
/*      */       case 4:
/* 1151 */         this._namespaceNameIndex = ((b & 0x1F) << 8 | read()) + 64;
/*      */         
/* 1153 */         return this._v.namespaceName._array[this._namespaceNameIndex - 1];
/*      */       case 5:
/* 1155 */         this._namespaceNameIndex = ((b & 0xF) << 16 | read() << 8 | read()) + 8256;
/*      */         
/* 1157 */         return this._v.namespaceName._array[this._namespaceNameIndex - 1];
/*      */     } 
/* 1159 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingForNamespaceName"));
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean compareCharsWithCharBufferFromEndToStart(char[] c) {
/* 1164 */     int i = this._charBufferLength;
/* 1165 */     while (--i >= 0) {
/* 1166 */       if (c[i] != this._charBuffer[i]) {
/* 1167 */         return false;
/*      */       }
/*      */     } 
/* 1170 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String decodeNonEmptyOctetStringOnSecondBitAsUtf8String() throws FastInfosetException, IOException {
/* 1177 */     decodeNonEmptyOctetStringOnSecondBitAsUtf8CharArray();
/* 1178 */     return new String(this._charBuffer, 0, this._charBufferLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void decodeNonEmptyOctetStringOnSecondBitAsUtf8CharArray() throws FastInfosetException, IOException {
/* 1185 */     decodeNonEmptyOctetStringLengthOnSecondBit();
/* 1186 */     decodeUtf8StringAsCharBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void decodeNonEmptyOctetStringLengthOnSecondBit() throws FastInfosetException, IOException {
/* 1193 */     int length, b = read();
/* 1194 */     switch (DecoderStateTables.ISTRING[b]) {
/*      */       case 0:
/* 1196 */         this._octetBufferLength = b + 1;
/*      */         return;
/*      */       case 1:
/* 1199 */         this._octetBufferLength = read() + 65;
/*      */         return;
/*      */       
/*      */       case 2:
/* 1203 */         length = read() << 24 | read() << 16 | read() << 8 | read();
/*      */ 
/*      */ 
/*      */         
/* 1207 */         this._octetBufferLength = length + 321;
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1214 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingNonEmptyOctet"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int decodeIntegerIndexOnSecondBit() throws FastInfosetException, IOException {
/* 1222 */     int b = read();
/* 1223 */     switch (DecoderStateTables.ISTRING[b]) {
/*      */       case 3:
/* 1225 */         return b & 0x3F;
/*      */       case 4:
/* 1227 */         return ((b & 0x1F) << 8 | read()) + 64;
/*      */       
/*      */       case 5:
/* 1230 */         return ((b & 0xF) << 16 | read() << 8 | read()) + 8256;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1236 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingIndexOnSecondBit"));
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void decodeHeader() throws FastInfosetException, IOException {
/* 1241 */     if (!_isFastInfosetDocument()) {
/* 1242 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.notFIDocument"));
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void decodeRestrictedAlphabetAsCharBuffer() throws FastInfosetException, IOException {
/* 1247 */     if (this._identifier <= 1) {
/* 1248 */       decodeFourBitAlphabetOctetsAsCharBuffer(BuiltInRestrictedAlphabets.table[this._identifier]);
/*      */     }
/* 1250 */     else if (this._identifier >= 32) {
/* 1251 */       CharArray ca = this._v.restrictedAlphabet.get(this._identifier - 32);
/* 1252 */       if (ca == null) {
/* 1253 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.alphabetNotPresent", new Object[] { new Integer(this._identifier) }));
/*      */       }
/* 1255 */       decodeAlphabetOctetsAsCharBuffer(ca.ch);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1260 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.alphabetIdentifiersReserved"));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final String decodeRestrictedAlphabetAsString() throws FastInfosetException, IOException {
/* 1265 */     decodeRestrictedAlphabetAsCharBuffer();
/* 1266 */     return new String(this._charBuffer, 0, this._charBufferLength);
/*      */   }
/*      */   
/*      */   protected final String decodeRAOctetsAsString(char[] restrictedAlphabet) throws FastInfosetException, IOException {
/* 1270 */     decodeAlphabetOctetsAsCharBuffer(null);
/* 1271 */     return new String(this._charBuffer, 0, this._charBufferLength);
/*      */   }
/*      */   
/*      */   protected final void decodeFourBitAlphabetOctetsAsCharBuffer(char[] restrictedAlphabet) throws FastInfosetException, IOException {
/* 1275 */     this._charBufferLength = 0;
/* 1276 */     int characters = this._octetBufferLength / 2;
/* 1277 */     if (this._charBuffer.length < characters) {
/* 1278 */       this._charBuffer = new char[characters];
/*      */     }
/*      */     
/* 1281 */     int v = 0;
/* 1282 */     for (int i = 0; i < this._octetBufferLength - 1; i++) {
/* 1283 */       v = this._octetBuffer[this._octetBufferStart++] & 0xFF;
/* 1284 */       this._charBuffer[this._charBufferLength++] = restrictedAlphabet[v >> 4];
/* 1285 */       this._charBuffer[this._charBufferLength++] = restrictedAlphabet[v & 0xF];
/*      */     } 
/* 1287 */     v = this._octetBuffer[this._octetBufferStart++] & 0xFF;
/* 1288 */     this._charBuffer[this._charBufferLength++] = restrictedAlphabet[v >> 4];
/* 1289 */     v &= 0xF;
/* 1290 */     if (v != 15) {
/* 1291 */       this._charBuffer[this._charBufferLength++] = restrictedAlphabet[v & 0xF];
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void decodeAlphabetOctetsAsCharBuffer(char[] restrictedAlphabet) throws FastInfosetException, IOException {
/* 1296 */     if (restrictedAlphabet.length < 2) {
/* 1297 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.alphabetMustContain2orMoreChars"));
/*      */     }
/*      */     
/* 1300 */     int bitsPerCharacter = 1;
/* 1301 */     while (1 << bitsPerCharacter <= restrictedAlphabet.length) {
/* 1302 */       bitsPerCharacter++;
/*      */     }
/* 1304 */     int terminatingValue = (1 << bitsPerCharacter) - 1;
/*      */     
/* 1306 */     int characters = (this._octetBufferLength << 3) / bitsPerCharacter;
/* 1307 */     if (characters == 0) {
/* 1308 */       throw new IOException("");
/*      */     }
/*      */     
/* 1311 */     this._charBufferLength = 0;
/* 1312 */     if (this._charBuffer.length < characters) {
/* 1313 */       this._charBuffer = new char[characters];
/*      */     }
/*      */     
/* 1316 */     resetBits();
/* 1317 */     for (int i = 0; i < characters; i++) {
/* 1318 */       int value = readBits(bitsPerCharacter);
/* 1319 */       if (bitsPerCharacter < 8 && value == terminatingValue) {
/* 1320 */         int octetPosition = i * bitsPerCharacter >>> 3;
/* 1321 */         if (octetPosition != this._octetBufferLength - 1) {
/* 1322 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.alphabetIncorrectlyTerminated"));
/*      */         }
/*      */         break;
/*      */       } 
/* 1326 */       this._charBuffer[this._charBufferLength++] = restrictedAlphabet[value];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void resetBits() {
/* 1333 */     this._bitsLeftInOctet = 0;
/*      */   }
/*      */   
/*      */   private int readBits(int bits) throws IOException {
/* 1337 */     int value = 0;
/* 1338 */     while (bits > 0) {
/* 1339 */       if (this._bitsLeftInOctet == 0) {
/* 1340 */         this._b = this._octetBuffer[this._octetBufferStart++] & 0xFF;
/* 1341 */         this._bitsLeftInOctet = 8;
/*      */       } 
/* 1343 */       int bit = ((this._b & 1 << --this._bitsLeftInOctet) > 0) ? 1 : 0;
/* 1344 */       value |= bit << --bits;
/*      */     } 
/*      */     
/* 1347 */     return value;
/*      */   }
/*      */   
/*      */   protected final void decodeUtf8StringAsCharBuffer() throws IOException {
/* 1351 */     ensureOctetBufferSize();
/* 1352 */     decodeUtf8StringIntoCharBuffer();
/*      */   }
/*      */   
/*      */   protected final String decodeUtf8StringAsString() throws IOException {
/* 1356 */     decodeUtf8StringAsCharBuffer();
/* 1357 */     return new String(this._charBuffer, 0, this._charBufferLength);
/*      */   }
/*      */   
/*      */   protected final void decodeUtf16StringAsCharBuffer() throws IOException {
/* 1361 */     ensureOctetBufferSize();
/* 1362 */     decodeUtf16StringIntoCharBuffer();
/*      */   }
/*      */   
/*      */   protected final String decodeUtf16StringAsString() throws IOException {
/* 1366 */     decodeUtf16StringAsCharBuffer();
/* 1367 */     return new String(this._charBuffer, 0, this._charBufferLength);
/*      */   }
/*      */   
/*      */   private void ensureOctetBufferSize() throws IOException {
/* 1371 */     if (this._octetBufferEnd < this._octetBufferOffset + this._octetBufferLength) {
/* 1372 */       int octetsInBuffer = this._octetBufferEnd - this._octetBufferOffset;
/*      */       
/* 1374 */       if (this._octetBuffer.length < this._octetBufferLength) {
/*      */         
/* 1376 */         byte[] newOctetBuffer = new byte[this._octetBufferLength];
/*      */         
/* 1378 */         System.arraycopy(this._octetBuffer, this._octetBufferOffset, newOctetBuffer, 0, octetsInBuffer);
/* 1379 */         this._octetBuffer = newOctetBuffer;
/*      */       } else {
/*      */         
/* 1382 */         System.arraycopy(this._octetBuffer, this._octetBufferOffset, this._octetBuffer, 0, octetsInBuffer);
/*      */       } 
/* 1384 */       this._octetBufferOffset = 0;
/*      */ 
/*      */       
/* 1387 */       int octetsRead = this._s.read(this._octetBuffer, octetsInBuffer, this._octetBuffer.length - octetsInBuffer);
/* 1388 */       if (octetsRead < 0) {
/* 1389 */         throw new EOFException("Unexpeceted EOF");
/*      */       }
/* 1391 */       this._octetBufferEnd = octetsInBuffer + octetsRead;
/*      */ 
/*      */ 
/*      */       
/* 1395 */       if (this._octetBufferEnd < this._octetBufferLength) {
/* 1396 */         repeatedRead();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void repeatedRead() throws IOException {
/* 1403 */     while (this._octetBufferEnd < this._octetBufferLength) {
/*      */       
/* 1405 */       int octetsRead = this._s.read(this._octetBuffer, this._octetBufferEnd, this._octetBuffer.length - this._octetBufferEnd);
/* 1406 */       if (octetsRead < 0) {
/* 1407 */         throw new EOFException("Unexpeceted EOF");
/*      */       }
/* 1409 */       this._octetBufferEnd += octetsRead;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void decodeUtf8StringIntoCharBuffer() throws IOException {
/* 1414 */     if (this._charBuffer.length < this._octetBufferLength) {
/* 1415 */       this._charBuffer = new char[this._octetBufferLength];
/*      */     }
/*      */     
/* 1418 */     this._charBufferLength = 0;
/* 1419 */     int end = this._octetBufferLength + this._octetBufferOffset;
/*      */     
/* 1421 */     while (end != this._octetBufferOffset) {
/* 1422 */       int b1 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1423 */       if (DecoderStateTables.UTF8[b1] == 1) {
/* 1424 */         this._charBuffer[this._charBufferLength++] = (char)b1; continue;
/*      */       } 
/* 1426 */       decodeTwoToFourByteUtf8Character(b1, end);
/*      */     } 
/*      */   } private void decodeTwoToFourByteUtf8Character(int b1, int end) throws IOException {
/*      */     int b2;
/*      */     char c;
/*      */     int supplemental;
/* 1432 */     switch (DecoderStateTables.UTF8[b1]) {
/*      */ 
/*      */       
/*      */       case 2:
/* 1436 */         if (end == this._octetBufferOffset) {
/* 1437 */           decodeUtf8StringLengthTooSmall();
/*      */         }
/* 1439 */         b2 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1440 */         if ((b2 & 0xC0) != 128) {
/* 1441 */           decodeUtf8StringIllegalState();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1447 */         this._charBuffer[this._charBufferLength++] = (char)((b1 & 0x1F) << 6 | b2 & 0x3F);
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1453 */         c = decodeUtf8ThreeByteChar(end, b1);
/* 1454 */         if (XMLChar.isContent(c)) {
/* 1455 */           this._charBuffer[this._charBufferLength++] = c;
/*      */         } else {
/*      */           
/* 1458 */           decodeUtf8StringIllegalState();
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 1462 */         supplemental = decodeUtf8FourByteChar(end, b1);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1472 */     decodeUtf8StringIllegalState();
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void decodeUtf8NCNameIntoCharBuffer() throws IOException {
/* 1477 */     this._charBufferLength = 0;
/* 1478 */     if (this._charBuffer.length < this._octetBufferLength) {
/* 1479 */       this._charBuffer = new char[this._octetBufferLength];
/*      */     }
/*      */     
/* 1482 */     int end = this._octetBufferLength + this._octetBufferOffset;
/*      */     
/* 1484 */     int b1 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1485 */     if (DecoderStateTables.UTF8_NCNAME[b1] == 0) {
/* 1486 */       this._charBuffer[this._charBufferLength++] = (char)b1;
/*      */     } else {
/* 1488 */       decodeUtf8NCNameStartTwoToFourByteCharacters(b1, end);
/*      */     } 
/*      */     
/* 1491 */     while (end != this._octetBufferOffset) {
/* 1492 */       b1 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1493 */       if (DecoderStateTables.UTF8_NCNAME[b1] < 2) {
/* 1494 */         this._charBuffer[this._charBufferLength++] = (char)b1; continue;
/*      */       } 
/* 1496 */       decodeUtf8NCNameTwoToFourByteCharacters(b1, end);
/*      */     } 
/*      */   } private void decodeUtf8NCNameStartTwoToFourByteCharacters(int b1, int end) throws IOException {
/*      */     int b2;
/*      */     char c, c1;
/*      */     int supplemental;
/* 1502 */     switch (DecoderStateTables.UTF8_NCNAME[b1]) {
/*      */ 
/*      */       
/*      */       case 2:
/* 1506 */         if (end == this._octetBufferOffset) {
/* 1507 */           decodeUtf8StringLengthTooSmall();
/*      */         }
/* 1509 */         b2 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1510 */         if ((b2 & 0xC0) != 128) {
/* 1511 */           decodeUtf8StringIllegalState();
/*      */         }
/*      */         
/* 1514 */         c1 = (char)((b1 & 0x1F) << 6 | b2 & 0x3F);
/*      */ 
/*      */         
/* 1517 */         if (XMLChar.isNCNameStart(c1)) {
/* 1518 */           this._charBuffer[this._charBufferLength++] = c1;
/*      */         } else {
/*      */           
/* 1521 */           decodeUtf8NCNameIllegalState();
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 1525 */         c = decodeUtf8ThreeByteChar(end, b1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 1535 */         supplemental = decodeUtf8FourByteChar(end, b1);
/* 1536 */         if (XMLChar.isNCNameStart(supplemental)) {
/* 1537 */           this._charBuffer[this._charBufferLength++] = this._utf8_highSurrogate;
/* 1538 */           this._charBuffer[this._charBufferLength++] = this._utf8_lowSurrogate;
/*      */         } else {
/* 1540 */           decodeUtf8NCNameIllegalState();
/*      */         } 
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1546 */     decodeUtf8NCNameIllegalState();
/*      */   }
/*      */   private void decodeUtf8NCNameTwoToFourByteCharacters(int b1, int end) throws IOException {
/*      */     int b2;
/*      */     char c, c1;
/*      */     int supplemental;
/* 1552 */     switch (DecoderStateTables.UTF8_NCNAME[b1]) {
/*      */ 
/*      */       
/*      */       case 2:
/* 1556 */         if (end == this._octetBufferOffset) {
/* 1557 */           decodeUtf8StringLengthTooSmall();
/*      */         }
/* 1559 */         b2 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1560 */         if ((b2 & 0xC0) != 128) {
/* 1561 */           decodeUtf8StringIllegalState();
/*      */         }
/*      */         
/* 1564 */         c1 = (char)((b1 & 0x1F) << 6 | b2 & 0x3F);
/*      */ 
/*      */         
/* 1567 */         if (XMLChar.isNCName(c1)) {
/* 1568 */           this._charBuffer[this._charBufferLength++] = c1;
/*      */         } else {
/*      */           
/* 1571 */           decodeUtf8NCNameIllegalState();
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 1575 */         c = decodeUtf8ThreeByteChar(end, b1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 1585 */         supplemental = decodeUtf8FourByteChar(end, b1);
/* 1586 */         if (XMLChar.isNCName(supplemental)) {
/* 1587 */           this._charBuffer[this._charBufferLength++] = this._utf8_highSurrogate;
/* 1588 */           this._charBuffer[this._charBufferLength++] = this._utf8_lowSurrogate;
/*      */         } else {
/* 1590 */           decodeUtf8NCNameIllegalState();
/*      */         } 
/*      */         return;
/*      */     } 
/*      */     
/* 1595 */     decodeUtf8NCNameIllegalState();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private char decodeUtf8ThreeByteChar(int end, int b1) throws IOException {
/* 1601 */     if (end == this._octetBufferOffset) {
/* 1602 */       decodeUtf8StringLengthTooSmall();
/*      */     }
/* 1604 */     int b2 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1605 */     if ((b2 & 0xC0) != 128 || (b1 == 237 && b2 >= 160) || ((b1 & 0xF) == 0 && (b2 & 0x20) == 0))
/*      */     {
/*      */       
/* 1608 */       decodeUtf8StringIllegalState();
/*      */     }
/*      */ 
/*      */     
/* 1612 */     if (end == this._octetBufferOffset) {
/* 1613 */       decodeUtf8StringLengthTooSmall();
/*      */     }
/* 1615 */     int b3 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1616 */     if ((b3 & 0xC0) != 128) {
/* 1617 */       decodeUtf8StringIllegalState();
/*      */     }
/*      */     
/* 1620 */     return (char)((b1 & 0xF) << 12 | (b2 & 0x3F) << 6 | b3 & 0x3F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int decodeUtf8FourByteChar(int end, int b1) throws IOException {
/* 1631 */     if (end == this._octetBufferOffset) {
/* 1632 */       decodeUtf8StringLengthTooSmall();
/*      */     }
/* 1634 */     int b2 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1635 */     if ((b2 & 0xC0) != 128 || ((b2 & 0x30) == 0 && (b1 & 0x7) == 0))
/*      */     {
/* 1637 */       decodeUtf8StringIllegalState();
/*      */     }
/*      */ 
/*      */     
/* 1641 */     if (end == this._octetBufferOffset) {
/* 1642 */       decodeUtf8StringLengthTooSmall();
/*      */     }
/* 1644 */     int b3 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1645 */     if ((b3 & 0xC0) != 128) {
/* 1646 */       decodeUtf8StringIllegalState();
/*      */     }
/*      */ 
/*      */     
/* 1650 */     if (end == this._octetBufferOffset) {
/* 1651 */       decodeUtf8StringLengthTooSmall();
/*      */     }
/* 1653 */     int b4 = this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/* 1654 */     if ((b4 & 0xC0) != 128) {
/* 1655 */       decodeUtf8StringIllegalState();
/*      */     }
/*      */     
/* 1658 */     int uuuuu = b1 << 2 & 0x1C | b2 >> 4 & 0x3;
/* 1659 */     if (uuuuu > 16) {
/* 1660 */       decodeUtf8StringIllegalState();
/*      */     }
/* 1662 */     int wwww = uuuuu - 1;
/*      */     
/* 1664 */     this._utf8_highSurrogate = (char)(0xD800 | wwww << 6 & 0x3C0 | b2 << 2 & 0x3C | b3 >> 4 & 0x3);
/*      */ 
/*      */     
/* 1667 */     this._utf8_lowSurrogate = (char)(0xDC00 | b3 << 6 & 0x3C0 | b4 & 0x3F);
/*      */     
/* 1669 */     return XMLChar.supplemental(this._utf8_highSurrogate, this._utf8_lowSurrogate);
/*      */   }
/*      */   
/*      */   private void decodeUtf8StringLengthTooSmall() throws IOException {
/* 1673 */     throw new IOException(CommonResourceBundle.getInstance().getString("message.deliminatorTooSmall"));
/*      */   }
/*      */   
/*      */   private void decodeUtf8StringIllegalState() throws IOException {
/* 1677 */     throw new IOException(CommonResourceBundle.getInstance().getString("message.UTF8Encoded"));
/*      */   }
/*      */   
/*      */   private void decodeUtf8NCNameIllegalState() throws IOException {
/* 1681 */     throw new IOException(CommonResourceBundle.getInstance().getString("message.UTF8EncodedNCName"));
/*      */   }
/*      */   
/*      */   private void decodeUtf16StringIntoCharBuffer() throws IOException {
/* 1685 */     this._charBufferLength = this._octetBufferLength / 2;
/* 1686 */     if (this._charBuffer.length < this._charBufferLength) {
/* 1687 */       this._charBuffer = new char[this._charBufferLength];
/*      */     }
/*      */     
/* 1690 */     for (int i = 0; i < this._charBufferLength; i++) {
/* 1691 */       char c = (char)(read() << 8 | read());
/*      */       
/* 1693 */       this._charBuffer[i] = c;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected String createQualifiedNameString(char[] first, String second) {
/* 1699 */     int l1 = first.length;
/* 1700 */     int l2 = second.length();
/* 1701 */     int total = l1 + l2 + 1;
/* 1702 */     if (total < this._charBuffer.length) {
/* 1703 */       System.arraycopy(first, 0, this._charBuffer, 0, l1);
/* 1704 */       this._charBuffer[l1] = ':';
/* 1705 */       second.getChars(0, l2, this._charBuffer, l1 + 1);
/* 1706 */       return new String(this._charBuffer, 0, total);
/*      */     } 
/* 1708 */     StringBuffer b = new StringBuffer(new String(first));
/* 1709 */     b.append(':');
/* 1710 */     b.append(second);
/* 1711 */     return b.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   protected final int read() throws IOException {
/* 1716 */     if (this._octetBufferOffset < this._octetBufferEnd) {
/* 1717 */       return this._octetBuffer[this._octetBufferOffset++] & 0xFF;
/*      */     }
/* 1719 */     this._octetBufferEnd = this._s.read(this._octetBuffer);
/* 1720 */     if (this._octetBufferEnd < 0) {
/* 1721 */       throw new EOFException(CommonResourceBundle.getInstance().getString("message.EOF"));
/*      */     }
/*      */     
/* 1724 */     this._octetBufferOffset = 1;
/* 1725 */     return this._octetBuffer[0] & 0xFF;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final int peak() throws IOException {
/* 1730 */     if (this._octetBufferOffset < this._octetBufferEnd) {
/* 1731 */       return this._octetBuffer[this._octetBufferOffset] & 0xFF;
/*      */     }
/* 1733 */     this._octetBufferEnd = this._s.read(this._octetBuffer);
/* 1734 */     if (this._octetBufferEnd < 0) {
/* 1735 */       throw new EOFException(CommonResourceBundle.getInstance().getString("message.EOF"));
/*      */     }
/*      */     
/* 1738 */     this._octetBufferOffset = 0;
/* 1739 */     return this._octetBuffer[0] & 0xFF;
/*      */   }
/*      */   
/*      */   protected class EncodingAlgorithmInputStream extends InputStream {
/*      */     private final Decoder this$0;
/*      */     
/*      */     public int read() throws IOException {
/* 1746 */       if (Decoder.this._octetBufferStart < Decoder.this._octetBufferOffset) {
/* 1747 */         return Decoder.this._octetBuffer[Decoder.this._octetBufferStart++] & 0xFF;
/*      */       }
/* 1749 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*      */     public int read(byte[] b) throws IOException {
/* 1754 */       return read(b, 0, b.length);
/*      */     }
/*      */     
/*      */     public int read(byte[] b, int off, int len) throws IOException {
/* 1758 */       if (b == null)
/* 1759 */         throw new NullPointerException(); 
/* 1760 */       if (off < 0 || off > b.length || len < 0 || off + len > b.length || off + len < 0)
/*      */       {
/* 1762 */         throw new IndexOutOfBoundsException(); } 
/* 1763 */       if (len == 0) {
/* 1764 */         return 0;
/*      */       }
/*      */       
/* 1767 */       int newOctetBufferStart = Decoder.this._octetBufferStart + len;
/* 1768 */       if (newOctetBufferStart < Decoder.this._octetBufferOffset) {
/* 1769 */         System.arraycopy(Decoder.this._octetBuffer, Decoder.this._octetBufferStart, b, off, len);
/* 1770 */         Decoder.this._octetBufferStart = newOctetBufferStart;
/* 1771 */         return len;
/* 1772 */       }  if (Decoder.this._octetBufferStart < Decoder.this._octetBufferOffset) {
/* 1773 */         int bytesToRead = Decoder.this._octetBufferOffset - Decoder.this._octetBufferStart;
/* 1774 */         System.arraycopy(Decoder.this._octetBuffer, Decoder.this._octetBufferStart, b, off, bytesToRead);
/* 1775 */         Decoder.this._octetBufferStart += bytesToRead;
/* 1776 */         return bytesToRead;
/*      */       } 
/* 1778 */       return -1;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _isFastInfosetDocument() throws IOException {
/* 1785 */     peak();
/*      */     
/* 1787 */     this._octetBufferLength = EncodingConstants.BINARY_HEADER.length;
/* 1788 */     ensureOctetBufferSize();
/* 1789 */     this._octetBufferOffset += this._octetBufferLength;
/*      */ 
/*      */     
/* 1792 */     if (this._octetBuffer[0] != EncodingConstants.BINARY_HEADER[0] || this._octetBuffer[1] != EncodingConstants.BINARY_HEADER[1] || this._octetBuffer[2] != EncodingConstants.BINARY_HEADER[2] || this._octetBuffer[3] != EncodingConstants.BINARY_HEADER[3]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1798 */       for (int i = 0; i < EncodingConstants.XML_DECLARATION_VALUES.length; i++) {
/* 1799 */         this._octetBufferLength = (EncodingConstants.XML_DECLARATION_VALUES[i]).length - this._octetBufferOffset;
/* 1800 */         ensureOctetBufferSize();
/* 1801 */         this._octetBufferOffset += this._octetBufferLength;
/*      */ 
/*      */         
/* 1804 */         if (arrayEquals(this._octetBuffer, 0, EncodingConstants.XML_DECLARATION_VALUES[i], (EncodingConstants.XML_DECLARATION_VALUES[i]).length)) {
/*      */ 
/*      */           
/* 1807 */           this._octetBufferLength = EncodingConstants.BINARY_HEADER.length;
/* 1808 */           ensureOctetBufferSize();
/*      */ 
/*      */           
/* 1811 */           if (this._octetBuffer[this._octetBufferOffset++] != EncodingConstants.BINARY_HEADER[0] || this._octetBuffer[this._octetBufferOffset++] != EncodingConstants.BINARY_HEADER[1] || this._octetBuffer[this._octetBufferOffset++] != EncodingConstants.BINARY_HEADER[2] || this._octetBuffer[this._octetBufferOffset++] != EncodingConstants.BINARY_HEADER[3])
/*      */           {
/*      */ 
/*      */             
/* 1815 */             return false;
/*      */           }
/*      */           
/* 1818 */           return true;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1823 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1827 */     return true;
/*      */   }
/*      */   
/*      */   private boolean arrayEquals(byte[] b1, int offset, byte[] b2, int length) {
/* 1831 */     for (int i = 0; i < length; i++) {
/* 1832 */       if (b1[offset + i] != b2[i]) {
/* 1833 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1837 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFastInfosetDocument(InputStream s) throws IOException {
/* 1844 */     byte[] header = new byte[4];
/* 1845 */     s.read(header);
/* 1846 */     if (header[0] != EncodingConstants.BINARY_HEADER[0] || header[1] != EncodingConstants.BINARY_HEADER[1] || header[2] != EncodingConstants.BINARY_HEADER[2] || header[3] != EncodingConstants.BINARY_HEADER[3])
/*      */     {
/*      */ 
/*      */       
/* 1850 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1854 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\Decoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */