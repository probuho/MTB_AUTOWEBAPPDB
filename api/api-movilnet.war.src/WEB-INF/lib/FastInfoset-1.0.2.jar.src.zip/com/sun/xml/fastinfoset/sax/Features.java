package com.sun.xml.fastinfoset.sax;

public class Features {
  public static final String NAMESPACES_FEATURE = "http://xml.org/sax/features/namespaces";
  
  public static final String NAMESPACE_PREFIXES_FEATURE = "http://xml.org/sax/features/namespace-prefixes";
  
  public static final String STRING_INTERNING_FEATURE = "http://xml.org/sax/features/string-interning";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sax\Features.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */