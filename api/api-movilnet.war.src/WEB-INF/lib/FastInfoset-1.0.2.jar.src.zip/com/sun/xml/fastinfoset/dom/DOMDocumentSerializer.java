/*     */ package com.sun.xml.fastinfoset.dom;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.Encoder;
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ import com.sun.xml.fastinfoset.util.LocalNameQualifiedNamesMap;
/*     */ import java.io.IOException;
/*     */ import org.jvnet.fastinfoset.FastInfosetException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMDocumentSerializer
/*     */   extends Encoder
/*     */ {
/*     */   public final void serialize(Node n) throws IOException {
/*  58 */     switch (n.getNodeType()) {
/*     */       case 9:
/*  60 */         serialize((Document)n);
/*     */       case 1:
/*  62 */         serializeElementAsDocument(n);
/*     */         break;
/*     */       case 8:
/*  65 */         serializeComment(n);
/*     */         break;
/*     */       case 7:
/*  68 */         serializeProcessingInstruction(n);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void serialize(Document d) throws IOException {
/*  74 */     reset();
/*  75 */     encodeHeader(false);
/*  76 */     encodeInitialVocabulary();
/*     */     
/*  78 */     NodeList nl = d.getChildNodes();
/*  79 */     for (int i = 0; i < nl.getLength(); i++) {
/*  80 */       Node n = nl.item(i);
/*  81 */       switch (n.getNodeType()) {
/*     */         case 1:
/*  83 */           serializeElement(n);
/*     */           break;
/*     */         case 8:
/*  86 */           serializeComment(n);
/*     */           break;
/*     */         case 7:
/*  89 */           serializeProcessingInstruction(n);
/*     */           break;
/*     */       } 
/*     */     } 
/*  93 */     encodeDocumentTermination();
/*     */   }
/*     */   
/*     */   protected final void serializeElementAsDocument(Node e) throws IOException {
/*  97 */     reset();
/*  98 */     encodeHeader(false);
/*  99 */     encodeInitialVocabulary();
/*     */     
/* 101 */     serializeElement(e);
/*     */     
/* 103 */     encodeDocumentTermination();
/*     */   }
/*     */ 
/*     */   
/* 107 */   protected Node[] _namespaceAttributes = new Node[4];
/* 108 */   protected Node[] _attributes = new Node[32];
/*     */   
/*     */   protected final void serializeElement(Node e) throws IOException {
/* 111 */     encodeTermination();
/*     */     
/* 113 */     int namespaceAttributesSize = 0;
/* 114 */     int attributesSize = 0;
/* 115 */     if (e.hasAttributes()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 120 */       NamedNodeMap nnm = e.getAttributes();
/* 121 */       for (int i = 0; i < nnm.getLength(); i++) {
/* 122 */         Node a = nnm.item(i);
/* 123 */         String str = a.getNamespaceURI();
/* 124 */         if (str != null && str.equals("http://www.w3.org/2000/xmlns/")) {
/* 125 */           if (namespaceAttributesSize == this._namespaceAttributes.length) {
/* 126 */             Node[] attributes = new Node[namespaceAttributesSize * 3 / 2 + 1];
/* 127 */             System.arraycopy(this._namespaceAttributes, 0, attributes, 0, namespaceAttributesSize);
/* 128 */             this._namespaceAttributes = attributes;
/*     */           } 
/* 130 */           this._namespaceAttributes[namespaceAttributesSize++] = a;
/*     */         } else {
/* 132 */           if (attributesSize == this._attributes.length) {
/* 133 */             Node[] attributes = new Node[attributesSize * 3 / 2 + 1];
/* 134 */             System.arraycopy(this._attributes, 0, attributes, 0, attributesSize);
/* 135 */             this._attributes = attributes;
/*     */           } 
/* 137 */           this._attributes[attributesSize++] = a;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 142 */     if (namespaceAttributesSize > 0) {
/* 143 */       if (attributesSize > 0) {
/* 144 */         write(120);
/*     */       } else {
/*     */         
/* 147 */         write(56);
/*     */       } 
/*     */ 
/*     */       
/* 151 */       for (int i = 0; i < namespaceAttributesSize; i++) {
/* 152 */         Node a = this._namespaceAttributes[i];
/* 153 */         this._namespaceAttributes[i] = null;
/* 154 */         String prefix = a.getLocalName();
/* 155 */         if (prefix == "xmlns" || prefix.equals("xmlns")) {
/* 156 */           prefix = "";
/*     */         }
/* 158 */         String uri = a.getNodeValue();
/* 159 */         encodeNamespaceAttribute(prefix, uri);
/*     */       } 
/*     */       
/* 162 */       write(240);
/* 163 */       this._b = 0;
/*     */     } else {
/* 165 */       this._b = (attributesSize > 0) ? 64 : 0;
/*     */     } 
/*     */ 
/*     */     
/* 169 */     String namespaceURI = e.getNamespaceURI();
/* 170 */     namespaceURI = (namespaceURI == null) ? "" : namespaceURI;
/* 171 */     encodeElement(namespaceURI, e.getNodeName(), e.getLocalName());
/*     */     
/* 173 */     if (attributesSize > 0) {
/*     */       
/* 175 */       for (int i = 0; i < attributesSize; i++) {
/* 176 */         Node a = this._attributes[i];
/* 177 */         this._attributes[i] = null;
/* 178 */         namespaceURI = a.getNamespaceURI();
/* 179 */         namespaceURI = (namespaceURI == null) ? "" : namespaceURI;
/* 180 */         encodeAttribute(namespaceURI, a.getNodeName(), a.getLocalName());
/*     */         
/* 182 */         String value = a.getNodeValue();
/* 183 */         boolean addToTable = (value.length() < this.attributeValueSizeConstraint);
/* 184 */         encodeNonIdentifyingStringOnFirstBit(value, this._v.attributeValue, addToTable);
/*     */       } 
/*     */       
/* 187 */       this._b = 240;
/* 188 */       this._terminate = true;
/*     */     } 
/*     */     
/* 191 */     if (e.hasChildNodes()) {
/*     */       
/* 193 */       NodeList nl = e.getChildNodes();
/* 194 */       for (int i = 0; i < nl.getLength(); i++) {
/* 195 */         Node n = nl.item(i);
/* 196 */         switch (n.getNodeType()) {
/*     */           case 1:
/* 198 */             serializeElement(n);
/*     */             break;
/*     */           case 3:
/* 201 */             serializeText(n);
/*     */             break;
/*     */           case 4:
/* 204 */             serializeCDATA(n);
/*     */             break;
/*     */           case 8:
/* 207 */             serializeComment(n);
/*     */             break;
/*     */           case 7:
/* 210 */             serializeProcessingInstruction(n);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 215 */     encodeElementTermination();
/*     */   }
/*     */   
/*     */   protected final void serializeText(Node t) throws IOException {
/* 219 */     String text = t.getNodeValue();
/*     */     
/* 221 */     int length = (text != null) ? text.length() : 0;
/* 222 */     if (length == 0)
/*     */       return; 
/* 224 */     if (length < this._charBuffer.length) {
/* 225 */       encodeTermination();
/* 226 */       text.getChars(0, length, this._charBuffer, 0);
/* 227 */       encodeCharacters(this._charBuffer, 0, length);
/*     */     } else {
/* 229 */       encodeTermination();
/* 230 */       char[] ch = text.toCharArray();
/* 231 */       encodeCharactersNoClone(ch, 0, length);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void serializeCDATA(Node t) throws IOException {
/* 236 */     String text = t.getNodeValue();
/*     */     
/* 238 */     int length = (text != null) ? text.length() : 0;
/* 239 */     if (length == 0) {
/*     */       return;
/*     */     }
/* 242 */     encodeTermination();
/* 243 */     char[] ch = text.toCharArray();
/*     */     try {
/* 245 */       encodeCIIBuiltInAlgorithmDataAsCDATA(ch, 0, length);
/* 246 */     } catch (FastInfosetException e) {
/* 247 */       throw new IOException("");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void serializeComment(Node c) throws IOException {
/* 253 */     encodeTermination();
/*     */     
/* 255 */     String comment = c.getNodeValue();
/*     */     
/* 257 */     int length = (comment != null) ? comment.length() : 0;
/* 258 */     if (length == 0) {
/* 259 */       encodeComment(this._charBuffer, 0, 0);
/* 260 */     } else if (length < this._charBuffer.length) {
/* 261 */       comment.getChars(0, length, this._charBuffer, 0);
/* 262 */       encodeComment(this._charBuffer, 0, length);
/*     */     } else {
/* 264 */       char[] ch = comment.toCharArray();
/* 265 */       encodeCommentNoClone(ch, 0, length);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void serializeProcessingInstruction(Node pi) throws IOException {
/* 270 */     encodeTermination();
/*     */     
/* 272 */     String target = pi.getNodeName();
/* 273 */     String data = pi.getNodeValue();
/* 274 */     encodeProcessingInstruction(target, data);
/*     */   }
/*     */   
/*     */   protected final void encodeElement(String namespaceURI, String qName, String localName) throws IOException {
/* 278 */     LocalNameQualifiedNamesMap.Entry entry = this._v.elementName.obtainEntry(qName);
/* 279 */     if (entry._valueIndex > 0) {
/* 280 */       QualifiedName[] names = entry._value;
/* 281 */       for (int i = 0; i < entry._valueIndex; i++) {
/* 282 */         if (namespaceURI == (names[i]).namespaceName || namespaceURI.equals((names[i]).namespaceName)) {
/* 283 */           encodeNonZeroIntegerOnThirdBit((names[i]).index);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 290 */     if (localName != null) {
/* 291 */       encodeLiteralElementQualifiedNameOnThirdBit(namespaceURI, getPrefixFromQualifiedName(qName), localName, entry);
/*     */     }
/*     */     else {
/*     */       
/* 295 */       encodeLiteralElementQualifiedNameOnThirdBit(namespaceURI, "", qName, entry);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void encodeAttribute(String namespaceURI, String qName, String localName) throws IOException {
/* 300 */     LocalNameQualifiedNamesMap.Entry entry = this._v.attributeName.obtainEntry(qName);
/* 301 */     if (entry._valueIndex > 0) {
/* 302 */       QualifiedName[] names = entry._value;
/* 303 */       for (int i = 0; i < entry._valueIndex; i++) {
/* 304 */         if (namespaceURI == (names[i]).namespaceName || namespaceURI.equals((names[i]).namespaceName)) {
/* 305 */           encodeNonZeroIntegerOnSecondBitFirstBitZero((names[i]).index);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 312 */     if (localName != null) {
/* 313 */       encodeLiteralAttributeQualifiedNameOnSecondBit(namespaceURI, getPrefixFromQualifiedName(qName), localName, entry);
/*     */     }
/*     */     else {
/*     */       
/* 317 */       encodeLiteralAttributeQualifiedNameOnSecondBit(namespaceURI, "", qName, entry);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\dom\DOMDocumentSerializer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */