/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import javax.xml.stream.events.StartDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StartDocumentEvent
/*     */   extends EventBase
/*     */   implements StartDocument
/*     */ {
/*     */   protected String _systemId;
/*  49 */   protected String _encoding = "UTF-8";
/*     */   protected boolean _standalone = true;
/*  51 */   protected String _version = "1.0";
/*     */   private boolean _encodingSet = false;
/*     */   private boolean _standaloneSet = false;
/*     */   
/*     */   public void reset() {
/*  56 */     this._encoding = "UTF-8";
/*  57 */     this._standalone = true;
/*  58 */     this._version = "1.0";
/*  59 */     this._encodingSet = false;
/*  60 */     this._standaloneSet = false;
/*     */   }
/*     */   public StartDocumentEvent() {
/*  63 */     this(null, null);
/*     */   }
/*     */   
/*     */   public StartDocumentEvent(String encoding) {
/*  67 */     this(encoding, null);
/*     */   }
/*     */   
/*     */   public StartDocumentEvent(String encoding, String version) {
/*  71 */     if (encoding != null) {
/*  72 */       this._encoding = encoding;
/*  73 */       this._encodingSet = true;
/*     */     } 
/*  75 */     if (version != null)
/*  76 */       this._version = version; 
/*  77 */     setEventType(7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSystemId() {
/*  87 */     return super.getSystemId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharacterEncodingScheme() {
/*  95 */     return this._encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean encodingSet() {
/* 102 */     return this._encodingSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStandalone() {
/* 111 */     return this._standalone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean standaloneSet() {
/* 118 */     return this._standaloneSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVersion() {
/* 126 */     return this._version;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStandalone(boolean standalone) {
/* 131 */     this._standaloneSet = true;
/* 132 */     this._standalone = standalone;
/*     */   }
/*     */   
/*     */   public void setStandalone(String s) {
/* 136 */     this._standaloneSet = true;
/* 137 */     if (s == null) {
/* 138 */       this._standalone = true;
/*     */       return;
/*     */     } 
/* 141 */     if (s.equals("yes")) {
/* 142 */       this._standalone = true;
/*     */     } else {
/* 144 */       this._standalone = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setEncoding(String encoding) {
/* 149 */     this._encoding = encoding;
/* 150 */     this._encodingSet = true;
/*     */   }
/*     */   
/*     */   void setDeclaredEncoding(boolean value) {
/* 154 */     this._encodingSet = value;
/*     */   }
/*     */   
/*     */   public void setVersion(String s) {
/* 158 */     this._version = s;
/*     */   }
/*     */   
/*     */   void clear() {
/* 162 */     this._encoding = "UTF-8";
/* 163 */     this._standalone = true;
/* 164 */     this._version = "1.0";
/* 165 */     this._encodingSet = false;
/* 166 */     this._standaloneSet = false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 170 */     String s = "<?xml version=\"" + this._version + "\"";
/* 171 */     s = s + " encoding='" + this._encoding + "'";
/* 172 */     if (this._standaloneSet)
/* 173 */     { if (this._standalone) {
/* 174 */         s = s + " standalone='yes'?>";
/*     */       } else {
/* 176 */         s = s + " standalone='no'?>";
/*     */       }  }
/* 178 */     else { s = s + "?>"; }
/*     */     
/* 180 */     return s;
/*     */   }
/*     */   
/*     */   public boolean isStartDocument() {
/* 184 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\StartDocumentEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */