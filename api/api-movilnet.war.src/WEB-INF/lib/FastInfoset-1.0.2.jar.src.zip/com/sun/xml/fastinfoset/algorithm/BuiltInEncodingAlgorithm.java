/*    */ package com.sun.xml.fastinfoset.algorithm;
/*    */ 
/*    */ import java.nio.CharBuffer;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.jvnet.fastinfoset.EncodingAlgorithm;
/*    */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BuiltInEncodingAlgorithm
/*    */   implements EncodingAlgorithm
/*    */ {
/* 49 */   protected static final Pattern SPACE_PATTERN = Pattern.compile("\\s");
/*    */ 
/*    */   
/*    */   public abstract int getPrimtiveLengthFromOctetLength(int paramInt) throws EncodingAlgorithmException;
/*    */ 
/*    */   
/*    */   public abstract int getOctetLengthFromPrimitiveLength(int paramInt);
/*    */ 
/*    */   
/*    */   public abstract void encodeToBytes(Object paramObject, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3);
/*    */ 
/*    */   
/*    */   public void matchWhiteSpaceDelimnatedWords(CharBuffer cb, WordListener wl) {
/* 62 */     Matcher m = SPACE_PATTERN.matcher(cb);
/* 63 */     int i = 0;
/* 64 */     while (m.find()) {
/* 65 */       int s = m.start();
/* 66 */       if (s != i) {
/* 67 */         wl.word(i, s);
/*    */       }
/* 69 */       i = m.end();
/*    */     } 
/*    */   }
/*    */   
/*    */   public StringBuffer removeWhitespace(char[] ch, int start, int length) {
/* 74 */     StringBuffer buf = new StringBuffer();
/* 75 */     int firstNonWS = 0;
/* 76 */     int idx = 0;
/* 77 */     for (; idx < length; idx++) {
/* 78 */       if (Character.isWhitespace(ch[idx])) {
/* 79 */         if (firstNonWS < idx) {
/* 80 */           buf.append(ch, firstNonWS, idx - firstNonWS);
/*    */         }
/* 82 */         firstNonWS = idx + 1;
/*    */       } 
/*    */     } 
/* 85 */     if (firstNonWS < idx) {
/* 86 */       buf.append(ch, firstNonWS, idx - firstNonWS);
/*    */     }
/* 88 */     return buf;
/*    */   }
/*    */   
/*    */   public static interface WordListener {
/*    */     void word(int param1Int1, int param1Int2);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\BuiltInEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */