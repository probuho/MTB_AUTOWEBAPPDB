/*     */ package com.sun.xml.fastinfoset.stax.util;
/*     */ 
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXParserWrapper
/*     */   implements XMLStreamReader
/*     */ {
/*     */   private XMLStreamReader _reader;
/*     */   
/*     */   public StAXParserWrapper() {}
/*     */   
/*     */   public StAXParserWrapper(XMLStreamReader reader) {
/*  57 */     this._reader = reader;
/*     */   }
/*     */   public void setReader(XMLStreamReader reader) {
/*  60 */     this._reader = reader;
/*     */   }
/*     */   public XMLStreamReader getReader() {
/*  63 */     return this._reader;
/*     */   }
/*     */ 
/*     */   
/*     */   public int next() throws XMLStreamException {
/*  68 */     return this._reader.next();
/*     */   }
/*     */ 
/*     */   
/*     */   public int nextTag() throws XMLStreamException {
/*  73 */     return this._reader.nextTag();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementText() throws XMLStreamException {
/*  78 */     return this._reader.getElementText();
/*     */   }
/*     */ 
/*     */   
/*     */   public void require(int type, String namespaceURI, String localName) throws XMLStreamException {
/*  83 */     this._reader.require(type, namespaceURI, localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() throws XMLStreamException {
/*  88 */     return this._reader.hasNext();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws XMLStreamException {
/*  93 */     this._reader.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/*  98 */     return this._reader.getNamespaceURI(prefix);
/*     */   }
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 102 */     return this._reader.getNamespaceContext();
/*     */   }
/*     */   
/*     */   public boolean isStartElement() {
/* 106 */     return this._reader.isStartElement();
/*     */   }
/*     */   
/*     */   public boolean isEndElement() {
/* 110 */     return this._reader.isEndElement();
/*     */   }
/*     */   
/*     */   public boolean isCharacters() {
/* 114 */     return this._reader.isCharacters();
/*     */   }
/*     */   
/*     */   public boolean isWhiteSpace() {
/* 118 */     return this._reader.isWhiteSpace();
/*     */   }
/*     */   
/*     */   public QName getAttributeName(int index) {
/* 122 */     return this._reader.getAttributeName(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextCharacters(int sourceStart, char[] target, int targetStart, int length) throws XMLStreamException {
/* 128 */     return this._reader.getTextCharacters(sourceStart, target, targetStart, length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttributeValue(String namespaceUri, String localName) {
/* 134 */     return this._reader.getAttributeValue(namespaceUri, localName);
/*     */   }
/*     */   public int getAttributeCount() {
/* 137 */     return this._reader.getAttributeCount();
/*     */   }
/*     */   public String getAttributePrefix(int index) {
/* 140 */     return this._reader.getAttributePrefix(index);
/*     */   }
/*     */   public String getAttributeNamespace(int index) {
/* 143 */     return this._reader.getAttributeNamespace(index);
/*     */   }
/*     */   public String getAttributeLocalName(int index) {
/* 146 */     return this._reader.getAttributeLocalName(index);
/*     */   }
/*     */   public String getAttributeType(int index) {
/* 149 */     return this._reader.getAttributeType(index);
/*     */   }
/*     */   public String getAttributeValue(int index) {
/* 152 */     return this._reader.getAttributeValue(index);
/*     */   }
/*     */   public boolean isAttributeSpecified(int index) {
/* 155 */     return this._reader.isAttributeSpecified(index);
/*     */   }
/*     */   
/*     */   public int getNamespaceCount() {
/* 159 */     return this._reader.getNamespaceCount();
/*     */   }
/*     */   public String getNamespacePrefix(int index) {
/* 162 */     return this._reader.getNamespacePrefix(index);
/*     */   }
/*     */   public String getNamespaceURI(int index) {
/* 165 */     return this._reader.getNamespaceURI(index);
/*     */   }
/*     */   
/*     */   public int getEventType() {
/* 169 */     return this._reader.getEventType();
/*     */   }
/*     */   
/*     */   public String getText() {
/* 173 */     return this._reader.getText();
/*     */   }
/*     */   
/*     */   public char[] getTextCharacters() {
/* 177 */     return this._reader.getTextCharacters();
/*     */   }
/*     */   
/*     */   public int getTextStart() {
/* 181 */     return this._reader.getTextStart();
/*     */   }
/*     */   
/*     */   public int getTextLength() {
/* 185 */     return this._reader.getTextLength();
/*     */   }
/*     */   
/*     */   public String getEncoding() {
/* 189 */     return this._reader.getEncoding();
/*     */   }
/*     */   
/*     */   public boolean hasText() {
/* 193 */     return this._reader.hasText();
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/* 197 */     return this._reader.getLocation();
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 201 */     return this._reader.getName();
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/* 205 */     return this._reader.getLocalName();
/*     */   }
/*     */   
/*     */   public boolean hasName() {
/* 209 */     return this._reader.hasName();
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/* 213 */     return this._reader.getNamespaceURI();
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 217 */     return this._reader.getPrefix();
/*     */   }
/*     */   
/*     */   public String getVersion() {
/* 221 */     return this._reader.getVersion();
/*     */   }
/*     */   
/*     */   public boolean isStandalone() {
/* 225 */     return this._reader.isStandalone();
/*     */   }
/*     */   
/*     */   public boolean standaloneSet() {
/* 229 */     return this._reader.standaloneSet();
/*     */   }
/*     */   
/*     */   public String getCharacterEncodingScheme() {
/* 233 */     return this._reader.getCharacterEncodingScheme();
/*     */   }
/*     */   
/*     */   public String getPITarget() {
/* 237 */     return this._reader.getPITarget();
/*     */   }
/*     */   
/*     */   public String getPIData() {
/* 241 */     return this._reader.getPIData();
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) {
/* 245 */     return this._reader.getProperty(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sta\\util\StAXParserWrapper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */