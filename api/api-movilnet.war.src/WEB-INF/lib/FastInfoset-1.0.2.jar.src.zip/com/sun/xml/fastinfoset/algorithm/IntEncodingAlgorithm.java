/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.CharBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntEncodingAlgorithm
/*     */   extends IntegerEncodingAlgorithm
/*     */ {
/*     */   public final int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/*  57 */     if (octetLength % 4 != 0) {
/*  58 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.lengthNotMultipleOfInt", new Object[] { new Integer(4) }));
/*     */     }
/*     */ 
/*     */     
/*  62 */     return octetLength / 4;
/*     */   }
/*     */   
/*     */   public int getOctetLengthFromPrimitiveLength(int primitiveLength) {
/*  66 */     return primitiveLength * 4;
/*     */   }
/*     */   
/*     */   public final Object decodeFromBytes(byte[] b, int start, int length) throws EncodingAlgorithmException {
/*  70 */     int[] data = new int[getPrimtiveLengthFromOctetLength(length)];
/*  71 */     decodeFromBytesToIntArray(data, 0, b, start, length);
/*     */     
/*  73 */     return data;
/*     */   }
/*     */   
/*     */   public final Object decodeFromInputStream(InputStream s) throws IOException {
/*  77 */     return decodeFromInputStreamToIntArray(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeToOutputStream(Object data, OutputStream s) throws IOException {
/*  82 */     if (!(data instanceof int[])) {
/*  83 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotIntArray"));
/*     */     }
/*     */     
/*  86 */     int[] idata = (int[])data;
/*     */     
/*  88 */     encodeToOutputStreamFromIntArray(idata, s);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object convertFromCharacters(char[] ch, int start, int length) {
/*  93 */     final CharBuffer cb = CharBuffer.wrap(ch, start, length);
/*  94 */     final List integerList = new ArrayList();
/*     */     
/*  96 */     matchWhiteSpaceDelimnatedWords(cb, new BuiltInEncodingAlgorithm.WordListener()
/*     */         {
/*     */           public void word(int start, int end) {
/*  99 */             String iStringValue = cb.subSequence(start, end).toString();
/* 100 */             integerList.add(Integer.valueOf(iStringValue));
/*     */           }
/*     */           private final CharBuffer val$cb; private final List val$integerList;
/*     */           private final IntEncodingAlgorithm this$0;
/*     */         });
/* 105 */     return generateArrayFromList(integerList);
/*     */   }
/*     */   
/*     */   public final void convertToCharacters(Object data, StringBuffer s) {
/* 109 */     if (!(data instanceof int[])) {
/* 110 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotIntArray"));
/*     */     }
/*     */     
/* 113 */     int[] idata = (int[])data;
/*     */     
/* 115 */     convertToCharactersFromIntArray(idata, s);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void decodeFromBytesToIntArray(int[] idata, int istart, byte[] b, int start, int length) {
/* 120 */     int size = length / 4;
/* 121 */     for (int i = 0; i < size; i++) {
/* 122 */       idata[istart++] = (b[start++] & 0xFF) << 24 | (b[start++] & 0xFF) << 16 | (b[start++] & 0xFF) << 8 | b[start++] & 0xFF;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int[] decodeFromInputStreamToIntArray(InputStream s) throws IOException {
/* 130 */     List integerList = new ArrayList();
/* 131 */     byte[] b = new byte[4];
/*     */     
/*     */     while (true) {
/* 134 */       int n = s.read(b);
/* 135 */       if (n != 4) {
/* 136 */         if (n == -1) {
/*     */           break;
/*     */         }
/*     */         
/* 140 */         while (n != 4) {
/* 141 */           int m = s.read(b, n, 4 - n);
/* 142 */           if (m == -1) {
/* 143 */             throw new EOFException();
/*     */           }
/* 145 */           n += m;
/*     */         } 
/*     */       } 
/*     */       
/* 149 */       int i = (b[0] & 0xFF) << 24 | (b[1] & 0xFF) << 16 | (b[2] & 0xFF) << 8 | b[3] & 0xFF;
/*     */ 
/*     */ 
/*     */       
/* 153 */       integerList.add(new Integer(i));
/*     */     } 
/*     */     
/* 156 */     return generateArrayFromList(integerList);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void encodeToOutputStreamFromIntArray(int[] idata, OutputStream s) throws IOException {
/* 161 */     for (int i = 0; i < idata.length; i++) {
/* 162 */       int bits = idata[i];
/* 163 */       s.write(bits >>> 24 & 0xFF);
/* 164 */       s.write(bits >>> 16 & 0xFF);
/* 165 */       s.write(bits >>> 8 & 0xFF);
/* 166 */       s.write(bits & 0xFF);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void encodeToBytes(Object array, int astart, int alength, byte[] b, int start) {
/* 171 */     encodeToBytesFromIntArray((int[])array, astart, alength, b, start);
/*     */   }
/*     */   
/*     */   public final void encodeToBytesFromIntArray(int[] idata, int istart, int ilength, byte[] b, int start) {
/* 175 */     int iend = istart + ilength;
/* 176 */     for (int i = istart; i < iend; i++) {
/* 177 */       int bits = idata[i];
/* 178 */       b[start++] = (byte)(bits >>> 24 & 0xFF);
/* 179 */       b[start++] = (byte)(bits >>> 16 & 0xFF);
/* 180 */       b[start++] = (byte)(bits >>> 8 & 0xFF);
/* 181 */       b[start++] = (byte)(bits & 0xFF);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void convertToCharactersFromIntArray(int[] idata, StringBuffer s) {
/* 187 */     int end = idata.length - 1;
/* 188 */     for (int i = 0; i <= end; i++) {
/* 189 */       s.append(Integer.toString(idata[i]));
/* 190 */       if (i != end) {
/* 191 */         s.append(' ');
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final int[] generateArrayFromList(List array) {
/* 198 */     int[] idata = new int[array.size()];
/* 199 */     for (int i = 0; i < idata.length; i++) {
/* 200 */       idata[i] = ((Integer)array.get(i)).intValue();
/*     */     }
/*     */     
/* 203 */     return idata;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\IntEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */