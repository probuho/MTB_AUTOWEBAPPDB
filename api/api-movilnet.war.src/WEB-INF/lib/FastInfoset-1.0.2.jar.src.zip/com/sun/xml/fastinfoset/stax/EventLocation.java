/*     */ package com.sun.xml.fastinfoset.stax;
/*     */ 
/*     */ import javax.xml.stream.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventLocation
/*     */   implements Location
/*     */ {
/*  45 */   String _systemId = null;
/*  46 */   String _publicId = null;
/*  47 */   int _column = -1;
/*  48 */   int _line = -1;
/*  49 */   int _charOffset = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Location getNilLocation() {
/*  56 */     return new EventLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/*  64 */     return this._line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnNumber() {
/*  72 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCharacterOffset() {
/*  84 */     return this._charOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPublicId() {
/*  92 */     return this._publicId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSystemId() {
/* 100 */     return this._systemId;
/*     */   }
/*     */   
/*     */   public void setLineNumber(int line) {
/* 104 */     this._line = line;
/*     */   }
/*     */   public void setColumnNumber(int col) {
/* 107 */     this._column = col;
/*     */   }
/*     */   public void setCharacterOffset(int offset) {
/* 110 */     this._charOffset = offset;
/*     */   }
/*     */   public void setPublicId(String id) {
/* 113 */     this._publicId = id;
/*     */   }
/*     */   public void setSystemId(String id) {
/* 116 */     this._systemId = id;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 120 */     StringBuffer sbuffer = new StringBuffer();
/* 121 */     sbuffer.append("Line number = " + this._line);
/* 122 */     sbuffer.append("\n");
/* 123 */     sbuffer.append("Column number = " + this._column);
/* 124 */     sbuffer.append("\n");
/* 125 */     sbuffer.append("System Id = " + this._systemId);
/* 126 */     sbuffer.append("\n");
/* 127 */     sbuffer.append("Public Id = " + this._publicId);
/* 128 */     sbuffer.append("\n");
/* 129 */     sbuffer.append("CharacterOffset = " + this._charOffset);
/* 130 */     sbuffer.append("\n");
/* 131 */     return sbuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\EventLocation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */