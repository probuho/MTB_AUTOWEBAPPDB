/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.jvnet.fastinfoset.FastInfosetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrefixArray
/*     */   extends ValueArray
/*     */ {
/*     */   public static final int PREFIX_MAP_SIZE = 64;
/*     */   private int _initialCapacity;
/*     */   public String[] _array;
/*     */   private PrefixArray _readOnlyArray;
/*     */   
/*     */   private static class PrefixEntry
/*     */   {
/*     */     private PrefixEntry next;
/*     */     private int prefixId;
/*     */     
/*     */     private PrefixEntry() {}
/*     */   }
/*  62 */   private PrefixEntry[] _prefixMap = new PrefixEntry[64];
/*     */   
/*     */   private PrefixEntry _prefixPool;
/*     */   
/*     */   private NamespaceEntry _namespacePool;
/*     */   
/*     */   private NamespaceEntry[] _inScopeNamespaces;
/*     */   public int[] _currentInScope;
/*     */   public int _declarationId;
/*     */   
/*     */   private static class NamespaceEntry
/*     */   {
/*     */     private NamespaceEntry next;
/*     */     private int declarationId;
/*     */     private int namespaceIndex;
/*     */     private String prefix;
/*     */     private String namespaceName;
/*     */     private int prefixEntryIndex;
/*     */     
/*     */     private NamespaceEntry() {}
/*     */   }
/*     */   
/*     */   public PrefixArray(int initialCapacity, int maximumCapacity) {
/*  85 */     this._initialCapacity = initialCapacity;
/*  86 */     this._maximumCapacity = maximumCapacity;
/*     */     
/*  88 */     this._array = new String[initialCapacity];
/*     */ 
/*     */ 
/*     */     
/*  92 */     this._inScopeNamespaces = new NamespaceEntry[initialCapacity + 2];
/*  93 */     this._currentInScope = new int[initialCapacity + 2];
/*     */     
/*  95 */     increaseNamespacePool(initialCapacity);
/*  96 */     increasePrefixPool(initialCapacity);
/*     */     
/*  98 */     initializeEntries();
/*     */   }
/*     */   
/*     */   public PrefixArray() {
/* 102 */     this(10, 2147483647);
/*     */   }
/*     */   
/*     */   private final void initializeEntries() {
/* 106 */     this._inScopeNamespaces[0] = this._namespacePool;
/* 107 */     this._namespacePool = this._namespacePool.next;
/* 108 */     (this._inScopeNamespaces[0]).next = null;
/* 109 */     (this._inScopeNamespaces[0]).prefix = "";
/* 110 */     (this._inScopeNamespaces[0]).namespaceName = "";
/* 111 */     (this._inScopeNamespaces[0]).namespaceIndex = this._currentInScope[0] = 0;
/*     */     
/* 113 */     int index = KeyIntMap.indexFor(KeyIntMap.hashHash((this._inScopeNamespaces[0]).prefix.hashCode()), this._prefixMap.length);
/* 114 */     this._prefixMap[index] = this._prefixPool;
/* 115 */     this._prefixPool = this._prefixPool.next;
/* 116 */     (this._prefixMap[index]).next = null;
/* 117 */     (this._prefixMap[index]).prefixId = 0;
/*     */ 
/*     */     
/* 120 */     this._inScopeNamespaces[1] = this._namespacePool;
/* 121 */     this._namespacePool = this._namespacePool.next;
/* 122 */     (this._inScopeNamespaces[1]).next = null;
/* 123 */     (this._inScopeNamespaces[1]).prefix = "xml";
/* 124 */     (this._inScopeNamespaces[1]).namespaceName = "http://www.w3.org/XML/1998/namespace";
/* 125 */     (this._inScopeNamespaces[1]).namespaceIndex = this._currentInScope[1] = 1;
/*     */     
/* 127 */     index = KeyIntMap.indexFor(KeyIntMap.hashHash((this._inScopeNamespaces[1]).prefix.hashCode()), this._prefixMap.length);
/* 128 */     if (this._prefixMap[index] == null) {
/* 129 */       this._prefixMap[index] = this._prefixPool;
/* 130 */       this._prefixPool = this._prefixPool.next;
/* 131 */       (this._prefixMap[index]).next = null;
/*     */     } else {
/* 133 */       PrefixEntry e = this._prefixMap[index];
/* 134 */       this._prefixMap[index] = this._prefixPool;
/* 135 */       this._prefixPool = this._prefixPool.next;
/* 136 */       (this._prefixMap[index]).next = e;
/*     */     } 
/* 138 */     (this._prefixMap[index]).prefixId = 1;
/*     */   }
/*     */   
/*     */   private final void increaseNamespacePool(int capacity) {
/* 142 */     if (this._namespacePool == null) {
/* 143 */       this._namespacePool = new NamespaceEntry();
/*     */     }
/*     */     
/* 146 */     for (int i = 0; i < capacity; i++) {
/* 147 */       NamespaceEntry ne = new NamespaceEntry();
/* 148 */       ne.next = this._namespacePool;
/* 149 */       this._namespacePool = ne;
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void increasePrefixPool(int capacity) {
/* 154 */     if (this._prefixPool == null) {
/* 155 */       this._prefixPool = new PrefixEntry();
/*     */     }
/*     */     
/* 158 */     for (int i = 0; i < capacity; i++) {
/* 159 */       PrefixEntry pe = new PrefixEntry();
/* 160 */       pe.next = this._prefixPool;
/* 161 */       this._prefixPool = pe;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int countNamespacePool() {
/* 166 */     int i = 0;
/* 167 */     NamespaceEntry e = this._namespacePool;
/* 168 */     while (e != null) {
/* 169 */       i++;
/* 170 */       e = e.next;
/*     */     } 
/* 172 */     return i;
/*     */   }
/*     */   
/*     */   public int countPrefixPool() {
/* 176 */     int i = 0;
/* 177 */     PrefixEntry e = this._prefixPool;
/* 178 */     while (e != null) {
/* 179 */       i++;
/* 180 */       e = e.next;
/*     */     } 
/* 182 */     return i;
/*     */   }
/*     */   
/*     */   public final void clear() {
/* 186 */     for (int i = this._readOnlyArraySize; i < this._size; i++) {
/* 187 */       this._array[i] = null;
/*     */     }
/* 189 */     this._size = this._readOnlyArraySize;
/*     */   }
/*     */   
/*     */   public final void clearCompletely() {
/* 193 */     this._prefixPool = null;
/* 194 */     this._namespacePool = null;
/*     */     int i;
/* 196 */     for (i = 0; i < this._size + 2; i++) {
/* 197 */       this._currentInScope[i] = 0;
/* 198 */       this._inScopeNamespaces[i] = null;
/*     */     } 
/*     */     
/* 201 */     for (i = 0; i < this._prefixMap.length; i++) {
/* 202 */       this._prefixMap[i] = null;
/*     */     }
/*     */     
/* 205 */     increaseNamespacePool(this._initialCapacity);
/* 206 */     increasePrefixPool(this._initialCapacity);
/*     */     
/* 208 */     initializeEntries();
/*     */     
/* 210 */     this._declarationId = 0;
/*     */     
/* 212 */     clear();
/*     */   }
/*     */   
/*     */   public final String[] getArray() {
/* 216 */     return this._array;
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(ValueArray readOnlyArray, boolean clear) {
/* 220 */     if (!(readOnlyArray instanceof PrefixArray)) {
/* 221 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyArray }));
/*     */     }
/*     */ 
/*     */     
/* 225 */     setReadOnlyArray((PrefixArray)readOnlyArray, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(PrefixArray readOnlyArray, boolean clear) {
/* 229 */     if (readOnlyArray != null) {
/* 230 */       this._readOnlyArray = readOnlyArray;
/* 231 */       this._readOnlyArraySize = readOnlyArray.getSize();
/*     */       
/* 233 */       clearCompletely();
/*     */ 
/*     */       
/* 236 */       this._inScopeNamespaces = new NamespaceEntry[this._readOnlyArraySize + this._inScopeNamespaces.length];
/* 237 */       this._currentInScope = new int[this._readOnlyArraySize + this._currentInScope.length];
/*     */       
/* 239 */       initializeEntries();
/*     */       
/* 241 */       if (clear) {
/* 242 */         clear();
/*     */       }
/*     */       
/* 245 */       this._array = getCompleteArray();
/* 246 */       this._size = this._readOnlyArraySize;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final String[] getCompleteArray() {
/* 251 */     if (this._readOnlyArray == null) {
/* 252 */       return this._array;
/*     */     }
/* 254 */     String[] ra = this._readOnlyArray.getCompleteArray();
/* 255 */     String[] a = new String[this._readOnlyArraySize + this._array.length];
/* 256 */     System.arraycopy(ra, 0, a, 0, this._readOnlyArraySize);
/* 257 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String get(int i) {
/* 262 */     return this._array[i];
/*     */   }
/*     */   
/*     */   public final int add(String s) {
/* 266 */     if (this._size == this._array.length) {
/* 267 */       resize();
/*     */     }
/*     */     
/* 270 */     this._array[this._size++] = s;
/* 271 */     return this._size;
/*     */   }
/*     */   
/*     */   protected final void resize() {
/* 275 */     if (this._size == this._maximumCapacity) {
/* 276 */       throw new ValueArrayResourceException(CommonResourceBundle.getInstance().getString("message.arrayMaxCapacity"));
/*     */     }
/*     */     
/* 279 */     int newSize = this._size * 3 / 2 + 1;
/* 280 */     if (newSize > this._maximumCapacity) {
/* 281 */       newSize = this._maximumCapacity;
/*     */     }
/*     */     
/* 284 */     String[] newArray = new String[newSize];
/* 285 */     System.arraycopy(this._array, 0, newArray, 0, this._size);
/* 286 */     this._array = newArray;
/*     */     
/* 288 */     newSize += this._readOnlyArraySize;
/* 289 */     NamespaceEntry[] newInScopeNamespaces = new NamespaceEntry[newSize + 2];
/* 290 */     System.arraycopy(this._inScopeNamespaces, 0, newInScopeNamespaces, 0, this._readOnlyArraySize + this._size + 2);
/* 291 */     this._inScopeNamespaces = newInScopeNamespaces;
/*     */     
/* 293 */     int[] newCurrentInScope = new int[newSize + 2];
/* 294 */     System.arraycopy(this._currentInScope, 0, newCurrentInScope, 0, this._readOnlyArraySize + this._size + 2);
/* 295 */     this._currentInScope = newCurrentInScope;
/*     */   }
/*     */   
/*     */   public final void clearDeclarationIds() {
/* 299 */     for (int i = 0; i < this._size; i++) {
/* 300 */       NamespaceEntry e = this._inScopeNamespaces[i];
/* 301 */       if (e != null) {
/* 302 */         e.declarationId = 0;
/*     */       }
/*     */     } 
/*     */     
/* 306 */     this._declarationId = 1;
/*     */   }
/*     */   
/*     */   public final void pushScope(int prefixIndex, int namespaceIndex) throws FastInfosetException {
/* 310 */     if (this._namespacePool == null) {
/* 311 */       increaseNamespacePool(16);
/*     */     }
/*     */     
/* 314 */     NamespaceEntry e = this._namespacePool;
/* 315 */     this._namespacePool = e.next;
/*     */     
/* 317 */     NamespaceEntry current = this._inScopeNamespaces[++prefixIndex];
/* 318 */     if (current == null) {
/* 319 */       e.declarationId = this._declarationId;
/* 320 */       e.namespaceIndex = this._currentInScope[prefixIndex] = ++namespaceIndex;
/* 321 */       e.next = null;
/*     */       
/* 323 */       this._inScopeNamespaces[prefixIndex] = e;
/* 324 */     } else if (current.declarationId < this._declarationId) {
/* 325 */       e.declarationId = this._declarationId;
/* 326 */       e.namespaceIndex = this._currentInScope[prefixIndex] = ++namespaceIndex;
/* 327 */       e.next = current;
/*     */       
/* 329 */       current.declarationId = 0;
/* 330 */       this._inScopeNamespaces[prefixIndex] = e;
/*     */     } else {
/* 332 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.duplicateNamespaceAttribute"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void pushScopeWithPrefixEntry(String prefix, String namespaceName, int prefixIndex, int namespaceIndex) throws FastInfosetException {
/* 338 */     if (this._namespacePool == null) {
/* 339 */       increaseNamespacePool(16);
/*     */     }
/* 341 */     if (this._prefixPool == null) {
/* 342 */       increasePrefixPool(16);
/*     */     }
/*     */     
/* 345 */     NamespaceEntry e = this._namespacePool;
/* 346 */     this._namespacePool = e.next;
/*     */     
/* 348 */     NamespaceEntry current = this._inScopeNamespaces[++prefixIndex];
/* 349 */     if (current == null) {
/* 350 */       e.declarationId = this._declarationId;
/* 351 */       e.namespaceIndex = this._currentInScope[prefixIndex] = ++namespaceIndex;
/* 352 */       e.next = null;
/*     */       
/* 354 */       this._inScopeNamespaces[prefixIndex] = e;
/* 355 */     } else if (current.declarationId < this._declarationId) {
/* 356 */       e.declarationId = this._declarationId;
/* 357 */       e.namespaceIndex = this._currentInScope[prefixIndex] = ++namespaceIndex;
/* 358 */       e.next = current;
/*     */       
/* 360 */       current.declarationId = 0;
/* 361 */       this._inScopeNamespaces[prefixIndex] = e;
/*     */     } else {
/* 363 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.duplicateNamespaceAttribute"));
/*     */     } 
/*     */     
/* 366 */     PrefixEntry p = this._prefixPool;
/* 367 */     this._prefixPool = this._prefixPool.next;
/* 368 */     p.prefixId = prefixIndex;
/*     */     
/* 370 */     e.prefix = prefix;
/* 371 */     e.namespaceName = namespaceName;
/* 372 */     e.prefixEntryIndex = KeyIntMap.indexFor(KeyIntMap.hashHash(prefix.hashCode()), this._prefixMap.length);
/*     */     
/* 374 */     PrefixEntry pCurrent = this._prefixMap[e.prefixEntryIndex];
/* 375 */     p.next = pCurrent;
/* 376 */     this._prefixMap[e.prefixEntryIndex] = p;
/*     */   }
/*     */   
/*     */   public final void popScope(int prefixIndex) {
/* 380 */     NamespaceEntry e = this._inScopeNamespaces[++prefixIndex];
/* 381 */     this._inScopeNamespaces[prefixIndex] = e.next;
/* 382 */     this._currentInScope[prefixIndex] = (e.next != null) ? e.next.namespaceIndex : 0;
/*     */     
/* 384 */     e.next = this._namespacePool;
/* 385 */     this._namespacePool = e;
/*     */   }
/*     */   
/*     */   public final void popScopeWithPrefixEntry(int prefixIndex) {
/* 389 */     NamespaceEntry e = this._inScopeNamespaces[++prefixIndex];
/*     */     
/* 391 */     this._inScopeNamespaces[prefixIndex] = e.next;
/* 392 */     this._currentInScope[prefixIndex] = (e.next != null) ? e.next.namespaceIndex : 0;
/*     */     
/* 394 */     e.prefix = e.namespaceName = null;
/* 395 */     e.next = this._namespacePool;
/* 396 */     this._namespacePool = e;
/*     */     
/* 398 */     PrefixEntry current = this._prefixMap[e.prefixEntryIndex];
/* 399 */     if (current.prefixId == prefixIndex) {
/* 400 */       this._prefixMap[e.prefixEntryIndex] = current.next;
/* 401 */       current.next = this._prefixPool;
/* 402 */       this._prefixPool = current;
/*     */     } else {
/* 404 */       PrefixEntry prev = current;
/* 405 */       current = current.next;
/* 406 */       while (current != null) {
/* 407 */         if (current.prefixId == prefixIndex) {
/* 408 */           prev.next = current.next;
/* 409 */           current.next = this._prefixPool;
/* 410 */           this._prefixPool = current;
/*     */           break;
/*     */         } 
/* 413 */         prev = current;
/* 414 */         current = current.next;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final String getNamespaceFromPrefix(String prefix) {
/* 420 */     int index = KeyIntMap.indexFor(KeyIntMap.hashHash(prefix.hashCode()), this._prefixMap.length);
/* 421 */     PrefixEntry pe = this._prefixMap[index];
/* 422 */     while (pe != null) {
/* 423 */       NamespaceEntry ne = this._inScopeNamespaces[pe.prefixId];
/* 424 */       if (prefix == ne.prefix || prefix.equals(ne.prefix)) {
/* 425 */         return ne.namespaceName;
/*     */       }
/* 427 */       pe = pe.next;
/*     */     } 
/*     */     
/* 430 */     return null;
/*     */   }
/*     */   
/*     */   public final String getPrefixFromNamespace(String namespaceName) {
/* 434 */     int position = 0;
/* 435 */     while (++position < this._size + 2) {
/* 436 */       NamespaceEntry ne = this._inScopeNamespaces[position];
/* 437 */       if (ne != null && namespaceName.equals(ne.namespaceName)) {
/* 438 */         return ne.prefix;
/*     */       }
/*     */     } 
/*     */     
/* 442 */     return null;
/*     */   }
/*     */   
/*     */   public final Iterator getPrefixes() {
/* 446 */     return new Iterator() {
/* 447 */         int _position = 1;
/* 448 */         PrefixArray.NamespaceEntry _ne = PrefixArray.this._inScopeNamespaces[this._position];
/*     */         
/*     */         public boolean hasNext() {
/* 451 */           return (this._ne != null);
/*     */         }
/*     */         private final PrefixArray this$0;
/*     */         public Object next() {
/* 455 */           if (this._position == PrefixArray.this._size + 2) {
/* 456 */             throw new NoSuchElementException();
/*     */           }
/*     */           
/* 459 */           String prefix = this._ne.prefix;
/* 460 */           moveToNext();
/* 461 */           return prefix;
/*     */         }
/*     */         
/*     */         public void remove() {
/* 465 */           throw new UnsupportedOperationException();
/*     */         }
/*     */         
/*     */         private final void moveToNext() {
/* 469 */           while (++this._position < PrefixArray.this._size + 2) {
/* 470 */             this._ne = PrefixArray.this._inScopeNamespaces[this._position];
/* 471 */             if (this._ne != null) {
/*     */               return;
/*     */             }
/*     */           } 
/* 475 */           this._ne = null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public final Iterator getPrefixesFromNamespace(final String namespaceName) {
/* 482 */     return new Iterator()
/*     */       {
/*     */         String _namespaceName;
/*     */         
/*     */         int _position;
/*     */         PrefixArray.NamespaceEntry _ne;
/*     */         private final String val$namespaceName;
/*     */         private final PrefixArray this$0;
/*     */         
/*     */         public boolean hasNext() {
/* 492 */           return (this._ne != null);
/*     */         }
/*     */         
/*     */         public Object next() {
/* 496 */           if (this._position == PrefixArray.this._size + 2) {
/* 497 */             throw new NoSuchElementException();
/*     */           }
/*     */           
/* 500 */           String prefix = this._ne.prefix;
/* 501 */           moveToNext();
/* 502 */           return prefix;
/*     */         }
/*     */         
/*     */         public void remove() {
/* 506 */           throw new UnsupportedOperationException();
/*     */         }
/*     */         
/*     */         private final void moveToNext() {
/* 510 */           while (++this._position < PrefixArray.this._size + 2) {
/* 511 */             this._ne = PrefixArray.this._inScopeNamespaces[this._position];
/* 512 */             if (this._ne != null && this._namespaceName.equals(this._ne.namespaceName)) {
/*     */               return;
/*     */             }
/*     */           } 
/* 516 */           this._ne = null;
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\PrefixArray.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */