/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.CharBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatEncodingAlgorithm
/*     */   extends IEEE754FloatingPointEncodingAlgorithm
/*     */ {
/*     */   public final int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/*  58 */     if (octetLength % 4 != 0) {
/*  59 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.lengthNotMultipleOfFloat", new Object[] { new Integer(4) }));
/*     */     }
/*     */ 
/*     */     
/*  63 */     return octetLength / 4;
/*     */   }
/*     */   
/*     */   public int getOctetLengthFromPrimitiveLength(int primitiveLength) {
/*  67 */     return primitiveLength * 4;
/*     */   }
/*     */   
/*     */   public final Object decodeFromBytes(byte[] b, int start, int length) throws EncodingAlgorithmException {
/*  71 */     float[] data = new float[getPrimtiveLengthFromOctetLength(length)];
/*  72 */     decodeFromBytesToFloatArray(data, 0, b, start, length);
/*     */     
/*  74 */     return data;
/*     */   }
/*     */   
/*     */   public final Object decodeFromInputStream(InputStream s) throws IOException {
/*  78 */     return decodeFromInputStreamToFloatArray(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeToOutputStream(Object data, OutputStream s) throws IOException {
/*  83 */     if (!(data instanceof float[])) {
/*  84 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotFloat"));
/*     */     }
/*     */     
/*  87 */     float[] fdata = (float[])data;
/*     */     
/*  89 */     encodeToOutputStreamFromFloatArray(fdata, s);
/*     */   }
/*     */   
/*     */   public final Object convertFromCharacters(char[] ch, int start, int length) {
/*  93 */     final CharBuffer cb = CharBuffer.wrap(ch, start, length);
/*  94 */     final List floatList = new ArrayList();
/*     */     
/*  96 */     matchWhiteSpaceDelimnatedWords(cb, new BuiltInEncodingAlgorithm.WordListener()
/*     */         {
/*     */           public void word(int start, int end) {
/*  99 */             String fStringValue = cb.subSequence(start, end).toString();
/* 100 */             floatList.add(Float.valueOf(fStringValue));
/*     */           }
/*     */           private final CharBuffer val$cb; private final List val$floatList;
/*     */           private final FloatEncodingAlgorithm this$0;
/*     */         });
/* 105 */     return generateArrayFromList(floatList);
/*     */   }
/*     */   
/*     */   public final void convertToCharacters(Object data, StringBuffer s) {
/* 109 */     if (!(data instanceof float[])) {
/* 110 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotFloat"));
/*     */     }
/*     */     
/* 113 */     float[] fdata = (float[])data;
/*     */     
/* 115 */     convertToCharactersFromFloatArray(fdata, s);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void decodeFromBytesToFloatArray(float[] data, int fstart, byte[] b, int start, int length) {
/* 120 */     int size = length / 4;
/* 121 */     for (int i = 0; i < size; i++) {
/* 122 */       int bits = (b[start++] & 0xFF) << 24 | (b[start++] & 0xFF) << 16 | (b[start++] & 0xFF) << 8 | b[start++] & 0xFF;
/*     */ 
/*     */ 
/*     */       
/* 126 */       data[fstart++] = Float.intBitsToFloat(bits);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final float[] decodeFromInputStreamToFloatArray(InputStream s) throws IOException {
/* 131 */     List floatList = new ArrayList();
/* 132 */     byte[] b = new byte[4];
/*     */     
/*     */     while (true) {
/* 135 */       int n = s.read(b);
/* 136 */       if (n != 4) {
/* 137 */         if (n == -1) {
/*     */           break;
/*     */         }
/*     */         
/* 141 */         while (n != 4) {
/* 142 */           int m = s.read(b, n, 4 - n);
/* 143 */           if (m == -1) {
/* 144 */             throw new EOFException();
/*     */           }
/* 146 */           n += m;
/*     */         } 
/*     */       } 
/*     */       
/* 150 */       int bits = (b[0] & 0xFF) << 24 | (b[1] & 0xFF) << 16 | (b[2] & 0xFF) << 8 | b[3] & 0xFF;
/*     */ 
/*     */ 
/*     */       
/* 154 */       floatList.add(new Float(Float.intBitsToFloat(bits)));
/*     */     } 
/*     */     
/* 157 */     return generateArrayFromList(floatList);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void encodeToOutputStreamFromFloatArray(float[] fdata, OutputStream s) throws IOException {
/* 162 */     for (int i = 0; i < fdata.length; i++) {
/* 163 */       int bits = Float.floatToIntBits(fdata[i]);
/* 164 */       s.write(bits >>> 24 & 0xFF);
/* 165 */       s.write(bits >>> 16 & 0xFF);
/* 166 */       s.write(bits >>> 8 & 0xFF);
/* 167 */       s.write(bits & 0xFF);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void encodeToBytes(Object array, int astart, int alength, byte[] b, int start) {
/* 172 */     encodeToBytesFromFloatArray((float[])array, astart, alength, b, start);
/*     */   }
/*     */   
/*     */   public final void encodeToBytesFromFloatArray(float[] fdata, int fstart, int flength, byte[] b, int start) {
/* 176 */     int fend = fstart + flength;
/* 177 */     for (int i = fstart; i < fend; i++) {
/* 178 */       int bits = Float.floatToIntBits(fdata[i]);
/* 179 */       b[start++] = (byte)(bits >>> 24 & 0xFF);
/* 180 */       b[start++] = (byte)(bits >>> 16 & 0xFF);
/* 181 */       b[start++] = (byte)(bits >>> 8 & 0xFF);
/* 182 */       b[start++] = (byte)(bits & 0xFF);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void convertToCharactersFromFloatArray(float[] fdata, StringBuffer s) {
/* 188 */     int end = fdata.length - 1;
/* 189 */     for (int i = 0; i <= end; i++) {
/* 190 */       s.append(Float.toString(fdata[i]));
/* 191 */       if (i != end) {
/* 192 */         s.append(' ');
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final float[] generateArrayFromList(List array) {
/* 199 */     float[] fdata = new float[array.size()];
/* 200 */     for (int i = 0; i < fdata.length; i++) {
/* 201 */       fdata[i] = ((Float)array.get(i)).floatValue();
/*     */     }
/*     */     
/* 204 */     return fdata;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\FloatEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */