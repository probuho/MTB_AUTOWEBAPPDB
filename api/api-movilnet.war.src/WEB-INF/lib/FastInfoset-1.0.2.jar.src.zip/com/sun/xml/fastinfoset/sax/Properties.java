package com.sun.xml.fastinfoset.sax;

public class Properties {
  public static final String LEXICAL_HANDLER_PROPERTY = "http://xml.org/sax/properties/lexical-handler";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sax\Properties.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */