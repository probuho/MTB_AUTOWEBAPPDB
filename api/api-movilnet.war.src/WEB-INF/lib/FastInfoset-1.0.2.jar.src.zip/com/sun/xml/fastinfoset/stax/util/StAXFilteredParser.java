/*    */ package com.sun.xml.fastinfoset.stax.util;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*    */ import javax.xml.stream.StreamFilter;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StAXFilteredParser
/*    */   extends StAXParserWrapper
/*    */ {
/*    */   private StreamFilter _filter;
/*    */   
/*    */   public StAXFilteredParser() {}
/*    */   
/*    */   public StAXFilteredParser(XMLStreamReader reader, StreamFilter filter) {
/* 54 */     super(reader);
/* 55 */     this._filter = filter;
/*    */   }
/*    */   
/*    */   public void setFilter(StreamFilter filter) {
/* 59 */     this._filter = filter;
/*    */   }
/*    */ 
/*    */   
/*    */   public int next() throws XMLStreamException {
/* 64 */     if (hasNext())
/* 65 */       return super.next(); 
/* 66 */     throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.noMoreItems"));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() throws XMLStreamException {
/* 71 */     while (super.hasNext()) {
/* 72 */       if (this._filter.accept(getReader())) return true; 
/* 73 */       super.next();
/*    */     } 
/* 75 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sta\\util\StAXFilteredParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */