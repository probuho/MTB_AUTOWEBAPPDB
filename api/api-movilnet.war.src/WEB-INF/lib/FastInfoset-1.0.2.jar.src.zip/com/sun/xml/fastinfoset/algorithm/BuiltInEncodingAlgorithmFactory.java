/*    */ package com.sun.xml.fastinfoset.algorithm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BuiltInEncodingAlgorithmFactory
/*    */ {
/* 47 */   public static final BuiltInEncodingAlgorithm[] table = new BuiltInEncodingAlgorithm[10];
/*    */ 
/*    */   
/* 50 */   public static final HexadecimalEncodingAlgorithm hexadecimalEncodingAlgorithm = new HexadecimalEncodingAlgorithm();
/*    */   
/* 52 */   public static final BASE64EncodingAlgorithm base64EncodingAlgorithm = new BASE64EncodingAlgorithm();
/*    */   
/* 54 */   public static final BooleanEncodingAlgorithm booleanEncodingAlgorithm = new BooleanEncodingAlgorithm();
/*    */   
/* 56 */   public static final ShortEncodingAlgorithm shortEncodingAlgorithm = new ShortEncodingAlgorithm();
/*    */   
/* 58 */   public static final IntEncodingAlgorithm intEncodingAlgorithm = new IntEncodingAlgorithm();
/*    */   
/* 60 */   public static final LongEncodingAlgorithm longEncodingAlgorithm = new LongEncodingAlgorithm();
/*    */   
/* 62 */   public static final FloatEncodingAlgorithm floatEncodingAlgorithm = new FloatEncodingAlgorithm();
/*    */   
/* 64 */   public static final DoubleEncodingAlgorithm doubleEncodingAlgorithm = new DoubleEncodingAlgorithm();
/*    */   
/* 66 */   public static final UUIDEncodingAlgorithm uuidEncodingAlgorithm = new UUIDEncodingAlgorithm();
/*    */   
/*    */   static {
/* 69 */     table[0] = hexadecimalEncodingAlgorithm;
/* 70 */     table[1] = base64EncodingAlgorithm;
/* 71 */     table[2] = shortEncodingAlgorithm;
/* 72 */     table[3] = intEncodingAlgorithm;
/* 73 */     table[4] = longEncodingAlgorithm;
/* 74 */     table[5] = booleanEncodingAlgorithm;
/* 75 */     table[6] = floatEncodingAlgorithm;
/* 76 */     table[7] = doubleEncodingAlgorithm;
/* 77 */     table[8] = uuidEncodingAlgorithm;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\BuiltInEncodingAlgorithmFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */