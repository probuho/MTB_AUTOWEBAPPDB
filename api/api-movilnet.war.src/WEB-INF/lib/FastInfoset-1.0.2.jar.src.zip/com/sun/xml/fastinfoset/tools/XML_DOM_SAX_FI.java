/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import javax.xml.transform.Result;
/*    */ import javax.xml.transform.Transformer;
/*    */ import javax.xml.transform.TransformerFactory;
/*    */ import javax.xml.transform.dom.DOMSource;
/*    */ import org.jvnet.fastinfoset.FastInfosetResult;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XML_DOM_SAX_FI
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream document, OutputStream finf) throws Exception {
/* 60 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 61 */     dbf.setNamespaceAware(true);
/* 62 */     DocumentBuilder db = dbf.newDocumentBuilder();
/* 63 */     Document d = db.parse(document);
/*    */     
/* 65 */     TransformerFactory tf = TransformerFactory.newInstance();
/* 66 */     Transformer t = tf.newTransformer();
/* 67 */     t.transform(new DOMSource(d), (Result)new FastInfosetResult(finf));
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 71 */     XML_DOM_SAX_FI p = new XML_DOM_SAX_FI();
/* 72 */     p.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\XML_DOM_SAX_FI.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */