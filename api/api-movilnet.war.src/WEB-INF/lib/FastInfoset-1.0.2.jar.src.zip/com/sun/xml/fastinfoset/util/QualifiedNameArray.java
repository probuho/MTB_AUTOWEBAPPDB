/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifiedNameArray
/*     */   extends ValueArray
/*     */ {
/*     */   public QualifiedName[] _array;
/*     */   private QualifiedNameArray _readOnlyArray;
/*     */   
/*     */   public QualifiedNameArray(int initialCapacity, int maximumCapacity) {
/*  52 */     this._array = new QualifiedName[initialCapacity];
/*  53 */     this._maximumCapacity = maximumCapacity;
/*     */   }
/*     */   
/*     */   public QualifiedNameArray() {
/*  57 */     this(10, 2147483647);
/*     */   }
/*     */   
/*     */   public final void clear() {
/*  61 */     for (int i = this._readOnlyArraySize; i < this._size; i++) {
/*  62 */       this._array[i] = null;
/*     */     }
/*  64 */     this._size = this._readOnlyArraySize;
/*     */   }
/*     */   
/*     */   public final QualifiedName[] getArray() {
/*  68 */     return this._array;
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(ValueArray readOnlyArray, boolean clear) {
/*  72 */     if (!(readOnlyArray instanceof QualifiedNameArray)) {
/*  73 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyArray }));
/*     */     }
/*     */ 
/*     */     
/*  77 */     setReadOnlyArray((QualifiedNameArray)readOnlyArray, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(QualifiedNameArray readOnlyArray, boolean clear) {
/*  81 */     if (readOnlyArray != null) {
/*  82 */       this._readOnlyArray = readOnlyArray;
/*  83 */       this._readOnlyArraySize = readOnlyArray.getSize();
/*     */       
/*  85 */       if (clear) {
/*  86 */         clear();
/*     */       }
/*     */       
/*  89 */       this._array = getCompleteArray();
/*  90 */       this._size = this._readOnlyArraySize;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final QualifiedName[] getCompleteArray() {
/*  95 */     if (this._readOnlyArray == null) {
/*  96 */       return this._array;
/*     */     }
/*  98 */     QualifiedName[] ra = this._readOnlyArray.getCompleteArray();
/*  99 */     QualifiedName[] a = new QualifiedName[this._readOnlyArraySize + this._array.length];
/* 100 */     System.arraycopy(ra, 0, a, 0, this._readOnlyArraySize);
/* 101 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public final QualifiedName get(int i) {
/* 106 */     return this._array[i];
/*     */   }
/*     */   
/*     */   public final void add(QualifiedName s) {
/* 110 */     if (this._size == this._array.length) {
/* 111 */       resize();
/*     */     }
/*     */     
/* 114 */     this._array[this._size++] = s;
/*     */   }
/*     */   
/*     */   protected final void resize() {
/* 118 */     if (this._size == this._maximumCapacity) {
/* 119 */       throw new ValueArrayResourceException(CommonResourceBundle.getInstance().getString("message.arrayMaxCapacity"));
/*     */     }
/*     */     
/* 122 */     int newSize = this._size * 3 / 2 + 1;
/* 123 */     if (newSize > this._maximumCapacity) {
/* 124 */       newSize = this._maximumCapacity;
/*     */     }
/*     */     
/* 127 */     QualifiedName[] newArray = new QualifiedName[newSize];
/* 128 */     System.arraycopy(this._array, 0, newArray, 0, this._size);
/* 129 */     this._array = newArray;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\QualifiedNameArray.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */