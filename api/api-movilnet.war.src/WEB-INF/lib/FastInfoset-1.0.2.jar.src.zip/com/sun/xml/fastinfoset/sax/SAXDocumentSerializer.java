/*     */ package com.sun.xml.fastinfoset.sax;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.Encoder;
/*     */ import com.sun.xml.fastinfoset.EncodingConstants;
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ import com.sun.xml.fastinfoset.util.LocalNameQualifiedNamesMap;
/*     */ import java.io.IOException;
/*     */ import org.jvnet.fastinfoset.FastInfosetException;
/*     */ import org.jvnet.fastinfoset.sax.EncodingAlgorithmAttributes;
/*     */ import org.jvnet.fastinfoset.sax.FastInfosetWriter;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAXDocumentSerializer
/*     */   extends Encoder
/*     */   implements FastInfosetWriter
/*     */ {
/*     */   protected boolean _elementHasNamespaces = false;
/*     */   protected boolean _charactersAsCDATA = false;
/*     */   
/*     */   public void reset() {
/*  67 */     super.reset();
/*     */     
/*  69 */     this._elementHasNamespaces = false;
/*  70 */     this._charactersAsCDATA = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void startDocument() throws SAXException {
/*     */     try {
/*  77 */       reset();
/*  78 */       encodeHeader(false);
/*  79 */       encodeInitialVocabulary();
/*  80 */     } catch (IOException e) {
/*  81 */       throw new SAXException("startDocument", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void endDocument() throws SAXException {
/*     */     try {
/*  87 */       encodeDocumentTermination();
/*  88 */     } catch (IOException e) {
/*  89 */       throw new SAXException("endDocument", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void startPrefixMapping(String prefix, String uri) throws SAXException {
/*     */     try {
/*  95 */       if (!this._elementHasNamespaces) {
/*  96 */         encodeTermination();
/*     */ 
/*     */         
/*  99 */         mark();
/* 100 */         this._elementHasNamespaces = true;
/*     */ 
/*     */         
/* 103 */         write(56);
/*     */       } 
/*     */       
/* 106 */       encodeNamespaceAttribute(prefix, uri);
/* 107 */     } catch (IOException e) {
/* 108 */       throw new SAXException("startElement", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
/* 114 */     int attributeCount = (atts.getLength() > 0) ? countAttributes(atts) : 0;
/*     */     try {
/* 116 */       if (this._elementHasNamespaces) {
/* 117 */         this._elementHasNamespaces = false;
/*     */         
/* 119 */         if (attributeCount > 0)
/*     */         {
/* 121 */           this._octetBuffer[this._markIndex] = (byte)(this._octetBuffer[this._markIndex] | 0x40);
/*     */         }
/* 123 */         resetMark();
/*     */         
/* 125 */         write(240);
/*     */         
/* 127 */         this._b = 0;
/*     */       } else {
/* 129 */         encodeTermination();
/*     */         
/* 131 */         this._b = 0;
/* 132 */         if (attributeCount > 0) {
/* 133 */           this._b |= 0x40;
/*     */         }
/*     */       } 
/*     */       
/* 137 */       encodeElement(namespaceURI, qName, localName);
/*     */       
/* 139 */       if (attributeCount > 0) {
/*     */ 
/*     */         
/* 142 */         if (atts instanceof EncodingAlgorithmAttributes) {
/* 143 */           EncodingAlgorithmAttributes eAtts = (EncodingAlgorithmAttributes)atts;
/* 144 */           for (int i = 0; i < eAtts.getLength(); i++) {
/* 145 */             if (encodeAttribute(atts.getURI(i), atts.getQName(i), atts.getLocalName(i))) {
/* 146 */               String value = eAtts.getValue(i);
/* 147 */               if (value != null) {
/* 148 */                 boolean addToTable = (value.length() < this.attributeValueSizeConstraint);
/* 149 */                 encodeNonIdentifyingStringOnFirstBit(value, this._v.attributeValue, addToTable);
/*     */               } else {
/* 151 */                 encodeNonIdentifyingStringOnFirstBit(eAtts.getAlgorithmURI(i), eAtts.getAlgorithmIndex(i), eAtts.getAlgorithmData(i));
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 157 */           for (int i = 0; i < atts.getLength(); i++) {
/* 158 */             if (encodeAttribute(atts.getURI(i), atts.getQName(i), atts.getLocalName(i))) {
/* 159 */               String value = atts.getValue(i);
/* 160 */               boolean addToTable = (value.length() < this.attributeValueSizeConstraint);
/* 161 */               encodeNonIdentifyingStringOnFirstBit(value, this._v.attributeValue, addToTable);
/*     */             } 
/*     */           } 
/*     */         } 
/* 165 */         this._b = 240;
/* 166 */         this._terminate = true;
/*     */       } 
/* 168 */     } catch (IOException e) {
/* 169 */       throw new SAXException("startElement", e);
/* 170 */     } catch (FastInfosetException e) {
/* 171 */       throw new SAXException("startElement", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int countAttributes(Attributes atts) {
/* 178 */     int count = 0;
/* 179 */     for (int i = 0; i < atts.getLength(); i++) {
/* 180 */       String uri = atts.getURI(i);
/* 181 */       if (uri != "http://www.w3.org/2000/xmlns/" && !uri.equals("http://www.w3.org/2000/xmlns/"))
/*     */       {
/*     */         
/* 184 */         count++; } 
/*     */     } 
/* 186 */     return count;
/*     */   }
/*     */   
/*     */   public final void endElement(String namespaceURI, String localName, String qName) throws SAXException {
/*     */     try {
/* 191 */       encodeElementTermination();
/* 192 */     } catch (IOException e) {
/* 193 */       throw new SAXException("startElement", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void characters(char[] ch, int start, int length) throws SAXException {
/* 198 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 203 */       encodeTermination();
/*     */       
/* 205 */       if (!this._charactersAsCDATA) {
/* 206 */         encodeCharacters(ch, start, length);
/*     */       } else {
/* 208 */         encodeCIIBuiltInAlgorithmDataAsCDATA(ch, start, length);
/*     */       } 
/* 210 */     } catch (IOException e) {
/* 211 */       throw new SAXException(e);
/* 212 */     } catch (FastInfosetException e) {
/* 213 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 218 */     characters(ch, start, length);
/*     */   }
/*     */   
/*     */   public final void processingInstruction(String target, String data) throws SAXException {
/*     */     try {
/* 223 */       if (target == "") {
/* 224 */         throw new SAXException(CommonResourceBundle.getInstance().getString("message.processingInstructionTargetIsEmpty"));
/*     */       }
/* 226 */       encodeTermination();
/*     */       
/* 228 */       encodeProcessingInstruction(target, data);
/* 229 */     } catch (IOException e) {
/* 230 */       throw new SAXException("processingInstruction", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDocumentLocator(Locator locator) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public final void skippedEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public final void comment(char[] ch, int start, int length) throws SAXException {
/*     */     try {
/* 246 */       encodeTermination();
/*     */       
/* 248 */       encodeComment(ch, start, length);
/* 249 */     } catch (IOException e) {
/* 250 */       throw new SAXException("startElement", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void startCDATA() throws SAXException {
/* 255 */     this._charactersAsCDATA = true;
/*     */   }
/*     */   
/*     */   public final void endCDATA() throws SAXException {
/* 259 */     this._charactersAsCDATA = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void startDTD(String name, String publicId, String systemId) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public final void endDTD() throws SAXException {}
/*     */ 
/*     */   
/*     */   public final void startEntity(String name) throws SAXException {}
/*     */ 
/*     */   
/*     */   public final void endEntity(String name) throws SAXException {}
/*     */ 
/*     */   
/*     */   public final void octets(String URI, int id, byte[] b, int start, int length) throws SAXException {
/* 278 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 283 */       encodeTermination();
/*     */       
/* 285 */       encodeNonIdentifyingStringOnThirdBit(URI, id, b, start, length);
/* 286 */     } catch (IOException e) {
/* 287 */       throw new SAXException(e);
/* 288 */     } catch (FastInfosetException e) {
/* 289 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void object(String URI, int id, Object data) throws SAXException {
/*     */     try {
/* 295 */       encodeTermination();
/*     */       
/* 297 */       encodeNonIdentifyingStringOnThirdBit(URI, id, data);
/* 298 */     } catch (IOException e) {
/* 299 */       throw new SAXException(e);
/* 300 */     } catch (FastInfosetException e) {
/* 301 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void bytes(byte[] b, int start, int length) throws SAXException {
/* 309 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 314 */       encodeTermination();
/*     */       
/* 316 */       encodeCIIOctetAlgorithmData(1, b, start, length);
/* 317 */     } catch (IOException e) {
/* 318 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void shorts(short[] s, int start, int length) throws SAXException {
/* 323 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 328 */       encodeTermination();
/*     */       
/* 330 */       encodeCIIBuiltInAlgorithmData(2, s, start, length);
/* 331 */     } catch (IOException e) {
/* 332 */       throw new SAXException(e);
/* 333 */     } catch (FastInfosetException e) {
/* 334 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void ints(int[] i, int start, int length) throws SAXException {
/* 339 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 344 */       encodeTermination();
/*     */       
/* 346 */       encodeCIIBuiltInAlgorithmData(3, i, start, length);
/* 347 */     } catch (IOException e) {
/* 348 */       throw new SAXException(e);
/* 349 */     } catch (FastInfosetException e) {
/* 350 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void longs(long[] l, int start, int length) throws SAXException {
/* 355 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 360 */       encodeTermination();
/*     */       
/* 362 */       encodeCIIBuiltInAlgorithmData(4, l, start, length);
/* 363 */     } catch (IOException e) {
/* 364 */       throw new SAXException(e);
/* 365 */     } catch (FastInfosetException e) {
/* 366 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void booleans(boolean[] b, int start, int length) throws SAXException {
/* 371 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 376 */       encodeTermination();
/*     */       
/* 378 */       encodeCIIBuiltInAlgorithmData(5, b, start, length);
/* 379 */     } catch (IOException e) {
/* 380 */       throw new SAXException(e);
/* 381 */     } catch (FastInfosetException e) {
/* 382 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void floats(float[] f, int start, int length) throws SAXException {
/* 387 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 392 */       encodeTermination();
/*     */       
/* 394 */       encodeCIIBuiltInAlgorithmData(6, f, start, length);
/* 395 */     } catch (IOException e) {
/* 396 */       throw new SAXException(e);
/* 397 */     } catch (FastInfosetException e) {
/* 398 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void doubles(double[] d, int start, int length) throws SAXException {
/* 403 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 408 */       encodeTermination();
/*     */       
/* 410 */       encodeCIIBuiltInAlgorithmData(7, d, start, length);
/* 411 */     } catch (IOException e) {
/* 412 */       throw new SAXException(e);
/* 413 */     } catch (FastInfosetException e) {
/* 414 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void uuids(long[] msblsb, int start, int length) throws SAXException {
/* 419 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 424 */       encodeTermination();
/*     */       
/* 426 */       encodeCIIBuiltInAlgorithmData(8, msblsb, start, length);
/* 427 */     } catch (IOException e) {
/* 428 */       throw new SAXException(e);
/* 429 */     } catch (FastInfosetException e) {
/* 430 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numericCharacters(char[] ch, int start, int length) throws SAXException {
/* 438 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 443 */       encodeTermination();
/*     */       
/* 445 */       encodeFourBitCharacters(0, EncodingConstants.NUMERIC_CHARACTERS_TABLE, ch, start, length);
/* 446 */     } catch (IOException e) {
/* 447 */       throw new SAXException(e);
/* 448 */     } catch (FastInfosetException e) {
/* 449 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dateTimeCharacters(char[] ch, int start, int length) throws SAXException {
/* 454 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 459 */       encodeTermination();
/*     */       
/* 461 */       encodeFourBitCharacters(1, EncodingConstants.DATE_TIME_CHARACTERS_TABLE, ch, start, length);
/* 462 */     } catch (IOException e) {
/* 463 */       throw new SAXException(e);
/* 464 */     } catch (FastInfosetException e) {
/* 465 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void alphabetCharacters(String alphabet, char[] ch, int start, int length) throws SAXException {
/* 470 */     if (length <= 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 475 */       encodeTermination();
/*     */       
/* 477 */       encodeAlphabetCharacters(alphabet, ch, start, length);
/* 478 */     } catch (IOException e) {
/* 479 */       throw new SAXException(e);
/* 480 */     } catch (FastInfosetException e) {
/* 481 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void encodeElement(String namespaceURI, String qName, String localName) throws IOException {
/* 488 */     LocalNameQualifiedNamesMap.Entry entry = this._v.elementName.obtainEntry(qName);
/* 489 */     if (entry._valueIndex > 0) {
/* 490 */       QualifiedName[] names = entry._value;
/* 491 */       for (int i = 0; i < entry._valueIndex; i++) {
/* 492 */         if (namespaceURI == (names[i]).namespaceName || namespaceURI.equals((names[i]).namespaceName)) {
/* 493 */           encodeNonZeroIntegerOnThirdBit((names[i]).index);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 499 */     encodeLiteralElementQualifiedNameOnThirdBit(namespaceURI, getPrefixFromQualifiedName(qName), localName, entry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final boolean encodeAttribute(String namespaceURI, String qName, String localName) throws IOException {
/* 504 */     LocalNameQualifiedNamesMap.Entry entry = this._v.attributeName.obtainEntry(qName);
/* 505 */     if (entry._valueIndex > 0) {
/* 506 */       QualifiedName[] names = entry._value;
/* 507 */       for (int i = 0; i < entry._valueIndex; i++) {
/* 508 */         if (namespaceURI == (names[i]).namespaceName || namespaceURI.equals((names[i]).namespaceName)) {
/* 509 */           encodeNonZeroIntegerOnSecondBitFirstBitZero((names[i]).index);
/* 510 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 515 */     return encodeLiteralAttributeQualifiedNameOnSecondBit(namespaceURI, getPrefixFromQualifiedName(qName), localName, entry);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sax\SAXDocumentSerializer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */