/*     */ package com.sun.xml.fastinfoset.sax;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemIdResolver
/*     */ {
/*     */   public static String getAbsoluteURIFromRelative(String localPath) {
/*     */     String urlString;
/*  50 */     if (localPath == null || localPath.length() == 0) {
/*  51 */       return "";
/*     */     }
/*     */     
/*  54 */     String absolutePath = localPath;
/*  55 */     if (!isAbsolutePath(localPath)) {
/*     */       try {
/*  57 */         absolutePath = getAbsolutePathFromRelativePath(localPath);
/*     */       }
/*  59 */       catch (SecurityException se) {
/*  60 */         return "file:" + localPath;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  65 */     if (null != absolutePath) {
/*  66 */       urlString = absolutePath.startsWith(File.separator) ? ("file://" + absolutePath) : ("file:///" + absolutePath);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  71 */       urlString = "file:" + localPath;
/*     */     } 
/*     */     
/*  74 */     return replaceChars(urlString);
/*     */   }
/*     */   
/*     */   private static String getAbsolutePathFromRelativePath(String relativePath) {
/*  78 */     return (new File(relativePath)).getAbsolutePath();
/*     */   }
/*     */   
/*     */   public static boolean isAbsoluteURI(String systemId) {
/*  82 */     if (systemId == null) {
/*  83 */       return false;
/*     */     }
/*     */     
/*  86 */     if (isWindowsAbsolutePath(systemId)) {
/*  87 */       return false;
/*     */     }
/*     */     
/*  90 */     int fragmentIndex = systemId.indexOf('#');
/*  91 */     int queryIndex = systemId.indexOf('?');
/*  92 */     int slashIndex = systemId.indexOf('/');
/*  93 */     int colonIndex = systemId.indexOf(':');
/*     */     
/*  95 */     int index = systemId.length() - 1;
/*  96 */     if (fragmentIndex > 0) {
/*  97 */       index = fragmentIndex;
/*     */     }
/*  99 */     if (queryIndex > 0 && queryIndex < index) {
/* 100 */       index = queryIndex;
/*     */     }
/* 102 */     if (slashIndex > 0 && slashIndex < index) {
/* 103 */       index = slashIndex;
/*     */     }
/* 105 */     return (colonIndex > 0 && colonIndex < index);
/*     */   }
/*     */   
/*     */   public static boolean isAbsolutePath(String systemId) {
/* 109 */     if (systemId == null)
/* 110 */       return false; 
/* 111 */     File file = new File(systemId);
/* 112 */     return file.isAbsolute();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isWindowsAbsolutePath(String systemId) {
/* 117 */     if (!isAbsolutePath(systemId))
/* 118 */       return false; 
/* 119 */     if (systemId.length() > 2 && systemId.charAt(1) == ':' && Character.isLetter(systemId.charAt(0)) && (systemId.charAt(2) == '\\' || systemId.charAt(2) == '/'))
/*     */     {
/*     */ 
/*     */       
/* 123 */       return true;
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   private static String replaceChars(String str) {
/* 129 */     StringBuffer buf = new StringBuffer(str);
/* 130 */     int length = buf.length();
/* 131 */     for (int i = 0; i < length; i++) {
/* 132 */       char currentChar = buf.charAt(i);
/*     */       
/* 134 */       if (currentChar == ' ') {
/* 135 */         buf.setCharAt(i, '%');
/* 136 */         buf.insert(i + 1, "20");
/* 137 */         length += 2;
/* 138 */         i += 2;
/*     */       
/*     */       }
/* 141 */       else if (currentChar == '\\') {
/* 142 */         buf.setCharAt(i, '/');
/*     */       } 
/*     */     } 
/*     */     
/* 146 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static String getAbsoluteURI(String systemId) {
/* 150 */     String absoluteURI = systemId;
/* 151 */     if (isAbsoluteURI(systemId)) {
/* 152 */       if (systemId.startsWith("file:")) {
/* 153 */         String str = systemId.substring(5);
/*     */         
/* 155 */         if (str != null && str.startsWith("/")) {
/* 156 */           if (str.startsWith("///") || !str.startsWith("//")) {
/* 157 */             int secondColonIndex = systemId.indexOf(':', 5);
/* 158 */             if (secondColonIndex > 0) {
/* 159 */               String localPath = systemId.substring(secondColonIndex - 1);
/*     */               try {
/* 161 */                 if (!isAbsolutePath(localPath)) {
/* 162 */                   absoluteURI = systemId.substring(0, secondColonIndex - 1) + getAbsolutePathFromRelativePath(localPath);
/*     */                 }
/*     */               }
/* 165 */               catch (SecurityException se) {
/* 166 */                 return systemId;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 172 */           return getAbsoluteURIFromRelative(systemId.substring(5));
/*     */         } 
/*     */         
/* 175 */         return replaceChars(absoluteURI);
/*     */       } 
/*     */       
/* 178 */       return systemId;
/*     */     } 
/*     */ 
/*     */     
/* 182 */     return getAbsoluteURIFromRelative(systemId);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sax\SystemIdResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */