/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharArrayArray
/*     */   extends ValueArray
/*     */ {
/*     */   private CharArray[] _array;
/*     */   private CharArrayArray _readOnlyArray;
/*     */   
/*     */   public CharArrayArray(int initialCapacity, int maximumCapacity) {
/*  51 */     this._array = new CharArray[initialCapacity];
/*  52 */     this._maximumCapacity = maximumCapacity;
/*     */   }
/*     */   
/*     */   public CharArrayArray() {
/*  56 */     this(10, 2147483647);
/*     */   }
/*     */   
/*     */   public final void clear() {
/*  60 */     for (int i = 0; i < this._size; i++) {
/*  61 */       this._array[i] = null;
/*     */     }
/*  63 */     this._size = 0;
/*     */   }
/*     */   
/*     */   public final CharArray[] getArray() {
/*  67 */     return this._array;
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(ValueArray readOnlyArray, boolean clear) {
/*  71 */     if (!(readOnlyArray instanceof CharArrayArray)) {
/*  72 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyArray }));
/*     */     }
/*     */     
/*  75 */     setReadOnlyArray((CharArrayArray)readOnlyArray, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyArray(CharArrayArray readOnlyArray, boolean clear) {
/*  79 */     if (readOnlyArray != null) {
/*  80 */       this._readOnlyArray = readOnlyArray;
/*  81 */       this._readOnlyArraySize = readOnlyArray.getSize();
/*     */       
/*  83 */       if (clear) {
/*  84 */         clear();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public final CharArray get(int i) {
/*  90 */     if (this._readOnlyArray == null) {
/*  91 */       return this._array[i];
/*     */     }
/*  93 */     if (i < this._readOnlyArraySize) {
/*  94 */       return this._readOnlyArray.get(i);
/*     */     }
/*  96 */     return this._array[i - this._readOnlyArraySize];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(CharArray s) {
/* 102 */     if (this._size == this._array.length) {
/* 103 */       resize();
/*     */     }
/*     */     
/* 106 */     this._array[this._size++] = s;
/*     */   }
/*     */   
/*     */   protected final void resize() {
/* 110 */     if (this._size == this._maximumCapacity) {
/* 111 */       throw new ValueArrayResourceException(CommonResourceBundle.getInstance().getString("message.arrayMaxCapacity"));
/*     */     }
/*     */     
/* 114 */     int newSize = this._size * 3 / 2 + 1;
/* 115 */     if (newSize > this._maximumCapacity) {
/* 116 */       newSize = this._maximumCapacity;
/*     */     }
/*     */     
/* 119 */     CharArray[] newArray = new CharArray[newSize];
/* 120 */     System.arraycopy(this._array, 0, newArray, 0, this._size);
/* 121 */     this._array = newArray;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\CharArrayArray.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */