/*     */ package com.sun.xml.fastinfoset.dom;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.Decoder;
/*     */ import com.sun.xml.fastinfoset.DecoderStateTables;
/*     */ import com.sun.xml.fastinfoset.EncodingConstants;
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithmFactory;
/*     */ import com.sun.xml.fastinfoset.util.CharArray;
/*     */ import com.sun.xml.fastinfoset.util.CharArrayString;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithm;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ import org.jvnet.fastinfoset.FastInfosetException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMDocumentParser
/*     */   extends Decoder
/*     */ {
/*     */   protected Document _document;
/*     */   protected Node _currentNode;
/*     */   protected Element _currentElement;
/*  69 */   protected Attr[] _namespaceAttributes = new Attr[16];
/*     */   
/*     */   protected int _namespaceAttributesIndex;
/*     */   
/*  73 */   protected int[] _namespacePrefixes = new int[16];
/*     */   
/*     */   protected int _namespacePrefixesIndex;
/*     */   
/*     */   public void parse(Document d, InputStream s) throws FastInfosetException, IOException {
/*  78 */     this._currentNode = this._document = d;
/*  79 */     this._namespaceAttributesIndex = 0;
/*     */     
/*  81 */     parse(s);
/*     */   }
/*     */   
/*     */   protected final void parse(InputStream s) throws FastInfosetException, IOException {
/*  85 */     setInputStream(s);
/*  86 */     parse();
/*     */   }
/*     */   
/*     */   protected void resetOnError() {
/*  90 */     this._namespacePrefixesIndex = 0;
/*     */     
/*  92 */     if (this._v == null) {
/*  93 */       this._prefixTable.clearCompletely();
/*     */     }
/*  95 */     this._duplicateAttributeVerifier.clear();
/*     */   }
/*     */   
/*     */   protected final void parse() throws FastInfosetException, IOException {
/*     */     try {
/* 100 */       reset();
/* 101 */       decodeHeader();
/* 102 */       processDII();
/* 103 */     } catch (RuntimeException e) {
/* 104 */       resetOnError();
/*     */       
/* 106 */       throw new FastInfosetException(e);
/* 107 */     } catch (FastInfosetException e) {
/* 108 */       resetOnError();
/* 109 */       throw e;
/* 110 */     } catch (IOException e) {
/* 111 */       resetOnError();
/* 112 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void processDII() throws FastInfosetException, IOException {
/* 117 */     this._b = read();
/* 118 */     if (this._b > 0) {
/* 119 */       processDIIOptionalProperties();
/*     */     }
/*     */ 
/*     */     
/* 123 */     boolean firstElementHasOccured = false;
/* 124 */     boolean documentTypeDeclarationOccured = false;
/* 125 */     while (!this._terminate || !firstElementHasOccured) {
/* 126 */       QualifiedName qn; String system_identifier, public_identifier; this._b = read();
/* 127 */       switch (DecoderStateTables.DII[this._b]) {
/*     */         case 0:
/* 129 */           processEII(this._elementNameTable._array[this._b], false);
/* 130 */           firstElementHasOccured = true;
/*     */           continue;
/*     */         case 1:
/* 133 */           processEII(this._elementNameTable._array[this._b & 0x1F], true);
/* 134 */           firstElementHasOccured = true;
/*     */           continue;
/*     */         case 2:
/* 137 */           processEII(decodeEIIIndexMedium(), ((this._b & 0x40) > 0));
/* 138 */           firstElementHasOccured = true;
/*     */           continue;
/*     */         case 3:
/* 141 */           processEII(decodeEIIIndexLarge(), ((this._b & 0x40) > 0));
/* 142 */           firstElementHasOccured = true;
/*     */           continue;
/*     */         
/*     */         case 5:
/* 146 */           qn = processLiteralQualifiedName(this._b & 0x3);
/*     */           
/* 148 */           this._elementNameTable.add(qn);
/* 149 */           processEII(qn, ((this._b & 0x40) > 0));
/* 150 */           firstElementHasOccured = true;
/*     */           continue;
/*     */         
/*     */         case 4:
/* 154 */           processEIIWithNamespaces();
/* 155 */           firstElementHasOccured = true;
/*     */           continue;
/*     */         
/*     */         case 20:
/* 159 */           if (documentTypeDeclarationOccured) {
/* 160 */             throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.secondOccurenceOfDTDII"));
/*     */           }
/* 162 */           documentTypeDeclarationOccured = true;
/*     */           
/* 164 */           system_identifier = ((this._b & 0x2) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : null;
/*     */           
/* 166 */           public_identifier = ((this._b & 0x1) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : null;
/*     */ 
/*     */           
/* 169 */           this._b = read();
/* 170 */           while (this._b == 225) {
/* 171 */             String data; switch (decodeNonIdentifyingStringOnFirstBit()) {
/*     */               case 0:
/* 173 */                 data = new String(this._charBuffer, 0, this._charBufferLength);
/* 174 */                 if (this._addToTable) {
/* 175 */                   this._v.otherString.add(new CharArray(this._charBuffer, 0, this._charBufferLength, true));
/*     */                 }
/*     */                 break;
/*     */               case 2:
/* 179 */                 throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.processingIIWithEncodingAlgorithm"));
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 185 */             this._b = read();
/*     */           } 
/* 187 */           if ((this._b & 0xF0) != 240) {
/* 188 */             throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.processingInstructionIIsNotTerminatedCorrectly"));
/*     */           }
/* 190 */           if (this._b == 255) {
/* 191 */             this._terminate = true;
/*     */           }
/*     */           
/* 194 */           this._notations.clear();
/* 195 */           this._unparsedEntities.clear();
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 18:
/* 203 */           processCommentII();
/*     */           continue;
/*     */         case 19:
/* 206 */           processProcessingII();
/*     */           continue;
/*     */         case 23:
/* 209 */           this._doubleTerminate = true;
/*     */         case 22:
/* 211 */           this._terminate = true;
/*     */           continue;
/*     */       } 
/* 214 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingDII"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 219 */     while (!this._terminate) {
/* 220 */       this._b = read();
/* 221 */       switch (DecoderStateTables.DII[this._b]) {
/*     */         case 18:
/* 223 */           processCommentII();
/*     */           continue;
/*     */         case 19:
/* 226 */           processProcessingII();
/*     */           continue;
/*     */         case 23:
/* 229 */           this._doubleTerminate = true;
/*     */         case 22:
/* 231 */           this._terminate = true;
/*     */           continue;
/*     */       } 
/* 234 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingDII"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void processDIIOptionalProperties() throws FastInfosetException, IOException {
/* 242 */     if (this._b == 32) {
/* 243 */       decodeInitialVocabulary();
/*     */       
/*     */       return;
/*     */     } 
/* 247 */     if ((this._b & 0x40) > 0) {
/* 248 */       decodeAdditionalData();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     if ((this._b & 0x20) > 0) {
/* 256 */       decodeInitialVocabulary();
/*     */     }
/*     */     
/* 259 */     if ((this._b & 0x10) > 0) {
/* 260 */       decodeNotations();
/*     */     }
/*     */ 
/*     */     
/* 264 */     if ((this._b & 0x8) > 0) {
/* 265 */       decodeUnparsedEntities();
/*     */     }
/*     */ 
/*     */     
/* 269 */     if ((this._b & 0x4) > 0) {
/* 270 */       String version = decodeCharacterEncodingScheme();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     if ((this._b & 0x2) > 0) {
/* 278 */       boolean standalone = (read() > 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     if ((this._b & 0x1) > 0) {
/* 286 */       String version = decodeVersion();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void processEII(QualifiedName name, boolean hasAttributes) throws FastInfosetException, IOException {
/* 295 */     if (this._prefixTable._currentInScope[name.prefixIndex] != name.namespaceNameIndex) {
/* 296 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.qnameOfEIINotInScope"));
/*     */     }
/*     */     
/* 299 */     Node parentCurrentNode = this._currentNode;
/*     */     
/* 301 */     this._currentNode = this._currentElement = createElement(name.namespaceName, name.qName, name.localName);
/*     */     
/* 303 */     if (this._namespaceAttributesIndex > 0) {
/* 304 */       for (int i = 0; i < this._namespaceAttributesIndex; i++) {
/* 305 */         this._currentElement.setAttributeNode(this._namespaceAttributes[i]);
/* 306 */         this._namespaceAttributes[i] = null;
/*     */       } 
/* 308 */       this._namespaceAttributesIndex = 0;
/*     */     } 
/*     */     
/* 311 */     if (hasAttributes) {
/* 312 */       processAIIs();
/*     */     }
/*     */     
/* 315 */     parentCurrentNode.appendChild(this._currentElement);
/*     */     
/* 317 */     while (!this._terminate) {
/* 318 */       QualifiedName qn; String v; boolean addToTable; String s; CharArray ca; int index; String entity_reference_name, str2, str1, system_identifier, public_identifier; this._b = read();
/* 319 */       switch (DecoderStateTables.EII[this._b]) {
/*     */         case 0:
/* 321 */           processEII(this._elementNameTable._array[this._b], false);
/*     */           continue;
/*     */         case 1:
/* 324 */           processEII(this._elementNameTable._array[this._b & 0x1F], true);
/*     */           continue;
/*     */         case 2:
/* 327 */           processEII(decodeEIIIndexMedium(), ((this._b & 0x40) > 0));
/*     */           continue;
/*     */         case 3:
/* 330 */           processEII(decodeEIIIndexLarge(), ((this._b & 0x40) > 0));
/*     */           continue;
/*     */         
/*     */         case 5:
/* 334 */           qn = processLiteralQualifiedName(this._b & 0x3);
/*     */           
/* 336 */           this._elementNameTable.add(qn);
/* 337 */           processEII(qn, ((this._b & 0x40) > 0));
/*     */           continue;
/*     */         
/*     */         case 4:
/* 341 */           processEIIWithNamespaces();
/*     */           continue;
/*     */         
/*     */         case 6:
/* 345 */           this._octetBufferLength = (this._b & 0x1) + 1;
/*     */           
/* 347 */           v = decodeUtf8StringAsString();
/* 348 */           if ((this._b & 0x10) > 0) {
/* 349 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*     */           }
/*     */           
/* 352 */           this._currentNode.appendChild(this._document.createTextNode(v));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 7:
/* 357 */           this._octetBufferLength = read() + 3;
/* 358 */           v = decodeUtf8StringAsString();
/* 359 */           if ((this._b & 0x10) > 0) {
/* 360 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*     */           }
/*     */           
/* 363 */           this._currentNode.appendChild(this._document.createTextNode(v));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 8:
/* 368 */           this._octetBufferLength = read() << 24 | read() << 16 | read() << 8 | read();
/*     */ 
/*     */ 
/*     */           
/* 372 */           this._octetBufferLength += 259;
/* 373 */           v = decodeUtf8StringAsString();
/* 374 */           if ((this._b & 0x10) > 0) {
/* 375 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*     */           }
/*     */           
/* 378 */           this._currentNode.appendChild(this._document.createTextNode(v));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 9:
/* 383 */           this._octetBufferLength = (this._b & 0x1) + 1;
/*     */           
/* 385 */           v = decodeUtf16StringAsString();
/* 386 */           if ((this._b & 0x10) > 0) {
/* 387 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*     */           }
/*     */           
/* 390 */           this._currentNode.appendChild(this._document.createTextNode(v));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 10:
/* 395 */           this._octetBufferLength = read() + 3;
/* 396 */           v = decodeUtf16StringAsString();
/* 397 */           if ((this._b & 0x10) > 0) {
/* 398 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*     */           }
/*     */           
/* 401 */           this._currentNode.appendChild(this._document.createTextNode(v));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 11:
/* 406 */           this._octetBufferLength = read() << 24 | read() << 16 | read() << 8 | read();
/*     */ 
/*     */ 
/*     */           
/* 410 */           this._octetBufferLength += 259;
/* 411 */           v = decodeUtf16StringAsString();
/* 412 */           if ((this._b & 0x10) > 0) {
/* 413 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*     */           }
/*     */           
/* 416 */           this._currentNode.appendChild(this._document.createTextNode(v));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 12:
/* 421 */           addToTable = ((this._b & 0x10) > 0);
/*     */ 
/*     */           
/* 424 */           this._identifier = (this._b & 0x2) << 6;
/* 425 */           this._b = read();
/* 426 */           this._identifier |= (this._b & 0xFC) >> 2;
/*     */           
/* 428 */           decodeOctetsOnSeventhBitOfNonIdentifyingStringOnThirdBit(this._b);
/*     */           
/* 430 */           str2 = decodeRestrictedAlphabetAsString();
/* 431 */           if (addToTable) {
/* 432 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*     */           }
/*     */           
/* 435 */           this._currentNode.appendChild(this._document.createTextNode(str2));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 13:
/* 440 */           if ((this._b & 0x40) > 0) {
/* 441 */             throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.addToTableNotSupported"));
/*     */           }
/*     */ 
/*     */           
/* 445 */           this._identifier = (this._b & 0x2) << 6;
/* 446 */           this._b = read();
/* 447 */           this._identifier |= (this._b & 0xFC) >> 2;
/*     */           
/* 449 */           decodeOctetsOnSeventhBitOfNonIdentifyingStringOnThirdBit(this._b);
/* 450 */           s = convertEncodingAlgorithmDataToCharacters(false);
/* 451 */           this._currentNode.appendChild(this._document.createTextNode(s));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 14:
/* 456 */           ca = this._characterContentChunkTable.get(this._b & 0xF);
/*     */           
/* 458 */           this._currentNode.appendChild(this._document.createTextNode(ca.toString()));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 15:
/* 463 */           index = ((this._b & 0x3) << 8 | read()) + 16;
/*     */           
/* 465 */           str1 = this._characterContentChunkTable.get(index).toString();
/*     */           
/* 467 */           this._currentNode.appendChild(this._document.createTextNode(str1));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 16:
/* 472 */           index = (this._b & 0x3) << 16 | read() << 8 | read();
/*     */ 
/*     */           
/* 475 */           index += 1040;
/* 476 */           str1 = this._characterContentChunkTable.get(index).toString();
/*     */           
/* 478 */           this._currentNode.appendChild(this._document.createTextNode(str1));
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 17:
/* 483 */           index = read() << 16 | read() << 8 | read();
/*     */ 
/*     */           
/* 486 */           index += 263184;
/* 487 */           str1 = this._characterContentChunkTable.get(index).toString();
/*     */           
/* 489 */           this._currentNode.appendChild(this._document.createTextNode(str1));
/*     */           continue;
/*     */         
/*     */         case 18:
/* 493 */           processCommentII();
/*     */           continue;
/*     */         case 19:
/* 496 */           processProcessingII();
/*     */           continue;
/*     */         
/*     */         case 21:
/* 500 */           entity_reference_name = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*     */           
/* 502 */           system_identifier = ((this._b & 0x2) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : null;
/*     */           
/* 504 */           public_identifier = ((this._b & 0x1) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : null;
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 23:
/* 511 */           this._doubleTerminate = true;
/*     */         case 22:
/* 513 */           this._terminate = true;
/*     */           continue;
/*     */       } 
/* 516 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingEII"));
/*     */     } 
/*     */ 
/*     */     
/* 520 */     this._terminate = this._doubleTerminate;
/* 521 */     this._doubleTerminate = false;
/*     */     
/* 523 */     this._currentNode = parentCurrentNode;
/*     */   }
/*     */   protected final void processEIIWithNamespaces() throws FastInfosetException, IOException {
/*     */     QualifiedName qn;
/* 527 */     boolean hasAttributes = ((this._b & 0x40) > 0);
/*     */     
/* 529 */     if (++this._prefixTable._declarationId == Integer.MAX_VALUE) {
/* 530 */       this._prefixTable.clearDeclarationIds();
/*     */     }
/*     */ 
/*     */     
/* 534 */     Attr a = null;
/* 535 */     int start = this._namespacePrefixesIndex;
/* 536 */     int b = read();
/* 537 */     while ((b & 0xFC) == 204) {
/* 538 */       String prefix; if (this._namespaceAttributesIndex == this._namespaceAttributes.length) {
/* 539 */         Attr[] newNamespaceAttributes = new Attr[this._namespaceAttributesIndex * 3 / 2 + 1];
/* 540 */         System.arraycopy(this._namespaceAttributes, 0, newNamespaceAttributes, 0, this._namespaceAttributesIndex);
/* 541 */         this._namespaceAttributes = newNamespaceAttributes;
/*     */       } 
/*     */       
/* 544 */       if (this._namespacePrefixesIndex == this._namespacePrefixes.length) {
/* 545 */         int[] namespaceAIIs = new int[this._namespacePrefixesIndex * 3 / 2 + 1];
/* 546 */         System.arraycopy(this._namespacePrefixes, 0, namespaceAIIs, 0, this._namespacePrefixesIndex);
/* 547 */         this._namespacePrefixes = namespaceAIIs;
/*     */       } 
/*     */ 
/*     */       
/* 551 */       switch (b & 0x3) {
/*     */ 
/*     */         
/*     */         case 0:
/* 555 */           a = createAttribute("http://www.w3.org/2000/xmlns/", "xmlns", "xmlns");
/*     */ 
/*     */ 
/*     */           
/* 559 */           a.setValue("");
/*     */           
/* 561 */           this._namespacePrefixes[this._namespacePrefixesIndex++] = -1; this._prefixIndex = this._namespaceNameIndex = -1;
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/* 566 */           a = createAttribute("http://www.w3.org/2000/xmlns/", "xmlns", "xmlns");
/*     */ 
/*     */ 
/*     */           
/* 570 */           a.setValue(decodeIdentifyingNonEmptyStringOnFirstBitAsNamespaceName(false));
/*     */           
/* 572 */           this._prefixIndex = this._namespacePrefixes[this._namespacePrefixesIndex++] = -1;
/*     */           break;
/*     */ 
/*     */         
/*     */         case 2:
/* 577 */           prefix = decodeIdentifyingNonEmptyStringOnFirstBitAsPrefix(false);
/* 578 */           a = createAttribute("http://www.w3.org/2000/xmlns/", createQualifiedNameString(EncodingConstants.XMLNS_NAMESPACE_PREFIX_CHARS, prefix), prefix);
/*     */ 
/*     */ 
/*     */           
/* 582 */           a.setValue("");
/*     */           
/* 584 */           this._namespaceNameIndex = -1;
/* 585 */           this._namespacePrefixes[this._namespacePrefixesIndex++] = this._prefixIndex;
/*     */           break;
/*     */ 
/*     */         
/*     */         case 3:
/* 590 */           prefix = decodeIdentifyingNonEmptyStringOnFirstBitAsPrefix(true);
/* 591 */           a = createAttribute("http://www.w3.org/2000/xmlns/", createQualifiedNameString(EncodingConstants.XMLNS_NAMESPACE_PREFIX_CHARS, prefix), prefix);
/*     */ 
/*     */ 
/*     */           
/* 595 */           a.setValue(decodeIdentifyingNonEmptyStringOnFirstBitAsNamespaceName(true));
/*     */           
/* 597 */           this._namespacePrefixes[this._namespacePrefixesIndex++] = this._prefixIndex;
/*     */           break;
/*     */       } 
/*     */       
/* 601 */       this._prefixTable.pushScope(this._prefixIndex, this._namespaceNameIndex);
/*     */       
/* 603 */       this._namespaceAttributes[this._namespaceAttributesIndex++] = a;
/*     */       
/* 605 */       b = read();
/*     */     } 
/* 607 */     if (b != 240) {
/* 608 */       throw new IOException(CommonResourceBundle.getInstance().getString("message.EIInamespaceNameNotTerminatedCorrectly"));
/*     */     }
/* 610 */     int end = this._namespacePrefixesIndex;
/*     */     
/* 612 */     this._b = read();
/* 613 */     switch (DecoderStateTables.EII[this._b]) {
/*     */       case 0:
/* 615 */         processEII(this._elementNameTable._array[this._b], hasAttributes);
/*     */         break;
/*     */       case 2:
/* 618 */         processEII(decodeEIIIndexMedium(), hasAttributes);
/*     */         break;
/*     */       case 3:
/* 621 */         processEII(decodeEIIIndexLarge(), hasAttributes);
/*     */         break;
/*     */       
/*     */       case 5:
/* 625 */         qn = processLiteralQualifiedName(this._b & 0x3);
/*     */         
/* 627 */         this._elementNameTable.add(qn);
/* 628 */         processEII(qn, hasAttributes);
/*     */         break;
/*     */       
/*     */       default:
/* 632 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingEIIAfterAIIs"));
/*     */     } 
/*     */     
/* 635 */     for (int i = start; i < end; i++) {
/* 636 */       this._prefixTable.popScope(this._namespacePrefixes[i]);
/*     */     }
/* 638 */     this._namespacePrefixesIndex = start;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final QualifiedName processLiteralQualifiedName(int state) throws FastInfosetException, IOException {
/* 643 */     switch (state) {
/*     */       
/*     */       case 0:
/* 646 */         return new QualifiedName(null, null, decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), -1, -1, this._identifier, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 656 */         return new QualifiedName(null, decodeIdentifyingNonEmptyStringIndexOnFirstBitAsNamespaceName(false), decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), -1, this._namespaceNameIndex, this._identifier, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 666 */         throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.qNameMissingNamespaceName"));
/*     */       
/*     */       case 3:
/* 669 */         return new QualifiedName(decodeIdentifyingNonEmptyStringIndexOnFirstBitAsPrefix(true), decodeIdentifyingNonEmptyStringIndexOnFirstBitAsNamespaceName(true), decodeIdentifyingNonEmptyStringOnFirstBit(this._v.localName), this._prefixIndex, this._namespaceNameIndex, this._identifier, this._charBuffer);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 678 */     throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.decodingEII"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void processAIIs() throws FastInfosetException, IOException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*     */     //   4: dup
/*     */     //   5: getfield _currentIteration : I
/*     */     //   8: iconst_1
/*     */     //   9: iadd
/*     */     //   10: dup_x1
/*     */     //   11: putfield _currentIteration : I
/*     */     //   14: ldc 2147483647
/*     */     //   16: if_icmpne -> 26
/*     */     //   19: aload_0
/*     */     //   20: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*     */     //   23: invokevirtual clear : ()V
/*     */     //   26: aload_0
/*     */     //   27: invokevirtual read : ()I
/*     */     //   30: istore_2
/*     */     //   31: getstatic com/sun/xml/fastinfoset/DecoderStateTables.AII : [I
/*     */     //   34: iload_2
/*     */     //   35: iaload
/*     */     //   36: tableswitch default -> 204, 0 -> 76, 1 -> 89, 2 -> 120, 3 -> 160, 4 -> 196, 5 -> 191
/*     */     //   76: aload_0
/*     */     //   77: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*     */     //   80: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*     */     //   83: iload_2
/*     */     //   84: aaload
/*     */     //   85: astore_1
/*     */     //   86: goto -> 220
/*     */     //   89: iload_2
/*     */     //   90: bipush #31
/*     */     //   92: iand
/*     */     //   93: bipush #8
/*     */     //   95: ishl
/*     */     //   96: aload_0
/*     */     //   97: invokevirtual read : ()I
/*     */     //   100: ior
/*     */     //   101: bipush #64
/*     */     //   103: iadd
/*     */     //   104: istore #4
/*     */     //   106: aload_0
/*     */     //   107: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*     */     //   110: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*     */     //   113: iload #4
/*     */     //   115: aaload
/*     */     //   116: astore_1
/*     */     //   117: goto -> 220
/*     */     //   120: iload_2
/*     */     //   121: bipush #15
/*     */     //   123: iand
/*     */     //   124: bipush #16
/*     */     //   126: ishl
/*     */     //   127: aload_0
/*     */     //   128: invokevirtual read : ()I
/*     */     //   131: bipush #8
/*     */     //   133: ishl
/*     */     //   134: ior
/*     */     //   135: aload_0
/*     */     //   136: invokevirtual read : ()I
/*     */     //   139: ior
/*     */     //   140: sipush #8256
/*     */     //   143: iadd
/*     */     //   144: istore #4
/*     */     //   146: aload_0
/*     */     //   147: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*     */     //   150: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*     */     //   153: iload #4
/*     */     //   155: aaload
/*     */     //   156: astore_1
/*     */     //   157: goto -> 220
/*     */     //   160: aload_0
/*     */     //   161: iload_2
/*     */     //   162: iconst_3
/*     */     //   163: iand
/*     */     //   164: invokevirtual processLiteralQualifiedName : (I)Lcom/sun/xml/fastinfoset/QualifiedName;
/*     */     //   167: astore_1
/*     */     //   168: aload_1
/*     */     //   169: aload_0
/*     */     //   170: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*     */     //   173: pop
/*     */     //   174: sipush #256
/*     */     //   177: invokevirtual createAttributeValues : (I)V
/*     */     //   180: aload_0
/*     */     //   181: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*     */     //   184: aload_1
/*     */     //   185: invokevirtual add : (Lcom/sun/xml/fastinfoset/QualifiedName;)V
/*     */     //   188: goto -> 220
/*     */     //   191: aload_0
/*     */     //   192: iconst_1
/*     */     //   193: putfield _doubleTerminate : Z
/*     */     //   196: aload_0
/*     */     //   197: iconst_1
/*     */     //   198: putfield _terminate : Z
/*     */     //   201: goto -> 1193
/*     */     //   204: new java/io/IOException
/*     */     //   207: dup
/*     */     //   208: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*     */     //   211: ldc 'message.decodingAIIs'
/*     */     //   213: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   216: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   219: athrow
/*     */     //   220: aload_1
/*     */     //   221: getfield prefixIndex : I
/*     */     //   224: ifle -> 262
/*     */     //   227: aload_0
/*     */     //   228: getfield _prefixTable : Lcom/sun/xml/fastinfoset/util/PrefixArray;
/*     */     //   231: getfield _currentInScope : [I
/*     */     //   234: aload_1
/*     */     //   235: getfield prefixIndex : I
/*     */     //   238: iaload
/*     */     //   239: aload_1
/*     */     //   240: getfield namespaceNameIndex : I
/*     */     //   243: if_icmpeq -> 262
/*     */     //   246: new org/jvnet/fastinfoset/FastInfosetException
/*     */     //   249: dup
/*     */     //   250: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*     */     //   253: ldc 'message.AIIqNameNotInScope'
/*     */     //   255: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   258: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   261: athrow
/*     */     //   262: aload_0
/*     */     //   263: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*     */     //   266: aload_1
/*     */     //   267: getfield attributeHash : I
/*     */     //   270: aload_1
/*     */     //   271: getfield attributeId : I
/*     */     //   274: invokevirtual checkForDuplicateAttribute : (II)V
/*     */     //   277: aload_0
/*     */     //   278: aload_1
/*     */     //   279: getfield namespaceName : Ljava/lang/String;
/*     */     //   282: aload_1
/*     */     //   283: getfield qName : Ljava/lang/String;
/*     */     //   286: aload_1
/*     */     //   287: getfield localName : Ljava/lang/String;
/*     */     //   290: invokevirtual createAttribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/w3c/dom/Attr;
/*     */     //   293: astore #4
/*     */     //   295: aload_0
/*     */     //   296: invokevirtual read : ()I
/*     */     //   299: istore_2
/*     */     //   300: getstatic com/sun/xml/fastinfoset/DecoderStateTables.NISTRING : [I
/*     */     //   303: iload_2
/*     */     //   304: iaload
/*     */     //   305: tableswitch default -> 1177, 0 -> 368, 1 -> 434, 2 -> 501, 3 -> 597, 4 -> 663, 5 -> 730, 6 -> 826, 7 -> 918, 8 -> 1006, 9 -> 1042, 10 -> 1093, 11 -> 1153
/*     */     //   368: iload_2
/*     */     //   369: bipush #64
/*     */     //   371: iand
/*     */     //   372: ifle -> 379
/*     */     //   375: iconst_1
/*     */     //   376: goto -> 380
/*     */     //   379: iconst_0
/*     */     //   380: istore #5
/*     */     //   382: aload_0
/*     */     //   383: iload_2
/*     */     //   384: bipush #7
/*     */     //   386: iand
/*     */     //   387: iconst_1
/*     */     //   388: iadd
/*     */     //   389: putfield _octetBufferLength : I
/*     */     //   392: aload_0
/*     */     //   393: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*     */     //   396: astore_3
/*     */     //   397: iload #5
/*     */     //   399: ifeq -> 411
/*     */     //   402: aload_0
/*     */     //   403: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   406: aload_3
/*     */     //   407: invokevirtual add : (Ljava/lang/String;)I
/*     */     //   410: pop
/*     */     //   411: aload #4
/*     */     //   413: aload_3
/*     */     //   414: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   419: aload_0
/*     */     //   420: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   423: aload #4
/*     */     //   425: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   430: pop
/*     */     //   431: goto -> 1193
/*     */     //   434: iload_2
/*     */     //   435: bipush #64
/*     */     //   437: iand
/*     */     //   438: ifle -> 445
/*     */     //   441: iconst_1
/*     */     //   442: goto -> 446
/*     */     //   445: iconst_0
/*     */     //   446: istore #5
/*     */     //   448: aload_0
/*     */     //   449: aload_0
/*     */     //   450: invokevirtual read : ()I
/*     */     //   453: bipush #9
/*     */     //   455: iadd
/*     */     //   456: putfield _octetBufferLength : I
/*     */     //   459: aload_0
/*     */     //   460: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*     */     //   463: astore_3
/*     */     //   464: iload #5
/*     */     //   466: ifeq -> 478
/*     */     //   469: aload_0
/*     */     //   470: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   473: aload_3
/*     */     //   474: invokevirtual add : (Ljava/lang/String;)I
/*     */     //   477: pop
/*     */     //   478: aload #4
/*     */     //   480: aload_3
/*     */     //   481: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   486: aload_0
/*     */     //   487: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   490: aload #4
/*     */     //   492: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   497: pop
/*     */     //   498: goto -> 1193
/*     */     //   501: iload_2
/*     */     //   502: bipush #64
/*     */     //   504: iand
/*     */     //   505: ifle -> 512
/*     */     //   508: iconst_1
/*     */     //   509: goto -> 513
/*     */     //   512: iconst_0
/*     */     //   513: istore #5
/*     */     //   515: aload_0
/*     */     //   516: invokevirtual read : ()I
/*     */     //   519: bipush #24
/*     */     //   521: ishl
/*     */     //   522: aload_0
/*     */     //   523: invokevirtual read : ()I
/*     */     //   526: bipush #16
/*     */     //   528: ishl
/*     */     //   529: ior
/*     */     //   530: aload_0
/*     */     //   531: invokevirtual read : ()I
/*     */     //   534: bipush #8
/*     */     //   536: ishl
/*     */     //   537: ior
/*     */     //   538: aload_0
/*     */     //   539: invokevirtual read : ()I
/*     */     //   542: ior
/*     */     //   543: istore #6
/*     */     //   545: aload_0
/*     */     //   546: iload #6
/*     */     //   548: sipush #265
/*     */     //   551: iadd
/*     */     //   552: putfield _octetBufferLength : I
/*     */     //   555: aload_0
/*     */     //   556: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*     */     //   559: astore_3
/*     */     //   560: iload #5
/*     */     //   562: ifeq -> 574
/*     */     //   565: aload_0
/*     */     //   566: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   569: aload_3
/*     */     //   570: invokevirtual add : (Ljava/lang/String;)I
/*     */     //   573: pop
/*     */     //   574: aload #4
/*     */     //   576: aload_3
/*     */     //   577: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   582: aload_0
/*     */     //   583: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   586: aload #4
/*     */     //   588: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   593: pop
/*     */     //   594: goto -> 1193
/*     */     //   597: iload_2
/*     */     //   598: bipush #64
/*     */     //   600: iand
/*     */     //   601: ifle -> 608
/*     */     //   604: iconst_1
/*     */     //   605: goto -> 609
/*     */     //   608: iconst_0
/*     */     //   609: istore #5
/*     */     //   611: aload_0
/*     */     //   612: iload_2
/*     */     //   613: bipush #7
/*     */     //   615: iand
/*     */     //   616: iconst_1
/*     */     //   617: iadd
/*     */     //   618: putfield _octetBufferLength : I
/*     */     //   621: aload_0
/*     */     //   622: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*     */     //   625: astore_3
/*     */     //   626: iload #5
/*     */     //   628: ifeq -> 640
/*     */     //   631: aload_0
/*     */     //   632: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   635: aload_3
/*     */     //   636: invokevirtual add : (Ljava/lang/String;)I
/*     */     //   639: pop
/*     */     //   640: aload #4
/*     */     //   642: aload_3
/*     */     //   643: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   648: aload_0
/*     */     //   649: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   652: aload #4
/*     */     //   654: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   659: pop
/*     */     //   660: goto -> 1193
/*     */     //   663: iload_2
/*     */     //   664: bipush #64
/*     */     //   666: iand
/*     */     //   667: ifle -> 674
/*     */     //   670: iconst_1
/*     */     //   671: goto -> 675
/*     */     //   674: iconst_0
/*     */     //   675: istore #5
/*     */     //   677: aload_0
/*     */     //   678: aload_0
/*     */     //   679: invokevirtual read : ()I
/*     */     //   682: bipush #9
/*     */     //   684: iadd
/*     */     //   685: putfield _octetBufferLength : I
/*     */     //   688: aload_0
/*     */     //   689: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*     */     //   692: astore_3
/*     */     //   693: iload #5
/*     */     //   695: ifeq -> 707
/*     */     //   698: aload_0
/*     */     //   699: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   702: aload_3
/*     */     //   703: invokevirtual add : (Ljava/lang/String;)I
/*     */     //   706: pop
/*     */     //   707: aload #4
/*     */     //   709: aload_3
/*     */     //   710: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   715: aload_0
/*     */     //   716: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   719: aload #4
/*     */     //   721: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   726: pop
/*     */     //   727: goto -> 1193
/*     */     //   730: iload_2
/*     */     //   731: bipush #64
/*     */     //   733: iand
/*     */     //   734: ifle -> 741
/*     */     //   737: iconst_1
/*     */     //   738: goto -> 742
/*     */     //   741: iconst_0
/*     */     //   742: istore #5
/*     */     //   744: aload_0
/*     */     //   745: invokevirtual read : ()I
/*     */     //   748: bipush #24
/*     */     //   750: ishl
/*     */     //   751: aload_0
/*     */     //   752: invokevirtual read : ()I
/*     */     //   755: bipush #16
/*     */     //   757: ishl
/*     */     //   758: ior
/*     */     //   759: aload_0
/*     */     //   760: invokevirtual read : ()I
/*     */     //   763: bipush #8
/*     */     //   765: ishl
/*     */     //   766: ior
/*     */     //   767: aload_0
/*     */     //   768: invokevirtual read : ()I
/*     */     //   771: ior
/*     */     //   772: istore #6
/*     */     //   774: aload_0
/*     */     //   775: iload #6
/*     */     //   777: sipush #265
/*     */     //   780: iadd
/*     */     //   781: putfield _octetBufferLength : I
/*     */     //   784: aload_0
/*     */     //   785: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*     */     //   788: astore_3
/*     */     //   789: iload #5
/*     */     //   791: ifeq -> 803
/*     */     //   794: aload_0
/*     */     //   795: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   798: aload_3
/*     */     //   799: invokevirtual add : (Ljava/lang/String;)I
/*     */     //   802: pop
/*     */     //   803: aload #4
/*     */     //   805: aload_3
/*     */     //   806: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   811: aload_0
/*     */     //   812: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   815: aload #4
/*     */     //   817: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   822: pop
/*     */     //   823: goto -> 1193
/*     */     //   826: iload_2
/*     */     //   827: bipush #64
/*     */     //   829: iand
/*     */     //   830: ifle -> 837
/*     */     //   833: iconst_1
/*     */     //   834: goto -> 838
/*     */     //   837: iconst_0
/*     */     //   838: istore #5
/*     */     //   840: aload_0
/*     */     //   841: iload_2
/*     */     //   842: bipush #15
/*     */     //   844: iand
/*     */     //   845: iconst_4
/*     */     //   846: ishl
/*     */     //   847: putfield _identifier : I
/*     */     //   850: aload_0
/*     */     //   851: invokevirtual read : ()I
/*     */     //   854: istore_2
/*     */     //   855: aload_0
/*     */     //   856: dup
/*     */     //   857: getfield _identifier : I
/*     */     //   860: iload_2
/*     */     //   861: sipush #240
/*     */     //   864: iand
/*     */     //   865: iconst_4
/*     */     //   866: ishr
/*     */     //   867: ior
/*     */     //   868: putfield _identifier : I
/*     */     //   871: aload_0
/*     */     //   872: iload_2
/*     */     //   873: invokevirtual decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit : (I)V
/*     */     //   876: aload_0
/*     */     //   877: invokevirtual decodeRestrictedAlphabetAsString : ()Ljava/lang/String;
/*     */     //   880: astore_3
/*     */     //   881: iload #5
/*     */     //   883: ifeq -> 895
/*     */     //   886: aload_0
/*     */     //   887: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   890: aload_3
/*     */     //   891: invokevirtual add : (Ljava/lang/String;)I
/*     */     //   894: pop
/*     */     //   895: aload #4
/*     */     //   897: aload_3
/*     */     //   898: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   903: aload_0
/*     */     //   904: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   907: aload #4
/*     */     //   909: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   914: pop
/*     */     //   915: goto -> 1193
/*     */     //   918: iload_2
/*     */     //   919: bipush #64
/*     */     //   921: iand
/*     */     //   922: ifle -> 941
/*     */     //   925: new org/jvnet/fastinfoset/EncodingAlgorithmException
/*     */     //   928: dup
/*     */     //   929: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*     */     //   932: ldc 'message.addToTableNotSupported'
/*     */     //   934: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   937: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   940: athrow
/*     */     //   941: aload_0
/*     */     //   942: iload_2
/*     */     //   943: bipush #15
/*     */     //   945: iand
/*     */     //   946: iconst_4
/*     */     //   947: ishl
/*     */     //   948: putfield _identifier : I
/*     */     //   951: aload_0
/*     */     //   952: invokevirtual read : ()I
/*     */     //   955: istore_2
/*     */     //   956: aload_0
/*     */     //   957: dup
/*     */     //   958: getfield _identifier : I
/*     */     //   961: iload_2
/*     */     //   962: sipush #240
/*     */     //   965: iand
/*     */     //   966: iconst_4
/*     */     //   967: ishr
/*     */     //   968: ior
/*     */     //   969: putfield _identifier : I
/*     */     //   972: aload_0
/*     */     //   973: iload_2
/*     */     //   974: invokevirtual decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit : (I)V
/*     */     //   977: aload_0
/*     */     //   978: iconst_1
/*     */     //   979: invokevirtual convertEncodingAlgorithmDataToCharacters : (Z)Ljava/lang/String;
/*     */     //   982: astore_3
/*     */     //   983: aload #4
/*     */     //   985: aload_3
/*     */     //   986: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   991: aload_0
/*     */     //   992: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   995: aload #4
/*     */     //   997: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   1002: pop
/*     */     //   1003: goto -> 1193
/*     */     //   1006: aload_0
/*     */     //   1007: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   1010: getfield _array : [Ljava/lang/String;
/*     */     //   1013: iload_2
/*     */     //   1014: bipush #63
/*     */     //   1016: iand
/*     */     //   1017: aaload
/*     */     //   1018: astore_3
/*     */     //   1019: aload #4
/*     */     //   1021: aload_3
/*     */     //   1022: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   1027: aload_0
/*     */     //   1028: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   1031: aload #4
/*     */     //   1033: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   1038: pop
/*     */     //   1039: goto -> 1193
/*     */     //   1042: iload_2
/*     */     //   1043: bipush #31
/*     */     //   1045: iand
/*     */     //   1046: bipush #8
/*     */     //   1048: ishl
/*     */     //   1049: aload_0
/*     */     //   1050: invokevirtual read : ()I
/*     */     //   1053: ior
/*     */     //   1054: bipush #64
/*     */     //   1056: iadd
/*     */     //   1057: istore #5
/*     */     //   1059: aload_0
/*     */     //   1060: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   1063: getfield _array : [Ljava/lang/String;
/*     */     //   1066: iload #5
/*     */     //   1068: aaload
/*     */     //   1069: astore_3
/*     */     //   1070: aload #4
/*     */     //   1072: aload_3
/*     */     //   1073: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   1078: aload_0
/*     */     //   1079: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   1082: aload #4
/*     */     //   1084: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   1089: pop
/*     */     //   1090: goto -> 1193
/*     */     //   1093: iload_2
/*     */     //   1094: bipush #15
/*     */     //   1096: iand
/*     */     //   1097: bipush #16
/*     */     //   1099: ishl
/*     */     //   1100: aload_0
/*     */     //   1101: invokevirtual read : ()I
/*     */     //   1104: bipush #8
/*     */     //   1106: ishl
/*     */     //   1107: ior
/*     */     //   1108: aload_0
/*     */     //   1109: invokevirtual read : ()I
/*     */     //   1112: ior
/*     */     //   1113: sipush #8256
/*     */     //   1116: iadd
/*     */     //   1117: istore #5
/*     */     //   1119: aload_0
/*     */     //   1120: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*     */     //   1123: getfield _array : [Ljava/lang/String;
/*     */     //   1126: iload #5
/*     */     //   1128: aaload
/*     */     //   1129: astore_3
/*     */     //   1130: aload #4
/*     */     //   1132: aload_3
/*     */     //   1133: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   1138: aload_0
/*     */     //   1139: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   1142: aload #4
/*     */     //   1144: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   1149: pop
/*     */     //   1150: goto -> 1193
/*     */     //   1153: aload #4
/*     */     //   1155: ldc ''
/*     */     //   1157: invokeinterface setValue : (Ljava/lang/String;)V
/*     */     //   1162: aload_0
/*     */     //   1163: getfield _currentElement : Lorg/w3c/dom/Element;
/*     */     //   1166: aload #4
/*     */     //   1168: invokeinterface setAttributeNode : (Lorg/w3c/dom/Attr;)Lorg/w3c/dom/Attr;
/*     */     //   1173: pop
/*     */     //   1174: goto -> 1193
/*     */     //   1177: new java/io/IOException
/*     */     //   1180: dup
/*     */     //   1181: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*     */     //   1184: ldc 'message.decodingAIIValue'
/*     */     //   1186: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1189: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   1192: athrow
/*     */     //   1193: aload_0
/*     */     //   1194: getfield _terminate : Z
/*     */     //   1197: ifeq -> 26
/*     */     //   1200: aload_0
/*     */     //   1201: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*     */     //   1204: aload_0
/*     */     //   1205: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*     */     //   1208: getfield _poolHead : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier$Entry;
/*     */     //   1211: putfield _poolCurrent : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier$Entry;
/*     */     //   1214: aload_0
/*     */     //   1215: aload_0
/*     */     //   1216: getfield _doubleTerminate : Z
/*     */     //   1219: putfield _terminate : Z
/*     */     //   1222: aload_0
/*     */     //   1223: iconst_0
/*     */     //   1224: putfield _doubleTerminate : Z
/*     */     //   1227: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #687	-> 0
/*     */     //   #688	-> 19
/*     */     //   #693	-> 26
/*     */     //   #694	-> 31
/*     */     //   #696	-> 76
/*     */     //   #697	-> 86
/*     */     //   #700	-> 89
/*     */     //   #702	-> 106
/*     */     //   #703	-> 117
/*     */     //   #707	-> 120
/*     */     //   #709	-> 146
/*     */     //   #710	-> 157
/*     */     //   #713	-> 160
/*     */     //   #715	-> 168
/*     */     //   #716	-> 180
/*     */     //   #717	-> 188
/*     */     //   #719	-> 191
/*     */     //   #721	-> 196
/*     */     //   #723	-> 201
/*     */     //   #725	-> 204
/*     */     //   #728	-> 220
/*     */     //   #729	-> 246
/*     */     //   #732	-> 262
/*     */     //   #734	-> 277
/*     */     //   #741	-> 295
/*     */     //   #742	-> 300
/*     */     //   #745	-> 368
/*     */     //   #746	-> 382
/*     */     //   #747	-> 392
/*     */     //   #748	-> 397
/*     */     //   #749	-> 402
/*     */     //   #752	-> 411
/*     */     //   #753	-> 419
/*     */     //   #754	-> 431
/*     */     //   #758	-> 434
/*     */     //   #759	-> 448
/*     */     //   #760	-> 459
/*     */     //   #761	-> 464
/*     */     //   #762	-> 469
/*     */     //   #765	-> 478
/*     */     //   #766	-> 486
/*     */     //   #767	-> 498
/*     */     //   #771	-> 501
/*     */     //   #772	-> 515
/*     */     //   #776	-> 545
/*     */     //   #777	-> 555
/*     */     //   #778	-> 560
/*     */     //   #779	-> 565
/*     */     //   #782	-> 574
/*     */     //   #783	-> 582
/*     */     //   #784	-> 594
/*     */     //   #788	-> 597
/*     */     //   #789	-> 611
/*     */     //   #790	-> 621
/*     */     //   #791	-> 626
/*     */     //   #792	-> 631
/*     */     //   #795	-> 640
/*     */     //   #796	-> 648
/*     */     //   #797	-> 660
/*     */     //   #801	-> 663
/*     */     //   #802	-> 677
/*     */     //   #803	-> 688
/*     */     //   #804	-> 693
/*     */     //   #805	-> 698
/*     */     //   #808	-> 707
/*     */     //   #809	-> 715
/*     */     //   #810	-> 727
/*     */     //   #814	-> 730
/*     */     //   #815	-> 744
/*     */     //   #819	-> 774
/*     */     //   #820	-> 784
/*     */     //   #821	-> 789
/*     */     //   #822	-> 794
/*     */     //   #825	-> 803
/*     */     //   #826	-> 811
/*     */     //   #827	-> 823
/*     */     //   #831	-> 826
/*     */     //   #833	-> 840
/*     */     //   #834	-> 850
/*     */     //   #835	-> 855
/*     */     //   #837	-> 871
/*     */     //   #839	-> 876
/*     */     //   #840	-> 881
/*     */     //   #841	-> 886
/*     */     //   #844	-> 895
/*     */     //   #845	-> 903
/*     */     //   #846	-> 915
/*     */     //   #850	-> 918
/*     */     //   #851	-> 925
/*     */     //   #854	-> 941
/*     */     //   #855	-> 951
/*     */     //   #856	-> 956
/*     */     //   #858	-> 972
/*     */     //   #859	-> 977
/*     */     //   #860	-> 983
/*     */     //   #861	-> 991
/*     */     //   #862	-> 1003
/*     */     //   #865	-> 1006
/*     */     //   #867	-> 1019
/*     */     //   #868	-> 1027
/*     */     //   #869	-> 1039
/*     */     //   #872	-> 1042
/*     */     //   #874	-> 1059
/*     */     //   #876	-> 1070
/*     */     //   #877	-> 1078
/*     */     //   #878	-> 1090
/*     */     //   #882	-> 1093
/*     */     //   #884	-> 1119
/*     */     //   #886	-> 1130
/*     */     //   #887	-> 1138
/*     */     //   #888	-> 1150
/*     */     //   #891	-> 1153
/*     */     //   #892	-> 1162
/*     */     //   #893	-> 1174
/*     */     //   #895	-> 1177
/*     */     //   #898	-> 1193
/*     */     //   #901	-> 1200
/*     */     //   #903	-> 1214
/*     */     //   #904	-> 1222
/*     */     //   #905	-> 1227
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   106	14	4	i	I
/*     */     //   146	14	4	i	I
/*     */     //   382	52	5	addToTable	Z
/*     */     //   448	53	5	addToTable	Z
/*     */     //   515	82	5	addToTable	Z
/*     */     //   545	52	6	length	I
/*     */     //   611	52	5	addToTable	Z
/*     */     //   677	53	5	addToTable	Z
/*     */     //   744	82	5	addToTable	Z
/*     */     //   774	52	6	length	I
/*     */     //   840	78	5	addToTable	Z
/*     */     //   1059	34	5	index	I
/*     */     //   1119	34	5	index	I
/*     */     //   295	898	4	a	Lorg/w3c/dom/Attr;
/*     */     //   86	1107	1	name	Lcom/sun/xml/fastinfoset/QualifiedName;
/*     */     //   0	1228	0	this	Lcom/sun/xml/fastinfoset/dom/DOMDocumentParser;
/*     */     //   31	1197	2	b	I
/*     */     //   397	831	3	value	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void processCommentII() throws FastInfosetException, IOException {
/*     */     String s;
/* 908 */     switch (decodeNonIdentifyingStringOnFirstBit()) {
/*     */       
/*     */       case 0:
/* 911 */         s = new String(this._charBuffer, 0, this._charBufferLength);
/* 912 */         if (this._addToTable) {
/* 913 */           this._v.otherString.add((CharArray)new CharArrayString(s, false));
/*     */         }
/*     */         
/* 916 */         this._currentNode.appendChild(this._document.createComment(s));
/*     */         break;
/*     */       
/*     */       case 2:
/* 920 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.commentIIAlgorithmNotSupported"));
/*     */       
/*     */       case 1:
/* 923 */         s = this._v.otherString.get(this._integer).toString();
/*     */         
/* 925 */         this._currentNode.appendChild(this._document.createComment(s));
/*     */         break;
/*     */       
/*     */       case 3:
/* 929 */         this._currentNode.appendChild(this._document.createComment(""));
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void processProcessingII() throws FastInfosetException, IOException {
/* 935 */     String data, target = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*     */     
/* 937 */     switch (decodeNonIdentifyingStringOnFirstBit()) {
/*     */       
/*     */       case 0:
/* 940 */         data = new String(this._charBuffer, 0, this._charBufferLength);
/* 941 */         if (this._addToTable) {
/* 942 */           this._v.otherString.add((CharArray)new CharArrayString(data, false));
/*     */         }
/*     */         
/* 945 */         this._currentNode.appendChild(this._document.createProcessingInstruction(target, data));
/*     */         break;
/*     */       
/*     */       case 2:
/* 949 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.processingIIWithEncodingAlgorithm"));
/*     */       
/*     */       case 1:
/* 952 */         data = this._v.otherString.get(this._integer).toString();
/*     */         
/* 954 */         this._currentNode.appendChild(this._document.createProcessingInstruction(target, data));
/*     */         break;
/*     */       
/*     */       case 3:
/* 958 */         this._currentNode.appendChild(this._document.createProcessingInstruction(target, ""));
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Element createElement(String namespaceName, String qName, String localName) {
/* 964 */     return this._document.createElementNS(namespaceName, qName);
/*     */   }
/*     */   
/*     */   protected Attr createAttribute(String namespaceName, String qName, String localName) {
/* 968 */     return this._document.createAttributeNS(namespaceName, qName);
/*     */   }
/*     */   
/*     */   protected String convertEncodingAlgorithmDataToCharacters(boolean isAttributeValue) throws FastInfosetException, IOException {
/* 972 */     StringBuffer buffer = new StringBuffer();
/* 973 */     if (this._identifier < 9)
/* 974 */     { Object array = BuiltInEncodingAlgorithmFactory.table[this._identifier].decodeFromBytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*     */       
/* 976 */       BuiltInEncodingAlgorithmFactory.table[this._identifier].convertToCharacters(array, buffer); }
/* 977 */     else { if (this._identifier == 9) {
/* 978 */         if (!isAttributeValue) {
/*     */           
/* 980 */           this._octetBufferOffset -= this._octetBufferLength;
/* 981 */           return decodeUtf8StringAsString();
/*     */         } 
/* 983 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.CDATAAlgorithmNotSupported"));
/* 984 */       }  if (this._identifier >= 32) {
/* 985 */         String URI = this._v.encodingAlgorithm.get(this._identifier - 32);
/* 986 */         EncodingAlgorithm ea = (EncodingAlgorithm)this._registeredEncodingAlgorithms.get(URI);
/* 987 */         if (ea != null) {
/* 988 */           Object data = ea.decodeFromBytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/* 989 */           ea.convertToCharacters(data, buffer);
/*     */         } else {
/* 991 */           throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.algorithmDataCannotBeReported"));
/*     */         } 
/*     */       }  }
/*     */     
/* 995 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\dom\DOMDocumentParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */