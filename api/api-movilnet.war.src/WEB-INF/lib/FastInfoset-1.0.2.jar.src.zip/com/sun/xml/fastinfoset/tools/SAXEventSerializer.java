/*     */ package com.sun.xml.fastinfoset.tools;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAXEventSerializer
/*     */   extends DefaultHandler
/*     */   implements LexicalHandler
/*     */ {
/*     */   private Writer _writer;
/*     */   private boolean _charactersAreCDATA;
/*     */   private StringBuffer _characters;
/*  63 */   private Stack _namespaceStack = new Stack();
/*     */   protected List _namespaceAttributes;
/*     */   
/*     */   public SAXEventSerializer(OutputStream s) throws IOException {
/*  67 */     this._writer = new OutputStreamWriter(s);
/*  68 */     this._charactersAreCDATA = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() throws SAXException {
/*     */     try {
/*  75 */       this._writer.write("<sax xmlns=\"http://www.sun.com/xml/sax-events\">\n");
/*  76 */       this._writer.write("<startDocument/>\n");
/*  77 */       this._writer.flush();
/*     */     }
/*  79 */     catch (IOException e) {
/*  80 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endDocument() throws SAXException {
/*     */     try {
/*  86 */       this._writer.write("<endDocument/>\n");
/*  87 */       this._writer.write("</sax>");
/*  88 */       this._writer.flush();
/*  89 */       this._writer.close();
/*     */     }
/*  91 */     catch (IOException e) {
/*  92 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 100 */     if (this._namespaceAttributes == null) {
/* 101 */       this._namespaceAttributes = new ArrayList();
/*     */     }
/*     */     
/* 104 */     String qName = (prefix == "") ? "xmlns" : ("xmlns" + prefix);
/* 105 */     AttributeValueHolder attribute = new AttributeValueHolder(qName, prefix, uri, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this._namespaceAttributes.add(attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
/*     */     try {
/* 136 */       outputCharacters();
/*     */       
/* 138 */       if (this._namespaceAttributes != null) {
/*     */         
/* 140 */         AttributeValueHolder[] arrayOfAttributeValueHolder = new AttributeValueHolder[0];
/* 141 */         arrayOfAttributeValueHolder = (AttributeValueHolder[])this._namespaceAttributes.toArray((Object[])arrayOfAttributeValueHolder);
/*     */ 
/*     */         
/* 144 */         quicksort(arrayOfAttributeValueHolder, 0, arrayOfAttributeValueHolder.length - 1);
/*     */         
/* 146 */         for (int k = 0; k < arrayOfAttributeValueHolder.length; k++) {
/* 147 */           this._writer.write("<startPrefixMapping prefix=\"" + (arrayOfAttributeValueHolder[k]).localName + "\" uri=\"" + (arrayOfAttributeValueHolder[k]).uri + "\"/>\n");
/*     */           
/* 149 */           this._writer.flush();
/*     */         } 
/*     */         
/* 152 */         this._namespaceStack.push(arrayOfAttributeValueHolder);
/* 153 */         this._namespaceAttributes = null;
/*     */       } else {
/* 155 */         this._namespaceStack.push(null);
/*     */       } 
/*     */       
/* 158 */       AttributeValueHolder[] attrsHolder = new AttributeValueHolder[attributes.getLength()];
/*     */       
/* 160 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 161 */         attrsHolder[i] = new AttributeValueHolder(attributes.getQName(i), attributes.getLocalName(i), attributes.getURI(i), attributes.getType(i), attributes.getValue(i));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       quicksort(attrsHolder, 0, attrsHolder.length - 1);
/*     */       
/* 172 */       int attributeCount = 0; int j;
/* 173 */       for (j = 0; j < attrsHolder.length; j++) {
/* 174 */         if (!(attrsHolder[j]).uri.equals("http://www.w3.org/2000/xmlns/"))
/*     */         {
/*     */ 
/*     */           
/* 178 */           attributeCount++;
/*     */         }
/*     */       } 
/* 181 */       if (attributeCount == 0) {
/* 182 */         this._writer.write("<startElement uri=\"" + uri + "\" localName=\"" + localName + "\" qName=\"" + qName + "\"/>\n");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 188 */       this._writer.write("<startElement uri=\"" + uri + "\" localName=\"" + localName + "\" qName=\"" + qName + "\">\n");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 193 */       for (j = 0; j < attrsHolder.length; j++) {
/* 194 */         if (!(attrsHolder[j]).uri.equals("http://www.w3.org/2000/xmlns/"))
/*     */         {
/*     */ 
/*     */           
/* 198 */           this._writer.write("  <attribute qName=\"" + (attrsHolder[j]).qName + "\" localName=\"" + (attrsHolder[j]).localName + "\" uri=\"" + (attrsHolder[j]).uri + "\" value=\"" + (attrsHolder[j]).value + "\"/>\n");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       this._writer.write("</startElement>\n");
/* 208 */       this._writer.flush();
/*     */     }
/* 210 */     catch (IOException e) {
/* 211 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {
/*     */     try {
/* 219 */       outputCharacters();
/*     */       
/* 221 */       this._writer.write("<endElement uri=\"" + uri + "\" localName=\"" + localName + "\" qName=\"" + qName + "\"/>\n");
/*     */ 
/*     */       
/* 224 */       this._writer.flush();
/*     */ 
/*     */ 
/*     */       
/* 228 */       AttributeValueHolder[] attrsHolder = this._namespaceStack.pop();
/* 229 */       if (attrsHolder != null) {
/* 230 */         for (int i = 0; i < attrsHolder.length; i++) {
/* 231 */           this._writer.write("<endPrefixMapping prefix=\"" + (attrsHolder[i]).localName + "\"/>\n");
/*     */           
/* 233 */           this._writer.flush();
/*     */         }
/*     */       
/*     */       }
/*     */     }
/* 238 */     catch (IOException e) {
/* 239 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 246 */     if (length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 250 */     if (this._characters == null) {
/* 251 */       this._characters = new StringBuffer();
/*     */     }
/*     */ 
/*     */     
/* 255 */     this._characters.append(ch, start, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void outputCharacters() throws SAXException {
/* 273 */     if (this._characters == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 278 */       this._writer.write("<characters>" + (this._charactersAreCDATA ? "<![CDATA[" : "") + this._characters + (this._charactersAreCDATA ? "]]>" : "") + "</characters>\n");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 283 */       this._writer.flush();
/*     */       
/* 285 */       this._characters = null;
/* 286 */     } catch (IOException e) {
/* 287 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 295 */     characters(ch, start, length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {
/*     */     try {
/* 302 */       outputCharacters();
/*     */       
/* 304 */       this._writer.write("<processingInstruction target=\"" + target + "\" data=\"" + data + "\"/>\n");
/*     */       
/* 306 */       this._writer.flush();
/*     */     }
/* 308 */     catch (IOException e) {
/* 309 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endDTD() throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startCDATA() throws SAXException {
/* 337 */     this._charactersAreCDATA = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void endCDATA() throws SAXException {
/* 342 */     this._charactersAreCDATA = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {
/*     */     try {
/* 349 */       outputCharacters();
/*     */       
/* 351 */       this._writer.write("<comment>" + new String(ch, start, length) + "</comment>\n");
/*     */ 
/*     */       
/* 354 */       this._writer.flush();
/*     */     }
/* 356 */     catch (IOException e) {
/* 357 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void quicksort(AttributeValueHolder[] attrs, int p, int r) {
/* 364 */     while (p < r) {
/* 365 */       int q = partition(attrs, p, r);
/* 366 */       quicksort(attrs, p, q);
/* 367 */       p = q + 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private int partition(AttributeValueHolder[] attrs, int p, int r) {
/* 372 */     AttributeValueHolder x = attrs[p + r >>> 1];
/* 373 */     int i = p - 1;
/* 374 */     int j = r + 1;
/*     */     while (true) {
/* 376 */       if (x.compareTo(attrs[--j]) < 0)
/* 377 */         continue;  while (x.compareTo(attrs[++i]) > 0);
/* 378 */       if (i < j) {
/* 379 */         AttributeValueHolder t = attrs[i];
/* 380 */         attrs[i] = attrs[j];
/* 381 */         attrs[j] = t; continue;
/*     */       }  break;
/*     */     } 
/* 384 */     return j;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class AttributeValueHolder
/*     */     implements Comparable
/*     */   {
/*     */     public final String qName;
/*     */     
/*     */     public final String localName;
/*     */     
/*     */     public final String uri;
/*     */     
/*     */     public final String type;
/*     */     
/*     */     public final String value;
/*     */     
/*     */     public AttributeValueHolder(String qName, String localName, String uri, String type, String value) {
/* 402 */       this.qName = qName;
/* 403 */       this.localName = localName;
/* 404 */       this.uri = uri;
/* 405 */       this.type = type;
/* 406 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int compareTo(Object o) {
/*     */       try {
/* 411 */         return this.qName.compareTo(((AttributeValueHolder)o).qName);
/*     */       }
/* 413 */       catch (Exception e) {
/* 414 */         throw new RuntimeException(CommonResourceBundle.getInstance().getString("message.AttributeValueHolderExpected"));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\SAXEventSerializer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */