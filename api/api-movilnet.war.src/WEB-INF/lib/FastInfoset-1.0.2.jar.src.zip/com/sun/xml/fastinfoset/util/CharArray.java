/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharArray
/*     */   implements CharSequence
/*     */ {
/*     */   public char[] ch;
/*     */   public int start;
/*     */   public int length;
/*     */   protected int _hash;
/*     */   
/*     */   protected CharArray() {}
/*     */   
/*     */   public CharArray(char[] _ch, int _start, int _length, boolean copy) {
/*  53 */     set(_ch, _start, _length, copy);
/*     */   }
/*     */   
/*     */   public final void set(char[] _ch, int _start, int _length, boolean copy) {
/*  57 */     if (copy) {
/*  58 */       this.ch = new char[_length];
/*  59 */       this.start = 0;
/*  60 */       this.length = _length;
/*  61 */       System.arraycopy(_ch, _start, this.ch, 0, _length);
/*     */     } else {
/*  63 */       this.ch = _ch;
/*  64 */       this.start = _start;
/*  65 */       this.length = _length;
/*     */     } 
/*  67 */     this._hash = 0;
/*     */   }
/*     */   
/*     */   public final void cloneArray() {
/*  71 */     char[] _ch = new char[this.length];
/*  72 */     System.arraycopy(this.ch, this.start, _ch, 0, this.length);
/*  73 */     this.ch = _ch;
/*  74 */     this.start = 0;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  78 */     return new String(this.ch, this.start, this.length);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  82 */     if (this._hash == 0)
/*     */     {
/*     */       
/*  85 */       for (int i = this.start; i < this.start + this.length; i++) {
/*  86 */         this._hash = 31 * this._hash + this.ch[i];
/*     */       }
/*     */     }
/*  89 */     return this._hash;
/*     */   }
/*     */   
/*     */   public static final int hashCode(char[] ch, int start, int length) {
/*  93 */     int hash = 0;
/*  94 */     for (int i = start; i < start + length; i++) {
/*  95 */       hash = 31 * hash + ch[i];
/*     */     }
/*     */     
/*  98 */     return hash;
/*     */   }
/*     */   
/*     */   public final boolean equalsCharArray(CharArray cha) {
/* 102 */     if (this == cha) {
/* 103 */       return true;
/*     */     }
/*     */     
/* 106 */     if (this.length == cha.length) {
/* 107 */       int n = this.length;
/* 108 */       int i = this.start;
/* 109 */       int j = cha.start;
/* 110 */       while (n-- != 0) {
/* 111 */         if (this.ch[i++] != cha.ch[j++])
/* 112 */           return false; 
/*     */       } 
/* 114 */       return true;
/*     */     } 
/*     */     
/* 117 */     return false;
/*     */   }
/*     */   
/*     */   public final boolean equalsCharArray(char[] ch, int start, int length) {
/* 121 */     if (this.length == length) {
/* 122 */       int n = this.length;
/* 123 */       int i = this.start;
/* 124 */       int j = start;
/* 125 */       while (n-- != 0) {
/* 126 */         if (this.ch[i++] != ch[j++])
/* 127 */           return false; 
/*     */       } 
/* 129 */       return true;
/*     */     } 
/*     */     
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 136 */     if (this == obj) {
/* 137 */       return true;
/*     */     }
/* 139 */     if (obj instanceof CharArray) {
/* 140 */       CharArray cha = (CharArray)obj;
/* 141 */       if (this.length == cha.length) {
/* 142 */         int n = this.length;
/* 143 */         int i = this.start;
/* 144 */         int j = cha.start;
/* 145 */         while (n-- != 0) {
/* 146 */           if (this.ch[i++] != cha.ch[j++])
/* 147 */             return false; 
/*     */         } 
/* 149 */         return true;
/*     */       } 
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int length() {
/* 158 */     return this.length;
/*     */   }
/*     */   
/*     */   public final char charAt(int index) {
/* 162 */     return this.ch[this.start + index];
/*     */   }
/*     */   
/*     */   public final CharSequence subSequence(int start, int end) {
/* 166 */     return new CharArray(this.ch, this.start + start, end - start, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\CharArray.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */