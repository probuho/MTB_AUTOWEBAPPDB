/*     */ package com.sun.xml.fastinfoset.sax;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithm;
/*     */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithmFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithm;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ import org.jvnet.fastinfoset.FastInfosetException;
/*     */ import org.jvnet.fastinfoset.sax.EncodingAlgorithmAttributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributesHolder
/*     */   implements EncodingAlgorithmAttributes
/*     */ {
/*     */   private static final int DEFAULT_CAPACITY = 8;
/*     */   private Map _registeredEncodingAlgorithms;
/*     */   private int _attributeCount;
/*  70 */   private QualifiedName[] _names = new QualifiedName[8];
/*  71 */   private String[] _values = new String[8];
/*     */   
/*  73 */   private String[] _algorithmURIs = new String[8];
/*  74 */   private int[] _algorithmIds = new int[8];
/*  75 */   private Object[] _algorithmData = new Object[8];
/*     */ 
/*     */   
/*     */   public AttributesHolder(Map registeredEncodingAlgorithms) {
/*  79 */     this();
/*  80 */     this._registeredEncodingAlgorithms = registeredEncodingAlgorithms;
/*     */   }
/*     */   
/*     */   public AttributesHolder() {}
/*     */   
/*     */   public final int getLength() {
/*  86 */     return this._attributeCount;
/*     */   }
/*     */   
/*     */   public final String getLocalName(int index) {
/*  90 */     return (this._names[index]).localName;
/*     */   }
/*     */   
/*     */   public final String getQName(int index) {
/*  94 */     return this._names[index].getQNameString();
/*     */   }
/*     */   
/*     */   public final String getType(int index) {
/*  98 */     return "CDATA";
/*     */   }
/*     */   
/*     */   public final String getURI(int index) {
/* 102 */     return (this._names[index]).namespaceName;
/*     */   }
/*     */   
/*     */   public final String getValue(int index) {
/* 106 */     String value = this._values[index];
/* 107 */     if (value != null) {
/* 108 */       return value;
/*     */     }
/*     */     
/* 111 */     if (this._algorithmData[index] == null || this._registeredEncodingAlgorithms == null) {
/* 112 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 116 */       this._values[index] = convertEncodingAlgorithmDataToString(this._algorithmIds[index], this._algorithmURIs[index], this._algorithmData[index]).toString(); return convertEncodingAlgorithmDataToString(this._algorithmIds[index], this._algorithmURIs[index], this._algorithmData[index]).toString();
/*     */ 
/*     */     
/*     */     }
/* 120 */     catch (IOException e) {
/* 121 */       return null;
/* 122 */     } catch (FastInfosetException e) {
/* 123 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int getIndex(String qName) {
/* 128 */     int i = qName.indexOf(':');
/* 129 */     String prefix = "";
/* 130 */     String localName = qName;
/* 131 */     if (i >= 0) {
/* 132 */       prefix = qName.substring(0, i);
/* 133 */       localName = qName.substring(i + 1);
/*     */     } 
/*     */     
/* 136 */     for (i = 0; i < this._attributeCount; i++) {
/* 137 */       QualifiedName name = this._names[i];
/* 138 */       if (localName.equals(name.localName) && prefix.equals(name.prefix))
/*     */       {
/* 140 */         return i;
/*     */       }
/*     */     } 
/* 143 */     return -1;
/*     */   }
/*     */   
/*     */   public final String getType(String qName) {
/* 147 */     int index = getIndex(qName);
/* 148 */     if (index >= 0) {
/* 149 */       return "CDATA";
/*     */     }
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getValue(String qName) {
/* 156 */     int index = getIndex(qName);
/* 157 */     if (index >= 0) {
/* 158 */       return this._values[index];
/*     */     }
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getIndex(String uri, String localName) {
/* 165 */     for (int i = 0; i < this._attributeCount; i++) {
/* 166 */       QualifiedName name = this._names[i];
/* 167 */       if (localName.equals(name.localName) && uri.equals(name.namespaceName))
/*     */       {
/* 169 */         return i;
/*     */       }
/*     */     } 
/* 172 */     return -1;
/*     */   }
/*     */   
/*     */   public final String getType(String uri, String localName) {
/* 176 */     int index = getIndex(uri, localName);
/* 177 */     if (index >= 0) {
/* 178 */       return "CDATA";
/*     */     }
/* 180 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getValue(String uri, String localName) {
/* 185 */     int index = getIndex(uri, localName);
/* 186 */     if (index >= 0) {
/* 187 */       return this._values[index];
/*     */     }
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void clear() {
/* 194 */     for (int i = 0; i < this._attributeCount; i++) {
/* 195 */       this._values[i] = null;
/* 196 */       this._algorithmData[i] = null;
/*     */     } 
/* 198 */     this._attributeCount = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getAlgorithmURI(int index) {
/* 204 */     return this._algorithmURIs[index];
/*     */   }
/*     */   
/*     */   public final int getAlgorithmIndex(int index) {
/* 208 */     return this._algorithmIds[index];
/*     */   }
/*     */   
/*     */   public final Object getAlgorithmData(int index) {
/* 212 */     return this._algorithmData[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addAttribute(QualifiedName name, String value) {
/* 219 */     if (this._attributeCount == this._names.length) {
/* 220 */       resize();
/*     */     }
/* 222 */     this._names[this._attributeCount] = name;
/* 223 */     this._values[this._attributeCount++] = value;
/*     */   }
/*     */   
/*     */   public final void addAttributeWithAlgorithmData(QualifiedName name, String URI, int id, Object data) {
/* 227 */     if (this._attributeCount == this._names.length) {
/* 228 */       resize();
/*     */     }
/* 230 */     this._names[this._attributeCount] = name;
/* 231 */     this._values[this._attributeCount] = null;
/*     */     
/* 233 */     this._algorithmURIs[this._attributeCount] = URI;
/* 234 */     this._algorithmIds[this._attributeCount] = id;
/* 235 */     this._algorithmData[this._attributeCount++] = data;
/*     */   }
/*     */   
/*     */   public final QualifiedName getQualifiedName(int index) {
/* 239 */     return this._names[index];
/*     */   }
/*     */   
/*     */   public final String getPrefix(int index) {
/* 243 */     return (this._names[index]).prefix;
/*     */   }
/*     */   
/*     */   private final void resize() {
/* 247 */     int newLength = this._attributeCount * 3 / 2 + 1;
/*     */     
/* 249 */     QualifiedName[] names = new QualifiedName[newLength];
/* 250 */     String[] values = new String[newLength];
/*     */     
/* 252 */     String[] algorithmURIs = new String[newLength];
/* 253 */     int[] algorithmIds = new int[newLength];
/* 254 */     Object[] algorithmData = new Object[newLength];
/*     */     
/* 256 */     System.arraycopy(this._names, 0, names, 0, this._attributeCount);
/* 257 */     System.arraycopy(this._values, 0, values, 0, this._attributeCount);
/*     */     
/* 259 */     System.arraycopy(this._algorithmURIs, 0, algorithmURIs, 0, this._attributeCount);
/* 260 */     System.arraycopy(this._algorithmIds, 0, algorithmIds, 0, this._attributeCount);
/* 261 */     System.arraycopy(this._algorithmData, 0, algorithmData, 0, this._attributeCount);
/*     */     
/* 263 */     this._names = names;
/* 264 */     this._values = values;
/*     */     
/* 266 */     this._algorithmURIs = algorithmURIs;
/* 267 */     this._algorithmIds = algorithmIds;
/* 268 */     this._algorithmData = algorithmData;
/*     */   }
/*     */   
/*     */   private final StringBuffer convertEncodingAlgorithmDataToString(int identifier, String URI, Object data) throws FastInfosetException, IOException {
/* 272 */     EncodingAlgorithm ea = null;
/* 273 */     if (identifier < 9)
/* 274 */     { BuiltInEncodingAlgorithm builtInEncodingAlgorithm = BuiltInEncodingAlgorithmFactory.table[identifier]; }
/* 275 */     else { if (identifier == 9)
/* 276 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.CDATAAlgorithmNotSupported")); 
/* 277 */       if (identifier >= 32) {
/* 278 */         if (URI == null) {
/* 279 */           throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.URINotPresent") + identifier);
/*     */         }
/*     */         
/* 282 */         ea = (EncodingAlgorithm)this._registeredEncodingAlgorithms.get(URI);
/* 283 */         if (ea == null) {
/* 284 */           throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.algorithmNotRegistered") + URI);
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 290 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.identifiers10to31Reserved"));
/*     */       }  }
/*     */     
/* 293 */     StringBuffer sb = new StringBuffer();
/* 294 */     ea.convertToCharacters(data, sb);
/* 295 */     return sb;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sax\AttributesHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */