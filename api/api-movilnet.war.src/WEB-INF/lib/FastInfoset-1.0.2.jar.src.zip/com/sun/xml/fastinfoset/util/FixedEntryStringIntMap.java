/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedEntryStringIntMap
/*     */   extends StringIntMap
/*     */ {
/*     */   private StringIntMap.Entry _fixedEntry;
/*     */   
/*     */   public FixedEntryStringIntMap(String fixedEntry, int initialCapacity, float loadFactor) {
/*  49 */     super(initialCapacity, loadFactor);
/*     */ 
/*     */     
/*  52 */     int hash = hashHash(fixedEntry.hashCode());
/*  53 */     int tableIndex = indexFor(hash, this._table.length);
/*  54 */     this._table[tableIndex] = this._fixedEntry = new StringIntMap.Entry(fixedEntry, hash, 0, null);
/*  55 */     if (this._size++ >= this._threshold) {
/*  56 */       resize(2 * this._table.length);
/*     */     }
/*     */   }
/*     */   
/*     */   public FixedEntryStringIntMap(String fixedEntry, int initialCapacity) {
/*  61 */     this(fixedEntry, initialCapacity, 0.75F);
/*     */   }
/*     */   
/*     */   public FixedEntryStringIntMap(String fixedEntry) {
/*  65 */     this(fixedEntry, 16, 0.75F);
/*     */   }
/*     */   
/*     */   public final void clear() {
/*  69 */     for (int i = 0; i < this._table.length; i++) {
/*  70 */       this._table[i] = null;
/*     */     }
/*  72 */     if (this._fixedEntry != null) {
/*  73 */       int tableIndex = indexFor(this._fixedEntry._hash, this._table.length);
/*  74 */       this._table[tableIndex] = this._fixedEntry;
/*  75 */       this._fixedEntry._next = null;
/*  76 */       this._size = 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void setReadOnlyMap(KeyIntMap readOnlyMap, boolean clear) {
/*  81 */     if (!(readOnlyMap instanceof FixedEntryStringIntMap)) {
/*  82 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyMap }));
/*     */     }
/*     */ 
/*     */     
/*  86 */     setReadOnlyMap((FixedEntryStringIntMap)readOnlyMap, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyMap(FixedEntryStringIntMap readOnlyMap, boolean clear) {
/*  90 */     this._readOnlyMap = readOnlyMap;
/*  91 */     if (this._readOnlyMap != null) {
/*  92 */       readOnlyMap.removeFixedEntry();
/*  93 */       this._readOnlyMapSize = readOnlyMap.size();
/*  94 */       if (clear) {
/*  95 */         clear();
/*     */       }
/*     */     } else {
/*  98 */       this._readOnlyMapSize = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void removeFixedEntry() {
/* 103 */     if (this._fixedEntry != null) {
/* 104 */       int tableIndex = indexFor(this._fixedEntry._hash, this._table.length);
/* 105 */       StringIntMap.Entry firstEntry = this._table[tableIndex];
/* 106 */       if (firstEntry == this._fixedEntry) {
/* 107 */         this._table[tableIndex] = this._fixedEntry._next;
/*     */       } else {
/* 109 */         StringIntMap.Entry previousEntry = firstEntry;
/* 110 */         while (previousEntry._next != this._fixedEntry) {
/* 111 */           previousEntry = previousEntry._next;
/*     */         }
/* 113 */         previousEntry._next = this._fixedEntry._next;
/*     */       } 
/*     */       
/* 116 */       this._fixedEntry = null;
/* 117 */       this._size--;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\FixedEntryStringIntMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */