/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StartElementEvent
/*     */   extends EventBase
/*     */   implements StartElement
/*     */ {
/*     */   private Map _attributes;
/*     */   private List _namespaces;
/*  62 */   private NamespaceContext _context = null;
/*     */   private QName _qname;
/*     */   
/*     */   public void reset() {
/*  66 */     if (this._attributes != null) this._attributes.clear(); 
/*  67 */     if (this._namespaces != null) this._namespaces.clear(); 
/*  68 */     if (this._context != null) this._context = null; 
/*     */   }
/*     */   
/*     */   public StartElementEvent() {
/*  72 */     init();
/*     */   }
/*     */   
/*     */   public StartElementEvent(String prefix, String uri, String localpart) {
/*  76 */     init();
/*  77 */     if (uri == null) uri = ""; 
/*  78 */     if (prefix == null) prefix = ""; 
/*  79 */     this._qname = new QName(uri, localpart, prefix);
/*  80 */     setEventType(1);
/*     */   }
/*     */   
/*     */   public StartElementEvent(QName qname) {
/*  84 */     init();
/*  85 */     this._qname = qname;
/*     */   }
/*     */   
/*     */   public StartElementEvent(StartElement startelement) {
/*  89 */     this(startelement.getName());
/*  90 */     addAttributes(startelement.getAttributes());
/*  91 */     addNamespaces(startelement.getNamespaces());
/*     */   }
/*     */   
/*     */   protected void init() {
/*  95 */     setEventType(1);
/*  96 */     this._attributes = new HashMap();
/*  97 */     this._namespaces = new ArrayList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getName() {
/* 106 */     return this._qname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getAttributes() {
/* 119 */     if (this._attributes != null) {
/* 120 */       Collection coll = this._attributes.values();
/* 121 */       return new ReadIterator(coll.iterator());
/*     */     } 
/* 123 */     return EmptyIterator.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getNamespaces() {
/* 148 */     if (this._namespaces != null) {
/* 149 */       return new ReadIterator(this._namespaces.iterator());
/*     */     }
/* 151 */     return EmptyIterator.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute getAttributeByName(QName qname) {
/* 160 */     if (qname == null)
/* 161 */       return null; 
/* 162 */     return (Attribute)this._attributes.get(qname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 173 */     return this._context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(QName qname) {
/* 178 */     this._qname = qname;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/* 183 */     return this._qname.getNamespaceURI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 195 */     if (getNamespace() != null) return getNamespace();
/*     */     
/* 197 */     if (this._context != null)
/* 198 */       return this._context.getNamespaceURI(prefix); 
/* 199 */     return null;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 203 */     String s = "<" + nameAsString();
/*     */     
/* 205 */     if (this._attributes != null) {
/* 206 */       Iterator it = getAttributes();
/* 207 */       Attribute attr = null;
/* 208 */       while (it.hasNext()) {
/* 209 */         attr = it.next();
/* 210 */         s = s + " " + attr.toString();
/*     */       } 
/*     */     } 
/*     */     
/* 214 */     if (this._namespaces != null) {
/* 215 */       Iterator it = this._namespaces.iterator();
/* 216 */       Namespace attr = null;
/* 217 */       while (it.hasNext()) {
/* 218 */         attr = it.next();
/* 219 */         s = s + " " + attr.toString();
/*     */       } 
/*     */     } 
/* 222 */     s = s + ">";
/* 223 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nameAsString() {
/* 230 */     if ("".equals(this._qname.getNamespaceURI()))
/* 231 */       return this._qname.getLocalPart(); 
/* 232 */     if (this._qname.getPrefix() != null) {
/* 233 */       return "['" + this._qname.getNamespaceURI() + "']:" + this._qname.getPrefix() + ":" + this._qname.getLocalPart();
/*     */     }
/* 235 */     return "['" + this._qname.getNamespaceURI() + "']:" + this._qname.getLocalPart();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext context) {
/* 240 */     this._context = context;
/*     */   }
/*     */   
/*     */   public void addAttribute(Attribute attr) {
/* 244 */     this._attributes.put(attr.getName(), attr);
/*     */   }
/*     */   
/*     */   public void addAttributes(Iterator attrs) {
/* 248 */     if (attrs != null) {
/* 249 */       while (attrs.hasNext()) {
/* 250 */         Attribute attr = attrs.next();
/* 251 */         this._attributes.put(attr.getName(), attr);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void addNamespace(Namespace namespace) {
/* 257 */     if (namespace != null) {
/* 258 */       this._namespaces.add(namespace);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addNamespaces(Iterator namespaces) {
/* 263 */     if (namespaces != null)
/* 264 */       while (namespaces.hasNext()) {
/* 265 */         Namespace namespace = namespaces.next();
/* 266 */         this._namespaces.add(namespace);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\StartElementEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */