package com.sun.xml.fastinfoset.stax.events;

public class XMLConstants {
  public static final String ENCODING = "UTF-8";
  
  public static final String XMLVERSION = "1.0";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\XMLConstants.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */