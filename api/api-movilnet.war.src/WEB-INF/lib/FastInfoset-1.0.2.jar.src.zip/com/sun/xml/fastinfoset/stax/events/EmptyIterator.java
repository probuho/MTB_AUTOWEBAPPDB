/*    */ package com.sun.xml.fastinfoset.stax.events;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyIterator
/*    */   implements Iterator
/*    */ {
/* 45 */   public static final EmptyIterator instance = new EmptyIterator();
/*    */ 
/*    */ 
/*    */   
/*    */   public static EmptyIterator getInstance() {
/* 50 */     return instance;
/*    */   }
/*    */   public boolean hasNext() {
/* 53 */     return false;
/*    */   }
/*    */   public Object next() {
/* 56 */     return null;
/*    */   }
/*    */   public void remove() {
/* 59 */     throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.emptyIterator"));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\EmptyIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */