/*     */ package com.sun.xml.fastinfoset.stax.factory;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.stax.StAXDocumentSerializer;
/*     */ import com.sun.xml.fastinfoset.stax.StAXManager;
/*     */ import com.sun.xml.fastinfoset.stax.events.StAXEventWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXOutputFactory
/*     */   extends XMLOutputFactory
/*     */ {
/*  60 */   private StAXManager _manager = null;
/*     */ 
/*     */   
/*     */   public StAXOutputFactory() {
/*  64 */     this._manager = new StAXManager(2);
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(Result result) throws XMLStreamException {
/*  68 */     return (XMLEventWriter)new StAXEventWriter(createXMLStreamWriter(result));
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(Writer writer) throws XMLStreamException {
/*  72 */     return (XMLEventWriter)new StAXEventWriter(createXMLStreamWriter(writer));
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(OutputStream outputStream) throws XMLStreamException {
/*  76 */     return (XMLEventWriter)new StAXEventWriter(createXMLStreamWriter(outputStream));
/*     */   }
/*     */   
/*     */   public XMLEventWriter createXMLEventWriter(OutputStream outputStream, String encoding) throws XMLStreamException {
/*  80 */     return (XMLEventWriter)new StAXEventWriter(createXMLStreamWriter(outputStream, encoding));
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(Result result) throws XMLStreamException {
/*  84 */     if (result instanceof StreamResult) {
/*  85 */       StreamResult streamResult = (StreamResult)result;
/*  86 */       if (streamResult.getWriter() != null)
/*  87 */         return createXMLStreamWriter(streamResult.getWriter()); 
/*  88 */       if (streamResult.getOutputStream() != null)
/*  89 */         return createXMLStreamWriter(streamResult.getOutputStream()); 
/*  90 */       if (streamResult.getSystemId() != null) {
/*     */         try {
/*  92 */           FileWriter writer = new FileWriter(new File(streamResult.getSystemId()));
/*  93 */           return createXMLStreamWriter(writer);
/*  94 */         } catch (IOException ie) {
/*  95 */           throw new XMLStreamException(ie);
/*     */         }
/*     */       
/*     */       }
/*  99 */     } else if (result instanceof Result) {
/*     */       
/*     */       try {
/* 102 */         FileWriter writer = new FileWriter(new File(result.getSystemId()));
/* 103 */         return createXMLStreamWriter(writer);
/* 104 */       } catch (IOException ie) {
/* 105 */         throw new XMLStreamException(ie);
/*     */       } 
/*     */     } 
/* 108 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(Writer writer) throws XMLStreamException {
/* 115 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(OutputStream outputStream) throws XMLStreamException {
/* 119 */     return (XMLStreamWriter)new StAXDocumentSerializer(outputStream, new StAXManager(this._manager));
/*     */   }
/*     */   
/*     */   public XMLStreamWriter createXMLStreamWriter(OutputStream outputStream, String encoding) throws XMLStreamException {
/* 123 */     StAXDocumentSerializer serializer = new StAXDocumentSerializer(outputStream, new StAXManager(this._manager));
/* 124 */     serializer.setEncoding(encoding);
/* 125 */     return (XMLStreamWriter)serializer;
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) throws IllegalArgumentException {
/* 129 */     if (name == null) {
/* 130 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.propertyNotSupported", new Object[] { name }));
/*     */     }
/* 132 */     if (this._manager.containsProperty(name))
/* 133 */       return this._manager.getProperty(name); 
/* 134 */     throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.propertyNotSupported", new Object[] { name }));
/*     */   }
/*     */   
/*     */   public boolean isPropertySupported(String name) {
/* 138 */     if (name == null) {
/* 139 */       return false;
/*     */     }
/* 141 */     return this._manager.containsProperty(name);
/*     */   }
/*     */   
/*     */   public void setProperty(String name, Object value) throws IllegalArgumentException {
/* 145 */     this._manager.setProperty(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\factory\StAXOutputFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */