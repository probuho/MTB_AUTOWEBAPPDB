/*     */ package com.sun.xml.fastinfoset.vocab;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.util.CharArrayArray;
/*     */ import com.sun.xml.fastinfoset.util.ContiguousCharArrayArray;
/*     */ import com.sun.xml.fastinfoset.util.PrefixArray;
/*     */ import com.sun.xml.fastinfoset.util.QualifiedNameArray;
/*     */ import com.sun.xml.fastinfoset.util.StringArray;
/*     */ import com.sun.xml.fastinfoset.util.ValueArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserVocabulary
/*     */   extends Vocabulary
/*     */ {
/*     */   public static final String IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS_PEOPERTY = "com.sun.xml.fastinfoset.vocab.ParserVocabulary.IdentifyingStringTable.maximumItems";
/*     */   public static final String NON_IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS_PEOPERTY = "com.sun.xml.fastinfoset.vocab.ParserVocabulary.NonIdentifyingStringTable.maximumItems";
/*     */   public static final String NON_IDENTIFYING_STRING_TABLE_MAXIMUM_CHARACTERS_PEOPERTY = "com.sun.xml.fastinfoset.vocab.ParserVocabulary.NonIdentifyingStringTable.maximumCharacters";
/*  62 */   protected static int IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS = getIntegerValueFromProperty("com.sun.xml.fastinfoset.vocab.ParserVocabulary.IdentifyingStringTable.maximumItems");
/*     */   
/*  64 */   protected static int NON_IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS = getIntegerValueFromProperty("com.sun.xml.fastinfoset.vocab.ParserVocabulary.NonIdentifyingStringTable.maximumItems");
/*     */   
/*  66 */   protected static int NON_IDENTIFYING_STRING_TABLE_MAXIMUM_CHARACTERS = getIntegerValueFromProperty("com.sun.xml.fastinfoset.vocab.ParserVocabulary.NonIdentifyingStringTable.maximumCharacters");
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getIntegerValueFromProperty(String property) {
/*  71 */     String value = System.getProperty(property);
/*  72 */     if (value == null) {
/*  73 */       return Integer.MAX_VALUE;
/*     */     }
/*     */     
/*     */     try {
/*  77 */       return Math.max(Integer.parseInt(value), 10);
/*  78 */     } catch (NumberFormatException e) {
/*  79 */       return Integer.MAX_VALUE;
/*     */     } 
/*     */   }
/*     */   
/*  83 */   public final CharArrayArray restrictedAlphabet = new CharArrayArray(10, 256);
/*  84 */   public final StringArray encodingAlgorithm = new StringArray(10, 256);
/*     */   
/*     */   public final StringArray namespaceName;
/*     */   
/*     */   public final PrefixArray prefix;
/*     */   
/*     */   public final StringArray localName;
/*     */   
/*     */   public final StringArray otherNCName;
/*     */   public final StringArray otherURI;
/*     */   public final StringArray attributeValue;
/*     */   public final CharArrayArray otherString;
/*     */   public final ContiguousCharArrayArray characterContentChunk;
/*     */   public final QualifiedNameArray elementName;
/*     */   public final QualifiedNameArray attributeName;
/*  99 */   public final ValueArray[] tables = new ValueArray[12];
/*     */   
/*     */   protected SerializerVocabulary _readOnlyVocabulary;
/*     */ 
/*     */   
/*     */   public ParserVocabulary() {
/* 105 */     this.namespaceName = new StringArray(10, IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/* 106 */     this.prefix = new PrefixArray(10, IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/* 107 */     this.localName = new StringArray(10, IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/* 108 */     this.otherNCName = new StringArray(10, IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/* 109 */     this.otherURI = new StringArray(10, IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/* 110 */     this.attributeValue = new StringArray(10, NON_IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/* 111 */     this.otherString = new CharArrayArray(10, NON_IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/*     */     
/* 113 */     this.characterContentChunk = new ContiguousCharArrayArray(10, NON_IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS, 512, NON_IDENTIFYING_STRING_TABLE_MAXIMUM_CHARACTERS);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.elementName = new QualifiedNameArray(10, IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/* 119 */     this.attributeName = new QualifiedNameArray(10, IDENTIFYING_STRING_TABLE_MAXIMUM_ITEMS);
/*     */     
/* 121 */     this.tables[0] = (ValueArray)this.restrictedAlphabet;
/* 122 */     this.tables[1] = (ValueArray)this.encodingAlgorithm;
/* 123 */     this.tables[2] = (ValueArray)this.prefix;
/* 124 */     this.tables[3] = (ValueArray)this.namespaceName;
/* 125 */     this.tables[4] = (ValueArray)this.localName;
/* 126 */     this.tables[5] = (ValueArray)this.otherNCName;
/* 127 */     this.tables[6] = (ValueArray)this.otherURI;
/* 128 */     this.tables[7] = (ValueArray)this.attributeValue;
/* 129 */     this.tables[8] = (ValueArray)this.otherString;
/* 130 */     this.tables[9] = (ValueArray)this.characterContentChunk;
/* 131 */     this.tables[10] = (ValueArray)this.elementName;
/* 132 */     this.tables[11] = (ValueArray)this.attributeName;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParserVocabulary(SerializerVocabulary vocab) {
/* 137 */     this();
/*     */   }
/*     */ 
/*     */   
/*     */   void setReadOnlyVocabulary(ParserVocabulary readOnlyVocabulary, boolean clear) {
/* 142 */     for (int i = 0; i < this.tables.length; i++) {
/* 143 */       this.tables[i].setReadOnlyArray(readOnlyVocabulary.tables[i], clear);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setInitialVocabulary(ParserVocabulary initialVocabulary, boolean clear) {
/* 148 */     setExternalVocabularyURI(null);
/* 149 */     setInitialReadOnlyVocabulary(true);
/* 150 */     setReadOnlyVocabulary(initialVocabulary, clear);
/*     */   }
/*     */   
/*     */   public void setReferencedVocabulary(String referencedVocabularyURI, ParserVocabulary referencedVocabulary, boolean clear) {
/* 154 */     if (!referencedVocabularyURI.equals(getExternalVocabularyURI())) {
/* 155 */       setInitialReadOnlyVocabulary(false);
/* 156 */       setExternalVocabularyURI(referencedVocabularyURI);
/* 157 */       setReadOnlyVocabulary(referencedVocabulary, clear);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/* 162 */     for (int i = 0; i < this.tables.length; i++)
/* 163 */       this.tables[i].clear(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\vocab\ParserVocabulary.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */