/*     */ package com.sun.xml.fastinfoset.stax;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.Encoder;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.xml.sax.helpers.NamespaceSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXDocumentSerializer
/*     */   extends Encoder
/*     */   implements XMLStreamWriter
/*     */ {
/*     */   protected StAXManager _manager;
/*     */   protected String _encoding;
/*     */   protected String _currentLocalName;
/*     */   protected String _currentUri;
/*     */   protected String _currentPrefix;
/*     */   protected boolean _inStartElement = false;
/*     */   protected boolean _isEmptyElement = false;
/*  88 */   protected String[] _attributesArray = new String[64];
/*  89 */   protected int _attributesArrayIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   protected NamespaceSupport _nsSupport = new NamespaceSupport();
/*     */   
/*  96 */   protected boolean[] _nsSupportContextStack = new boolean[32];
/*  97 */   protected int _stackCount = -1;
/*     */   
/*  99 */   protected NamespaceContext _nsContext = new NamespaceContextImpl();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   protected String[] _namespacesArray = new String[16];
/* 105 */   protected int _namespacesArrayIndex = 0;
/*     */ 
/*     */   
/*     */   public StAXDocumentSerializer() {}
/*     */   
/*     */   public StAXDocumentSerializer(OutputStream outputStream) {
/* 111 */     setOutputStream(outputStream);
/*     */   }
/*     */   
/*     */   public StAXDocumentSerializer(OutputStream outputStream, StAXManager manager) {
/* 115 */     setOutputStream(outputStream);
/* 116 */     this._manager = manager;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 120 */     super.reset();
/*     */     
/* 122 */     this._attributesArrayIndex = 0;
/* 123 */     this._namespacesArrayIndex = 0;
/* 124 */     this._nsSupport.reset();
/* 125 */     this._stackCount = -1;
/*     */     
/* 127 */     this._currentUri = this._currentPrefix = null;
/* 128 */     this._currentLocalName = null;
/*     */     
/* 130 */     this._inStartElement = this._isEmptyElement = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartDocument() throws XMLStreamException {
/* 136 */     writeStartDocument("finf", "1.0");
/*     */   }
/*     */   
/*     */   public void writeStartDocument(String version) throws XMLStreamException {
/* 140 */     writeStartDocument("finf", version);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartDocument(String encoding, String version) throws XMLStreamException {
/* 146 */     reset();
/*     */     
/*     */     try {
/* 149 */       encodeHeader(false);
/* 150 */       encodeInitialVocabulary();
/* 151 */     } catch (IOException e) {
/* 152 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEndDocument() throws XMLStreamException {
/* 158 */     if (this._inStartElement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 168 */       encodeDocumentTermination();
/*     */     }
/* 170 */     catch (IOException e) {
/* 171 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws XMLStreamException {
/* 176 */     reset();
/*     */   }
/*     */   
/*     */   public void flush() throws XMLStreamException {
/*     */     try {
/* 181 */       this._s.flush();
/*     */     }
/* 183 */     catch (IOException e) {
/* 184 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartElement(String localName) throws XMLStreamException {
/* 192 */     writeStartElement("", localName, "");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartElement(String namespaceURI, String localName) throws XMLStreamException {
/* 198 */     writeStartElement(getPrefix(namespaceURI), localName, namespaceURI);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
/* 204 */     encodeTerminationAndCurrentElement(false);
/*     */     
/* 206 */     this._inStartElement = true;
/* 207 */     this._isEmptyElement = false;
/*     */     
/* 209 */     this._currentLocalName = localName;
/* 210 */     this._currentPrefix = prefix;
/* 211 */     this._currentUri = namespaceURI;
/*     */     
/* 213 */     this._stackCount++;
/* 214 */     if (this._stackCount == this._nsSupportContextStack.length) {
/* 215 */       boolean[] nsSupportContextStack = new boolean[this._stackCount * 2];
/* 216 */       System.arraycopy(this._nsSupportContextStack, 0, nsSupportContextStack, 0, this._nsSupportContextStack.length);
/* 217 */       this._nsSupportContextStack = nsSupportContextStack;
/*     */     } 
/*     */     
/* 220 */     this._nsSupportContextStack[this._stackCount] = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String localName) throws XMLStreamException {
/* 227 */     writeEmptyElement("", localName, "");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String namespaceURI, String localName) throws XMLStreamException {
/* 233 */     writeEmptyElement(getPrefix(namespaceURI), localName, namespaceURI);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
/* 239 */     encodeTerminationAndCurrentElement(false);
/*     */     
/* 241 */     this._isEmptyElement = this._inStartElement = true;
/*     */     
/* 243 */     this._currentLocalName = localName;
/* 244 */     this._currentPrefix = prefix;
/* 245 */     this._currentUri = namespaceURI;
/*     */     
/* 247 */     this._stackCount++;
/* 248 */     if (this._stackCount == this._nsSupportContextStack.length) {
/* 249 */       boolean[] nsSupportContextStack = new boolean[this._stackCount * 2];
/* 250 */       System.arraycopy(this._nsSupportContextStack, 0, nsSupportContextStack, 0, this._nsSupportContextStack.length);
/* 251 */       this._nsSupportContextStack = nsSupportContextStack;
/*     */     } 
/*     */     
/* 254 */     this._nsSupportContextStack[this._stackCount] = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEndElement() throws XMLStreamException {
/* 259 */     if (this._inStartElement) {
/* 260 */       encodeTerminationAndCurrentElement(false);
/*     */     }
/*     */     
/*     */     try {
/* 264 */       encodeElementTermination();
/* 265 */       if (this._nsSupportContextStack[this._stackCount--] == true) {
/* 266 */         this._nsSupport.popContext();
/*     */       }
/*     */     }
/* 269 */     catch (IOException e) {
/* 270 */       throw new XMLStreamException(e);
/*     */     }
/* 272 */     catch (EmptyStackException e) {
/* 273 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAttribute(String localName, String value) throws XMLStreamException {
/* 281 */     writeAttribute("", "", localName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAttribute(String namespaceURI, String localName, String value) throws XMLStreamException {
/* 287 */     String prefix = "";
/*     */ 
/*     */     
/* 290 */     if (namespaceURI.length() > 0) {
/* 291 */       prefix = this._nsSupport.getPrefix(namespaceURI);
/*     */ 
/*     */       
/* 294 */       if (prefix == null || prefix.length() == 0) {
/*     */ 
/*     */         
/* 297 */         if (namespaceURI == "http://www.w3.org/2000/xmlns/" || namespaceURI.equals("http://www.w3.org/2000/xmlns/")) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 306 */         throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.URIUnbound", new Object[] { namespaceURI }));
/*     */       } 
/*     */     } 
/* 309 */     writeAttribute(prefix, namespaceURI, localName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAttribute(String prefix, String namespaceURI, String localName, String value) throws XMLStreamException {
/* 315 */     if (!this._inStartElement) {
/* 316 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.attributeWritingNotAllowed"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     if (namespaceURI == "http://www.w3.org/2000/xmlns/" || namespaceURI.equals("http://www.w3.org/2000/xmlns/")) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 329 */     if (this._attributesArrayIndex == this._attributesArray.length) {
/* 330 */       String[] attributesArray = new String[this._attributesArrayIndex * 2];
/* 331 */       System.arraycopy(this._attributesArray, 0, attributesArray, 0, this._attributesArrayIndex);
/* 332 */       this._attributesArray = attributesArray;
/*     */     } 
/*     */     
/* 335 */     this._attributesArray[this._attributesArrayIndex++] = namespaceURI;
/* 336 */     this._attributesArray[this._attributesArrayIndex++] = prefix;
/* 337 */     this._attributesArray[this._attributesArrayIndex++] = localName;
/* 338 */     this._attributesArray[this._attributesArrayIndex++] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeNamespace(String prefix, String namespaceURI) throws XMLStreamException {
/* 344 */     if (prefix == null || prefix.length() == 0 || prefix.equals("xmlns")) {
/* 345 */       writeDefaultNamespace(namespaceURI);
/*     */     } else {
/*     */       
/* 348 */       if (!this._inStartElement) {
/* 349 */         throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.attributeWritingNotAllowed"));
/*     */       }
/*     */       
/* 352 */       if (this._namespacesArrayIndex == this._namespacesArray.length) {
/* 353 */         String[] namespacesArray = new String[this._namespacesArrayIndex * 2];
/* 354 */         System.arraycopy(this._namespacesArray, 0, namespacesArray, 0, this._namespacesArrayIndex);
/* 355 */         this._namespacesArray = namespacesArray;
/*     */       } 
/*     */       
/* 358 */       this._namespacesArray[this._namespacesArrayIndex++] = prefix;
/* 359 */       this._namespacesArray[this._namespacesArrayIndex++] = namespaceURI;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDefaultNamespace(String namespaceURI) throws XMLStreamException {
/* 366 */     if (!this._inStartElement) {
/* 367 */       throw new IllegalStateException(CommonResourceBundle.getInstance().getString("message.attributeWritingNotAllowed"));
/*     */     }
/*     */     
/* 370 */     if (this._namespacesArrayIndex == this._namespacesArray.length) {
/* 371 */       String[] namespacesArray = new String[this._namespacesArrayIndex * 2];
/* 372 */       System.arraycopy(this._namespacesArray, 0, namespacesArray, 0, this._namespacesArrayIndex);
/* 373 */       this._namespacesArray = namespacesArray;
/*     */     } 
/*     */     
/* 376 */     this._namespacesArray[this._namespacesArrayIndex++] = "";
/* 377 */     this._namespacesArray[this._namespacesArrayIndex++] = namespaceURI;
/*     */   }
/*     */   
/*     */   public void writeComment(String data) throws XMLStreamException {
/*     */     try {
/* 382 */       encodeTerminationAndCurrentElement(true);
/*     */ 
/*     */       
/* 385 */       encodeComment(data.toCharArray(), 0, data.length());
/*     */     }
/* 387 */     catch (IOException e) {
/* 388 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeProcessingInstruction(String target) throws XMLStreamException {
/* 395 */     writeProcessingInstruction(target, "");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeProcessingInstruction(String target, String data) throws XMLStreamException {
/*     */     try {
/* 402 */       encodeTerminationAndCurrentElement(true);
/*     */       
/* 404 */       encodeProcessingInstruction(target, data);
/*     */     }
/* 406 */     catch (IOException e) {
/* 407 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeCData(String data) throws XMLStreamException {
/* 412 */     throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.notImplemented"));
/*     */   }
/*     */   
/*     */   public void writeDTD(String dtd) throws XMLStreamException {
/* 416 */     throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.notImplemented"));
/*     */   }
/*     */   
/*     */   public void writeEntityRef(String name) throws XMLStreamException {
/* 420 */     throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.notImplemented"));
/*     */   }
/*     */   
/*     */   public void writeCharacters(String text) throws XMLStreamException {
/*     */     try {
/* 425 */       int length = text.length();
/* 426 */       if (length == 0)
/*     */         return; 
/* 428 */       if (length < this._charBuffer.length) {
/* 429 */         encodeTerminationAndCurrentElement(true);
/*     */         
/* 431 */         text.getChars(0, length, this._charBuffer, 0);
/* 432 */         encodeCharacters(this._charBuffer, 0, length);
/*     */       } else {
/* 434 */         encodeTerminationAndCurrentElement(true);
/*     */         
/* 436 */         char[] ch = text.toCharArray();
/* 437 */         encodeCharactersNoClone(ch, 0, length);
/*     */       }
/*     */     
/* 440 */     } catch (IOException e) {
/* 441 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCharacters(char[] text, int start, int len) throws XMLStreamException {
/*     */     try {
/* 449 */       if (len == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 453 */       encodeTerminationAndCurrentElement(true);
/*     */       
/* 455 */       encodeCharacters(text, start, len);
/*     */     }
/* 457 */     catch (IOException e) {
/* 458 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getPrefix(String uri) throws XMLStreamException {
/* 463 */     return this._nsSupport.getPrefix(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix, String uri) throws XMLStreamException {
/* 469 */     if (this._stackCount > -1 && !this._nsSupportContextStack[this._stackCount]) {
/* 470 */       this._nsSupportContextStack[this._stackCount] = true;
/* 471 */       this._nsSupport.pushContext();
/*     */     } 
/*     */     
/* 474 */     this._nsSupport.declarePrefix(prefix, uri);
/*     */   }
/*     */   
/*     */   public void setDefaultNamespace(String uri) throws XMLStreamException {
/* 478 */     setPrefix("", uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext context) throws XMLStreamException {
/* 498 */     throw new UnsupportedOperationException("setNamespaceContext");
/*     */   }
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 502 */     return this._nsContext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws IllegalArgumentException {
/* 508 */     if (this._manager != null) {
/* 509 */       return this._manager.getProperty(name);
/*     */     }
/* 511 */     return null;
/*     */   }
/*     */   
/*     */   public void setManager(StAXManager manager) {
/* 515 */     this._manager = manager;
/*     */   }
/*     */   
/*     */   public void setEncoding(String encoding) {
/* 519 */     this._encoding = encoding;
/*     */   }
/*     */   protected class NamespaceContextImpl implements NamespaceContext { private final StAXDocumentSerializer this$0;
/*     */     
/*     */     public final String getNamespaceURI(String prefix) {
/* 524 */       return StAXDocumentSerializer.this._nsSupport.getURI(prefix);
/*     */     }
/*     */     
/*     */     public final String getPrefix(String namespaceURI) {
/* 528 */       return StAXDocumentSerializer.this._nsSupport.getPrefix(namespaceURI);
/*     */     }
/*     */     
/*     */     public final Iterator getPrefixes(String namespaceURI) {
/* 532 */       final Enumeration e = StAXDocumentSerializer.this._nsSupport.getPrefixes(namespaceURI);
/*     */       
/* 534 */       return new Iterator() { private final Enumeration val$e;
/*     */           public boolean hasNext() {
/* 536 */             return e.hasMoreElements();
/*     */           }
/*     */           private final StAXDocumentSerializer.NamespaceContextImpl this$1;
/*     */           public Object next() {
/* 540 */             return e.nextElement();
/*     */           }
/*     */           
/*     */           public void remove() {
/* 544 */             throw new UnsupportedOperationException();
/*     */           } }
/*     */         ;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeOctets(byte[] b, int start, int len) throws XMLStreamException {
/*     */     try {
/* 554 */       if (len == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 558 */       encodeTerminationAndCurrentElement(true);
/*     */       
/* 560 */       encodeCIIOctetAlgorithmData(1, b, start, len);
/*     */     }
/* 562 */     catch (IOException e) {
/* 563 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void encodeTerminationAndCurrentElement(boolean terminateAfter) throws XMLStreamException {
/*     */     try {
/* 569 */       encodeTermination();
/*     */       
/* 571 */       if (this._inStartElement) {
/*     */         
/* 573 */         this._b = 0;
/* 574 */         if (this._attributesArrayIndex > 0) {
/* 575 */           this._b |= 0x40;
/*     */         }
/*     */ 
/*     */         
/* 579 */         if (this._namespacesArrayIndex > 0) {
/* 580 */           write(this._b | 0x38);
/* 581 */           for (int j = 0; j < this._namespacesArrayIndex;) {
/* 582 */             encodeNamespaceAttribute(this._namespacesArray[j++], this._namespacesArray[j++]);
/*     */           }
/* 584 */           this._namespacesArrayIndex = 0;
/*     */           
/* 586 */           write(240);
/*     */           
/* 588 */           this._b = 0;
/*     */         } 
/*     */ 
/*     */         
/* 592 */         encodeElementQualifiedNameOnThirdBit(this._currentUri, this._currentPrefix, this._currentLocalName);
/*     */         
/* 594 */         for (int i = 0; i < this._attributesArrayIndex; ) {
/* 595 */           encodeAttributeQualifiedNameOnSecondBit(this._attributesArray[i++], this._attributesArray[i++], this._attributesArray[i++]);
/*     */ 
/*     */           
/* 598 */           String value = this._attributesArray[i];
/* 599 */           this._attributesArray[i++] = null;
/* 600 */           boolean addToTable = (value.length() < this.attributeValueSizeConstraint);
/* 601 */           encodeNonIdentifyingStringOnFirstBit(value, this._v.attributeValue, addToTable);
/*     */           
/* 603 */           this._b = 240;
/* 604 */           this._terminate = true;
/*     */         } 
/* 606 */         this._attributesArrayIndex = 0;
/* 607 */         this._inStartElement = false;
/*     */         
/* 609 */         if (this._isEmptyElement) {
/* 610 */           encodeElementTermination();
/* 611 */           if (this._nsSupportContextStack[this._stackCount--] == true) {
/* 612 */             this._nsSupport.popContext();
/*     */           }
/*     */           
/* 615 */           this._isEmptyElement = false;
/*     */         } 
/*     */         
/* 618 */         if (terminateAfter) {
/* 619 */           encodeTermination();
/*     */         }
/*     */       } 
/* 622 */     } catch (IOException e) {
/* 623 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\StAXDocumentSerializer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */