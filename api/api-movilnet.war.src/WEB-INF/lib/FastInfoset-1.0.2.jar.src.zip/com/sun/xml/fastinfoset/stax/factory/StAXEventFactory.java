/*     */ package com.sun.xml.fastinfoset.stax.factory;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.stax.events.AttributeBase;
/*     */ import com.sun.xml.fastinfoset.stax.events.CharactersEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.CommentEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.DTDEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.EndDocumentEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.EndElementEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.EntityReferenceEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.NamespaceBase;
/*     */ import com.sun.xml.fastinfoset.stax.events.ProcessingInstructionEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.StartDocumentEvent;
/*     */ import com.sun.xml.fastinfoset.stax.events.StartElementEvent;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.Comment;
/*     */ import javax.xml.stream.events.DTD;
/*     */ import javax.xml.stream.events.EndDocument;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.EntityDeclaration;
/*     */ import javax.xml.stream.events.EntityReference;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.ProcessingInstruction;
/*     */ import javax.xml.stream.events.StartDocument;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXEventFactory
/*     */   extends XMLEventFactory
/*     */ {
/*  52 */   Location location = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocation(Location location) {
/*  65 */     this.location = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute createAttribute(String prefix, String namespaceURI, String localName, String value) {
/*  77 */     AttributeBase attr = new AttributeBase(prefix, namespaceURI, localName, value, null);
/*  78 */     if (this.location != null) attr.setLocation(this.location); 
/*  79 */     return (Attribute)attr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute createAttribute(String localName, String value) {
/*  89 */     AttributeBase attr = new AttributeBase(localName, value);
/*  90 */     if (this.location != null) attr.setLocation(this.location); 
/*  91 */     return (Attribute)attr;
/*     */   }
/*     */   
/*     */   public Attribute createAttribute(QName name, String value) {
/*  95 */     AttributeBase attr = new AttributeBase(name, value);
/*  96 */     if (this.location != null) attr.setLocation(this.location); 
/*  97 */     return (Attribute)attr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Namespace createNamespace(String namespaceURI) {
/* 106 */     NamespaceBase event = new NamespaceBase(namespaceURI);
/* 107 */     if (this.location != null) event.setLocation(this.location); 
/* 108 */     return (Namespace)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Namespace createNamespace(String prefix, String namespaceURI) {
/* 118 */     NamespaceBase event = new NamespaceBase(prefix, namespaceURI);
/* 119 */     if (this.location != null) event.setLocation(this.location); 
/* 120 */     return (Namespace)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartElement createStartElement(QName name, Iterator attributes, Iterator namespaces) {
/* 133 */     return createStartElement(name.getPrefix(), name.getNamespaceURI(), name.getLocalPart(), attributes, namespaces);
/*     */   }
/*     */   
/*     */   public StartElement createStartElement(String prefix, String namespaceUri, String localName) {
/* 137 */     StartElementEvent event = new StartElementEvent(prefix, namespaceUri, localName);
/* 138 */     if (this.location != null) event.setLocation(this.location); 
/* 139 */     return (StartElement)event;
/*     */   }
/*     */   
/*     */   public StartElement createStartElement(String prefix, String namespaceUri, String localName, Iterator attributes, Iterator namespaces) {
/* 143 */     return createStartElement(prefix, namespaceUri, localName, attributes, namespaces, null);
/*     */   }
/*     */   
/*     */   public StartElement createStartElement(String prefix, String namespaceUri, String localName, Iterator attributes, Iterator namespaces, NamespaceContext context) {
/* 147 */     StartElementEvent elem = new StartElementEvent(prefix, namespaceUri, localName);
/* 148 */     elem.addAttributes(attributes);
/* 149 */     elem.addNamespaces(namespaces);
/* 150 */     elem.setNamespaceContext(context);
/* 151 */     if (this.location != null) elem.setLocation(this.location); 
/* 152 */     return (StartElement)elem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EndElement createEndElement(QName name, Iterator namespaces) {
/* 163 */     return createEndElement(name.getPrefix(), name.getNamespaceURI(), name.getLocalPart(), namespaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EndElement createEndElement(String prefix, String namespaceUri, String localName) {
/* 174 */     EndElementEvent event = new EndElementEvent(prefix, namespaceUri, localName);
/* 175 */     if (this.location != null) event.setLocation(this.location); 
/* 176 */     return (EndElement)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EndElement createEndElement(String prefix, String namespaceUri, String localName, Iterator namespaces) {
/* 190 */     EndElementEvent event = new EndElementEvent(prefix, namespaceUri, localName);
/* 191 */     if (namespaces != null)
/* 192 */       while (namespaces.hasNext()) {
/* 193 */         event.addNamespace(namespaces.next());
/*     */       } 
/* 195 */     if (this.location != null) event.setLocation(this.location); 
/* 196 */     return (EndElement)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Characters createCharacters(String content) {
/* 206 */     CharactersEvent charEvent = new CharactersEvent(content);
/* 207 */     if (this.location != null) charEvent.setLocation(this.location); 
/* 208 */     return (Characters)charEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Characters createCData(String content) {
/* 217 */     CharactersEvent charEvent = new CharactersEvent(content, true);
/* 218 */     if (this.location != null) charEvent.setLocation(this.location); 
/* 219 */     return (Characters)charEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Characters createSpace(String content) {
/* 228 */     CharactersEvent event = new CharactersEvent(content);
/* 229 */     event.setSpace(true);
/* 230 */     if (this.location != null) event.setLocation(this.location); 
/* 231 */     return (Characters)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Characters createIgnorableSpace(String content) {
/* 239 */     CharactersEvent event = new CharactersEvent(content, false);
/* 240 */     event.setSpace(true);
/* 241 */     event.setIgnorable(true);
/* 242 */     if (this.location != null) event.setLocation(this.location); 
/* 243 */     return (Characters)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartDocument createStartDocument() {
/* 250 */     StartDocumentEvent event = new StartDocumentEvent();
/* 251 */     if (this.location != null) event.setLocation(this.location); 
/* 252 */     return (StartDocument)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartDocument createStartDocument(String encoding) {
/* 262 */     StartDocumentEvent event = new StartDocumentEvent(encoding);
/* 263 */     if (this.location != null) event.setLocation(this.location); 
/* 264 */     return (StartDocument)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartDocument createStartDocument(String encoding, String version) {
/* 275 */     StartDocumentEvent event = new StartDocumentEvent(encoding, version);
/* 276 */     if (this.location != null) event.setLocation(this.location); 
/* 277 */     return (StartDocument)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StartDocument createStartDocument(String encoding, String version, boolean standalone) {
/* 289 */     StartDocumentEvent event = new StartDocumentEvent(encoding, version);
/* 290 */     event.setStandalone(standalone);
/* 291 */     if (this.location != null) event.setLocation(this.location); 
/* 292 */     return (StartDocument)event;
/*     */   }
/*     */   
/*     */   public EndDocument createEndDocument() {
/* 296 */     EndDocumentEvent event = new EndDocumentEvent();
/* 297 */     if (this.location != null) event.setLocation(this.location); 
/* 298 */     return (EndDocument)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityReference createEntityReference(String name, EntityDeclaration entityDeclaration) {
/* 308 */     EntityReferenceEvent event = new EntityReferenceEvent(name, entityDeclaration);
/* 309 */     if (this.location != null) event.setLocation(this.location); 
/* 310 */     return (EntityReference)event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comment createComment(String text) {
/* 319 */     CommentEvent charEvent = new CommentEvent(text);
/* 320 */     if (this.location != null) charEvent.setLocation(this.location); 
/* 321 */     return (Comment)charEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DTD createDTD(String dtd) {
/* 332 */     DTDEvent dtdEvent = new DTDEvent(dtd);
/* 333 */     if (this.location != null) dtdEvent.setLocation(this.location); 
/* 334 */     return (DTD)dtdEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProcessingInstruction createProcessingInstruction(String target, String data) {
/* 345 */     ProcessingInstructionEvent event = new ProcessingInstructionEvent(target, data);
/* 346 */     if (this.location != null) event.setLocation(this.location); 
/* 347 */     return (ProcessingInstruction)event;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\factory\StAXEventFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */