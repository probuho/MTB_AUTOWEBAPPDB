/*    */ package com.sun.xml.fastinfoset.stax.events;
/*    */ 
/*    */ import javax.xml.stream.events.ProcessingInstruction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessingInstructionEvent
/*    */   extends EventBase
/*    */   implements ProcessingInstruction
/*    */ {
/*    */   private String targetName;
/*    */   private String _data;
/*    */   
/*    */   public ProcessingInstructionEvent() {
/* 51 */     init();
/*    */   }
/*    */   
/*    */   public ProcessingInstructionEvent(String targetName, String data) {
/* 55 */     this.targetName = targetName;
/* 56 */     this._data = data;
/* 57 */     init();
/*    */   }
/*    */   
/*    */   protected void init() {
/* 61 */     setEventType(3);
/*    */   }
/*    */   
/*    */   public String getTarget() {
/* 65 */     return this.targetName;
/*    */   }
/*    */   
/*    */   public void setTarget(String targetName) {
/* 69 */     this.targetName = targetName;
/*    */   }
/*    */   
/*    */   public void setData(String data) {
/* 73 */     this._data = data;
/*    */   }
/*    */   
/*    */   public String getData() {
/* 77 */     return this._data;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 81 */     if (this._data != null && this.targetName != null)
/* 82 */       return "<?" + this.targetName + " " + this._data + "?>"; 
/* 83 */     if (this.targetName != null)
/* 84 */       return "<?" + this.targetName + "?>"; 
/* 85 */     if (this._data != null) {
/* 86 */       return "<?" + this._data + "?>";
/*    */     }
/* 88 */     return "<??>";
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\ProcessingInstructionEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */