package com.sun.xml.fastinfoset.algorithm;

public abstract class IEEE754FloatingPointEncodingAlgorithm extends BuiltInEncodingAlgorithm {
  public static final int FLOAT_SIZE = 4;
  
  public static final int DOUBLE_SIZE = 8;
  
  public static final int FLOAT_MAX_CHARACTER_SIZE = 14;
  
  public static final int DOUBLE_MAX_CHARACTER_SIZE = 24;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\IEEE754FloatingPointEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */