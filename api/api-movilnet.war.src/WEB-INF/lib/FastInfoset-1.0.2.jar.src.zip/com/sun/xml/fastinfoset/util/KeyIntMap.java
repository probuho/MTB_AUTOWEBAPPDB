/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyIntMap
/*     */ {
/*     */   public static final int NOT_PRESENT = -1;
/*     */   static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   static final int MAXIMUM_CAPACITY = 1048576;
/*     */   static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   int _readOnlyMapSize;
/*     */   int _size;
/*     */   int _capacity;
/*     */   int _threshold;
/*     */   final float _loadFactor;
/*     */   
/*     */   static class BaseEntry
/*     */   {
/*     */     final int _hash;
/*     */     final int _value;
/*     */     
/*     */     public BaseEntry(int hash, int value) {
/*  87 */       this._hash = hash;
/*  88 */       this._value = value;
/*     */     }
/*     */   }
/*     */   
/*     */   public KeyIntMap(int initialCapacity, float loadFactor) {
/*  93 */     if (initialCapacity < 0) {
/*  94 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalInitialCapacity", new Object[] { new Integer(initialCapacity) }));
/*     */     }
/*  96 */     if (initialCapacity > 1048576)
/*  97 */       initialCapacity = 1048576; 
/*  98 */     if (loadFactor <= 0.0F || Float.isNaN(loadFactor)) {
/*  99 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalLoadFactor", new Object[] { new Float(loadFactor) }));
/*     */     }
/*     */ 
/*     */     
/* 103 */     if (initialCapacity != 16) {
/* 104 */       this._capacity = 1;
/* 105 */       while (this._capacity < initialCapacity) {
/* 106 */         this._capacity <<= 1;
/*     */       }
/* 108 */       this._loadFactor = loadFactor;
/* 109 */       this._threshold = (int)(this._capacity * this._loadFactor);
/*     */     } else {
/* 111 */       this._capacity = 16;
/* 112 */       this._loadFactor = 0.75F;
/* 113 */       this._threshold = 12;
/*     */     } 
/*     */   }
/*     */   
/*     */   public KeyIntMap(int initialCapacity) {
/* 118 */     this(initialCapacity, 0.75F);
/*     */   }
/*     */   
/*     */   public KeyIntMap() {
/* 122 */     this._capacity = 16;
/* 123 */     this._loadFactor = 0.75F;
/* 124 */     this._threshold = 12;
/*     */   }
/*     */   
/*     */   public final int size() {
/* 128 */     return this._size + this._readOnlyMapSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void clear();
/*     */   
/*     */   public abstract void setReadOnlyMap(KeyIntMap paramKeyIntMap, boolean paramBoolean);
/*     */   
/*     */   public static final int hashHash(int h) {
/* 137 */     h += h << 9 ^ 0xFFFFFFFF;
/* 138 */     h ^= h >>> 14;
/* 139 */     h += h << 4;
/* 140 */     h ^= h >>> 10;
/* 141 */     return h;
/*     */   }
/*     */   
/*     */   public static final int indexFor(int h, int length) {
/* 145 */     return h & length - 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\KeyIntMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */