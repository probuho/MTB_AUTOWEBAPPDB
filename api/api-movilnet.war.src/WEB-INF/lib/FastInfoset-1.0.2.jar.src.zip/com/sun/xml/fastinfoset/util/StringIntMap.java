/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringIntMap
/*     */   extends KeyIntMap
/*     */ {
/*     */   protected StringIntMap _readOnlyMap;
/*     */   protected Entry[] _table;
/*     */   
/*     */   protected static class Entry
/*     */     extends KeyIntMap.BaseEntry
/*     */   {
/*     */     final String _key;
/*     */     Entry _next;
/*     */     
/*     */     public Entry(String key, int hash, int value, Entry next) {
/*  53 */       super(hash, value);
/*  54 */       this._key = key;
/*  55 */       this._next = next;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringIntMap(int initialCapacity, float loadFactor) {
/*  62 */     super(initialCapacity, loadFactor);
/*     */     
/*  64 */     this._table = new Entry[this._capacity];
/*     */   }
/*     */   
/*     */   public StringIntMap(int initialCapacity) {
/*  68 */     this(initialCapacity, 0.75F);
/*     */   }
/*     */   
/*     */   public StringIntMap() {
/*  72 */     this(16, 0.75F);
/*     */   }
/*     */   
/*     */   public void clear() {
/*  76 */     for (int i = 0; i < this._table.length; i++) {
/*  77 */       this._table[i] = null;
/*     */     }
/*  79 */     this._size = 0;
/*     */   }
/*     */   
/*     */   public void setReadOnlyMap(KeyIntMap readOnlyMap, boolean clear) {
/*  83 */     if (!(readOnlyMap instanceof StringIntMap)) {
/*  84 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyMap }));
/*     */     }
/*     */ 
/*     */     
/*  88 */     setReadOnlyMap((StringIntMap)readOnlyMap, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyMap(StringIntMap readOnlyMap, boolean clear) {
/*  92 */     this._readOnlyMap = readOnlyMap;
/*  93 */     if (this._readOnlyMap != null) {
/*  94 */       this._readOnlyMapSize = this._readOnlyMap.size();
/*     */       
/*  96 */       if (clear) {
/*  97 */         clear();
/*     */       }
/*     */     } else {
/* 100 */       this._readOnlyMapSize = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int obtainIndex(String key) {
/* 105 */     int hash = hashHash(key.hashCode());
/*     */     
/* 107 */     if (this._readOnlyMap != null) {
/* 108 */       int index = this._readOnlyMap.get(key, hash);
/* 109 */       if (index != -1) {
/* 110 */         return index;
/*     */       }
/*     */     } 
/*     */     
/* 114 */     int tableIndex = indexFor(hash, this._table.length);
/* 115 */     for (Entry e = this._table[tableIndex]; e != null; e = e._next) {
/* 116 */       if (e._hash == hash && eq(key, e._key)) {
/* 117 */         return e._value;
/*     */       }
/*     */     } 
/*     */     
/* 121 */     addEntry(key, hash, this._size + this._readOnlyMapSize, tableIndex);
/* 122 */     return -1;
/*     */   }
/*     */   
/*     */   public final void add(String key) {
/* 126 */     int hash = hashHash(key.hashCode());
/* 127 */     int tableIndex = indexFor(hash, this._table.length);
/* 128 */     addEntry(key, hash, this._size + this._readOnlyMapSize, tableIndex);
/*     */   }
/*     */   
/*     */   public final int get(String key) {
/* 132 */     return get(key, hashHash(key.hashCode()));
/*     */   }
/*     */   
/*     */   private final int get(String key, int hash) {
/* 136 */     if (this._readOnlyMap != null) {
/* 137 */       int i = this._readOnlyMap.get(key, hash);
/* 138 */       if (i != -1) {
/* 139 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 143 */     int tableIndex = indexFor(hash, this._table.length);
/* 144 */     for (Entry e = this._table[tableIndex]; e != null; e = e._next) {
/* 145 */       if (e._hash == hash && eq(key, e._key)) {
/* 146 */         return e._value;
/*     */       }
/*     */     } 
/*     */     
/* 150 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private final void addEntry(String key, int hash, int value, int bucketIndex) {
/* 155 */     Entry e = this._table[bucketIndex];
/* 156 */     this._table[bucketIndex] = new Entry(key, hash, value, e);
/* 157 */     if (this._size++ >= this._threshold) {
/* 158 */       resize(2 * this._table.length);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void resize(int newCapacity) {
/* 163 */     this._capacity = newCapacity;
/* 164 */     Entry[] oldTable = this._table;
/* 165 */     int oldCapacity = oldTable.length;
/* 166 */     if (oldCapacity == 1048576) {
/* 167 */       this._threshold = Integer.MAX_VALUE;
/*     */       
/*     */       return;
/*     */     } 
/* 171 */     Entry[] newTable = new Entry[this._capacity];
/* 172 */     transfer(newTable);
/* 173 */     this._table = newTable;
/* 174 */     this._threshold = (int)(this._capacity * this._loadFactor);
/*     */   }
/*     */   
/*     */   private final void transfer(Entry[] newTable) {
/* 178 */     Entry[] src = this._table;
/* 179 */     int newCapacity = newTable.length;
/* 180 */     for (int j = 0; j < src.length; j++) {
/* 181 */       Entry e = src[j];
/* 182 */       if (e != null) {
/* 183 */         src[j] = null;
/*     */         do {
/* 185 */           Entry next = e._next;
/* 186 */           int i = indexFor(e._hash, newCapacity);
/* 187 */           e._next = newTable[i];
/* 188 */           newTable[i] = e;
/* 189 */           e = next;
/* 190 */         } while (e != null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final boolean eq(String x, String y) {
/* 196 */     return (x == y || x.equals(y));
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\StringIntMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */