/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.stax.StAXDocumentParser;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXEventReader
/*     */   implements XMLEventReader
/*     */ {
/*     */   protected XMLStreamReader _streamReader;
/*     */   protected XMLEventAllocator _eventAllocator;
/*     */   private XMLEvent _currentEvent;
/*  56 */   private XMLEvent[] events = new XMLEvent[3];
/*  57 */   private int size = 3;
/*  58 */   private int currentIndex = 0;
/*     */   
/*     */   private boolean hasEvent = false;
/*     */   
/*     */   public StAXEventReader(XMLStreamReader reader) throws XMLStreamException {
/*  63 */     this._streamReader = reader;
/*  64 */     this._eventAllocator = (XMLEventAllocator)reader.getProperty("javax.xml.stream.allocator");
/*  65 */     if (this._eventAllocator == null) {
/*  66 */       this._eventAllocator = new StAXEventAllocatorBase();
/*     */     }
/*     */     
/*  69 */     if (this._streamReader.hasNext()) {
/*     */       
/*  71 */       this._streamReader.next();
/*  72 */       this._currentEvent = this._eventAllocator.allocate(this._streamReader);
/*  73 */       this.events[0] = this._currentEvent;
/*  74 */       System.out.println("current event:" + this._currentEvent);
/*  75 */       this.hasEvent = true;
/*     */     } else {
/*  77 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.noElement"));
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/*  82 */     return this.hasEvent;
/*     */   }
/*     */   
/*     */   public XMLEvent nextEvent() throws XMLStreamException {
/*  86 */     XMLEvent event = null;
/*  87 */     XMLEvent nextEvent = null;
/*  88 */     if (this.hasEvent) {
/*     */       
/*  90 */       event = this.events[this.currentIndex];
/*  91 */       this.events[this.currentIndex] = null;
/*  92 */       if (this._streamReader.hasNext()) {
/*     */ 
/*     */         
/*  95 */         this._streamReader.next();
/*  96 */         nextEvent = this._eventAllocator.allocate(this._streamReader);
/*  97 */         if (++this.currentIndex == this.size)
/*  98 */           this.currentIndex = 0; 
/*  99 */         this.events[this.currentIndex] = nextEvent;
/* 100 */         this.hasEvent = true;
/*     */       } else {
/* 102 */         this._currentEvent = null;
/* 103 */         this.hasEvent = false;
/*     */       } 
/* 105 */       return event;
/*     */     } 
/*     */     
/* 108 */     throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 114 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws XMLStreamException {
/* 119 */     this._streamReader.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getElementText() throws XMLStreamException {
/* 129 */     if (!this.hasEvent) {
/* 130 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/* 133 */     if (!this._currentEvent.isStartElement()) {
/* 134 */       StAXDocumentParser parser = (StAXDocumentParser)this._streamReader;
/* 135 */       return parser.getElementText(true);
/*     */     } 
/* 137 */     return this._streamReader.getElementText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws IllegalArgumentException {
/* 147 */     return this._streamReader.getProperty(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent nextTag() throws XMLStreamException {
/* 159 */     if (!this.hasEvent) {
/* 160 */       throw new NoSuchElementException();
/*     */     }
/* 162 */     StAXDocumentParser parser = (StAXDocumentParser)this._streamReader;
/* 163 */     parser.nextTag(true);
/* 164 */     return this._eventAllocator.allocate(this._streamReader);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object next() {
/*     */     try {
/* 170 */       return nextEvent();
/* 171 */     } catch (XMLStreamException streamException) {
/* 172 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public XMLEvent peek() throws XMLStreamException {
/* 177 */     if (!this.hasEvent)
/* 178 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.noElement")); 
/* 179 */     this._currentEvent = this.events[this.currentIndex];
/* 180 */     return this._currentEvent;
/*     */   }
/*     */   
/*     */   public void setAllocator(XMLEventAllocator allocator) {
/* 184 */     if (allocator == null) {
/* 185 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.nullXMLEventAllocator"));
/*     */     }
/* 187 */     this._eventAllocator = allocator;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\StAXEventReader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */