/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.Comment;
/*     */ import javax.xml.stream.events.DTD;
/*     */ import javax.xml.stream.events.EntityReference;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.ProcessingInstruction;
/*     */ import javax.xml.stream.events.StartDocument;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXEventWriter
/*     */   implements XMLEventWriter
/*     */ {
/*     */   private XMLStreamWriter _streamWriter;
/*     */   
/*     */   public StAXEventWriter(XMLStreamWriter streamWriter) {
/*  60 */     this._streamWriter = streamWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws XMLStreamException {
/*  68 */     this._streamWriter.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws XMLStreamException {
/*  75 */     this._streamWriter.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(XMLEventReader eventReader) throws XMLStreamException {
/*  84 */     if (eventReader == null) throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.nullEventReader")); 
/*  85 */     while (eventReader.hasNext())
/*  86 */       add(eventReader.nextEvent());  } public void add(XMLEvent event) throws XMLStreamException { DTD dtd;
/*     */     StartDocument startDocument;
/*     */     StartElement startElement;
/*     */     Namespace namespace;
/*     */     Comment comment;
/*     */     ProcessingInstruction processingInstruction;
/*     */     Characters characters1;
/*     */     EntityReference entityReference;
/*     */     Attribute attribute;
/*     */     Characters characters;
/*     */     QName qname;
/*     */     Iterator iterator;
/*     */     Iterator attributes;
/*  99 */     int type = event.getEventType();
/* 100 */     switch (type) {
/*     */       case 11:
/* 102 */         dtd = (DTD)event;
/* 103 */         this._streamWriter.writeDTD(dtd.getDocumentTypeDeclaration());
/*     */         return;
/*     */       
/*     */       case 7:
/* 107 */         startDocument = (StartDocument)event;
/* 108 */         this._streamWriter.writeStartDocument(startDocument.getCharacterEncodingScheme(), startDocument.getVersion());
/*     */         return;
/*     */       
/*     */       case 1:
/* 112 */         startElement = event.asStartElement();
/* 113 */         qname = startElement.getName();
/* 114 */         this._streamWriter.writeStartElement(qname.getPrefix(), qname.getLocalPart(), qname.getNamespaceURI());
/*     */         
/* 116 */         iterator = startElement.getNamespaces();
/* 117 */         while (iterator.hasNext()) {
/* 118 */           Namespace namespace1 = iterator.next();
/* 119 */           this._streamWriter.writeNamespace(namespace1.getPrefix(), namespace1.getNamespaceURI());
/*     */         } 
/*     */         
/* 122 */         attributes = startElement.getAttributes();
/* 123 */         while (attributes.hasNext()) {
/* 124 */           Attribute attribute1 = attributes.next();
/* 125 */           QName name = attribute1.getName();
/* 126 */           this._streamWriter.writeAttribute(name.getPrefix(), name.getNamespaceURI(), name.getLocalPart(), attribute1.getValue());
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 13:
/* 132 */         namespace = (Namespace)event;
/* 133 */         this._streamWriter.writeNamespace(namespace.getPrefix(), namespace.getNamespaceURI());
/*     */         return;
/*     */       
/*     */       case 5:
/* 137 */         comment = (Comment)event;
/* 138 */         this._streamWriter.writeComment(comment.getText());
/*     */         return;
/*     */       
/*     */       case 3:
/* 142 */         processingInstruction = (ProcessingInstruction)event;
/* 143 */         this._streamWriter.writeProcessingInstruction(processingInstruction.getTarget(), processingInstruction.getData());
/*     */         return;
/*     */       
/*     */       case 4:
/* 147 */         characters1 = event.asCharacters();
/*     */         
/* 149 */         if (characters1.isCData()) {
/* 150 */           this._streamWriter.writeCData(characters1.getData());
/*     */         } else {
/*     */           
/* 153 */           this._streamWriter.writeCharacters(characters1.getData());
/*     */         } 
/*     */         return;
/*     */       
/*     */       case 9:
/* 158 */         entityReference = (EntityReference)event;
/* 159 */         this._streamWriter.writeEntityRef(entityReference.getName());
/*     */         return;
/*     */       
/*     */       case 10:
/* 163 */         attribute = (Attribute)event;
/* 164 */         qname = attribute.getName();
/* 165 */         this._streamWriter.writeAttribute(qname.getPrefix(), qname.getNamespaceURI(), qname.getLocalPart(), attribute.getValue());
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 12:
/* 171 */         characters = (Characters)event;
/* 172 */         if (characters.isCData()) {
/* 173 */           this._streamWriter.writeCData(characters.getData());
/*     */         }
/*     */         return;
/*     */ 
/*     */       
/*     */       case 2:
/* 179 */         this._streamWriter.writeEndElement();
/*     */         return;
/*     */       
/*     */       case 8:
/* 183 */         this._streamWriter.writeEndDocument();
/*     */         return;
/*     */     } 
/*     */     
/* 187 */     throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.eventTypeNotSupported", new Object[] { Util.getEventTypeString(type) })); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix(String uri) throws XMLStreamException {
/* 199 */     return this._streamWriter.getPrefix(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 208 */     return this._streamWriter.getNamespaceContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultNamespace(String uri) throws XMLStreamException {
/* 222 */     this._streamWriter.setDefaultNamespace(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext namespaceContext) throws XMLStreamException {
/* 236 */     this._streamWriter.setNamespaceContext(namespaceContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix, String uri) throws XMLStreamException {
/* 248 */     this._streamWriter.setPrefix(prefix, uri);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\StAXEventWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */