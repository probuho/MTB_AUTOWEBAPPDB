/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.stax.StAXDocumentSerializer;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.parsers.SAXParser;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XML_SAX_StAX_FI
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream xml, OutputStream finf) throws Exception {
/* 55 */     StAXDocumentSerializer documentSerializer = new StAXDocumentSerializer();
/* 56 */     documentSerializer.setOutputStream(finf);
/*    */     
/* 58 */     SAX2StAXWriter saxTostax = new SAX2StAXWriter((XMLStreamWriter)documentSerializer);
/*    */     
/* 60 */     SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
/* 61 */     saxParserFactory.setNamespaceAware(true);
/* 62 */     SAXParser saxParser = saxParserFactory.newSAXParser();
/*    */     
/* 64 */     saxParser.setProperty("http://xml.org/sax/properties/lexical-handler", saxTostax);
/* 65 */     saxParser.parse(xml, saxTostax);
/* 66 */     xml.close();
/* 67 */     finf.close();
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 71 */     XML_SAX_StAX_FI s = new XML_SAX_StAX_FI();
/* 72 */     s.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\XML_SAX_StAX_FI.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */