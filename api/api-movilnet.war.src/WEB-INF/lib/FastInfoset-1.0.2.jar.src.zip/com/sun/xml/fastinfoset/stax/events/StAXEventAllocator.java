/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ import javax.xml.stream.util.XMLEventConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXEventAllocator
/*     */   implements XMLEventAllocator
/*     */ {
/*  61 */   StartElementEvent startElement = new StartElementEvent();
/*  62 */   EndElementEvent endElement = new EndElementEvent();
/*  63 */   CharactersEvent characters = new CharactersEvent();
/*  64 */   CharactersEvent cData = new CharactersEvent("", true);
/*  65 */   CharactersEvent space = new CharactersEvent();
/*  66 */   CommentEvent comment = new CommentEvent();
/*  67 */   EntityReferenceEvent entity = new EntityReferenceEvent();
/*  68 */   ProcessingInstructionEvent pi = new ProcessingInstructionEvent();
/*  69 */   StartDocumentEvent startDoc = new StartDocumentEvent();
/*  70 */   EndDocumentEvent endDoc = new EndDocumentEvent();
/*  71 */   DTDEvent dtd = new DTDEvent();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEventAllocator newInstance() {
/*  77 */     return new StAXEventAllocator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent allocate(XMLStreamReader streamReader) throws XMLStreamException {
/*  88 */     if (streamReader == null)
/*  89 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.nullReader")); 
/*  90 */     return getXMLEvent(streamReader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void allocate(XMLStreamReader streamReader, XMLEventConsumer consumer) throws XMLStreamException {
/* 101 */     consumer.add(getXMLEvent(streamReader));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XMLEvent getXMLEvent(XMLStreamReader reader) {
/*     */     String encoding, version;
/* 108 */     EventBase event = null;
/* 109 */     int eventType = reader.getEventType();
/*     */     
/* 111 */     switch (eventType) {
/*     */ 
/*     */       
/*     */       case 1:
/* 115 */         this.startElement.reset();
/* 116 */         this.startElement.setName(new QName(reader.getNamespaceURI(), reader.getLocalName(), reader.getPrefix()));
/*     */ 
/*     */         
/* 119 */         addAttributes(this.startElement, reader);
/* 120 */         addNamespaces(this.startElement, reader);
/*     */ 
/*     */         
/* 123 */         event = this.startElement;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 128 */         this.endElement.reset();
/* 129 */         this.endElement.setName(new QName(reader.getNamespaceURI(), reader.getLocalName(), reader.getPrefix()));
/*     */         
/* 131 */         addNamespaces(this.endElement, reader);
/* 132 */         event = this.endElement;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/* 137 */         this.pi.setTarget(reader.getPITarget());
/* 138 */         this.pi.setData(reader.getPIData());
/* 139 */         event = this.pi;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 144 */         this.characters.setData(reader.getText());
/* 145 */         event = this.characters;
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 161 */         this.comment.setText(reader.getText());
/* 162 */         event = this.comment;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 7:
/* 167 */         this.startDoc.reset();
/* 168 */         encoding = reader.getEncoding();
/* 169 */         version = reader.getVersion();
/* 170 */         if (encoding != null)
/* 171 */           this.startDoc.setEncoding(encoding); 
/* 172 */         if (version != null)
/* 173 */           this.startDoc.setVersion(version); 
/* 174 */         this.startDoc.setStandalone(reader.isStandalone());
/* 175 */         if (reader.getCharacterEncodingScheme() != null) {
/* 176 */           this.startDoc.setDeclaredEncoding(true);
/*     */         } else {
/* 178 */           this.startDoc.setDeclaredEncoding(false);
/*     */         } 
/* 180 */         event = this.startDoc;
/*     */         break;
/*     */       
/*     */       case 8:
/* 184 */         event = this.endDoc;
/*     */         break;
/*     */       
/*     */       case 9:
/* 188 */         this.entity.setName(reader.getLocalName());
/* 189 */         this.entity.setDeclaration(new EntityDeclarationImpl(reader.getLocalName(), reader.getText()));
/* 190 */         event = this.entity;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 10:
/* 195 */         event = null;
/*     */         break;
/*     */       
/*     */       case 11:
/* 199 */         this.dtd.setDTD(reader.getText());
/* 200 */         event = this.dtd;
/*     */         break;
/*     */       
/*     */       case 12:
/* 204 */         this.cData.setData(reader.getText());
/* 205 */         event = this.cData;
/*     */         break;
/*     */       
/*     */       case 6:
/* 209 */         this.space.setData(reader.getText());
/* 210 */         this.space.setSpace(true);
/* 211 */         event = this.space;
/*     */         break;
/*     */     } 
/*     */     
/* 215 */     event.setLocation(reader.getLocation());
/* 216 */     return event;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addAttributes(StartElementEvent event, XMLStreamReader reader) {
/* 221 */     AttributeBase attr = null;
/* 222 */     for (int i = 0; i < reader.getAttributeCount(); i++) {
/* 223 */       attr = new AttributeBase(reader.getAttributeName(i), reader.getAttributeValue(i));
/* 224 */       attr.setAttributeType(reader.getAttributeType(i));
/* 225 */       attr.setSpecified(reader.isAttributeSpecified(i));
/* 226 */       event.addAttribute(attr);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addNamespaces(StartElementEvent event, XMLStreamReader reader) {
/* 232 */     Namespace namespace = null;
/* 233 */     for (int i = 0; i < reader.getNamespaceCount(); i++) {
/* 234 */       namespace = new NamespaceBase(reader.getNamespacePrefix(i), reader.getNamespaceURI(i));
/* 235 */       event.addNamespace(namespace);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void addNamespaces(EndElementEvent event, XMLStreamReader reader) {
/* 240 */     Namespace namespace = null;
/* 241 */     for (int i = 0; i < reader.getNamespaceCount(); i++) {
/* 242 */       namespace = new NamespaceBase(reader.getNamespacePrefix(i), reader.getNamespaceURI(i));
/* 243 */       event.addNamespace(namespace);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\StAXEventAllocator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */