/*     */ package com.sun.xml.fastinfoset;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResourceBundle
/*     */   extends ResourceBundle
/*     */ {
/*     */   public static final String LOCALE = "com.sun.xml.fastinfoset.locale";
/*  64 */   static String _bundleName = null;
/*     */   
/*     */   public static String getBundleName() {
/*  67 */     return _bundleName;
/*     */   }
/*     */   public void setBundleName(String name) {
/*  70 */     _bundleName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(String key, Object[] args) {
/*  80 */     String pattern = getBundle().getString(key);
/*  81 */     return MessageFormat.format(pattern, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(String key, Object[] args, Locale locale) {
/*  93 */     String pattern = null;
/*  94 */     if (locale == null) {
/*  95 */       pattern = getBundle().getString(key);
/*     */     } else {
/*  97 */       pattern = getBundle(_bundleName, locale).getString(key);
/*     */     } 
/*  99 */     return MessageFormat.format(pattern, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Locale parseLocale(String localeString) {
/* 110 */     Locale locale = null;
/* 111 */     if (localeString == null) {
/* 112 */       locale = Locale.getDefault();
/*     */     } else {
/*     */       try {
/* 115 */         String[] args = localeString.split("_");
/* 116 */         if (args.length == 1) {
/* 117 */           locale = new Locale(args[0]);
/* 118 */         } else if (args.length == 2) {
/* 119 */           locale = new Locale(args[0], args[1]);
/* 120 */         } else if (args.length == 3) {
/* 121 */           locale = new Locale(args[0], args[1], args[2]);
/*     */         } 
/* 123 */       } catch (Throwable t) {
/* 124 */         locale = Locale.getDefault();
/*     */       } 
/*     */     } 
/* 127 */     return locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ResourceBundle getBundle();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object handleGetObject(String key) {
/* 154 */     return getBundle().getObject(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Enumeration getKeys() {
/* 167 */     return getBundle().getKeys();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\AbstractResourceBundle.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */