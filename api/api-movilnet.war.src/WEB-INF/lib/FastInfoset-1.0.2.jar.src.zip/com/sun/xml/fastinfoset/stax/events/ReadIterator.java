/*    */ package com.sun.xml.fastinfoset.stax.events;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadIterator
/*    */   implements Iterator
/*    */ {
/* 47 */   Iterator iterator = EmptyIterator.getInstance();
/*    */ 
/*    */   
/*    */   public ReadIterator() {}
/*    */   
/*    */   public ReadIterator(Iterator iterator) {
/* 53 */     if (iterator != null) {
/* 54 */       this.iterator = iterator;
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 59 */     return this.iterator.hasNext();
/*    */   }
/*    */   
/*    */   public Object next() {
/* 63 */     return this.iterator.next();
/*    */   }
/*    */   
/*    */   public void remove() {
/* 67 */     throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.readonlyList"));
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\ReadIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */