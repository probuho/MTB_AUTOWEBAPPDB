/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.Decoder;
/*    */ import com.sun.xml.fastinfoset.stax.StAXDocumentParser;
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.parsers.SAXParser;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ import javax.xml.stream.XMLStreamReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FI_StAX_SAX_Or_XML_SAX_SAXEvent
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream document, OutputStream events) throws Exception {
/* 58 */     if (!document.markSupported()) {
/* 59 */       document = new BufferedInputStream(document);
/*    */     }
/*    */     
/* 62 */     document.mark(4);
/* 63 */     boolean isFastInfosetDocument = Decoder.isFastInfosetDocument(document);
/* 64 */     document.reset();
/*    */     
/* 66 */     if (isFastInfosetDocument) {
/* 67 */       StAXDocumentParser parser = new StAXDocumentParser();
/* 68 */       parser.setInputStream(document);
/* 69 */       SAXEventSerializer ses = new SAXEventSerializer(events);
/* 70 */       StAX2SAXReader reader = new StAX2SAXReader((XMLStreamReader)parser, ses);
/* 71 */       reader.setLexicalHandler(ses);
/* 72 */       reader.adapt();
/*    */     } else {
/* 74 */       SAXParserFactory parserFactory = SAXParserFactory.newInstance();
/* 75 */       parserFactory.setNamespaceAware(true);
/* 76 */       SAXParser parser = parserFactory.newSAXParser();
/* 77 */       SAXEventSerializer ses = new SAXEventSerializer(events);
/* 78 */       parser.setProperty("http://xml.org/sax/properties/lexical-handler", ses);
/* 79 */       parser.parse(document, ses);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 84 */     FI_StAX_SAX_Or_XML_SAX_SAXEvent p = new FI_StAX_SAX_Or_XML_SAX_SAXEvent();
/* 85 */     p.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\FI_StAX_SAX_Or_XML_SAX_SAXEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */