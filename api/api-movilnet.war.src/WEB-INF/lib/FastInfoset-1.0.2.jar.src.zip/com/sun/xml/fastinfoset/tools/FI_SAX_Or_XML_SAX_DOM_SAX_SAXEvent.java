/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.Decoder;
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.transform.Source;
/*    */ import javax.xml.transform.Transformer;
/*    */ import javax.xml.transform.TransformerFactory;
/*    */ import javax.xml.transform.dom.DOMResult;
/*    */ import javax.xml.transform.dom.DOMSource;
/*    */ import javax.xml.transform.sax.SAXResult;
/*    */ import javax.xml.transform.stream.StreamSource;
/*    */ import org.jvnet.fastinfoset.FastInfosetSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FI_SAX_Or_XML_SAX_DOM_SAX_SAXEvent
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream document, OutputStream events) throws Exception {
/* 60 */     if (!document.markSupported()) {
/* 61 */       document = new BufferedInputStream(document);
/*    */     }
/*    */     
/* 64 */     document.mark(4);
/* 65 */     boolean isFastInfosetDocument = Decoder.isFastInfosetDocument(document);
/* 66 */     document.reset();
/*    */     
/* 68 */     TransformerFactory tf = TransformerFactory.newInstance();
/* 69 */     Transformer t = tf.newTransformer();
/* 70 */     DOMResult dr = new DOMResult();
/*    */     
/* 72 */     if (isFastInfosetDocument) {
/* 73 */       t.transform((Source)new FastInfosetSource(document), dr);
/*    */     } else {
/* 75 */       t.transform(new StreamSource(document), dr);
/*    */     } 
/*    */     
/* 78 */     SAXEventSerializer ses = new SAXEventSerializer(events);
/* 79 */     t.transform(new DOMSource(dr.getNode()), new SAXResult(ses));
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 83 */     FI_SAX_Or_XML_SAX_DOM_SAX_SAXEvent p = new FI_SAX_Or_XML_SAX_DOM_SAX_SAXEvent();
/* 84 */     p.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\FI_SAX_Or_XML_SAX_DOM_SAX_SAXEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */