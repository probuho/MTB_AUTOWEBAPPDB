/*     */ package com.sun.xml.fastinfoset.sax;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ import com.sun.xml.fastinfoset.util.CharArray;
/*     */ import com.sun.xml.fastinfoset.util.LocalNameQualifiedNamesMap;
/*     */ import com.sun.xml.fastinfoset.util.PrefixArray;
/*     */ import com.sun.xml.fastinfoset.util.QualifiedNameArray;
/*     */ import com.sun.xml.fastinfoset.util.StringArray;
/*     */ import com.sun.xml.fastinfoset.util.StringIntMap;
/*     */ import com.sun.xml.fastinfoset.vocab.ParserVocabulary;
/*     */ import com.sun.xml.fastinfoset.vocab.SerializerVocabulary;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VocabularyGenerator
/*     */   extends DefaultHandler
/*     */   implements LexicalHandler
/*     */ {
/*     */   protected SerializerVocabulary _serializerVocabulary;
/*     */   protected ParserVocabulary _parserVocabulary;
/*  66 */   protected int attributeValueSizeConstraint = 7;
/*     */   
/*  68 */   protected int characterContentChunkSizeContraint = 7;
/*     */ 
/*     */   
/*     */   public VocabularyGenerator(SerializerVocabulary serializerVocabulary) {
/*  72 */     this._serializerVocabulary = serializerVocabulary;
/*  73 */     this._parserVocabulary = new ParserVocabulary();
/*     */   }
/*     */   
/*     */   public VocabularyGenerator(ParserVocabulary parserVocabulary) {
/*  77 */     this._serializerVocabulary = new SerializerVocabulary();
/*  78 */     this._parserVocabulary = parserVocabulary;
/*     */   }
/*     */ 
/*     */   
/*     */   public VocabularyGenerator(SerializerVocabulary serializerVocabulary, ParserVocabulary parserVocabulary) {
/*  83 */     this._serializerVocabulary = serializerVocabulary;
/*  84 */     this._parserVocabulary = parserVocabulary;
/*     */   }
/*     */   
/*     */   public void setCharacterContentChunkSizeLimit(int size) {
/*  88 */     if (size < 0) {
/*  89 */       size = 0;
/*     */     }
/*     */     
/*  92 */     this.characterContentChunkSizeContraint = size;
/*     */   }
/*     */   
/*     */   public int getCharacterContentChunkSizeLimit() {
/*  96 */     return this.characterContentChunkSizeContraint;
/*     */   }
/*     */   
/*     */   public void setAttributeValueSizeLimit(int size) {
/* 100 */     if (size < 0) {
/* 101 */       size = 0;
/*     */     }
/*     */     
/* 104 */     this.attributeValueSizeConstraint = size;
/*     */   }
/*     */   
/*     */   public int getAttributeValueSizeLimit() {
/* 108 */     return this.attributeValueSizeConstraint;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() throws SAXException {}
/*     */ 
/*     */   
/*     */   public void endDocument() throws SAXException {}
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 120 */     addToTable(prefix, this._serializerVocabulary.prefix, this._parserVocabulary.prefix);
/* 121 */     addToTable(uri, this._serializerVocabulary.namespaceName, this._parserVocabulary.namespaceName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {}
/*     */   
/*     */   public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
/* 128 */     addToNameTable(namespaceURI, qName, localName, this._serializerVocabulary.elementName, this._parserVocabulary.elementName, false);
/*     */     
/* 130 */     for (int a = 0; a < atts.getLength(); a++) {
/* 131 */       addToNameTable(atts.getURI(a), atts.getQName(a), atts.getLocalName(a), this._serializerVocabulary.attributeName, this._parserVocabulary.attributeName, true);
/*     */       
/* 133 */       String value = atts.getValue(a);
/* 134 */       if (value.length() < this.attributeValueSizeConstraint) {
/* 135 */         addToTable(value, this._serializerVocabulary.attributeValue, this._parserVocabulary.attributeValue);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(String namespaceURI, String localName, String qName) throws SAXException {}
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 144 */     if (length < this.characterContentChunkSizeContraint) {
/* 145 */       addToCharArrayTable(new CharArray(ch, start, length, true));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void skippedEntity(String name) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void startCDATA() throws SAXException {}
/*     */ 
/*     */   
/*     */   public void endCDATA() throws SAXException {}
/*     */ 
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void endDTD() throws SAXException {}
/*     */ 
/*     */   
/*     */   public void startEntity(String name) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void endEntity(String name) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void addToTable(String s, StringIntMap m, StringArray a) {
/* 188 */     if (s == "") {
/*     */       return;
/*     */     }
/*     */     
/* 192 */     if (m.obtainIndex(s) == -1) {
/* 193 */       a.add(s);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addToTable(String s, StringIntMap m, PrefixArray a) {
/* 198 */     if (s == "") {
/*     */       return;
/*     */     }
/*     */     
/* 202 */     if (m.obtainIndex(s) == -1) {
/* 203 */       a.add(s);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addToCharArrayTable(CharArray c) {
/* 208 */     if (this._serializerVocabulary.characterContentChunk.obtainIndex(c.ch, c.start, c.length, false) == -1) {
/* 209 */       this._parserVocabulary.characterContentChunk.add(c.ch, c.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToNameTable(String namespaceURI, String qName, String localName, LocalNameQualifiedNamesMap m, QualifiedNameArray a, boolean isAttribute) throws SAXException {
/* 216 */     LocalNameQualifiedNamesMap.Entry entry = m.obtainEntry(qName);
/* 217 */     if (entry._valueIndex > 0) {
/* 218 */       QualifiedName[] names = entry._value;
/* 219 */       for (int i = 0; i < entry._valueIndex; i++) {
/* 220 */         if (namespaceURI == (names[i]).namespaceName || namespaceURI.equals((names[i]).namespaceName)) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 226 */     String prefix = getPrefixFromQualifiedName(qName);
/*     */     
/* 228 */     int namespaceURIIndex = -1;
/* 229 */     int prefixIndex = -1;
/* 230 */     int localNameIndex = -1;
/* 231 */     if (namespaceURI != "") {
/* 232 */       namespaceURIIndex = this._serializerVocabulary.namespaceName.get(namespaceURI);
/* 233 */       if (namespaceURIIndex == -1) {
/* 234 */         throw new SAXException(CommonResourceBundle.getInstance().getString("message.namespaceURINotIndexed", new Object[] { new Integer(namespaceURIIndex) }));
/*     */       }
/*     */ 
/*     */       
/* 238 */       if (prefix != "") {
/* 239 */         prefixIndex = this._serializerVocabulary.prefix.get(prefix);
/* 240 */         if (prefixIndex == -1) {
/* 241 */           throw new SAXException(CommonResourceBundle.getInstance().getString("message.prefixNotIndexed", new Object[] { new Integer(prefixIndex) }));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 247 */     localNameIndex = this._serializerVocabulary.localName.obtainIndex(localName);
/* 248 */     if (localNameIndex == -1) {
/* 249 */       this._parserVocabulary.localName.add(localName);
/* 250 */       localNameIndex = this._parserVocabulary.localName.getSize() - 1;
/*     */     } 
/* 252 */     QualifiedName name = new QualifiedName(prefix, namespaceURI, localName, m.getNextIndex(), prefixIndex, namespaceURIIndex, localNameIndex);
/*     */     
/* 254 */     if (isAttribute) {
/* 255 */       name.createAttributeValues(256);
/*     */     }
/* 257 */     entry.addQualifiedName(name);
/* 258 */     a.add(name);
/*     */   }
/*     */   
/*     */   public static String getPrefixFromQualifiedName(String qName) {
/* 262 */     int i = qName.indexOf(':');
/* 263 */     String prefix = "";
/* 264 */     if (i != -1) {
/* 265 */       prefix = qName.substring(0, i);
/*     */     }
/* 267 */     return prefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sax\VocabularyGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */