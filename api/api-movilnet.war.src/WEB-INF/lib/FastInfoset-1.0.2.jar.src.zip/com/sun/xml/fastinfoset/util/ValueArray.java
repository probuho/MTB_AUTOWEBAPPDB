/*    */ package com.sun.xml.fastinfoset.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ValueArray
/*    */ {
/*    */   public static final int DEFAULT_CAPACITY = 10;
/*    */   public static final int MAXIMUM_CAPACITY = 2147483647;
/*    */   protected int _size;
/*    */   protected int _readOnlyArraySize;
/*    */   protected int _maximumCapacity;
/*    */   
/*    */   public int getSize() {
/* 53 */     return this._size;
/*    */   }
/*    */   
/*    */   public int getMaximumCapacity() {
/* 57 */     return this._maximumCapacity;
/*    */   }
/*    */   
/*    */   public void setMaximumCapacity(int maximumCapacity) {
/* 61 */     this._maximumCapacity = maximumCapacity;
/*    */   }
/*    */   
/*    */   public abstract void setReadOnlyArray(ValueArray paramValueArray, boolean paramBoolean);
/*    */   
/*    */   public abstract void clear();
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\ValueArray.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */