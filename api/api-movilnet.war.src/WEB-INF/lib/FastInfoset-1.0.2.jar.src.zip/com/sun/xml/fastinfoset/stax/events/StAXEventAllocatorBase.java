/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ import javax.xml.stream.util.XMLEventConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXEventAllocatorBase
/*     */   implements XMLEventAllocator
/*     */ {
/*     */   XMLEventFactory factory;
/*     */   
/*     */   public StAXEventAllocatorBase() {
/*  71 */     if (System.getProperty("javax.xml.stream.XMLEventFactory") == null) {
/*  72 */       System.setProperty("javax.xml.stream.XMLEventFactory", "com.sun.xml.fastinfoset.stax.StAXEventFactory");
/*     */     }
/*     */     
/*  75 */     this.factory = XMLEventFactory.newInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEventAllocator newInstance() {
/*  85 */     return new StAXEventAllocatorBase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent allocate(XMLStreamReader streamReader) throws XMLStreamException {
/*  96 */     if (streamReader == null)
/*  97 */       throw new XMLStreamException(CommonResourceBundle.getInstance().getString("message.nullReader")); 
/*  98 */     return getXMLEvent(streamReader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void allocate(XMLStreamReader streamReader, XMLEventConsumer consumer) throws XMLStreamException {
/* 109 */     consumer.add(getXMLEvent(streamReader));
/*     */   }
/*     */   XMLEvent getXMLEvent(XMLStreamReader reader) {
/*     */     StartElementEvent startElement;
/*     */     EndElementEvent endElement;
/*     */     StartDocumentEvent docEvent;
/*     */     EndDocumentEvent endDocumentEvent;
/* 116 */     XMLEvent event = null;
/*     */     
/* 118 */     int eventType = reader.getEventType();
/*     */     
/* 120 */     this.factory.setLocation(reader.getLocation());
/* 121 */     switch (eventType) {
/*     */ 
/*     */       
/*     */       case 1:
/* 125 */         startElement = (StartElementEvent)this.factory.createStartElement(reader.getPrefix(), reader.getNamespaceURI(), reader.getLocalName());
/*     */ 
/*     */         
/* 128 */         addAttributes(startElement, reader);
/* 129 */         addNamespaces(startElement, reader);
/*     */ 
/*     */         
/* 132 */         event = startElement;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 137 */         endElement = (EndElementEvent)this.factory.createEndElement(reader.getPrefix(), reader.getNamespaceURI(), reader.getLocalName());
/*     */         
/* 139 */         addNamespaces(endElement, reader);
/* 140 */         event = endElement;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/* 145 */         event = this.factory.createProcessingInstruction(reader.getPITarget(), reader.getPIData());
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 150 */         if (reader.isWhiteSpace()) {
/* 151 */           event = this.factory.createSpace(reader.getText()); break;
/*     */         } 
/* 153 */         event = this.factory.createCharacters(reader.getText());
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 159 */         event = this.factory.createComment(reader.getText());
/*     */         break;
/*     */ 
/*     */       
/*     */       case 7:
/* 164 */         docEvent = (StartDocumentEvent)this.factory.createStartDocument(reader.getVersion(), reader.getEncoding(), reader.isStandalone());
/*     */         
/* 166 */         if (reader.getCharacterEncodingScheme() != null) {
/* 167 */           docEvent.setDeclaredEncoding(true);
/*     */         } else {
/* 169 */           docEvent.setDeclaredEncoding(false);
/*     */         } 
/* 171 */         event = docEvent;
/*     */         break;
/*     */       
/*     */       case 8:
/* 175 */         endDocumentEvent = new EndDocumentEvent();
/* 176 */         event = endDocumentEvent;
/*     */         break;
/*     */       
/*     */       case 9:
/* 180 */         event = this.factory.createEntityReference(reader.getLocalName(), new EntityDeclarationImpl(reader.getLocalName(), reader.getText()));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 10:
/* 186 */         event = null;
/*     */         break;
/*     */       
/*     */       case 11:
/* 190 */         event = this.factory.createDTD(reader.getText());
/*     */         break;
/*     */       
/*     */       case 12:
/* 194 */         event = this.factory.createCData(reader.getText());
/*     */         break;
/*     */       
/*     */       case 6:
/* 198 */         event = this.factory.createSpace(reader.getText());
/*     */         break;
/*     */     } 
/*     */     
/* 202 */     return event;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addAttributes(StartElementEvent event, XMLStreamReader streamReader) {
/* 207 */     AttributeBase attr = null;
/* 208 */     for (int i = 0; i < streamReader.getAttributeCount(); i++) {
/* 209 */       attr = (AttributeBase)this.factory.createAttribute(streamReader.getAttributeName(i), streamReader.getAttributeValue(i));
/*     */       
/* 211 */       attr.setAttributeType(streamReader.getAttributeType(i));
/* 212 */       attr.setSpecified(streamReader.isAttributeSpecified(i));
/* 213 */       event.addAttribute(attr);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addNamespaces(StartElementEvent event, XMLStreamReader streamReader) {
/* 219 */     Namespace namespace = null;
/* 220 */     for (int i = 0; i < streamReader.getNamespaceCount(); i++) {
/* 221 */       namespace = this.factory.createNamespace(streamReader.getNamespacePrefix(i), streamReader.getNamespaceURI(i));
/*     */       
/* 223 */       event.addNamespace(namespace);
/*     */     } 
/*     */   }
/*     */   protected void addNamespaces(EndElementEvent event, XMLStreamReader streamReader) {
/* 227 */     Namespace namespace = null;
/* 228 */     for (int i = 0; i < streamReader.getNamespaceCount(); i++) {
/* 229 */       namespace = this.factory.createNamespace(streamReader.getNamespacePrefix(i), streamReader.getNamespaceURI(i));
/*     */       
/* 231 */       event.addNamespace(namespace);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\StAXEventAllocatorBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */