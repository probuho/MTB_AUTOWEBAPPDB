/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EndElementEvent
/*     */   extends EventBase
/*     */   implements EndElement
/*     */ {
/*  54 */   List _namespaces = null;
/*     */   QName _qname;
/*     */   
/*     */   public void reset() {
/*  58 */     if (this._namespaces != null) this._namespaces.clear(); 
/*     */   }
/*     */   
/*     */   public EndElementEvent() {
/*  62 */     setEventType(2);
/*     */   }
/*     */   
/*     */   public EndElementEvent(String namespaceURI, String localpart, String prefix) {
/*  66 */     this._qname = getQName(namespaceURI, localpart, prefix);
/*  67 */     setEventType(2);
/*     */   }
/*     */   
/*     */   public EndElementEvent(QName qname) {
/*  71 */     this._qname = qname;
/*  72 */     setEventType(2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getName() {
/*  80 */     return this._qname;
/*     */   }
/*     */   
/*     */   public void setName(QName qname) {
/*  84 */     this._qname = qname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getNamespaces() {
/*  95 */     if (this._namespaces != null)
/*  96 */       return this._namespaces.iterator(); 
/*  97 */     return EmptyIterator.getInstance();
/*     */   }
/*     */   
/*     */   public void addNamespace(Namespace namespace) {
/* 101 */     if (this._namespaces == null) {
/* 102 */       this._namespaces = new ArrayList();
/*     */     }
/* 104 */     this._namespaces.add(namespace);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 108 */     StringBuffer sb = new StringBuffer();
/* 109 */     sb.append("</").append(nameAsString());
/* 110 */     Iterator namespaces = getNamespaces();
/* 111 */     while (namespaces.hasNext()) {
/* 112 */       sb.append(" ").append(namespaces.next().toString());
/*     */     }
/* 114 */     sb.append(">");
/* 115 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String nameAsString() {
/* 120 */     if ("".equals(this._qname.getNamespaceURI()))
/* 121 */       return this._qname.getLocalPart(); 
/* 122 */     if (this._qname.getPrefix() != null) {
/* 123 */       return "['" + this._qname.getNamespaceURI() + "']:" + this._qname.getPrefix() + ":" + this._qname.getLocalPart();
/*     */     }
/* 125 */     return "['" + this._qname.getNamespaceURI() + "']:" + this._qname.getLocalPart();
/*     */   }
/*     */   private QName getQName(String uri, String localPart, String prefix) {
/* 128 */     QName qn = null;
/* 129 */     if (prefix != null && uri != null) {
/* 130 */       qn = new QName(uri, localPart, prefix);
/* 131 */     } else if (prefix == null && uri != null) {
/* 132 */       qn = new QName(uri, localPart);
/* 133 */     } else if (prefix == null && uri == null) {
/* 134 */       qn = new QName(localPart);
/* 135 */     }  return qn;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\EndElementEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */