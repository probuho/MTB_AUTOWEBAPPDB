/*    */ package com.sun.xml.fastinfoset.alphabet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BuiltInRestrictedAlphabets
/*    */ {
/* 46 */   public static final char[][] table = new char[2][];
/*    */ 
/*    */   
/*    */   static {
/* 50 */     table[0] = "0123456789-+.E ".toCharArray();
/* 51 */     table[1] = "0123456789-:TZ ".toCharArray();
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\alphabet\BuiltInRestrictedAlphabets.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */