/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.org.apache.xerces.util.XMLChar;
/*     */ import javax.xml.stream.events.Characters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharactersEvent
/*     */   extends EventBase
/*     */   implements Characters
/*     */ {
/*     */   private String _text;
/*     */   private boolean isCData = false;
/*     */   private boolean isSpace = false;
/*     */   private boolean isIgnorable = false;
/*     */   private boolean needtoCheck = true;
/*     */   
/*     */   public CharactersEvent() {
/*  55 */     super(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharactersEvent(String data) {
/*  62 */     super(4);
/*  63 */     this._text = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharactersEvent(String data, boolean isCData) {
/*  72 */     super(4);
/*  73 */     this._text = data;
/*  74 */     this.isCData = isCData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getData() {
/*  81 */     return this._text;
/*     */   }
/*     */   
/*     */   public void setData(String data) {
/*  85 */     this._text = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCData() {
/*  93 */     return this.isCData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 101 */     if (this.isCData) {
/* 102 */       return "<![CDATA[" + this._text + "]]>";
/*     */     }
/* 104 */     return this._text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnorableWhiteSpace() {
/* 114 */     return this.isIgnorable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWhiteSpace() {
/* 125 */     if (this.needtoCheck) {
/* 126 */       checkWhiteSpace();
/* 127 */       this.needtoCheck = false;
/*     */     } 
/* 129 */     return this.isSpace;
/*     */   }
/*     */   
/*     */   public void setSpace(boolean isSpace) {
/* 133 */     this.isSpace = isSpace;
/* 134 */     this.needtoCheck = false;
/*     */   }
/*     */   public void setIgnorable(boolean isIgnorable) {
/* 137 */     this.isIgnorable = isIgnorable;
/* 138 */     setEventType(6);
/*     */   }
/*     */   
/*     */   private void checkWhiteSpace() {
/* 142 */     if (!Util.isEmptyString(this._text)) {
/* 143 */       this.isSpace = true;
/* 144 */       for (int i = 0; i < this._text.length(); i++) {
/* 145 */         if (!XMLChar.isSpace(this._text.charAt(i))) {
/* 146 */           this.isSpace = false;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\CharactersEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */