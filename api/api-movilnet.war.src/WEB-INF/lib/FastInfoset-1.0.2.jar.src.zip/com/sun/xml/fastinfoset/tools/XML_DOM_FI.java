/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.dom.DOMDocumentSerializer;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XML_DOM_FI
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream document, OutputStream finf) throws Exception {
/* 17 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 18 */     dbf.setNamespaceAware(true);
/* 19 */     DocumentBuilder db = dbf.newDocumentBuilder();
/* 20 */     Document d = db.parse(document);
/*    */     
/* 22 */     DOMDocumentSerializer s = new DOMDocumentSerializer();
/* 23 */     s.setOutputStream(finf);
/* 24 */     s.serialize(d);
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 28 */     XML_DOM_FI p = new XML_DOM_FI();
/* 29 */     p.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\XML_DOM_FI.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */