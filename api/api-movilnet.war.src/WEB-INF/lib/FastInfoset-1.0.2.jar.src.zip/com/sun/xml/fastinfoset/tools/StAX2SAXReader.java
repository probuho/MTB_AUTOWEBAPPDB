/*     */ package com.sun.xml.fastinfoset.tools;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAX2SAXReader
/*     */ {
/*     */   ContentHandler _handler;
/*     */   LexicalHandler _lexicalHandler;
/*     */   XMLStreamReader _reader;
/*     */   
/*     */   public StAX2SAXReader(XMLStreamReader reader, ContentHandler handler) {
/*  70 */     this._handler = handler;
/*  71 */     this._reader = reader;
/*     */   }
/*     */   
/*     */   public StAX2SAXReader(XMLStreamReader reader) {
/*  75 */     this._reader = reader;
/*     */   }
/*     */   
/*     */   public void setContentHandler(ContentHandler handler) {
/*  79 */     this._handler = handler;
/*     */   }
/*     */   
/*     */   public void setLexicalHandler(LexicalHandler lexicalHandler) {
/*  83 */     this._lexicalHandler = lexicalHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void adapt() throws XMLStreamException, SAXException {
/*  89 */     AttributesImpl attrs = new AttributesImpl();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     this._handler.startDocument();
/*     */ 
/*     */     
/*     */     try {
/*  98 */       while (this._reader.hasNext()) {
/*  99 */         QName qname; String prefix, localPart; int nsc, nat, i, event = this._reader.next();
/*     */ 
/*     */         
/* 102 */         switch (event) {
/*     */           
/*     */           case 1:
/* 105 */             nsc = this._reader.getNamespaceCount();
/* 106 */             for (i = 0; i < nsc; i++) {
/* 107 */               this._handler.startPrefixMapping(this._reader.getNamespacePrefix(i), this._reader.getNamespaceURI(i));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 112 */             attrs.clear();
/* 113 */             nat = this._reader.getAttributeCount();
/* 114 */             for (i = 0; i < nat; i++) {
/* 115 */               QName q = this._reader.getAttributeName(i);
/* 116 */               String qName = this._reader.getAttributePrefix(i);
/* 117 */               if (qName == null || qName == "") {
/* 118 */                 qName = q.getLocalPart();
/*     */               } else {
/* 120 */                 qName = qName + ":" + q.getLocalPart();
/*     */               } 
/* 122 */               attrs.addAttribute(this._reader.getAttributeNamespace(i), q.getLocalPart(), qName, this._reader.getAttributeType(i), this._reader.getAttributeValue(i));
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 130 */             qname = this._reader.getName();
/* 131 */             prefix = qname.getPrefix();
/* 132 */             localPart = qname.getLocalPart();
/*     */             
/* 134 */             this._handler.startElement(this._reader.getNamespaceURI(), localPart, (prefix.length() > 0) ? (prefix + ":" + localPart) : localPart, attrs);
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 2:
/* 143 */             qname = this._reader.getName();
/* 144 */             prefix = qname.getPrefix();
/* 145 */             localPart = qname.getLocalPart();
/*     */             
/* 147 */             this._handler.endElement(this._reader.getNamespaceURI(), localPart, (prefix.length() > 0) ? (prefix + ":" + localPart) : localPart);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 153 */             nsc = this._reader.getNamespaceCount();
/* 154 */             for (i = 0; i < nsc; i++) {
/* 155 */               this._handler.endPrefixMapping(this._reader.getNamespacePrefix(i));
/*     */             }
/*     */             continue;
/*     */           
/*     */           case 4:
/* 160 */             this._handler.characters(this._reader.getTextCharacters(), this._reader.getTextStart(), this._reader.getTextLength());
/*     */             continue;
/*     */           case 5:
/* 163 */             this._lexicalHandler.comment(this._reader.getTextCharacters(), this._reader.getTextStart(), this._reader.getTextLength());
/*     */             continue;
/*     */           case 3:
/* 166 */             this._handler.processingInstruction(this._reader.getPITarget(), this._reader.getPIData());
/*     */             continue;
/*     */           case 8:
/*     */             continue;
/*     */         } 
/* 171 */         throw new RuntimeException(CommonResourceBundle.getInstance().getString("message.StAX2SAXReader", new Object[] { new Integer(event) }));
/*     */       }
/*     */     
/*     */     }
/* 175 */     catch (XMLStreamException e) {
/* 176 */       this._handler.endDocument();
/* 177 */       throw e;
/*     */     } 
/*     */     
/* 180 */     this._handler.endDocument();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\StAX2SAXReader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */