/*     */ package com.sun.xml.fastinfoset.stax.events;
/*     */ 
/*     */ import javax.xml.stream.events.EntityDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityDeclarationImpl
/*     */   extends EventBase
/*     */   implements EntityDeclaration
/*     */ {
/*     */   private String _publicId;
/*     */   private String _systemId;
/*     */   private String _baseURI;
/*     */   private String _entityName;
/*     */   private String _replacement;
/*     */   private String _notationName;
/*     */   
/*     */   public EntityDeclarationImpl() {
/*  54 */     init();
/*     */   }
/*     */   
/*     */   public EntityDeclarationImpl(String entityName, String replacement) {
/*  58 */     init();
/*  59 */     this._entityName = entityName;
/*  60 */     this._replacement = replacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPublicId() {
/*  68 */     return this._publicId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSystemId() {
/*  76 */     return this._systemId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  84 */     return this._entityName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNotationName() {
/*  92 */     return this._notationName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReplacementText() {
/* 102 */     return this._replacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseURI() {
/* 111 */     return this._baseURI;
/*     */   }
/*     */   
/*     */   public void setName(String entityName) {
/* 115 */     this._entityName = entityName;
/*     */   }
/*     */   
/*     */   public void setReplacementText(String replacement) {
/* 119 */     this._replacement = replacement;
/*     */   }
/*     */   
/*     */   public void setNotationName(String notationName) {
/* 123 */     this._notationName = notationName;
/*     */   }
/*     */   
/*     */   protected void init() {
/* 127 */     setEventType(15);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\events\EntityDeclarationImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */