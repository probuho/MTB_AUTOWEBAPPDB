/*      */ package com.sun.xml.fastinfoset.org.apache.xerces.util;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XMLChar
/*      */ {
/*  131 */   private static final byte[] CHARS = new byte[65536];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_VALID = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_SPACE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_NAME_START = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_NAME = 8;
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_PUBID = 16;
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_CONTENT = 32;
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_NCNAME_START = 64;
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MASK_NCNAME = 128;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  173 */     CHARS[9] = 35;
/*  174 */     CHARS[10] = 19;
/*  175 */     CHARS[13] = 19;
/*  176 */     CHARS[32] = 51;
/*  177 */     CHARS[33] = 49;
/*  178 */     CHARS[34] = 33;
/*  179 */     Arrays.fill(CHARS, 35, 38, (byte)49);
/*  180 */     CHARS[38] = 1;
/*  181 */     Arrays.fill(CHARS, 39, 45, (byte)49);
/*  182 */     Arrays.fill(CHARS, 45, 47, (byte)-71);
/*  183 */     CHARS[47] = 49;
/*  184 */     Arrays.fill(CHARS, 48, 58, (byte)-71);
/*  185 */     CHARS[58] = 61;
/*  186 */     CHARS[59] = 49;
/*  187 */     CHARS[60] = 1;
/*  188 */     CHARS[61] = 49;
/*  189 */     CHARS[62] = 33;
/*  190 */     Arrays.fill(CHARS, 63, 65, (byte)49);
/*  191 */     Arrays.fill(CHARS, 65, 91, (byte)-3);
/*  192 */     Arrays.fill(CHARS, 91, 93, (byte)33);
/*  193 */     CHARS[93] = 1;
/*  194 */     CHARS[94] = 33;
/*  195 */     CHARS[95] = -3;
/*  196 */     CHARS[96] = 33;
/*  197 */     Arrays.fill(CHARS, 97, 123, (byte)-3);
/*  198 */     Arrays.fill(CHARS, 123, 183, (byte)33);
/*  199 */     CHARS[183] = -87;
/*  200 */     Arrays.fill(CHARS, 184, 192, (byte)33);
/*  201 */     Arrays.fill(CHARS, 192, 215, (byte)-19);
/*  202 */     CHARS[215] = 33;
/*  203 */     Arrays.fill(CHARS, 216, 247, (byte)-19);
/*  204 */     CHARS[247] = 33;
/*  205 */     Arrays.fill(CHARS, 248, 306, (byte)-19);
/*  206 */     Arrays.fill(CHARS, 306, 308, (byte)33);
/*  207 */     Arrays.fill(CHARS, 308, 319, (byte)-19);
/*  208 */     Arrays.fill(CHARS, 319, 321, (byte)33);
/*  209 */     Arrays.fill(CHARS, 321, 329, (byte)-19);
/*  210 */     CHARS[329] = 33;
/*  211 */     Arrays.fill(CHARS, 330, 383, (byte)-19);
/*  212 */     CHARS[383] = 33;
/*  213 */     Arrays.fill(CHARS, 384, 452, (byte)-19);
/*  214 */     Arrays.fill(CHARS, 452, 461, (byte)33);
/*  215 */     Arrays.fill(CHARS, 461, 497, (byte)-19);
/*  216 */     Arrays.fill(CHARS, 497, 500, (byte)33);
/*  217 */     Arrays.fill(CHARS, 500, 502, (byte)-19);
/*  218 */     Arrays.fill(CHARS, 502, 506, (byte)33);
/*  219 */     Arrays.fill(CHARS, 506, 536, (byte)-19);
/*  220 */     Arrays.fill(CHARS, 536, 592, (byte)33);
/*  221 */     Arrays.fill(CHARS, 592, 681, (byte)-19);
/*  222 */     Arrays.fill(CHARS, 681, 699, (byte)33);
/*  223 */     Arrays.fill(CHARS, 699, 706, (byte)-19);
/*  224 */     Arrays.fill(CHARS, 706, 720, (byte)33);
/*  225 */     Arrays.fill(CHARS, 720, 722, (byte)-87);
/*  226 */     Arrays.fill(CHARS, 722, 768, (byte)33);
/*  227 */     Arrays.fill(CHARS, 768, 838, (byte)-87);
/*  228 */     Arrays.fill(CHARS, 838, 864, (byte)33);
/*  229 */     Arrays.fill(CHARS, 864, 866, (byte)-87);
/*  230 */     Arrays.fill(CHARS, 866, 902, (byte)33);
/*  231 */     CHARS[902] = -19;
/*  232 */     CHARS[903] = -87;
/*  233 */     Arrays.fill(CHARS, 904, 907, (byte)-19);
/*  234 */     CHARS[907] = 33;
/*  235 */     CHARS[908] = -19;
/*  236 */     CHARS[909] = 33;
/*  237 */     Arrays.fill(CHARS, 910, 930, (byte)-19);
/*  238 */     CHARS[930] = 33;
/*  239 */     Arrays.fill(CHARS, 931, 975, (byte)-19);
/*  240 */     CHARS[975] = 33;
/*  241 */     Arrays.fill(CHARS, 976, 983, (byte)-19);
/*  242 */     Arrays.fill(CHARS, 983, 986, (byte)33);
/*  243 */     CHARS[986] = -19;
/*  244 */     CHARS[987] = 33;
/*  245 */     CHARS[988] = -19;
/*  246 */     CHARS[989] = 33;
/*  247 */     CHARS[990] = -19;
/*  248 */     CHARS[991] = 33;
/*  249 */     CHARS[992] = -19;
/*  250 */     CHARS[993] = 33;
/*  251 */     Arrays.fill(CHARS, 994, 1012, (byte)-19);
/*  252 */     Arrays.fill(CHARS, 1012, 1025, (byte)33);
/*  253 */     Arrays.fill(CHARS, 1025, 1037, (byte)-19);
/*  254 */     CHARS[1037] = 33;
/*  255 */     Arrays.fill(CHARS, 1038, 1104, (byte)-19);
/*  256 */     CHARS[1104] = 33;
/*  257 */     Arrays.fill(CHARS, 1105, 1117, (byte)-19);
/*  258 */     CHARS[1117] = 33;
/*  259 */     Arrays.fill(CHARS, 1118, 1154, (byte)-19);
/*  260 */     CHARS[1154] = 33;
/*  261 */     Arrays.fill(CHARS, 1155, 1159, (byte)-87);
/*  262 */     Arrays.fill(CHARS, 1159, 1168, (byte)33);
/*  263 */     Arrays.fill(CHARS, 1168, 1221, (byte)-19);
/*  264 */     Arrays.fill(CHARS, 1221, 1223, (byte)33);
/*  265 */     Arrays.fill(CHARS, 1223, 1225, (byte)-19);
/*  266 */     Arrays.fill(CHARS, 1225, 1227, (byte)33);
/*  267 */     Arrays.fill(CHARS, 1227, 1229, (byte)-19);
/*  268 */     Arrays.fill(CHARS, 1229, 1232, (byte)33);
/*  269 */     Arrays.fill(CHARS, 1232, 1260, (byte)-19);
/*  270 */     Arrays.fill(CHARS, 1260, 1262, (byte)33);
/*  271 */     Arrays.fill(CHARS, 1262, 1270, (byte)-19);
/*  272 */     Arrays.fill(CHARS, 1270, 1272, (byte)33);
/*  273 */     Arrays.fill(CHARS, 1272, 1274, (byte)-19);
/*  274 */     Arrays.fill(CHARS, 1274, 1329, (byte)33);
/*  275 */     Arrays.fill(CHARS, 1329, 1367, (byte)-19);
/*  276 */     Arrays.fill(CHARS, 1367, 1369, (byte)33);
/*  277 */     CHARS[1369] = -19;
/*  278 */     Arrays.fill(CHARS, 1370, 1377, (byte)33);
/*  279 */     Arrays.fill(CHARS, 1377, 1415, (byte)-19);
/*  280 */     Arrays.fill(CHARS, 1415, 1425, (byte)33);
/*  281 */     Arrays.fill(CHARS, 1425, 1442, (byte)-87);
/*  282 */     CHARS[1442] = 33;
/*  283 */     Arrays.fill(CHARS, 1443, 1466, (byte)-87);
/*  284 */     CHARS[1466] = 33;
/*  285 */     Arrays.fill(CHARS, 1467, 1470, (byte)-87);
/*  286 */     CHARS[1470] = 33;
/*  287 */     CHARS[1471] = -87;
/*  288 */     CHARS[1472] = 33;
/*  289 */     Arrays.fill(CHARS, 1473, 1475, (byte)-87);
/*  290 */     CHARS[1475] = 33;
/*  291 */     CHARS[1476] = -87;
/*  292 */     Arrays.fill(CHARS, 1477, 1488, (byte)33);
/*  293 */     Arrays.fill(CHARS, 1488, 1515, (byte)-19);
/*  294 */     Arrays.fill(CHARS, 1515, 1520, (byte)33);
/*  295 */     Arrays.fill(CHARS, 1520, 1523, (byte)-19);
/*  296 */     Arrays.fill(CHARS, 1523, 1569, (byte)33);
/*  297 */     Arrays.fill(CHARS, 1569, 1595, (byte)-19);
/*  298 */     Arrays.fill(CHARS, 1595, 1600, (byte)33);
/*  299 */     CHARS[1600] = -87;
/*  300 */     Arrays.fill(CHARS, 1601, 1611, (byte)-19);
/*  301 */     Arrays.fill(CHARS, 1611, 1619, (byte)-87);
/*  302 */     Arrays.fill(CHARS, 1619, 1632, (byte)33);
/*  303 */     Arrays.fill(CHARS, 1632, 1642, (byte)-87);
/*  304 */     Arrays.fill(CHARS, 1642, 1648, (byte)33);
/*  305 */     CHARS[1648] = -87;
/*  306 */     Arrays.fill(CHARS, 1649, 1720, (byte)-19);
/*  307 */     Arrays.fill(CHARS, 1720, 1722, (byte)33);
/*  308 */     Arrays.fill(CHARS, 1722, 1727, (byte)-19);
/*  309 */     CHARS[1727] = 33;
/*  310 */     Arrays.fill(CHARS, 1728, 1743, (byte)-19);
/*  311 */     CHARS[1743] = 33;
/*  312 */     Arrays.fill(CHARS, 1744, 1748, (byte)-19);
/*  313 */     CHARS[1748] = 33;
/*  314 */     CHARS[1749] = -19;
/*  315 */     Arrays.fill(CHARS, 1750, 1765, (byte)-87);
/*  316 */     Arrays.fill(CHARS, 1765, 1767, (byte)-19);
/*  317 */     Arrays.fill(CHARS, 1767, 1769, (byte)-87);
/*  318 */     CHARS[1769] = 33;
/*  319 */     Arrays.fill(CHARS, 1770, 1774, (byte)-87);
/*  320 */     Arrays.fill(CHARS, 1774, 1776, (byte)33);
/*  321 */     Arrays.fill(CHARS, 1776, 1786, (byte)-87);
/*  322 */     Arrays.fill(CHARS, 1786, 2305, (byte)33);
/*  323 */     Arrays.fill(CHARS, 2305, 2308, (byte)-87);
/*  324 */     CHARS[2308] = 33;
/*  325 */     Arrays.fill(CHARS, 2309, 2362, (byte)-19);
/*  326 */     Arrays.fill(CHARS, 2362, 2364, (byte)33);
/*  327 */     CHARS[2364] = -87;
/*  328 */     CHARS[2365] = -19;
/*  329 */     Arrays.fill(CHARS, 2366, 2382, (byte)-87);
/*  330 */     Arrays.fill(CHARS, 2382, 2385, (byte)33);
/*  331 */     Arrays.fill(CHARS, 2385, 2389, (byte)-87);
/*  332 */     Arrays.fill(CHARS, 2389, 2392, (byte)33);
/*  333 */     Arrays.fill(CHARS, 2392, 2402, (byte)-19);
/*  334 */     Arrays.fill(CHARS, 2402, 2404, (byte)-87);
/*  335 */     Arrays.fill(CHARS, 2404, 2406, (byte)33);
/*  336 */     Arrays.fill(CHARS, 2406, 2416, (byte)-87);
/*  337 */     Arrays.fill(CHARS, 2416, 2433, (byte)33);
/*  338 */     Arrays.fill(CHARS, 2433, 2436, (byte)-87);
/*  339 */     CHARS[2436] = 33;
/*  340 */     Arrays.fill(CHARS, 2437, 2445, (byte)-19);
/*  341 */     Arrays.fill(CHARS, 2445, 2447, (byte)33);
/*  342 */     Arrays.fill(CHARS, 2447, 2449, (byte)-19);
/*  343 */     Arrays.fill(CHARS, 2449, 2451, (byte)33);
/*  344 */     Arrays.fill(CHARS, 2451, 2473, (byte)-19);
/*  345 */     CHARS[2473] = 33;
/*  346 */     Arrays.fill(CHARS, 2474, 2481, (byte)-19);
/*  347 */     CHARS[2481] = 33;
/*  348 */     CHARS[2482] = -19;
/*  349 */     Arrays.fill(CHARS, 2483, 2486, (byte)33);
/*  350 */     Arrays.fill(CHARS, 2486, 2490, (byte)-19);
/*  351 */     Arrays.fill(CHARS, 2490, 2492, (byte)33);
/*  352 */     CHARS[2492] = -87;
/*  353 */     CHARS[2493] = 33;
/*  354 */     Arrays.fill(CHARS, 2494, 2501, (byte)-87);
/*  355 */     Arrays.fill(CHARS, 2501, 2503, (byte)33);
/*  356 */     Arrays.fill(CHARS, 2503, 2505, (byte)-87);
/*  357 */     Arrays.fill(CHARS, 2505, 2507, (byte)33);
/*  358 */     Arrays.fill(CHARS, 2507, 2510, (byte)-87);
/*  359 */     Arrays.fill(CHARS, 2510, 2519, (byte)33);
/*  360 */     CHARS[2519] = -87;
/*  361 */     Arrays.fill(CHARS, 2520, 2524, (byte)33);
/*  362 */     Arrays.fill(CHARS, 2524, 2526, (byte)-19);
/*  363 */     CHARS[2526] = 33;
/*  364 */     Arrays.fill(CHARS, 2527, 2530, (byte)-19);
/*  365 */     Arrays.fill(CHARS, 2530, 2532, (byte)-87);
/*  366 */     Arrays.fill(CHARS, 2532, 2534, (byte)33);
/*  367 */     Arrays.fill(CHARS, 2534, 2544, (byte)-87);
/*  368 */     Arrays.fill(CHARS, 2544, 2546, (byte)-19);
/*  369 */     Arrays.fill(CHARS, 2546, 2562, (byte)33);
/*  370 */     CHARS[2562] = -87;
/*  371 */     Arrays.fill(CHARS, 2563, 2565, (byte)33);
/*  372 */     Arrays.fill(CHARS, 2565, 2571, (byte)-19);
/*  373 */     Arrays.fill(CHARS, 2571, 2575, (byte)33);
/*  374 */     Arrays.fill(CHARS, 2575, 2577, (byte)-19);
/*  375 */     Arrays.fill(CHARS, 2577, 2579, (byte)33);
/*  376 */     Arrays.fill(CHARS, 2579, 2601, (byte)-19);
/*  377 */     CHARS[2601] = 33;
/*  378 */     Arrays.fill(CHARS, 2602, 2609, (byte)-19);
/*  379 */     CHARS[2609] = 33;
/*  380 */     Arrays.fill(CHARS, 2610, 2612, (byte)-19);
/*  381 */     CHARS[2612] = 33;
/*  382 */     Arrays.fill(CHARS, 2613, 2615, (byte)-19);
/*  383 */     CHARS[2615] = 33;
/*  384 */     Arrays.fill(CHARS, 2616, 2618, (byte)-19);
/*  385 */     Arrays.fill(CHARS, 2618, 2620, (byte)33);
/*  386 */     CHARS[2620] = -87;
/*  387 */     CHARS[2621] = 33;
/*  388 */     Arrays.fill(CHARS, 2622, 2627, (byte)-87);
/*  389 */     Arrays.fill(CHARS, 2627, 2631, (byte)33);
/*  390 */     Arrays.fill(CHARS, 2631, 2633, (byte)-87);
/*  391 */     Arrays.fill(CHARS, 2633, 2635, (byte)33);
/*  392 */     Arrays.fill(CHARS, 2635, 2638, (byte)-87);
/*  393 */     Arrays.fill(CHARS, 2638, 2649, (byte)33);
/*  394 */     Arrays.fill(CHARS, 2649, 2653, (byte)-19);
/*  395 */     CHARS[2653] = 33;
/*  396 */     CHARS[2654] = -19;
/*  397 */     Arrays.fill(CHARS, 2655, 2662, (byte)33);
/*  398 */     Arrays.fill(CHARS, 2662, 2674, (byte)-87);
/*  399 */     Arrays.fill(CHARS, 2674, 2677, (byte)-19);
/*  400 */     Arrays.fill(CHARS, 2677, 2689, (byte)33);
/*  401 */     Arrays.fill(CHARS, 2689, 2692, (byte)-87);
/*  402 */     CHARS[2692] = 33;
/*  403 */     Arrays.fill(CHARS, 2693, 2700, (byte)-19);
/*  404 */     CHARS[2700] = 33;
/*  405 */     CHARS[2701] = -19;
/*  406 */     CHARS[2702] = 33;
/*  407 */     Arrays.fill(CHARS, 2703, 2706, (byte)-19);
/*  408 */     CHARS[2706] = 33;
/*  409 */     Arrays.fill(CHARS, 2707, 2729, (byte)-19);
/*  410 */     CHARS[2729] = 33;
/*  411 */     Arrays.fill(CHARS, 2730, 2737, (byte)-19);
/*  412 */     CHARS[2737] = 33;
/*  413 */     Arrays.fill(CHARS, 2738, 2740, (byte)-19);
/*  414 */     CHARS[2740] = 33;
/*  415 */     Arrays.fill(CHARS, 2741, 2746, (byte)-19);
/*  416 */     Arrays.fill(CHARS, 2746, 2748, (byte)33);
/*  417 */     CHARS[2748] = -87;
/*  418 */     CHARS[2749] = -19;
/*  419 */     Arrays.fill(CHARS, 2750, 2758, (byte)-87);
/*  420 */     CHARS[2758] = 33;
/*  421 */     Arrays.fill(CHARS, 2759, 2762, (byte)-87);
/*  422 */     CHARS[2762] = 33;
/*  423 */     Arrays.fill(CHARS, 2763, 2766, (byte)-87);
/*  424 */     Arrays.fill(CHARS, 2766, 2784, (byte)33);
/*  425 */     CHARS[2784] = -19;
/*  426 */     Arrays.fill(CHARS, 2785, 2790, (byte)33);
/*  427 */     Arrays.fill(CHARS, 2790, 2800, (byte)-87);
/*  428 */     Arrays.fill(CHARS, 2800, 2817, (byte)33);
/*  429 */     Arrays.fill(CHARS, 2817, 2820, (byte)-87);
/*  430 */     CHARS[2820] = 33;
/*  431 */     Arrays.fill(CHARS, 2821, 2829, (byte)-19);
/*  432 */     Arrays.fill(CHARS, 2829, 2831, (byte)33);
/*  433 */     Arrays.fill(CHARS, 2831, 2833, (byte)-19);
/*  434 */     Arrays.fill(CHARS, 2833, 2835, (byte)33);
/*  435 */     Arrays.fill(CHARS, 2835, 2857, (byte)-19);
/*  436 */     CHARS[2857] = 33;
/*  437 */     Arrays.fill(CHARS, 2858, 2865, (byte)-19);
/*  438 */     CHARS[2865] = 33;
/*  439 */     Arrays.fill(CHARS, 2866, 2868, (byte)-19);
/*  440 */     Arrays.fill(CHARS, 2868, 2870, (byte)33);
/*  441 */     Arrays.fill(CHARS, 2870, 2874, (byte)-19);
/*  442 */     Arrays.fill(CHARS, 2874, 2876, (byte)33);
/*  443 */     CHARS[2876] = -87;
/*  444 */     CHARS[2877] = -19;
/*  445 */     Arrays.fill(CHARS, 2878, 2884, (byte)-87);
/*  446 */     Arrays.fill(CHARS, 2884, 2887, (byte)33);
/*  447 */     Arrays.fill(CHARS, 2887, 2889, (byte)-87);
/*  448 */     Arrays.fill(CHARS, 2889, 2891, (byte)33);
/*  449 */     Arrays.fill(CHARS, 2891, 2894, (byte)-87);
/*  450 */     Arrays.fill(CHARS, 2894, 2902, (byte)33);
/*  451 */     Arrays.fill(CHARS, 2902, 2904, (byte)-87);
/*  452 */     Arrays.fill(CHARS, 2904, 2908, (byte)33);
/*  453 */     Arrays.fill(CHARS, 2908, 2910, (byte)-19);
/*  454 */     CHARS[2910] = 33;
/*  455 */     Arrays.fill(CHARS, 2911, 2914, (byte)-19);
/*  456 */     Arrays.fill(CHARS, 2914, 2918, (byte)33);
/*  457 */     Arrays.fill(CHARS, 2918, 2928, (byte)-87);
/*  458 */     Arrays.fill(CHARS, 2928, 2946, (byte)33);
/*  459 */     Arrays.fill(CHARS, 2946, 2948, (byte)-87);
/*  460 */     CHARS[2948] = 33;
/*  461 */     Arrays.fill(CHARS, 2949, 2955, (byte)-19);
/*  462 */     Arrays.fill(CHARS, 2955, 2958, (byte)33);
/*  463 */     Arrays.fill(CHARS, 2958, 2961, (byte)-19);
/*  464 */     CHARS[2961] = 33;
/*  465 */     Arrays.fill(CHARS, 2962, 2966, (byte)-19);
/*  466 */     Arrays.fill(CHARS, 2966, 2969, (byte)33);
/*  467 */     Arrays.fill(CHARS, 2969, 2971, (byte)-19);
/*  468 */     CHARS[2971] = 33;
/*  469 */     CHARS[2972] = -19;
/*  470 */     CHARS[2973] = 33;
/*  471 */     Arrays.fill(CHARS, 2974, 2976, (byte)-19);
/*  472 */     Arrays.fill(CHARS, 2976, 2979, (byte)33);
/*  473 */     Arrays.fill(CHARS, 2979, 2981, (byte)-19);
/*  474 */     Arrays.fill(CHARS, 2981, 2984, (byte)33);
/*  475 */     Arrays.fill(CHARS, 2984, 2987, (byte)-19);
/*  476 */     Arrays.fill(CHARS, 2987, 2990, (byte)33);
/*  477 */     Arrays.fill(CHARS, 2990, 2998, (byte)-19);
/*  478 */     CHARS[2998] = 33;
/*  479 */     Arrays.fill(CHARS, 2999, 3002, (byte)-19);
/*  480 */     Arrays.fill(CHARS, 3002, 3006, (byte)33);
/*  481 */     Arrays.fill(CHARS, 3006, 3011, (byte)-87);
/*  482 */     Arrays.fill(CHARS, 3011, 3014, (byte)33);
/*  483 */     Arrays.fill(CHARS, 3014, 3017, (byte)-87);
/*  484 */     CHARS[3017] = 33;
/*  485 */     Arrays.fill(CHARS, 3018, 3022, (byte)-87);
/*  486 */     Arrays.fill(CHARS, 3022, 3031, (byte)33);
/*  487 */     CHARS[3031] = -87;
/*  488 */     Arrays.fill(CHARS, 3032, 3047, (byte)33);
/*  489 */     Arrays.fill(CHARS, 3047, 3056, (byte)-87);
/*  490 */     Arrays.fill(CHARS, 3056, 3073, (byte)33);
/*  491 */     Arrays.fill(CHARS, 3073, 3076, (byte)-87);
/*  492 */     CHARS[3076] = 33;
/*  493 */     Arrays.fill(CHARS, 3077, 3085, (byte)-19);
/*  494 */     CHARS[3085] = 33;
/*  495 */     Arrays.fill(CHARS, 3086, 3089, (byte)-19);
/*  496 */     CHARS[3089] = 33;
/*  497 */     Arrays.fill(CHARS, 3090, 3113, (byte)-19);
/*  498 */     CHARS[3113] = 33;
/*  499 */     Arrays.fill(CHARS, 3114, 3124, (byte)-19);
/*  500 */     CHARS[3124] = 33;
/*  501 */     Arrays.fill(CHARS, 3125, 3130, (byte)-19);
/*  502 */     Arrays.fill(CHARS, 3130, 3134, (byte)33);
/*  503 */     Arrays.fill(CHARS, 3134, 3141, (byte)-87);
/*  504 */     CHARS[3141] = 33;
/*  505 */     Arrays.fill(CHARS, 3142, 3145, (byte)-87);
/*  506 */     CHARS[3145] = 33;
/*  507 */     Arrays.fill(CHARS, 3146, 3150, (byte)-87);
/*  508 */     Arrays.fill(CHARS, 3150, 3157, (byte)33);
/*  509 */     Arrays.fill(CHARS, 3157, 3159, (byte)-87);
/*  510 */     Arrays.fill(CHARS, 3159, 3168, (byte)33);
/*  511 */     Arrays.fill(CHARS, 3168, 3170, (byte)-19);
/*  512 */     Arrays.fill(CHARS, 3170, 3174, (byte)33);
/*  513 */     Arrays.fill(CHARS, 3174, 3184, (byte)-87);
/*  514 */     Arrays.fill(CHARS, 3184, 3202, (byte)33);
/*  515 */     Arrays.fill(CHARS, 3202, 3204, (byte)-87);
/*  516 */     CHARS[3204] = 33;
/*  517 */     Arrays.fill(CHARS, 3205, 3213, (byte)-19);
/*  518 */     CHARS[3213] = 33;
/*  519 */     Arrays.fill(CHARS, 3214, 3217, (byte)-19);
/*  520 */     CHARS[3217] = 33;
/*  521 */     Arrays.fill(CHARS, 3218, 3241, (byte)-19);
/*  522 */     CHARS[3241] = 33;
/*  523 */     Arrays.fill(CHARS, 3242, 3252, (byte)-19);
/*  524 */     CHARS[3252] = 33;
/*  525 */     Arrays.fill(CHARS, 3253, 3258, (byte)-19);
/*  526 */     Arrays.fill(CHARS, 3258, 3262, (byte)33);
/*  527 */     Arrays.fill(CHARS, 3262, 3269, (byte)-87);
/*  528 */     CHARS[3269] = 33;
/*  529 */     Arrays.fill(CHARS, 3270, 3273, (byte)-87);
/*  530 */     CHARS[3273] = 33;
/*  531 */     Arrays.fill(CHARS, 3274, 3278, (byte)-87);
/*  532 */     Arrays.fill(CHARS, 3278, 3285, (byte)33);
/*  533 */     Arrays.fill(CHARS, 3285, 3287, (byte)-87);
/*  534 */     Arrays.fill(CHARS, 3287, 3294, (byte)33);
/*  535 */     CHARS[3294] = -19;
/*  536 */     CHARS[3295] = 33;
/*  537 */     Arrays.fill(CHARS, 3296, 3298, (byte)-19);
/*  538 */     Arrays.fill(CHARS, 3298, 3302, (byte)33);
/*  539 */     Arrays.fill(CHARS, 3302, 3312, (byte)-87);
/*  540 */     Arrays.fill(CHARS, 3312, 3330, (byte)33);
/*  541 */     Arrays.fill(CHARS, 3330, 3332, (byte)-87);
/*  542 */     CHARS[3332] = 33;
/*  543 */     Arrays.fill(CHARS, 3333, 3341, (byte)-19);
/*  544 */     CHARS[3341] = 33;
/*  545 */     Arrays.fill(CHARS, 3342, 3345, (byte)-19);
/*  546 */     CHARS[3345] = 33;
/*  547 */     Arrays.fill(CHARS, 3346, 3369, (byte)-19);
/*  548 */     CHARS[3369] = 33;
/*  549 */     Arrays.fill(CHARS, 3370, 3386, (byte)-19);
/*  550 */     Arrays.fill(CHARS, 3386, 3390, (byte)33);
/*  551 */     Arrays.fill(CHARS, 3390, 3396, (byte)-87);
/*  552 */     Arrays.fill(CHARS, 3396, 3398, (byte)33);
/*  553 */     Arrays.fill(CHARS, 3398, 3401, (byte)-87);
/*  554 */     CHARS[3401] = 33;
/*  555 */     Arrays.fill(CHARS, 3402, 3406, (byte)-87);
/*  556 */     Arrays.fill(CHARS, 3406, 3415, (byte)33);
/*  557 */     CHARS[3415] = -87;
/*  558 */     Arrays.fill(CHARS, 3416, 3424, (byte)33);
/*  559 */     Arrays.fill(CHARS, 3424, 3426, (byte)-19);
/*  560 */     Arrays.fill(CHARS, 3426, 3430, (byte)33);
/*  561 */     Arrays.fill(CHARS, 3430, 3440, (byte)-87);
/*  562 */     Arrays.fill(CHARS, 3440, 3585, (byte)33);
/*  563 */     Arrays.fill(CHARS, 3585, 3631, (byte)-19);
/*  564 */     CHARS[3631] = 33;
/*  565 */     CHARS[3632] = -19;
/*  566 */     CHARS[3633] = -87;
/*  567 */     Arrays.fill(CHARS, 3634, 3636, (byte)-19);
/*  568 */     Arrays.fill(CHARS, 3636, 3643, (byte)-87);
/*  569 */     Arrays.fill(CHARS, 3643, 3648, (byte)33);
/*  570 */     Arrays.fill(CHARS, 3648, 3654, (byte)-19);
/*  571 */     Arrays.fill(CHARS, 3654, 3663, (byte)-87);
/*  572 */     CHARS[3663] = 33;
/*  573 */     Arrays.fill(CHARS, 3664, 3674, (byte)-87);
/*  574 */     Arrays.fill(CHARS, 3674, 3713, (byte)33);
/*  575 */     Arrays.fill(CHARS, 3713, 3715, (byte)-19);
/*  576 */     CHARS[3715] = 33;
/*  577 */     CHARS[3716] = -19;
/*  578 */     Arrays.fill(CHARS, 3717, 3719, (byte)33);
/*  579 */     Arrays.fill(CHARS, 3719, 3721, (byte)-19);
/*  580 */     CHARS[3721] = 33;
/*  581 */     CHARS[3722] = -19;
/*  582 */     Arrays.fill(CHARS, 3723, 3725, (byte)33);
/*  583 */     CHARS[3725] = -19;
/*  584 */     Arrays.fill(CHARS, 3726, 3732, (byte)33);
/*  585 */     Arrays.fill(CHARS, 3732, 3736, (byte)-19);
/*  586 */     CHARS[3736] = 33;
/*  587 */     Arrays.fill(CHARS, 3737, 3744, (byte)-19);
/*  588 */     CHARS[3744] = 33;
/*  589 */     Arrays.fill(CHARS, 3745, 3748, (byte)-19);
/*  590 */     CHARS[3748] = 33;
/*  591 */     CHARS[3749] = -19;
/*  592 */     CHARS[3750] = 33;
/*  593 */     CHARS[3751] = -19;
/*  594 */     Arrays.fill(CHARS, 3752, 3754, (byte)33);
/*  595 */     Arrays.fill(CHARS, 3754, 3756, (byte)-19);
/*  596 */     CHARS[3756] = 33;
/*  597 */     Arrays.fill(CHARS, 3757, 3759, (byte)-19);
/*  598 */     CHARS[3759] = 33;
/*  599 */     CHARS[3760] = -19;
/*  600 */     CHARS[3761] = -87;
/*  601 */     Arrays.fill(CHARS, 3762, 3764, (byte)-19);
/*  602 */     Arrays.fill(CHARS, 3764, 3770, (byte)-87);
/*  603 */     CHARS[3770] = 33;
/*  604 */     Arrays.fill(CHARS, 3771, 3773, (byte)-87);
/*  605 */     CHARS[3773] = -19;
/*  606 */     Arrays.fill(CHARS, 3774, 3776, (byte)33);
/*  607 */     Arrays.fill(CHARS, 3776, 3781, (byte)-19);
/*  608 */     CHARS[3781] = 33;
/*  609 */     CHARS[3782] = -87;
/*  610 */     CHARS[3783] = 33;
/*  611 */     Arrays.fill(CHARS, 3784, 3790, (byte)-87);
/*  612 */     Arrays.fill(CHARS, 3790, 3792, (byte)33);
/*  613 */     Arrays.fill(CHARS, 3792, 3802, (byte)-87);
/*  614 */     Arrays.fill(CHARS, 3802, 3864, (byte)33);
/*  615 */     Arrays.fill(CHARS, 3864, 3866, (byte)-87);
/*  616 */     Arrays.fill(CHARS, 3866, 3872, (byte)33);
/*  617 */     Arrays.fill(CHARS, 3872, 3882, (byte)-87);
/*  618 */     Arrays.fill(CHARS, 3882, 3893, (byte)33);
/*  619 */     CHARS[3893] = -87;
/*  620 */     CHARS[3894] = 33;
/*  621 */     CHARS[3895] = -87;
/*  622 */     CHARS[3896] = 33;
/*  623 */     CHARS[3897] = -87;
/*  624 */     Arrays.fill(CHARS, 3898, 3902, (byte)33);
/*  625 */     Arrays.fill(CHARS, 3902, 3904, (byte)-87);
/*  626 */     Arrays.fill(CHARS, 3904, 3912, (byte)-19);
/*  627 */     CHARS[3912] = 33;
/*  628 */     Arrays.fill(CHARS, 3913, 3946, (byte)-19);
/*  629 */     Arrays.fill(CHARS, 3946, 3953, (byte)33);
/*  630 */     Arrays.fill(CHARS, 3953, 3973, (byte)-87);
/*  631 */     CHARS[3973] = 33;
/*  632 */     Arrays.fill(CHARS, 3974, 3980, (byte)-87);
/*  633 */     Arrays.fill(CHARS, 3980, 3984, (byte)33);
/*  634 */     Arrays.fill(CHARS, 3984, 3990, (byte)-87);
/*  635 */     CHARS[3990] = 33;
/*  636 */     CHARS[3991] = -87;
/*  637 */     CHARS[3992] = 33;
/*  638 */     Arrays.fill(CHARS, 3993, 4014, (byte)-87);
/*  639 */     Arrays.fill(CHARS, 4014, 4017, (byte)33);
/*  640 */     Arrays.fill(CHARS, 4017, 4024, (byte)-87);
/*  641 */     CHARS[4024] = 33;
/*  642 */     CHARS[4025] = -87;
/*  643 */     Arrays.fill(CHARS, 4026, 4256, (byte)33);
/*  644 */     Arrays.fill(CHARS, 4256, 4294, (byte)-19);
/*  645 */     Arrays.fill(CHARS, 4294, 4304, (byte)33);
/*  646 */     Arrays.fill(CHARS, 4304, 4343, (byte)-19);
/*  647 */     Arrays.fill(CHARS, 4343, 4352, (byte)33);
/*  648 */     CHARS[4352] = -19;
/*  649 */     CHARS[4353] = 33;
/*  650 */     Arrays.fill(CHARS, 4354, 4356, (byte)-19);
/*  651 */     CHARS[4356] = 33;
/*  652 */     Arrays.fill(CHARS, 4357, 4360, (byte)-19);
/*  653 */     CHARS[4360] = 33;
/*  654 */     CHARS[4361] = -19;
/*  655 */     CHARS[4362] = 33;
/*  656 */     Arrays.fill(CHARS, 4363, 4365, (byte)-19);
/*  657 */     CHARS[4365] = 33;
/*  658 */     Arrays.fill(CHARS, 4366, 4371, (byte)-19);
/*  659 */     Arrays.fill(CHARS, 4371, 4412, (byte)33);
/*  660 */     CHARS[4412] = -19;
/*  661 */     CHARS[4413] = 33;
/*  662 */     CHARS[4414] = -19;
/*  663 */     CHARS[4415] = 33;
/*  664 */     CHARS[4416] = -19;
/*  665 */     Arrays.fill(CHARS, 4417, 4428, (byte)33);
/*  666 */     CHARS[4428] = -19;
/*  667 */     CHARS[4429] = 33;
/*  668 */     CHARS[4430] = -19;
/*  669 */     CHARS[4431] = 33;
/*  670 */     CHARS[4432] = -19;
/*  671 */     Arrays.fill(CHARS, 4433, 4436, (byte)33);
/*  672 */     Arrays.fill(CHARS, 4436, 4438, (byte)-19);
/*  673 */     Arrays.fill(CHARS, 4438, 4441, (byte)33);
/*  674 */     CHARS[4441] = -19;
/*  675 */     Arrays.fill(CHARS, 4442, 4447, (byte)33);
/*  676 */     Arrays.fill(CHARS, 4447, 4450, (byte)-19);
/*  677 */     CHARS[4450] = 33;
/*  678 */     CHARS[4451] = -19;
/*  679 */     CHARS[4452] = 33;
/*  680 */     CHARS[4453] = -19;
/*  681 */     CHARS[4454] = 33;
/*  682 */     CHARS[4455] = -19;
/*  683 */     CHARS[4456] = 33;
/*  684 */     CHARS[4457] = -19;
/*  685 */     Arrays.fill(CHARS, 4458, 4461, (byte)33);
/*  686 */     Arrays.fill(CHARS, 4461, 4463, (byte)-19);
/*  687 */     Arrays.fill(CHARS, 4463, 4466, (byte)33);
/*  688 */     Arrays.fill(CHARS, 4466, 4468, (byte)-19);
/*  689 */     CHARS[4468] = 33;
/*  690 */     CHARS[4469] = -19;
/*  691 */     Arrays.fill(CHARS, 4470, 4510, (byte)33);
/*  692 */     CHARS[4510] = -19;
/*  693 */     Arrays.fill(CHARS, 4511, 4520, (byte)33);
/*  694 */     CHARS[4520] = -19;
/*  695 */     Arrays.fill(CHARS, 4521, 4523, (byte)33);
/*  696 */     CHARS[4523] = -19;
/*  697 */     Arrays.fill(CHARS, 4524, 4526, (byte)33);
/*  698 */     Arrays.fill(CHARS, 4526, 4528, (byte)-19);
/*  699 */     Arrays.fill(CHARS, 4528, 4535, (byte)33);
/*  700 */     Arrays.fill(CHARS, 4535, 4537, (byte)-19);
/*  701 */     CHARS[4537] = 33;
/*  702 */     CHARS[4538] = -19;
/*  703 */     CHARS[4539] = 33;
/*  704 */     Arrays.fill(CHARS, 4540, 4547, (byte)-19);
/*  705 */     Arrays.fill(CHARS, 4547, 4587, (byte)33);
/*  706 */     CHARS[4587] = -19;
/*  707 */     Arrays.fill(CHARS, 4588, 4592, (byte)33);
/*  708 */     CHARS[4592] = -19;
/*  709 */     Arrays.fill(CHARS, 4593, 4601, (byte)33);
/*  710 */     CHARS[4601] = -19;
/*  711 */     Arrays.fill(CHARS, 4602, 7680, (byte)33);
/*  712 */     Arrays.fill(CHARS, 7680, 7836, (byte)-19);
/*  713 */     Arrays.fill(CHARS, 7836, 7840, (byte)33);
/*  714 */     Arrays.fill(CHARS, 7840, 7930, (byte)-19);
/*  715 */     Arrays.fill(CHARS, 7930, 7936, (byte)33);
/*  716 */     Arrays.fill(CHARS, 7936, 7958, (byte)-19);
/*  717 */     Arrays.fill(CHARS, 7958, 7960, (byte)33);
/*  718 */     Arrays.fill(CHARS, 7960, 7966, (byte)-19);
/*  719 */     Arrays.fill(CHARS, 7966, 7968, (byte)33);
/*  720 */     Arrays.fill(CHARS, 7968, 8006, (byte)-19);
/*  721 */     Arrays.fill(CHARS, 8006, 8008, (byte)33);
/*  722 */     Arrays.fill(CHARS, 8008, 8014, (byte)-19);
/*  723 */     Arrays.fill(CHARS, 8014, 8016, (byte)33);
/*  724 */     Arrays.fill(CHARS, 8016, 8024, (byte)-19);
/*  725 */     CHARS[8024] = 33;
/*  726 */     CHARS[8025] = -19;
/*  727 */     CHARS[8026] = 33;
/*  728 */     CHARS[8027] = -19;
/*  729 */     CHARS[8028] = 33;
/*  730 */     CHARS[8029] = -19;
/*  731 */     CHARS[8030] = 33;
/*  732 */     Arrays.fill(CHARS, 8031, 8062, (byte)-19);
/*  733 */     Arrays.fill(CHARS, 8062, 8064, (byte)33);
/*  734 */     Arrays.fill(CHARS, 8064, 8117, (byte)-19);
/*  735 */     CHARS[8117] = 33;
/*  736 */     Arrays.fill(CHARS, 8118, 8125, (byte)-19);
/*  737 */     CHARS[8125] = 33;
/*  738 */     CHARS[8126] = -19;
/*  739 */     Arrays.fill(CHARS, 8127, 8130, (byte)33);
/*  740 */     Arrays.fill(CHARS, 8130, 8133, (byte)-19);
/*  741 */     CHARS[8133] = 33;
/*  742 */     Arrays.fill(CHARS, 8134, 8141, (byte)-19);
/*  743 */     Arrays.fill(CHARS, 8141, 8144, (byte)33);
/*  744 */     Arrays.fill(CHARS, 8144, 8148, (byte)-19);
/*  745 */     Arrays.fill(CHARS, 8148, 8150, (byte)33);
/*  746 */     Arrays.fill(CHARS, 8150, 8156, (byte)-19);
/*  747 */     Arrays.fill(CHARS, 8156, 8160, (byte)33);
/*  748 */     Arrays.fill(CHARS, 8160, 8173, (byte)-19);
/*  749 */     Arrays.fill(CHARS, 8173, 8178, (byte)33);
/*  750 */     Arrays.fill(CHARS, 8178, 8181, (byte)-19);
/*  751 */     CHARS[8181] = 33;
/*  752 */     Arrays.fill(CHARS, 8182, 8189, (byte)-19);
/*  753 */     Arrays.fill(CHARS, 8189, 8400, (byte)33);
/*  754 */     Arrays.fill(CHARS, 8400, 8413, (byte)-87);
/*  755 */     Arrays.fill(CHARS, 8413, 8417, (byte)33);
/*  756 */     CHARS[8417] = -87;
/*  757 */     Arrays.fill(CHARS, 8418, 8486, (byte)33);
/*  758 */     CHARS[8486] = -19;
/*  759 */     Arrays.fill(CHARS, 8487, 8490, (byte)33);
/*  760 */     Arrays.fill(CHARS, 8490, 8492, (byte)-19);
/*  761 */     Arrays.fill(CHARS, 8492, 8494, (byte)33);
/*  762 */     CHARS[8494] = -19;
/*  763 */     Arrays.fill(CHARS, 8495, 8576, (byte)33);
/*  764 */     Arrays.fill(CHARS, 8576, 8579, (byte)-19);
/*  765 */     Arrays.fill(CHARS, 8579, 12293, (byte)33);
/*  766 */     CHARS[12293] = -87;
/*  767 */     CHARS[12294] = 33;
/*  768 */     CHARS[12295] = -19;
/*  769 */     Arrays.fill(CHARS, 12296, 12321, (byte)33);
/*  770 */     Arrays.fill(CHARS, 12321, 12330, (byte)-19);
/*  771 */     Arrays.fill(CHARS, 12330, 12336, (byte)-87);
/*  772 */     CHARS[12336] = 33;
/*  773 */     Arrays.fill(CHARS, 12337, 12342, (byte)-87);
/*  774 */     Arrays.fill(CHARS, 12342, 12353, (byte)33);
/*  775 */     Arrays.fill(CHARS, 12353, 12437, (byte)-19);
/*  776 */     Arrays.fill(CHARS, 12437, 12441, (byte)33);
/*  777 */     Arrays.fill(CHARS, 12441, 12443, (byte)-87);
/*  778 */     Arrays.fill(CHARS, 12443, 12445, (byte)33);
/*  779 */     Arrays.fill(CHARS, 12445, 12447, (byte)-87);
/*  780 */     Arrays.fill(CHARS, 12447, 12449, (byte)33);
/*  781 */     Arrays.fill(CHARS, 12449, 12539, (byte)-19);
/*  782 */     CHARS[12539] = 33;
/*  783 */     Arrays.fill(CHARS, 12540, 12543, (byte)-87);
/*  784 */     Arrays.fill(CHARS, 12543, 12549, (byte)33);
/*  785 */     Arrays.fill(CHARS, 12549, 12589, (byte)-19);
/*  786 */     Arrays.fill(CHARS, 12589, 19968, (byte)33);
/*  787 */     Arrays.fill(CHARS, 19968, 40870, (byte)-19);
/*  788 */     Arrays.fill(CHARS, 40870, 44032, (byte)33);
/*  789 */     Arrays.fill(CHARS, 44032, 55204, (byte)-19);
/*  790 */     Arrays.fill(CHARS, 55204, 55296, (byte)33);
/*  791 */     Arrays.fill(CHARS, 57344, 65534, (byte)33);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSupplemental(int c) {
/*  805 */     return (c >= 65536 && c <= 1114111);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int supplemental(char h, char l) {
/*  816 */     return (h - 55296) * 1024 + l - 56320 + 65536;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char highSurrogate(int c) {
/*  825 */     return (char)((c - 65536 >> 10) + 55296);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char lowSurrogate(int c) {
/*  834 */     return (char)((c - 65536 & 0x3FF) + 56320);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isHighSurrogate(int c) {
/*  843 */     return (55296 <= c && c <= 56319);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLowSurrogate(int c) {
/*  852 */     return (56320 <= c && c <= 57343);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValid(int c) {
/*  867 */     return ((c < 65536 && (CHARS[c] & 0x1) != 0) || (65536 <= c && c <= 1114111));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInvalid(int c) {
/*  877 */     return !isValid(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isContent(int c) {
/*  886 */     return ((c < 65536 && (CHARS[c] & 0x20) != 0) || (65536 <= c && c <= 1114111));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isMarkup(int c) {
/*  897 */     return (c == 60 || c == 38 || c == 37);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSpace(int c) {
/*  907 */     return (c <= 32 && (CHARS[c] & 0x2) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNameStart(int c) {
/*  918 */     return (c < 65536 && (CHARS[c] & 0x4) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isName(int c) {
/*  929 */     return (c < 65536 && (CHARS[c] & 0x8) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNCNameStart(int c) {
/*  940 */     return (c < 65536 && (CHARS[c] & 0x40) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNCName(int c) {
/*  951 */     return (c < 65536 && (CHARS[c] & 0x80) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isPubid(int c) {
/*  962 */     return (c < 65536 && (CHARS[c] & 0x10) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidName(String name) {
/*  976 */     if (name.length() == 0)
/*  977 */       return false; 
/*  978 */     char ch = name.charAt(0);
/*  979 */     if (!isNameStart(ch))
/*  980 */       return false; 
/*  981 */     for (int i = 1; i < name.length(); i++) {
/*  982 */       ch = name.charAt(i);
/*  983 */       if (!isName(ch)) {
/*  984 */         return false;
/*      */       }
/*      */     } 
/*  987 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidNCName(String ncName) {
/* 1003 */     if (ncName.length() == 0)
/* 1004 */       return false; 
/* 1005 */     char ch = ncName.charAt(0);
/* 1006 */     if (!isNCNameStart(ch))
/* 1007 */       return false; 
/* 1008 */     for (int i = 1; i < ncName.length(); i++) {
/* 1009 */       ch = ncName.charAt(i);
/* 1010 */       if (!isNCName(ch)) {
/* 1011 */         return false;
/*      */       }
/*      */     } 
/* 1014 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidNmtoken(String nmtoken) {
/* 1028 */     if (nmtoken.length() == 0)
/* 1029 */       return false; 
/* 1030 */     for (int i = 0; i < nmtoken.length(); i++) {
/* 1031 */       char ch = nmtoken.charAt(i);
/* 1032 */       if (!isName(ch)) {
/* 1033 */         return false;
/*      */       }
/*      */     } 
/* 1036 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidIANAEncoding(String ianaEncoding) {
/* 1054 */     if (ianaEncoding != null) {
/* 1055 */       int length = ianaEncoding.length();
/* 1056 */       if (length > 0) {
/* 1057 */         char c = ianaEncoding.charAt(0);
/* 1058 */         if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
/* 1059 */           for (int i = 1; i < length; i++) {
/* 1060 */             c = ianaEncoding.charAt(i);
/* 1061 */             if ((c < 'A' || c > 'Z') && (c < 'a' || c > 'z') && (c < '0' || c > '9') && c != '.' && c != '_' && c != '-')
/*      */             {
/*      */               
/* 1064 */               return false;
/*      */             }
/*      */           } 
/* 1067 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1071 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidJavaEncoding(String javaEncoding) {
/* 1083 */     if (javaEncoding != null) {
/* 1084 */       int length = javaEncoding.length();
/* 1085 */       if (length > 0) {
/* 1086 */         for (int i = 1; i < length; i++) {
/* 1087 */           char c = javaEncoding.charAt(i);
/* 1088 */           if ((c < 'A' || c > 'Z') && (c < 'a' || c > 'z') && (c < '0' || c > '9') && c != '.' && c != '_' && c != '-')
/*      */           {
/*      */             
/* 1091 */             return false;
/*      */           }
/*      */         } 
/* 1094 */         return true;
/*      */       } 
/*      */     } 
/* 1097 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\org\apache\xerce\\util\XMLChar.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */