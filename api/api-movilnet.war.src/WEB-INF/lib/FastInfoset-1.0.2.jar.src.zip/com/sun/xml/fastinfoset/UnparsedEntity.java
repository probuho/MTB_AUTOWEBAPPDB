/*    */ package com.sun.xml.fastinfoset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnparsedEntity
/*    */   extends Notation
/*    */ {
/*    */   public final String notationName;
/*    */   
/*    */   public UnparsedEntity(String _name, String _systemIdentifier, String _publicIdentifier, String _notationName) {
/* 46 */     super(_name, _systemIdentifier, _publicIdentifier);
/* 47 */     this.notationName = _notationName;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\UnparsedEntity.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */