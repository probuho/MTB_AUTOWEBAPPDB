/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.CharBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongEncodingAlgorithm
/*     */   extends IntegerEncodingAlgorithm
/*     */ {
/*     */   public int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/*  56 */     if (octetLength % 8 != 0) {
/*  57 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.lengthNotMultipleOfLong", new Object[] { new Integer(8) }));
/*     */     }
/*     */ 
/*     */     
/*  61 */     return octetLength / 8;
/*     */   }
/*     */   
/*     */   public int getOctetLengthFromPrimitiveLength(int primitiveLength) {
/*  65 */     return primitiveLength * 8;
/*     */   }
/*     */   
/*     */   public final Object decodeFromBytes(byte[] b, int start, int length) throws EncodingAlgorithmException {
/*  69 */     long[] data = new long[getPrimtiveLengthFromOctetLength(length)];
/*  70 */     decodeFromBytesToLongArray(data, 0, b, start, length);
/*     */     
/*  72 */     return data;
/*     */   }
/*     */   
/*     */   public final Object decodeFromInputStream(InputStream s) throws IOException {
/*  76 */     return decodeFromInputStreamToIntArray(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeToOutputStream(Object data, OutputStream s) throws IOException {
/*  81 */     if (!(data instanceof long[])) {
/*  82 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotLongArray"));
/*     */     }
/*     */     
/*  85 */     long[] ldata = (long[])data;
/*     */     
/*  87 */     encodeToOutputStreamFromLongArray(ldata, s);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convertFromCharacters(char[] ch, int start, int length) {
/*  92 */     final CharBuffer cb = CharBuffer.wrap(ch, start, length);
/*  93 */     final List longList = new ArrayList();
/*     */     
/*  95 */     matchWhiteSpaceDelimnatedWords(cb, new BuiltInEncodingAlgorithm.WordListener()
/*     */         {
/*     */           public void word(int start, int end) {
/*  98 */             String lStringValue = cb.subSequence(start, end).toString();
/*  99 */             longList.add(Long.valueOf(lStringValue));
/*     */           }
/*     */           private final CharBuffer val$cb; private final List val$longList;
/*     */           private final LongEncodingAlgorithm this$0;
/*     */         });
/* 104 */     return generateArrayFromList(longList);
/*     */   }
/*     */   
/*     */   public void convertToCharacters(Object data, StringBuffer s) {
/* 108 */     if (!(data instanceof long[])) {
/* 109 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotLongArray"));
/*     */     }
/*     */     
/* 112 */     long[] ldata = (long[])data;
/*     */     
/* 114 */     convertToCharactersFromLongArray(ldata, s);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void decodeFromBytesToLongArray(long[] ldata, int istart, byte[] b, int start, int length) {
/* 119 */     int size = length / 8;
/* 120 */     for (int i = 0; i < size; i++) {
/* 121 */       ldata[istart++] = (b[start++] & 0xFF) << 56L | (b[start++] & 0xFF) << 48L | (b[start++] & 0xFF) << 40L | (b[start++] & 0xFF) << 32L | (b[start++] & 0xFF) << 24L | (b[start++] & 0xFF) << 16L | (b[start++] & 0xFF) << 8L | (b[start++] & 0xFF);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long[] decodeFromInputStreamToIntArray(InputStream s) throws IOException {
/* 134 */     List longList = new ArrayList();
/* 135 */     byte[] b = new byte[8];
/*     */     
/*     */     while (true) {
/* 138 */       int n = s.read(b);
/* 139 */       if (n != 8) {
/* 140 */         if (n == -1) {
/*     */           break;
/*     */         }
/*     */         
/* 144 */         while (n != 8) {
/* 145 */           int m = s.read(b, n, 8 - n);
/* 146 */           if (m == -1) {
/* 147 */             throw new EOFException();
/*     */           }
/* 149 */           n += m;
/*     */         } 
/*     */       } 
/*     */       
/* 153 */       int l = (b[0] & 0xFF) << 56 | (b[1] & 0xFF) << 48 | (b[2] & 0xFF) << 40 | (b[3] & 0xFF) << 32 | (b[4] & 0xFF) << 24 | (b[5] & 0xFF) << 16 | (b[6] & 0xFF) << 8 | b[7] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 162 */       longList.add(new Long(l));
/*     */     } 
/*     */     
/* 165 */     return generateArrayFromList(longList);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void encodeToOutputStreamFromLongArray(long[] ldata, OutputStream s) throws IOException {
/* 170 */     for (int i = 0; i < ldata.length; i++) {
/* 171 */       long bits = ldata[i];
/* 172 */       s.write((int)(bits >>> 56L & 0xFFL));
/* 173 */       s.write((int)(bits >>> 48L & 0xFFL));
/* 174 */       s.write((int)(bits >>> 40L & 0xFFL));
/* 175 */       s.write((int)(bits >>> 32L & 0xFFL));
/* 176 */       s.write((int)(bits >>> 24L & 0xFFL));
/* 177 */       s.write((int)(bits >>> 16L & 0xFFL));
/* 178 */       s.write((int)(bits >>> 8L & 0xFFL));
/* 179 */       s.write((int)(bits & 0xFFL));
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void encodeToBytes(Object array, int astart, int alength, byte[] b, int start) {
/* 184 */     encodeToBytesFromLongArray((long[])array, astart, alength, b, start);
/*     */   }
/*     */   
/*     */   public final void encodeToBytesFromLongArray(long[] ldata, int lstart, int llength, byte[] b, int start) {
/* 188 */     int lend = lstart + llength;
/* 189 */     for (int i = lstart; i < lend; i++) {
/* 190 */       long bits = ldata[i];
/* 191 */       b[start++] = (byte)(int)(bits >>> 56L & 0xFFL);
/* 192 */       b[start++] = (byte)(int)(bits >>> 48L & 0xFFL);
/* 193 */       b[start++] = (byte)(int)(bits >>> 40L & 0xFFL);
/* 194 */       b[start++] = (byte)(int)(bits >>> 32L & 0xFFL);
/* 195 */       b[start++] = (byte)(int)(bits >>> 24L & 0xFFL);
/* 196 */       b[start++] = (byte)(int)(bits >>> 16L & 0xFFL);
/* 197 */       b[start++] = (byte)(int)(bits >>> 8L & 0xFFL);
/* 198 */       b[start++] = (byte)(int)(bits & 0xFFL);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void convertToCharactersFromLongArray(long[] ldata, StringBuffer s) {
/* 204 */     int end = ldata.length - 1;
/* 205 */     for (int i = 0; i <= end; i++) {
/* 206 */       s.append(Long.toString(ldata[i]));
/* 207 */       if (i != end) {
/* 208 */         s.append(' ');
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final long[] generateArrayFromList(List array) {
/* 215 */     long[] ldata = new long[array.size()];
/* 216 */     for (int i = 0; i < ldata.length; i++) {
/* 217 */       ldata[i] = ((Long)array.get(i)).longValue();
/*     */     }
/*     */     
/* 220 */     return ldata;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\LongEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */