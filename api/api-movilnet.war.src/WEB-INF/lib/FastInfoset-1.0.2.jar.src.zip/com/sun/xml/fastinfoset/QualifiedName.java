/*     */ package com.sun.xml.fastinfoset;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifiedName
/*     */ {
/*     */   public final String prefix;
/*     */   public final String namespaceName;
/*     */   public final String localName;
/*     */   public String qName;
/*     */   public final int index;
/*     */   public final int prefixIndex;
/*     */   public final int namespaceNameIndex;
/*     */   public final int localNameIndex;
/*     */   public int attributeId;
/*     */   public int attributeHash;
/*     */   private QName qNameObject;
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName, String localName, String qName) {
/*  58 */     this.prefix = prefix;
/*  59 */     this.namespaceName = namespaceName;
/*  60 */     this.localName = localName;
/*  61 */     this.qName = qName;
/*  62 */     this.index = -1;
/*  63 */     this.prefixIndex = 0;
/*  64 */     this.namespaceNameIndex = 0;
/*  65 */     this.localNameIndex = -1;
/*     */   }
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName, String localName, String qName, int index) {
/*  69 */     this.prefix = prefix;
/*  70 */     this.namespaceName = namespaceName;
/*  71 */     this.localName = localName;
/*  72 */     this.qName = qName;
/*  73 */     this.index = index;
/*  74 */     this.prefixIndex = 0;
/*  75 */     this.namespaceNameIndex = 0;
/*  76 */     this.localNameIndex = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName, String localName, String qName, int index, int prefixIndex, int namespaceNameIndex, int localNameIndex) {
/*  81 */     this.prefix = prefix;
/*  82 */     this.namespaceName = namespaceName;
/*  83 */     this.localName = localName;
/*  84 */     this.qName = qName;
/*  85 */     this.index = index;
/*  86 */     this.prefixIndex = prefixIndex + 1;
/*  87 */     this.namespaceNameIndex = namespaceNameIndex + 1;
/*  88 */     this.localNameIndex = localNameIndex;
/*     */   }
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName, String localName) {
/*  92 */     this.prefix = prefix;
/*  93 */     this.namespaceName = namespaceName;
/*  94 */     this.localName = localName;
/*  95 */     this.qName = createQNameString(prefix, localName);
/*  96 */     this.index = -1;
/*  97 */     this.prefixIndex = 0;
/*  98 */     this.namespaceNameIndex = 0;
/*  99 */     this.localNameIndex = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName, String localName, int prefixIndex, int namespaceNameIndex, int localNameIndex, char[] charBuffer) {
/* 105 */     this.prefix = prefix;
/* 106 */     this.namespaceName = namespaceName;
/* 107 */     this.localName = localName;
/*     */     
/* 109 */     if (charBuffer != null) {
/* 110 */       int l1 = prefix.length();
/* 111 */       int l2 = localName.length();
/* 112 */       int total = l1 + l2 + 1;
/* 113 */       if (total < charBuffer.length) {
/* 114 */         prefix.getChars(0, l1, charBuffer, 0);
/* 115 */         charBuffer[l1] = ':';
/* 116 */         localName.getChars(0, l2, charBuffer, l1 + 1);
/* 117 */         this.qName = new String(charBuffer, 0, total);
/*     */       } else {
/* 119 */         this.qName = createQNameString(prefix, localName);
/*     */       } 
/*     */     } else {
/* 122 */       this.qName = this.localName;
/*     */     } 
/*     */     
/* 125 */     this.prefixIndex = prefixIndex + 1;
/* 126 */     this.namespaceNameIndex = namespaceNameIndex + 1;
/* 127 */     this.localNameIndex = localNameIndex;
/* 128 */     this.index = -1;
/*     */   }
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName, String localName, int index) {
/* 132 */     this.prefix = prefix;
/* 133 */     this.namespaceName = namespaceName;
/* 134 */     this.localName = localName;
/* 135 */     this.qName = createQNameString(prefix, localName);
/* 136 */     this.index = index;
/* 137 */     this.prefixIndex = 0;
/* 138 */     this.namespaceNameIndex = 0;
/* 139 */     this.localNameIndex = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName, String localName, int index, int prefixIndex, int namespaceNameIndex, int localNameIndex) {
/* 144 */     this.prefix = prefix;
/* 145 */     this.namespaceName = namespaceName;
/* 146 */     this.localName = localName;
/* 147 */     this.qName = createQNameString(prefix, localName);
/* 148 */     this.index = index;
/* 149 */     this.prefixIndex = prefixIndex + 1;
/* 150 */     this.namespaceNameIndex = namespaceNameIndex + 1;
/* 151 */     this.localNameIndex = localNameIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public QualifiedName(String prefix, String namespaceName) {
/* 156 */     this.prefix = prefix;
/* 157 */     this.namespaceName = namespaceName;
/* 158 */     this.localName = "";
/* 159 */     this.qName = "";
/* 160 */     this.index = -1;
/* 161 */     this.prefixIndex = 0;
/* 162 */     this.namespaceNameIndex = 0;
/* 163 */     this.localNameIndex = -1;
/*     */   }
/*     */   
/*     */   public final QName getQName() {
/* 167 */     if (this.qNameObject == null) {
/* 168 */       this.qNameObject = new QName(this.namespaceName, this.localName, this.prefix);
/*     */     }
/*     */     
/* 171 */     return this.qNameObject;
/*     */   }
/*     */   
/*     */   public final String getQNameString() {
/* 175 */     if (this.qName != "") {
/* 176 */       return this.qName;
/*     */     }
/*     */     
/* 179 */     return this.qName = createQNameString(this.prefix, this.localName);
/*     */   }
/*     */   
/*     */   public final void createAttributeValues(int size) {
/* 183 */     this.attributeId = this.localNameIndex | this.namespaceNameIndex << 20;
/* 184 */     this.attributeHash = this.localNameIndex % size;
/*     */   }
/*     */   
/*     */   private final String createQNameString(String p, String l) {
/* 188 */     if (p != null && p != "") {
/* 189 */       StringBuffer b = new StringBuffer(p);
/* 190 */       b.append(':');
/* 191 */       b.append(l);
/* 192 */       return b.toString();
/*     */     } 
/* 194 */     return l;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\QualifiedName.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */