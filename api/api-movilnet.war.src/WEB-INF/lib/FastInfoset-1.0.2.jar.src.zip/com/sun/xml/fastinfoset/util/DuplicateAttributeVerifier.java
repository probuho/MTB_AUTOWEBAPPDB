/*    */ package com.sun.xml.fastinfoset.util;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*    */ import org.jvnet.fastinfoset.FastInfosetException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DuplicateAttributeVerifier
/*    */ {
/*    */   public static final int MAP_SIZE = 256;
/*    */   public int _currentIteration;
/*    */   private Entry[] _map;
/*    */   public final Entry _poolHead;
/*    */   public Entry _poolCurrent;
/*    */   private Entry _poolTail;
/*    */   
/*    */   private static class Entry
/*    */   {
/*    */     private int iteration;
/*    */     private int value;
/*    */     private Entry hashNext;
/*    */     private Entry poolNext;
/*    */     
/*    */     private Entry() {}
/*    */   }
/*    */   
/*    */   public DuplicateAttributeVerifier() {
/* 30 */     this._poolTail = this._poolHead = new Entry();
/*    */   }
/*    */   
/*    */   public final void clear() {
/* 34 */     this._currentIteration = 0;
/*    */     
/* 36 */     Entry e = this._poolHead;
/* 37 */     while (e != null) {
/* 38 */       e.iteration = 0;
/* 39 */       e = e.poolNext;
/*    */     } 
/*    */     
/* 42 */     reset();
/*    */   }
/*    */   
/*    */   public final void reset() {
/* 46 */     this._poolCurrent = this._poolHead;
/* 47 */     if (this._map == null) {
/* 48 */       this._map = new Entry[256];
/*    */     }
/*    */   }
/*    */   
/*    */   private final void increasePool(int capacity) {
/* 53 */     if (this._map == null) {
/* 54 */       this._map = new Entry[256];
/* 55 */       this._poolCurrent = this._poolHead;
/*    */     } else {
/* 57 */       Entry tail = this._poolTail;
/* 58 */       for (int i = 0; i < capacity; i++) {
/* 59 */         Entry e = new Entry();
/* 60 */         this._poolTail.poolNext = e;
/* 61 */         this._poolTail = e;
/*    */       } 
/*    */       
/* 64 */       this._poolCurrent = tail.poolNext;
/*    */     } 
/*    */   }
/*    */   
/*    */   public final void checkForDuplicateAttribute(int hash, int value) throws FastInfosetException {
/* 69 */     if (this._poolCurrent == null) {
/* 70 */       increasePool(16);
/*    */     }
/*    */ 
/*    */     
/* 74 */     Entry newEntry = this._poolCurrent;
/* 75 */     this._poolCurrent = this._poolCurrent.poolNext;
/*    */     
/* 77 */     Entry head = this._map[hash];
/* 78 */     if (head == null || head.iteration < this._currentIteration) {
/* 79 */       newEntry.hashNext = null;
/* 80 */       this._map[hash] = newEntry;
/* 81 */       newEntry.iteration = this._currentIteration;
/* 82 */       newEntry.value = value;
/*    */     } else {
/* 84 */       Entry e = head;
/*    */       do {
/* 86 */         if (e.value == value) {
/* 87 */           reset();
/* 88 */           throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.duplicateAttribute"));
/*    */         } 
/* 90 */       } while ((e = e.hashNext) != null);
/*    */       
/* 92 */       newEntry.hashNext = head;
/* 93 */       this._map[hash] = newEntry;
/* 94 */       newEntry.iteration = this._currentIteration;
/* 95 */       newEntry.value = value;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\DuplicateAttributeVerifier.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */