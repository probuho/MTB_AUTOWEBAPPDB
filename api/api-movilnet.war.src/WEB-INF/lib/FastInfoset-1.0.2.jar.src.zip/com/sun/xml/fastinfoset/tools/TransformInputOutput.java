/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TransformInputOutput
/*    */ {
/*    */   public void parse(String[] args) throws Exception {
/* 57 */     InputStream in = null;
/* 58 */     OutputStream out = null;
/* 59 */     if (args.length == 0) {
/* 60 */       in = new BufferedInputStream(System.in);
/* 61 */       out = new BufferedOutputStream(System.out);
/* 62 */     } else if (args.length == 1) {
/* 63 */       in = new BufferedInputStream(new FileInputStream(args[0]));
/* 64 */       out = new BufferedOutputStream(System.out);
/* 65 */     } else if (args.length == 2) {
/* 66 */       in = new BufferedInputStream(new FileInputStream(args[0]));
/* 67 */       out = new BufferedOutputStream(new FileOutputStream(args[1]));
/*    */     } else {
/* 69 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.optinalFileNotSpecified"));
/*    */     } 
/*    */     
/* 72 */     parse(in, out);
/*    */   }
/*    */   
/*    */   abstract void parse(InputStream paramInputStream, OutputStream paramOutputStream) throws Exception;
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\TransformInputOutput.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */