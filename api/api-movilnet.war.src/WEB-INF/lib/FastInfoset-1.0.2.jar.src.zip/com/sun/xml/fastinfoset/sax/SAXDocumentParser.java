/*      */ package com.sun.xml.fastinfoset.sax;
/*      */ 
/*      */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*      */ import com.sun.xml.fastinfoset.Decoder;
/*      */ import com.sun.xml.fastinfoset.DecoderStateTables;
/*      */ import com.sun.xml.fastinfoset.EncodingConstants;
/*      */ import com.sun.xml.fastinfoset.QualifiedName;
/*      */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithmFactory;
/*      */ import com.sun.xml.fastinfoset.algorithm.BuiltInEncodingAlgorithmState;
/*      */ import com.sun.xml.fastinfoset.util.CharArray;
/*      */ import com.sun.xml.fastinfoset.util.CharArrayString;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.URL;
/*      */ import java.util.Map;
/*      */ import org.jvnet.fastinfoset.EncodingAlgorithm;
/*      */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*      */ import org.jvnet.fastinfoset.FastInfosetException;
/*      */ import org.jvnet.fastinfoset.sax.EncodingAlgorithmContentHandler;
/*      */ import org.jvnet.fastinfoset.sax.FastInfosetReader;
/*      */ import org.jvnet.fastinfoset.sax.PrimitiveTypeContentHandler;
/*      */ import org.xml.sax.Attributes;
/*      */ import org.xml.sax.ContentHandler;
/*      */ import org.xml.sax.DTDHandler;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.ErrorHandler;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.SAXNotRecognizedException;
/*      */ import org.xml.sax.SAXNotSupportedException;
/*      */ import org.xml.sax.SAXParseException;
/*      */ import org.xml.sax.ext.LexicalHandler;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SAXDocumentParser
/*      */   extends Decoder
/*      */   implements FastInfosetReader
/*      */ {
/*      */   private static final class LexicalHandlerImpl
/*      */     implements LexicalHandler
/*      */   {
/*      */     private LexicalHandlerImpl() {}
/*      */     
/*      */     public void comment(char[] ch, int start, int end) {}
/*      */     
/*      */     public void startDTD(String name, String publicId, String systemId) {}
/*      */     
/*      */     public void endDTD() {}
/*      */     
/*      */     public void startEntity(String name) {}
/*      */     
/*      */     public void endEntity(String name) {}
/*      */     
/*      */     public void startCDATA() {}
/*      */     
/*      */     public void endCDATA() {}
/*      */   }
/*      */   
/*      */   protected boolean _namespacePrefixesFeature = false;
/*      */   protected EntityResolver _entityResolver;
/*      */   protected DTDHandler _dtdHandler;
/*      */   protected ContentHandler _contentHandler;
/*      */   protected ErrorHandler _errorHandler;
/*      */   protected LexicalHandler _lexicalHandler;
/*      */   protected EncodingAlgorithmContentHandler _algorithmHandler;
/*      */   protected PrimitiveTypeContentHandler _primitiveHandler;
/*  127 */   protected BuiltInEncodingAlgorithmState builtInAlgorithmState = new BuiltInEncodingAlgorithmState();
/*      */ 
/*      */   
/*      */   protected AttributesHolder _attributes;
/*      */   
/*  132 */   protected int[] _namespacePrefixes = new int[16];
/*      */   
/*      */   protected int _namespacePrefixesIndex;
/*      */   
/*      */   protected boolean _clearAttributes = false;
/*      */ 
/*      */   
/*      */   public SAXDocumentParser() {
/*  140 */     DefaultHandler handler = new DefaultHandler();
/*  141 */     this._attributes = new AttributesHolder(this._registeredEncodingAlgorithms);
/*      */     
/*  143 */     this._entityResolver = handler;
/*  144 */     this._dtdHandler = handler;
/*  145 */     this._contentHandler = handler;
/*  146 */     this._errorHandler = handler;
/*  147 */     this._lexicalHandler = new LexicalHandlerImpl();
/*      */   }
/*      */   
/*      */   protected void resetOnError() {
/*  151 */     this._clearAttributes = false;
/*  152 */     this._attributes.clear();
/*  153 */     this._namespacePrefixesIndex = 0;
/*      */     
/*  155 */     if (this._v != null) {
/*  156 */       this._v.prefix.clearCompletely();
/*      */     }
/*  158 */     this._duplicateAttributeVerifier.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFeature(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
/*  165 */     if (name.equals("http://xml.org/sax/features/namespaces"))
/*  166 */       return true; 
/*  167 */     if (name.equals("http://xml.org/sax/features/namespace-prefixes"))
/*  168 */       return this._namespacePrefixesFeature; 
/*  169 */     if (name.equals("http://xml.org/sax/features/string-interning") || name.equals("http://jvnet.org/fastinfoset/parser/properties/string-interning"))
/*      */     {
/*  171 */       return getStringInterning();
/*      */     }
/*  173 */     throw new SAXNotRecognizedException(CommonResourceBundle.getInstance().getString("message.featureNotSupported") + name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFeature(String name, boolean value) throws SAXNotRecognizedException, SAXNotSupportedException {
/*  180 */     if (name.equals("http://xml.org/sax/features/namespaces")) {
/*  181 */       if (!value) {
/*  182 */         throw new SAXNotSupportedException(name + ":" + value);
/*      */       }
/*  184 */     } else if (name.equals("http://xml.org/sax/features/namespace-prefixes")) {
/*  185 */       this._namespacePrefixesFeature = value;
/*  186 */     } else if (name.equals("http://xml.org/sax/features/string-interning") || name.equals("http://jvnet.org/fastinfoset/parser/properties/string-interning")) {
/*      */       
/*  188 */       setStringInterning(value);
/*      */     } else {
/*  190 */       throw new SAXNotRecognizedException(CommonResourceBundle.getInstance().getString("message.featureNotSupported") + name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getProperty(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
/*  197 */     if (name.equals("http://xml.org/sax/properties/lexical-handler"))
/*  198 */       return getLexicalHandler(); 
/*  199 */     if (name.equals("http://jvnet.org/fastinfoset/parser/properties/external-vocabularies"))
/*  200 */       return getExternalVocabularies(); 
/*  201 */     if (name.equals("http://jvnet.org/fastinfoset/parser/properties/registered-encoding-algorithms"))
/*  202 */       return getRegisteredEncodingAlgorithms(); 
/*  203 */     if (name.equals("http://jvnet.org/fastinfoset/sax/properties/encoding-algorithm-content-handler"))
/*  204 */       return getEncodingAlgorithmContentHandler(); 
/*  205 */     if (name.equals("http://jvnet.org/fastinfoset/sax/properties/primitive-type-content-handler")) {
/*  206 */       return getPrimitiveTypeContentHandler();
/*      */     }
/*  208 */     throw new SAXNotRecognizedException(CommonResourceBundle.getInstance().getString("message.propertyNotRecognized", new Object[] { name }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProperty(String name, Object value) throws SAXNotRecognizedException, SAXNotSupportedException {
/*  215 */     if (name.equals("http://xml.org/sax/properties/lexical-handler")) {
/*  216 */       if (value instanceof LexicalHandler) {
/*  217 */         setLexicalHandler((LexicalHandler)value);
/*      */       } else {
/*  219 */         throw new SAXNotSupportedException("http://xml.org/sax/properties/lexical-handler");
/*      */       } 
/*  221 */     } else if (name.equals("http://jvnet.org/fastinfoset/parser/properties/external-vocabularies")) {
/*  222 */       if (value instanceof Map) {
/*  223 */         setExternalVocabularies((Map)value);
/*      */       } else {
/*  225 */         throw new SAXNotSupportedException("http://jvnet.org/fastinfoset/parser/properties/external-vocabularies");
/*      */       } 
/*  227 */     } else if (name.equals("http://jvnet.org/fastinfoset/parser/properties/registered-encoding-algorithms")) {
/*  228 */       if (value instanceof Map) {
/*  229 */         setRegisteredEncodingAlgorithms((Map)value);
/*      */       } else {
/*  231 */         throw new SAXNotSupportedException("http://jvnet.org/fastinfoset/parser/properties/registered-encoding-algorithms");
/*      */       } 
/*  233 */     } else if (name.equals("http://jvnet.org/fastinfoset/sax/properties/encoding-algorithm-content-handler")) {
/*  234 */       if (value instanceof EncodingAlgorithmContentHandler) {
/*  235 */         setEncodingAlgorithmContentHandler((EncodingAlgorithmContentHandler)value);
/*      */       } else {
/*  237 */         throw new SAXNotSupportedException("http://jvnet.org/fastinfoset/sax/properties/encoding-algorithm-content-handler");
/*      */       } 
/*  239 */     } else if (name.equals("http://jvnet.org/fastinfoset/sax/properties/primitive-type-content-handler")) {
/*  240 */       if (value instanceof PrimitiveTypeContentHandler) {
/*  241 */         setPrimitiveTypeContentHandler((PrimitiveTypeContentHandler)value);
/*      */       } else {
/*  243 */         throw new SAXNotSupportedException("http://jvnet.org/fastinfoset/sax/properties/primitive-type-content-handler");
/*      */       } 
/*  245 */     } else if (name.equals("http://jvnet.org/fastinfoset/parser/properties/buffer-size")) {
/*  246 */       if (value instanceof Integer) {
/*  247 */         setBufferSize(((Integer)value).intValue());
/*      */       } else {
/*  249 */         throw new SAXNotSupportedException("http://jvnet.org/fastinfoset/parser/properties/buffer-size");
/*      */       } 
/*      */     } else {
/*  252 */       throw new SAXNotRecognizedException(CommonResourceBundle.getInstance().getString("message.propertyNotRecognized", new Object[] { name }));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEntityResolver(EntityResolver resolver) {
/*  258 */     this._entityResolver = resolver;
/*      */   }
/*      */   
/*      */   public EntityResolver getEntityResolver() {
/*  262 */     return this._entityResolver;
/*      */   }
/*      */   
/*      */   public void setDTDHandler(DTDHandler handler) {
/*  266 */     this._dtdHandler = handler;
/*      */   }
/*      */   
/*      */   public DTDHandler getDTDHandler() {
/*  270 */     return this._dtdHandler;
/*      */   }
/*      */   public void setContentHandler(ContentHandler handler) {
/*  273 */     this._contentHandler = handler;
/*      */   }
/*      */   
/*      */   public ContentHandler getContentHandler() {
/*  277 */     return this._contentHandler;
/*      */   }
/*      */   
/*      */   public void setErrorHandler(ErrorHandler handler) {
/*  281 */     this._errorHandler = handler;
/*      */   }
/*      */   
/*      */   public ErrorHandler getErrorHandler() {
/*  285 */     return this._errorHandler;
/*      */   }
/*      */   
/*      */   public void parse(InputSource input) throws IOException, SAXException {
/*      */     try {
/*  290 */       InputStream s = input.getByteStream();
/*  291 */       if (s == null) {
/*  292 */         String systemId = input.getSystemId();
/*  293 */         if (systemId == null) {
/*  294 */           throw new SAXException(CommonResourceBundle.getInstance().getString("message.inputSource"));
/*      */         }
/*  296 */         parse(systemId);
/*      */       } else {
/*  298 */         parse(s);
/*      */       } 
/*  300 */     } catch (FastInfosetException e) {
/*  301 */       e.printStackTrace();
/*  302 */       throw new SAXException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void parse(String systemId) throws IOException, SAXException {
/*      */     try {
/*  308 */       systemId = SystemIdResolver.getAbsoluteURI(systemId);
/*  309 */       parse((new URL(systemId)).openStream());
/*  310 */     } catch (FastInfosetException e) {
/*  311 */       e.printStackTrace();
/*  312 */       throw new SAXException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void parse(InputStream s) throws IOException, FastInfosetException, SAXException {
/*  322 */     setInputStream(s);
/*  323 */     parse();
/*      */   }
/*      */   
/*      */   public void setLexicalHandler(LexicalHandler handler) {
/*  327 */     this._lexicalHandler = handler;
/*      */   }
/*      */   
/*      */   public LexicalHandler getLexicalHandler() {
/*  331 */     return this._lexicalHandler;
/*      */   }
/*      */   
/*      */   public void setEncodingAlgorithmContentHandler(EncodingAlgorithmContentHandler handler) {
/*  335 */     this._algorithmHandler = handler;
/*      */   }
/*      */   
/*      */   public EncodingAlgorithmContentHandler getEncodingAlgorithmContentHandler() {
/*  339 */     return this._algorithmHandler;
/*      */   }
/*      */   
/*      */   public void setPrimitiveTypeContentHandler(PrimitiveTypeContentHandler handler) {
/*  343 */     this._primitiveHandler = handler;
/*      */   }
/*      */   
/*      */   public PrimitiveTypeContentHandler getPrimitiveTypeContentHandler() {
/*  347 */     return this._primitiveHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void parse() throws FastInfosetException, IOException {
/*  354 */     if (this._octetBuffer.length < this._bufferSize) {
/*  355 */       this._octetBuffer = new byte[this._bufferSize];
/*      */     }
/*      */     
/*      */     try {
/*  359 */       reset();
/*  360 */       decodeHeader();
/*  361 */       processDII();
/*  362 */     } catch (RuntimeException e) {
/*      */       try {
/*  364 */         this._errorHandler.fatalError(new SAXParseException(e.getClass().getName(), null, e));
/*  365 */       } catch (Exception ee) {}
/*      */       
/*  367 */       resetOnError();
/*      */       
/*  369 */       throw new FastInfosetException(e);
/*  370 */     } catch (FastInfosetException e) {
/*      */       try {
/*  372 */         this._errorHandler.fatalError(new SAXParseException(e.getClass().getName(), null, (Exception)e));
/*  373 */       } catch (Exception ee) {}
/*      */       
/*  375 */       resetOnError();
/*  376 */       throw e;
/*  377 */     } catch (IOException e) {
/*      */       try {
/*  379 */         this._errorHandler.fatalError(new SAXParseException(e.getClass().getName(), null, e));
/*  380 */       } catch (Exception ee) {}
/*      */       
/*  382 */       resetOnError();
/*  383 */       throw e;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void processDII() throws FastInfosetException, IOException {
/*      */     try {
/*  389 */       this._contentHandler.startDocument();
/*  390 */     } catch (SAXException e) {
/*  391 */       throw new FastInfosetException("processDII", e);
/*      */     } 
/*      */     
/*  394 */     this._b = read();
/*  395 */     if (this._b > 0) {
/*  396 */       processDIIOptionalProperties();
/*      */     }
/*      */ 
/*      */     
/*  400 */     boolean firstElementHasOccured = false;
/*  401 */     boolean documentTypeDeclarationOccured = false;
/*  402 */     while (!this._terminate || !firstElementHasOccured) {
/*  403 */       QualifiedName qn; String system_identifier, public_identifier; this._b = read();
/*  404 */       switch (DecoderStateTables.DII[this._b]) {
/*      */         case 0:
/*  406 */           processEII(this._elementNameTable._array[this._b], false);
/*  407 */           firstElementHasOccured = true;
/*      */           continue;
/*      */         case 1:
/*  410 */           processEII(this._elementNameTable._array[this._b & 0x1F], true);
/*  411 */           firstElementHasOccured = true;
/*      */           continue;
/*      */         case 2:
/*  414 */           processEII(decodeEIIIndexMedium(), ((this._b & 0x40) > 0));
/*  415 */           firstElementHasOccured = true;
/*      */           continue;
/*      */         case 3:
/*  418 */           processEII(decodeEIIIndexLarge(), ((this._b & 0x40) > 0));
/*  419 */           firstElementHasOccured = true;
/*      */           continue;
/*      */         
/*      */         case 5:
/*  423 */           qn = decodeLiteralQualifiedName(this._b & 0x3);
/*      */           
/*  425 */           this._elementNameTable.add(qn);
/*  426 */           processEII(qn, ((this._b & 0x40) > 0));
/*  427 */           firstElementHasOccured = true;
/*      */           continue;
/*      */         
/*      */         case 4:
/*  431 */           processEIIWithNamespaces();
/*  432 */           firstElementHasOccured = true;
/*      */           continue;
/*      */         
/*      */         case 20:
/*  436 */           if (documentTypeDeclarationOccured) {
/*  437 */             throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.secondOccurenceOfDTDII"));
/*      */           }
/*  439 */           documentTypeDeclarationOccured = true;
/*      */           
/*  441 */           system_identifier = ((this._b & 0x2) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */           
/*  443 */           public_identifier = ((this._b & 0x1) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */ 
/*      */           
/*  446 */           this._b = read();
/*  447 */           while (this._b == 225) {
/*  448 */             String data; switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */               case 0:
/*  450 */                 data = new String(this._charBuffer, 0, this._charBufferLength);
/*  451 */                 if (this._addToTable) {
/*  452 */                   this._v.otherString.add(new CharArray(this._charBuffer, 0, this._charBufferLength, true));
/*      */                 }
/*      */                 break;
/*      */               case 2:
/*  456 */                 throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.processingIIWithEncodingAlgorithm"));
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  462 */             this._b = read();
/*      */           } 
/*  464 */           if ((this._b & 0xF0) != 240) {
/*  465 */             throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.processingInstructionIIsNotTerminatedCorrectly"));
/*      */           }
/*  467 */           if (this._b == 255) {
/*  468 */             this._terminate = true;
/*      */           }
/*      */           
/*  471 */           this._notations.clear();
/*  472 */           this._unparsedEntities.clear();
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 18:
/*  480 */           processCommentII();
/*      */           continue;
/*      */         case 19:
/*  483 */           processProcessingII();
/*      */           continue;
/*      */         case 23:
/*  486 */           this._doubleTerminate = true;
/*      */         case 22:
/*  488 */           this._terminate = true;
/*      */           continue;
/*      */       } 
/*  491 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingDII"));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  496 */     while (!this._terminate) {
/*  497 */       this._b = read();
/*  498 */       switch (DecoderStateTables.DII[this._b]) {
/*      */         case 18:
/*  500 */           processCommentII();
/*      */           continue;
/*      */         case 19:
/*  503 */           processProcessingII();
/*      */           continue;
/*      */         case 23:
/*  506 */           this._doubleTerminate = true;
/*      */         case 22:
/*  508 */           this._terminate = true;
/*      */           continue;
/*      */       } 
/*  511 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingDII"));
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  516 */       this._contentHandler.endDocument();
/*  517 */     } catch (SAXException e) {
/*  518 */       throw new FastInfosetException("processDII", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void processDIIOptionalProperties() throws FastInfosetException, IOException {
/*  524 */     if (this._b == 32) {
/*  525 */       decodeInitialVocabulary();
/*      */       
/*      */       return;
/*      */     } 
/*  529 */     if ((this._b & 0x40) > 0) {
/*  530 */       decodeAdditionalData();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  537 */     if ((this._b & 0x20) > 0) {
/*  538 */       decodeInitialVocabulary();
/*      */     }
/*      */     
/*  541 */     if ((this._b & 0x10) > 0) {
/*  542 */       decodeNotations();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  552 */     if ((this._b & 0x8) > 0) {
/*  553 */       decodeUnparsedEntities();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  563 */     if ((this._b & 0x4) > 0) {
/*  564 */       String characterEncodingScheme = decodeCharacterEncodingScheme();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  571 */     if ((this._b & 0x2) > 0) {
/*  572 */       boolean standalone = (read() > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  579 */     if ((this._b & 0x1) > 0) {
/*  580 */       String version = decodeVersion();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void processEII(QualifiedName name, boolean hasAttributes) throws FastInfosetException, IOException {
/*  589 */     if (this._prefixTable._currentInScope[name.prefixIndex] != name.namespaceNameIndex) {
/*  590 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.qNameOfEIINotInScope"));
/*      */     }
/*      */     
/*  593 */     if (hasAttributes) {
/*  594 */       processAIIs();
/*      */     }
/*      */     
/*      */     try {
/*  598 */       this._contentHandler.startElement(name.namespaceName, name.localName, name.qName, (Attributes)this._attributes);
/*  599 */     } catch (SAXException e) {
/*  600 */       e.printStackTrace();
/*  601 */       throw new FastInfosetException("processEII", e);
/*      */     } 
/*      */     
/*  604 */     if (this._clearAttributes) {
/*  605 */       this._attributes.clear();
/*  606 */       this._clearAttributes = false;
/*      */     } 
/*      */     
/*  609 */     while (!this._terminate) {
/*  610 */       QualifiedName qn; boolean addToTable; int index; String entity_reference_name, system_identifier, public_identifier; this._b = read();
/*  611 */       switch (DecoderStateTables.EII[this._b]) {
/*      */         case 0:
/*  613 */           processEII(this._elementNameTable._array[this._b], false);
/*      */           continue;
/*      */         case 1:
/*  616 */           processEII(this._elementNameTable._array[this._b & 0x1F], true);
/*      */           continue;
/*      */         case 2:
/*  619 */           processEII(decodeEIIIndexMedium(), ((this._b & 0x40) > 0));
/*      */           continue;
/*      */         case 3:
/*  622 */           processEII(decodeEIIIndexLarge(), ((this._b & 0x40) > 0));
/*      */           continue;
/*      */         
/*      */         case 5:
/*  626 */           qn = decodeLiteralQualifiedName(this._b & 0x3);
/*      */           
/*  628 */           this._elementNameTable.add(qn);
/*  629 */           processEII(qn, ((this._b & 0x40) > 0));
/*      */           continue;
/*      */         
/*      */         case 4:
/*  633 */           processEIIWithNamespaces();
/*      */           continue;
/*      */         case 6:
/*  636 */           this._octetBufferLength = (this._b & 0x1) + 1;
/*      */           
/*  638 */           decodeUtf8StringAsCharBuffer();
/*  639 */           if ((this._b & 0x10) > 0) {
/*  640 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*      */           try {
/*  644 */             this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/*  645 */           } catch (SAXException e) {
/*  646 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */         case 7:
/*  650 */           this._octetBufferLength = read() + 3;
/*  651 */           decodeUtf8StringAsCharBuffer();
/*  652 */           if ((this._b & 0x10) > 0) {
/*  653 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*      */           try {
/*  657 */             this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/*  658 */           } catch (SAXException e) {
/*  659 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */         case 8:
/*  663 */           this._octetBufferLength = (read() << 24 | read() << 16 | read() << 8 | read()) + 259;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  668 */           decodeUtf8StringAsCharBuffer();
/*  669 */           if ((this._b & 0x10) > 0) {
/*  670 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*      */           try {
/*  674 */             this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/*  675 */           } catch (SAXException e) {
/*  676 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */         case 9:
/*  680 */           this._octetBufferLength = (this._b & 0x1) + 1;
/*      */           
/*  682 */           decodeUtf16StringAsCharBuffer();
/*  683 */           if ((this._b & 0x10) > 0) {
/*  684 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*      */           try {
/*  688 */             this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/*  689 */           } catch (SAXException e) {
/*  690 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */         case 10:
/*  694 */           this._octetBufferLength = read() + 3;
/*  695 */           decodeUtf16StringAsCharBuffer();
/*  696 */           if ((this._b & 0x10) > 0) {
/*  697 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*      */           try {
/*  701 */             this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/*  702 */           } catch (SAXException e) {
/*  703 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */         case 11:
/*  707 */           this._octetBufferLength = (read() << 24 | read() << 16 | read() << 8 | read()) + 259;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  712 */           decodeUtf16StringAsCharBuffer();
/*  713 */           if ((this._b & 0x10) > 0) {
/*  714 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*      */           try {
/*  718 */             this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/*  719 */           } catch (SAXException e) {
/*  720 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 12:
/*  725 */           addToTable = ((this._b & 0x10) > 0);
/*      */ 
/*      */           
/*  728 */           this._identifier = (this._b & 0x2) << 6;
/*  729 */           this._b = read();
/*  730 */           this._identifier |= (this._b & 0xFC) >> 2;
/*      */           
/*  732 */           decodeOctetsOnSeventhBitOfNonIdentifyingStringOnThirdBit(this._b);
/*      */           
/*  734 */           decodeRestrictedAlphabetAsCharBuffer();
/*      */           
/*  736 */           if (addToTable) {
/*  737 */             this._characterContentChunkTable.add(this._charBuffer, this._charBufferLength);
/*      */           }
/*      */           
/*      */           try {
/*  741 */             this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/*  742 */           } catch (SAXException e) {
/*  743 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 13:
/*  749 */           if ((this._b & 0x40) > 0) {
/*  750 */             throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.addToTableNotSupported"));
/*      */           }
/*      */ 
/*      */           
/*  754 */           this._identifier = (this._b & 0x2) << 6;
/*  755 */           this._b = read();
/*  756 */           this._identifier |= (this._b & 0xFC) >> 2;
/*      */           
/*  758 */           decodeOctetsOnSeventhBitOfNonIdentifyingStringOnThirdBit(this._b);
/*      */           
/*  760 */           processCIIEncodingAlgorithm();
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 14:
/*  765 */           index = this._b & 0xF;
/*      */           try {
/*  767 */             this._contentHandler.characters(this._characterContentChunkTable._array, this._characterContentChunkTable._offset[index], this._characterContentChunkTable._length[index]);
/*      */           
/*      */           }
/*  770 */           catch (SAXException e) {
/*  771 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 15:
/*  777 */           index = ((this._b & 0x3) << 8 | read()) + 16;
/*      */           
/*      */           try {
/*  780 */             this._contentHandler.characters(this._characterContentChunkTable._array, this._characterContentChunkTable._offset[index], this._characterContentChunkTable._length[index]);
/*      */           
/*      */           }
/*  783 */           catch (SAXException e) {
/*  784 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 16:
/*  790 */           index = ((this._b & 0x3) << 16 | read() << 8 | read()) + 1040;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*  796 */             this._contentHandler.characters(this._characterContentChunkTable._array, this._characterContentChunkTable._offset[index], this._characterContentChunkTable._length[index]);
/*      */           
/*      */           }
/*  799 */           catch (SAXException e) {
/*  800 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 17:
/*  806 */           index = (read() << 16 | read() << 8 | read()) + 263184;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*  812 */             this._contentHandler.characters(this._characterContentChunkTable._array, this._characterContentChunkTable._offset[index], this._characterContentChunkTable._length[index]);
/*      */           
/*      */           }
/*  815 */           catch (SAXException e) {
/*  816 */             throw new FastInfosetException("processCII", e);
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 18:
/*  821 */           processCommentII();
/*      */           continue;
/*      */         case 19:
/*  824 */           processProcessingII();
/*      */           continue;
/*      */         
/*      */         case 21:
/*  828 */           entity_reference_name = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*      */           
/*  830 */           system_identifier = ((this._b & 0x2) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */           
/*  832 */           public_identifier = ((this._b & 0x1) > 0) ? decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherURI) : "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*  843 */             this._contentHandler.skippedEntity(entity_reference_name);
/*  844 */           } catch (SAXException e) {
/*  845 */             throw new FastInfosetException("processUnexpandedEntityReferenceII", e);
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 23:
/*  850 */           this._doubleTerminate = true;
/*      */         case 22:
/*  852 */           this._terminate = true;
/*      */           continue;
/*      */       } 
/*  855 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingEII"));
/*      */     } 
/*      */ 
/*      */     
/*  859 */     this._terminate = this._doubleTerminate;
/*  860 */     this._doubleTerminate = false;
/*      */     
/*      */     try {
/*  863 */       this._contentHandler.endElement(name.namespaceName, name.localName, name.qName);
/*  864 */     } catch (SAXException e) {
/*  865 */       throw new FastInfosetException("processEII", e);
/*      */     } 
/*      */   }
/*      */   protected final void processEIIWithNamespaces() throws FastInfosetException, IOException {
/*      */     QualifiedName qn;
/*  870 */     boolean hasAttributes = ((this._b & 0x40) > 0);
/*      */     
/*  872 */     this._clearAttributes = this._namespacePrefixesFeature;
/*      */     
/*  874 */     if (++this._prefixTable._declarationId == Integer.MAX_VALUE) {
/*  875 */       this._prefixTable.clearDeclarationIds();
/*      */     }
/*      */     
/*  878 */     String prefix = "", namespaceName = "";
/*  879 */     int start = this._namespacePrefixesIndex;
/*  880 */     int b = read();
/*  881 */     while ((b & 0xFC) == 204) {
/*  882 */       if (this._namespacePrefixesIndex == this._namespacePrefixes.length) {
/*  883 */         int[] namespaceAIIs = new int[this._namespacePrefixesIndex * 3 / 2 + 1];
/*  884 */         System.arraycopy(this._namespacePrefixes, 0, namespaceAIIs, 0, this._namespacePrefixesIndex);
/*  885 */         this._namespacePrefixes = namespaceAIIs;
/*      */       } 
/*      */       
/*  888 */       switch (b & 0x3) {
/*      */ 
/*      */         
/*      */         case 0:
/*  892 */           prefix = namespaceName = "";
/*  893 */           this._namespacePrefixes[this._namespacePrefixesIndex++] = -1; this._namespaceNameIndex = this._prefixIndex = -1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/*  898 */           prefix = "";
/*  899 */           namespaceName = decodeIdentifyingNonEmptyStringOnFirstBitAsNamespaceName(false);
/*      */           
/*  901 */           this._prefixIndex = this._namespacePrefixes[this._namespacePrefixesIndex++] = -1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/*  906 */           prefix = decodeIdentifyingNonEmptyStringOnFirstBitAsPrefix(false);
/*  907 */           namespaceName = "";
/*      */           
/*  909 */           this._namespaceNameIndex = -1;
/*  910 */           this._namespacePrefixes[this._namespacePrefixesIndex++] = this._prefixIndex;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*  915 */           prefix = decodeIdentifyingNonEmptyStringOnFirstBitAsPrefix(true);
/*  916 */           namespaceName = decodeIdentifyingNonEmptyStringOnFirstBitAsNamespaceName(true);
/*      */           
/*  918 */           this._namespacePrefixes[this._namespacePrefixesIndex++] = this._prefixIndex;
/*      */           break;
/*      */       } 
/*      */       
/*  922 */       this._prefixTable.pushScope(this._prefixIndex, this._namespaceNameIndex);
/*      */       
/*  924 */       if (this._namespacePrefixesFeature)
/*      */       {
/*  926 */         if (prefix != "") {
/*  927 */           this._attributes.addAttribute(new QualifiedName("xmlns", "http://www.w3.org/2000/xmlns/", prefix), namespaceName);
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/*  933 */           this._attributes.addAttribute(EncodingConstants.DEFAULT_NAMESPACE_DECLARATION, namespaceName);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  939 */         this._contentHandler.startPrefixMapping(prefix, namespaceName);
/*  940 */       } catch (SAXException e) {
/*  941 */         throw new IOException("processStartNamespaceAII");
/*      */       } 
/*      */       
/*  944 */       b = read();
/*      */     } 
/*  946 */     if (b != 240) {
/*  947 */       throw new IOException(CommonResourceBundle.getInstance().getString("message.EIInamespaceNameNotTerminatedCorrectly"));
/*      */     }
/*  949 */     int end = this._namespacePrefixesIndex;
/*      */     
/*  951 */     this._b = read();
/*  952 */     switch (DecoderStateTables.EII[this._b]) {
/*      */       case 0:
/*  954 */         processEII(this._elementNameTable._array[this._b], hasAttributes);
/*      */         break;
/*      */       case 2:
/*  957 */         processEII(decodeEIIIndexMedium(), hasAttributes);
/*      */         break;
/*      */       case 3:
/*  960 */         processEII(decodeEIIIndexLarge(), hasAttributes);
/*      */         break;
/*      */       
/*      */       case 5:
/*  964 */         qn = decodeLiteralQualifiedName(this._b & 0x3);
/*      */         
/*  966 */         this._elementNameTable.add(qn);
/*  967 */         processEII(qn, hasAttributes);
/*      */         break;
/*      */       
/*      */       default:
/*  971 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.IllegalStateDecodingEIIAfterAIIs"));
/*      */     } 
/*      */     
/*      */     try {
/*  975 */       for (int i = end - 1; i >= start; i--) {
/*  976 */         int prefixIndex = this._namespacePrefixes[i];
/*  977 */         this._prefixTable.popScope(prefixIndex);
/*  978 */         prefix = (prefixIndex > 0) ? this._prefixTable.get(prefixIndex - 1) : ((prefixIndex == -1) ? "" : "xml");
/*      */         
/*  980 */         this._contentHandler.endPrefixMapping(prefix);
/*      */       } 
/*  982 */       this._namespacePrefixesIndex = start;
/*  983 */     } catch (SAXException e) {
/*  984 */       throw new IOException("processStartNamespaceAII");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void processAIIs() throws FastInfosetException, IOException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: iconst_1
/*      */     //   2: putfield _clearAttributes : Z
/*      */     //   5: aload_0
/*      */     //   6: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   9: dup
/*      */     //   10: getfield _currentIteration : I
/*      */     //   13: iconst_1
/*      */     //   14: iadd
/*      */     //   15: dup_x1
/*      */     //   16: putfield _currentIteration : I
/*      */     //   19: ldc 2147483647
/*      */     //   21: if_icmpne -> 31
/*      */     //   24: aload_0
/*      */     //   25: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   28: invokevirtual clear : ()V
/*      */     //   31: aload_0
/*      */     //   32: invokevirtual read : ()I
/*      */     //   35: istore_2
/*      */     //   36: getstatic com/sun/xml/fastinfoset/DecoderStateTables.AII : [I
/*      */     //   39: iload_2
/*      */     //   40: iaload
/*      */     //   41: tableswitch default -> 208, 0 -> 80, 1 -> 93, 2 -> 124, 3 -> 164, 4 -> 200, 5 -> 195
/*      */     //   80: aload_0
/*      */     //   81: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   84: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   87: iload_2
/*      */     //   88: aaload
/*      */     //   89: astore_1
/*      */     //   90: goto -> 224
/*      */     //   93: iload_2
/*      */     //   94: bipush #31
/*      */     //   96: iand
/*      */     //   97: bipush #8
/*      */     //   99: ishl
/*      */     //   100: aload_0
/*      */     //   101: invokevirtual read : ()I
/*      */     //   104: ior
/*      */     //   105: bipush #64
/*      */     //   107: iadd
/*      */     //   108: istore #4
/*      */     //   110: aload_0
/*      */     //   111: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   114: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   117: iload #4
/*      */     //   119: aaload
/*      */     //   120: astore_1
/*      */     //   121: goto -> 224
/*      */     //   124: iload_2
/*      */     //   125: bipush #15
/*      */     //   127: iand
/*      */     //   128: bipush #16
/*      */     //   130: ishl
/*      */     //   131: aload_0
/*      */     //   132: invokevirtual read : ()I
/*      */     //   135: bipush #8
/*      */     //   137: ishl
/*      */     //   138: ior
/*      */     //   139: aload_0
/*      */     //   140: invokevirtual read : ()I
/*      */     //   143: ior
/*      */     //   144: sipush #8256
/*      */     //   147: iadd
/*      */     //   148: istore #4
/*      */     //   150: aload_0
/*      */     //   151: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   154: getfield _array : [Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   157: iload #4
/*      */     //   159: aaload
/*      */     //   160: astore_1
/*      */     //   161: goto -> 224
/*      */     //   164: aload_0
/*      */     //   165: iload_2
/*      */     //   166: iconst_3
/*      */     //   167: iand
/*      */     //   168: invokevirtual decodeLiteralQualifiedName : (I)Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   171: astore_1
/*      */     //   172: aload_1
/*      */     //   173: aload_0
/*      */     //   174: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   177: pop
/*      */     //   178: sipush #256
/*      */     //   181: invokevirtual createAttributeValues : (I)V
/*      */     //   184: aload_0
/*      */     //   185: getfield _attributeNameTable : Lcom/sun/xml/fastinfoset/util/QualifiedNameArray;
/*      */     //   188: aload_1
/*      */     //   189: invokevirtual add : (Lcom/sun/xml/fastinfoset/QualifiedName;)V
/*      */     //   192: goto -> 224
/*      */     //   195: aload_0
/*      */     //   196: iconst_1
/*      */     //   197: putfield _doubleTerminate : Z
/*      */     //   200: aload_0
/*      */     //   201: iconst_1
/*      */     //   202: putfield _terminate : Z
/*      */     //   205: goto -> 949
/*      */     //   208: new java/io/IOException
/*      */     //   211: dup
/*      */     //   212: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   215: ldc 'message.decodingAIIs'
/*      */     //   217: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   220: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   223: athrow
/*      */     //   224: aload_1
/*      */     //   225: getfield prefixIndex : I
/*      */     //   228: ifle -> 266
/*      */     //   231: aload_0
/*      */     //   232: getfield _prefixTable : Lcom/sun/xml/fastinfoset/util/PrefixArray;
/*      */     //   235: getfield _currentInScope : [I
/*      */     //   238: aload_1
/*      */     //   239: getfield prefixIndex : I
/*      */     //   242: iaload
/*      */     //   243: aload_1
/*      */     //   244: getfield namespaceNameIndex : I
/*      */     //   247: if_icmpeq -> 266
/*      */     //   250: new org/jvnet/fastinfoset/FastInfosetException
/*      */     //   253: dup
/*      */     //   254: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   257: ldc 'message.AIIqNameNotInScope'
/*      */     //   259: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   262: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   265: athrow
/*      */     //   266: aload_0
/*      */     //   267: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   270: aload_1
/*      */     //   271: getfield attributeHash : I
/*      */     //   274: aload_1
/*      */     //   275: getfield attributeId : I
/*      */     //   278: invokevirtual checkForDuplicateAttribute : (II)V
/*      */     //   281: aload_0
/*      */     //   282: invokevirtual read : ()I
/*      */     //   285: istore_2
/*      */     //   286: getstatic com/sun/xml/fastinfoset/DecoderStateTables.NISTRING : [I
/*      */     //   289: iload_2
/*      */     //   290: iaload
/*      */     //   291: tableswitch default -> 933, 0 -> 352, 1 -> 395, 2 -> 439, 3 -> 508, 4 -> 551, 5 -> 595, 6 -> 664, 7 -> 745, 8 -> 812, 9 -> 835, 10 -> 873, 11 -> 920
/*      */     //   352: aload_0
/*      */     //   353: iload_2
/*      */     //   354: bipush #7
/*      */     //   356: iand
/*      */     //   357: iconst_1
/*      */     //   358: iadd
/*      */     //   359: putfield _octetBufferLength : I
/*      */     //   362: aload_0
/*      */     //   363: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*      */     //   366: astore_3
/*      */     //   367: iload_2
/*      */     //   368: bipush #64
/*      */     //   370: iand
/*      */     //   371: ifle -> 383
/*      */     //   374: aload_0
/*      */     //   375: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   378: aload_3
/*      */     //   379: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   382: pop
/*      */     //   383: aload_0
/*      */     //   384: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   387: aload_1
/*      */     //   388: aload_3
/*      */     //   389: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   392: goto -> 949
/*      */     //   395: aload_0
/*      */     //   396: aload_0
/*      */     //   397: invokevirtual read : ()I
/*      */     //   400: bipush #9
/*      */     //   402: iadd
/*      */     //   403: putfield _octetBufferLength : I
/*      */     //   406: aload_0
/*      */     //   407: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*      */     //   410: astore_3
/*      */     //   411: iload_2
/*      */     //   412: bipush #64
/*      */     //   414: iand
/*      */     //   415: ifle -> 427
/*      */     //   418: aload_0
/*      */     //   419: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   422: aload_3
/*      */     //   423: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   426: pop
/*      */     //   427: aload_0
/*      */     //   428: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   431: aload_1
/*      */     //   432: aload_3
/*      */     //   433: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   436: goto -> 949
/*      */     //   439: aload_0
/*      */     //   440: aload_0
/*      */     //   441: invokevirtual read : ()I
/*      */     //   444: bipush #24
/*      */     //   446: ishl
/*      */     //   447: aload_0
/*      */     //   448: invokevirtual read : ()I
/*      */     //   451: bipush #16
/*      */     //   453: ishl
/*      */     //   454: ior
/*      */     //   455: aload_0
/*      */     //   456: invokevirtual read : ()I
/*      */     //   459: bipush #8
/*      */     //   461: ishl
/*      */     //   462: ior
/*      */     //   463: aload_0
/*      */     //   464: invokevirtual read : ()I
/*      */     //   467: ior
/*      */     //   468: sipush #265
/*      */     //   471: iadd
/*      */     //   472: putfield _octetBufferLength : I
/*      */     //   475: aload_0
/*      */     //   476: invokevirtual decodeUtf8StringAsString : ()Ljava/lang/String;
/*      */     //   479: astore_3
/*      */     //   480: iload_2
/*      */     //   481: bipush #64
/*      */     //   483: iand
/*      */     //   484: ifle -> 496
/*      */     //   487: aload_0
/*      */     //   488: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   491: aload_3
/*      */     //   492: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   495: pop
/*      */     //   496: aload_0
/*      */     //   497: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   500: aload_1
/*      */     //   501: aload_3
/*      */     //   502: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   505: goto -> 949
/*      */     //   508: aload_0
/*      */     //   509: iload_2
/*      */     //   510: bipush #7
/*      */     //   512: iand
/*      */     //   513: iconst_1
/*      */     //   514: iadd
/*      */     //   515: putfield _octetBufferLength : I
/*      */     //   518: aload_0
/*      */     //   519: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*      */     //   522: astore_3
/*      */     //   523: iload_2
/*      */     //   524: bipush #64
/*      */     //   526: iand
/*      */     //   527: ifle -> 539
/*      */     //   530: aload_0
/*      */     //   531: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   534: aload_3
/*      */     //   535: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   538: pop
/*      */     //   539: aload_0
/*      */     //   540: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   543: aload_1
/*      */     //   544: aload_3
/*      */     //   545: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   548: goto -> 949
/*      */     //   551: aload_0
/*      */     //   552: aload_0
/*      */     //   553: invokevirtual read : ()I
/*      */     //   556: bipush #9
/*      */     //   558: iadd
/*      */     //   559: putfield _octetBufferLength : I
/*      */     //   562: aload_0
/*      */     //   563: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*      */     //   566: astore_3
/*      */     //   567: iload_2
/*      */     //   568: bipush #64
/*      */     //   570: iand
/*      */     //   571: ifle -> 583
/*      */     //   574: aload_0
/*      */     //   575: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   578: aload_3
/*      */     //   579: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   582: pop
/*      */     //   583: aload_0
/*      */     //   584: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   587: aload_1
/*      */     //   588: aload_3
/*      */     //   589: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   592: goto -> 949
/*      */     //   595: aload_0
/*      */     //   596: aload_0
/*      */     //   597: invokevirtual read : ()I
/*      */     //   600: bipush #24
/*      */     //   602: ishl
/*      */     //   603: aload_0
/*      */     //   604: invokevirtual read : ()I
/*      */     //   607: bipush #16
/*      */     //   609: ishl
/*      */     //   610: ior
/*      */     //   611: aload_0
/*      */     //   612: invokevirtual read : ()I
/*      */     //   615: bipush #8
/*      */     //   617: ishl
/*      */     //   618: ior
/*      */     //   619: aload_0
/*      */     //   620: invokevirtual read : ()I
/*      */     //   623: ior
/*      */     //   624: sipush #265
/*      */     //   627: iadd
/*      */     //   628: putfield _octetBufferLength : I
/*      */     //   631: aload_0
/*      */     //   632: invokevirtual decodeUtf16StringAsString : ()Ljava/lang/String;
/*      */     //   635: astore_3
/*      */     //   636: iload_2
/*      */     //   637: bipush #64
/*      */     //   639: iand
/*      */     //   640: ifle -> 652
/*      */     //   643: aload_0
/*      */     //   644: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   647: aload_3
/*      */     //   648: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   651: pop
/*      */     //   652: aload_0
/*      */     //   653: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   656: aload_1
/*      */     //   657: aload_3
/*      */     //   658: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   661: goto -> 949
/*      */     //   664: iload_2
/*      */     //   665: bipush #64
/*      */     //   667: iand
/*      */     //   668: ifle -> 675
/*      */     //   671: iconst_1
/*      */     //   672: goto -> 676
/*      */     //   675: iconst_0
/*      */     //   676: istore #4
/*      */     //   678: aload_0
/*      */     //   679: iload_2
/*      */     //   680: bipush #15
/*      */     //   682: iand
/*      */     //   683: iconst_4
/*      */     //   684: ishl
/*      */     //   685: putfield _identifier : I
/*      */     //   688: aload_0
/*      */     //   689: invokevirtual read : ()I
/*      */     //   692: istore_2
/*      */     //   693: aload_0
/*      */     //   694: dup
/*      */     //   695: getfield _identifier : I
/*      */     //   698: iload_2
/*      */     //   699: sipush #240
/*      */     //   702: iand
/*      */     //   703: iconst_4
/*      */     //   704: ishr
/*      */     //   705: ior
/*      */     //   706: putfield _identifier : I
/*      */     //   709: aload_0
/*      */     //   710: iload_2
/*      */     //   711: invokevirtual decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit : (I)V
/*      */     //   714: aload_0
/*      */     //   715: invokevirtual decodeRestrictedAlphabetAsString : ()Ljava/lang/String;
/*      */     //   718: astore_3
/*      */     //   719: iload #4
/*      */     //   721: ifeq -> 733
/*      */     //   724: aload_0
/*      */     //   725: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   728: aload_3
/*      */     //   729: invokevirtual add : (Ljava/lang/String;)I
/*      */     //   732: pop
/*      */     //   733: aload_0
/*      */     //   734: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   737: aload_1
/*      */     //   738: aload_3
/*      */     //   739: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   742: goto -> 949
/*      */     //   745: iload_2
/*      */     //   746: bipush #64
/*      */     //   748: iand
/*      */     //   749: ifle -> 768
/*      */     //   752: new org/jvnet/fastinfoset/EncodingAlgorithmException
/*      */     //   755: dup
/*      */     //   756: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   759: ldc 'message.addToTableNotSupported'
/*      */     //   761: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   764: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   767: athrow
/*      */     //   768: aload_0
/*      */     //   769: iload_2
/*      */     //   770: bipush #15
/*      */     //   772: iand
/*      */     //   773: iconst_4
/*      */     //   774: ishl
/*      */     //   775: putfield _identifier : I
/*      */     //   778: aload_0
/*      */     //   779: invokevirtual read : ()I
/*      */     //   782: istore_2
/*      */     //   783: aload_0
/*      */     //   784: dup
/*      */     //   785: getfield _identifier : I
/*      */     //   788: iload_2
/*      */     //   789: sipush #240
/*      */     //   792: iand
/*      */     //   793: iconst_4
/*      */     //   794: ishr
/*      */     //   795: ior
/*      */     //   796: putfield _identifier : I
/*      */     //   799: aload_0
/*      */     //   800: iload_2
/*      */     //   801: invokevirtual decodeOctetsOnFifthBitOfNonIdentifyingStringOnFirstBit : (I)V
/*      */     //   804: aload_0
/*      */     //   805: aload_1
/*      */     //   806: invokevirtual processAIIEncodingAlgorithm : (Lcom/sun/xml/fastinfoset/QualifiedName;)V
/*      */     //   809: goto -> 949
/*      */     //   812: aload_0
/*      */     //   813: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   816: aload_1
/*      */     //   817: aload_0
/*      */     //   818: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   821: getfield _array : [Ljava/lang/String;
/*      */     //   824: iload_2
/*      */     //   825: bipush #63
/*      */     //   827: iand
/*      */     //   828: aaload
/*      */     //   829: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   832: goto -> 949
/*      */     //   835: iload_2
/*      */     //   836: bipush #31
/*      */     //   838: iand
/*      */     //   839: bipush #8
/*      */     //   841: ishl
/*      */     //   842: aload_0
/*      */     //   843: invokevirtual read : ()I
/*      */     //   846: ior
/*      */     //   847: bipush #64
/*      */     //   849: iadd
/*      */     //   850: istore #4
/*      */     //   852: aload_0
/*      */     //   853: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   856: aload_1
/*      */     //   857: aload_0
/*      */     //   858: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   861: getfield _array : [Ljava/lang/String;
/*      */     //   864: iload #4
/*      */     //   866: aaload
/*      */     //   867: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   870: goto -> 949
/*      */     //   873: iload_2
/*      */     //   874: bipush #15
/*      */     //   876: iand
/*      */     //   877: bipush #16
/*      */     //   879: ishl
/*      */     //   880: aload_0
/*      */     //   881: invokevirtual read : ()I
/*      */     //   884: bipush #8
/*      */     //   886: ishl
/*      */     //   887: ior
/*      */     //   888: aload_0
/*      */     //   889: invokevirtual read : ()I
/*      */     //   892: ior
/*      */     //   893: sipush #8256
/*      */     //   896: iadd
/*      */     //   897: istore #4
/*      */     //   899: aload_0
/*      */     //   900: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   903: aload_1
/*      */     //   904: aload_0
/*      */     //   905: getfield _attributeValueTable : Lcom/sun/xml/fastinfoset/util/StringArray;
/*      */     //   908: getfield _array : [Ljava/lang/String;
/*      */     //   911: iload #4
/*      */     //   913: aaload
/*      */     //   914: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   917: goto -> 949
/*      */     //   920: aload_0
/*      */     //   921: getfield _attributes : Lcom/sun/xml/fastinfoset/sax/AttributesHolder;
/*      */     //   924: aload_1
/*      */     //   925: ldc ''
/*      */     //   927: invokevirtual addAttribute : (Lcom/sun/xml/fastinfoset/QualifiedName;Ljava/lang/String;)V
/*      */     //   930: goto -> 949
/*      */     //   933: new java/io/IOException
/*      */     //   936: dup
/*      */     //   937: invokestatic getInstance : ()Lcom/sun/xml/fastinfoset/CommonResourceBundle;
/*      */     //   940: ldc 'message.decodingAIIValue'
/*      */     //   942: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   945: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   948: athrow
/*      */     //   949: aload_0
/*      */     //   950: getfield _terminate : Z
/*      */     //   953: ifeq -> 31
/*      */     //   956: aload_0
/*      */     //   957: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   960: aload_0
/*      */     //   961: getfield _duplicateAttributeVerifier : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier;
/*      */     //   964: getfield _poolHead : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier$Entry;
/*      */     //   967: putfield _poolCurrent : Lcom/sun/xml/fastinfoset/util/DuplicateAttributeVerifier$Entry;
/*      */     //   970: aload_0
/*      */     //   971: aload_0
/*      */     //   972: getfield _doubleTerminate : Z
/*      */     //   975: putfield _terminate : Z
/*      */     //   978: aload_0
/*      */     //   979: iconst_0
/*      */     //   980: putfield _doubleTerminate : Z
/*      */     //   983: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #993	-> 0
/*      */     //   #995	-> 5
/*      */     //   #996	-> 24
/*      */     //   #1001	-> 31
/*      */     //   #1002	-> 36
/*      */     //   #1004	-> 80
/*      */     //   #1005	-> 90
/*      */     //   #1008	-> 93
/*      */     //   #1010	-> 110
/*      */     //   #1011	-> 121
/*      */     //   #1015	-> 124
/*      */     //   #1017	-> 150
/*      */     //   #1018	-> 161
/*      */     //   #1021	-> 164
/*      */     //   #1023	-> 172
/*      */     //   #1024	-> 184
/*      */     //   #1025	-> 192
/*      */     //   #1027	-> 195
/*      */     //   #1029	-> 200
/*      */     //   #1031	-> 205
/*      */     //   #1033	-> 208
/*      */     //   #1036	-> 224
/*      */     //   #1037	-> 250
/*      */     //   #1040	-> 266
/*      */     //   #1044	-> 281
/*      */     //   #1045	-> 286
/*      */     //   #1047	-> 352
/*      */     //   #1048	-> 362
/*      */     //   #1049	-> 367
/*      */     //   #1050	-> 374
/*      */     //   #1053	-> 383
/*      */     //   #1054	-> 392
/*      */     //   #1056	-> 395
/*      */     //   #1057	-> 406
/*      */     //   #1058	-> 411
/*      */     //   #1059	-> 418
/*      */     //   #1062	-> 427
/*      */     //   #1063	-> 436
/*      */     //   #1065	-> 439
/*      */     //   #1070	-> 475
/*      */     //   #1071	-> 480
/*      */     //   #1072	-> 487
/*      */     //   #1075	-> 496
/*      */     //   #1076	-> 505
/*      */     //   #1078	-> 508
/*      */     //   #1079	-> 518
/*      */     //   #1080	-> 523
/*      */     //   #1081	-> 530
/*      */     //   #1084	-> 539
/*      */     //   #1085	-> 548
/*      */     //   #1087	-> 551
/*      */     //   #1088	-> 562
/*      */     //   #1089	-> 567
/*      */     //   #1090	-> 574
/*      */     //   #1093	-> 583
/*      */     //   #1094	-> 592
/*      */     //   #1096	-> 595
/*      */     //   #1101	-> 631
/*      */     //   #1102	-> 636
/*      */     //   #1103	-> 643
/*      */     //   #1106	-> 652
/*      */     //   #1107	-> 661
/*      */     //   #1110	-> 664
/*      */     //   #1112	-> 678
/*      */     //   #1113	-> 688
/*      */     //   #1114	-> 693
/*      */     //   #1116	-> 709
/*      */     //   #1118	-> 714
/*      */     //   #1119	-> 719
/*      */     //   #1120	-> 724
/*      */     //   #1123	-> 733
/*      */     //   #1124	-> 742
/*      */     //   #1128	-> 745
/*      */     //   #1129	-> 752
/*      */     //   #1132	-> 768
/*      */     //   #1133	-> 778
/*      */     //   #1134	-> 783
/*      */     //   #1136	-> 799
/*      */     //   #1138	-> 804
/*      */     //   #1139	-> 809
/*      */     //   #1142	-> 812
/*      */     //   #1144	-> 832
/*      */     //   #1147	-> 835
/*      */     //   #1150	-> 852
/*      */     //   #1152	-> 870
/*      */     //   #1156	-> 873
/*      */     //   #1159	-> 899
/*      */     //   #1161	-> 917
/*      */     //   #1164	-> 920
/*      */     //   #1165	-> 930
/*      */     //   #1167	-> 933
/*      */     //   #1170	-> 949
/*      */     //   #1173	-> 956
/*      */     //   #1175	-> 970
/*      */     //   #1176	-> 978
/*      */     //   #1177	-> 983
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   110	14	4	i	I
/*      */     //   150	14	4	i	I
/*      */     //   678	67	4	addToTable	Z
/*      */     //   852	21	4	index	I
/*      */     //   899	21	4	index	I
/*      */     //   90	859	1	name	Lcom/sun/xml/fastinfoset/QualifiedName;
/*      */     //   0	984	0	this	Lcom/sun/xml/fastinfoset/sax/SAXDocumentParser;
/*      */     //   36	948	2	b	I
/*      */     //   367	617	3	value	Ljava/lang/String;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void processCommentII() throws FastInfosetException, IOException {
/*      */     CharArray ca;
/* 1180 */     switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */       case 0:
/* 1182 */         if (this._addToTable) {
/* 1183 */           this._v.otherString.add(new CharArray(this._charBuffer, 0, this._charBufferLength, true));
/*      */         }
/*      */         
/*      */         try {
/* 1187 */           this._lexicalHandler.comment(this._charBuffer, 0, this._charBufferLength);
/* 1188 */         } catch (SAXException e) {
/* 1189 */           throw new FastInfosetException("processCommentII", e);
/*      */         } 
/*      */         break;
/*      */       case 2:
/* 1193 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.commentIIAlgorithmNotSupported"));
/*      */       case 1:
/* 1195 */         ca = this._v.otherString.get(this._integer);
/*      */         
/*      */         try {
/* 1198 */           this._lexicalHandler.comment(ca.ch, ca.start, ca.length);
/* 1199 */         } catch (SAXException e) {
/* 1200 */           throw new FastInfosetException("processCommentII", e);
/*      */         } 
/*      */         break;
/*      */       case 3:
/*      */         try {
/* 1205 */           this._lexicalHandler.comment(this._charBuffer, 0, 0);
/* 1206 */         } catch (SAXException e) {
/* 1207 */           throw new FastInfosetException("processCommentII", e);
/*      */         } 
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void processProcessingII() throws FastInfosetException, IOException {
/* 1214 */     String data, target = decodeIdentifyingNonEmptyStringOnFirstBit(this._v.otherNCName);
/*      */     
/* 1216 */     switch (decodeNonIdentifyingStringOnFirstBit()) {
/*      */       case 0:
/* 1218 */         data = new String(this._charBuffer, 0, this._charBufferLength);
/* 1219 */         if (this._addToTable) {
/* 1220 */           this._v.otherString.add((CharArray)new CharArrayString(data));
/*      */         }
/*      */         try {
/* 1223 */           this._contentHandler.processingInstruction(target, data);
/* 1224 */         } catch (SAXException e) {
/* 1225 */           throw new FastInfosetException("processProcessingII", e);
/*      */         } 
/*      */         break;
/*      */       case 2:
/* 1229 */         throw new IOException(CommonResourceBundle.getInstance().getString("message.processingIIWithEncodingAlgorithm"));
/*      */       case 1:
/*      */         try {
/* 1232 */           this._contentHandler.processingInstruction(target, this._v.otherString.get(this._integer).toString());
/* 1233 */         } catch (SAXException e) {
/* 1234 */           throw new FastInfosetException("processProcessingII", e);
/*      */         } 
/*      */         break;
/*      */       case 3:
/*      */         try {
/* 1239 */           this._contentHandler.processingInstruction(target, "");
/* 1240 */         } catch (SAXException e) {
/* 1241 */           throw new FastInfosetException("processProcessingII", e);
/*      */         } 
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void processCIIEncodingAlgorithm() throws FastInfosetException, IOException {
/* 1248 */     if (this._identifier < 9)
/* 1249 */     { if (this._primitiveHandler != null) {
/* 1250 */         processCIIBuiltInEncodingAlgorithmAsPrimitive();
/* 1251 */       } else if (this._algorithmHandler != null) {
/* 1252 */         Object array = processBuiltInEncodingAlgorithmAsObject();
/*      */         
/*      */         try {
/* 1255 */           this._algorithmHandler.object(null, this._identifier, array);
/* 1256 */         } catch (SAXException e) {
/* 1257 */           throw new FastInfosetException(e);
/*      */         } 
/*      */       } else {
/* 1260 */         StringBuffer buffer = new StringBuffer();
/* 1261 */         processBuiltInEncodingAlgorithmAsCharacters(buffer);
/*      */         
/*      */         try {
/* 1264 */           this._contentHandler.characters(buffer.toString().toCharArray(), 0, buffer.length());
/* 1265 */         } catch (SAXException e) {
/* 1266 */           throw new FastInfosetException(e);
/*      */         } 
/*      */       }  }
/* 1269 */     else if (this._identifier == 9)
/*      */     
/* 1271 */     { this._octetBufferOffset -= this._octetBufferLength;
/* 1272 */       decodeUtf8StringIntoCharBuffer();
/*      */       
/*      */       try {
/* 1275 */         this._lexicalHandler.startCDATA();
/* 1276 */         this._contentHandler.characters(this._charBuffer, 0, this._charBufferLength);
/* 1277 */         this._lexicalHandler.endCDATA();
/* 1278 */       } catch (SAXException e) {
/* 1279 */         throw new FastInfosetException(e);
/*      */       }  }
/* 1281 */     else if (this._identifier >= 32 && this._algorithmHandler != null)
/* 1282 */     { String URI = this._v.encodingAlgorithm.get(this._identifier - 32);
/* 1283 */       if (URI == null) {
/* 1284 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.URINotPresent", new Object[] { new Integer(this._identifier) }));
/*      */       }
/*      */ 
/*      */       
/* 1288 */       EncodingAlgorithm ea = (EncodingAlgorithm)this._registeredEncodingAlgorithms.get(URI);
/* 1289 */       if (ea != null) {
/* 1290 */         Object data = ea.decodeFromBytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */         try {
/* 1292 */           this._algorithmHandler.object(URI, this._identifier, data);
/* 1293 */         } catch (SAXException e) {
/* 1294 */           throw new FastInfosetException(e);
/*      */         } 
/*      */       } else {
/*      */         try {
/* 1298 */           this._algorithmHandler.octets(URI, this._identifier, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/* 1299 */         } catch (SAXException e) {
/* 1300 */           throw new FastInfosetException(e);
/*      */         } 
/*      */       }  }
/* 1303 */     else { if (this._identifier >= 32)
/*      */       {
/* 1305 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.algorithmDataCannotBeReported"));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1311 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.identifiers10to31Reserved")); }
/*      */   
/*      */   }
/*      */   
/*      */   protected final void processCIIBuiltInEncodingAlgorithmAsPrimitive() throws FastInfosetException, IOException {
/*      */     try {
/*      */       int length;
/* 1318 */       switch (this._identifier) {
/*      */         case 0:
/* 1320 */           this._primitiveHandler.bytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */           return;
/*      */         case 1:
/* 1323 */           this._primitiveHandler.bytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */           return;
/*      */         case 2:
/* 1326 */           length = BuiltInEncodingAlgorithmFactory.shortEncodingAlgorithm.getPrimtiveLengthFromOctetLength(this._octetBufferLength);
/*      */           
/* 1328 */           if (length > this.builtInAlgorithmState.shortArray.length) {
/* 1329 */             short[] array = new short[length * 3 / 2 + 1];
/* 1330 */             System.arraycopy(this.builtInAlgorithmState.shortArray, 0, array, 0, this.builtInAlgorithmState.shortArray.length);
/*      */             
/* 1332 */             this.builtInAlgorithmState.shortArray = array;
/*      */           } 
/*      */           
/* 1335 */           BuiltInEncodingAlgorithmFactory.shortEncodingAlgorithm.decodeFromBytesToShortArray(this.builtInAlgorithmState.shortArray, 0, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */           
/* 1338 */           this._primitiveHandler.shorts(this.builtInAlgorithmState.shortArray, 0, length);
/*      */           return;
/*      */         case 3:
/* 1341 */           length = BuiltInEncodingAlgorithmFactory.intEncodingAlgorithm.getPrimtiveLengthFromOctetLength(this._octetBufferLength);
/*      */           
/* 1343 */           if (length > this.builtInAlgorithmState.intArray.length) {
/* 1344 */             int[] array = new int[length * 3 / 2 + 1];
/* 1345 */             System.arraycopy(this.builtInAlgorithmState.intArray, 0, array, 0, this.builtInAlgorithmState.intArray.length);
/*      */             
/* 1347 */             this.builtInAlgorithmState.intArray = array;
/*      */           } 
/*      */           
/* 1350 */           BuiltInEncodingAlgorithmFactory.intEncodingAlgorithm.decodeFromBytesToIntArray(this.builtInAlgorithmState.intArray, 0, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */           
/* 1353 */           this._primitiveHandler.ints(this.builtInAlgorithmState.intArray, 0, length);
/*      */           return;
/*      */         case 4:
/* 1356 */           length = BuiltInEncodingAlgorithmFactory.longEncodingAlgorithm.getPrimtiveLengthFromOctetLength(this._octetBufferLength);
/*      */           
/* 1358 */           if (length > this.builtInAlgorithmState.longArray.length) {
/* 1359 */             long[] array = new long[length * 3 / 2 + 1];
/* 1360 */             System.arraycopy(this.builtInAlgorithmState.longArray, 0, array, 0, this.builtInAlgorithmState.longArray.length);
/*      */             
/* 1362 */             this.builtInAlgorithmState.longArray = array;
/*      */           } 
/*      */           
/* 1365 */           BuiltInEncodingAlgorithmFactory.longEncodingAlgorithm.decodeFromBytesToLongArray(this.builtInAlgorithmState.longArray, 0, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */           
/* 1368 */           this._primitiveHandler.longs(this.builtInAlgorithmState.longArray, 0, length);
/*      */           return;
/*      */         case 5:
/* 1371 */           length = BuiltInEncodingAlgorithmFactory.booleanEncodingAlgorithm.getPrimtiveLengthFromOctetLength(this._octetBufferLength, this._octetBuffer[this._octetBufferStart] & 0xFF);
/*      */           
/* 1373 */           if (length > this.builtInAlgorithmState.booleanArray.length) {
/* 1374 */             boolean[] array = new boolean[length * 3 / 2 + 1];
/* 1375 */             System.arraycopy(this.builtInAlgorithmState.booleanArray, 0, array, 0, this.builtInAlgorithmState.booleanArray.length);
/*      */             
/* 1377 */             this.builtInAlgorithmState.booleanArray = array;
/*      */           } 
/*      */           
/* 1380 */           BuiltInEncodingAlgorithmFactory.booleanEncodingAlgorithm.decodeFromBytesToBooleanArray(this.builtInAlgorithmState.booleanArray, 0, length, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */ 
/*      */           
/* 1384 */           this._primitiveHandler.booleans(this.builtInAlgorithmState.booleanArray, 0, length);
/*      */           return;
/*      */         case 6:
/* 1387 */           length = BuiltInEncodingAlgorithmFactory.floatEncodingAlgorithm.getPrimtiveLengthFromOctetLength(this._octetBufferLength);
/*      */           
/* 1389 */           if (length > this.builtInAlgorithmState.floatArray.length) {
/* 1390 */             float[] array = new float[length * 3 / 2 + 1];
/* 1391 */             System.arraycopy(this.builtInAlgorithmState.floatArray, 0, array, 0, this.builtInAlgorithmState.floatArray.length);
/*      */             
/* 1393 */             this.builtInAlgorithmState.floatArray = array;
/*      */           } 
/*      */           
/* 1396 */           BuiltInEncodingAlgorithmFactory.floatEncodingAlgorithm.decodeFromBytesToFloatArray(this.builtInAlgorithmState.floatArray, 0, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */           
/* 1399 */           this._primitiveHandler.floats(this.builtInAlgorithmState.floatArray, 0, length);
/*      */           return;
/*      */         case 7:
/* 1402 */           length = BuiltInEncodingAlgorithmFactory.doubleEncodingAlgorithm.getPrimtiveLengthFromOctetLength(this._octetBufferLength);
/*      */           
/* 1404 */           if (length > this.builtInAlgorithmState.doubleArray.length) {
/* 1405 */             double[] array = new double[length * 3 / 2 + 1];
/* 1406 */             System.arraycopy(this.builtInAlgorithmState.doubleArray, 0, array, 0, this.builtInAlgorithmState.doubleArray.length);
/*      */             
/* 1408 */             this.builtInAlgorithmState.doubleArray = array;
/*      */           } 
/*      */           
/* 1411 */           BuiltInEncodingAlgorithmFactory.doubleEncodingAlgorithm.decodeFromBytesToDoubleArray(this.builtInAlgorithmState.doubleArray, 0, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */           
/* 1414 */           this._primitiveHandler.doubles(this.builtInAlgorithmState.doubleArray, 0, length);
/*      */           return;
/*      */         case 8:
/* 1417 */           length = BuiltInEncodingAlgorithmFactory.uuidEncodingAlgorithm.getPrimtiveLengthFromOctetLength(this._octetBufferLength);
/*      */           
/* 1419 */           if (length > this.builtInAlgorithmState.longArray.length) {
/* 1420 */             long[] array = new long[length * 3 / 2 + 1];
/* 1421 */             System.arraycopy(this.builtInAlgorithmState.longArray, 0, array, 0, this.builtInAlgorithmState.longArray.length);
/*      */             
/* 1423 */             this.builtInAlgorithmState.longArray = array;
/*      */           } 
/*      */           
/* 1426 */           BuiltInEncodingAlgorithmFactory.uuidEncodingAlgorithm.decodeFromBytesToLongArray(this.builtInAlgorithmState.longArray, 0, this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */           
/* 1429 */           this._primitiveHandler.uuids(this.builtInAlgorithmState.longArray, 0, length);
/*      */           return;
/*      */         case 9:
/* 1432 */           throw new UnsupportedOperationException("CDATA");
/*      */       } 
/* 1434 */       throw new FastInfosetException(CommonResourceBundle.getInstance().getString("message.unsupportedAlgorithm", new Object[] { new Integer(this._identifier) }));
/*      */     
/*      */     }
/* 1437 */     catch (SAXException e) {
/* 1438 */       throw new FastInfosetException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void processAIIEncodingAlgorithm(QualifiedName name) throws FastInfosetException, IOException {
/* 1444 */     if (this._identifier < 9)
/* 1445 */     { if (this._primitiveHandler != null || this._algorithmHandler != null) {
/* 1446 */         Object data = processBuiltInEncodingAlgorithmAsObject();
/* 1447 */         this._attributes.addAttributeWithAlgorithmData(name, null, this._identifier, data);
/*      */       } else {
/* 1449 */         StringBuffer buffer = new StringBuffer();
/* 1450 */         processBuiltInEncodingAlgorithmAsCharacters(buffer);
/* 1451 */         this._attributes.addAttribute(name, buffer.toString());
/*      */       }  }
/* 1453 */     else if (this._identifier >= 32 && this._algorithmHandler != null)
/* 1454 */     { String URI = this._v.encodingAlgorithm.get(this._identifier - 32);
/* 1455 */       if (URI == null) {
/* 1456 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.URINotPresent", new Object[] { new Integer(this._identifier) }));
/*      */       }
/*      */ 
/*      */       
/* 1460 */       EncodingAlgorithm ea = (EncodingAlgorithm)this._registeredEncodingAlgorithms.get(URI);
/* 1461 */       if (ea != null) {
/* 1462 */         Object data = ea.decodeFromBytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/* 1463 */         this._attributes.addAttributeWithAlgorithmData(name, URI, this._identifier, data);
/*      */       } else {
/* 1465 */         byte[] data = new byte[this._octetBufferLength];
/* 1466 */         System.arraycopy(this._octetBuffer, this._octetBufferStart, data, 0, this._octetBufferLength);
/* 1467 */         this._attributes.addAttributeWithAlgorithmData(name, URI, this._identifier, data);
/*      */       }  }
/* 1469 */     else { if (this._identifier >= 32)
/*      */       {
/* 1471 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.algorithmDataCannotBeReported"));
/*      */       }
/* 1473 */       if (this._identifier == 9) {
/* 1474 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.CDATAAlgorithmNotSupported"));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1479 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.identifiers10to31Reserved")); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void processBuiltInEncodingAlgorithmAsCharacters(StringBuffer buffer) throws FastInfosetException, IOException {
/* 1485 */     Object array = BuiltInEncodingAlgorithmFactory.table[this._identifier].decodeFromBytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */ 
/*      */     
/* 1488 */     BuiltInEncodingAlgorithmFactory.table[this._identifier].convertToCharacters(array, buffer);
/*      */   }
/*      */   
/*      */   protected final Object processBuiltInEncodingAlgorithmAsObject() throws FastInfosetException, IOException {
/* 1492 */     return BuiltInEncodingAlgorithmFactory.table[this._identifier].decodeFromBytes(this._octetBuffer, this._octetBufferStart, this._octetBufferLength);
/*      */   }
/*      */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\sax\SAXDocumentParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */