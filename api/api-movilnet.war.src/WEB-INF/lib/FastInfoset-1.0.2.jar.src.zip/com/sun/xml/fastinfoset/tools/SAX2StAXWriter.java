/*     */ package com.sun.xml.fastinfoset.tools;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ import java.util.ArrayList;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAX2StAXWriter
/*     */   extends DefaultHandler
/*     */   implements LexicalHandler
/*     */ {
/*     */   XMLStreamWriter _writer;
/*  62 */   ArrayList _namespaces = new ArrayList();
/*     */   
/*     */   public SAX2StAXWriter(XMLStreamWriter writer) {
/*  65 */     this._writer = writer;
/*     */   }
/*     */   
/*     */   public XMLStreamWriter getWriter() {
/*  69 */     return this._writer;
/*     */   }
/*     */   
/*     */   public void startDocument() throws SAXException {
/*     */     try {
/*  74 */       this._writer.writeStartDocument();
/*     */     }
/*  76 */     catch (XMLStreamException e) {
/*  77 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endDocument() throws SAXException {
/*     */     try {
/*  83 */       this._writer.writeEndDocument();
/*  84 */       this._writer.flush();
/*     */     }
/*  86 */     catch (XMLStreamException e) {
/*  87 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/*     */     try {
/*  95 */       this._writer.writeCharacters(ch, start, length);
/*     */     }
/*  97 */     catch (XMLStreamException e) {
/*  98 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
/*     */     try {
/* 106 */       int k = qName.indexOf(':');
/* 107 */       String prefix = (k > 0) ? qName.substring(0, k) : "";
/* 108 */       this._writer.writeStartElement(prefix, localName, namespaceURI);
/*     */       
/* 110 */       int length = this._namespaces.size(); int i;
/* 111 */       for (i = 0; i < length; i++) {
/* 112 */         QualifiedName nsh = this._namespaces.get(i);
/* 113 */         this._writer.writeNamespace(nsh.prefix, nsh.namespaceName);
/*     */       } 
/* 115 */       this._namespaces.clear();
/*     */       
/* 117 */       length = atts.getLength();
/* 118 */       for (i = 0; i < length; i++) {
/* 119 */         this._writer.writeAttribute(atts.getURI(i), atts.getLocalName(i), atts.getValue(i));
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 124 */     catch (XMLStreamException e) {
/* 125 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
/*     */     try {
/* 133 */       this._writer.writeEndElement();
/*     */     }
/* 135 */     catch (XMLStreamException e) {
/* 136 */       e.printStackTrace();
/* 137 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/*     */     try {
/* 145 */       this._writer.setPrefix(prefix, uri);
/* 146 */       this._namespaces.add(new QualifiedName(prefix, uri));
/*     */     }
/* 148 */     catch (XMLStreamException e) {
/* 149 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 159 */     characters(ch, start, length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {
/*     */     try {
/* 166 */       this._writer.writeProcessingInstruction(target, data);
/*     */     }
/* 168 */     catch (XMLStreamException e) {
/* 169 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {}
/*     */ 
/*     */   
/*     */   public void skippedEntity(String name) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {
/*     */     try {
/* 183 */       this._writer.writeComment(new String(ch, start, length));
/*     */     }
/* 185 */     catch (XMLStreamException e) {
/* 186 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endCDATA() throws SAXException {}
/*     */   
/*     */   public void endDTD() throws SAXException {}
/*     */   
/*     */   public void endEntity(String name) throws SAXException {}
/*     */   
/*     */   public void startCDATA() throws SAXException {}
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {}
/*     */   
/*     */   public void startEntity(String name) throws SAXException {}
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\SAX2StAXWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */