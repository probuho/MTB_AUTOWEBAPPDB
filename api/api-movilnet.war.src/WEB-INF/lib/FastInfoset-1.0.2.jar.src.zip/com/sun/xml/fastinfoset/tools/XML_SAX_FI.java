/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.sax.SAXDocumentSerializer;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Reader;
/*    */ import javax.xml.parsers.SAXParser;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ import org.xml.sax.InputSource;
/*    */ import org.xml.sax.helpers.DefaultHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XML_SAX_FI
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream xml, OutputStream finf) throws Exception {
/* 56 */     SAXParser saxParser = getParser();
/* 57 */     SAXDocumentSerializer documentSerializer = getSerializer(finf);
/*    */     
/* 59 */     saxParser.setProperty("http://xml.org/sax/properties/lexical-handler", documentSerializer);
/* 60 */     saxParser.parse(xml, (DefaultHandler)documentSerializer);
/*    */   }
/*    */   
/*    */   public void convert(Reader reader, OutputStream finf) throws Exception {
/* 64 */     InputSource is = new InputSource(reader);
/*    */     
/* 66 */     SAXParser saxParser = getParser();
/* 67 */     SAXDocumentSerializer documentSerializer = getSerializer(finf);
/*    */     
/* 69 */     saxParser.setProperty("http://xml.org/sax/properties/lexical-handler", documentSerializer);
/* 70 */     saxParser.parse(is, (DefaultHandler)documentSerializer);
/*    */   }
/*    */   
/*    */   private SAXParser getParser() {
/* 74 */     SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
/* 75 */     saxParserFactory.setNamespaceAware(true);
/*    */     try {
/* 77 */       return saxParserFactory.newSAXParser();
/* 78 */     } catch (Exception e) {
/*    */       
/* 80 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private SAXDocumentSerializer getSerializer(OutputStream finf) {
/* 85 */     SAXDocumentSerializer documentSerializer = new SAXDocumentSerializer();
/* 86 */     documentSerializer.setOutputStream(finf);
/* 87 */     return documentSerializer;
/*    */   }
/*    */   public static void main(String[] args) throws Exception {
/* 90 */     XML_SAX_FI s = new XML_SAX_FI();
/* 91 */     s.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\XML_SAX_FI.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */