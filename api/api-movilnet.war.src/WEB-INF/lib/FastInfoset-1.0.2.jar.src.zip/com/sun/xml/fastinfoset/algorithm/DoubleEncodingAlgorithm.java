/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.CharBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoubleEncodingAlgorithm
/*     */   extends IEEE754FloatingPointEncodingAlgorithm
/*     */ {
/*     */   public final int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/*  58 */     if (octetLength % 8 != 0) {
/*  59 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.lengthIsNotMultipleOfDouble", new Object[] { new Integer(8) }));
/*     */     }
/*     */ 
/*     */     
/*  63 */     return octetLength / 8;
/*     */   }
/*     */   
/*     */   public int getOctetLengthFromPrimitiveLength(int primitiveLength) {
/*  67 */     return primitiveLength * 8;
/*     */   }
/*     */   
/*     */   public final Object decodeFromBytes(byte[] b, int start, int length) throws EncodingAlgorithmException {
/*  71 */     double[] data = new double[getPrimtiveLengthFromOctetLength(length)];
/*  72 */     decodeFromBytesToDoubleArray(data, 0, b, start, length);
/*     */     
/*  74 */     return data;
/*     */   }
/*     */   
/*     */   public final Object decodeFromInputStream(InputStream s) throws IOException {
/*  78 */     return decodeFromInputStreamToDoubleArray(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeToOutputStream(Object data, OutputStream s) throws IOException {
/*  83 */     if (!(data instanceof double[])) {
/*  84 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotDouble"));
/*     */     }
/*     */     
/*  87 */     double[] fdata = (double[])data;
/*     */     
/*  89 */     encodeToOutputStreamFromDoubleArray(fdata, s);
/*     */   }
/*     */   
/*     */   public final Object convertFromCharacters(char[] ch, int start, int length) {
/*  93 */     final CharBuffer cb = CharBuffer.wrap(ch, start, length);
/*  94 */     final List doubleList = new ArrayList();
/*     */     
/*  96 */     matchWhiteSpaceDelimnatedWords(cb, new BuiltInEncodingAlgorithm.WordListener()
/*     */         {
/*     */           public void word(int start, int end) {
/*  99 */             String fStringValue = cb.subSequence(start, end).toString();
/* 100 */             doubleList.add(Float.valueOf(fStringValue));
/*     */           }
/*     */           private final CharBuffer val$cb; private final List val$doubleList;
/*     */           private final DoubleEncodingAlgorithm this$0;
/*     */         });
/* 105 */     return generateArrayFromList(doubleList);
/*     */   }
/*     */   
/*     */   public final void convertToCharacters(Object data, StringBuffer s) {
/* 109 */     if (!(data instanceof double[])) {
/* 110 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotDouble"));
/*     */     }
/*     */     
/* 113 */     double[] fdata = (double[])data;
/*     */     
/* 115 */     convertToCharactersFromDoubleArray(fdata, s);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void decodeFromBytesToDoubleArray(double[] data, int fstart, byte[] b, int start, int length) {
/* 120 */     int size = length / 8;
/* 121 */     for (int i = 0; i < size; i++) {
/* 122 */       long bits = (b[start++] & 0xFF) << 56L | (b[start++] & 0xFF) << 48L | (b[start++] & 0xFF) << 40L | (b[start++] & 0xFF) << 32L | (b[start++] & 0xFF) << 24L | (b[start++] & 0xFF) << 16L | (b[start++] & 0xFF) << 8L | (b[start++] & 0xFF);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 131 */       data[fstart++] = Double.longBitsToDouble(bits);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final double[] decodeFromInputStreamToDoubleArray(InputStream s) throws IOException {
/* 136 */     List doubleList = new ArrayList();
/* 137 */     byte[] b = new byte[8];
/*     */     
/*     */     while (true) {
/* 140 */       int n = s.read(b);
/* 141 */       if (n != 8) {
/* 142 */         if (n == -1) {
/*     */           break;
/*     */         }
/*     */         
/* 146 */         while (n != 8) {
/* 147 */           int m = s.read(b, n, 8 - n);
/* 148 */           if (m == -1) {
/* 149 */             throw new EOFException();
/*     */           }
/* 151 */           n += m;
/*     */         } 
/*     */       } 
/*     */       
/* 155 */       int bits = (b[0] & 0xFF) << 56 | (b[1] & 0xFF) << 48 | (b[2] & 0xFF) << 40 | (b[3] & 0xFF) << 32 | (b[4] & 0xFF) << 24 | (b[5] & 0xFF) << 16 | (b[6] & 0xFF) << 8 | b[7] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       doubleList.add(new Double(Double.longBitsToDouble(bits)));
/*     */     } 
/*     */     
/* 168 */     return generateArrayFromList(doubleList);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void encodeToOutputStreamFromDoubleArray(double[] fdata, OutputStream s) throws IOException {
/* 173 */     for (int i = 0; i < fdata.length; i++) {
/* 174 */       long bits = Double.doubleToLongBits(fdata[i]);
/* 175 */       s.write((int)(bits >>> 56L & 0xFFL));
/* 176 */       s.write((int)(bits >>> 48L & 0xFFL));
/* 177 */       s.write((int)(bits >>> 40L & 0xFFL));
/* 178 */       s.write((int)(bits >>> 32L & 0xFFL));
/* 179 */       s.write((int)(bits >>> 24L & 0xFFL));
/* 180 */       s.write((int)(bits >>> 16L & 0xFFL));
/* 181 */       s.write((int)(bits >>> 8L & 0xFFL));
/* 182 */       s.write((int)(bits & 0xFFL));
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void encodeToBytes(Object array, int astart, int alength, byte[] b, int start) {
/* 187 */     encodeToBytesFromDoubleArray((double[])array, astart, alength, b, start);
/*     */   }
/*     */   
/*     */   public final void encodeToBytesFromDoubleArray(double[] fdata, int fstart, int flength, byte[] b, int start) {
/* 191 */     int fend = fstart + flength;
/* 192 */     for (int i = fstart; i < fend; i++) {
/* 193 */       long bits = Double.doubleToLongBits(fdata[i]);
/* 194 */       b[start++] = (byte)(int)(bits >>> 56L & 0xFFL);
/* 195 */       b[start++] = (byte)(int)(bits >>> 48L & 0xFFL);
/* 196 */       b[start++] = (byte)(int)(bits >>> 40L & 0xFFL);
/* 197 */       b[start++] = (byte)(int)(bits >>> 32L & 0xFFL);
/* 198 */       b[start++] = (byte)(int)(bits >>> 24L & 0xFFL);
/* 199 */       b[start++] = (byte)(int)(bits >>> 16L & 0xFFL);
/* 200 */       b[start++] = (byte)(int)(bits >>> 8L & 0xFFL);
/* 201 */       b[start++] = (byte)(int)(bits & 0xFFL);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void convertToCharactersFromDoubleArray(double[] fdata, StringBuffer s) {
/* 207 */     int end = fdata.length - 1;
/* 208 */     for (int i = 0; i <= end; i++) {
/* 209 */       s.append(Double.toString(fdata[i]));
/* 210 */       if (i != end) {
/* 211 */         s.append(' ');
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final double[] generateArrayFromList(List array) {
/* 218 */     double[] fdata = new double[array.size()];
/* 219 */     for (int i = 0; i < fdata.length; i++) {
/* 220 */       fdata[i] = ((Double)array.get(i)).doubleValue();
/*     */     }
/*     */     
/* 223 */     return fdata;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\DoubleEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */