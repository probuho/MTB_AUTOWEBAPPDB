/*    */ package com.sun.xml.fastinfoset.algorithm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltInEncodingAlgorithmState
/*    */ {
/*    */   public static final int INITIAL_LENGTH = 8;
/* 46 */   public boolean[] booleanArray = new boolean[8];
/*    */   
/* 48 */   public short[] shortArray = new short[8];
/*    */   
/* 50 */   public int[] intArray = new int[8];
/*    */   
/* 52 */   public long[] longArray = new long[8];
/*    */   
/* 54 */   public float[] floatArray = new float[8];
/*    */   
/* 56 */   public double[] doubleArray = new double[8];
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\BuiltInEncodingAlgorithmState.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */