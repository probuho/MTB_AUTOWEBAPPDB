/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64EncodingAlgorithm
/*     */   extends BuiltInEncodingAlgorithm
/*     */ {
/*  50 */   protected static final char[] encodeBase64 = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   protected static final int[] decodeBase64 = new int[] { 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object decodeFromBytes(byte[] b, int start, int length) throws EncodingAlgorithmException {
/* 129 */     byte[] data = new byte[length];
/* 130 */     System.arraycopy(b, start, data, 0, length);
/* 131 */     return data;
/*     */   }
/*     */   
/*     */   public final Object decodeFromInputStream(InputStream s) throws IOException {
/* 135 */     throw new UnsupportedOperationException(CommonResourceBundle.getInstance().getString("message.notImplemented"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeToOutputStream(Object data, OutputStream s) throws IOException {
/* 140 */     if (!(data instanceof byte[])) {
/* 141 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotByteArray"));
/*     */     }
/*     */     
/* 144 */     s.write((byte[])data);
/*     */   }
/*     */   
/*     */   public final Object convertFromCharacters(char[] ch, int start, int length) {
/* 148 */     if (length == 0) {
/* 149 */       return new byte[0];
/*     */     }
/*     */     
/* 152 */     StringBuffer encodedValue = removeWhitespace(ch, start, length);
/* 153 */     int encodedLength = encodedValue.length();
/* 154 */     if (encodedLength == 0) {
/* 155 */       return new byte[0];
/*     */     }
/*     */     
/* 158 */     int blockCount = encodedLength / 4;
/* 159 */     int partialBlockLength = 3;
/*     */     
/* 161 */     if (encodedValue.charAt(encodedLength - 1) == '=') {
/* 162 */       partialBlockLength--;
/* 163 */       if (encodedValue.charAt(encodedLength - 2) == '=') {
/* 164 */         partialBlockLength--;
/*     */       }
/*     */     } 
/*     */     
/* 168 */     int valueLength = (blockCount - 1) * 3 + partialBlockLength;
/* 169 */     byte[] value = new byte[valueLength];
/*     */     
/* 171 */     int idx = 0;
/* 172 */     int encodedIdx = 0;
/* 173 */     for (int i = 0; i < blockCount; i++) {
/* 174 */       int x1 = decodeBase64[encodedValue.charAt(encodedIdx++) - 43];
/* 175 */       int x2 = decodeBase64[encodedValue.charAt(encodedIdx++) - 43];
/* 176 */       int x3 = decodeBase64[encodedValue.charAt(encodedIdx++) - 43];
/* 177 */       int x4 = decodeBase64[encodedValue.charAt(encodedIdx++) - 43];
/*     */       
/* 179 */       value[idx++] = (byte)(x1 << 2 | x2 >> 4);
/* 180 */       if (idx < valueLength) {
/* 181 */         value[idx++] = (byte)((x2 & 0xF) << 4 | x3 >> 2);
/*     */       }
/* 183 */       if (idx < valueLength) {
/* 184 */         value[idx++] = (byte)((x3 & 0x3) << 6 | x4);
/*     */       }
/*     */     } 
/*     */     
/* 188 */     return value;
/*     */   }
/*     */   
/*     */   public final void convertToCharacters(Object data, StringBuffer s) {
/* 192 */     if (data == null) {
/*     */       return;
/*     */     }
/* 195 */     byte[] value = (byte[])data;
/* 196 */     if (value.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 200 */     int partialBlockLength = value.length % 3;
/* 201 */     int blockCount = (partialBlockLength != 0) ? (value.length / 3 + 1) : (value.length / 3);
/*     */ 
/*     */ 
/*     */     
/* 205 */     int encodedLength = blockCount * 4;
/* 206 */     s.ensureCapacity(encodedLength);
/*     */     
/* 208 */     int idx = 0;
/* 209 */     for (int i = 0; i < blockCount; i++) {
/* 210 */       int b1 = value[idx++] & 0xFF;
/* 211 */       int b2 = (idx < value.length) ? (value[idx++] & 0xFF) : 0;
/* 212 */       int b3 = (idx < value.length) ? (value[idx++] & 0xFF) : 0;
/*     */       
/* 214 */       s.append(encodeBase64[b1 >> 2]);
/*     */       
/* 216 */       s.append(encodeBase64[(b1 & 0x3) << 4 | b2 >> 4]);
/*     */       
/* 218 */       s.append(encodeBase64[(b2 & 0xF) << 2 | b3 >> 6]);
/*     */       
/* 220 */       s.append(encodeBase64[b3 & 0x3F]);
/*     */     } 
/*     */     
/* 223 */     switch (partialBlockLength) {
/*     */       case 1:
/* 225 */         s.setCharAt(encodedLength - 1, '=');
/* 226 */         s.setCharAt(encodedLength - 2, '=');
/*     */         break;
/*     */       case 2:
/* 229 */         s.setCharAt(encodedLength - 1, '=');
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/* 237 */     return octetLength;
/*     */   }
/*     */   
/*     */   public int getOctetLengthFromPrimitiveLength(int primitiveLength) {
/* 241 */     return primitiveLength;
/*     */   }
/*     */   
/*     */   public final void encodeToBytes(Object array, int astart, int alength, byte[] b, int start) {
/* 245 */     System.arraycopy(array, astart, b, start, alength);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\BASE64EncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */