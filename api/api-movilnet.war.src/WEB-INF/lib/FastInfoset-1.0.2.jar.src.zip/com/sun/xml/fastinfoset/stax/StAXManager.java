/*     */ package com.sun.xml.fastinfoset.stax;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXManager
/*     */ {
/*     */   protected static final String STAX_NOTATIONS = "javax.xml.stream.notations";
/*     */   protected static final String STAX_ENTITIES = "javax.xml.stream.entities";
/*  50 */   HashMap features = new HashMap();
/*     */   
/*     */   public static final int CONTEXT_READER = 1;
/*     */   
/*     */   public static final int CONTEXT_WRITER = 2;
/*     */ 
/*     */   
/*     */   public StAXManager() {}
/*     */ 
/*     */   
/*     */   public StAXManager(int context) {
/*  61 */     switch (context) {
/*     */       case 1:
/*  63 */         initConfigurableReaderProperties();
/*     */         break;
/*     */       
/*     */       case 2:
/*  67 */         initWriterProps();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StAXManager(StAXManager manager) {
/*  75 */     HashMap properties = manager.getProperties();
/*  76 */     this.features.putAll(properties);
/*     */   }
/*     */   
/*     */   private HashMap getProperties() {
/*  80 */     return this.features;
/*     */   }
/*     */ 
/*     */   
/*     */   private void initConfigurableReaderProperties() {
/*  85 */     this.features.put("javax.xml.stream.isNamespaceAware", Boolean.TRUE);
/*  86 */     this.features.put("javax.xml.stream.isValidating", Boolean.FALSE);
/*  87 */     this.features.put("javax.xml.stream.isReplacingEntityReferences", Boolean.TRUE);
/*  88 */     this.features.put("javax.xml.stream.isSupportingExternalEntities", Boolean.TRUE);
/*  89 */     this.features.put("javax.xml.stream.isCoalescing", Boolean.FALSE);
/*  90 */     this.features.put("javax.xml.stream.supportDTD", Boolean.FALSE);
/*  91 */     this.features.put("javax.xml.stream.reporter", (Object)null);
/*  92 */     this.features.put("javax.xml.stream.resolver", (Object)null);
/*  93 */     this.features.put("javax.xml.stream.allocator", (Object)null);
/*  94 */     this.features.put("javax.xml.stream.notations", (Object)null);
/*     */   }
/*     */   
/*     */   private void initWriterProps() {
/*  98 */     this.features.put("javax.xml.stream.isRepairingNamespaces", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsProperty(String property) {
/* 107 */     return this.features.containsKey(property);
/*     */   }
/*     */   
/*     */   public Object getProperty(String name) {
/* 111 */     checkProperty(name);
/* 112 */     return this.features.get(name);
/*     */   }
/*     */   
/*     */   public void setProperty(String name, Object value) {
/* 116 */     checkProperty(name);
/* 117 */     if (name.equals("javax.xml.stream.isValidating") && Boolean.TRUE.equals(value))
/*     */     {
/* 119 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.validationNotSupported") + CommonResourceBundle.getInstance().getString("support_validation"));
/*     */     }
/* 121 */     if (name.equals("javax.xml.stream.isSupportingExternalEntities") && Boolean.TRUE.equals(value))
/*     */     {
/* 123 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.externalEntities") + CommonResourceBundle.getInstance().getString("resolve_external_entities_"));
/*     */     }
/*     */     
/* 126 */     this.features.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkProperty(String name) {
/* 131 */     if (!this.features.containsKey(name))
/* 132 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.propertyNotSupported", new Object[] { name })); 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 136 */     return this.features.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\stax\StAXManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */