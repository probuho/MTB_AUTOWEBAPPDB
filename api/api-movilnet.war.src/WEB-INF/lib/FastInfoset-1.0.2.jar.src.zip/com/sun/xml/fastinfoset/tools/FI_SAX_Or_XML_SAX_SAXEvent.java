/*    */ package com.sun.xml.fastinfoset.tools;
/*    */ 
/*    */ import com.sun.xml.fastinfoset.Decoder;
/*    */ import com.sun.xml.fastinfoset.sax.SAXDocumentParser;
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.parsers.SAXParser;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FI_SAX_Or_XML_SAX_SAXEvent
/*    */   extends TransformInputOutput
/*    */ {
/*    */   public void parse(InputStream document, OutputStream events) throws Exception {
/* 57 */     if (!document.markSupported()) {
/* 58 */       document = new BufferedInputStream(document);
/*    */     }
/*    */     
/* 61 */     document.mark(4);
/* 62 */     boolean isFastInfosetDocument = Decoder.isFastInfosetDocument(document);
/* 63 */     document.reset();
/*    */     
/* 65 */     if (isFastInfosetDocument) {
/* 66 */       SAXDocumentParser parser = new SAXDocumentParser();
/* 67 */       SAXEventSerializer ses = new SAXEventSerializer(events);
/* 68 */       parser.setContentHandler(ses);
/* 69 */       parser.setProperty("http://xml.org/sax/properties/lexical-handler", ses);
/* 70 */       parser.parse(document);
/*    */     } else {
/* 72 */       SAXParserFactory parserFactory = SAXParserFactory.newInstance();
/* 73 */       parserFactory.setNamespaceAware(true);
/* 74 */       SAXParser parser = parserFactory.newSAXParser();
/* 75 */       SAXEventSerializer ses = new SAXEventSerializer(events);
/* 76 */       parser.setProperty("http://xml.org/sax/properties/lexical-handler", ses);
/* 77 */       parser.parse(document, ses);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 82 */     FI_SAX_Or_XML_SAX_SAXEvent p = new FI_SAX_Or_XML_SAX_SAXEvent();
/* 83 */     p.parse(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\FI_SAX_Or_XML_SAX_SAXEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */