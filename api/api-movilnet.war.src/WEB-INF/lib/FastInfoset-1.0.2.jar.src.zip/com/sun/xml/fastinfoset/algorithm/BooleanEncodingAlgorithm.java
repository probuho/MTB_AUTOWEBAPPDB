/*     */ package com.sun.xml.fastinfoset.algorithm;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.CharBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jvnet.fastinfoset.EncodingAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanEncodingAlgorithm
/*     */   extends BuiltInEncodingAlgorithm
/*     */ {
/*  66 */   private static final int[] BIT_TABLE = new int[] { 128, 64, 32, 16, 8, 4, 2, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrimtiveLengthFromOctetLength(int octetLength) throws EncodingAlgorithmException {
/*  78 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getOctetLengthFromPrimitiveLength(int primitiveLength) {
/*  82 */     if (primitiveLength < 5) {
/*  83 */       return 1;
/*     */     }
/*  85 */     int div = primitiveLength / 8;
/*  86 */     return (div == 0) ? 2 : (1 + div);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object decodeFromBytes(byte[] b, int start, int length) throws EncodingAlgorithmException {
/*  91 */     int blength = getPrimtiveLengthFromOctetLength(length, b[start]);
/*  92 */     boolean[] data = new boolean[blength];
/*     */     
/*  94 */     decodeFromBytesToBooleanArray(data, 0, blength, b, start, length);
/*  95 */     return data;
/*     */   }
/*     */   
/*     */   public final Object decodeFromInputStream(InputStream s) throws IOException {
/*  99 */     List booleanList = new ArrayList();
/*     */     
/* 101 */     int value = s.read();
/* 102 */     if (value == -1) {
/* 103 */       throw new EOFException();
/*     */     }
/* 105 */     int unusedBits = value >> 4 & 0xFF;
/*     */     
/* 107 */     int bitPosition = 4;
/* 108 */     int bitPositionEnd = 8;
/* 109 */     int valueNext = 0;
/*     */     do {
/* 111 */       valueNext = s.read();
/* 112 */       if (valueNext == -1) {
/* 113 */         bitPositionEnd -= unusedBits;
/*     */       }
/*     */       
/* 116 */       while (bitPosition < bitPositionEnd) {
/* 117 */         booleanList.add(new Boolean(((value & BIT_TABLE[bitPosition++]) > 0)));
/*     */       }
/*     */ 
/*     */       
/* 121 */       value = valueNext;
/* 122 */     } while (value != -1);
/*     */     
/* 124 */     return generateArrayFromList(booleanList);
/*     */   }
/*     */   
/*     */   public void encodeToOutputStream(Object data, OutputStream s) throws IOException {
/* 128 */     if (!(data instanceof boolean[])) {
/* 129 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotBoolean"));
/*     */     }
/*     */     
/* 132 */     boolean[] array = (boolean[])data;
/* 133 */     int alength = array.length;
/*     */     
/* 135 */     int mod = (alength + 4) % 8;
/* 136 */     int unusedBits = (mod == 0) ? 0 : (8 - mod);
/*     */     
/* 138 */     int bitPosition = 4;
/* 139 */     int value = unusedBits << 4;
/* 140 */     int astart = 0;
/* 141 */     while (astart < alength) {
/* 142 */       if (array[astart++]) {
/* 143 */         value |= BIT_TABLE[bitPosition];
/*     */       }
/*     */       
/* 146 */       if (++bitPosition == 8) {
/* 147 */         s.write(value);
/* 148 */         bitPosition = value = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 152 */     if (bitPosition != 8) {
/* 153 */       s.write(value);
/*     */     }
/*     */   }
/*     */   
/*     */   public final Object convertFromCharacters(char[] ch, int start, int length) {
/* 158 */     if (length == 0) {
/* 159 */       return new boolean[0];
/*     */     }
/*     */     
/* 162 */     final CharBuffer cb = CharBuffer.wrap(ch, start, length);
/* 163 */     final List booleanList = new ArrayList();
/*     */     
/* 165 */     matchWhiteSpaceDelimnatedWords(cb, new BuiltInEncodingAlgorithm.WordListener()
/*     */         {
/*     */           public void word(int start, int end) {
/* 168 */             if (cb.charAt(start) == 't') {
/* 169 */               booleanList.add(Boolean.TRUE);
/*     */             } else {
/* 171 */               booleanList.add(Boolean.FALSE);
/*     */             } 
/*     */           }
/*     */           private final CharBuffer val$cb; private final List val$booleanList;
/*     */           private final BooleanEncodingAlgorithm this$0;
/*     */         });
/* 177 */     return generateArrayFromList(booleanList);
/*     */   }
/*     */   
/*     */   public final void convertToCharacters(Object data, StringBuffer s) {
/* 181 */     if (data == null) {
/*     */       return;
/*     */     }
/*     */     
/* 185 */     boolean[] value = (boolean[])data;
/* 186 */     if (value.length == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 191 */     s.ensureCapacity(value.length * 5);
/*     */     
/* 193 */     int end = value.length - 1;
/* 194 */     for (int i = 0; i <= end; i++) {
/* 195 */       if (value[i]) {
/* 196 */         s.append("true");
/*     */       } else {
/* 198 */         s.append("false");
/*     */       } 
/* 200 */       if (i != end) {
/* 201 */         s.append(' ');
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getPrimtiveLengthFromOctetLength(int octetLength, int firstOctet) throws EncodingAlgorithmException {
/* 207 */     int unusedBits = firstOctet >> 4 & 0xFF;
/* 208 */     if (octetLength == 1) {
/* 209 */       if (unusedBits > 3) {
/* 210 */         throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.unusedBits4"));
/*     */       }
/* 212 */       return 4 - unusedBits;
/*     */     } 
/* 214 */     if (unusedBits > 7) {
/* 215 */       throw new EncodingAlgorithmException(CommonResourceBundle.getInstance().getString("message.unusedBits8"));
/*     */     }
/* 217 */     return octetLength * 8 - 4 - unusedBits;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void decodeFromBytesToBooleanArray(boolean[] bdata, int bstart, int blength, byte[] b, int start, int length) {
/* 222 */     int value = b[start++] & 0xFF;
/* 223 */     int bitPosition = 4;
/* 224 */     int bend = bstart + blength;
/* 225 */     while (bstart < bend) {
/* 226 */       if (bitPosition == 8) {
/* 227 */         value = b[start++] & 0xFF;
/* 228 */         bitPosition = 0;
/*     */       } 
/*     */       
/* 231 */       bdata[bstart++] = ((value & BIT_TABLE[bitPosition++]) > 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void encodeToBytes(Object array, int astart, int alength, byte[] b, int start) {
/* 236 */     if (!(array instanceof boolean[])) {
/* 237 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.dataNotBoolean"));
/*     */     }
/*     */     
/* 240 */     encodeToBytesFromBooleanArray((boolean[])array, astart, alength, b, start);
/*     */   }
/*     */   
/*     */   public void encodeToBytesFromBooleanArray(boolean[] array, int astart, int alength, byte[] b, int start) {
/* 244 */     int mod = (alength + 4) % 8;
/* 245 */     int unusedBits = (mod == 0) ? 0 : (8 - mod);
/*     */     
/* 247 */     int bitPosition = 4;
/* 248 */     int value = unusedBits << 4;
/* 249 */     int aend = astart + alength;
/* 250 */     while (astart < aend) {
/* 251 */       if (array[astart++]) {
/* 252 */         value |= BIT_TABLE[bitPosition];
/*     */       }
/*     */       
/* 255 */       if (++bitPosition == 8) {
/* 256 */         b[start++] = (byte)value;
/* 257 */         bitPosition = value = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 261 */     if (bitPosition > 0) {
/* 262 */       b[start] = (byte)value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean[] generateArrayFromList(List array) {
/* 275 */     boolean[] bdata = new boolean[array.size()];
/* 276 */     for (int i = 0; i < bdata.length; i++) {
/* 277 */       bdata[i] = ((Boolean)array.get(i)).booleanValue();
/*     */     }
/*     */     
/* 280 */     return bdata;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\algorithm\BooleanEncodingAlgorithm.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */