/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharArrayIntMap
/*     */   extends KeyIntMap
/*     */ {
/*     */   private CharArrayIntMap _readOnlyMap;
/*     */   private Entry[] _table;
/*     */   
/*     */   static class Entry
/*     */     extends KeyIntMap.BaseEntry
/*     */   {
/*     */     final char[] _ch;
/*     */     final int _start;
/*     */     final int _length;
/*     */     Entry _next;
/*     */     
/*     */     public Entry(char[] ch, int start, int length, int hash, int value, Entry next) {
/*  54 */       super(hash, value);
/*  55 */       this._ch = ch;
/*  56 */       this._start = start;
/*  57 */       this._length = length;
/*  58 */       this._next = next;
/*     */     }
/*     */     
/*     */     public final boolean equalsCharArray(char[] ch, int start, int length) {
/*  62 */       if (this._length == length) {
/*  63 */         int n = this._length;
/*  64 */         int i = this._start;
/*  65 */         int j = start;
/*  66 */         while (n-- != 0) {
/*  67 */           if (this._ch[i++] != ch[j++])
/*  68 */             return false; 
/*     */         } 
/*  70 */         return true;
/*     */       } 
/*     */       
/*  73 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharArrayIntMap(int initialCapacity, float loadFactor) {
/*  81 */     super(initialCapacity, loadFactor);
/*     */     
/*  83 */     this._table = new Entry[this._capacity];
/*     */   }
/*     */   
/*     */   public CharArrayIntMap(int initialCapacity) {
/*  87 */     this(initialCapacity, 0.75F);
/*     */   }
/*     */   
/*     */   public CharArrayIntMap() {
/*  91 */     this(16, 0.75F);
/*     */   }
/*     */   
/*     */   public final void clear() {
/*  95 */     for (int i = 0; i < this._table.length; i++) {
/*  96 */       this._table[i] = null;
/*     */     }
/*  98 */     this._size = 0;
/*     */   }
/*     */   
/*     */   public final void setReadOnlyMap(KeyIntMap readOnlyMap, boolean clear) {
/* 102 */     if (!(readOnlyMap instanceof CharArrayIntMap)) {
/* 103 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyMap }));
/*     */     }
/*     */ 
/*     */     
/* 107 */     setReadOnlyMap((CharArrayIntMap)readOnlyMap, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyMap(CharArrayIntMap readOnlyMap, boolean clear) {
/* 111 */     this._readOnlyMap = readOnlyMap;
/* 112 */     if (this._readOnlyMap != null) {
/* 113 */       this._readOnlyMapSize = this._readOnlyMap.size();
/*     */       
/* 115 */       if (clear) {
/* 116 */         clear();
/*     */       }
/*     */     } else {
/* 119 */       this._readOnlyMapSize = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int obtainIndex(char[] ch, int start, int length, boolean clone) {
/* 124 */     int hash = hashHash(CharArray.hashCode(ch, start, length));
/*     */     
/* 126 */     if (this._readOnlyMap != null) {
/* 127 */       int index = this._readOnlyMap.get(ch, start, length, hash);
/* 128 */       if (index != -1) {
/* 129 */         return index;
/*     */       }
/*     */     } 
/*     */     
/* 133 */     int tableIndex = indexFor(hash, this._table.length);
/* 134 */     for (Entry e = this._table[tableIndex]; e != null; e = e._next) {
/* 135 */       if (e._hash == hash && e.equalsCharArray(ch, start, length)) {
/* 136 */         return e._value;
/*     */       }
/*     */     } 
/*     */     
/* 140 */     if (clone) {
/* 141 */       char[] chClone = new char[length];
/* 142 */       System.arraycopy(ch, start, chClone, 0, length);
/*     */       
/* 144 */       ch = chClone;
/* 145 */       start = 0;
/*     */     } 
/*     */     
/* 148 */     addEntry(ch, start, length, hash, this._size + this._readOnlyMapSize, tableIndex);
/* 149 */     return -1;
/*     */   }
/*     */   
/*     */   private final int get(char[] ch, int start, int length, int hash) {
/* 153 */     if (this._readOnlyMap != null) {
/* 154 */       int i = this._readOnlyMap.get(ch, start, length, hash);
/* 155 */       if (i != -1) {
/* 156 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 160 */     int tableIndex = indexFor(hash, this._table.length);
/* 161 */     for (Entry e = this._table[tableIndex]; e != null; e = e._next) {
/* 162 */       if (e._hash == hash && e.equalsCharArray(ch, start, length)) {
/* 163 */         return e._value;
/*     */       }
/*     */     } 
/*     */     
/* 167 */     return -1;
/*     */   }
/*     */   
/*     */   private final void addEntry(char[] ch, int start, int length, int hash, int value, int bucketIndex) {
/* 171 */     Entry e = this._table[bucketIndex];
/* 172 */     this._table[bucketIndex] = new Entry(ch, start, length, hash, value, e);
/* 173 */     if (this._size++ >= this._threshold) {
/* 174 */       resize(2 * this._table.length);
/*     */     }
/*     */   }
/*     */   
/*     */   private final void resize(int newCapacity) {
/* 179 */     this._capacity = newCapacity;
/* 180 */     Entry[] oldTable = this._table;
/* 181 */     int oldCapacity = oldTable.length;
/* 182 */     if (oldCapacity == 1048576) {
/* 183 */       this._threshold = Integer.MAX_VALUE;
/*     */       
/*     */       return;
/*     */     } 
/* 187 */     Entry[] newTable = new Entry[this._capacity];
/* 188 */     transfer(newTable);
/* 189 */     this._table = newTable;
/* 190 */     this._threshold = (int)(this._capacity * this._loadFactor);
/*     */   }
/*     */   
/*     */   private final void transfer(Entry[] newTable) {
/* 194 */     Entry[] src = this._table;
/* 195 */     int newCapacity = newTable.length;
/* 196 */     for (int j = 0; j < src.length; j++) {
/* 197 */       Entry e = src[j];
/* 198 */       if (e != null) {
/* 199 */         src[j] = null;
/*     */         do {
/* 201 */           Entry next = e._next;
/* 202 */           int i = indexFor(e._hash, newCapacity);
/* 203 */           e._next = newTable[i];
/* 204 */           newTable[i] = e;
/* 205 */           e = next;
/* 206 */         } while (e != null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\CharArrayIntMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */