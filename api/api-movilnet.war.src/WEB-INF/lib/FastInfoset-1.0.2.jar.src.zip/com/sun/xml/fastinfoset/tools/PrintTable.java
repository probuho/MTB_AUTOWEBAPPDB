/*     */ package com.sun.xml.fastinfoset.tools;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ import com.sun.xml.fastinfoset.sax.VocabularyGenerator;
/*     */ import com.sun.xml.fastinfoset.util.CharArrayArray;
/*     */ import com.sun.xml.fastinfoset.util.ContiguousCharArrayArray;
/*     */ import com.sun.xml.fastinfoset.util.PrefixArray;
/*     */ import com.sun.xml.fastinfoset.util.QualifiedNameArray;
/*     */ import com.sun.xml.fastinfoset.util.StringArray;
/*     */ import com.sun.xml.fastinfoset.vocab.ParserVocabulary;
/*     */ import java.io.File;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrintTable
/*     */ {
/*     */   public static void printVocabulary(ParserVocabulary vocabulary) {
/*  64 */     printArray("Attribute Name Table", vocabulary.attributeName);
/*  65 */     printArray("Attribute Value Table", vocabulary.attributeValue);
/*  66 */     printArray("Character Content Chunk Table", vocabulary.characterContentChunk);
/*  67 */     printArray("Element Name Table", vocabulary.elementName);
/*  68 */     printArray("Local Name Table", vocabulary.localName);
/*  69 */     printArray("Namespace Name Table", vocabulary.namespaceName);
/*  70 */     printArray("Other NCName Table", vocabulary.otherNCName);
/*  71 */     printArray("Other String Table", vocabulary.otherString);
/*  72 */     printArray("Other URI Table", vocabulary.otherURI);
/*  73 */     printArray("Prefix Table", vocabulary.prefix);
/*     */   }
/*     */   
/*     */   public static void printArray(String title, StringArray a) {
/*  77 */     System.out.println(title);
/*     */     
/*  79 */     for (int i = 0; i < a.getSize(); i++) {
/*  80 */       System.out.println("" + (i + 1) + ": " + a.getArray()[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void printArray(String title, PrefixArray a) {
/*  85 */     System.out.println(title);
/*     */     
/*  87 */     for (int i = 0; i < a.getSize(); i++) {
/*  88 */       System.out.println("" + (i + 1) + ": " + a.getArray()[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void printArray(String title, CharArrayArray a) {
/*  93 */     System.out.println(title);
/*     */     
/*  95 */     for (int i = 0; i < a.getSize(); i++) {
/*  96 */       System.out.println("" + (i + 1) + ": " + a.getArray()[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void printArray(String title, ContiguousCharArrayArray a) {
/* 101 */     System.out.println(title);
/*     */     
/* 103 */     for (int i = 0; i < a.getSize(); i++) {
/* 104 */       System.out.println("" + (i + 1) + ": " + a.get(i).toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public static void printArray(String title, QualifiedNameArray a) {
/* 109 */     System.out.println(title);
/*     */     
/* 111 */     for (int i = 0; i < a.getSize(); i++) {
/* 112 */       QualifiedName name = a.getArray()[i];
/* 113 */       System.out.println("" + (name.index + 1) + ": " + "{" + name.namespaceName + "}" + name.prefix + ":" + name.localName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 124 */       SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
/* 125 */       saxParserFactory.setNamespaceAware(true);
/*     */       
/* 127 */       SAXParser saxParser = saxParserFactory.newSAXParser();
/*     */       
/* 129 */       ParserVocabulary referencedVocabulary = new ParserVocabulary();
/*     */       
/* 131 */       VocabularyGenerator vocabularyGenerator = new VocabularyGenerator(referencedVocabulary);
/* 132 */       File f = new File(args[0]);
/* 133 */       saxParser.parse(f, (DefaultHandler)vocabularyGenerator);
/*     */       
/* 135 */       printVocabulary(referencedVocabulary);
/* 136 */     } catch (Exception e) {
/* 137 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\tools\PrintTable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */