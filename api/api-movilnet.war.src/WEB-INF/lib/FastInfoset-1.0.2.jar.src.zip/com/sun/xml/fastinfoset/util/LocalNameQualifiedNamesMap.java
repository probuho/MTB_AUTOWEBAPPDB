/*     */ package com.sun.xml.fastinfoset.util;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.CommonResourceBundle;
/*     */ import com.sun.xml.fastinfoset.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalNameQualifiedNamesMap
/*     */   extends KeyIntMap
/*     */ {
/*     */   private LocalNameQualifiedNamesMap _readOnlyMap;
/*     */   private int _index;
/*     */   private Entry[] _table;
/*     */   
/*     */   public static class Entry
/*     */   {
/*     */     final String _key;
/*     */     final int _hash;
/*     */     public QualifiedName[] _value;
/*     */     public int _valueIndex;
/*     */     Entry _next;
/*     */     
/*     */     public Entry(String key, int hash, Entry next) {
/*  59 */       this._key = key;
/*  60 */       this._hash = hash;
/*  61 */       this._next = next;
/*  62 */       this._value = new QualifiedName[1];
/*     */     }
/*     */     
/*     */     public void addQualifiedName(QualifiedName name) {
/*  66 */       if (this._valueIndex < this._value.length) {
/*  67 */         this._value[this._valueIndex++] = name;
/*  68 */       } else if (this._valueIndex == this._value.length) {
/*  69 */         QualifiedName[] newValue = new QualifiedName[this._valueIndex * 3 / 2 + 1];
/*  70 */         System.arraycopy(this._value, 0, newValue, 0, this._valueIndex);
/*  71 */         this._value = newValue;
/*  72 */         this._value[this._valueIndex++] = name;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNameQualifiedNamesMap(int initialCapacity, float loadFactor) {
/*  80 */     super(initialCapacity, loadFactor);
/*     */     
/*  82 */     this._table = new Entry[this._capacity];
/*     */   }
/*     */   
/*     */   public LocalNameQualifiedNamesMap(int initialCapacity) {
/*  86 */     this(initialCapacity, 0.75F);
/*     */   }
/*     */   
/*     */   public LocalNameQualifiedNamesMap() {
/*  90 */     this(16, 0.75F);
/*     */   }
/*     */   
/*     */   public final void clear() {
/*  94 */     for (int i = 0; i < this._table.length; i++) {
/*  95 */       this._table[i] = null;
/*     */     }
/*  97 */     this._size = 0;
/*     */     
/*  99 */     if (this._readOnlyMap != null) {
/* 100 */       this._index = this._readOnlyMap.getIndex();
/*     */     } else {
/* 102 */       this._index = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void setReadOnlyMap(KeyIntMap readOnlyMap, boolean clear) {
/* 107 */     if (!(readOnlyMap instanceof LocalNameQualifiedNamesMap)) {
/* 108 */       throw new IllegalArgumentException(CommonResourceBundle.getInstance().getString("message.illegalClass", new Object[] { readOnlyMap }));
/*     */     }
/*     */ 
/*     */     
/* 112 */     setReadOnlyMap((LocalNameQualifiedNamesMap)readOnlyMap, clear);
/*     */   }
/*     */   
/*     */   public final void setReadOnlyMap(LocalNameQualifiedNamesMap readOnlyMap, boolean clear) {
/* 116 */     this._readOnlyMap = readOnlyMap;
/* 117 */     if (this._readOnlyMap != null) {
/* 118 */       this._readOnlyMapSize = this._readOnlyMap.size();
/* 119 */       this._index = this._readOnlyMap.getIndex();
/* 120 */       if (clear) {
/* 121 */         clear();
/*     */       }
/*     */     } else {
/* 124 */       this._readOnlyMapSize = 0;
/* 125 */       this._index = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int getNextIndex() {
/* 130 */     return this._index++;
/*     */   }
/*     */   
/*     */   public final int getIndex() {
/* 134 */     return this._index;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Entry obtainEntry(String key) {
/* 139 */     int hash = hashHash(key.hashCode());
/*     */     
/* 141 */     if (this._readOnlyMap != null) {
/* 142 */       Entry entry = this._readOnlyMap.getEntry(key, hash);
/* 143 */       if (entry != null) {
/* 144 */         return entry;
/*     */       }
/*     */     } 
/*     */     
/* 148 */     int tableIndex = indexFor(hash, this._table.length);
/* 149 */     for (Entry e = this._table[tableIndex]; e != null; e = e._next) {
/* 150 */       if (e._hash == hash && eq(key, e._key)) {
/* 151 */         return e;
/*     */       }
/*     */     } 
/*     */     
/* 155 */     return addEntry(key, hash, tableIndex);
/*     */   }
/*     */   
/*     */   private final Entry getEntry(String key, int hash) {
/* 159 */     if (this._readOnlyMap != null) {
/* 160 */       Entry entry = this._readOnlyMap.getEntry(key, hash);
/* 161 */       if (entry != null) {
/* 162 */         return entry;
/*     */       }
/*     */     } 
/*     */     
/* 166 */     int tableIndex = indexFor(hash, this._table.length);
/* 167 */     for (Entry e = this._table[tableIndex]; e != null; e = e._next) {
/* 168 */       if (e._hash == hash && eq(key, e._key)) {
/* 169 */         return e;
/*     */       }
/*     */     } 
/*     */     
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private final Entry addEntry(String key, int hash, int bucketIndex) {
/* 178 */     Entry e = this._table[bucketIndex];
/* 179 */     this._table[bucketIndex] = new Entry(key, hash, e);
/* 180 */     e = this._table[bucketIndex];
/* 181 */     if (this._size++ >= this._threshold) {
/* 182 */       resize(2 * this._table.length);
/*     */     }
/*     */     
/* 185 */     return e;
/*     */   }
/*     */   
/*     */   private final void resize(int newCapacity) {
/* 189 */     this._capacity = newCapacity;
/* 190 */     Entry[] oldTable = this._table;
/* 191 */     int oldCapacity = oldTable.length;
/* 192 */     if (oldCapacity == 1048576) {
/* 193 */       this._threshold = Integer.MAX_VALUE;
/*     */       
/*     */       return;
/*     */     } 
/* 197 */     Entry[] newTable = new Entry[this._capacity];
/* 198 */     transfer(newTable);
/* 199 */     this._table = newTable;
/* 200 */     this._threshold = (int)(this._capacity * this._loadFactor);
/*     */   }
/*     */   
/*     */   private final void transfer(Entry[] newTable) {
/* 204 */     Entry[] src = this._table;
/* 205 */     int newCapacity = newTable.length;
/* 206 */     for (int j = 0; j < src.length; j++) {
/* 207 */       Entry e = src[j];
/* 208 */       if (e != null) {
/* 209 */         src[j] = null;
/*     */         do {
/* 211 */           Entry next = e._next;
/* 212 */           int i = indexFor(e._hash, newCapacity);
/* 213 */           e._next = newTable[i];
/* 214 */           newTable[i] = e;
/* 215 */           e = next;
/* 216 */         } while (e != null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final boolean eq(String x, String y) {
/* 222 */     return (x == y || x.equals(y));
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfose\\util\LocalNameQualifiedNamesMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */