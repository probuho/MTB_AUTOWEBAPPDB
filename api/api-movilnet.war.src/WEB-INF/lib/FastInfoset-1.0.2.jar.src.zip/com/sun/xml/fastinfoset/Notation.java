/*    */ package com.sun.xml.fastinfoset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Notation
/*    */ {
/*    */   public final String name;
/*    */   public final String systemIdentifier;
/*    */   public final String publicIdentifier;
/*    */   
/*    */   public Notation(String _name, String _systemIdentifier, String _publicIdentifier) {
/* 48 */     this.name = _name;
/* 49 */     this.systemIdentifier = _systemIdentifier;
/* 50 */     this.publicIdentifier = _publicIdentifier;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\FastInfoset-1.0.2.jar!\com\sun\xml\fastinfoset\Notation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */