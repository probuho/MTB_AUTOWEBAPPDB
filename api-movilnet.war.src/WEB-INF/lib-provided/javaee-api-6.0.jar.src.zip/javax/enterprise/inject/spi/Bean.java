package javax.enterprise.inject.spi;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Set;
import javax.enterprise.context.spi.Contextual;

public interface Bean<T> extends Contextual<T> {
  Set<Type> getTypes();
  
  Set<Annotation> getQualifiers();
  
  Class<? extends Annotation> getScope();
  
  String getName();
  
  Set<Class<? extends Annotation>> getStereotypes();
  
  Class<?> getBeanClass();
  
  boolean isAlternative();
  
  boolean isNullable();
  
  Set<InjectionPoint> getInjectionPoints();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\Bean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */