package javax.enterprise.inject.spi;

import java.util.Set;
import javax.enterprise.context.spi.CreationalContext;

public interface Producer<T> {
  T produce(CreationalContext<T> paramCreationalContext);
  
  void dispose(T paramT);
  
  Set<InjectionPoint> getInjectionPoints();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\Producer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */