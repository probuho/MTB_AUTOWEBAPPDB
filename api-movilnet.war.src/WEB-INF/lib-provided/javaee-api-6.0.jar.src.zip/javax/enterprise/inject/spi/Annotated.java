package javax.enterprise.inject.spi;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Set;

public interface Annotated {
  Type getBaseType();
  
  Set<Type> getTypeClosure();
  
  <T extends Annotation> T getAnnotation(Class<T> paramClass);
  
  Set<Annotation> getAnnotations();
  
  boolean isAnnotationPresent(Class<? extends Annotation> paramClass);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\Annotated.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */