package javax.enterprise.inject.spi;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Set;
import javax.enterprise.event.Reception;
import javax.enterprise.event.TransactionPhase;

public interface ObserverMethod<T> {
  Class<?> getBeanClass();
  
  Type getObservedType();
  
  Set<Annotation> getObservedQualifiers();
  
  Reception getReception();
  
  TransactionPhase getTransactionPhase();
  
  void notify(T paramT);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\ObserverMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */