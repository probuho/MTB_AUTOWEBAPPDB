package javax.enterprise.inject.spi;

import java.lang.annotation.Annotation;

public interface BeforeBeanDiscovery {
  void addQualifier(Class<? extends Annotation> paramClass);
  
  void addScope(Class<? extends Annotation> paramClass, boolean paramBoolean1, boolean paramBoolean2);
  
  void addStereotype(Class<? extends Annotation> paramClass, Annotation... paramVarArgs);
  
  void addInterceptorBinding(Class<? extends Annotation> paramClass);
  
  void addAnnotatedType(AnnotatedType<?> paramAnnotatedType);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\BeforeBeanDiscovery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */