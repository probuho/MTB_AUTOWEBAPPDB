package javax.enterprise.inject.spi;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;
import javax.el.ELResolver;
import javax.el.ExpressionFactory;
import javax.enterprise.context.spi.Context;
import javax.enterprise.context.spi.Contextual;
import javax.enterprise.context.spi.CreationalContext;

public interface BeanManager {
  Object getReference(Bean<?> paramBean, Type paramType, CreationalContext<?> paramCreationalContext);
  
  Object getInjectableReference(InjectionPoint paramInjectionPoint, CreationalContext<?> paramCreationalContext);
  
  <T> CreationalContext<T> createCreationalContext(Contextual<T> paramContextual);
  
  Set<Bean<?>> getBeans(Type paramType, Annotation... paramVarArgs);
  
  Set<Bean<?>> getBeans(String paramString);
  
  Bean<?> getPassivationCapableBean(String paramString);
  
  <X> Bean<? extends X> resolve(Set<Bean<? extends X>> paramSet);
  
  void validate(InjectionPoint paramInjectionPoint);
  
  void fireEvent(Object paramObject, Annotation... paramVarArgs);
  
  <T> Set<ObserverMethod<? super T>> resolveObserverMethods(T paramT, Annotation... paramVarArgs);
  
  List<Decorator<?>> resolveDecorators(Set<Type> paramSet, Annotation... paramVarArgs);
  
  List<Interceptor<?>> resolveInterceptors(InterceptionType paramInterceptionType, Annotation... paramVarArgs);
  
  boolean isScope(Class<? extends Annotation> paramClass);
  
  boolean isNormalScope(Class<? extends Annotation> paramClass);
  
  boolean isPassivatingScope(Class<? extends Annotation> paramClass);
  
  boolean isQualifier(Class<? extends Annotation> paramClass);
  
  boolean isInterceptorBinding(Class<? extends Annotation> paramClass);
  
  boolean isStereotype(Class<? extends Annotation> paramClass);
  
  Set<Annotation> getInterceptorBindingDefinition(Class<? extends Annotation> paramClass);
  
  Set<Annotation> getStereotypeDefinition(Class<? extends Annotation> paramClass);
  
  Context getContext(Class<? extends Annotation> paramClass);
  
  ELResolver getELResolver();
  
  ExpressionFactory wrapExpressionFactory(ExpressionFactory paramExpressionFactory);
  
  <T> AnnotatedType<T> createAnnotatedType(Class<T> paramClass);
  
  <T> InjectionTarget<T> createInjectionTarget(AnnotatedType<T> paramAnnotatedType);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\BeanManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */