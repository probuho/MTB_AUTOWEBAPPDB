package javax.enterprise.inject.spi;

import java.util.Set;

public interface AnnotatedType<X> extends Annotated {
  Class<X> getJavaClass();
  
  Set<AnnotatedConstructor<X>> getConstructors();
  
  Set<AnnotatedMethod<? super X>> getMethods();
  
  Set<AnnotatedField<? super X>> getFields();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\AnnotatedType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */