package javax.enterprise.inject.spi;

import java.lang.annotation.Annotation;
import java.util.Set;
import javax.interceptor.InvocationContext;

public interface Interceptor<T> extends Bean<T> {
  Set<Annotation> getInterceptorBindings();
  
  boolean intercepts(InterceptionType paramInterceptionType);
  
  Object intercept(InterceptionType paramInterceptionType, T paramT, InvocationContext paramInvocationContext);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\Interceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */