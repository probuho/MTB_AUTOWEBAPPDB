package javax.enterprise.inject.spi;

public interface ProcessProducerMethod<T, X> extends ProcessBean<X> {
  AnnotatedMethod<T> getAnnotatedProducerMethod();
  
  AnnotatedParameter<T> getAnnotatedDisposedParameter();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\ProcessProducerMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */