package javax.enterprise.inject.spi;

import javax.enterprise.context.spi.CreationalContext;

public interface InjectionTarget<T> extends Producer<T> {
  void inject(T paramT, CreationalContext<T> paramCreationalContext);
  
  void postConstruct(T paramT);
  
  void preDestroy(T paramT);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\InjectionTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */