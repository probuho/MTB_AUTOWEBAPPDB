package javax.enterprise.inject.spi;

public interface Extension {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\spi\Extension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */