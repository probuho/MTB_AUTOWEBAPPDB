package javax.enterprise.inject;

import java.lang.annotation.Annotation;
import javax.enterprise.util.TypeLiteral;
import javax.inject.Provider;

public interface Instance<T> extends Iterable<T>, Provider<T> {
  Instance<T> select(Annotation... paramVarArgs);
  
  <U extends T> Instance<U> select(Class<U> paramClass, Annotation... paramVarArgs);
  
  <U extends T> Instance<U> select(TypeLiteral<U> paramTypeLiteral, Annotation... paramVarArgs);
  
  boolean isUnsatisfied();
  
  boolean isAmbiguous();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\inject\Instance.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */