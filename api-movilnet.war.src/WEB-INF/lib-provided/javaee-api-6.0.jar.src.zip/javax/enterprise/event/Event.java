package javax.enterprise.event;

import java.lang.annotation.Annotation;
import javax.enterprise.util.TypeLiteral;

public interface Event<T> {
  void fire(T paramT);
  
  Event<T> select(Annotation... paramVarArgs);
  
  <U extends T> Event<U> select(Class<U> paramClass, Annotation... paramVarArgs);
  
  <U extends T> Event<U> select(TypeLiteral<U> paramTypeLiteral, Annotation... paramVarArgs);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\event\Event.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */