package javax.enterprise.deploy.model;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Enumeration;
import javax.enterprise.deploy.model.exceptions.DDBeanCreateException;
import javax.enterprise.deploy.shared.ModuleType;

public interface DeployableObject {
  ModuleType getType();
  
  DDBeanRoot getDDBeanRoot();
  
  DDBean[] getChildBean(String paramString);
  
  String[] getText(String paramString);
  
  Class getClassFromScope(String paramString);
  
  String getModuleDTDVersion();
  
  DDBeanRoot getDDBeanRoot(String paramString) throws FileNotFoundException, DDBeanCreateException;
  
  Enumeration entries();
  
  InputStream getEntry(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\model\DeployableObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */