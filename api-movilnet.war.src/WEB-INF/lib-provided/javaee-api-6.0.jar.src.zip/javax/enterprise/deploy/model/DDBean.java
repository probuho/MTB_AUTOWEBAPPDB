package javax.enterprise.deploy.model;

public interface DDBean {
  String getXpath();
  
  String getText();
  
  String getId();
  
  DDBeanRoot getRoot();
  
  DDBean[] getChildBean(String paramString);
  
  String[] getText(String paramString);
  
  void addXpathListener(String paramString, XpathListener paramXpathListener);
  
  void removeXpathListener(String paramString, XpathListener paramXpathListener);
  
  String[] getAttributeNames();
  
  String getAttributeValue(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\model\DDBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */