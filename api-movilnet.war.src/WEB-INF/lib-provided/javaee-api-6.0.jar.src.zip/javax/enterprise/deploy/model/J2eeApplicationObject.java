package javax.enterprise.deploy.model;

import javax.enterprise.deploy.shared.ModuleType;

public interface J2eeApplicationObject extends DeployableObject {
  DeployableObject getDeployableObject(String paramString);
  
  DeployableObject[] getDeployableObjects(ModuleType paramModuleType);
  
  DeployableObject[] getDeployableObjects();
  
  String[] getModuleUris(ModuleType paramModuleType);
  
  String[] getModuleUris();
  
  DDBean[] getChildBean(ModuleType paramModuleType, String paramString);
  
  String[] getText(ModuleType paramModuleType, String paramString);
  
  void addXpathListener(ModuleType paramModuleType, String paramString, XpathListener paramXpathListener);
  
  void removeXpathListener(ModuleType paramModuleType, String paramString, XpathListener paramXpathListener);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\model\J2eeApplicationObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */