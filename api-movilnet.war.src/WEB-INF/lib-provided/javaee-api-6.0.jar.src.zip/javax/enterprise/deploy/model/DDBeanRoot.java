package javax.enterprise.deploy.model;

import javax.enterprise.deploy.shared.ModuleType;

public interface DDBeanRoot extends DDBean {
  ModuleType getType();
  
  DeployableObject getDeployableObject();
  
  String getModuleDTDVersion();
  
  String getDDBeanRootVersion();
  
  String getXpath();
  
  String getFilename();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\model\DDBeanRoot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */