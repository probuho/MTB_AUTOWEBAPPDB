package javax.enterprise.deploy.model;

public interface XpathListener {
  void fireXpathEvent(XpathEvent paramXpathEvent);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\model\XpathListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */