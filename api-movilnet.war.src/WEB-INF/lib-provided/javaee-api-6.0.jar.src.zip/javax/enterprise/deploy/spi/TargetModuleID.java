package javax.enterprise.deploy.spi;

public interface TargetModuleID {
  Target getTarget();
  
  String getModuleID();
  
  String getWebURL();
  
  String toString();
  
  TargetModuleID getParentTargetModuleID();
  
  TargetModuleID[] getChildTargetModuleID();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\spi\TargetModuleID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */