package javax.enterprise.deploy.spi;

import java.io.InputStream;
import java.io.OutputStream;
import javax.enterprise.deploy.model.DDBeanRoot;
import javax.enterprise.deploy.model.DeployableObject;
import javax.enterprise.deploy.spi.exceptions.BeanNotFoundException;
import javax.enterprise.deploy.spi.exceptions.ConfigurationException;

public interface DeploymentConfiguration {
  DeployableObject getDeployableObject();
  
  DConfigBeanRoot getDConfigBeanRoot(DDBeanRoot paramDDBeanRoot) throws ConfigurationException;
  
  void removeDConfigBean(DConfigBeanRoot paramDConfigBeanRoot) throws BeanNotFoundException;
  
  DConfigBeanRoot restoreDConfigBean(InputStream paramInputStream, DDBeanRoot paramDDBeanRoot) throws ConfigurationException;
  
  void saveDConfigBean(OutputStream paramOutputStream, DConfigBeanRoot paramDConfigBeanRoot) throws ConfigurationException;
  
  void restore(InputStream paramInputStream) throws ConfigurationException;
  
  void save(OutputStream paramOutputStream) throws ConfigurationException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\spi\DeploymentConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */