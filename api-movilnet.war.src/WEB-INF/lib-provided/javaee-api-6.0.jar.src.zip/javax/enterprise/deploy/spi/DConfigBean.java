package javax.enterprise.deploy.spi;

import java.beans.PropertyChangeListener;
import javax.enterprise.deploy.model.DDBean;
import javax.enterprise.deploy.model.XpathEvent;
import javax.enterprise.deploy.spi.exceptions.BeanNotFoundException;
import javax.enterprise.deploy.spi.exceptions.ConfigurationException;

public interface DConfigBean {
  DDBean getDDBean();
  
  String[] getXpaths();
  
  DConfigBean getDConfigBean(DDBean paramDDBean) throws ConfigurationException;
  
  void removeDConfigBean(DConfigBean paramDConfigBean) throws BeanNotFoundException;
  
  void notifyDDChange(XpathEvent paramXpathEvent);
  
  void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\spi\DConfigBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */