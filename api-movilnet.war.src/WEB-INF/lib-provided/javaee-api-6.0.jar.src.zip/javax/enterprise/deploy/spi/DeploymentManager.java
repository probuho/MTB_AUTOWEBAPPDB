package javax.enterprise.deploy.spi;

import java.io.File;
import java.io.InputStream;
import java.util.Locale;
import javax.enterprise.deploy.model.DeployableObject;
import javax.enterprise.deploy.shared.DConfigBeanVersionType;
import javax.enterprise.deploy.shared.ModuleType;
import javax.enterprise.deploy.spi.exceptions.DConfigBeanVersionUnsupportedException;
import javax.enterprise.deploy.spi.exceptions.InvalidModuleException;
import javax.enterprise.deploy.spi.exceptions.TargetException;
import javax.enterprise.deploy.spi.status.ProgressObject;

public interface DeploymentManager {
  Target[] getTargets() throws IllegalStateException;
  
  TargetModuleID[] getRunningModules(ModuleType paramModuleType, Target[] paramArrayOfTarget) throws TargetException, IllegalStateException;
  
  TargetModuleID[] getNonRunningModules(ModuleType paramModuleType, Target[] paramArrayOfTarget) throws TargetException, IllegalStateException;
  
  TargetModuleID[] getAvailableModules(ModuleType paramModuleType, Target[] paramArrayOfTarget) throws TargetException, IllegalStateException;
  
  DeploymentConfiguration createConfiguration(DeployableObject paramDeployableObject) throws InvalidModuleException;
  
  ProgressObject distribute(Target[] paramArrayOfTarget, File paramFile1, File paramFile2) throws IllegalStateException;
  
  ProgressObject distribute(Target[] paramArrayOfTarget, InputStream paramInputStream1, InputStream paramInputStream2) throws IllegalStateException;
  
  ProgressObject distribute(Target[] paramArrayOfTarget, ModuleType paramModuleType, InputStream paramInputStream1, InputStream paramInputStream2) throws IllegalStateException;
  
  ProgressObject start(TargetModuleID[] paramArrayOfTargetModuleID) throws IllegalStateException;
  
  ProgressObject stop(TargetModuleID[] paramArrayOfTargetModuleID) throws IllegalStateException;
  
  ProgressObject undeploy(TargetModuleID[] paramArrayOfTargetModuleID) throws IllegalStateException;
  
  boolean isRedeploySupported();
  
  ProgressObject redeploy(TargetModuleID[] paramArrayOfTargetModuleID, File paramFile1, File paramFile2) throws UnsupportedOperationException, IllegalStateException;
  
  ProgressObject redeploy(TargetModuleID[] paramArrayOfTargetModuleID, InputStream paramInputStream1, InputStream paramInputStream2) throws UnsupportedOperationException, IllegalStateException;
  
  void release();
  
  Locale getDefaultLocale();
  
  Locale getCurrentLocale();
  
  void setLocale(Locale paramLocale) throws UnsupportedOperationException;
  
  Locale[] getSupportedLocales();
  
  boolean isLocaleSupported(Locale paramLocale);
  
  DConfigBeanVersionType getDConfigBeanVersion();
  
  boolean isDConfigBeanVersionSupported(DConfigBeanVersionType paramDConfigBeanVersionType);
  
  void setDConfigBeanVersion(DConfigBeanVersionType paramDConfigBeanVersionType) throws DConfigBeanVersionUnsupportedException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\deploy\spi\DeploymentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */