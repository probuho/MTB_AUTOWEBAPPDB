package javax.enterprise.context;

public interface Conversation {
  void begin();
  
  void begin(String paramString);
  
  void end();
  
  String getId();
  
  long getTimeout();
  
  void setTimeout(long paramLong);
  
  boolean isTransient();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\context\Conversation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */