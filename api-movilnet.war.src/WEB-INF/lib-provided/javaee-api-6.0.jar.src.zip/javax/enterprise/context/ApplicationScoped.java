package javax.enterprise.context;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@NormalScope
@Inherited
public @interface ApplicationScoped {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\context\ApplicationScoped.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */