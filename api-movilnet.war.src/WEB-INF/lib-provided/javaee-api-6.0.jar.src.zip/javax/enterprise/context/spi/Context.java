package javax.enterprise.context.spi;

import java.lang.annotation.Annotation;

public interface Context {
  Class<? extends Annotation> getScope();
  
  <T> T get(Contextual<T> paramContextual, CreationalContext<T> paramCreationalContext);
  
  <T> T get(Contextual<T> paramContextual);
  
  boolean isActive();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\enterprise\context\spi\Context.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */