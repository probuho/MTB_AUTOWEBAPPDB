package javax.faces.model;

import java.util.EventListener;

public interface DataModelListener extends EventListener {
  void rowSelected(DataModelEvent paramDataModelEvent);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\model\DataModelListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */