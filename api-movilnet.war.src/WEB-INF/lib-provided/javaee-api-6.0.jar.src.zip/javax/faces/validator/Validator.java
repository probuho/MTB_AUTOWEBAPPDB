package javax.faces.validator;

import java.util.EventListener;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public interface Validator extends EventListener {
  public static final String NOT_IN_RANGE_MESSAGE_ID = "javax.faces.validator.NOT_IN_RANGE";
  
  void validate(FacesContext paramFacesContext, UIComponent paramUIComponent, Object paramObject) throws ValidatorException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\validator\Validator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */