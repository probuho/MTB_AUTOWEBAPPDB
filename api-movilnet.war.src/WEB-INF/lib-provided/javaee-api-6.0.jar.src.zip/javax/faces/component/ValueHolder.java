package javax.faces.component;

import javax.faces.convert.Converter;

public interface ValueHolder {
  Object getLocalValue();
  
  Object getValue();
  
  void setValue(Object paramObject);
  
  Converter getConverter();
  
  void setConverter(Converter paramConverter);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\ValueHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */