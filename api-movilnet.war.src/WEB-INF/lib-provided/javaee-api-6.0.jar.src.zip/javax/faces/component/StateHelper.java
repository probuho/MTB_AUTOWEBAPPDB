package javax.faces.component;

import java.io.Serializable;

public interface StateHelper extends StateHolder {
  Object put(Serializable paramSerializable, Object paramObject);
  
  Object remove(Serializable paramSerializable);
  
  Object put(Serializable paramSerializable, String paramString, Object paramObject);
  
  Object get(Serializable paramSerializable);
  
  Object eval(Serializable paramSerializable);
  
  Object eval(Serializable paramSerializable, Object paramObject);
  
  void add(Serializable paramSerializable, Object paramObject);
  
  Object remove(Serializable paramSerializable, Object paramObject);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\StateHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */