package javax.faces.component;

import javax.faces.el.MethodBinding;
import javax.faces.event.ActionListener;

public interface ActionSource {
  MethodBinding getAction();
  
  void setAction(MethodBinding paramMethodBinding);
  
  MethodBinding getActionListener();
  
  void setActionListener(MethodBinding paramMethodBinding);
  
  boolean isImmediate();
  
  void setImmediate(boolean paramBoolean);
  
  void addActionListener(ActionListener paramActionListener);
  
  ActionListener[] getActionListeners();
  
  void removeActionListener(ActionListener paramActionListener);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\ActionSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */