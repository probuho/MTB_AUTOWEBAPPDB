package javax.faces.component;

import javax.faces.context.FacesContext;

public interface StateHolder {
  Object saveState(FacesContext paramFacesContext);
  
  void restoreState(FacesContext paramFacesContext, Object paramObject);
  
  boolean isTransient();
  
  void setTransient(boolean paramBoolean);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\StateHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */