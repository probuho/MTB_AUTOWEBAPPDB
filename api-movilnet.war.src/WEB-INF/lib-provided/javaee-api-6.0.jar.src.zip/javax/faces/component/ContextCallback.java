package javax.faces.component;

import javax.faces.context.FacesContext;

public interface ContextCallback {
  void invokeContextCallback(FacesContext paramFacesContext, UIComponent paramUIComponent);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\ContextCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */