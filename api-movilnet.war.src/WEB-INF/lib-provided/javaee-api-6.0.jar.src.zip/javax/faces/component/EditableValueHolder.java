package javax.faces.component;

import javax.faces.el.MethodBinding;
import javax.faces.event.ValueChangeListener;
import javax.faces.validator.Validator;

public interface EditableValueHolder extends ValueHolder {
  Object getSubmittedValue();
  
  void resetValue();
  
  void setSubmittedValue(Object paramObject);
  
  boolean isLocalValueSet();
  
  void setLocalValueSet(boolean paramBoolean);
  
  boolean isValid();
  
  void setValid(boolean paramBoolean);
  
  boolean isRequired();
  
  void setRequired(boolean paramBoolean);
  
  boolean isImmediate();
  
  void setImmediate(boolean paramBoolean);
  
  MethodBinding getValidator();
  
  void setValidator(MethodBinding paramMethodBinding);
  
  MethodBinding getValueChangeListener();
  
  void setValueChangeListener(MethodBinding paramMethodBinding);
  
  void addValidator(Validator paramValidator);
  
  Validator[] getValidators();
  
  void removeValidator(Validator paramValidator);
  
  void addValueChangeListener(ValueChangeListener paramValueChangeListener);
  
  ValueChangeListener[] getValueChangeListeners();
  
  void removeValueChangeListener(ValueChangeListener paramValueChangeListener);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\EditableValueHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */