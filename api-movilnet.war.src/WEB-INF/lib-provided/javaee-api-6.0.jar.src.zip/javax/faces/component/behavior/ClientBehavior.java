package javax.faces.component.behavior;

import java.util.Set;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public interface ClientBehavior extends Behavior {
  String getScript(ClientBehaviorContext paramClientBehaviorContext);
  
  void decode(FacesContext paramFacesContext, UIComponent paramUIComponent);
  
  Set<ClientBehaviorHint> getHints();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\behavior\ClientBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */