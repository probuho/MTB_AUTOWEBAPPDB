package javax.faces.component.behavior;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface ClientBehaviorHolder {
  void addClientBehavior(String paramString, ClientBehavior paramClientBehavior);
  
  Collection<String> getEventNames();
  
  Map<String, List<ClientBehavior>> getClientBehaviors();
  
  String getDefaultEventName();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\component\behavior\ClientBehaviorHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */