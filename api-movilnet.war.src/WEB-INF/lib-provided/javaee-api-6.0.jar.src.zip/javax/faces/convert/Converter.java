package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

public interface Converter {
  Object getAsObject(FacesContext paramFacesContext, UIComponent paramUIComponent, String paramString);
  
  String getAsString(FacesContext paramFacesContext, UIComponent paramUIComponent, Object paramObject);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\convert\Converter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */