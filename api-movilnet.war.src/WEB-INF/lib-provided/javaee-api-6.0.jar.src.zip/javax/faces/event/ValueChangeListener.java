package javax.faces.event;

public interface ValueChangeListener extends FacesListener {
  void processValueChange(ValueChangeEvent paramValueChangeEvent) throws AbortProcessingException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\event\ValueChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */