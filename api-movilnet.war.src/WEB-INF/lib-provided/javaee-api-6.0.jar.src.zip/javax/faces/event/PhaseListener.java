package javax.faces.event;

import java.io.Serializable;
import java.util.EventListener;

public interface PhaseListener extends EventListener, Serializable {
  void afterPhase(PhaseEvent paramPhaseEvent);
  
  void beforePhase(PhaseEvent paramPhaseEvent);
  
  PhaseId getPhaseId();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\event\PhaseListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */