package javax.faces.event;

import java.util.List;

public interface SystemEventListenerHolder {
  List<SystemEventListener> getListenersForEventClass(Class<? extends SystemEvent> paramClass);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\faces\event\SystemEventListenerHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */