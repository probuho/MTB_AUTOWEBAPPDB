package javax.ejb;

import java.rmi.RemoteException;

public interface SessionBean extends EnterpriseBean {
  void setSessionContext(SessionContext paramSessionContext) throws EJBException, RemoteException;
  
  void ejbRemove() throws EJBException, RemoteException;
  
  void ejbActivate() throws EJBException, RemoteException;
  
  void ejbPassivate() throws EJBException, RemoteException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\SessionBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */