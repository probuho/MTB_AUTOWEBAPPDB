package javax.ejb;

public interface EntityContext extends EJBContext {
  EJBLocalObject getEJBLocalObject() throws IllegalStateException;
  
  EJBObject getEJBObject() throws IllegalStateException;
  
  Object getPrimaryKey() throws IllegalStateException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\EntityContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */