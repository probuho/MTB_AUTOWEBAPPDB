package javax.ejb;

import java.security.Identity;
import java.security.Principal;
import java.util.Map;
import java.util.Properties;
import javax.transaction.UserTransaction;

public interface EJBContext {
  EJBHome getEJBHome();
  
  EJBLocalHome getEJBLocalHome();
  
  Properties getEnvironment();
  
  Identity getCallerIdentity();
  
  Principal getCallerPrincipal();
  
  boolean isCallerInRole(Identity paramIdentity);
  
  boolean isCallerInRole(String paramString);
  
  UserTransaction getUserTransaction() throws IllegalStateException;
  
  void setRollbackOnly() throws IllegalStateException;
  
  boolean getRollbackOnly() throws IllegalStateException;
  
  TimerService getTimerService() throws IllegalStateException;
  
  Object lookup(String paramString);
  
  Map<String, Object> getContextData();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\EJBContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */