package javax.ejb;

import java.io.Serializable;

public interface TimerHandle extends Serializable {
  Timer getTimer() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\TimerHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */