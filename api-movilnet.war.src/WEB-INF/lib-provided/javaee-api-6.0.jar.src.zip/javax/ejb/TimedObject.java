package javax.ejb;

public interface TimedObject {
  void ejbTimeout(Timer paramTimer);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\TimedObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */