package javax.ejb;

import java.rmi.RemoteException;

public interface SessionSynchronization {
  void afterBegin() throws EJBException, RemoteException;
  
  void beforeCompletion() throws EJBException, RemoteException;
  
  void afterCompletion(boolean paramBoolean) throws EJBException, RemoteException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\SessionSynchronization.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */