package javax.ejb;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface EJB {
  String name() default "";
  
  String description() default "";
  
  String beanName() default "";
  
  Class beanInterface() default Object.class;
  
  String mappedName() default "";
  
  String lookup() default "";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\EJB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */