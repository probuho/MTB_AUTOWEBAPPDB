package javax.ejb;

public interface EJBLocalObject {
  EJBLocalHome getEJBLocalHome() throws EJBException;
  
  Object getPrimaryKey() throws EJBException;
  
  void remove() throws RemoveException, EJBException;
  
  boolean isIdentical(EJBLocalObject paramEJBLocalObject) throws EJBException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\EJBLocalObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */