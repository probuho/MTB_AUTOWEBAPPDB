package javax.ejb;

import javax.xml.rpc.handler.MessageContext;

public interface SessionContext extends EJBContext {
  EJBLocalObject getEJBLocalObject() throws IllegalStateException;
  
  EJBObject getEJBObject() throws IllegalStateException;
  
  MessageContext getMessageContext() throws IllegalStateException;
  
  <T> T getBusinessObject(Class<T> paramClass) throws IllegalStateException;
  
  Class getInvokedBusinessInterface() throws IllegalStateException;
  
  boolean wasCancelCalled() throws IllegalStateException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\SessionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */