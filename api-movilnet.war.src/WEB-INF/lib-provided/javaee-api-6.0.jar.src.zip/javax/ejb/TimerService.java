package javax.ejb;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

public interface TimerService {
  Timer createTimer(long paramLong, Serializable paramSerializable) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createSingleActionTimer(long paramLong, TimerConfig paramTimerConfig) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createTimer(long paramLong1, long paramLong2, Serializable paramSerializable) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createIntervalTimer(long paramLong1, long paramLong2, TimerConfig paramTimerConfig) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createTimer(Date paramDate, Serializable paramSerializable) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createSingleActionTimer(Date paramDate, TimerConfig paramTimerConfig) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createTimer(Date paramDate, long paramLong, Serializable paramSerializable) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createIntervalTimer(Date paramDate, long paramLong, TimerConfig paramTimerConfig) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createCalendarTimer(ScheduleExpression paramScheduleExpression) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Timer createCalendarTimer(ScheduleExpression paramScheduleExpression, TimerConfig paramTimerConfig) throws IllegalArgumentException, IllegalStateException, EJBException;
  
  Collection<Timer> getTimers() throws IllegalStateException, EJBException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\TimerService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */