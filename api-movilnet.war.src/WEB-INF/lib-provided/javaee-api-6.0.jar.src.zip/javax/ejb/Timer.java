package javax.ejb;

import java.io.Serializable;
import java.util.Date;

public interface Timer {
  void cancel() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  long getTimeRemaining() throws IllegalStateException, NoSuchObjectLocalException, NoMoreTimeoutsException, EJBException;
  
  Date getNextTimeout() throws IllegalStateException, NoSuchObjectLocalException, NoMoreTimeoutsException, EJBException;
  
  ScheduleExpression getSchedule() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  boolean isPersistent() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  boolean isCalendarTimer() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  Serializable getInfo() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  TimerHandle getHandle() throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\Timer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */