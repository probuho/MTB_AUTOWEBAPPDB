package javax.ejb;

import java.rmi.RemoteException;

public interface EntityBean extends EnterpriseBean {
  void setEntityContext(EntityContext paramEntityContext) throws EJBException, RemoteException;
  
  void unsetEntityContext() throws EJBException, RemoteException;
  
  void ejbRemove() throws RemoveException, EJBException, RemoteException;
  
  void ejbActivate() throws EJBException, RemoteException;
  
  void ejbPassivate() throws EJBException, RemoteException;
  
  void ejbLoad() throws EJBException, RemoteException;
  
  void ejbStore() throws EJBException, RemoteException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\EntityBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */