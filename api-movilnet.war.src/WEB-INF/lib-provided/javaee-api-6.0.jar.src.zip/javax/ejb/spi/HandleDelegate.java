package javax.ejb.spi;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;

public interface HandleDelegate {
  void writeEJBObject(EJBObject paramEJBObject, ObjectOutputStream paramObjectOutputStream) throws IOException;
  
  EJBObject readEJBObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException;
  
  void writeEJBHome(EJBHome paramEJBHome, ObjectOutputStream paramObjectOutputStream) throws IOException;
  
  EJBHome readEJBHome(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\spi\HandleDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */