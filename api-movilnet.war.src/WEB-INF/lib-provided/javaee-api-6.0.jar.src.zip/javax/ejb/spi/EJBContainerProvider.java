package javax.ejb.spi;

import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.embeddable.EJBContainer;

public interface EJBContainerProvider {
  EJBContainer createEJBContainer(Map<?, ?> paramMap) throws EJBException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\spi\EJBContainerProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */