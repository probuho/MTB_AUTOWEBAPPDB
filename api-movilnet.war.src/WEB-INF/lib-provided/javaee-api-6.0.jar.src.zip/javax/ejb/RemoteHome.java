package javax.ejb;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RemoteHome {
  Class value();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\RemoteHome.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */