package javax.ejb;

import java.io.Serializable;

public interface EnterpriseBean extends Serializable {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\ejb\EnterpriseBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */