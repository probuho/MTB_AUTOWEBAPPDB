package javax.activation;

import java.io.IOException;

public interface CommandObject {
  void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib-provided\javaee-api-6.0.jar!\javax\activation\CommandObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */