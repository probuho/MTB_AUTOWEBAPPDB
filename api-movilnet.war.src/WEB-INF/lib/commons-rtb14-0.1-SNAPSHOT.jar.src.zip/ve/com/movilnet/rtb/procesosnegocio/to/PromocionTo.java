/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PromocionTo
/*    */   implements Serializable
/*    */ {
/*    */   private String idPromocion;
/*    */   private String descripcion;
/*    */   
/*    */   public String getIdPromocion() {
/* 20 */     return this.idPromocion;
/*    */   }
/*    */   
/*    */   public void setIdPromocion(String idPromocion) {
/* 24 */     this.idPromocion = idPromocion;
/*    */   }
/*    */   
/*    */   public String getDescripcion() {
/* 28 */     return this.descripcion;
/*    */   }
/*    */   
/*    */   public void setDescripcion(String descripcion) {
/* 32 */     this.descripcion = descripcion;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\PromocionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */