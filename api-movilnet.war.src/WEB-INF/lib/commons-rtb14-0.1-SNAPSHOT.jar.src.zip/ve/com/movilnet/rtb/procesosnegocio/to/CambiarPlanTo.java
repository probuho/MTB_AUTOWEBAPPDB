/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CambiarPlanTo
/*    */   implements Serializable
/*    */ {
/*    */   private List servicios;
/*    */   private String imei;
/*    */   private Long numeroCelular;
/*    */   private String cedulaCliente;
/*    */   private PlanTo planNuevo;
/*    */   private EntradaTo entrada;
/*    */   private String planActual;
/*    */   private PlanConsejoComunalTo planConsejoComunal;
/*    */   
/*    */   public List getServicios() {
/* 31 */     return this.servicios;
/*    */   }
/*    */   
/*    */   public void setServicios(List servicios) {
/* 35 */     this.servicios = servicios;
/*    */   }
/*    */   
/*    */   public String getImei() {
/* 39 */     return this.imei;
/*    */   }
/*    */   
/*    */   public void setImei(String imei) {
/* 43 */     this.imei = imei;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 47 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 51 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public String getCedulaCliente() {
/* 55 */     return this.cedulaCliente;
/*    */   }
/*    */   
/*    */   public void setCedulaCliente(String cedulaCliente) {
/* 59 */     this.cedulaCliente = cedulaCliente;
/*    */   }
/*    */   
/*    */   public PlanTo getPlanNuevo() {
/* 63 */     return this.planNuevo;
/*    */   }
/*    */   
/*    */   public void setPlanNuevo(PlanTo planNuevo) {
/* 67 */     this.planNuevo = planNuevo;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 71 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 75 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public String getPlanActual() {
/* 79 */     return this.planActual;
/*    */   }
/*    */   
/*    */   public void setPlanActual(String planActual) {
/* 83 */     this.planActual = planActual;
/*    */   }
/*    */   
/*    */   public void setPlanConsejoComunal(PlanConsejoComunalTo planConsejoComunal) {
/* 87 */     this.planConsejoComunal = planConsejoComunal;
/*    */   }
/*    */   
/*    */   public PlanConsejoComunalTo getPlanConsejoComunal() {
/* 91 */     return this.planConsejoComunal;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\CambiarPlanTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */