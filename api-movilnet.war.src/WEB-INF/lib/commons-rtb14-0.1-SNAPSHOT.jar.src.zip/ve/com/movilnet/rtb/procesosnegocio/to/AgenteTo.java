/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AgenteTo
/*    */   implements Serializable
/*    */ {
/*    */   private String descripcion;
/*    */   private String idAgente;
/*    */   
/*    */   public String getDescripcion() {
/* 20 */     return this.descripcion;
/*    */   }
/*    */   
/*    */   public void setDescripcion(String descripcion) {
/* 24 */     this.descripcion = descripcion;
/*    */   }
/*    */   
/*    */   public String getIdAgente() {
/* 28 */     return this.idAgente;
/*    */   }
/*    */   
/*    */   public void setIdAgente(String idAgente) {
/* 32 */     this.idAgente = idAgente;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\AgenteTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */