/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineaTo
/*     */   implements Serializable
/*     */ {
/*     */   private Date fechaExpiracionSaldo;
/*     */   private Date fechaUltimoPago;
/*     */   private Long nuemeroCelular;
/*     */   private AgenteTo agente;
/*     */   private Date fechaActivacion;
/*     */   private String formatoSerial;
/*     */   private Date fechaCreacion;
/*     */   private String unidadesOperaciones;
/*     */   private String simCard;
/*     */   private String localidad;
/*     */   private Double cargoUltimaLlamada;
/*     */   private String imei;
/*     */   private boolean buzonMensaje;
/*     */   private Double saldo;
/*     */   private PersonaTo personaAutorizada;
/*     */   private EquipoTo equipo;
/*     */   private Date fechaCorte;
/*     */   private PromocionTo promocion;
/*     */   private int idBalanceUltimoPago;
/*     */   private PlanTo plan;
/*     */   private String estatus;
/*     */   private String ultimoPago;
/*     */   private Double montoUltimoPago;
/*     */   private PersonaTo personaContacto;
/*     */   private String tipoChip;
/*     */   
/*     */   public Long getNuemeroCelular() {
/*  46 */     return this.nuemeroCelular;
/*     */   }
/*     */   
/*     */   public void setNuemeroCelular(Long nuemeroCelular) {
/*  50 */     this.nuemeroCelular = nuemeroCelular;
/*     */   }
/*     */   
/*     */   public AgenteTo getAgente() {
/*  54 */     return this.agente;
/*     */   }
/*     */   
/*     */   public void setAgente(AgenteTo agente) {
/*  58 */     this.agente = agente;
/*     */   }
/*     */   
/*     */   public String getFormatoSerial() {
/*  62 */     return this.formatoSerial;
/*     */   }
/*     */   
/*     */   public void setFormatoSerial(String formatoSerial) {
/*  66 */     this.formatoSerial = formatoSerial;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUnidadesOperaciones() {
/*  71 */     return this.unidadesOperaciones;
/*     */   }
/*     */   
/*     */   public void setUnidadesOperaciones(String unidadesOperaciones) {
/*  75 */     this.unidadesOperaciones = unidadesOperaciones;
/*     */   }
/*     */   
/*     */   public String getSimCard() {
/*  79 */     return this.simCard;
/*     */   }
/*     */   
/*     */   public void setSimCard(String simCard) {
/*  83 */     this.simCard = simCard;
/*     */   }
/*     */   
/*     */   public String getLocalidad() {
/*  87 */     return this.localidad;
/*     */   }
/*     */   
/*     */   public void setLocalidad(String localidad) {
/*  91 */     this.localidad = localidad;
/*     */   }
/*     */   
/*     */   public Double getCargoUltimaLlamada() {
/*  95 */     return this.cargoUltimaLlamada;
/*     */   }
/*     */   
/*     */   public void setCargoUltimaLlamada(Double cargoUltimaLlamada) {
/*  99 */     this.cargoUltimaLlamada = cargoUltimaLlamada;
/*     */   }
/*     */   
/*     */   public String getImei() {
/* 103 */     return this.imei;
/*     */   }
/*     */   
/*     */   public void setImei(String imei) {
/* 107 */     this.imei = imei;
/*     */   }
/*     */   
/*     */   public boolean isBuzonMensaje() {
/* 111 */     return this.buzonMensaje;
/*     */   }
/*     */   
/*     */   public void setBuzonMensaje(boolean buzonMensaje) {
/* 115 */     this.buzonMensaje = buzonMensaje;
/*     */   }
/*     */   
/*     */   public Double getSaldo() {
/* 119 */     return this.saldo;
/*     */   }
/*     */   
/*     */   public void setSaldo(Double saldo) {
/* 123 */     this.saldo = saldo;
/*     */   }
/*     */   
/*     */   public PersonaTo getPersonaAutorizada() {
/* 127 */     return this.personaAutorizada;
/*     */   }
/*     */   
/*     */   public void setPersonaAutorizada(PersonaTo personaAutorizada) {
/* 131 */     this.personaAutorizada = personaAutorizada;
/*     */   }
/*     */   
/*     */   public EquipoTo getEquipo() {
/* 135 */     return this.equipo;
/*     */   }
/*     */   
/*     */   public void setEquipo(EquipoTo equipo) {
/* 139 */     this.equipo = equipo;
/*     */   }
/*     */   
/*     */   public Date getFechaExpiracionSaldo() {
/* 143 */     return this.fechaExpiracionSaldo;
/*     */   }
/*     */   
/*     */   public void setFechaExpiracionSaldo(Date fechaExpiracionSaldo) {
/* 147 */     this.fechaExpiracionSaldo = fechaExpiracionSaldo;
/*     */   }
/*     */   
/*     */   public Date getFechaUltimoPago() {
/* 151 */     return this.fechaUltimoPago;
/*     */   }
/*     */   
/*     */   public void setFechaUltimoPago(Date fechaUltimoPago) {
/* 155 */     this.fechaUltimoPago = fechaUltimoPago;
/*     */   }
/*     */   
/*     */   public Date getFechaActivacion() {
/* 159 */     return this.fechaActivacion;
/*     */   }
/*     */   
/*     */   public void setFechaActivacion(Date fechaActivacion) {
/* 163 */     this.fechaActivacion = fechaActivacion;
/*     */   }
/*     */   
/*     */   public Date getFechaCreacion() {
/* 167 */     return this.fechaCreacion;
/*     */   }
/*     */   
/*     */   public void setFechaCreacion(Date fechaCreacion) {
/* 171 */     this.fechaCreacion = fechaCreacion;
/*     */   }
/*     */   
/*     */   public Date getFechaCorte() {
/* 175 */     return this.fechaCorte;
/*     */   }
/*     */   
/*     */   public void setFechaCorte(Date fechaCorte) {
/* 179 */     this.fechaCorte = fechaCorte;
/*     */   }
/*     */   
/*     */   public PromocionTo getPromocion() {
/* 183 */     return this.promocion;
/*     */   }
/*     */   
/*     */   public void setPromocion(PromocionTo promocion) {
/* 187 */     this.promocion = promocion;
/*     */   }
/*     */   
/*     */   public int getIdBalanceUltimoPago() {
/* 191 */     return this.idBalanceUltimoPago;
/*     */   }
/*     */   
/*     */   public void setIdBalanceUltimoPago(int idBalanceUltimoPago) {
/* 195 */     this.idBalanceUltimoPago = idBalanceUltimoPago;
/*     */   }
/*     */   
/*     */   public PlanTo getPlan() {
/* 199 */     return this.plan;
/*     */   }
/*     */   
/*     */   public void setPlan(PlanTo plan) {
/* 203 */     this.plan = plan;
/*     */   }
/*     */   
/*     */   public String getEstatus() {
/* 207 */     return this.estatus;
/*     */   }
/*     */   
/*     */   public void setEstatus(String estatus) {
/* 211 */     this.estatus = estatus;
/*     */   }
/*     */   
/*     */   public String getUltimoPago() {
/* 215 */     return this.ultimoPago;
/*     */   }
/*     */   
/*     */   public void setUltimoPago(String ultimoPago) {
/* 219 */     this.ultimoPago = ultimoPago;
/*     */   }
/*     */   
/*     */   public Double getMontoUltimoPago() {
/* 223 */     return this.montoUltimoPago;
/*     */   }
/*     */   
/*     */   public void setMontoUltimoPago(Double montoUltimoPago) {
/* 227 */     this.montoUltimoPago = montoUltimoPago;
/*     */   }
/*     */   
/*     */   public PersonaTo getPersonaContacto() {
/* 231 */     return this.personaContacto;
/*     */   }
/*     */   
/*     */   public void setPersonaContacto(PersonaTo personaContacto) {
/* 235 */     this.personaContacto = personaContacto;
/*     */   }
/*     */   
/*     */   public void setTipoChip(String tipoChip) {
/* 239 */     this.tipoChip = tipoChip;
/*     */   }
/*     */   
/*     */   public String getTipoChip() {
/* 243 */     return this.tipoChip;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\LineaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */