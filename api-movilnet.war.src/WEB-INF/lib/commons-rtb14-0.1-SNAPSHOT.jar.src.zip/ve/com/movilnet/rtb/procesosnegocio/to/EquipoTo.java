/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EquipoTo
/*    */   implements Serializable
/*    */ {
/*    */   private String tecnologia;
/*    */   private String modelo;
/*    */   private String idEquipo;
/*    */   private String tipoEquipo;
/*    */   private String descripcionTipoEquipo;
/*    */   
/*    */   public String getTecnologia() {
/* 22 */     return this.tecnologia;
/*    */   }
/*    */   
/*    */   public void setTecnologia(String tecnologia) {
/* 26 */     this.tecnologia = tecnologia;
/*    */   }
/*    */   
/*    */   public String getModelo() {
/* 30 */     return this.modelo;
/*    */   }
/*    */   
/*    */   public void setModelo(String modelo) {
/* 34 */     this.modelo = modelo;
/*    */   }
/*    */   
/*    */   public String getIdEquipo() {
/* 38 */     return this.idEquipo;
/*    */   }
/*    */   
/*    */   public void setIdEquipo(String idEquipo) {
/* 42 */     this.idEquipo = idEquipo;
/*    */   }
/*    */   
/*    */   public void setTipoEquipo(String tipoEquipo) {
/* 46 */     this.tipoEquipo = tipoEquipo;
/*    */   }
/*    */   
/*    */   public String getTipoEquipo() {
/* 50 */     return this.tipoEquipo;
/*    */   }
/*    */   
/*    */   public void setDescripcionTipoEquipo(String descripcionTipoEquipo) {
/* 54 */     this.descripcionTipoEquipo = descripcionTipoEquipo;
/*    */   }
/*    */   
/*    */   public String getDescripcionTipoEquipo() {
/* 58 */     return this.descripcionTipoEquipo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\EquipoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */