/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlanConsejoComunalTo
/*    */   implements Serializable
/*    */ {
/*    */   private String codigoConsejo2;
/*    */   private String codigoConsejo3;
/*    */   private String codigoConsejo1;
/*    */   private String cargoConsejo;
/*    */   private String codigoConsejo4;
/*    */   private String nombreConsejo;
/*    */   
/*    */   public String getCodigoConsejo2() {
/* 24 */     return this.codigoConsejo2;
/*    */   }
/*    */   
/*    */   public void setCodigoConsejo2(String codigoConsejo2) {
/* 28 */     this.codigoConsejo2 = codigoConsejo2;
/*    */   }
/*    */   
/*    */   public String getCodigoConsejo3() {
/* 32 */     return this.codigoConsejo3;
/*    */   }
/*    */   
/*    */   public void setCodigoConsejo3(String codigoConsejo3) {
/* 36 */     this.codigoConsejo3 = codigoConsejo3;
/*    */   }
/*    */   
/*    */   public String getCodigoConsejo1() {
/* 40 */     return this.codigoConsejo1;
/*    */   }
/*    */   
/*    */   public void setCodigoConsejo1(String codigoConsejo1) {
/* 44 */     this.codigoConsejo1 = codigoConsejo1;
/*    */   }
/*    */   
/*    */   public String getCargoConsejo() {
/* 48 */     return this.cargoConsejo;
/*    */   }
/*    */   
/*    */   public void setCargoConsejo(String cargoConsejo) {
/* 52 */     this.cargoConsejo = cargoConsejo;
/*    */   }
/*    */   
/*    */   public String getCodigoConsejo4() {
/* 56 */     return this.codigoConsejo4;
/*    */   }
/*    */   
/*    */   public void setCodigoConsejo4(String codigoConsejo4) {
/* 60 */     this.codigoConsejo4 = codigoConsejo4;
/*    */   }
/*    */   
/*    */   public String getNombreConsejo() {
/* 64 */     return this.nombreConsejo;
/*    */   }
/*    */   
/*    */   public void setNombreConsejo(String nombreConsejo) {
/* 68 */     this.nombreConsejo = nombreConsejo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\PlanConsejoComunalTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */