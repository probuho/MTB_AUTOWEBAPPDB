/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PinResponseTo
/*     */   implements Serializable
/*     */ {
/*     */   private PinTo pin;
/*     */   private String estadoTarjeta;
/*     */   private String fechaUso;
/*     */   private String fechaUltimoEstado;
/*     */   private String fechaCreacion;
/*     */   private String fechaExpiracion;
/*     */   private String fechaDistribucion;
/*     */   private Long numeroTelefo;
/*     */   private String montoTarjeta;
/*     */   private String expriracionMonto;
/*     */   private String provedor;
/*     */   private String unidadOperacion;
/*     */   private Double balance;
/*     */   private String nombre;
/*     */   
/*     */   public void setPin(PinTo pin) {
/*  30 */     this.pin = pin;
/*     */   }
/*     */   
/*     */   public PinTo getPin() {
/*  34 */     return this.pin;
/*     */   }
/*     */   
/*     */   public void setEstadoTarjeta(String estadoTarjeta) {
/*  38 */     this.estadoTarjeta = estadoTarjeta;
/*     */   }
/*     */   
/*     */   public String getEstadoTarjeta() {
/*  42 */     return this.estadoTarjeta;
/*     */   }
/*     */   
/*     */   public void setFechaUso(String fechaUso) {
/*  46 */     this.fechaUso = fechaUso;
/*     */   }
/*     */   
/*     */   public String getFechaUso() {
/*  50 */     return this.fechaUso;
/*     */   }
/*     */   
/*     */   public void setFechaUltimoEstado(String fechaUltimoEstado) {
/*  54 */     this.fechaUltimoEstado = fechaUltimoEstado;
/*     */   }
/*     */   
/*     */   public String getFechaUltimoEstado() {
/*  58 */     return this.fechaUltimoEstado;
/*     */   }
/*     */   
/*     */   public void setFechaCreacion(String fechaCreacion) {
/*  62 */     this.fechaCreacion = fechaCreacion;
/*     */   }
/*     */   
/*     */   public String getFechaCreacion() {
/*  66 */     return this.fechaCreacion;
/*     */   }
/*     */   
/*     */   public void setFechaExpiracion(String fechaExpiracion) {
/*  70 */     this.fechaExpiracion = fechaExpiracion;
/*     */   }
/*     */   
/*     */   public String getFechaExpiracion() {
/*  74 */     return this.fechaExpiracion;
/*     */   }
/*     */   
/*     */   public void setFechaDistribucion(String fechaDistribucion) {
/*  78 */     this.fechaDistribucion = fechaDistribucion;
/*     */   }
/*     */   
/*     */   public String getFechaDistribucion() {
/*  82 */     return this.fechaDistribucion;
/*     */   }
/*     */   
/*     */   public void setNumeroTelefo(Long numeroTelefo) {
/*  86 */     this.numeroTelefo = numeroTelefo;
/*     */   }
/*     */   
/*     */   public Long getNumeroTelefo() {
/*  90 */     return this.numeroTelefo;
/*     */   }
/*     */   
/*     */   public void setMontoTarjeta(String montoTarjeta) {
/*  94 */     this.montoTarjeta = montoTarjeta;
/*     */   }
/*     */   
/*     */   public String getMontoTarjeta() {
/*  98 */     return this.montoTarjeta;
/*     */   }
/*     */   
/*     */   public void setExpriracionMonto(String expriracionMonto) {
/* 102 */     this.expriracionMonto = expriracionMonto;
/*     */   }
/*     */   
/*     */   public String getExpriracionMonto() {
/* 106 */     return this.expriracionMonto;
/*     */   }
/*     */   
/*     */   public void setProvedor(String provedor) {
/* 110 */     this.provedor = provedor;
/*     */   }
/*     */   
/*     */   public String getProvedor() {
/* 114 */     return this.provedor;
/*     */   }
/*     */   
/*     */   public void setUnidadOperacion(String unidadOperacion) {
/* 118 */     this.unidadOperacion = unidadOperacion;
/*     */   }
/*     */   
/*     */   public String getUnidadOperacion() {
/* 122 */     return this.unidadOperacion;
/*     */   }
/*     */   
/*     */   public void setBalance(Double balance) {
/* 126 */     this.balance = balance;
/*     */   }
/*     */   
/*     */   public Double getBalance() {
/* 130 */     return this.balance;
/*     */   }
/*     */   
/*     */   public void setNombre(String nombre) {
/* 134 */     this.nombre = nombre;
/*     */   }
/*     */   
/*     */   public String getNombre() {
/* 138 */     return this.nombre;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\PinResponseTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */