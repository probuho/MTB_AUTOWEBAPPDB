/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuspensionTo
/*    */   implements Serializable
/*    */ {
/*    */   private String numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   private String razon;
/*    */   
/*    */   public String getNumeroCelular() {
/* 21 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(String numeroCelular) {
/* 25 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 29 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 33 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public String getRazon() {
/* 37 */     return this.razon;
/*    */   }
/*    */   
/*    */   public void setRazon(String razon) {
/* 41 */     this.razon = razon;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\SuspensionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */