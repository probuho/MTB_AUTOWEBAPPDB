/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LlamadaTo
/*     */   implements Serializable
/*     */ {
/*     */   private String idLlamada;
/*     */   private Date fechaInicioLlamada;
/*     */   private Date fechaFinLlamada;
/*     */   private String descripcion;
/*     */   private String numeroReceptor;
/*     */   private Long duracionLlamada;
/*     */   private Double costoLlamada;
/*     */   private String tipoLlamada;
/*     */   private String razonLlamada;
/*     */   private String numeroLlamada;
/*     */   private String proveedorServicio;
/*     */   
/*     */   public void setIdLlamada(String idLlamada) {
/*  31 */     this.idLlamada = idLlamada;
/*     */   }
/*     */   
/*     */   public String getIdLlamada() {
/*  35 */     return this.idLlamada;
/*     */   }
/*     */   
/*     */   public void setFechaInicioLlamada(Date fechaInicioLlamada) {
/*  39 */     this.fechaInicioLlamada = fechaInicioLlamada;
/*     */   }
/*     */   
/*     */   public Date getFechaInicioLlamada() {
/*  43 */     return this.fechaInicioLlamada;
/*     */   }
/*     */   
/*     */   public void setFechaFinLlamada(Date fechaFinLlamada) {
/*  47 */     this.fechaFinLlamada = fechaFinLlamada;
/*     */   }
/*     */   
/*     */   public Date getFechaFinLlamada() {
/*  51 */     return this.fechaFinLlamada;
/*     */   }
/*     */   
/*     */   public void setDescripcion(String descripcion) {
/*  55 */     this.descripcion = descripcion;
/*     */   }
/*     */   
/*     */   public String getDescripcion() {
/*  59 */     return this.descripcion;
/*     */   }
/*     */   
/*     */   public void setNumeroReceptor(String numeroReceptor) {
/*  63 */     this.numeroReceptor = numeroReceptor;
/*     */   }
/*     */   
/*     */   public String getNumeroReceptor() {
/*  67 */     return this.numeroReceptor;
/*     */   }
/*     */   
/*     */   public void setDuracionLlamada(Long duracionLlamada) {
/*  71 */     this.duracionLlamada = duracionLlamada;
/*     */   }
/*     */   
/*     */   public Long getDuracionLlamada() {
/*  75 */     return this.duracionLlamada;
/*     */   }
/*     */   
/*     */   public void setCostoLlamada(Double costoLlamada) {
/*  79 */     this.costoLlamada = costoLlamada;
/*     */   }
/*     */   
/*     */   public Double getCostoLlamada() {
/*  83 */     return this.costoLlamada;
/*     */   }
/*     */   
/*     */   public void setTipoLlamada(String tipoLlamada) {
/*  87 */     this.tipoLlamada = tipoLlamada;
/*     */   }
/*     */   
/*     */   public String getTipoLlamada() {
/*  91 */     return this.tipoLlamada;
/*     */   }
/*     */   
/*     */   public void setRazonLlamada(String razonLlamada) {
/*  95 */     this.razonLlamada = razonLlamada;
/*     */   }
/*     */   
/*     */   public String getRazonLlamada() {
/*  99 */     return this.razonLlamada;
/*     */   }
/*     */   
/*     */   public void setNumeroLlamada(String numeroLlamada) {
/* 103 */     this.numeroLlamada = numeroLlamada;
/*     */   }
/*     */   
/*     */   public String getNumeroLlamada() {
/* 107 */     return this.numeroLlamada;
/*     */   }
/*     */   
/*     */   public void setProveedorServicio(String proveedorServicio) {
/* 111 */     this.proveedorServicio = proveedorServicio;
/*     */   }
/*     */   
/*     */   public String getProveedorServicio() {
/* 115 */     return this.proveedorServicio;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\LlamadaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */