/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActDatosLineaTo
/*    */   implements Serializable
/*    */ {
/*    */   private String numeroCelular;
/*    */   private LineaTo linea;
/*    */   private EntradaTo entrada;
/*    */   
/*    */   public String getNumeroCelular() {
/* 21 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(String numeroCelular) {
/* 25 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public LineaTo getLinea() {
/* 29 */     return this.linea;
/*    */   }
/*    */   
/*    */   public void setLinea(LineaTo linea) {
/* 33 */     this.linea = linea;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 37 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 41 */     this.entrada = entrada;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ActDatosLineaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */