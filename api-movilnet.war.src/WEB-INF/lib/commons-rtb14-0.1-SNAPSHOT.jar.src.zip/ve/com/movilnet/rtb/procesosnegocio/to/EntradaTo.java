/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntradaTo
/*    */   implements Serializable
/*    */ {
/*    */   private String tecnologia;
/*    */   private AplicacionTo aplicacion;
/*    */   private String proveedor;
/*    */   private String nodo;
/*    */   private SeguridadTo seguridad;
/*    */   private String idUsuario;
/*    */   
/*    */   public String getTecnologia() {
/* 24 */     return this.tecnologia;
/*    */   }
/*    */   
/*    */   public void setTecnologia(String tecnologia) {
/* 28 */     this.tecnologia = tecnologia;
/*    */   }
/*    */   
/*    */   public AplicacionTo getAplicacion() {
/* 32 */     return this.aplicacion;
/*    */   }
/*    */   
/*    */   public void setAplicacion(AplicacionTo aplicacion) {
/* 36 */     this.aplicacion = aplicacion;
/*    */   }
/*    */   
/*    */   public String getProveedor() {
/* 40 */     return this.proveedor;
/*    */   }
/*    */   
/*    */   public void setProveedor(String proveedor) {
/* 44 */     this.proveedor = proveedor;
/*    */   }
/*    */   
/*    */   public String getNodo() {
/* 48 */     return this.nodo;
/*    */   }
/*    */   
/*    */   public void setNodo(String nodo) {
/* 52 */     this.nodo = nodo;
/*    */   }
/*    */   
/*    */   public SeguridadTo getSeguridad() {
/* 56 */     return this.seguridad;
/*    */   }
/*    */   
/*    */   public void setSeguridad(SeguridadTo seguridad) {
/* 60 */     this.seguridad = seguridad;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setIdUsuario(String idUsuario) {
/* 65 */     this.idUsuario = idUsuario;
/*    */   }
/*    */   
/*    */   public String getIdUsuario() {
/* 69 */     return this.idUsuario;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\EntradaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */