/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlanTo
/*    */   implements Serializable
/*    */ {
/*    */   private Date fechaActivacion;
/*    */   private String unidadPlan;
/*    */   private String cargoPeriodicoAsociado;
/*    */   private String descripcion;
/*    */   private String idPlan;
/*    */   private String sufijoNombrePlan;
/*    */   private String idTipoPlan;
/*    */   
/*    */   public Date getFechaActivacion() {
/* 27 */     return this.fechaActivacion;
/*    */   }
/*    */   
/*    */   public void setFechaActivacion(Date fechaActivacion) {
/* 31 */     this.fechaActivacion = fechaActivacion;
/*    */   }
/*    */   
/*    */   public String getUnidadPlan() {
/* 35 */     return this.unidadPlan;
/*    */   }
/*    */   
/*    */   public void setUnidadPlan(String unidadPlan) {
/* 39 */     this.unidadPlan = unidadPlan;
/*    */   }
/*    */   
/*    */   public String getCargoPeriodicoAsociado() {
/* 43 */     return this.cargoPeriodicoAsociado;
/*    */   }
/*    */   
/*    */   public void setCargoPeriodicoAsociado(String cargoPeriodicoAsociado) {
/* 47 */     this.cargoPeriodicoAsociado = cargoPeriodicoAsociado;
/*    */   }
/*    */   
/*    */   public String getDescripcion() {
/* 51 */     return this.descripcion;
/*    */   }
/*    */   
/*    */   public void setDescripcion(String descripcion) {
/* 55 */     this.descripcion = descripcion;
/*    */   }
/*    */   
/*    */   public String getIdPlan() {
/* 59 */     return this.idPlan;
/*    */   }
/*    */   
/*    */   public void setIdPlan(String idPlan) {
/* 63 */     this.idPlan = idPlan;
/*    */   }
/*    */   
/*    */   public String getSufijoNombrePlan() {
/* 67 */     return this.sufijoNombrePlan;
/*    */   }
/*    */   
/*    */   public void setSufijoNombrePlan(String sufijoNombrePlan) {
/* 71 */     this.sufijoNombrePlan = sufijoNombrePlan;
/*    */   }
/*    */   
/*    */   public String getIdTipoPlan() {
/* 75 */     return this.idTipoPlan;
/*    */   }
/*    */   
/*    */   public void setIdTipoPlan(String idTipoPlan) {
/* 79 */     this.idTipoPlan = idTipoPlan;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\PlanTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */