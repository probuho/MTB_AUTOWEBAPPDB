/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecargaSaldoTo
/*    */   implements Serializable
/*    */ {
/*    */   private RecargaTo recarga;
/*    */   private Long numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   
/*    */   public RecargaTo getRecarga() {
/* 21 */     return this.recarga;
/*    */   }
/*    */   
/*    */   public void setRecarga(RecargaTo recarga) {
/* 25 */     this.recarga = recarga;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 29 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 33 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 37 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 41 */     this.entrada = entrada;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\RecargaSaldoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */