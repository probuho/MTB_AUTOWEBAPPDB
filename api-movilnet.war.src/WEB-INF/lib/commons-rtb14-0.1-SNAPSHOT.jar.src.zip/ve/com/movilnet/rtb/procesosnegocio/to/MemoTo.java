/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemoTo
/*    */   implements Serializable
/*    */ {
/*    */   private String categoria;
/*    */   private Date fecha;
/*    */   private String usuario;
/*    */   private String asunto;
/*    */   private String idMemo;
/*    */   private String memoTexto;
/*    */   
/*    */   public String getCategoria() {
/* 26 */     return this.categoria;
/*    */   }
/*    */   
/*    */   public void setCategoria(String categoria) {
/* 30 */     this.categoria = categoria;
/*    */   }
/*    */   
/*    */   public Date getFecha() {
/* 34 */     return this.fecha;
/*    */   }
/*    */   
/*    */   public void setFecha(Date fecha) {
/* 38 */     this.fecha = fecha;
/*    */   }
/*    */   
/*    */   public String getUsuario() {
/* 42 */     return this.usuario;
/*    */   }
/*    */   
/*    */   public void setUsuario(String usuario) {
/* 46 */     this.usuario = usuario;
/*    */   }
/*    */   
/*    */   public String getAsunto() {
/* 50 */     return this.asunto;
/*    */   }
/*    */   
/*    */   public void setAsunto(String asunto) {
/* 54 */     this.asunto = asunto;
/*    */   }
/*    */   
/*    */   public String getIdMemo() {
/* 58 */     return this.idMemo;
/*    */   }
/*    */   
/*    */   public void setIdMemo(String idMemo) {
/* 62 */     this.idMemo = idMemo;
/*    */   }
/*    */   
/*    */   public void setMemoTexto(String memoTexto) {
/* 66 */     this.memoTexto = memoTexto;
/*    */   }
/*    */   
/*    */   public String getMemoTexto() {
/* 70 */     return this.memoTexto;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\MemoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */