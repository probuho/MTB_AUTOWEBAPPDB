/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SeguridadTo
/*    */   implements Serializable
/*    */ {
/*    */   private String usuario;
/*    */   private String clave;
/*    */   
/*    */   public String getUsuario() {
/* 19 */     return this.usuario;
/*    */   }
/*    */   
/*    */   public void setUsuario(String usuario) {
/* 23 */     this.usuario = usuario;
/*    */   }
/*    */   
/*    */   public String getClave() {
/* 27 */     return this.clave;
/*    */   }
/*    */   
/*    */   public void setClave(String clave) {
/* 31 */     this.clave = clave;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\SeguridadTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */