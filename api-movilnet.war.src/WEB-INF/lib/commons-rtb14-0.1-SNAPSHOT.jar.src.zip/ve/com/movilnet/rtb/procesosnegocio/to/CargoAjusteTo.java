/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CargoAjusteTo
/*     */   implements Serializable
/*     */ {
/*     */   private String idCargoAjuste;
/*     */   private Date fechaCargoAjuste;
/*     */   private Double montoBono;
/*     */   private Double montoDescuento;
/*     */   private String descripcionCargoAjuste;
/*     */   private String planDescuento;
/*     */   private String bonoPlan;
/*     */   
/*     */   public String getIdCargoAjuste() {
/*  51 */     return this.idCargoAjuste;
/*     */   }
/*     */   
/*     */   public void setIdCargoAjuste(String idCargoAjuste) {
/*  55 */     this.idCargoAjuste = idCargoAjuste;
/*     */   }
/*     */   
/*     */   public Date getFechaCargoAjuste() {
/*  59 */     return this.fechaCargoAjuste;
/*     */   }
/*     */   
/*     */   public void setFechaCargoAjuste(Date fechaCargoAjuste) {
/*  63 */     this.fechaCargoAjuste = fechaCargoAjuste;
/*     */   }
/*     */   
/*     */   public Double getMontoBono() {
/*  67 */     return this.montoBono;
/*     */   }
/*     */   
/*     */   public void setMontoBono(Double montoBono) {
/*  71 */     this.montoBono = montoBono;
/*     */   }
/*     */   
/*     */   public Double getMontoDescuento() {
/*  75 */     return this.montoDescuento;
/*     */   }
/*     */   
/*     */   public void setMontoDescuento(Double montoDescuento) {
/*  79 */     this.montoDescuento = montoDescuento;
/*     */   }
/*     */   
/*     */   public String getDescripcionCargoAjuste() {
/*  83 */     return this.descripcionCargoAjuste;
/*     */   }
/*     */   
/*     */   public void setDescripcionCargoAjuste(String descripcionCargoAjuste) {
/*  87 */     this.descripcionCargoAjuste = descripcionCargoAjuste;
/*     */   }
/*     */   
/*     */   public String getPlanDescuento() {
/*  91 */     return this.planDescuento;
/*     */   }
/*     */   
/*     */   public void setPlanDescuento(String planDescuento) {
/*  95 */     this.planDescuento = planDescuento;
/*     */   }
/*     */   
/*     */   public String getBonoPlan() {
/*  99 */     return this.bonoPlan;
/*     */   }
/*     */   
/*     */   public void setBonoPlan(String bonoPlan) {
/* 103 */     this.bonoPlan = bonoPlan;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\CargoAjusteTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */