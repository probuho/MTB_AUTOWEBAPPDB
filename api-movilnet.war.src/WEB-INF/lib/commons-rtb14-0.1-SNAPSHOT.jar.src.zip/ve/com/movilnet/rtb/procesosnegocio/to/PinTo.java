/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PinTo
/*    */   implements Serializable
/*    */ {
/*    */   private String codigoTarjeta;
/*    */   private String memoTest;
/*    */   private String tipoAjuste;
/*    */   private String razonAjuste;
/*    */   
/*    */   public String getCodigoTarjeta() {
/* 22 */     return this.codigoTarjeta;
/*    */   }
/*    */   
/*    */   public void setCodigoTarjeta(String codigoTarjeta) {
/* 26 */     this.codigoTarjeta = codigoTarjeta;
/*    */   }
/*    */   
/*    */   public String getMemoTest() {
/* 30 */     return this.memoTest;
/*    */   }
/*    */   
/*    */   public void setMemoTest(String memoTest) {
/* 34 */     this.memoTest = memoTest;
/*    */   }
/*    */   
/*    */   public String getTipoAjuste() {
/* 38 */     return this.tipoAjuste;
/*    */   }
/*    */   
/*    */   public void setTipoAjuste(String tipoAjuste) {
/* 42 */     this.tipoAjuste = tipoAjuste;
/*    */   }
/*    */   
/*    */   public String getRazonAjuste() {
/* 46 */     return this.razonAjuste;
/*    */   }
/*    */   
/*    */   public void setRazonAjuste(String razonAjuste) {
/* 50 */     this.razonAjuste = razonAjuste;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\PinTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */