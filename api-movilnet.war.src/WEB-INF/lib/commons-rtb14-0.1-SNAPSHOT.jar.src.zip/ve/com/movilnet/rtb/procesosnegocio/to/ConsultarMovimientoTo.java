/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConsultarMovimientoTo
/*    */   implements Serializable
/*    */ {
/*    */   private Date fechaInicioConsulta;
/*    */   private Long numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   private Date fechaFinConsulta;
/*    */   private int numeroRegistros;
/*    */   private int ultimoRegistro;
/*    */   
/*    */   public Date getFechaInicioConsulta() {
/* 26 */     return this.fechaInicioConsulta;
/*    */   }
/*    */   
/*    */   public void setFechaInicioConsulta(Date fechaInicioConsulta) {
/* 30 */     this.fechaInicioConsulta = fechaInicioConsulta;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 34 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 38 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 42 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 46 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public int getNumeroRegistros() {
/* 50 */     return this.numeroRegistros;
/*    */   }
/*    */   
/*    */   public void setNumeroRegistros(int numeroRegistros) {
/* 54 */     this.numeroRegistros = numeroRegistros;
/*    */   }
/*    */   
/*    */   public Date getFechaFinConsulta() {
/* 58 */     return this.fechaFinConsulta;
/*    */   }
/*    */   
/*    */   public void setFechaFinConsulta(Date fechaFinConsulta) {
/* 62 */     this.fechaFinConsulta = fechaFinConsulta;
/*    */   }
/*    */   
/*    */   public void setUltimoRegistro(int ultimoRegistro) {
/* 66 */     this.ultimoRegistro = ultimoRegistro;
/*    */   }
/*    */   
/*    */   public int getUltimoRegistro() {
/* 70 */     return this.ultimoRegistro;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ConsultarMovimientoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */