/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CrearMemoTo
/*    */   implements Serializable
/*    */ {
/*    */   private MemoTo memo;
/*    */   private Long numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   
/*    */   public MemoTo getMemo() {
/* 21 */     return this.memo;
/*    */   }
/*    */   
/*    */   public void setMemo(MemoTo memo) {
/* 25 */     this.memo = memo;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 29 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 33 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 37 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 41 */     this.entrada = entrada;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\CrearMemoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */