/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PagoTo
/*     */   implements Serializable
/*     */ {
/*     */   private String idPago;
/*     */   private Date fechaPago;
/*     */   private Double montoTarjeta;
/*     */   private Date fechaExpiracionPago;
/*     */   private String numeroTarjeta;
/*     */   private Double montoAplicadoBalance;
/*     */   private String metodoPago;
/*     */   private Long tipoTarjeta;
/*     */   
/*     */   public String getIdPago() {
/*  53 */     return this.idPago;
/*     */   }
/*     */   
/*     */   public void setIdPago(String idPago) {
/*  57 */     this.idPago = idPago;
/*     */   }
/*     */   
/*     */   public Date getFechaPago() {
/*  61 */     return this.fechaPago;
/*     */   }
/*     */   
/*     */   public void setFechaPago(Date fechaPago) {
/*  65 */     this.fechaPago = fechaPago;
/*     */   }
/*     */   
/*     */   public Double getMontoTarjeta() {
/*  69 */     return this.montoTarjeta;
/*     */   }
/*     */   
/*     */   public void setMontoTarjeta(Double montoTarjeta) {
/*  73 */     this.montoTarjeta = montoTarjeta;
/*     */   }
/*     */   
/*     */   public Date getFechaExpiracionPago() {
/*  77 */     return this.fechaExpiracionPago;
/*     */   }
/*     */   
/*     */   public void setFechaExpiracionPago(Date fechaExpiracionPago) {
/*  81 */     this.fechaExpiracionPago = fechaExpiracionPago;
/*     */   }
/*     */   
/*     */   public String getNumeroTarjeta() {
/*  85 */     return this.numeroTarjeta;
/*     */   }
/*     */   
/*     */   public void setNumeroTarjeta(String numeroTarjeta) {
/*  89 */     this.numeroTarjeta = numeroTarjeta;
/*     */   }
/*     */   
/*     */   public Double getMontoAplicadoBalance() {
/*  93 */     return this.montoAplicadoBalance;
/*     */   }
/*     */   
/*     */   public void setMontoAplicadoBalance(Double montoAplicadoBalance) {
/*  97 */     this.montoAplicadoBalance = montoAplicadoBalance;
/*     */   }
/*     */   
/*     */   public String getMetodoPago() {
/* 101 */     return this.metodoPago;
/*     */   }
/*     */   
/*     */   public void setMetodoPago(String metodoPago) {
/* 105 */     this.metodoPago = metodoPago;
/*     */   }
/*     */   
/*     */   public Long getTipoTarjeta() {
/* 109 */     return this.tipoTarjeta;
/*     */   }
/*     */   
/*     */   public void setTipoTarjeta(Long tipoTarjeta) {
/* 113 */     this.tipoTarjeta = tipoTarjeta;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\PagoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */