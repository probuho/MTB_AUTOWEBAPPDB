/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AjusteTo
/*     */   implements Serializable
/*     */ {
/*     */   private String nombreBalance;
/*     */   private int incrementoDias;
/*     */   private String idBalance;
/*     */   private Double montoAjuste;
/*     */   private String casoSise;
/*     */   private String tipoIncremento;
/*     */   private Double montoIva;
/*     */   private String indicadorIva;
/*     */   private String subCategoria;
/*     */   private String descripcionMemo;
/*     */   private String razonAjuste;
/*     */   
/*     */   public String getNombreBalance() {
/*  29 */     return this.nombreBalance;
/*     */   }
/*     */   
/*     */   public void setNombreBalance(String nombreBalance) {
/*  33 */     this.nombreBalance = nombreBalance;
/*     */   }
/*     */   
/*     */   public int getIncrementoDias() {
/*  37 */     return this.incrementoDias;
/*     */   }
/*     */   
/*     */   public void setIncrementoDias(int incrementoDias) {
/*  41 */     this.incrementoDias = incrementoDias;
/*     */   }
/*     */   
/*     */   public String getIdBalance() {
/*  45 */     return this.idBalance;
/*     */   }
/*     */   
/*     */   public void setIdBalance(String idBalance) {
/*  49 */     this.idBalance = idBalance;
/*     */   }
/*     */   
/*     */   public Double getMontoAjuste() {
/*  53 */     return this.montoAjuste;
/*     */   }
/*     */   
/*     */   public void setMontoAjuste(Double montoAjuste) {
/*  57 */     this.montoAjuste = montoAjuste;
/*     */   }
/*     */   
/*     */   public String getCasoSise() {
/*  61 */     return this.casoSise;
/*     */   }
/*     */   
/*     */   public void setCasoSise(String casoSise) {
/*  65 */     this.casoSise = casoSise;
/*     */   }
/*     */   
/*     */   public String getTipoIncremento() {
/*  69 */     return this.tipoIncremento;
/*     */   }
/*     */   
/*     */   public void setTipoIncremento(String tipoIncremento) {
/*  73 */     this.tipoIncremento = tipoIncremento;
/*     */   }
/*     */   
/*     */   public Double getMontoIva() {
/*  77 */     return this.montoIva;
/*     */   }
/*     */   
/*     */   public void setMontoIva(Double montoIva) {
/*  81 */     this.montoIva = montoIva;
/*     */   }
/*     */   
/*     */   public String getIndicadorIva() {
/*  85 */     return this.indicadorIva;
/*     */   }
/*     */   
/*     */   public void setIndicadorIva(String indicadorIva) {
/*  89 */     this.indicadorIva = indicadorIva;
/*     */   }
/*     */   
/*     */   public String getSubCategoria() {
/*  93 */     return this.subCategoria;
/*     */   }
/*     */   
/*     */   public void setSubCategoria(String subCategoria) {
/*  97 */     this.subCategoria = subCategoria;
/*     */   }
/*     */   
/*     */   public String getDescripcionMemo() {
/* 101 */     return this.descripcionMemo;
/*     */   }
/*     */   
/*     */   public void setDescripcionMemo(String descripcionMemo) {
/* 105 */     this.descripcionMemo = descripcionMemo;
/*     */   }
/*     */   
/*     */   public String getRazonAjuste() {
/* 109 */     return this.razonAjuste;
/*     */   }
/*     */   
/*     */   public void setRazonAjuste(String razonAjuste) {
/* 113 */     this.razonAjuste = razonAjuste;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\AjusteTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */