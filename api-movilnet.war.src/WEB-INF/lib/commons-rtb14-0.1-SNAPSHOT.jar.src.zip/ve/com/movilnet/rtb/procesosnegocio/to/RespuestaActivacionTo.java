/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RespuestaActivacionTo
/*    */ {
/*    */   private long numero;
/*    */   private long numeroContrato;
/*    */   
/*    */   public void setNumero(long numero) {
/* 13 */     this.numero = numero;
/*    */   }
/*    */   
/*    */   public long getNumero() {
/* 17 */     return this.numero;
/*    */   }
/*    */   
/*    */   public void setNumeroContrato(long numeroContrato) {
/* 21 */     this.numeroContrato = numeroContrato;
/*    */   }
/*    */   
/*    */   public long getNumeroContrato() {
/* 25 */     return this.numeroContrato;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\RespuestaActivacionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */