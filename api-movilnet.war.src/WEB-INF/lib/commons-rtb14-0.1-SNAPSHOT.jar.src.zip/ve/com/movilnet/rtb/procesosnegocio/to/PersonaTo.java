/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersonaTo
/*    */   implements Serializable
/*    */ {
/*    */   private String nombre;
/*    */   private String apellido;
/*    */   private String telefono;
/*    */   private String cedula;
/*    */   
/*    */   public String getNombre() {
/* 22 */     return this.nombre;
/*    */   }
/*    */   
/*    */   public void setNombre(String nombre) {
/* 26 */     this.nombre = nombre;
/*    */   }
/*    */   
/*    */   public String getApellido() {
/* 30 */     return this.apellido;
/*    */   }
/*    */   
/*    */   public void setApellido(String apellido) {
/* 34 */     this.apellido = apellido;
/*    */   }
/*    */   
/*    */   public String getTelefono() {
/* 38 */     return this.telefono;
/*    */   }
/*    */   
/*    */   public void setTelefono(String telefono) {
/* 42 */     this.telefono = telefono;
/*    */   }
/*    */   
/*    */   public String getCedula() {
/* 46 */     return this.cedula;
/*    */   }
/*    */   
/*    */   public void setCedula(String cedula) {
/* 50 */     this.cedula = cedula;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\PersonaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */