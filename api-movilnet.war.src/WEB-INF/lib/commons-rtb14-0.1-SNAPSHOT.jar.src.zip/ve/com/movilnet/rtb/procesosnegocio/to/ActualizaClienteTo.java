/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActualizaClienteTo
/*    */   implements Serializable
/*    */ {
/*    */   private EntradaTo entrada;
/*    */   private String numero;
/*    */   private ClienteTo cliente;
/*    */   private AgenteTo agente;
/*    */   private PersonaTo personaAutorizada;
/*    */   private PersonaTo personaContacto;
/*    */   private PersonaTo usuarioAutenticado;
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 19 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 23 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setNumero(String numero) {
/* 27 */     this.numero = numero;
/*    */   }
/*    */   
/*    */   public String getNumero() {
/* 31 */     return this.numero;
/*    */   }
/*    */   
/*    */   public void setCliente(ClienteTo cliente) {
/* 35 */     this.cliente = cliente;
/*    */   }
/*    */   
/*    */   public ClienteTo getCliente() {
/* 39 */     return this.cliente;
/*    */   }
/*    */   
/*    */   public void setPersonaAutorizada(PersonaTo personaAutorizada) {
/* 43 */     this.personaAutorizada = personaAutorizada;
/*    */   }
/*    */   
/*    */   public PersonaTo getPersonaAutorizada() {
/* 47 */     return this.personaAutorizada;
/*    */   }
/*    */   
/*    */   public void setPersonaContacto(PersonaTo personaContacto) {
/* 51 */     this.personaContacto = personaContacto;
/*    */   }
/*    */   
/*    */   public PersonaTo getPersonaContacto() {
/* 55 */     return this.personaContacto;
/*    */   }
/*    */   
/*    */   public void setAgente(AgenteTo agente) {
/* 59 */     this.agente = agente;
/*    */   }
/*    */   
/*    */   public AgenteTo getAgente() {
/* 63 */     return this.agente;
/*    */   }
/*    */   
/*    */   public void setUsuarioAutenticado(PersonaTo usuarioAutenticado) {
/* 67 */     this.usuarioAutenticado = usuarioAutenticado;
/*    */   }
/*    */   
/*    */   public PersonaTo getUsuarioAutenticado() {
/* 71 */     return this.usuarioAutenticado;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ActualizaClienteTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */