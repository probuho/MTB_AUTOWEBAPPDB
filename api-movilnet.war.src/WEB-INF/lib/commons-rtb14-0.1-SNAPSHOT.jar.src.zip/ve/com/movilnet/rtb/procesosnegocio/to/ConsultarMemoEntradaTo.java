/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConsultarMemoEntradaTo
/*    */   implements Serializable
/*    */ {
/*    */   private String categoria;
/*    */   private Long numeroCelular;
/*    */   private Date fechaFin;
/*    */   private EntradaTo entrada;
/*    */   private Date fechaInicio;
/*    */   
/*    */   public String getCategoria() {
/* 25 */     return this.categoria;
/*    */   }
/*    */   
/*    */   public void setCategoria(String categoria) {
/* 29 */     this.categoria = categoria;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 33 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 37 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public Date getFechaFin() {
/* 41 */     return this.fechaFin;
/*    */   }
/*    */   
/*    */   public void setFechaFin(Date fechaFin) {
/* 45 */     this.fechaFin = fechaFin;
/*    */   }
/*    */   
/*    */   public Date getFechaInicio() {
/* 49 */     return this.fechaInicio;
/*    */   }
/*    */   
/*    */   public void setFechaInicio(Date fechaInicio) {
/* 53 */     this.fechaInicio = fechaInicio;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 57 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 61 */     this.entrada = entrada;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ConsultarMemoEntradaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */