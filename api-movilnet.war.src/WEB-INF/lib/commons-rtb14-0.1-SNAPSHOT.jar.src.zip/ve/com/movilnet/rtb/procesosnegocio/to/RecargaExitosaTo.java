/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecargaExitosaTo
/*    */   implements Serializable
/*    */ {
/*    */   protected Double balance;
/*    */   protected Date fechaVencimientoSaldo;
/*    */   protected Double montoRecarga;
/*    */   protected String saldoAnterior;
/*    */   
/*    */   public Double getBalance() {
/* 24 */     return this.balance;
/*    */   }
/*    */   
/*    */   public void setBalance(Double balance) {
/* 28 */     this.balance = balance;
/*    */   }
/*    */   
/*    */   public Double getMontoRecarga() {
/* 32 */     return this.montoRecarga;
/*    */   }
/*    */   
/*    */   public void setMontoRecarga(Double montoRecarga) {
/* 36 */     this.montoRecarga = montoRecarga;
/*    */   }
/*    */   
/*    */   public Date getFechaVencimientoSaldo() {
/* 40 */     return this.fechaVencimientoSaldo;
/*    */   }
/*    */   
/*    */   public void setFechaVencimientoSaldo(Date fechaVencimientoSaldo) {
/* 44 */     this.fechaVencimientoSaldo = fechaVencimientoSaldo;
/*    */   }
/*    */   
/*    */   public void setSaldoAnterior(String saldoAnterior) {
/* 48 */     this.saldoAnterior = saldoAnterior;
/*    */   }
/*    */   
/*    */   public String getSaldoAnterior() {
/* 52 */     return this.saldoAnterior;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\RecargaExitosaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */