/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CuentaTo
/*    */   implements Serializable
/*    */ {
/*    */   private String subTipoCuenta;
/*    */   private String numeroCuenta;
/*    */   private String tipoCuenta;
/*    */   private String idRif;
/*    */   private String tipoRif;
/*    */   private String razonSocial;
/*    */   private String actividadComercial;
/*    */   
/*    */   public String getSubTipoCuenta() {
/* 26 */     return this.subTipoCuenta;
/*    */   }
/*    */   
/*    */   public void setSubTipoCuenta(String subTipoCuenta) {
/* 30 */     this.subTipoCuenta = subTipoCuenta;
/*    */   }
/*    */   
/*    */   public String getNumeroCuenta() {
/* 34 */     return this.numeroCuenta;
/*    */   }
/*    */   
/*    */   public void setNumeroCuenta(String numeroCuenta) {
/* 38 */     this.numeroCuenta = numeroCuenta;
/*    */   }
/*    */   
/*    */   public String getTipoCuenta() {
/* 42 */     return this.tipoCuenta;
/*    */   }
/*    */   
/*    */   public void setTipoCuenta(String tipoCuenta) {
/* 46 */     this.tipoCuenta = tipoCuenta;
/*    */   }
/*    */   
/*    */   public void setIdRif(String idRif) {
/* 50 */     this.idRif = idRif;
/*    */   }
/*    */   
/*    */   public String getIdRif() {
/* 54 */     return this.idRif;
/*    */   }
/*    */   
/*    */   public void setTipoRif(String tipoRif) {
/* 58 */     this.tipoRif = tipoRif;
/*    */   }
/*    */   
/*    */   public String getTipoRif() {
/* 62 */     return this.tipoRif;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRazonSocial(String razonSocial) {
/* 67 */     this.razonSocial = razonSocial;
/*    */   }
/*    */   
/*    */   public String getRazonSocial() {
/* 71 */     return this.razonSocial;
/*    */   }
/*    */   
/*    */   public void setActividadComercial(String actividadComercial) {
/* 75 */     this.actividadComercial = actividadComercial;
/*    */   }
/*    */   
/*    */   public String getActividadComercial() {
/* 79 */     return this.actividadComercial;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\CuentaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */