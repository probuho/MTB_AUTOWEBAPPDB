/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AfiliarServicioTo
/*    */   implements Serializable
/*    */ {
/*    */   private ServicioTo servicio;
/*    */   private long numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   private PlanTo plan;
/*    */   private EquipoTo equipo;
/*    */   
/*    */   public ServicioTo getServicio() {
/* 23 */     return this.servicio;
/*    */   }
/*    */   
/*    */   public void setServicio(ServicioTo servicio) {
/* 27 */     this.servicio = servicio;
/*    */   }
/*    */   
/*    */   public long getNumeroCelular() {
/* 31 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(long numeroCelular) {
/* 35 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 39 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 43 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setPlan(PlanTo plan) {
/* 47 */     this.plan = plan;
/*    */   }
/*    */   
/*    */   public PlanTo getPlan() {
/* 51 */     return this.plan;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEquipo(EquipoTo equipo) {
/* 56 */     this.equipo = equipo;
/*    */   }
/*    */   
/*    */   public EquipoTo getEquipo() {
/* 60 */     return this.equipo;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\AfiliarServicioTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */