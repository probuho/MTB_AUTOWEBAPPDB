/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActivarEmpresarialEntradaTo
/*    */   implements Serializable
/*    */ {
/*    */   private ClienteTo cliente;
/*    */   private LineaTo linea;
/*    */   private EntradaTo entrada;
/*    */   private CuentaTo cuenta;
/*    */   private PersonaTo usuarioAutenticado;
/*    */   
/*    */   public ClienteTo getCliente() {
/* 23 */     return this.cliente;
/*    */   }
/*    */   
/*    */   public void setCliente(ClienteTo cliente) {
/* 27 */     this.cliente = cliente;
/*    */   }
/*    */   
/*    */   public LineaTo getLinea() {
/* 31 */     return this.linea;
/*    */   }
/*    */   
/*    */   public void setLinea(LineaTo linea) {
/* 35 */     this.linea = linea;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 39 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 43 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public CuentaTo getCuenta() {
/* 47 */     return this.cuenta;
/*    */   }
/*    */   
/*    */   public void setCuenta(CuentaTo cuenta) {
/* 51 */     this.cuenta = cuenta;
/*    */   }
/*    */   
/*    */   public void setUsuarioAutenticado(PersonaTo usuarioAutenticado) {
/* 55 */     this.usuarioAutenticado = usuarioAutenticado;
/*    */   }
/*    */   
/*    */   public PersonaTo getUsuarioAutenticado() {
/* 59 */     return this.usuarioAutenticado;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ActivarEmpresarialEntradaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */