/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CambiarPlanTextoTo
/*    */   implements Serializable
/*    */ {
/*    */   private String planTextoActual;
/*    */   private Long numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   private ServicioTo planTexto;
/*    */   
/*    */   public String getPlanTextoActual() {
/* 22 */     return this.planTextoActual;
/*    */   }
/*    */   
/*    */   public void setPlanTextoActual(String planTextoActual) {
/* 26 */     this.planTextoActual = planTextoActual;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 30 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 34 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 38 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 42 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public ServicioTo getPlanTexto() {
/* 46 */     return this.planTexto;
/*    */   }
/*    */   
/*    */   public void setPlanTexto(ServicioTo planTexto) {
/* 50 */     this.planTexto = planTexto;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\CambiarPlanTextoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */