/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AplicacionTo
/*    */   implements Serializable
/*    */ {
/*    */   private String nombre;
/*    */   private String codigo;
/*    */   private String tipoAplicacion;
/*    */   
/*    */   public String getNombre() {
/* 23 */     return this.nombre;
/*    */   }
/*    */   
/*    */   public void setNombre(String nombre) {
/* 27 */     this.nombre = nombre;
/*    */   }
/*    */   
/*    */   public String getCodigo() {
/* 31 */     return this.codigo;
/*    */   }
/*    */   
/*    */   public void setCodigo(String codigo) {
/* 35 */     this.codigo = codigo;
/*    */   }
/*    */   
/*    */   public String getTipoAplicacion() {
/* 39 */     return this.tipoAplicacion;
/*    */   }
/*    */   
/*    */   public void setTipoAplicacion(String tipoAplicacion) {
/* 43 */     this.tipoAplicacion = tipoAplicacion;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\AplicacionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */