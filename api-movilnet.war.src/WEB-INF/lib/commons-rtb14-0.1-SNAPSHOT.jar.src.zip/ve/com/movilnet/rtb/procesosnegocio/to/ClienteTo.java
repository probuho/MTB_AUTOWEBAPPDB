/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClienteTo
/*     */   implements Serializable
/*     */ {
/*     */   private String documentoId;
/*     */   private String tipoCliente;
/*     */   private DireccionTo direccion;
/*     */   private String extensionOficina;
/*     */   private String telefonoOficina;
/*     */   private String sexo;
/*     */   private String cargo;
/*     */   private Date fechaNacimiento;
/*     */   private String primerNombre;
/*     */   private String segundoApellido;
/*     */   private String titulo;
/*     */   private String correoElectronico;
/*     */   private Date fechaIngresoEmpresa;
/*     */   private String primerApellido;
/*     */   private String profesion;
/*     */   private String empresa;
/*     */   private String tipoDocumento;
/*     */   private String telefonoHabitacion;
/*     */   private String segundoNombre;
/*     */   private String nacionalidad;
/*     */   
/*     */   public String getDocumentoId() {
/*  41 */     return this.documentoId;
/*     */   }
/*     */   
/*     */   public void setDocumentoId(String documentoId) {
/*  45 */     this.documentoId = documentoId;
/*     */   }
/*     */   
/*     */   public String getTipoCliente() {
/*  49 */     return this.tipoCliente;
/*     */   }
/*     */   
/*     */   public void setTipoCliente(String tipoCliente) {
/*  53 */     this.tipoCliente = tipoCliente;
/*     */   }
/*     */   
/*     */   public DireccionTo getDireccion() {
/*  57 */     return this.direccion;
/*     */   }
/*     */   
/*     */   public void setDireccion(DireccionTo direccion) {
/*  61 */     this.direccion = direccion;
/*     */   }
/*     */   
/*     */   public String getExtensionOficina() {
/*  65 */     return this.extensionOficina;
/*     */   }
/*     */   
/*     */   public void setExtensionOficina(String extensionOficina) {
/*  69 */     this.extensionOficina = extensionOficina;
/*     */   }
/*     */   
/*     */   public String getTelefonoOficina() {
/*  73 */     return this.telefonoOficina;
/*     */   }
/*     */   
/*     */   public void setTelefonoOficina(String telefonoOficina) {
/*  77 */     this.telefonoOficina = telefonoOficina;
/*     */   }
/*     */   
/*     */   public String getSexo() {
/*  81 */     return this.sexo;
/*     */   }
/*     */   
/*     */   public void setSexo(String sexo) {
/*  85 */     this.sexo = sexo;
/*     */   }
/*     */   
/*     */   public String getCargo() {
/*  89 */     return this.cargo;
/*     */   }
/*     */   
/*     */   public void setCargo(String cargo) {
/*  93 */     this.cargo = cargo;
/*     */   }
/*     */   
/*     */   public Date getFechaNacimiento() {
/*  97 */     return this.fechaNacimiento;
/*     */   }
/*     */   
/*     */   public void setFechaNacimiento(Date fechaNacimiento) {
/* 101 */     this.fechaNacimiento = fechaNacimiento;
/*     */   }
/*     */   
/*     */   public String getPrimerNombre() {
/* 105 */     return this.primerNombre;
/*     */   }
/*     */   
/*     */   public void setPrimerNombre(String primerNombre) {
/* 109 */     this.primerNombre = primerNombre;
/*     */   }
/*     */   
/*     */   public String getSegundoApellido() {
/* 113 */     return this.segundoApellido;
/*     */   }
/*     */   
/*     */   public void setSegundoApellido(String segundoApellido) {
/* 117 */     this.segundoApellido = segundoApellido;
/*     */   }
/*     */   
/*     */   public String getTitulo() {
/* 121 */     return this.titulo;
/*     */   }
/*     */   
/*     */   public void setTitulo(String titulo) {
/* 125 */     this.titulo = titulo;
/*     */   }
/*     */   
/*     */   public String getCorreoElectronico() {
/* 129 */     return this.correoElectronico;
/*     */   }
/*     */   
/*     */   public void setCorreoElectronico(String correoElectronico) {
/* 133 */     this.correoElectronico = correoElectronico;
/*     */   }
/*     */ 
/*     */   
/*     */   public Date getFechaIngresoEmpresa() {
/* 138 */     return this.fechaIngresoEmpresa;
/*     */   }
/*     */   
/*     */   public void setFechaIngresoEmpresa(Date fechaIngresoEmpresa) {
/* 142 */     this.fechaIngresoEmpresa = fechaIngresoEmpresa;
/*     */   }
/*     */   
/*     */   public String getPrimerApellido() {
/* 146 */     return this.primerApellido;
/*     */   }
/*     */   
/*     */   public void setPrimerApellido(String primerApellido) {
/* 150 */     this.primerApellido = primerApellido;
/*     */   }
/*     */   
/*     */   public String getProfesion() {
/* 154 */     return this.profesion;
/*     */   }
/*     */   
/*     */   public void setProfesion(String profesion) {
/* 158 */     this.profesion = profesion;
/*     */   }
/*     */   
/*     */   public String getEmpresa() {
/* 162 */     return this.empresa;
/*     */   }
/*     */   
/*     */   public void setEmpresa(String empresa) {
/* 166 */     this.empresa = empresa;
/*     */   }
/*     */   
/*     */   public String getTipoDocumento() {
/* 170 */     return this.tipoDocumento;
/*     */   }
/*     */   
/*     */   public void setTipoDocumento(String tipoDocumento) {
/* 174 */     this.tipoDocumento = tipoDocumento;
/*     */   }
/*     */   
/*     */   public String getTelefonoHabitacion() {
/* 178 */     return this.telefonoHabitacion;
/*     */   }
/*     */   
/*     */   public void setTelefonoHabitacion(String telefonoHabitacion) {
/* 182 */     this.telefonoHabitacion = telefonoHabitacion;
/*     */   }
/*     */   
/*     */   public String getSegundoNombre() {
/* 186 */     return this.segundoNombre;
/*     */   }
/*     */   
/*     */   public void setSegundoNombre(String segundoNombre) {
/* 190 */     this.segundoNombre = segundoNombre;
/*     */   }
/*     */   
/*     */   public String getNacionalidad() {
/* 194 */     return this.nacionalidad;
/*     */   }
/*     */   
/*     */   public void setNacionalidad(String nacionalidad) {
/* 198 */     this.nacionalidad = nacionalidad;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ClienteTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */