/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DireccionTo
/*     */   implements Serializable
/*     */ {
/*     */   private String sector;
/*     */   private String tipoCalle;
/*     */   private String ciudad;
/*     */   private String nombreCalle;
/*     */   private String parroquiaUrbanizacion;
/*     */   private String tipoPiso;
/*     */   private String identificadorEdificacion;
/*     */   private String estado;
/*     */   private String identificadorPiso;
/*     */   private String municipio;
/*     */   private String zonaPostal;
/*     */   private String idApartamento;
/*     */   private String tipoEdificacion;
/*     */   private String tipoApartamento;
/*     */   private String puntoReferencia;
/*     */   
/*     */   public String getSector() {
/*  33 */     return this.sector;
/*     */   }
/*     */   
/*     */   public void setSector(String sector) {
/*  37 */     this.sector = sector;
/*     */   }
/*     */   
/*     */   public String getTipoCalle() {
/*  41 */     return this.tipoCalle;
/*     */   }
/*     */   
/*     */   public void setTipoCalle(String tipoCalle) {
/*  45 */     this.tipoCalle = tipoCalle;
/*     */   }
/*     */   
/*     */   public String getCiudad() {
/*  49 */     return this.ciudad;
/*     */   }
/*     */   
/*     */   public void setCiudad(String ciudad) {
/*  53 */     this.ciudad = ciudad;
/*     */   }
/*     */   
/*     */   public String getNombreCalle() {
/*  57 */     return this.nombreCalle;
/*     */   }
/*     */   
/*     */   public void setNombreCalle(String nombreCalle) {
/*  61 */     this.nombreCalle = nombreCalle;
/*     */   }
/*     */   
/*     */   public String getParroquiaUrbanizacion() {
/*  65 */     return this.parroquiaUrbanizacion;
/*     */   }
/*     */   
/*     */   public void setParroquiaUrbanizacion(String parroquiaUrbanizacion) {
/*  69 */     this.parroquiaUrbanizacion = parroquiaUrbanizacion;
/*     */   }
/*     */   
/*     */   public String getTipoPiso() {
/*  73 */     return this.tipoPiso;
/*     */   }
/*     */   
/*     */   public void setTipoPiso(String tipoPiso) {
/*  77 */     this.tipoPiso = tipoPiso;
/*     */   }
/*     */   
/*     */   public String getIdentificadorEdificacion() {
/*  81 */     return this.identificadorEdificacion;
/*     */   }
/*     */   
/*     */   public void setIdentificadorEdificacion(String identificadorEdificacion) {
/*  85 */     this.identificadorEdificacion = identificadorEdificacion;
/*     */   }
/*     */   
/*     */   public String getEstado() {
/*  89 */     return this.estado;
/*     */   }
/*     */   
/*     */   public void setEstado(String estado) {
/*  93 */     this.estado = estado;
/*     */   }
/*     */   
/*     */   public String getIdentificadorPiso() {
/*  97 */     return this.identificadorPiso;
/*     */   }
/*     */   
/*     */   public void setIdentificadorPiso(String identificadorPiso) {
/* 101 */     this.identificadorPiso = identificadorPiso;
/*     */   }
/*     */   
/*     */   public String getMunicipio() {
/* 105 */     return this.municipio;
/*     */   }
/*     */   
/*     */   public void setMunicipio(String municipio) {
/* 109 */     this.municipio = municipio;
/*     */   }
/*     */   
/*     */   public String getZonaPostal() {
/* 113 */     return this.zonaPostal;
/*     */   }
/*     */   
/*     */   public void setZonaPostal(String zonaPostal) {
/* 117 */     this.zonaPostal = zonaPostal;
/*     */   }
/*     */   
/*     */   public String getIdApartamento() {
/* 121 */     return this.idApartamento;
/*     */   }
/*     */   
/*     */   public void setIdApartamento(String idApartamento) {
/* 125 */     this.idApartamento = idApartamento;
/*     */   }
/*     */   
/*     */   public String getTipoEdificacion() {
/* 129 */     return this.tipoEdificacion;
/*     */   }
/*     */   
/*     */   public void setTipoEdificacion(String tipoEdificacion) {
/* 133 */     this.tipoEdificacion = tipoEdificacion;
/*     */   }
/*     */   
/*     */   public String getTipoApartamento() {
/* 137 */     return this.tipoApartamento;
/*     */   }
/*     */   
/*     */   public void setTipoApartamento(String tipoApartamento) {
/* 141 */     this.tipoApartamento = tipoApartamento;
/*     */   }
/*     */   
/*     */   public String getPuntoReferencia() {
/* 145 */     return this.puntoReferencia;
/*     */   }
/*     */   
/*     */   public void setPuntoReferencia(String puntoReferencia) {
/* 149 */     this.puntoReferencia = puntoReferencia;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\DireccionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */