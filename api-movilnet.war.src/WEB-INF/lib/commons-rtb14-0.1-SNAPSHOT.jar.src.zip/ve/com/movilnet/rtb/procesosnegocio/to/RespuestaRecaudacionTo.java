/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RespuestaRecaudacionTo
/*    */   implements Serializable
/*    */ {
/*    */   private Double saldoActual;
/*    */   private Double saldoAnterior;
/*    */   private String numeroAprobacion;
/*    */   private Date fechaAprobacion;
/*    */   
/*    */   public Double getSaldoActual() {
/* 24 */     return this.saldoActual;
/*    */   }
/*    */   
/*    */   public void setSaldoActual(Double saldoActual) {
/* 28 */     this.saldoActual = saldoActual;
/*    */   }
/*    */   
/*    */   public Double getSaldoAnterior() {
/* 32 */     return this.saldoAnterior;
/*    */   }
/*    */   
/*    */   public void setSaldoAnterior(Double saldoAnterior) {
/* 36 */     this.saldoAnterior = saldoAnterior;
/*    */   }
/*    */   
/*    */   public String getNumeroAprobacion() {
/* 40 */     return this.numeroAprobacion;
/*    */   }
/*    */   
/*    */   public void setNumeroAprobacion(String numeroAprobacion) {
/* 44 */     this.numeroAprobacion = numeroAprobacion;
/*    */   }
/*    */   
/*    */   public Date getFechaAprobacion() {
/* 48 */     return this.fechaAprobacion;
/*    */   }
/*    */   
/*    */   public void setFechaAprobacion(Date fechaAprobacion) {
/* 52 */     this.fechaAprobacion = fechaAprobacion;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\RespuestaRecaudacionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */