/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FacturacionPrepagoTo
/*    */   implements Serializable
/*    */ {
/*    */   private List servicios;
/*    */   private int balanceMinSeg;
/*    */   private Date fechaExpiracion;
/*    */   private Double balanceMensaje;
/*    */   private Double balanceVoz;
/*    */   
/*    */   public List getServicios() {
/* 26 */     return this.servicios;
/*    */   }
/*    */   
/*    */   public void setServicios(List servicios) {
/* 30 */     this.servicios = servicios;
/*    */   }
/*    */   
/*    */   public int getBalanceMinSeg() {
/* 34 */     return this.balanceMinSeg;
/*    */   }
/*    */   
/*    */   public void setBalanceMinSeg(int balanceMinSeg) {
/* 38 */     this.balanceMinSeg = balanceMinSeg;
/*    */   }
/*    */   
/*    */   public Double getBalanceMensaje() {
/* 42 */     return this.balanceMensaje;
/*    */   }
/*    */   
/*    */   public void setBalanceMensaje(Double balanceMensaje) {
/* 46 */     this.balanceMensaje = balanceMensaje;
/*    */   }
/*    */   
/*    */   public Double getBalanceVoz() {
/* 50 */     return this.balanceVoz;
/*    */   }
/*    */   
/*    */   public void setBalanceVoz(Double balanceVoz) {
/* 54 */     this.balanceVoz = balanceVoz;
/*    */   }
/*    */   
/*    */   public Date getFechaExpiracion() {
/* 58 */     return this.fechaExpiracion;
/*    */   }
/*    */   
/*    */   public void setFechaExpiracion(Date fechaExpiracion) {
/* 62 */     this.fechaExpiracion = fechaExpiracion;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\FacturacionPrepagoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */