/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CambiarSerialSimcardTo
/*    */   implements Serializable
/*    */ {
/*    */   private ImeiSimcardTo imeiSimCardNuevo;
/*    */   private LineaTo linea;
/*    */   private EntradaTo entrada;
/*    */   
/*    */   public ImeiSimcardTo getImeiSimCardNuevo() {
/* 23 */     return this.imeiSimCardNuevo;
/*    */   }
/*    */   
/*    */   public void setImeiSimCardNuevo(ImeiSimcardTo imeiSimCardNuevo) {
/* 27 */     this.imeiSimCardNuevo = imeiSimCardNuevo;
/*    */   }
/*    */   
/*    */   public LineaTo getLinea() {
/* 31 */     return this.linea;
/*    */   }
/*    */   
/*    */   public void setLinea(LineaTo linea) {
/* 35 */     this.linea = linea;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 39 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 43 */     this.entrada = entrada;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\CambiarSerialSimcardTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */