/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReversoPinTo
/*    */   implements Serializable
/*    */ {
/*    */   private PinTo pin;
/*    */   private Long numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   
/*    */   public PinTo getPin() {
/* 21 */     return this.pin;
/*    */   }
/*    */   
/*    */   public void setPin(PinTo pin) {
/* 25 */     this.pin = pin;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 29 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 33 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 37 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 41 */     this.entrada = entrada;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ReversoPinTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */