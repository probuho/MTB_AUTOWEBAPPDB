/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaldoTo
/*    */ {
/*    */   private String codigoBalance;
/*    */   private String descripcionBalance;
/*    */   private Date fechaExpiracion;
/*    */   private Double montoBalance;
/*    */   private String unidadBalance;
/*    */   private String factorConversion;
/*    */   private Double balanceDisponible;
/*    */   
/*    */   public String getCodigoBalance() {
/* 46 */     return this.codigoBalance;
/*    */   }
/*    */   
/*    */   public void setCodigoBalance(String codigoBalance) {
/* 50 */     this.codigoBalance = codigoBalance;
/*    */   }
/*    */   
/*    */   public String getDescripcionBalance() {
/* 54 */     return this.descripcionBalance;
/*    */   }
/*    */   
/*    */   public void setDescripcionBalance(String descripcionBalance) {
/* 58 */     this.descripcionBalance = descripcionBalance;
/*    */   }
/*    */   
/*    */   public Date getFechaExpiracion() {
/* 62 */     return this.fechaExpiracion;
/*    */   }
/*    */   
/*    */   public void setFechaExpiracion(Date fechaExpiracion) {
/* 66 */     this.fechaExpiracion = fechaExpiracion;
/*    */   }
/*    */   
/*    */   public Double getMontoBalance() {
/* 70 */     return this.montoBalance;
/*    */   }
/*    */   
/*    */   public void setMontoBalance(Double montoBalance) {
/* 74 */     this.montoBalance = montoBalance;
/*    */   }
/*    */   
/*    */   public String getUnidadBalance() {
/* 78 */     return this.unidadBalance;
/*    */   }
/*    */   
/*    */   public void setUnidadBalance(String unidadBalance) {
/* 82 */     this.unidadBalance = unidadBalance;
/*    */   }
/*    */   
/*    */   public String getFactorConversion() {
/* 86 */     return this.factorConversion;
/*    */   }
/*    */   
/*    */   public void setFactorConversion(String factorConversion) {
/* 90 */     this.factorConversion = factorConversion;
/*    */   }
/*    */   
/*    */   public void setBalanceDisponible(Double balanceDisponible) {
/* 94 */     this.balanceDisponible = balanceDisponible;
/*    */   }
/*    */   
/*    */   public Double getBalanceDisponible() {
/* 98 */     return this.balanceDisponible;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\SaldoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */