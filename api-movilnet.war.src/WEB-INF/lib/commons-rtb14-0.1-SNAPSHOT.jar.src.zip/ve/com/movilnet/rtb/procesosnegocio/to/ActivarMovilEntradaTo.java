/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActivarMovilEntradaTo
/*    */   implements Serializable
/*    */ {
/*    */   private ClienteTo cliente;
/*    */   private PlanConsejoComunalTo planConsejoComunal;
/*    */   private LineaTo linea;
/*    */   private EntradaTo entrada;
/*    */   private PersonaTo usuarioAutenticado;
/*    */   
/*    */   public ClienteTo getCliente() {
/* 23 */     return this.cliente;
/*    */   }
/*    */   
/*    */   public void setCliente(ClienteTo cliente) {
/* 27 */     this.cliente = cliente;
/*    */   }
/*    */   
/*    */   public PlanConsejoComunalTo getPlanConsejoComunal() {
/* 31 */     return this.planConsejoComunal;
/*    */   }
/*    */   
/*    */   public void setPlanConsejoComunal(PlanConsejoComunalTo planConsejoComunal) {
/* 35 */     this.planConsejoComunal = planConsejoComunal;
/*    */   }
/*    */   
/*    */   public LineaTo getLinea() {
/* 39 */     return this.linea;
/*    */   }
/*    */   
/*    */   public void setLinea(LineaTo linea) {
/* 43 */     this.linea = linea;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 47 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 51 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public void setUsuarioAutenticado(PersonaTo usuarioAutenticado) {
/* 55 */     this.usuarioAutenticado = usuarioAutenticado;
/*    */   }
/*    */   
/*    */   public PersonaTo getUsuarioAutenticado() {
/* 59 */     return this.usuarioAutenticado;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ActivarMovilEntradaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */