/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CargoTarifaMensajeTo
/*    */   implements Serializable
/*    */ {
/*    */   private String idCargoMensaje;
/*    */   private Date fechaCargoMensaje;
/*    */   private Double montoCargosMensaje;
/*    */   private String descripcionCargoMensaje;
/*    */   
/*    */   public String getIdCargoMensaje() {
/* 40 */     return this.idCargoMensaje;
/*    */   }
/*    */   
/*    */   public void setIdCargoMensaje(String idCargoMensaje) {
/* 44 */     this.idCargoMensaje = idCargoMensaje;
/*    */   }
/*    */   
/*    */   public Date getFechaCargoMensaje() {
/* 48 */     return this.fechaCargoMensaje;
/*    */   }
/*    */   
/*    */   public void setFechaCargoMensaje(Date fechaCargoMensaje) {
/* 52 */     this.fechaCargoMensaje = fechaCargoMensaje;
/*    */   }
/*    */   
/*    */   public Double getMontoCargosMensaje() {
/* 56 */     return this.montoCargosMensaje;
/*    */   }
/*    */   
/*    */   public void setMontoCargosMensaje(Double montoCargosMensaje) {
/* 60 */     this.montoCargosMensaje = montoCargosMensaje;
/*    */   }
/*    */   
/*    */   public String getDescripcionCargoMensaje() {
/* 64 */     return this.descripcionCargoMensaje;
/*    */   }
/*    */   
/*    */   public void setDescripcionCargoMensaje(String descripcionCargoMensaje) {
/* 68 */     this.descripcionCargoMensaje = descripcionCargoMensaje;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\CargoTarifaMensajeTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */