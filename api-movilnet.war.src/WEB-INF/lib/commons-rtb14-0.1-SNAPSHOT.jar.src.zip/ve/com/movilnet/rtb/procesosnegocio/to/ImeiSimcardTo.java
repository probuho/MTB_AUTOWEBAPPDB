/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImeiSimcardTo
/*    */   implements Serializable
/*    */ {
/*    */   private EquipoTo equipo;
/*    */   private String serialElectronico;
/*    */   private String simCard;
/*    */   
/*    */   public EquipoTo getEquipo() {
/* 21 */     return this.equipo;
/*    */   }
/*    */   
/*    */   public void setEquipo(EquipoTo equipo) {
/* 25 */     this.equipo = equipo;
/*    */   }
/*    */   
/*    */   public String getSerialElectronico() {
/* 29 */     return this.serialElectronico;
/*    */   }
/*    */   
/*    */   public void setSerialElectronico(String serialElectronico) {
/* 33 */     this.serialElectronico = serialElectronico;
/*    */   }
/*    */   
/*    */   public String getSimCard() {
/* 37 */     return this.simCard;
/*    */   }
/*    */   
/*    */   public void setSimCard(String simCard) {
/* 41 */     this.simCard = simCard;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ImeiSimcardTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */