/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MovimientoTo
/*    */   implements Serializable
/*    */ {
/*    */   private List llamadas;
/*    */   private List cargosAjustes;
/*    */   private List pagos;
/*    */   private List smsDescargas;
/*    */   
/*    */   public List getLlamadas() {
/* 38 */     return this.llamadas;
/*    */   }
/*    */   
/*    */   public void setLlamadas(List llamadas) {
/* 42 */     this.llamadas = llamadas;
/*    */   }
/*    */   
/*    */   public List getCargosAjustes() {
/* 46 */     return this.cargosAjustes;
/*    */   }
/*    */   
/*    */   public void setCargosAjustes(List cargosAjustes) {
/* 50 */     this.cargosAjustes = cargosAjustes;
/*    */   }
/*    */   
/*    */   public List getPagos() {
/* 54 */     return this.pagos;
/*    */   }
/*    */   
/*    */   public void setPagos(List pagos) {
/* 58 */     this.pagos = pagos;
/*    */   }
/*    */   
/*    */   public List getSmsDescargas() {
/* 62 */     return this.smsDescargas;
/*    */   }
/*    */   
/*    */   public void setSmsDescargas(List smsDescargas) {
/* 66 */     this.smsDescargas = smsDescargas;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\MovimientoTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */