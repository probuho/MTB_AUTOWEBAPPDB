/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuscarTelefonoRespuestaTo
/*    */   implements Serializable
/*    */ {
/*    */   private List servicios;
/*    */   private ClienteTo cliente;
/*    */   private LineaTo linea;
/*    */   private String segmento;
/*    */   private CuentaTo cuenta;
/*    */   private PlanTo planTexto;
/*    */   private String codigoRazon;
/*    */   
/*    */   public List getServicios() {
/* 27 */     return this.servicios;
/*    */   }
/*    */   
/*    */   public void setServicios(List servicios) {
/* 31 */     this.servicios = servicios;
/*    */   }
/*    */   
/*    */   public ClienteTo getCliente() {
/* 35 */     return this.cliente;
/*    */   }
/*    */   
/*    */   public void setCliente(ClienteTo cliente) {
/* 39 */     this.cliente = cliente;
/*    */   }
/*    */   
/*    */   public LineaTo getLinea() {
/* 43 */     return this.linea;
/*    */   }
/*    */   
/*    */   public void setLinea(LineaTo linea) {
/* 47 */     this.linea = linea;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSegmento(String segmento) {
/* 52 */     this.segmento = segmento;
/*    */   }
/*    */   
/*    */   public String getSegmento() {
/* 56 */     return this.segmento;
/*    */   }
/*    */   
/*    */   public void setCuenta(CuentaTo cuenta) {
/* 60 */     this.cuenta = cuenta;
/*    */   }
/*    */   
/*    */   public CuentaTo getCuenta() {
/* 64 */     return this.cuenta;
/*    */   }
/*    */   
/*    */   public void setPlanTexto(PlanTo planTexto) {
/* 68 */     this.planTexto = planTexto;
/*    */   }
/*    */   
/*    */   public PlanTo getPlanTexto() {
/* 72 */     return this.planTexto;
/*    */   }
/*    */   
/*    */   public void setCodigoRazon(String codigoRazon) {
/* 76 */     this.codigoRazon = codigoRazon;
/*    */   }
/*    */   
/*    */   public String getCodigoRazon() {
/* 80 */     return this.codigoRazon;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\BuscarTelefonoRespuestaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */