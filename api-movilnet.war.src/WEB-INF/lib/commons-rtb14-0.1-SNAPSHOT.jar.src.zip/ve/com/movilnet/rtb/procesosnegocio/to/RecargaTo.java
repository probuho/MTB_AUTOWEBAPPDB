/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecargaTo
/*    */   implements Serializable
/*    */ {
/*    */   private String codigoSecreto;
/*    */   private String codigoDeBarra;
/*    */   
/*    */   public String getCodigoSecreto() {
/* 20 */     return this.codigoSecreto;
/*    */   }
/*    */   
/*    */   public void setCodigoSecreto(String codigoSecreto) {
/* 24 */     this.codigoSecreto = codigoSecreto;
/*    */   }
/*    */   
/*    */   public String getCodigoDeBarra() {
/* 28 */     return this.codigoDeBarra;
/*    */   }
/*    */   
/*    */   public void setCodigoDeBarra(String codigoDeBarra) {
/* 32 */     this.codigoDeBarra = codigoDeBarra;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\RecargaTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */