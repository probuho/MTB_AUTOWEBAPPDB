/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServicioTo
/*     */   implements Serializable
/*     */ {
/*     */   private String nombreCargoMensual;
/*     */   private String descripcion;
/*     */   private String idServicio;
/*     */   private Date fechaFinServicio;
/*     */   private int minimoLineasAfiliadas;
/*     */   private Date fechaActivacion;
/*     */   private Date fechaInicioServicio;
/*     */   private String tipoServicio;
/*     */   private Date fechaEstatus;
/*     */   private String indicadorCargoMensual;
/*     */   private String indicadorProvisioning;
/*     */   private int maximoLineasAfiliadas;
/*     */   private Double montoServicio;
/*     */   private String estatus;
/*     */   private String grupo;
/*     */   private String subGrupo;
/*     */   private String subTipo;
/*     */   private String codigoServicio;
/*     */   private String etiqueta;
/*     */   private String comando;
/*     */   
/*     */   public Date getFechaFinServicio() {
/*  37 */     return this.fechaFinServicio;
/*     */   }
/*     */   
/*     */   public void setFechaFinServicio(Date fechaFinServicio) {
/*  41 */     this.fechaFinServicio = fechaFinServicio;
/*     */   }
/*     */   
/*     */   public Date getFechaActivacion() {
/*  45 */     return this.fechaActivacion;
/*     */   }
/*     */   
/*     */   public void setFechaActivacion(Date fechaActivacion) {
/*  49 */     this.fechaActivacion = fechaActivacion;
/*     */   }
/*     */   
/*     */   public Date getFechaInicioServicio() {
/*  53 */     return this.fechaInicioServicio;
/*     */   }
/*     */   
/*     */   public void setFechaInicioServicio(Date fechaInicioServicio) {
/*  57 */     this.fechaInicioServicio = fechaInicioServicio;
/*     */   }
/*     */   
/*     */   public Date getFechaEstatus() {
/*  61 */     return this.fechaEstatus;
/*     */   }
/*     */   
/*     */   public void setFechaEstatus(Date fechaEstatus) {
/*  65 */     this.fechaEstatus = fechaEstatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNombreCargoMensual() {
/*  72 */     return this.nombreCargoMensual;
/*     */   }
/*     */   
/*     */   public void setNombreCargoMensual(String nombreCargoMensual) {
/*  76 */     this.nombreCargoMensual = nombreCargoMensual;
/*     */   }
/*     */   
/*     */   public String getDescripcion() {
/*  80 */     return this.descripcion;
/*     */   }
/*     */   
/*     */   public void setDescripcion(String descripcion) {
/*  84 */     this.descripcion = descripcion;
/*     */   }
/*     */   
/*     */   public String getIdServicio() {
/*  88 */     return this.idServicio;
/*     */   }
/*     */   
/*     */   public void setIdServicio(String idServicio) {
/*  92 */     this.idServicio = idServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimoLineasAfiliadas() {
/*  98 */     return this.minimoLineasAfiliadas;
/*     */   }
/*     */   
/*     */   public void setMinimoLineasAfiliadas(int minimoLineasAfiliadas) {
/* 102 */     this.minimoLineasAfiliadas = minimoLineasAfiliadas;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoServicio() {
/* 108 */     return this.tipoServicio;
/*     */   }
/*     */   
/*     */   public void setTipoServicio(String tipoServicio) {
/* 112 */     this.tipoServicio = tipoServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndicadorCargoMensual() {
/* 118 */     return this.indicadorCargoMensual;
/*     */   }
/*     */   
/*     */   public void setIndicadorCargoMensual(String indicadorCargoMensual) {
/* 122 */     this.indicadorCargoMensual = indicadorCargoMensual;
/*     */   }
/*     */   
/*     */   public String getIndicadorProvisioning() {
/* 126 */     return this.indicadorProvisioning;
/*     */   }
/*     */   
/*     */   public void setIndicadorProvisioning(String indicadorProvisioning) {
/* 130 */     this.indicadorProvisioning = indicadorProvisioning;
/*     */   }
/*     */   
/*     */   public int getMaximoLineasAfiliadas() {
/* 134 */     return this.maximoLineasAfiliadas;
/*     */   }
/*     */   
/*     */   public void setMaximoLineasAfiliadas(int maximoLineasAfiliadas) {
/* 138 */     this.maximoLineasAfiliadas = maximoLineasAfiliadas;
/*     */   }
/*     */   
/*     */   public Double getMontoServicio() {
/* 142 */     return this.montoServicio;
/*     */   }
/*     */   
/*     */   public void setMontoServicio(Double montoServicio) {
/* 146 */     this.montoServicio = montoServicio;
/*     */   }
/*     */   
/*     */   public String getEstatus() {
/* 150 */     return this.estatus;
/*     */   }
/*     */   
/*     */   public void setEstatus(String estatus) {
/* 154 */     this.estatus = estatus;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGrupo(String grupo) {
/* 159 */     this.grupo = grupo;
/*     */   }
/*     */   
/*     */   public String getGrupo() {
/* 163 */     return this.grupo;
/*     */   }
/*     */   
/*     */   public void setSubTipo(String subTipo) {
/* 167 */     this.subTipo = subTipo;
/*     */   }
/*     */   
/*     */   public String getSubTipo() {
/* 171 */     return this.subTipo;
/*     */   }
/*     */   
/*     */   public void setCodigoServicio(String codigoServicio) {
/* 175 */     this.codigoServicio = codigoServicio;
/*     */   }
/*     */   
/*     */   public String getCodigoServicio() {
/* 179 */     return this.codigoServicio;
/*     */   }
/*     */   
/*     */   public void setEtiqueta(String etiqueta) {
/* 183 */     this.etiqueta = etiqueta;
/*     */   }
/*     */   
/*     */   public String getEtiqueta() {
/* 187 */     return this.etiqueta;
/*     */   }
/*     */   
/*     */   public void setComando(String comando) {
/* 191 */     this.comando = comando;
/*     */   }
/*     */   
/*     */   public String getComando() {
/* 195 */     return this.comando;
/*     */   }
/*     */   
/*     */   public void setSubGrupo(String subGrupo) {
/* 199 */     this.subGrupo = subGrupo;
/*     */   }
/*     */   
/*     */   public String getSubGrupo() {
/* 203 */     return this.subGrupo;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ServicioTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */