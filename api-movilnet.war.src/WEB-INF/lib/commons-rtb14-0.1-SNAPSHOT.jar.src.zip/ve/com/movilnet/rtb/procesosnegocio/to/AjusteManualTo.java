/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AjusteManualTo
/*    */   implements Serializable
/*    */ {
/*    */   private Long numeroCelular;
/*    */   private EntradaTo entrada;
/*    */   private AjusteTo ajuste;
/*    */   
/*    */   public Long getNumeroCelular() {
/* 21 */     return this.numeroCelular;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 25 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 29 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 33 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public AjusteTo getAjuste() {
/* 37 */     return this.ajuste;
/*    */   }
/*    */   
/*    */   public void setAjuste(AjusteTo ajuste) {
/* 41 */     this.ajuste = ajuste;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\AjusteManualTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */