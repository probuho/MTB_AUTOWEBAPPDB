/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactivacionTo
/*    */   implements Serializable
/*    */ {
/*    */   private Long numeroCelular;
/*    */   private LineaTo linea;
/*    */   private EntradaTo entrada;
/*    */   private String razon;
/*    */   
/*    */   public LineaTo getLinea() {
/* 22 */     return this.linea;
/*    */   }
/*    */   
/*    */   public void setLinea(LineaTo linea) {
/* 26 */     this.linea = linea;
/*    */   }
/*    */   
/*    */   public EntradaTo getEntrada() {
/* 30 */     return this.entrada;
/*    */   }
/*    */   
/*    */   public void setEntrada(EntradaTo entrada) {
/* 34 */     this.entrada = entrada;
/*    */   }
/*    */   
/*    */   public void setRazon(String razon) {
/* 38 */     this.razon = razon;
/*    */   }
/*    */   
/*    */   public String getRazon() {
/* 42 */     return this.razon;
/*    */   }
/*    */   
/*    */   public void setNumeroCelular(Long numeroCelular) {
/* 46 */     this.numeroCelular = numeroCelular;
/*    */   }
/*    */   
/*    */   public Long getNumeroCelular() {
/* 50 */     return this.numeroCelular;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\ReactivacionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */