/*    */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AfiliarServicioElement
/*    */   implements Serializable
/*    */ {
/*    */   private String transaccionId;
/*    */   private AfiliarServicioTo afiliarServicio;
/*    */   
/*    */   public String getTransaccionId() {
/* 20 */     return this.transaccionId;
/*    */   }
/*    */   
/*    */   public void setTransaccionId(String transaccionId) {
/* 24 */     this.transaccionId = transaccionId;
/*    */   }
/*    */   
/*    */   public AfiliarServicioTo getAfiliarServicio() {
/* 28 */     return this.afiliarServicio;
/*    */   }
/*    */   
/*    */   public void setAfiliarServicio(AfiliarServicioTo afiliarServicio) {
/* 32 */     this.afiliarServicio = afiliarServicio;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\AfiliarServicioElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */