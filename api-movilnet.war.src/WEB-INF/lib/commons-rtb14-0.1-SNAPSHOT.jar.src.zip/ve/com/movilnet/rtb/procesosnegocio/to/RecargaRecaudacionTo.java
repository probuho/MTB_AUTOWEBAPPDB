/*     */ package ve.com.movilnet.rtb.procesosnegocio.to;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecargaRecaudacionTo
/*     */   implements Serializable
/*     */ {
/*     */   private String idTerminal;
/*     */   private String modalidadRecarga;
/*     */   private String codigoOrigen;
/*     */   private String tipoOrigen;
/*     */   private String tipoPago;
/*     */   private String lote;
/*     */   private int secuencia;
/*     */   private String clasificacion;
/*     */   private String codigoComercio;
/*     */   private String numeroReferencia;
/*     */   private Date fechaTransaccionGateway;
/*     */   private Date fechaTransaccionCTC;
/*     */   private Long direccionIp;
/*     */   private Double monto;
/*     */   
/*     */   public String getIdTerminal() {
/*  34 */     return this.idTerminal;
/*     */   }
/*     */   
/*     */   public void setIdTerminal(String idTerminal) {
/*  38 */     this.idTerminal = idTerminal;
/*     */   }
/*     */   
/*     */   public String getModalidadRecarga() {
/*  42 */     return this.modalidadRecarga;
/*     */   }
/*     */   
/*     */   public void setModalidadRecarga(String modalidadRecarga) {
/*  46 */     this.modalidadRecarga = modalidadRecarga;
/*     */   }
/*     */   
/*     */   public String getCodigoOrigen() {
/*  50 */     return this.codigoOrigen;
/*     */   }
/*     */   
/*     */   public void setCodigoOrigen(String codigoOrigen) {
/*  54 */     this.codigoOrigen = codigoOrigen;
/*     */   }
/*     */   
/*     */   public String getTipoOrigen() {
/*  58 */     return this.tipoOrigen;
/*     */   }
/*     */   
/*     */   public void setTipoOrigen(String tipoOrigen) {
/*  62 */     this.tipoOrigen = tipoOrigen;
/*     */   }
/*     */   
/*     */   public String getTipoPago() {
/*  66 */     return this.tipoPago;
/*     */   }
/*     */   
/*     */   public void setTipoPago(String tipoPago) {
/*  70 */     this.tipoPago = tipoPago;
/*     */   }
/*     */   
/*     */   public String getLote() {
/*  74 */     return this.lote;
/*     */   }
/*     */   
/*     */   public void setLote(String lote) {
/*  78 */     this.lote = lote;
/*     */   }
/*     */   
/*     */   public int getSecuencia() {
/*  82 */     return this.secuencia;
/*     */   }
/*     */   
/*     */   public void setSecuencia(int secuencia) {
/*  86 */     this.secuencia = secuencia;
/*     */   }
/*     */   
/*     */   public String getClasificacion() {
/*  90 */     return this.clasificacion;
/*     */   }
/*     */   
/*     */   public void setClasificacion(String clasificacion) {
/*  94 */     this.clasificacion = clasificacion;
/*     */   }
/*     */   
/*     */   public String getCodigoComercio() {
/*  98 */     return this.codigoComercio;
/*     */   }
/*     */   
/*     */   public void setCodigoComercio(String codigoComercio) {
/* 102 */     this.codigoComercio = codigoComercio;
/*     */   }
/*     */   
/*     */   public String getNumeroReferencia() {
/* 106 */     return this.numeroReferencia;
/*     */   }
/*     */   
/*     */   public void setNumeroReferencia(String numeroReferencia) {
/* 110 */     this.numeroReferencia = numeroReferencia;
/*     */   }
/*     */   
/*     */   public Long getDireccionIp() {
/* 114 */     return this.direccionIp;
/*     */   }
/*     */   
/*     */   public void setDireccionIp(Long direccionIp) {
/* 118 */     this.direccionIp = direccionIp;
/*     */   }
/*     */   
/*     */   public Double getMonto() {
/* 122 */     return this.monto;
/*     */   }
/*     */   
/*     */   public void setMonto(Double monto) {
/* 126 */     this.monto = monto;
/*     */   }
/*     */   
/*     */   public Date getFechaTransaccionGateway() {
/* 130 */     return this.fechaTransaccionGateway;
/*     */   }
/*     */   
/*     */   public void setFechaTransaccionGateway(Date fechaTransaccionGateway) {
/* 134 */     this.fechaTransaccionGateway = fechaTransaccionGateway;
/*     */   }
/*     */   
/*     */   public Date getFechaTransaccionCTC() {
/* 138 */     return this.fechaTransaccionCTC;
/*     */   }
/*     */   
/*     */   public void setFechaTransaccionCTC(Date fechaTransaccionCTC) {
/* 142 */     this.fechaTransaccionCTC = fechaTransaccionCTC;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-rtb14-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\to\RecargaRecaudacionTo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */