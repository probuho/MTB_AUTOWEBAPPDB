/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlSchemaType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "ServicioTo", propOrder = {"fechaActivacion", "subTipo", "minimoLineasAfiliadas", "estatus", "codigoServicio", "indicadorProvisioning", "fechaInicioServicio", "indicadorCargoMensual", "descripcion", "maximoLineasAfiliadas", "idServicio", "subGrupo", "montoServicio", "fechaEstatus", "grupo", "tipoServicio", "fechaFinServicio", "etiqueta", "comando", "nombreCargoMensual"})
/*     */ public class ServicioTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaActivacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String subTipo;
/*     */   protected int minimoLineasAfiliadas;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String estatus;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigoServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String indicadorProvisioning;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaInicioServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String indicadorCargoMensual;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String descripcion;
/*     */   protected int maximoLineasAfiliadas;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String subGrupo;
/*     */   @XmlElement(required = true, type = Double.class, nillable = true)
/*     */   protected Double montoServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaEstatus;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String grupo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaFinServicio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String etiqueta;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String comando;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nombreCargoMensual;
/*     */   
/*     */   public XMLGregorianCalendar getFechaActivacion() {
/* 127 */     return this.fechaActivacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaActivacion(XMLGregorianCalendar value) {
/* 139 */     this.fechaActivacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubTipo() {
/* 151 */     return this.subTipo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubTipo(String value) {
/* 163 */     this.subTipo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimoLineasAfiliadas() {
/* 171 */     return this.minimoLineasAfiliadas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinimoLineasAfiliadas(int value) {
/* 179 */     this.minimoLineasAfiliadas = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEstatus() {
/* 191 */     return this.estatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEstatus(String value) {
/* 203 */     this.estatus = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigoServicio() {
/* 215 */     return this.codigoServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigoServicio(String value) {
/* 227 */     this.codigoServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndicadorProvisioning() {
/* 239 */     return this.indicadorProvisioning;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndicadorProvisioning(String value) {
/* 251 */     this.indicadorProvisioning = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaInicioServicio() {
/* 263 */     return this.fechaInicioServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaInicioServicio(XMLGregorianCalendar value) {
/* 275 */     this.fechaInicioServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndicadorCargoMensual() {
/* 287 */     return this.indicadorCargoMensual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndicadorCargoMensual(String value) {
/* 299 */     this.indicadorCargoMensual = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescripcion() {
/* 311 */     return this.descripcion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescripcion(String value) {
/* 323 */     this.descripcion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximoLineasAfiliadas() {
/* 331 */     return this.maximoLineasAfiliadas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaximoLineasAfiliadas(int value) {
/* 339 */     this.maximoLineasAfiliadas = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdServicio() {
/* 351 */     return this.idServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdServicio(String value) {
/* 363 */     this.idServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubGrupo() {
/* 375 */     return this.subGrupo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubGrupo(String value) {
/* 387 */     this.subGrupo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getMontoServicio() {
/* 399 */     return this.montoServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMontoServicio(Double value) {
/* 411 */     this.montoServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaEstatus() {
/* 423 */     return this.fechaEstatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaEstatus(XMLGregorianCalendar value) {
/* 435 */     this.fechaEstatus = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getGrupo() {
/* 447 */     return this.grupo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGrupo(String value) {
/* 459 */     this.grupo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoServicio() {
/* 471 */     return this.tipoServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoServicio(String value) {
/* 483 */     this.tipoServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaFinServicio() {
/* 495 */     return this.fechaFinServicio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaFinServicio(XMLGregorianCalendar value) {
/* 507 */     this.fechaFinServicio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEtiqueta() {
/* 519 */     return this.etiqueta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEtiqueta(String value) {
/* 531 */     this.etiqueta = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getComando() {
/* 543 */     return this.comando;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComando(String value) {
/* 555 */     this.comando = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNombreCargoMensual() {
/* 567 */     return this.nombreCargoMensual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNombreCargoMensual(String value) {
/* 579 */     this.nombreCargoMensual = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\ServicioTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */