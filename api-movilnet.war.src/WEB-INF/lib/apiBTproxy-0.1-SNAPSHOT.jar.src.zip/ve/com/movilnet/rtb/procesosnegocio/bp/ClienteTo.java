/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlSchemaType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "ClienteTo", propOrder = {"titulo", "fechaNacimiento", "telefonoHabitacion", "documentoId", "sexo", "segundoNombre", "fechaIngresoEmpresa", "profesion", "correoElectronico", "telefonoOficina", "segundoApellido", "tipoDocumento", "tipoCliente", "extensionOficina", "primerApellido", "primerNombre", "empresa", "cargo", "direccion", "nacionalidad"})
/*     */ public class ClienteTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String titulo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaNacimiento;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String telefonoHabitacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String documentoId;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String sexo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String segundoNombre;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaIngresoEmpresa;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String profesion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String correoElectronico;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String telefonoOficina;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String segundoApellido;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoDocumento;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoCliente;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String extensionOficina;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String primerApellido;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String primerNombre;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String empresa;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String cargo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected DireccionTo direccion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nacionalidad;
/*     */   
/*     */   public String getTitulo() {
/* 127 */     return this.titulo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTitulo(String value) {
/* 139 */     this.titulo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaNacimiento() {
/* 151 */     return this.fechaNacimiento;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaNacimiento(XMLGregorianCalendar value) {
/* 163 */     this.fechaNacimiento = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTelefonoHabitacion() {
/* 175 */     return this.telefonoHabitacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTelefonoHabitacion(String value) {
/* 187 */     this.telefonoHabitacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDocumentoId() {
/* 199 */     return this.documentoId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentoId(String value) {
/* 211 */     this.documentoId = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSexo() {
/* 223 */     return this.sexo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSexo(String value) {
/* 235 */     this.sexo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSegundoNombre() {
/* 247 */     return this.segundoNombre;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSegundoNombre(String value) {
/* 259 */     this.segundoNombre = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaIngresoEmpresa() {
/* 271 */     return this.fechaIngresoEmpresa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaIngresoEmpresa(XMLGregorianCalendar value) {
/* 283 */     this.fechaIngresoEmpresa = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProfesion() {
/* 295 */     return this.profesion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProfesion(String value) {
/* 307 */     this.profesion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCorreoElectronico() {
/* 319 */     return this.correoElectronico;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCorreoElectronico(String value) {
/* 331 */     this.correoElectronico = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTelefonoOficina() {
/* 343 */     return this.telefonoOficina;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTelefonoOficina(String value) {
/* 355 */     this.telefonoOficina = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSegundoApellido() {
/* 367 */     return this.segundoApellido;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSegundoApellido(String value) {
/* 379 */     this.segundoApellido = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoDocumento() {
/* 391 */     return this.tipoDocumento;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoDocumento(String value) {
/* 403 */     this.tipoDocumento = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoCliente() {
/* 415 */     return this.tipoCliente;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoCliente(String value) {
/* 427 */     this.tipoCliente = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExtensionOficina() {
/* 439 */     return this.extensionOficina;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtensionOficina(String value) {
/* 451 */     this.extensionOficina = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrimerApellido() {
/* 463 */     return this.primerApellido;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrimerApellido(String value) {
/* 475 */     this.primerApellido = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrimerNombre() {
/* 487 */     return this.primerNombre;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrimerNombre(String value) {
/* 499 */     this.primerNombre = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEmpresa() {
/* 511 */     return this.empresa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEmpresa(String value) {
/* 523 */     this.empresa = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCargo() {
/* 535 */     return this.cargo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCargo(String value) {
/* 547 */     this.cargo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DireccionTo getDireccion() {
/* 559 */     return this.direccion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDireccion(DireccionTo value) {
/* 571 */     this.direccion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNacionalidad() {
/* 583 */     return this.nacionalidad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNacionalidad(String value) {
/* 595 */     this.nacionalidad = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\ClienteTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */