/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlSchemaType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "LineaTo", propOrder = {"plan", "montoUltimoPago", "formatoSerial", "fechaExpiracionSaldo", "equipo", "tipoChip", "fechaUltimoPago", "cargoUltimaLlamada", "localidad", "fechaActivacion", "unidadesOperaciones", "idBalanceUltimoPago", "personaContacto", "estatus", "saldo", "promocion", "personaAutorizada", "buzonMensaje", "agente", "fechaCreacion", "nuemeroCelular", "ultimoPago", "imei", "fechaCorte", "simCard"})
/*     */ public class LineaTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PlanTo plan;
/*     */   @XmlElement(required = true, type = Double.class, nillable = true)
/*     */   protected Double montoUltimoPago;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String formatoSerial;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaExpiracionSaldo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected EquipoTo equipo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoChip;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaUltimoPago;
/*     */   @XmlElement(required = true, type = Double.class, nillable = true)
/*     */   protected Double cargoUltimaLlamada;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String localidad;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaActivacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String unidadesOperaciones;
/*     */   protected int idBalanceUltimoPago;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PersonaTo personaContacto;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String estatus;
/*     */   @XmlElement(required = true, type = Double.class, nillable = true)
/*     */   protected Double saldo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PromocionTo promocion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PersonaTo personaAutorizada;
/*     */   protected boolean buzonMensaje;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected AgenteTo agente;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaCreacion;
/*     */   @XmlElement(required = true, type = Long.class, nillable = true)
/*     */   protected Long nuemeroCelular;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String ultimoPago;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String imei;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   @XmlSchemaType(name = "dateTime")
/*     */   protected XMLGregorianCalendar fechaCorte;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String simCard;
/*     */   
/*     */   public PlanTo getPlan() {
/* 148 */     return this.plan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlan(PlanTo value) {
/* 160 */     this.plan = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getMontoUltimoPago() {
/* 172 */     return this.montoUltimoPago;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMontoUltimoPago(Double value) {
/* 184 */     this.montoUltimoPago = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormatoSerial() {
/* 196 */     return this.formatoSerial;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormatoSerial(String value) {
/* 208 */     this.formatoSerial = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaExpiracionSaldo() {
/* 220 */     return this.fechaExpiracionSaldo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaExpiracionSaldo(XMLGregorianCalendar value) {
/* 232 */     this.fechaExpiracionSaldo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EquipoTo getEquipo() {
/* 244 */     return this.equipo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEquipo(EquipoTo value) {
/* 256 */     this.equipo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoChip() {
/* 268 */     return this.tipoChip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoChip(String value) {
/* 280 */     this.tipoChip = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaUltimoPago() {
/* 292 */     return this.fechaUltimoPago;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaUltimoPago(XMLGregorianCalendar value) {
/* 304 */     this.fechaUltimoPago = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getCargoUltimaLlamada() {
/* 316 */     return this.cargoUltimaLlamada;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCargoUltimaLlamada(Double value) {
/* 328 */     this.cargoUltimaLlamada = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalidad() {
/* 340 */     return this.localidad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalidad(String value) {
/* 352 */     this.localidad = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaActivacion() {
/* 364 */     return this.fechaActivacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaActivacion(XMLGregorianCalendar value) {
/* 376 */     this.fechaActivacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnidadesOperaciones() {
/* 388 */     return this.unidadesOperaciones;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnidadesOperaciones(String value) {
/* 400 */     this.unidadesOperaciones = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIdBalanceUltimoPago() {
/* 408 */     return this.idBalanceUltimoPago;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdBalanceUltimoPago(int value) {
/* 416 */     this.idBalanceUltimoPago = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersonaTo getPersonaContacto() {
/* 428 */     return this.personaContacto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersonaContacto(PersonaTo value) {
/* 440 */     this.personaContacto = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEstatus() {
/* 452 */     return this.estatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEstatus(String value) {
/* 464 */     this.estatus = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getSaldo() {
/* 476 */     return this.saldo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSaldo(Double value) {
/* 488 */     this.saldo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PromocionTo getPromocion() {
/* 500 */     return this.promocion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPromocion(PromocionTo value) {
/* 512 */     this.promocion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersonaTo getPersonaAutorizada() {
/* 524 */     return this.personaAutorizada;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersonaAutorizada(PersonaTo value) {
/* 536 */     this.personaAutorizada = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBuzonMensaje() {
/* 544 */     return this.buzonMensaje;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuzonMensaje(boolean value) {
/* 552 */     this.buzonMensaje = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AgenteTo getAgente() {
/* 564 */     return this.agente;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAgente(AgenteTo value) {
/* 576 */     this.agente = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaCreacion() {
/* 588 */     return this.fechaCreacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaCreacion(XMLGregorianCalendar value) {
/* 600 */     this.fechaCreacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getNuemeroCelular() {
/* 612 */     return this.nuemeroCelular;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNuemeroCelular(Long value) {
/* 624 */     this.nuemeroCelular = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUltimoPago() {
/* 636 */     return this.ultimoPago;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUltimoPago(String value) {
/* 648 */     this.ultimoPago = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImei() {
/* 660 */     return this.imei;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImei(String value) {
/* 672 */     this.imei = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLGregorianCalendar getFechaCorte() {
/* 684 */     return this.fechaCorte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFechaCorte(XMLGregorianCalendar value) {
/* 696 */     this.fechaCorte = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSimCard() {
/* 708 */     return this.simCard;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSimCard(String value) {
/* 720 */     this.simCard = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\LineaTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */