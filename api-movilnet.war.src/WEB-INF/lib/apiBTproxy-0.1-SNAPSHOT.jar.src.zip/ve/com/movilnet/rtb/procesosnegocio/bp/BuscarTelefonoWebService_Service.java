/*    */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.ws.Service;
/*    */ import javax.xml.ws.WebEndpoint;
/*    */ import javax.xml.ws.WebServiceClient;
/*    */ import javax.xml.ws.WebServiceException;
/*    */ import javax.xml.ws.WebServiceFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebServiceClient(name = "BuscarTelefonoWebService", targetNamespace = "http://bp.procesosnegocio.rtb.movilnet.com.ve/", wsdlLocation = "http://192.168.0.16:8888/BuscarTelefonoServicio/BuscarTelefonoWebServiceSoapHttpPort?WSDL")
/*    */ public class BuscarTelefonoWebService_Service
/*    */   extends Service
/*    */ {
/*    */   private static final URL BUSCARTELEFONOWEBSERVICE_WSDL_LOCATION;
/*    */   private static final WebServiceException BUSCARTELEFONOWEBSERVICE_EXCEPTION;
/* 29 */   private static final QName BUSCARTELEFONOWEBSERVICE_QNAME = new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "BuscarTelefonoWebService");
/*    */   
/*    */   static {
/* 32 */     URL url = null;
/* 33 */     WebServiceException e = null;
/*    */     try {
/* 35 */       url = new URL("http://192.168.0.17:8888/BuscarTelefonoServicio/BuscarTelefonoWebServiceSoapHttpPort?WSDL");
/* 36 */     } catch (MalformedURLException ex) {
/* 37 */       e = new WebServiceException(ex);
/*    */     } 
/* 39 */     BUSCARTELEFONOWEBSERVICE_WSDL_LOCATION = url;
/* 40 */     BUSCARTELEFONOWEBSERVICE_EXCEPTION = e;
/*    */   }
/*    */   
/*    */   public BuscarTelefonoWebService_Service() {
/* 44 */     super(__getWsdlLocation(), BUSCARTELEFONOWEBSERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public BuscarTelefonoWebService_Service(WebServiceFeature... features) {
/* 48 */     super(__getWsdlLocation(), BUSCARTELEFONOWEBSERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public BuscarTelefonoWebService_Service(URL wsdlLocation) {
/* 52 */     super(wsdlLocation, BUSCARTELEFONOWEBSERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public BuscarTelefonoWebService_Service(URL wsdlLocation, WebServiceFeature... features) {
/* 56 */     super(wsdlLocation, BUSCARTELEFONOWEBSERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public BuscarTelefonoWebService_Service(URL wsdlLocation, QName serviceName) {
/* 60 */     super(wsdlLocation, serviceName);
/*    */   }
/*    */   
/*    */   public BuscarTelefonoWebService_Service(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
/* 64 */     super(wsdlLocation, serviceName, features);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @WebEndpoint(name = "BuscarTelefonoWebServiceSoapHttpPort")
/*    */   public BuscarTelefonoWebService getBuscarTelefonoWebServiceSoapHttpPort() {
/* 74 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "BuscarTelefonoWebServiceSoapHttpPort"), BuscarTelefonoWebService.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @WebEndpoint(name = "BuscarTelefonoWebServiceSoapHttpPort")
/*    */   public BuscarTelefonoWebService getBuscarTelefonoWebServiceSoapHttpPort(WebServiceFeature... features) {
/* 86 */     return getPort(new QName("http://bp.procesosnegocio.rtb.movilnet.com.ve/", "BuscarTelefonoWebServiceSoapHttpPort"), BuscarTelefonoWebService.class, features);
/*    */   }
/*    */   
/*    */   private static URL __getWsdlLocation() {
/* 90 */     if (BUSCARTELEFONOWEBSERVICE_EXCEPTION != null) {
/* 91 */       throw BUSCARTELEFONOWEBSERVICE_EXCEPTION;
/*    */     }
/* 93 */     return BUSCARTELEFONOWEBSERVICE_WSDL_LOCATION;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\BuscarTelefonoWebService_Service.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */