/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "CuentaTo", propOrder = {"tipoCuenta", "razonSocial", "numeroCuenta", "subTipoCuenta", "actividadComercial", "idRif", "tipoRif"})
/*     */ public class CuentaTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoCuenta;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String razonSocial;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String numeroCuenta;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String subTipoCuenta;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String actividadComercial;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idRif;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoRif;
/*     */   
/*     */   public String getTipoCuenta() {
/*  71 */     return this.tipoCuenta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoCuenta(String value) {
/*  83 */     this.tipoCuenta = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRazonSocial() {
/*  95 */     return this.razonSocial;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRazonSocial(String value) {
/* 107 */     this.razonSocial = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNumeroCuenta() {
/* 119 */     return this.numeroCuenta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumeroCuenta(String value) {
/* 131 */     this.numeroCuenta = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubTipoCuenta() {
/* 143 */     return this.subTipoCuenta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubTipoCuenta(String value) {
/* 155 */     this.subTipoCuenta = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActividadComercial() {
/* 167 */     return this.actividadComercial;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActividadComercial(String value) {
/* 179 */     this.actividadComercial = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdRif() {
/* 191 */     return this.idRif;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdRif(String value) {
/* 203 */     this.idRif = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoRif() {
/* 215 */     return this.tipoRif;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoRif(String value) {
/* 227 */     this.tipoRif = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\CuentaTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */