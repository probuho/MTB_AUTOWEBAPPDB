/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "BuscarTelefonoRespuestaTo", propOrder = {"servicios", "cuenta", "codigoRazon", "cliente", "linea", "planTexto", "segmento"})
/*     */ public class BuscarTelefonoRespuestaTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected List servicios;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected CuentaTo cuenta;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String codigoRazon;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected ClienteTo cliente;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected LineaTo linea;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected PlanTo planTexto;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String segmento;
/*     */   
/*     */   public List getServicios() {
/*  71 */     return this.servicios;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServicios(List value) {
/*  83 */     this.servicios = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CuentaTo getCuenta() {
/*  95 */     return this.cuenta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCuenta(CuentaTo value) {
/* 107 */     this.cuenta = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigoRazon() {
/* 119 */     return this.codigoRazon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigoRazon(String value) {
/* 131 */     this.codigoRazon = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClienteTo getCliente() {
/* 143 */     return this.cliente;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCliente(ClienteTo value) {
/* 155 */     this.cliente = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineaTo getLinea() {
/* 167 */     return this.linea;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLinea(LineaTo value) {
/* 179 */     this.linea = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlanTo getPlanTexto() {
/* 191 */     return this.planTexto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlanTexto(PlanTo value) {
/* 203 */     this.planTexto = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSegmento() {
/* 215 */     return this.segmento;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSegmento(String value) {
/* 227 */     this.segmento = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\BuscarTelefonoRespuestaTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */