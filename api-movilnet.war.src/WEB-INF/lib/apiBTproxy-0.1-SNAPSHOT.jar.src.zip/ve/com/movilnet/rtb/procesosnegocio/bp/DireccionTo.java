/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "DireccionTo", propOrder = {"nombreCalle", "tipoPiso", "identificadorEdificacion", "parroquiaUrbanizacion", "tipoCalle", "sector", "identificadorPiso", "tipoApartamento", "puntoReferencia", "zonaPostal", "municipio", "estado", "tipoEdificacion", "ciudad", "idApartamento"})
/*     */ public class DireccionTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nombreCalle;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoPiso;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String identificadorEdificacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String parroquiaUrbanizacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoCalle;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String sector;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String identificadorPiso;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoApartamento;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String puntoReferencia;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String zonaPostal;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String municipio;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String estado;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoEdificacion;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String ciudad;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idApartamento;
/*     */   
/*     */   public String getNombreCalle() {
/* 103 */     return this.nombreCalle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNombreCalle(String value) {
/* 115 */     this.nombreCalle = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoPiso() {
/* 127 */     return this.tipoPiso;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoPiso(String value) {
/* 139 */     this.tipoPiso = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdentificadorEdificacion() {
/* 151 */     return this.identificadorEdificacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdentificadorEdificacion(String value) {
/* 163 */     this.identificadorEdificacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParroquiaUrbanizacion() {
/* 175 */     return this.parroquiaUrbanizacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParroquiaUrbanizacion(String value) {
/* 187 */     this.parroquiaUrbanizacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoCalle() {
/* 199 */     return this.tipoCalle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoCalle(String value) {
/* 211 */     this.tipoCalle = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSector() {
/* 223 */     return this.sector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSector(String value) {
/* 235 */     this.sector = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdentificadorPiso() {
/* 247 */     return this.identificadorPiso;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdentificadorPiso(String value) {
/* 259 */     this.identificadorPiso = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoApartamento() {
/* 271 */     return this.tipoApartamento;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoApartamento(String value) {
/* 283 */     this.tipoApartamento = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPuntoReferencia() {
/* 295 */     return this.puntoReferencia;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPuntoReferencia(String value) {
/* 307 */     this.puntoReferencia = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getZonaPostal() {
/* 319 */     return this.zonaPostal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setZonaPostal(String value) {
/* 331 */     this.zonaPostal = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMunicipio() {
/* 343 */     return this.municipio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMunicipio(String value) {
/* 355 */     this.municipio = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEstado() {
/* 367 */     return this.estado;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEstado(String value) {
/* 379 */     this.estado = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoEdificacion() {
/* 391 */     return this.tipoEdificacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoEdificacion(String value) {
/* 403 */     this.tipoEdificacion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCiudad() {
/* 415 */     return this.ciudad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCiudad(String value) {
/* 427 */     this.ciudad = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdApartamento() {
/* 439 */     return this.idApartamento;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdApartamento(String value) {
/* 451 */     this.idApartamento = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\DireccionTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */