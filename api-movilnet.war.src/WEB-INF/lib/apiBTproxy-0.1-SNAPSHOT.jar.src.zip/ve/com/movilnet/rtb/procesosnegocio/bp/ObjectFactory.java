/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.annotation.XmlElementDecl;
/*     */ import javax.xml.bind.annotation.XmlRegistry;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlRegistry
/*     */ public class ObjectFactory
/*     */ {
/*  27 */   private static final QName _AdvertenciaFuncionalExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "AdvertenciaFuncionalExceptionElement");
/*  28 */   private static final QName _ErrorOperacionalExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "ErrorOperacionalExceptionElement");
/*  29 */   private static final QName _PlataformaNoDisponibleExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "PlataformaNoDisponibleExceptionElement");
/*  30 */   private static final QName _MantenimientoExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "MantenimientoExceptionElement");
/*  31 */   private static final QName _SeguridadExceptionElement_QNAME = new QName("http://to.procesosnegocio.rtb.movilnet.com.ve/", "SeguridadExceptionElement");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuscarTelefonoElement createBuscarTelefonoElement() {
/*  45 */     return new BuscarTelefonoElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntradaTo createEntradaTo() {
/*  53 */     return new EntradaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuscarTelefonoResponseElement createBuscarTelefonoResponseElement() {
/*  61 */     return new BuscarTelefonoResponseElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuscarTelefonoRespuestaTo createBuscarTelefonoRespuestaTo() {
/*  69 */     return new BuscarTelefonoRespuestaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException createSeguridadException() {
/*  77 */     return new SeguridadException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdvertenciaFuncionalException createAdvertenciaFuncionalException() {
/*  85 */     return new AdvertenciaFuncionalException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorOperacionalException createErrorOperacionalException() {
/*  93 */     return new ErrorOperacionalException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlataformaNoDisponibleException createPlataformaNoDisponibleException() {
/* 101 */     return new PlataformaNoDisponibleException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MantenimientoException createMantenimientoException() {
/* 109 */     return new MantenimientoException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClienteTo createClienteTo() {
/* 117 */     return new ClienteTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CuentaTo createCuentaTo() {
/* 125 */     return new CuentaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlanTo createPlanTo() {
/* 133 */     return new PlanTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DireccionTo createDireccionTo() {
/* 141 */     return new DireccionTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineaTo createLineaTo() {
/* 149 */     return new LineaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersonaTo createPersonaTo() {
/* 157 */     return new PersonaTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EquipoTo createEquipoTo() {
/* 165 */     return new EquipoTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServicioTo createServicioTo() {
/* 173 */     return new ServicioTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AgenteTo createAgenteTo() {
/* 181 */     return new AgenteTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadTo createSeguridadTo() {
/* 189 */     return new SeguridadTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AplicacionTo createAplicacionTo() {
/* 197 */     return new AplicacionTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException createMovilnetException() {
/* 205 */     return new MovilnetException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PromocionTo createPromocionTo() {
/* 213 */     return new PromocionTo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection createCollection() {
/* 221 */     return new Collection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List createList() {
/* 229 */     return new List();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "AdvertenciaFuncionalExceptionElement")
/*     */   public JAXBElement<AdvertenciaFuncionalException> createAdvertenciaFuncionalExceptionElement(AdvertenciaFuncionalException value) {
/* 238 */     return new JAXBElement<>(_AdvertenciaFuncionalExceptionElement_QNAME, AdvertenciaFuncionalException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "ErrorOperacionalExceptionElement")
/*     */   public JAXBElement<ErrorOperacionalException> createErrorOperacionalExceptionElement(ErrorOperacionalException value) {
/* 247 */     return new JAXBElement<>(_ErrorOperacionalExceptionElement_QNAME, ErrorOperacionalException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "PlataformaNoDisponibleExceptionElement")
/*     */   public JAXBElement<PlataformaNoDisponibleException> createPlataformaNoDisponibleExceptionElement(PlataformaNoDisponibleException value) {
/* 256 */     return new JAXBElement<>(_PlataformaNoDisponibleExceptionElement_QNAME, PlataformaNoDisponibleException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "MantenimientoExceptionElement")
/*     */   public JAXBElement<MantenimientoException> createMantenimientoExceptionElement(MantenimientoException value) {
/* 265 */     return new JAXBElement<>(_MantenimientoExceptionElement_QNAME, MantenimientoException.class, null, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://to.procesosnegocio.rtb.movilnet.com.ve/", name = "SeguridadExceptionElement")
/*     */   public JAXBElement<SeguridadException> createSeguridadExceptionElement(SeguridadException value) {
/* 274 */     return new JAXBElement<>(_SeguridadExceptionElement_QNAME, SeguridadException.class, null, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */