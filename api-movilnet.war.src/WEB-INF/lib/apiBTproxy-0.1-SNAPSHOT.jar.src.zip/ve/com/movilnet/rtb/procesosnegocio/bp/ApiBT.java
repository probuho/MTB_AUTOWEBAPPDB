/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApiBT
/*     */ {
/*     */   public static void main(String[] args) {
/*     */     try {
/*  53 */       BuscarTelefonoElement request = new BuscarTelefonoElement();
/*  54 */       request.setTransaccionId("PC.MARCO");
/*  55 */       request.setNumeroCelular("04161231221");
/*     */ 
/*     */       
/*  58 */       EntradaTo entrada = new EntradaTo();
/*     */       
/*  60 */       entrada.setTecnologia("3");
/*  61 */       entrada.setProveedor("MOVILNET");
/*  62 */       entrada.setNodo("OGM01");
/*     */ 
/*     */       
/*  65 */       SeguridadTo seguridad = new SeguridadTo();
/*  66 */       seguridad.setUsuario("rtb_web");
/*  67 */       seguridad.setClave("rtb_web");
/*  68 */       entrada.setSeguridad(seguridad);
/*     */       
/*  70 */       AplicacionTo aplicacion = new AplicacionTo();
/*  71 */       aplicacion.setNombre("rtb_web");
/*  72 */       aplicacion.setTipoAplicacion("OC");
/*  73 */       entrada.setAplicacion(aplicacion);
/*     */       
/*  75 */       request.setEntrada(entrada);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  82 */       BuscarTelefonoWebService_Service service = new BuscarTelefonoWebService_Service();
/*  83 */       BuscarTelefonoWebService port = service.getBuscarTelefonoWebServiceSoapHttpPort();
/*     */       
/*  85 */       System.out.println(" request " + request);
/*  86 */       BuscarTelefonoResponseElement responseElement = port.buscarTelefono(request);
/*  87 */       BuscarTelefonoRespuestaTo response = responseElement.getResult();
/*     */       
/*  89 */       System.out.println(" ............" + response.getServicios());
/*     */ 
/*     */ 
/*     */       
/*  93 */       ArrayList arrayList = new ArrayList();
/*     */     
/*     */     }
/*  96 */     catch (PlataformaNoDisponibleException_Exception ex) {
/*  97 */       Logger.getLogger(ApiBT.class.getName()).log(Level.SEVERE, (String)null, ex);
/*  98 */     } catch (AdvertenciaFuncionalException_Exception ex) {
/*  99 */       Logger.getLogger(ApiBT.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 100 */     } catch (ErrorOperacionalException_Exception ex) {
/* 101 */       Logger.getLogger(ApiBT.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 102 */     } catch (MantenimientoException_Exception ex) {
/* 103 */       Logger.getLogger(ApiBT.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 104 */     } catch (SeguridadException_Exception ex) {
/* 105 */       Logger.getLogger(ApiBT.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\ApiBT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */