/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "EquipoTo", propOrder = {"tipoEquipo", "idEquipo", "descripcionTipoEquipo", "modelo", "tecnologia"})
/*     */ public class EquipoTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tipoEquipo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String idEquipo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String descripcionTipoEquipo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String modelo;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String tecnologia;
/*     */   
/*     */   public String getTipoEquipo() {
/*  63 */     return this.tipoEquipo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoEquipo(String value) {
/*  75 */     this.tipoEquipo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdEquipo() {
/*  87 */     return this.idEquipo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdEquipo(String value) {
/*  99 */     this.idEquipo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescripcionTipoEquipo() {
/* 111 */     return this.descripcionTipoEquipo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescripcionTipoEquipo(String value) {
/* 123 */     this.descripcionTipoEquipo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getModelo() {
/* 135 */     return this.modelo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModelo(String value) {
/* 147 */     this.modelo = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTecnologia() {
/* 159 */     return this.tecnologia;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTecnologia(String value) {
/* 171 */     this.tecnologia = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\EquipoTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */