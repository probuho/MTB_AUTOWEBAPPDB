/*     */ package ve.com.movilnet.rtb.procesosnegocio.bp;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "PersonaTo", propOrder = {"cedula", "nombre", "apellido", "telefono"})
/*     */ public class PersonaTo
/*     */ {
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String cedula;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String nombre;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String apellido;
/*     */   @XmlElement(required = true, nillable = true)
/*     */   protected String telefono;
/*     */   
/*     */   public String getCedula() {
/*  59 */     return this.cedula;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCedula(String value) {
/*  71 */     this.cedula = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNombre() {
/*  83 */     return this.nombre;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNombre(String value) {
/*  95 */     this.nombre = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getApellido() {
/* 107 */     return this.apellido;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApellido(String value) {
/* 119 */     this.apellido = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTelefono() {
/* 131 */     return this.telefono;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTelefono(String value) {
/* 143 */     this.telefono = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\PersonaTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */