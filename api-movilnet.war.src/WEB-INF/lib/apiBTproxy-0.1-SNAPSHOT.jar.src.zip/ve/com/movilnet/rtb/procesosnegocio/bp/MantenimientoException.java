package ve.com.movilnet.rtb.procesosnegocio.bp;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MantenimientoException")
public class MantenimientoException extends AdvertenciaFuncionalException {}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\apiBTproxy-0.1-SNAPSHOT.jar!\ve\com\movilnet\rtb\procesosnegocio\bp\MantenimientoException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */