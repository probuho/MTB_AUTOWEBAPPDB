package com.sun.xml.rpc.spi.tools;

import java.net.URL;

public interface WSDLParser {
  WSDLDocument getWSDLDocument(URL paramURL);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\WSDLParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */