/*    */ package com.sun.xml.rpc.spi.tools;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CompileToolDelegate
/*    */ {
/*    */   public Configuration createConfiguration() {
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   public void preOnError() {}
/*    */   
/*    */   public void postRegisterProcessorActions() {}
/*    */   
/*    */   public void postRun() {}
/*    */   
/*    */   public void setCompileTool(CompileTool wscompile) {}
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\CompileToolDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */