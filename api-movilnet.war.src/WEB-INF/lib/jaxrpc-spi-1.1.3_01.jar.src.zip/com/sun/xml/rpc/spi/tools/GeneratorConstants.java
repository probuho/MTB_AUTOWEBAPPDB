package com.sun.xml.rpc.spi.tools;

public interface GeneratorConstants {
  public static final String FILE_TYPE_WSDL = "Wsdl";
  
  public static final String FILE_TYPE_REMOTE_INTERFACE = "RemoteInterface";
  
  public static final String FILE_TYPE_SERVICE = "Service";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\GeneratorConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */