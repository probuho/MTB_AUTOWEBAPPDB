package com.sun.xml.rpc.spi.tools;

import java.io.File;

public interface GeneratedFileInfo {
  File getFile();
  
  String getType();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\GeneratedFileInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */