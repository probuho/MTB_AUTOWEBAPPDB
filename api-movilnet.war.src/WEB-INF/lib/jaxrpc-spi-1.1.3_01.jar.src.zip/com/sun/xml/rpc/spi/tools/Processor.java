package com.sun.xml.rpc.spi.tools;

import com.sun.xml.rpc.spi.model.Model;

public interface Processor {
  Model getModel();
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\Processor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */