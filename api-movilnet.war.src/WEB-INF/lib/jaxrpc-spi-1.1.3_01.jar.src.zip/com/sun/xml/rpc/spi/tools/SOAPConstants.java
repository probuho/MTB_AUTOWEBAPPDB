package com.sun.xml.rpc.spi.tools;

public interface SOAPConstants {
  public static final String NS_SOAP_ENCODING = "http://schemas.xmlsoap.org/soap/encoding/";
  
  public static final String URI_ENVELOPE = "http://schemas.xmlsoap.org/soap/envelope/";
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\SOAPConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */