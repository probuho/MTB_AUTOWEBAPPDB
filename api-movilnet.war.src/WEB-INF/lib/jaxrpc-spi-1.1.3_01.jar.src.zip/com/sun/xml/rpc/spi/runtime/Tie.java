package com.sun.xml.rpc.spi.runtime;

import java.rmi.Remote;

public interface Tie extends Handler {
  void setTarget(Remote paramRemote);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\runtime\Tie.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */