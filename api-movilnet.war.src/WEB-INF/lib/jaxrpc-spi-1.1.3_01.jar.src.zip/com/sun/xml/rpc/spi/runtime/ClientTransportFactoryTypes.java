package com.sun.xml.rpc.spi.runtime;

public interface ClientTransportFactoryTypes {
  public static final int HTTP = 0;
  
  public static final int LOCAL = 1;
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\runtime\ClientTransportFactoryTypes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */