package com.sun.xml.rpc.spi.tools;

import com.sun.xml.rpc.spi.model.JavaInterface;
import com.sun.xml.rpc.spi.model.Port;

public interface Names {
  String stubFor(Port paramPort);
  
  String interfaceImplClassName(JavaInterface paramJavaInterface);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\Names.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */