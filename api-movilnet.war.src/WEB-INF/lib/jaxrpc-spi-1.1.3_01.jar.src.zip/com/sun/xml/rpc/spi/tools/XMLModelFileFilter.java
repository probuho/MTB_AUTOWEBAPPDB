package com.sun.xml.rpc.spi.tools;

import java.io.InputStream;
import java.net.URL;

public interface XMLModelFileFilter {
  boolean isModelFile(InputStream paramInputStream);
  
  boolean isModelFile(URL paramURL);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\XMLModelFileFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */