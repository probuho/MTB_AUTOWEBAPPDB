package com.sun.xml.rpc.spi.tools;

import javax.xml.namespace.QName;

public interface WSDLDocument {
  QName[] getAllServiceQNames();
  
  QName[] getAllPortQNames();
  
  QName[] getPortQNames(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\tools\WSDLDocument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */