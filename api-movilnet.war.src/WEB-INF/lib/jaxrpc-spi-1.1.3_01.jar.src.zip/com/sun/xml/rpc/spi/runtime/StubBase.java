package com.sun.xml.rpc.spi.runtime;

public interface StubBase {
  void _setTransportFactory(ClientTransportFactory paramClientTransportFactory);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\jaxrpc-spi-1.1.3_01.jar!\com\sun\xml\rpc\spi\runtime\StubBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */