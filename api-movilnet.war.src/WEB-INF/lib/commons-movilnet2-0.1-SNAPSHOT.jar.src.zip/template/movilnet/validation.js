function clearErrorMessages(form) {
}

function clearErrorLabels(form) {
}

function addError(e, errorText) {
    alert (errorText);
}
