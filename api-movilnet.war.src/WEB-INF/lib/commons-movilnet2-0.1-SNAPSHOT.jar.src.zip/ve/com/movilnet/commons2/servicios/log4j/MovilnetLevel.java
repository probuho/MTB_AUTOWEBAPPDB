/*    */ package ve.com.movilnet.commons2.servicios.log4j;
/*    */ 
/*    */ import org.apache.log4j.Level;
/*    */ 
/*    */ public class MovilnetLevel
/*    */   extends Level
/*    */ {
/*  8 */   public static final String[] LEVELS = new String[] { "ALL", "PERF", "DEBUG", "TRACE", "INFO", "STATS", "WARN", "ALARM", "ERROR", "FATAL", "OFF" };
/*    */   
/*    */   public static final int PERF_INT = 9990;
/*    */   public static final int STATS_INT = 29990;
/*    */   public static final int ALARM_INT = 39990;
/*    */   public static final String PERF_STRING = "PERF";
/*    */   public static final String STATS_STRING = "STATS";
/*    */   public static final String ALARM_STRING = "ALARM";
/* 16 */   public static final Level PERF = new MovilnetLevel(9990, "PERF", 7);
/* 17 */   public static final Level STATS = new MovilnetLevel(29990, "STATS", 7);
/* 18 */   public static final Level ALARM = new MovilnetLevel(39990, "ALARM", 7);
/*    */   
/*    */   protected MovilnetLevel(int level, String levelString, int syslogEquivalent) {
/* 21 */     super(level, levelString, syslogEquivalent);
/*    */   }
/*    */   
/*    */   public static Level toLevel(String level) {
/* 25 */     if (level != null) {
/* 26 */       if (level.toUpperCase().equals("PERF"))
/* 27 */         return PERF; 
/* 28 */       if (level.toUpperCase().equals("STATS"))
/* 29 */         return STATS; 
/* 30 */       if (level.toUpperCase().equals("ALARM")) {
/* 31 */         return ALARM;
/*    */       }
/*    */     } 
/* 34 */     return toLevel(level, Level.DEBUG);
/*    */   }
/*    */   
/*    */   public static Level toLevel(String level, Level defaultLevel) {
/* 38 */     if (level != null) {
/* 39 */       if (level.toUpperCase().equals("PERF"))
/* 40 */         return PERF; 
/* 41 */       if (level.toUpperCase().equals("STATS"))
/* 42 */         return STATS; 
/* 43 */       if (level.toUpperCase().equals("ALARM")) {
/* 44 */         return ALARM;
/*    */       }
/*    */     } 
/* 47 */     return Level.toLevel(level, defaultLevel);
/*    */   }
/*    */   
/*    */   public static Level toLevel(int val) {
/* 51 */     if (val == 9990)
/* 52 */       return PERF; 
/* 53 */     if (val == 29990)
/* 54 */       return STATS; 
/* 55 */     if (val == 39990) {
/* 56 */       return ALARM;
/*    */     }
/* 58 */     return toLevel(val, Level.DEBUG);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Level toLevel(int val, Level defaultLevel) {
/* 63 */     if (val == 9990)
/* 64 */       return PERF; 
/* 65 */     if (val == 29990)
/* 66 */       return STATS; 
/* 67 */     if (val == 39990) {
/* 68 */       return ALARM;
/*    */     }
/* 70 */     return Level.toLevel(val, defaultLevel);
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\log4j\MovilnetLevel.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */