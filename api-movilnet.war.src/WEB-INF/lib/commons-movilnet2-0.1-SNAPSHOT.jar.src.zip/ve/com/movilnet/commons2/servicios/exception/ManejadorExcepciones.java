/*     */ package ve.com.movilnet.commons2.servicios.exception;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Arrays;
/*     */ import org.acegisecurity.AuthenticationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManejadorExcepciones
/*     */ {
/*  18 */   private static final int[] PLATAFORMA_NO_DISPONIBLE_ORA_CODIGOS = new int[] { 1033, 1089, 12505, 12518, 12519, 12528, 12541, 17002 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararMantenimientoException(String aplicacion) throws MantenimientoException {
/*  25 */     dispararMantenimientoException(null, null, null, null, aplicacion, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararMantenimientoException(String origen, String tipoTransaccion, String tipoObjeto, String aplicacion) throws MantenimientoException {
/*  36 */     dispararMantenimientoException(null, origen, tipoTransaccion, tipoObjeto, aplicacion, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararMantenimientoException(String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma) throws MantenimientoException {
/*  48 */     dispararMantenimientoException(null, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararMantenimientoException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma) throws MantenimientoException {
/*  61 */     throw new MantenimientoException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, "MNT-0000", "La aplicación se encuentra en mantenimiento");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararSeguridadException(String aplicacion) throws SeguridadException {
/*  69 */     dispararSeguridadException(null, null, null, null, aplicacion, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararSeguridadException(String origen, String tipoTransaccion, String tipoObjeto, String aplicacion) throws SeguridadException {
/*  80 */     dispararSeguridadException(null, origen, tipoTransaccion, tipoObjeto, aplicacion, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararSeguridadException(String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma) throws SeguridadException {
/*  92 */     dispararSeguridadException(null, origen, aplicacion, tipoTransaccion, tipoObjeto, plataforma);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispararSeguridadException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma) throws SeguridadException {
/* 105 */     throw new SeguridadException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, "SEG-0000", "No puede acceder al recurso");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MovilnetException manejar(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, Throwable e) {
/* 119 */     if (e instanceof MovilnetException)
/* 120 */       return manejarMovilnetException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, (MovilnetException)e); 
/* 121 */     if (e instanceof SQLException)
/* 122 */       return manejarSQLException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, (SQLException)e); 
/* 123 */     if (e instanceof RemoteException)
/* 124 */       return manejarRemoteException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, (RemoteException)e); 
/* 125 */     if (e instanceof AuthenticationException)
/* 126 */       return manejarAuthenticationException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, (AuthenticationException)e); 
/* 127 */     if (e != null) {
/* 128 */       return new ErrorOperacionalException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, null, e.getMessage(), e);
/*     */     }
/* 130 */     return new ErrorOperacionalException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MovilnetException manejar(String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, Throwable e) {
/* 143 */     return manejar(null, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MovilnetException manejar(String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, Throwable e) {
/* 155 */     return manejar(null, origen, tipoTransaccion, tipoObjeto, aplicacion, null, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MovilnetException manejar(Throwable e) {
/* 163 */     return manejar(null, null, null, null, null, e);
/*     */   }
/*     */   
/*     */   private static MovilnetException manejarMovilnetException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, MovilnetException e) {
/* 167 */     if (e.getTransaccionId() == null) e.setTransaccionId(transaccionId); 
/* 168 */     if (e.getAplicacion() == null) e.setAplicacion(aplicacion); 
/* 169 */     if (e.getOrigen() == null) e.setOrigen(origen); 
/* 170 */     if (e.getTipoTransaccion() == null) e.setTipoTransaccion(tipoTransaccion); 
/* 171 */     if (e.getTipoObjeto() == null) e.setTipoTransaccion(tipoObjeto); 
/* 172 */     if (e.getPlataforma() == null) e.setPlataforma(plataforma);
/*     */     
/* 174 */     return e;
/*     */   }
/*     */   
/*     */   private static MovilnetException manejarSQLException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, SQLException e) {
/* 178 */     int codigo = e.getErrorCode();
/* 179 */     String mensaje = e.getMessage();
/*     */     
/* 181 */     if (codigo == 0) {
/* 182 */       int index = mensaje.indexOf("ORA-");
/*     */       try {
/* 184 */         codigo = Integer.parseInt(mensaje.substring(index + 4, index + 9));
/* 185 */       } catch (Exception e2) {}
/*     */     } 
/*     */     
/* 188 */     if (Arrays.binarySearch(PLATAFORMA_NO_DISPONIBLE_ORA_CODIGOS, codigo) >= 0) {
/* 189 */       return new PlataformaNoDisponibleException(transaccionId, origen, "DB", "CONNECTION", aplicacion, plataforma, "ORA-" + codigo, mensaje, e);
/*     */     }
/* 191 */     return new ErrorOperacionalException(transaccionId, origen, "DB", tipoObjeto, aplicacion, plataforma, "ORA-" + codigo, mensaje, e);
/*     */   }
/*     */   
/*     */   private static MovilnetException manejarRemoteException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, RemoteException e) {
/* 195 */     if (e.detail != null && e.detail.getClass().getName().equals("oracle.j2ee.ws.client.ClientTransportException")) {
/* 196 */       return new PlataformaNoDisponibleException(transaccionId, origen, "WS", "CONNECTION", aplicacion, plataforma, "RMI-0000", e.getMessage(), e);
/*     */     }
/* 198 */     return new ErrorOperacionalException(transaccionId, origen, "WS", tipoObjeto, aplicacion, plataforma, "RMI-0000", e.getMessage(), e);
/*     */   }
/*     */   
/*     */   private static MovilnetException manejarAuthenticationException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, AuthenticationException e) {
/* 202 */     if (e instanceof org.acegisecurity.BadCredentialsException)
/* 203 */       return new SeguridadException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, "SEC-0000", e.getMessage(), (Throwable)e); 
/* 204 */     if (e instanceof org.acegisecurity.LockedException)
/* 205 */       return new SeguridadException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, "SEC-0000", e.getMessage(), (Throwable)e); 
/* 206 */     if (e instanceof org.acegisecurity.DisabledException)
/* 207 */       return new SeguridadException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, "SEC-0000", e.getMessage(), (Throwable)e); 
/* 208 */     if (e instanceof org.acegisecurity.AuthenticationServiceException) {
/* 209 */       if (e.getCause() != null) {
/* 210 */         return manejar(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, e.getCause());
/*     */       }
/* 212 */       return new ErrorOperacionalException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, "SEC-0000", e.getMessage(), (Throwable)e);
/*     */     } 
/*     */     
/* 215 */     return new ErrorOperacionalException(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, "SEC-0000", e.getMessage(), (Throwable)e);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\exception\ManejadorExcepciones.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */