/*     */ package ve.com.movilnet.commons2.servicios.exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovilnetException
/*     */   extends Exception
/*     */ {
/*     */   public static final String TIPO_TRANSACCION_APP = "APP";
/*     */   public static final String TIPO_TRANSACCION_DB = "DB";
/*     */   public static final String TIPO_TRANSACCION_LDAP = "LDAP";
/*     */   public static final String TIPO_TRANSACCION_RSA = "RSA";
/*     */   public static final String TIPO_TRANSACCION_WS = "WS";
/*     */   public static final String TIPO_TRANSACCION_URL = "URL";
/*     */   public static final String TIPO_OBJETO_CACHE = "CACHE";
/*     */   public static final String TIPO_OBJETO_CONNECTION = "CONNECTION";
/*     */   public static final String TIPO_OBJETO_FUNCTION = "FUNCTION";
/*     */   public static final String TIPO_OBJETO_PROCEDURE = "PROCEDURE";
/*     */   public static final String TIPO_OBJETO_PACKAGE = "PACKAGE";
/*     */   public static final String TIPO_OBJETO_DATASOURCE = "DATASOURCE";
/*     */   private String transaccionId;
/*     */   private String codigo;
/*     */   private String mensaje;
/*     */   private String aplicacion;
/*     */   private String plataforma;
/*     */   private String origen;
/*     */   private String tipoTransaccion;
/*     */   private String tipoObjeto;
/*     */   
/*     */   public MovilnetException() {}
/*     */   
/*     */   public MovilnetException(String aplicacion, String codigo, String mensaje) {
/*  47 */     super(mensaje);
/*     */     
/*  49 */     this.aplicacion = aplicacion;
/*  50 */     this.codigo = codigo;
/*  51 */     this.mensaje = mensaje;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException(String aplicacion, String codigo, String mensaje, Throwable cause) {
/*  61 */     super(mensaje, cause);
/*     */     
/*  63 */     this.aplicacion = aplicacion;
/*  64 */     this.codigo = codigo;
/*  65 */     this.mensaje = mensaje;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException(String aplicacion, String plataforma, String codigo, String mensaje, Throwable cause) {
/*  76 */     this(aplicacion, codigo, mensaje, cause);
/*  77 */     this.plataforma = plataforma;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException(String aplicacion, String plataforma, String codigo, String mensaje) {
/*  87 */     this(aplicacion, codigo, mensaje, (Throwable)null);
/*  88 */     this.plataforma = plataforma;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException(String transaccionId, String aplicacion, String plataforma, String codigo, String mensaje, Throwable cause) {
/* 100 */     this(aplicacion, plataforma, codigo, mensaje, cause);
/* 101 */     this.transaccionId = transaccionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException(String transaccionId, String aplicacion, String plataforma, String codigo, String mensaje) {
/* 112 */     this(transaccionId, aplicacion, plataforma, codigo, mensaje, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, String codigo, String mensaje, Throwable cause) {
/* 127 */     this(transaccionId, aplicacion, plataforma, codigo, mensaje, cause);
/* 128 */     this.origen = origen;
/* 129 */     this.tipoTransaccion = tipoTransaccion;
/* 130 */     this.tipoObjeto = tipoObjeto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovilnetException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, String codigo, String mensaje) {
/* 144 */     this(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, codigo, mensaje, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransaccionId() {
/* 151 */     return this.transaccionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodigo() {
/* 158 */     return this.codigo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMensaje() {
/* 165 */     return this.mensaje;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAplicacion() {
/* 172 */     return this.aplicacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPlataforma() {
/* 179 */     return this.plataforma;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransaccionId(String transaccionId) {
/* 186 */     this.transaccionId = transaccionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodigo(String codigo) {
/* 193 */     this.codigo = codigo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMensaje(String mensaje) {
/* 200 */     this.mensaje = mensaje;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAplicacion(String aplicacion) {
/* 207 */     this.aplicacion = aplicacion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlataforma(String plataforma) {
/* 214 */     this.plataforma = plataforma;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 221 */     return this.mensaje;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrigen(String origen) {
/* 228 */     this.origen = origen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOrigen() {
/* 245 */     return this.origen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTipoObjeto(String tipoObjeto) {
/* 252 */     this.tipoObjeto = tipoObjeto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTipoObjeto() {
/* 259 */     return this.tipoObjeto;
/*     */   }
/*     */   
/*     */   public void setTipoTransaccion(String tipoTransaccion) {
/* 263 */     this.tipoTransaccion = tipoTransaccion;
/*     */   }
/*     */   
/*     */   public String getTipoTransaccion() {
/* 267 */     return this.tipoTransaccion;
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\exception\MovilnetException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */