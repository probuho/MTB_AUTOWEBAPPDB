/*     */ package ve.com.movilnet.commons2.servicios.exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SeguridadException
/*     */   extends AdvertenciaFuncionalException
/*     */ {
/*     */   public SeguridadException() {}
/*     */   
/*     */   public SeguridadException(String aplicacion, String codigo, String mensaje) {
/*  17 */     super(aplicacion, codigo, mensaje);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException(String aplicacion, String codigo, String mensaje, Throwable cause) {
/*  27 */     super(aplicacion, codigo, mensaje, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException(String aplicacion, String plataforma, String codigo, String mensaje, Throwable cause) {
/*  38 */     super(aplicacion, plataforma, codigo, mensaje, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException(String aplicacion, String plataforma, String codigo, String mensaje) {
/*  48 */     super(aplicacion, plataforma, codigo, mensaje);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException(String transaccionId, String aplicacion, String plataforma, String codigo, String mensaje, Throwable cause) {
/*  60 */     super(transaccionId, aplicacion, plataforma, codigo, mensaje, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException(String transaccionId, String aplicacion, String plataforma, String codigo, String mensaje) {
/*  71 */     super(transaccionId, aplicacion, plataforma, codigo, mensaje);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, String codigo, String mensaje, Throwable cause) {
/*  86 */     super(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, codigo, mensaje, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeguridadException(String transaccionId, String origen, String tipoTransaccion, String tipoObjeto, String aplicacion, String plataforma, String codigo, String mensaje) {
/* 100 */     super(transaccionId, origen, tipoTransaccion, tipoObjeto, aplicacion, plataforma, codigo, mensaje);
/*     */   }
/*     */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\exception\SeguridadException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */