/*    */ package ve.com.movilnet.commons2.servicios.log4j;
/*    */ 
/*    */ import org.apache.log4j.helpers.FormattingInfo;
/*    */ import org.apache.log4j.helpers.PatternConverter;
/*    */ import org.apache.log4j.helpers.PatternParser;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ public class MovilnetPatternParser
/*    */   extends PatternParser
/*    */ {
/*    */   public MovilnetPatternParser(String pattern) {
/* 12 */     super(pattern);
/*    */   }
/*    */   public void finalizeConverter(char formatChar) {
/*    */     String option;
/* 16 */     PatternConverter pc = null;
/*    */     
/* 18 */     int index = 0;
/*    */     
/* 20 */     switch (formatChar) {
/*    */       case 'm':
/* 22 */         option = extractOption();
/*    */         try {
/* 24 */           if (option != null) index = Integer.parseInt(option);
/*    */         
/* 26 */         } catch (NumberFormatException e) {}
/*    */ 
/*    */         
/* 29 */         pc = new MovilnetPatternConverter(this.formattingInfo, index);
/* 30 */         this.currentLiteral.setLength(0);
/* 31 */         addConverter(pc);
/*    */         return;
/*    */     } 
/* 34 */     super.finalizeConverter(formatChar);
/*    */   }
/*    */   
/*    */   private static class MovilnetPatternConverter
/*    */     extends PatternConverter {
/*    */     private int index;
/*    */     
/*    */     MovilnetPatternConverter(FormattingInfo formattingInfo, int index) {
/* 42 */       super(formattingInfo);
/*    */       
/* 44 */       this.index = index;
/*    */     }
/*    */     
/*    */     public String convert(LoggingEvent event) {
/* 48 */       String result = null;
/*    */ 
/*    */       
/* 51 */       if (event.getMessage() instanceof Object[]) {
/* 52 */         Object[] messages = (Object[])event.getMessage();
/*    */         
/* 54 */         if (this.index >= 0 && this.index < messages.length && messages[this.index] != null)
/* 55 */           result = messages[this.index].toString().replace('\n', ' ').replace('\r', ' '); 
/* 56 */       } else if (this.index == 0 && event.getMessage() != null) {
/* 57 */         result = event.getMessage().toString().replace('\n', ' ').replace('\r', ' ');
/*    */       } 
/*    */       
/* 60 */       return result;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\log4j\MovilnetPatternParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */