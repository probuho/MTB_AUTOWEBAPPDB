/*    */ package ve.com.movilnet.commons2.servicios.mantenimiento;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.Priority;
/*    */ import org.quartz.Scheduler;
/*    */ import org.quartz.SchedulerException;
/*    */ import ve.com.movilnet.commons2.servicios.log4j.MovilnetLevel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Mantenimiento
/*    */ {
/* 14 */   private static final Logger logger = Logger.getLogger(Mantenimiento.class);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean habilitar;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Scheduler scheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setHabilitar(boolean habilitar) {
/*    */     try {
/* 31 */       this.habilitar = habilitar;
/*    */       
/* 33 */       if (this.scheduler != null) {
/* 34 */         if (habilitar) {
/* 35 */           this.scheduler.pauseAll();
/*    */         } else {
/* 37 */           this.scheduler.resumeAll();
/*    */         } 
/*    */       }
/* 40 */     } catch (SchedulerException e) {
/* 41 */       if (logger.isEnabledFor((Priority)MovilnetLevel.ERROR)) logger.log((Priority)MovilnetLevel.ERROR, new String[] { e.getMessage(), "Mantenimiento.setHabilitar" });
/*    */     
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isHabilitar() {
/* 49 */     return this.habilitar;
/*    */   }
/*    */   
/*    */   public void setScheduler(Scheduler scheduler) {
/* 53 */     this.scheduler = scheduler;
/*    */   }
/*    */   
/*    */   public Scheduler getScheduler() {
/* 57 */     return this.scheduler;
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\mantenimiento\Mantenimiento.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */