/*    */ package ve.com.movilnet.commons2.servicios.dao;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.log4j.Logger;
/*    */ import ve.com.movilnet.commons2.servicios.exception.ManejadorExcepciones;
/*    */ import ve.com.movilnet.commons2.servicios.exception.MovilnetException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonDao
/*    */ {
/* 18 */   private static final Logger logger = Logger.getLogger(CommonDao.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private DataSource dataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataSource getDataSource() {
/* 32 */     return this.dataSource;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDataSource(DataSource dataSource) {
/* 39 */     this.dataSource = dataSource;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Connection getConnection() throws MovilnetException {
/* 47 */     Connection connection = null;
/*    */     
/*    */     try {
/* 50 */       connection = this.dataSource.getConnection();
/*    */     }
/* 52 */     catch (SQLException e) {
/* 53 */       throw ManejadorExcepciones.manejar(null, "DB", "CONNECTION", null, e);
/*    */     } 
/*    */     
/* 56 */     return connection;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void closeJdbcObjects(Connection connection, Statement statement) throws MovilnetException {
/* 64 */     closeJdbcObjects(connection, statement, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void closeJdbcObjects(Connection connection, Statement statement, ResultSet result) throws MovilnetException {
/*    */     try {
/* 74 */       if (result != null) result.close(); 
/* 75 */     } catch (SQLException e) {
/* 76 */       throw ManejadorExcepciones.manejar(null, "DB", "CONNECTION", null, e);
/*    */     } 
/*    */     
/*    */     try {
/* 80 */       if (statement != null) statement.close(); 
/* 81 */     } catch (SQLException e) {
/* 82 */       throw ManejadorExcepciones.manejar(null, "DB", "CONNECTION", null, e);
/*    */     } 
/*    */     
/*    */     try {
/* 86 */       if (connection != null) connection.close(); 
/* 87 */     } catch (SQLException e) {
/* 88 */       throw ManejadorExcepciones.manejar(null, "DB", "CONNECTION", null, e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\dao\CommonDao.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */