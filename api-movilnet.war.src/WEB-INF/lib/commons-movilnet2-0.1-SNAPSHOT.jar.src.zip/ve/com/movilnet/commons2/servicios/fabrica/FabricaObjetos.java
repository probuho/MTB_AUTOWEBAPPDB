package ve.com.movilnet.commons2.servicios.fabrica;

public interface FabricaObjetos {
  Object getObjeto(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\commons-movilnet2-0.1-SNAPSHOT.jar!\ve\com\movilnet\commons2\servicios\fabrica\FabricaObjetos.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */