package org.slf4j;

public interface ILoggerFactory {
  Logger getLogger(String paramString);
}


/* Location:              C:\Users\aruizc01\Desktop\api-movilnet.war!\WEB-INF\lib\slf4j-api-1.7.28.jar!\org\slf4j\ILoggerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */